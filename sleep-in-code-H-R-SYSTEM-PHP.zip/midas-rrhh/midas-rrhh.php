<?php
/*
Plugin Name: Midas RRHH
Plugin URI: https://accesswork.com.ar
Description: Sistema integral de gestión de recursos humanos
Version: 1.0.1.2
Author: Accesswork Technology
Author URI: https://accesswork.com.ar
License: GPLv2 or later
Text Domain: midas-rrhh
*/

if (!defined('ABSPATH')) exit;

/* =========================
 * DEBUG (solo desarrollo)
 * ========================= */
if (!defined('WP_DEBUG'))         define('WP_DEBUG', true);
if (!defined('WP_DEBUG_LOG'))     define('WP_DEBUG_LOG', true);
if (!defined('WP_DEBUG_DISPLAY')) define('WP_DEBUG_DISPLAY', false);

/* =========================
 * Constantes del plugin
 * ========================= */
define('MIDAS_RRHH_VERSION', '1.0.1.2');
define('MIDAS_RRHH_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MIDAS_RRHH_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MIDAS_RRHH_BASENAME', plugin_basename(__FILE__));

/* =========================
 * Autoloader
 * ========================= */
require_once MIDAS_RRHH_PLUGIN_DIR . 'includes/class-autoloader.php';

/* Guard de submenús/pestañas admin (opcional) */
if (is_admin()) {
    $guard_path = MIDAS_RRHH_PLUGIN_DIR . 'templates/admin/includes/admin-submenu-guard.php';
    if (file_exists($guard_path)) {
        require_once $guard_path;
    } else {
        error_log('[Midas RRHH] Falta templates/admin/includes/admin-submenu-guard.php');
    }
}

/* =========================
 * Hooks ciclo de vida
 * ========================= */
if (class_exists('MidasRRHH\Core\Installer')) {
    register_activation_hook(__FILE__,   ['MidasRRHH\Core\Installer', 'activate']);
    register_deactivation_hook(__FILE__, ['MidasRRHH\Core\Installer', 'deactivate']);
    register_uninstall_hook(__FILE__,    ['MidasRRHH\Core\Installer', 'uninstall']);
    MidasRRHH\Core\Installer::init();
} else {
    error_log('ERROR: No se encontró la clase Installer. Verifica el autoloader y las rutas.');
}

/* =========================
 * Bootstrap del plugin
 * ========================= */
add_action('plugins_loaded', function () {
    load_plugin_textdomain('midas-rrhh', false, dirname(MIDAS_RRHH_BASENAME) . '/languages/');

    if (class_exists('MidasRRHH\Core\Roles'))                MidasRRHH\Core\Roles::init();
    if (class_exists('MidasRRHH\Admin\Admin'))               MidasRRHH\Admin\Admin::init();
    if (class_exists('MidasRRHH\Frontend\Frontend'))         MidasRRHH\Frontend\Frontend::init();
    if (class_exists('MidasRRHH\Ajax\Ajax_Handler'))         MidasRRHH\Ajax\Ajax_Handler::init();

    // Pantalla de bienvenida (si existe)
    if (class_exists('MidasRRHH\Controllers\WelcomeController')) {
        MidasRRHH\Controllers\WelcomeController::maybe_show_welcome();
    }

    // =========================
    // API REST + admin_post para API Keys
    // =========================
    if (class_exists(\MidasRRHH\Controllers\API_Controller::class)) {
        \MidasRRHH\Controllers\API_Controller::init();
    } else {
        // Fallback por si el autoloader no encontró la clase (ajusta la ruta si tu estructura difiere)
        $api_file_candidates = [
            MIDAS_RRHH_PLUGIN_DIR . 'Controllers/API_Controller.php',
            MIDAS_RRHH_PLUGIN_DIR . 'controllers/API_Controller.php',
            MIDAS_RRHH_PLUGIN_DIR . 'includes/Controllers/API_Controller.php',
        ];
        foreach ($api_file_candidates as $api_file) {
            if (file_exists($api_file)) { require_once $api_file; break; }
        }
        if (class_exists(\MidasRRHH\Controllers\API_Controller::class)) {
            \MidasRRHH\Controllers\API_Controller::init();
            error_log('[Midas RRHH] API_Controller inicializado (fallback).');
        } else {
            error_log('[Midas RRHH] API_Controller no encontrado. No se registraron rutas REST ni admin_post de API keys.');
        }
    }
});

/* =========================
 * Shortcodes (opcional)
 * ========================= */
if (class_exists('MidasRRHH\Frontend\Login')) {
    add_shortcode('midas_login', ['MidasRRHH\Frontend\Login', 'render_login_form']);
}

/* ========================================================================
 * MENÚ ADMIN + PANTALLA "REPORTES" (fallback para asegurar el ítem)
 * ======================================================================== */
add_action('admin_menu', function () {
    // Aseguramos un menú padre "Midas RRHH" si no existe (no duplica si ya lo crea otra clase)
    if (!menu_page_url('midas-rrhh', false)) {
        add_menu_page(
            __('Midas RRHH', 'midas-rrhh'),
            __('Midas RRHH', 'midas-rrhh'),
            'manage_options',             // cambia a 'rrhh_admin' si tu rol ya lo define
            'midas-rrhh',
            '__return_null',
            'dashicons-groups',
            26
        );
    }

    // Submenú: Reportes (solo si no lo registró ya la clase Admin)
    add_submenu_page(
        'midas-rrhh',
        __('Reportes', 'midas-rrhh'),
        __('Reportes', 'midas-rrhh'),
        'manage_options',                 // cambia a 'rrhh_admin' / 'rrhh_gestor' si tu Roles::init() los define
        'midas-reportes',
        'midas_rrhh_render_reportes_page'
    );
});

/* =========================
 * Helpers usados por la vista
 * ========================= */
if (!function_exists('calcular_antiguedad')) {
function calcular_antiguedad($fecha_inicio) {
    if (empty($fecha_inicio) || $fecha_inicio == '0000-00-00') return '';
    try {
        $inicio = new DateTime($fecha_inicio);
        $hoy = new DateTime();
        $diff = $hoy->diff($inicio);
        return $diff->y . ' ' . __('años', 'midas-rrhh') . ', ' . $diff->m . ' ' . __('meses', 'midas-rrhh');
    } catch (\Throwable $e) { return ''; }
}}
if (!function_exists('formatear_fecha')) {
function formatear_fecha($fecha) {
    if (empty($fecha) || $fecha == '0000-00-00') return '';
    $date = DateTime::createFromFormat('Y-m-d', $fecha);
    return $date ? $date->format('d/m/Y') : '';
}}
if (!function_exists('formatear_datetime')) {
function formatear_datetime($fecha_hora) {
    if (empty($fecha_hora) || $fecha_hora == '0000-00-00 00:00:00') return '';
    $date = DateTime::createFromFormat('Y-m-d H:i:s', $fecha_hora);
    return $date ? $date->format('d/m/Y H:i') : '';
}}
if (!function_exists('obtener_usuario_info')) {
function obtener_usuario_info($user_id) {
    if (!$user_id) return null;
    $user = get_userdata($user_id);
    return $user ?: null;
}}
if (!function_exists('badge_usuario_wp')) {
function badge_usuario_wp($user_id, $size = 32) {
    $u = obtener_usuario_info($user_id);
    if (!$u) return '<span style="color:#bbb;">—</span>';
    $avatar = get_avatar($u->ID, $size, '', '', [
        'style' => 'vertical-align:middle;border-radius:50%;margin-right:6px;'
    ]);
    $name  = esc_html($u->display_name);
    $mail  = esc_html($u->user_email);
    return $avatar . '<span style="vertical-align:middle;">' . $name . '</span><br><small style="color:#888;">' . $mail . '</small>';
}}
/* Helpers SQL seguros/dinámicos */
if (!function_exists('midas_table_exists')) {
function midas_table_exists($table_name){
    global $wpdb;
    $sql = "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s";
    return ((int)$wpdb->get_var($wpdb->prepare($sql, $table_name))) > 0;
}}
if (!function_exists('midas_column_exists')) {
function midas_column_exists($table_name, $column_name){
    global $wpdb;
    $sql = "SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = %s";
    return ((int)$wpdb->get_var($wpdb->prepare($sql, $table_name, $column_name))) > 0;
}}
if (!function_exists('midas_first_existing_table')) {
function midas_first_existing_table($candidates){
    foreach ($candidates as $t) if (midas_table_exists($t)) return $t;
    return null;
}}
if (!function_exists('midas_existing_cols_qualified')) {
function midas_existing_cols_qualified($table, $alias, $candidates){
    $out = [];
    foreach ($candidates as $c) if (midas_column_exists($table, $c)) $out[] = $alias.'.'.$c;
    return $out;
}}
if (!function_exists('midas_first_existing_col_qualified')) {
function midas_first_existing_col_qualified($table, $alias, $candidates, $default='NULL'){
    $cols = midas_existing_cols_qualified($table, $alias, $candidates);
    return $cols ? $cols[0] : $default;
}}
if (!function_exists('midas_coalesce_qualified')) {
function midas_coalesce_qualified($table, $alias, $candidates, $default='NULL'){
    $cols = midas_existing_cols_qualified($table, $alias, $candidates);
    if (!$cols) return $default;
    if (count($cols) === 1) return $cols[0];
    return 'COALESCE('.implode(',', $cols).')';
}}

/* =========================
 * Render de la pantalla "Reportes"
 * ========================= */
function midas_rrhh_render_reportes_page() {
    if (!current_user_can('manage_options') && !current_user_can('administrator') && !current_user_can('rrhh_admin') && !current_user_can('rrhh_gestor')) {
        wp_die(__('No tienes permiso para ver esta página.', 'midas-rrhh'));
    }

    global $wpdb;
    $prefix = $wpdb->prefix;

    /* ====== REPORTE DE EMPLEADOS ====== */
    $items_emp_por_pagina = 5;
    $pagina_emp = (isset($_GET['paged_emp']) && is_numeric($_GET['paged_emp']) && $_GET['paged_emp'] > 0) ? intval($_GET['paged_emp']) : 1;
    $buscar_emp = isset($_GET['buscar_emp']) ? sanitize_text_field($_GET['buscar_emp']) : '';
    $where_emp = '';
    $params_emp = [];

    if (!empty($buscar_emp)) {
        $where_emp = " WHERE nombre LIKE %s OR apellido LIKE %s OR dni LIKE %s OR cuil LIKE %s ";
        $like_emp = '%' . $wpdb->esc_like($buscar_emp) . '%';
        $params_emp = [$like_emp, $like_emp, $like_emp, $like_emp];
    }

    $sql_emp_total = "SELECT COUNT(*) FROM {$wpdb->prefix}midas_empleados $where_emp";
    if (!empty($params_emp)) {
        $total_items_emp = (int) call_user_func_array([$wpdb,'get_var'], [ call_user_func_array([$wpdb,'prepare'], array_merge([$sql_emp_total], $params_emp)) ]);
    } else {
        $total_items_emp = (int) $wpdb->get_var($sql_emp_total);
    }

    $offset_emp = ($pagina_emp - 1) * $items_emp_por_pagina;
    $sql_emp = "
        SELECT id, nombre, apellido, dni, cuil, email, telefono, fecha_nacimiento, foto_id, direccion, estado_civil, cv_id, fecha_inicio_laboral, activo, created_at, updated_at, created_by, updated_by
        FROM {$wpdb->prefix}midas_empleados
        $where_emp
        ORDER BY updated_at DESC
        LIMIT %d OFFSET %d
    ";
    $params_emp_list = $params_emp;
    $params_emp_list[] = $items_emp_por_pagina;
    $params_emp_list[] = $offset_emp;
    $empleados = call_user_func_array([$wpdb,'get_results'], [
        call_user_func_array([$wpdb,'prepare'], array_merge([$sql_emp], $params_emp_list))
    ]);
    $total_paginas_emp = max(1, (int) ceil($total_items_emp / $items_emp_por_pagina));

    /* ====== REPORTE DE MOVIMIENTOS ====== */
    $tabla_docs_candidatas = [
        "{$prefix}midas_documentaciones",
        "{$prefix}midas_docv",
        "{$prefix}midas_docs_venc",
        "{$prefix}midas_documentos",
        "{$prefix}midas_doc_vencimientos",
    ];
    $tabla_docs  = midas_first_existing_table($tabla_docs_candidatas);
    $tabla_tipos = midas_table_exists("{$prefix}midas_doc_tipos") ? "{$prefix}midas_doc_tipos" : null;

    $items_mov_por_pagina = 20;
    $pagina_mov = (isset($_GET['paged_mov']) && is_numeric($_GET['paged_mov']) && $_GET['paged_mov'] > 0) ? intval($_GET['paged_mov']) : 1;
    $buscar_mov = isset($_GET['buscar_mov']) ? sanitize_text_field($_GET['buscar_mov']) : '';
    $offset_mov = ($pagina_mov - 1) * $items_mov_por_pagina;

    $sql_mov_parts = [];

    /* EMPLEADOS */
    $sql_mov_parts[] = "
      SELECT 'EMPLEADOS' AS modulo, 'CREADO' AS accion, e.id AS ref_id,
             CONCAT(UCASE(e.nombre),' ',UCASE(e.apellido)) AS detalle,
             e.created_by AS user_id, e.created_at AS fecha
      FROM {$prefix}midas_empleados e
      WHERE e.created_at IS NOT NULL
    ";
    $sql_mov_parts[] = "
      SELECT 'EMPLEADOS','ACTUALIZADO', e.id,
             CONCAT(UCASE(e.nombre),' ',UCASE(e.apellido)) AS detalle,
             e.updated_by, e.updated_at
      FROM {$prefix}midas_empleados e
      WHERE e.updated_at IS NOT NULL
    ";

    /* LICENCIAS */
    $sql_mov_parts[] = "
      SELECT 'LICENCIAS','CREADA', l.id,
             CONCAT('Tipo ', UCASE(l.tipo),' - ',
               CASE WHEN emp.id IS NULL THEN CONCAT('Empleado #', l.empleado_id)
                    ELSE CONCAT(UCASE(emp.nombre),' ',UCASE(emp.apellido)) END
             ) AS detalle,
             l.gestor_id, l.created_at
      FROM {$prefix}midas_licencias l
      LEFT JOIN {$prefix}midas_empleados emp ON emp.id = l.empleado_id
      WHERE l.created_at IS NOT NULL
    ";
    $sql_mov_parts[] = "
      SELECT 'LICENCIAS','ACTUALIZADA', l.id,
             CONCAT('Tipo ', UCASE(l.tipo),' - ',
               CASE WHEN emp.id IS NULL THEN CONCAT('Empleado #', l.empleado_id)
                    ELSE CONCAT(UCASE(emp.nombre),' ',UCASE(emp.apellido)) END
             ) AS detalle,
             l.gestor_id, l.updated_at
      FROM {$prefix}midas_licencias l
      LEFT JOIN {$prefix}midas_empleados emp ON emp.id = l.empleado_id
      WHERE l.updated_at IS NOT NULL
    ";

    /* CARPETA MÉDICA */
    $sql_mov_parts[] = "
      SELECT 'CARPETA MÉDICA','CREADA', c.id,
             CONCAT(
               CASE WHEN emp2.id IS NULL THEN CONCAT('Empleado #', c.empleado_id)
                    ELSE CONCAT(UCASE(emp2.nombre),' ',UCASE(emp2.apellido)) END,
               CASE
                 WHEN mot.descripcion IS NOT NULL AND mot.descripcion <> ''
                 THEN CONCAT(' - ', UCASE(mot.descripcion))
                 ELSE COALESCE(CONCAT(' - Motivo #', c.motivo_id),'')
               END
             ) AS detalle,
             c.gestor_id, c.created_at
      FROM {$prefix}midas_carpeta_medica c
      LEFT JOIN {$prefix}midas_empleados emp2 ON emp2.id = c.empleado_id
      LEFT JOIN {$prefix}midas_motivos_carpeta_medica mot ON mot.id = c.motivo_id
      WHERE c.created_at IS NOT NULL
    ";
    $sql_mov_parts[] = "
      SELECT 'CARPETA MÉDICA','ACTUALIZADA', c.id,
             CONCAT(
               CASE WHEN emp2.id IS NULL THEN CONCAT('Empleado #', c.empleado_id)
                    ELSE CONCAT(UCASE(emp2.nombre),' ',UCASE(emp2.apellido)) END,
               CASE
                 WHEN mot.descripcion IS NOT NULL AND mot.descripcion <> ''
                 THEN CONCAT(' - ', UCASE(mot.descripcion))
                 ELSE COALESCE(CONCAT(' - Motivo #', c.motivo_id),'')
               END
             ) AS detalle,
             c.gestor_id, c.updated_at
      FROM {$prefix}midas_carpeta_medica c
      LEFT JOIN {$prefix}midas_empleados emp2 ON emp2.id = c.empleado_id
      LEFT JOIN {$prefix}midas_motivos_carpeta_medica mot ON mot.id = c.motivo_id
      WHERE c.updated_at IS NOT NULL
    ";

    /* RECIBOS — user/fecha dinámicos si existen columnas */
    $rec_user_created_expr  = midas_first_existing_col_qualified("{$prefix}midas_recibos", 'r', ['created_by','gestor_id','admin_id','user_id'], 'NULL');
    $rec_fecha_created_expr = midas_coalesce_qualified("{$prefix}midas_recibos", 'r', ['created_at','created','fecha_alta','fecha'], 'NULL');

    $sql_mov_parts[] = "
      SELECT 'RECIBOS' AS modulo, 'CREADO' AS accion, r.id AS ref_id,
             CONCAT(
               'Periodo ', r.periodo, ' - ',
               CASE WHEN emp3.id IS NULL THEN CONCAT('Empleado #', r.empleado_id)
                    ELSE CONCAT(UCASE(emp3.nombre),' ',UCASE(emp3.apellido)) END
             ) AS detalle,
             {$rec_user_created_expr} AS user_id, {$rec_fecha_created_expr} AS fecha
      FROM {$prefix}midas_recibos r
      LEFT JOIN {$prefix}midas_empleados emp3 ON emp3.id = r.empleado_id
      WHERE {$rec_fecha_created_expr} IS NOT NULL
    ";

    /* INSTANCIAS (TICKETS) */
    $sql_mov_parts[] = "
      SELECT 'INSTANCIAS','CREADA', t.id,
             CONCAT('Asunto: ', t.asunto) AS detalle,
             t.user_id, t.fecha_creacion
      FROM {$prefix}midas_tickets t
      WHERE t.fecha_creacion IS NOT NULL
    ";
    $sql_mov_parts[] = "
      SELECT 'INSTANCIAS',
             IF(t.estado='rechazado','RECHAZADA', IF(t.estado='respondido','RESPONDIDA','ACTUALIZADA')) AS accion,
             t.id,
             CONCAT('Asunto: ', t.asunto) AS detalle,
             t.admin_id, t.fecha_respuesta
      FROM {$prefix}midas_tickets t
      WHERE t.fecha_respuesta IS NOT NULL
    ";

    /* DOCUMENTACIÓN CON VENCIMIENTO */
    if ($tabla_docs) {
        $doc_user_created_expr  = midas_first_existing_col_qualified($tabla_docs, 'd', ['created_by','gestor_id','user_id'], 'NULL');
        $doc_user_updated_expr  = midas_first_existing_col_qualified($tabla_docs, 'd', ['updated_by','gestor_id','admin_id','user_id'], 'NULL');
        $doc_fecha_created_expr = midas_coalesce_qualified($tabla_docs, 'd', ['created_at','created','fecha_alta','fecha_inicio','fecha'], 'NULL');
        $doc_fecha_updated_expr = midas_coalesce_qualified($tabla_docs, 'd', ['updated_at','updated','fecha_mod','fecha_fin','fecha'], 'NULL');

        $sql_mov_parts[] = "
          SELECT 'DOCUMENTACIÓN' AS modulo, 'CREADA' AS accion, d.id AS ref_id,
                 CONCAT(
                   CASE WHEN emp.id IS NULL THEN CONCAT('Empleado #', d.empleado_id)
                        ELSE CONCAT(UCASE(emp.nombre),' ',UCASE(emp.apellido)) END,
                   CASE WHEN tipo.id IS NOT NULL THEN CONCAT(' - ', UCASE(tipo.descripcion)) ELSE '' END,
                   CASE WHEN d.descripcion IS NOT NULL AND d.descripcion <> '' THEN CONCAT(' - ', UCASE(d.descripcion)) ELSE '' END
                 ) AS detalle,
                 {$doc_user_created_expr} AS user_id, {$doc_fecha_created_expr} AS fecha
          FROM {$tabla_docs} d
          LEFT JOIN {$prefix}midas_empleados emp ON emp.id = d.empleado_id
          LEFT JOIN {$prefix}midas_doc_tipos tipo ON tipo.id = d.tipo_id
          WHERE {$doc_fecha_created_expr} IS NOT NULL
        ";

        $sql_mov_parts[] = "
          SELECT 'DOCUMENTACIÓN','ACTUALIZADA', d.id,
                 CONCAT(
                   CASE WHEN emp.id IS NULL THEN CONCAT('Empleado #', d.empleado_id)
                        ELSE CONCAT(UCASE(emp.nombre),' ',UCASE(emp.apellido)) END,
                   CASE WHEN tipo.id IS NOT NULL THEN CONCAT(' - ', UCASE(tipo.descripcion)) ELSE '' END,
                   CASE WHEN d.descripcion IS NOT NULL AND d.descripcion <> '' THEN CONCAT(' - ', UCASE(d.descripcion)) ELSE '' END
                 ) AS detalle,
                 {$doc_user_updated_expr} AS user_id, {$doc_fecha_updated_expr} AS fecha
          FROM {$tabla_docs} d
          LEFT JOIN {$prefix}midas_empleados emp ON emp.id = d.empleado_id
          LEFT JOIN {$prefix}midas_doc_tipos tipo ON tipo.id = d.tipo_id
          WHERE {$doc_fecha_updated_expr} IS NOT NULL
        ";
    }

    if ($tabla_tipos) {
        $t_user_created_expr  = midas_first_existing_col_qualified($tabla_tipos, 't', ['created_by','gestor_id','user_id'], 'NULL');
        $t_user_updated_expr  = midas_first_existing_col_qualified($tabla_tipos, 't', ['updated_by','gestor_id','admin_id','user_id'], 'NULL');
        $t_fecha_created_expr = midas_coalesce_qualified($tabla_tipos, 't', ['created_at','created','fecha_alta','fecha'], 'NULL');
        $t_fecha_updated_expr = midas_coalesce_qualified($tabla_tipos, 't', ['updated_at','updated','fecha_mod','fecha'], 'NULL');

        $sql_mov_parts[] = "
          SELECT 'TIPOS (DOC.)' AS modulo, 'CREADO' AS accion, t.id AS ref_id,
                 UCASE(t.descripcion) AS detalle,
                 {$t_user_created_expr} AS user_id, {$t_fecha_created_expr} AS fecha
          FROM {$tabla_tipos} t
          WHERE {$t_fecha_created_expr} IS NOT NULL
        ";
        $sql_mov_parts[] = "
          SELECT 'TIPOS (DOC.)','ACTUALIZADO', t.id,
                 UCASE(t.descripcion) AS detalle,
                 {$t_user_updated_expr} AS user_id, {$t_fecha_updated_expr} AS fecha
          FROM {$tabla_tipos} t
          WHERE {$t_fecha_updated_expr} IS NOT NULL
        ";
    }

    $sql_mov_base = "SELECT * FROM (\n" . implode("\nUNION ALL\n", $sql_mov_parts) . "\n) AS mov";

    $where_mov = '';
    $params_mov = [];
    if (!empty($buscar_mov)) {
        $like_mov = '%' . $wpdb->esc_like($buscar_mov) . '%';
        $where_mov = " WHERE (mov.modulo LIKE %s OR mov.accion LIKE %s OR mov.detalle LIKE %s";
        $params_mov = [$like_mov, $like_mov, $like_mov];

        $user_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT ID FROM {$wpdb->users} WHERE display_name LIKE %s OR user_email LIKE %s",
            $like_mov, $like_mov
        ));
        if (!empty($user_ids)) {
            $ids_clean = implode(',', array_map('intval', $user_ids));
            $where_mov .= " OR mov.user_id IN ($ids_clean)";
        }
        $where_mov .= ")";
    }

    $sql_mov_total = $sql_mov_base . $where_mov;
    if (!empty($params_mov)) {
        $count_sql = "SELECT COUNT(*) FROM ($sql_mov_total) AS tot";
        $total_mov = (int) call_user_func_array([$wpdb,'get_var'], [
            call_user_func_array([$wpdb,'prepare'], array_merge([$count_sql], $params_mov))
        ]);
    } else {
        $total_mov = (int) $wpdb->get_var("SELECT COUNT(*) FROM ($sql_mov_total) AS tot");
    }

    $sql_mov_list = $sql_mov_base . $where_mov . " ORDER BY mov.fecha DESC LIMIT %d OFFSET %d";
    $params_mov_list = $params_mov;
    $params_mov_list[] = $items_mov_por_pagina;
    $params_mov_list[] = $offset_mov;
    $movimientos = call_user_func_array([$wpdb,'get_results'], [
        call_user_func_array([$wpdb,'prepare'], array_merge([$sql_mov_list], $params_mov_list))
    ]);
    $total_paginas_mov = max(1, (int) ceil($total_mov / $items_mov_por_pagina));

    /* ========= OUTPUT ========= */
    ?>
    <div class="wrap midas-reportes">
        <h1><?php esc_html_e('Reportes', 'midas-rrhh'); ?></h1>

        <!-- ====== Buscador EMPLEADOS ====== -->
        <form method="get" class="midas-filtros">
            <input type="hidden" name="page" value="<?php echo esc_attr($_GET['page'] ?? ''); ?>">
            <input type="hidden" name="paged_mov" value="<?php echo esc_attr($pagina_mov); ?>">
            <input type="hidden" name="buscar_mov" value="<?php echo esc_attr($buscar_mov); ?>">
            <input
                type="text"
                name="buscar_emp"
                placeholder="<?php esc_attr_e('Buscar empleados por nombre, apellido, DNI o CUIL', 'midas-rrhh'); ?>"
                value="<?php echo esc_attr($buscar_emp); ?>"
                class="midas-input"
            >
            <button type="submit" class="button"><?php esc_html_e('Buscar', 'midas-rrhh'); ?></button>
            <?php if ($buscar_emp): ?>
                <a href="?page=<?php echo esc_attr($_GET['page'] ?? ''); ?>&paged_mov=<?php echo esc_attr($pagina_mov); ?>&buscar_mov=<?php echo esc_attr($buscar_mov); ?>" class="button"><?php esc_html_e('Limpiar', 'midas-rrhh'); ?></a>
            <?php endif; ?>
        </form>

        <div class="midas-card">
            <h2><?php esc_html_e('Reporte de Empleados', 'midas-rrhh'); ?></h2>
            <div class="midas-card-body">
                <div class="midas-table-wrap">
                <table class="wp-list-table widefat fixed striped midas-responsive" style="margin-top:20px; font-size:13px;">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>DNI</th>
                            <th>Email</th>
                            <th>Teléfono</th>
                            <th>Fecha Nac.</th>
                            <th>Dirección</th>
                            <th>Estado Civil</th>
                            <th>CV ID</th>
                            <th>Fecha Inicio Laboral</th>
                            <th>Antigüedad</th>
                            <th>Activo</th>
                            <th>Creado</th>
                            <th>Actualizado</th>
                            <th style="text-align:center;">Gestor</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($empleados)) : ?>
                            <?php foreach ($empleados as $e): ?>
                                <tr>
                                    <td data-label="Nombre"><?php echo esc_html("{$e->nombre} {$e->apellido}"); ?></td>
                                    <td data-label="DNI"><?php echo esc_html($e->dni ?? ''); ?></td>
                                    <td data-label="Email"><?php echo esc_html($e->email ?? ''); ?></td>
                                    <td data-label="Teléfono"><?php echo esc_html($e->telefono ?? ''); ?></td>
                                    <td data-label="Fecha Nac."><?php echo esc_html(formatear_fecha($e->fecha_nacimiento ?? '')); ?></td>
                                    <td data-label="Dirección"><?php echo esc_html($e->direccion ?? ''); ?></td>
                                    <td data-label="Estado Civil"><?php echo esc_html($e->estado_civil ?? ''); ?></td>
                                    <td data-label="CV ID"><?php echo esc_html($e->cv_id ?? ''); ?></td>
                                    <td data-label="Fecha Inicio Laboral"><?php echo esc_html(formatear_fecha($e->fecha_inicio_laboral ?? '')); ?></td>
                                    <td data-label="Antigüedad"><?php echo esc_html(calcular_antiguedad($e->fecha_inicio_laboral ?? '')); ?></td>
                                    <td data-label="Activo"><?php echo $e->activo == 1 ? 'Sí' : 'No'; ?></td>
                                    <td data-label="Creado"><?php echo esc_html(formatear_datetime($e->created_at ?? '')); ?></td>
                                    <td data-label="Actualizado"><?php echo esc_html(formatear_datetime($e->updated_at ?? '')); ?></td>
                                    <td data-label="Gestor" style="text-align:center;">
                                        <?php
                                        $created_user = (!empty($e->created_by)) ? obtener_usuario_info($e->created_by) : null;
                                        $updated_user = (!empty($e->updated_by)) ? obtener_usuario_info($e->updated_by) : null;

                                        if ($created_user) {
                                            echo get_avatar($created_user->ID, 32, '', '', [
                                                'style' => 'vertical-align:middle;border-radius:50%;margin-right:6px;'
                                            ]);
                                            echo '<span style="vertical-align:middle;">' . esc_html($created_user->display_name) . '</span>';
                                            echo "<br><small style='color:#888'>Creado el " . esc_html(formatear_datetime($e->created_at)) . "</small>";
                                        }

                                        if ($updated_user && (!empty($e->updated_by)) && ($e->updated_by != $e->created_by)) {
                                            echo '<hr style="margin:4px 0;">';
                                            echo get_avatar($updated_user->ID, 24, '', '', [
                                                'style' => 'vertical-align:middle;border-radius:50%;margin-right:6px;'
                                            ]);
                                            echo '<span style="vertical-align:middle;">' . esc_html($updated_user->display_name) . '</span>';
                                            echo "<br><small style='color:#888'>Actualizado el " . esc_html(formatear_datetime($e->updated_at)) . "</small>";
                                        } elseif (!$created_user && $updated_user) {
                                            echo get_avatar($updated_user->ID, 32, '', '', [
                                                'style' => 'vertical-align:middle;border-radius:50%;margin-right:6px;'
                                            ]);
                                            echo '<span style="vertical-align:middle;">' . esc_html($updated_user->display_name) . '</span>';
                                            echo "<br><small style='color:#888'>Actualizado el " . esc_html(formatear_datetime($e->updated_at)) . "</small>";
                                        }

                                        if (!$created_user && !$updated_user) {
                                            echo '<span style="color:#bbb;">Sin gestor</span>';
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="14"><?php esc_html_e('No se encontraron empleados.', 'midas-rrhh'); ?></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                </div>

                <?php if ($total_paginas_emp > 1): ?>
                    <div class="tablenav bottom">
                        <div class="tablenav-pages midas-pages">
                            <?php
                            $base_url_emp = remove_query_arg('paged_emp');
                            for ($i = 1; $i <= $total_paginas_emp; $i++) {
                                $url = add_query_arg([
                                    'paged_emp'  => $i,
                                    'buscar_emp' => $buscar_emp,
                                    'paged_mov'  => $pagina_mov,
                                    'buscar_mov' => $buscar_mov,
                                ], $base_url_emp);
                                $class = ($i === $pagina_emp) ? 'current' : '';
                                echo '<a class="page-numbers ' . esc_attr($class) . '" href="' . esc_url($url) . '">' . intval($i) . '</a> ';
                            }
                            ?>
                        </div>
                    </div>
                <?php endif; ?>

            </div>
        </div>

        <!-- ====== Buscador MOVIMIENTOS ====== -->
        <form method="get" class="midas-filtros" style="margin-top:24px;">
            <input type="hidden" name="page" value="<?php echo esc_attr($_GET['page'] ?? ''); ?>">
            <input type="hidden" name="paged_emp" value="<?php echo esc_attr($pagina_emp); ?>">
            <input type="hidden" name="buscar_emp" value="<?php echo esc_attr($buscar_emp); ?>">
            <input
                type="text"
                name="buscar_mov"
                placeholder="<?php esc_attr_e('Buscar movimientos por módulo, acción, detalle o usuario WP', 'midas-rrhh'); ?>"
                value="<?php echo esc_attr($buscar_mov); ?>"
                class="midas-input"
            >
            <button type="submit" class="button"><?php esc_html_e('Buscar', 'midas-rrhh'); ?></button>
            <?php if ($buscar_mov): ?>
                <a href="?page=<?php echo esc_attr($_GET['page'] ?? ''); ?>&paged_emp=<?php echo esc_attr($pagina_emp); ?>&buscar_emp=<?php echo esc_attr($buscar_emp); ?>" class="button"><?php esc_html_e('Limpiar', 'midas-rrhh'); ?></a>
            <?php endif; ?>
        </form>

        <div class="midas-card">
            <h2><?php esc_html_e('Movimientos (Actividad)', 'midas-rrhh'); ?></h2>
            <div class="midas-card-body">
                <p style="margin:8px 0 14px;color:#555;">
                    <?php esc_html_e('Se listan altas/actualizaciones de empleados, licencias, carpeta médica, recibos, instancias y documentación con vencimiento (incluye Tipos), con el usuario de WordPress que ejecutó la acción (si está disponible), fecha y hora.', 'midas-rrhh'); ?>
                </p>

                <div class="midas-table-wrap">
                <table class="wp-list-table widefat fixed striped midas-responsive" style="margin-top:10px; font-size:13px;">
                    <thead>
                        <tr>
                            <th style="width:140px;"><?php esc_html_e('Fecha y hora', 'midas-rrhh'); ?></th>
                            <th style="width:160px;"><?php esc_html_e('Módulo', 'midas-rrhh'); ?></th>
                            <th style="width:130px;"><?php esc_html_e('Acción', 'midas-rrhh'); ?></th>
                            <th><?php esc_html_e('Detalle', 'midas-rrhh'); ?></th>
                            <th style="width:260px;"><?php esc_html_e('Usuario WP', 'midas-rrhh'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (!empty($movimientos)): ?>
                        <?php foreach ($movimientos as $m): ?>
                            <tr>
                                <td data-label="Fecha y hora"><?php echo esc_html(formatear_datetime($m->fecha)); ?></td>
                                <td data-label="Módulo"><?php echo esc_html($m->modulo); ?></td>
                                <td data-label="Acción"><?php echo esc_html($m->accion); ?></td>
                                <td data-label="Detalle"><?php echo esc_html($m->detalle); ?></td>
                                <td data-label="Usuario WP"><?php echo badge_usuario_wp(intval($m->user_id)); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="5"><?php esc_html_e('No hay movimientos para mostrar.', 'midas-rrhh'); ?></td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                </div>

                <?php if ($total_paginas_mov > 1): ?>
                    <div class="tablenav bottom">
                        <div class="tablenav-pages midas-pages">
                            <?php
                            $base_url_mov = remove_query_arg('paged_mov');
                            for ($i = 1; $i <= $total_paginas_mov; $i++) {
                                $url = add_query_arg([
                                    'paged_mov'  => $i,
                                    'buscar_mov' => $buscar_mov,
                                    'paged_emp'  => $pagina_emp,
                                    'buscar_emp' => $buscar_emp,
                                ], $base_url_mov);
                                $class = ($i === $pagina_mov) ? 'current' : '';
                                echo '<a class="page-numbers ' . esc_attr($class) . '" href="' . esc_url($url) . '">' . intval($i) . '</a> ';
                            }
                            ?>
                        </div>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>

    <style>
    /* === Layout general === */
    .midas-card { background:#fff; border:1px solid #ccd0d4; box-shadow:0 2px 7px #0001; margin-bottom:22px; padding:24px; border-radius:8px; overflow:hidden; }
    .midas-card-body { padding:0; }
    .midas-reportes th, .midas-reportes td { text-align:center; vertical-align:middle!important; }
    .midas-reportes th { background:#f6f7f7; font-weight:700; }

    /* Filtros */
    .midas-filtros{ display:flex; flex-wrap:wrap; gap:8px; margin:0 0 20px; align-items:center; }
    .midas-input{ width:380px; max-width:100%; padding:6px; }

    /* Paginación */
    .midas-pages{ display:flex; flex-wrap:wrap; gap:6px; align-items:center; }
    .page-numbers{ display:inline-block; padding:6px 12px; border-radius:4px; background:#f1f1f1; color:#333; font-weight:700; text-decoration:none; transition:background .2s,color .2s; }
    .page-numbers:hover,.page-numbers.current{ background:#2271b1; color:#fff; }

    /* Contenedor con scroll suave para tablas anchas */
    .midas-table-wrap{ overflow:auto; -webkit-overflow-scrolling:touch; }

    /* ===== Tablas responsivas (stacked cards) ===== */
    @media (max-width: 980px){
      .midas-responsive thead{ display:none; }
      .midas-responsive, .midas-responsive tbody, .midas-responsive tr, .midas-responsive td{
        display:block; width:100%;
      }
      .midas-responsive tr{
        background:#fff; border:1px solid #e6e6e6; border-radius:10px;
        margin:0 0 12px; padding:6px;
        box-shadow:0 1px 4px rgba(0,0,0,.03);
      }
      .midas-responsive td{
        border:none; border-bottom:1px solid #f3f3f3;
        padding:10px 12px;
        display:grid; grid-template-columns:42% 1fr; gap:10px;
        text-align:left; font-size:13px;
      }
      .midas-responsive td::before{
        content:attr(data-label);
        font-weight:600; color:#555;
      }
      .midas-responsive td:last-child{ border-bottom:none; }
      .midas-responsive td[data-label="Usuario WP"],
      .midas-responsive td[data-label="Gestor"]{ align-items:center; }
    }

    @media (max-width: 520px){
      .midas-responsive td{ grid-template-columns: 1fr; }
      .midas-responsive td::before{ margin-bottom:4px; }
      .midas-card{ padding:16px; }
    }
    </style>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        <?php if (isset($_GET['update_success'])): ?>
            alert('Empleado actualizado con éxito');
        <?php endif; ?>
        if (window.localStorage.getItem('employee_updated') === 'true') {
            showSuccessNotification('Empleado actualizado con éxito');
            window.localStorage.setItem('employee_updated', 'false');
        }
    });
    function showSuccessNotification(message) {
        const notification = document.createElement('div');
        notification.style.position = 'fixed';
        notification.style.top = '10px';
        notification.style.left = '50%';
        notification.style.transform = 'translateX(-50%)';
        notification.style.backgroundColor = '#28a745';
        notification.style.color = '#fff';
        notification.style.padding = '10px 20px';
        notification.style.borderRadius = '5px';
        notification.style.fontSize = '16px';
        notification.style.zIndex = '1000';
        notification.textContent = message;
        document.body.appendChild(notification);
        setTimeout(function() { notification.remove(); }, 3000);
    }
    </script>
    <?php
}

/* =========================
 * NOTA sobre AJAX adicional
 * =========================
 * Ya estás cubierto por MidasRRHH\Ajax\Ajax_Handler::init() (registrado en plugins_loaded).
 * Si en tu versión tenías add_action('init', ...) para AJAX sueltos, podés eliminarlo
 * para evitar duplicados. Este archivo no agrega endpoints AJAX extra porque el handler
 * central ya los registra todos.
 */
