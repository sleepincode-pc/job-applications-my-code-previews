<?php
if (!defined('ABSPATH')) exit;
global $wpdb;

$tareas_table = $wpdb->prefix . 'midas_tareas';
$areas_table = $wpdb->prefix . 'midas_areas';

$tareas = $wpdb->get_results("SELECT * FROM $tareas_table ORDER BY nombre");
$areas = $wpdb->get_results("SELECT * FROM $areas_table ORDER BY nombre");
?>

<div class="wrap midas-tareas-areas">
    <h1><?php esc_html_e('Gestión de Tareas y Áreas', 'midas-rrhh'); ?></h1>

    <div class="midas-tabs">
        <ul class="nav-tab-wrapper">
            <li><a href="#tareas" class="nav-tab nav-tab-active"><?php esc_html_e('Tareas', 'midas-rrhh'); ?></a></li>
            <li><a href="#areas" class="nav-tab"><?php esc_html_e('Áreas', 'midas-rrhh'); ?></a></li>
        </ul>

        <div id="tareas" class="midas-tab-content" style="display:block;">
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('ID', 'midas-rrhh'); ?></th>
                        <th><?php esc_html_e('Nombre', 'midas-rrhh'); ?></th>
                        <th><?php esc_html_e('Estado', 'midas-rrhh'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tareas as $tarea): ?>
                        <tr>
                            <td><?php echo esc_html($tarea->id); ?></td>
                            <td><?php echo esc_html($tarea->nombre); ?></td>
                            <td><?php echo $tarea->activo ? __('Activo', 'midas-rrhh') : __('Inactivo', 'midas-rrhh'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($tareas)) : ?>
                        <tr><td colspan="3"><?php esc_html_e('No se encontraron tareas.', 'midas-rrhh'); ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div id="areas" class="midas-tab-content" style="display:none;">
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('ID', 'midas-rrhh'); ?></th>
                        <th><?php esc_html_e('Nombre', 'midas-rrhh'); ?></th>
                        <th><?php esc_html_e('Estado', 'midas-rrhh'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($areas as $area): ?>
                        <tr>
                            <td><?php echo esc_html($area->id); ?></td>
                            <td><?php echo esc_html($area->nombre); ?></td>
                            <td><?php echo $area->activo ? __('Activo', 'midas-rrhh') : __('Inactivo', 'midas-rrhh'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($areas)) : ?>
                        <tr><td colspan="3"><?php esc_html_e('No se encontraron áreas.', 'midas-rrhh'); ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Tabs
    const tabs = document.querySelectorAll('.nav-tab-wrapper a');
    const contenidos = document.querySelectorAll('.midas-tab-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', e => {
            e.preventDefault();
            tabs.forEach(t => t.classList.remove('nav-tab-active'));
            contenidos.forEach(c => c.style.display = 'none');
            tab.classList.add('nav-tab-active');
            const target = tab.getAttribute('href');
            document.querySelector(target).style.display = 'block';
        });
    });
});
</script>
