<?php
// === INICIALIZACIÓN SEGURA ===
if (!isset($empleados)) $empleados = [];
if (!is_array($empleados)) $empleados = [];
$areas_map = isset($areas_map) && is_array($areas_map) ? $areas_map : [];
$tareas_map = isset($tareas_map) && is_array($tareas_map) ? $tareas_map : [];
$notas_empleados = isset($notas_empleados) && is_array($notas_empleados) ? $notas_empleados : [];

/**
 * Calcula la antigüedad total (años, días) entre dos fechas, sumando la reconocida.
 * Si $fin es nulo, toma la fecha actual.
 */
if (!function_exists('midas_calcular_antiguedad')) {
    function midas_calcular_antiguedad($inicio, $reconocida = 0, $fin = null) {
        if (!$inicio || $inicio === '0000-00-00') return '—';
        try {
            $date_inicio = new DateTime($inicio);
            $date_fin = $fin && $fin !== '0000-00-00' ? new DateTime($fin) : new DateTime('now');
            if ($date_fin < $date_inicio) return '—'; // Evita negativos
            $interval = $date_inicio->diff($date_fin);
            $dias_totales = $interval->days;
            $anios = intval(floor($dias_totales / 365)) + intval($reconocida);
            $dias_restantes = $dias_totales - (floor($dias_totales / 365) * 365);

            // Suma años si los días reconocidos extra pasan los 365
            while ($dias_restantes >= 365) {
                $anios++;
                $dias_restantes -= 365;
            }
            if ($anios > 0 && $dias_restantes > 0)  return "$anios años, $dias_restantes días";
            if ($anios > 0)               return "$anios años";
            if ($dias_restantes > 0)      return "$dias_restantes días";
            return 'Menos de 1 día';
        } catch (Exception $e) {
            return '—';
        }
    }
}

// === NUNCA DEJA LA TABLA VACÍA NI ROMPE EL FOREACH ===
if (empty($empleados)) : ?>
    <tr>
        <td colspan="17" style="text-align:center;color:#888;">
            <?php esc_html_e('No se encontraron empleados.', 'midas-rrhh'); ?>
        </td>
    </tr>
<?php
else :
    foreach ($empleados as $empleado) :
        if (!$empleado) continue;
        // Evita warnings por propiedades que falten
        $nota = '';
        if (is_object($empleado)) {
            $nota = property_exists($empleado, 'nota')
                ? $empleado->nota
                : (isset($notas_empleados[$empleado->id]) ? $notas_empleados[$empleado->id] : '');
            $foto_url = !empty($empleado->foto_id)
                ? wp_get_attachment_url($empleado->foto_id)
                : (property_exists($empleado, 'foto_url') ? $empleado->foto_url : '');
            $area_id  = isset($empleado->area) ? $empleado->area : (isset($empleado->area_id) ? $empleado->area_id : '');
            $tarea_id = isset($empleado->tarea) ? $empleado->tarea : (isset($empleado->tarea_id) ? $empleado->tarea_id : '');
            $user_id  = isset($empleado->user_id) ? $empleado->user_id : '';
            $user_obj = $user_id ? get_user_by('ID', $user_id) : null;
            $antiguedad_reconocida = isset($empleado->antiguedad_reconocida) ? intval($empleado->antiguedad_reconocida) : 0;
            $fecha_fin = property_exists($empleado, 'fecha_fin_laboral') ? $empleado->fecha_fin_laboral : null;
        } else {
            $nota = isset($empleado['nota']) ? $empleado['nota'] : (isset($notas_empleados[$empleado['id']]) ? $notas_empleados[$empleado['id']] : '');
            $foto_url = !empty($empleado['foto_id'])
                ? wp_get_attachment_url($empleado['foto_id'])
                : (isset($empleado['foto_url']) ? $empleado['foto_url'] : '');
            $area_id  = isset($empleado['area']) ? $empleado['area'] : (isset($empleado['area_id']) ? $empleado['area_id'] : '');
            $tarea_id = isset($empleado['tarea']) ? $empleado['tarea'] : (isset($empleado['tarea_id']) ? $empleado['tarea_id'] : '');
            $user_id  = isset($empleado['user_id']) ? $empleado['user_id'] : '';
            $user_obj = $user_id ? get_user_by('ID', $user_id) : null;
            $antiguedad_reconocida = isset($empleado['antiguedad_reconocida']) ? intval($empleado['antiguedad_reconocida']) : 0;
            $fecha_fin = isset($empleado['fecha_fin_laboral']) ? $empleado['fecha_fin_laboral'] : null;
        }
        ?>
        <tr data-id="<?php echo esc_attr(is_object($empleado) ? $empleado->id : $empleado['id']); ?>">
            <td>
                <div class="foto-nota-superpuesta" data-empleado-id="<?php echo esc_attr(is_object($empleado) ? $empleado->id : $empleado['id']); ?>">
                    <button type="button"
                        class="nota-burbuja-superpuesta<?php echo empty($nota) ? ' vacia' : ''; ?>"
                        data-empleado-id="<?php echo esc_attr(is_object($empleado) ? $empleado->id : $empleado['id']); ?>"
                        title="Click para agregar/editar nota">
                        <span class="nota-texto">
                            <?php
                            echo $nota
                                ? esc_html(wp_trim_words($nota, 8, '...'))
                                : esc_html__('Nota', 'midas-rrhh');
                            ?>
                        </span>
                    </button>
                    <?php if ($foto_url) : ?>
                        <img src="<?php echo esc_url($foto_url); ?>?v=<?php echo time(); ?>"
                            alt="<?php echo esc_attr(
                                (is_object($empleado) ? $empleado->nombre : $empleado['nombre']) . ' ' .
                                (is_object($empleado) ? $empleado->apellido : $empleado['apellido'])
                            ); ?>"
                            class="foto-empleado">
                    <?php else : ?>
                        <span class="foto-placeholder">
                            <?php esc_html_e('Sin foto', 'midas-rrhh'); ?>
                        </span>
                    <?php endif; ?>
                </div>
            </td>
            <td><?php echo esc_html(is_object($empleado) ? $empleado->nombre : $empleado['nombre']); ?></td>
            <td><?php echo esc_html(is_object($empleado) ? $empleado->apellido : $empleado['apellido']); ?></td>
            <td><?php echo esc_html(is_object($empleado) ? $empleado->dni : $empleado['dni']); ?></td>
            <td><?php echo esc_html(is_object($empleado) ? $empleado->cuil : $empleado['cuil']); ?></td>
            <td><?php echo esc_html(is_object($empleado) ? $empleado->email : $empleado['email']); ?></td>
            <td><?php echo esc_html(is_object($empleado) ? $empleado->telefono : $empleado['telefono']); ?></td>
            <td><?php echo esc_html(is_object($empleado) ? $empleado->fecha_nacimiento : $empleado['fecha_nacimiento']); ?></td>
            <td><?php echo esc_html(is_object($empleado) ? $empleado->direccion : $empleado['direccion']); ?></td>
            <td><?php echo esc_html(is_object($empleado) ? $empleado->estado_civil : $empleado['estado_civil']); ?></td>
            <td><?php echo esc_html(is_object($empleado) ? $empleado->fecha_inicio_laboral : $empleado['fecha_inicio_laboral']); ?></td>
            <td><?php echo esc_html(is_object($empleado) ? ($empleado->fecha_fin_laboral ?? '') : ($empleado['fecha_fin_laboral'] ?? '')); ?></td>
            <td><?php echo esc_html($areas_map[$area_id] ?? $area_id); ?></td>
            <td><?php echo esc_html($tareas_map[$tarea_id] ?? $tarea_id); ?></td>
            <td>
                <?php
                $inicio = is_object($empleado) ? $empleado->fecha_inicio_laboral : $empleado['fecha_inicio_laboral'];
                echo esc_html(midas_calcular_antiguedad($inicio, $antiguedad_reconocida, $fecha_fin ?? null));
                ?>
            </td>
            <td><?php echo $user_obj ? esc_html($user_obj->user_login) : '—'; ?></td>
            <td class="col-acciones">
                <div class="acciones-empleado">
                    <button type="button"
                        class="button editar-btn"
                        data-id="<?php echo esc_attr(is_object($empleado) ? $empleado->id : $empleado['id']); ?>"
                        data-nombre="<?php echo esc_attr(is_object($empleado) ? $empleado->nombre : $empleado['nombre']); ?>"
                        data-apellido="<?php echo esc_attr(is_object($empleado) ? $empleado->apellido : $empleado['apellido']); ?>"
                        data-dni="<?php echo esc_attr(is_object($empleado) ? $empleado->dni : $empleado['dni']); ?>"
                        data-cuil="<?php echo esc_attr(is_object($empleado) ? $empleado->cuil : $empleado['cuil']); ?>"
                        data-email="<?php echo esc_attr(is_object($empleado) ? $empleado->email : $empleado['email']); ?>"
                        data-telefono="<?php echo esc_attr(is_object($empleado) ? $empleado->telefono : $empleado['telefono']); ?>"
                        data-fecha_nacimiento="<?php echo esc_attr(is_object($empleado) ? $empleado->fecha_nacimiento : $empleado['fecha_nacimiento']); ?>"
                        data-direccion="<?php echo esc_attr(is_object($empleado) ? $empleado->direccion : $empleado['direccion']); ?>"
                        data-estado_civil="<?php echo esc_attr(is_object($empleado) ? $empleado->estado_civil : $empleado['estado_civil']); ?>"
                        data-fecha_inicio_laboral="<?php echo esc_attr(is_object($empleado) ? $empleado->fecha_inicio_laboral : $empleado['fecha_inicio_laboral']); ?>"
                        data-fecha_fin_laboral="<?php echo esc_attr(is_object($empleado) ? ($empleado->fecha_fin_laboral ?? '') : ($empleado['fecha_fin_laboral'] ?? '')); ?>"
                        data-area="<?php echo esc_attr($area_id); ?>"
                        data-tarea="<?php echo esc_attr($tarea_id); ?>"
                        data-user_id="<?php echo esc_attr($user_id); ?>"
                        data-antiguedad_reconocida="<?php echo esc_attr($antiguedad_reconocida); ?>"
                        data-foto_id="<?php echo esc_attr(is_object($empleado) ? ($empleado->foto_id ?? '') : ($empleado['foto_id'] ?? '')); ?>"
                        data-foto_url="<?php echo esc_url($foto_url); ?>"
                    >
                        <?php esc_html_e('Editar', 'midas-rrhh'); ?>
                    </button>
                    <button type="button"
                        class="button button-danger btn-eliminar"
                        data-id="<?php echo esc_attr(is_object($empleado) ? $empleado->id : $empleado['id']); ?>"
                    >
                        <?php esc_html_e('Eliminar', 'midas-rrhh'); ?>
                    </button>
                </div>
            </td>
        </tr>
    <?php endforeach;
endif;
?>
