<?php
if (!defined('ABSPATH')) exit;

use MidasRRHH\Models\Empleado_Model;

global $wpdb;

/* ===========================
 *  IMÁGENES: tamaño chico + WebP
 *  (lo ideal es poner esto en el bootstrap del plugin)
 * =========================== */
add_action('after_setup_theme', function () {
  // Miniatura para listados
  add_image_size('midas_avatar', 96, 96, true);
});
add_filter('image_editor_output_format', function ($formats, $mime, $image) {
  // Si el editor puede, exporta JPEG/PNG como WebP
  $formats['image/jpeg'] = 'image/webp';
  $formats['image/png']  = 'image/webp';
  return $formats;
}, 10, 3);
add_filter('jpeg_quality', function(){ return 82; });
add_filter('wp_editor_set_quality', function($q){ return 82; });

/* ===========================
 *  Datos base (ligeros)
 * =========================== */
$areas  = $wpdb->get_results("SELECT id, nombre, rol FROM {$wpdb->prefix}midas_areas ORDER BY nombre ASC");
$tareas = $wpdb->get_results("SELECT id, nombre FROM {$wpdb->prefix}midas_tareas ORDER BY nombre ASC");
$all_users    = get_users(['fields' => ['ID', 'user_login']]);
$search_query = isset($_GET['buscar_empleado']) ? sanitize_text_field($_GET['buscar_empleado']) : '';

/* ====== Paleta guardada por usuario (para aplicar en este scope) ====== */
$ajax_url       = admin_url('admin-ajax.php');
$nonce_palette  = wp_create_nonce('midas_palette_scoped_nonce');
$uid            = get_current_user_id();
$saved_palette  = $uid ? get_user_meta($uid, 'midas_palette_scoped', true) : null;
if (!is_array($saved_palette)) $saved_palette = null;

/* Placeholder 1x1 transparente para lazy images */
$tiny_placeholder = 'data:image/gif;base64,R0lGODlhAQABAAAAACw=';
?>
<style>
/* ====== Scope de paleta SOLO para Empleados ====== */
.midas-empleados{
  --md-card-bg:#ffffff;
  --md-card-border:#ccd0d4;
  --md-card-header-bg:#f7f7f7;
  --md-card-header-text:#1f2937;
  --md-table-stripe:#f9fafb;
  --md-text:#1e293b;
  --md-muted:#475569;

  color:var(--md-text);
}

/* ====== Tipografía y estados ====== */
input[type="text"].input-mayus, input[type="number"].input-mayus, textarea.input-mayus { text-transform: uppercase !important; }
input:invalid, select:invalid, input.input-error, select.input-error { border-color:#c0392b !important; background:#ffeaea !important; }
.hidden{ display:none !important; }

/* ====== Formulario en CSS Grid (desktop 2 cols, mobile 1 col) ====== */
.two-column-form{ display:grid; grid-template-columns:1fr 1fr; gap:12px; align-items:start; }
.two-column-form .form-field{ display:flex; flex-direction:column; }
.two-column-form .form-field.full{ grid-column:1 / -1; }
.two-column-form .form-field label{ margin:0 0 6px; line-height:1.2; }
.two-column-form .form-field input, .two-column-form .form-field select, .two-column-form .form-field textarea{ width:100%; box-sizing:border-box; margin:0; }
.two-column-form input[type="text"], .two-column-form input[type="email"], .two-column-form input[type="date"], .two-column-form input[type="number"], .two-column-form select{ height:36px; line-height:1.3; padding:6px 8px; }
@media (max-width: 900px){ .two-column-form{ grid-template-columns:1fr; gap:10px; } }

/* ====== Previews ====== */
.foto-preview{ width:80px; height:80px; object-fit:cover; border-radius:50%; display:none; margin-top:8px; }

/* ===== MODALES ===== */
.modal-overlay{ position:fixed; inset:0; background:rgba(0,0,0,.32); z-index:99999; display:none; align-items:center; justify-content:center; overflow-y:auto; }
.modal-overlay[style*="display: flex"]{ display:flex !important; }
.modal-content{ background:#fff; border-radius:12px; padding:18px 18px 14px; position:relative; box-shadow:0 12px 40px #0002; width:min(640px, 92vw); max-height:86vh; overflow:auto; display:flex; flex-direction:column; gap:12px; animation:modalIn .28s ease both; }
@keyframes modalIn{ from{opacity:0; transform:translateY(18px) scale(.98);} to{opacity:1; transform:none;} }
.modal-content h2{ margin:0 32px 10px 0; font-size:18px; line-height:1.2; position:sticky; top:0; background:#fff; padding-top:4px; z-index:2; }
.modal-close{ position:sticky; top:6px; margin-left:auto; align-self:flex-end; background:none; border:none; font-size:24px; color:#999; cursor:pointer; line-height:1; }
.modal-close:hover{ color:#333; }
@media (max-width: 600px){
  .modal-content{ width:94vw; max-height:88vh; padding:14px 12px; }
  .two-column-form{ gap:8px; }
  .two-column-form .form-field label{ font-size:12px; }
  .two-column-form .form-field input, .two-column-form .form-field select{ height:34px; font-size:13px; }
  .fullwidth-btn{ font-size:13px; padding:9px 10px; }
}

/* ===== TABLA ===== */
.tabla-empleados-container{ width:100%; overflow-x:auto; -webkit-overflow-scrolling:touch; }
.empleados-table{
  width:100%; border-collapse:collapse; margin-top:20px; font-size:14px;
  background:var(--md-card-bg);
  box-shadow:0 0 5px rgba(0,0,0,.05);
  border:1px solid var(--md-card-border);
  color:var(--md-text);
}
.empleados-table th, .empleados-table td{
  padding:12px 12px; text-align:left;
  border-bottom:1px solid var(--md-card-border);
  vertical-align:middle;
  color:var(--md-text);
}
.empleados-table thead{
  background:var(--md-card-header-bg);
  color:var(--md-card-header-text);
  font-weight:600;
}
.empleados-table tr:hover{ background:var(--md-table-stripe); }
.empleados-table.striped tbody tr:nth-child(odd){ background:var(--md-table-stripe) !important; }
.foto-empleado{ width:60px; height:60px; object-fit:cover; border-radius:50%; display:inline-block; box-shadow:0 0 3px rgba(0,0,0,.1); }
.foto-placeholder{ display:inline-block; width:60px; height:60px; line-height:60px; text-align:center; background:var(--md-table-stripe); border-radius:50%; font-size:11px; color:#888; }

/* ===== Vista “cards” en móviles ===== */
@media (max-width: 860px){
  .empleados-table.is-stacked thead{ display:none; }
  .empleados-table.is-stacked, .empleados-table.is-stacked tbody, .empleados-table.is-stacked tr, .empleados-table.is-stacked td{ display:block; width:100%; }
  .empleados-table.is-stacked tr{
    background:var(--md-card-bg);
    border:1px solid var(--md-card-border);
    border-radius:10px; margin:0 0 12px; padding:4px;
    box-shadow:0 1px 4px rgba(0,0,0,.03);
  }
  .empleados-table.is-stacked td{
    border:none; border-bottom:1px solid var(--md-card-border);
    padding:10px 12px; text-align:left; display:grid; grid-template-columns:42% 1fr; gap:10px; color:var(--md-text);
  }
  .empleados-table.is-stacked td::before{ content:attr(data-label); font-weight:600; color:var(--md-muted); }
  .empleados-table.is-stacked td:last-child{ border-bottom:none; }
  .foto-empleado,.foto-placeholder{ width:44px; height:44px; line-height:44px; font-size:10px; }
}
@media (max-width: 520px){
  .empleados-table.is-stacked td{ grid-template-columns:1fr; }
  .empleados-table.is-stacked td::before{ margin-bottom:4px; }
}

/* ===== ACCIONES ===== */
.col-acciones{ max-width:100%; vertical-align:middle !important; }
.col-acciones .acciones-empleado{ display:flex; flex-wrap:wrap; gap:6px; }
.col-acciones .acciones-empleado .button{ padding:6px 10px; font-size:12px; border-radius:6px; height:auto; transition:transform .18s, box-shadow .18s; display:inline-flex; align-items:center; justify-content:center; }
.col-acciones .acciones-empleado .button:hover{ transform:translateY(-2px); box-shadow:0 6px 16px rgba(0,0,0,.15); }
.button.editar-btn{ background:#0073aa; border:1px solid #0073aa; color:#fff; }
.button.editar-btn:hover{ background:#005f8d; border-color:#005f8d; }
.button.button-danger{ background:#dc3232; border:1px solid #dc3232; color:#fff; }
.button.button-danger:hover{ background:#a32323; border-color:#a32323; }

/* Paginación flexible */
.pagination-flex{ display:flex !important; gap:8px; justify-content:center; align-items:center; flex-wrap:wrap; }
.pagination-flex a, .pagination-flex span{ display:inline-flex !important; padding:6px 10px; border:1px solid #ccc; border-radius:4px; text-decoration:none; color:#0073aa; font-weight:600; }
.pagination-flex a:hover{ background:#0073aa; color:#fff; }
.pagination-flex .current{ background:#0073aa; color:#fff; cursor:default; pointer-events:none; border-color:#005177; }
@media (max-width:600px){ .pagination-flex a, .pagination-flex span{ padding:3px 6px; font-size:11px; } }

/* Nota sobre foto */
.foto-nota-superpuesta{ position:relative; display:inline-block; width:60px; height:60px; vertical-align:top; }
.nota-burbuja-superpuesta{ position:absolute; top:-15px; left:42px; z-index:3; cursor:pointer; background:#e7f1fa; border:1.5px solid #a8d2f0; color:#095078; padding:2px 10px; border-radius:18px; font-size:12px; min-width:42px; max-width:300px; text-overflow:ellipsis; white-space:nowrap; overflow:hidden; box-shadow:0 2px 7px rgba(0,74,150,.10); }
.nota-burbuja-superpuesta.vacia{ background:#f7f7fa; color:#888; border-color:#e3e3e3; }
@media (max-width:900px){ .foto-nota-superpuesta{ width:50px; height:50px; } .nota-burbuja-superpuesta{ font-size:10px; left:35px; top:-10px; max-width:130px; padding:2px 6px; } }
@media (max-width:600px){ .foto-nota-superpuesta{ width:38px; height:38px; } .nota-burbuja-superpuesta{ font-size:9px; left:25px; top:-8px; max-width:80px; padding:1.5px 3px; } }

/* Spinner */
.midas-cargando-empleados{ display:flex; align-items:center; justify-content:center; font-weight:500; font-size:1.05em; color:#1976d2; min-height:52px; gap:10px; }
.midas-spinner{ width:26px; height:26px; border:4px solid #e4ecf7; border-top:4px solid #1976d2; border-radius:50%; animation:spin .8s linear infinite; }
@keyframes spin{ to{ transform:rotate(360deg); } }

/* Modo oscuro (opcional) */
.dark-mode .modal-content{ background:#23272e !important; color:#ececec !important; box-shadow:0 12px 44px #000a; }
.dark-mode .modal-content h2{ background:#23272e !important; }
.dark-mode .empleados-table, .dark-mode .empleados-table th, .dark-mode .empleados-table td{ background:#23272e !important; color:#ececec !important; border-color:#353b48 !important; }
</style>

<!-- Inyecta config/nonce + paleta guardada (si existe) -->
<script>
  window.midas_rrhh = window.midas_rrhh || {};
  midas_rrhh.ajax_url = midas_rrhh.ajax_url || "<?php echo esc_js($ajax_url); ?>";
  midas_rrhh.palette_nonce = midas_rrhh.palette_nonce || "<?php echo esc_js($nonce_palette); ?>";
  midas_rrhh.user_palette = midas_rrhh.user_palette || <?php echo wp_json_encode($saved_palette ?: (object)[]); ?>;
</script>

<div class="wrap midas-empleados" id="midasEmpleados" data-midas-scope>
  <h1><?php esc_html_e('Gestión de Empleados', 'midas-rrhh'); ?></h1>

  <div class="buscador-empleado" style="margin-bottom: 20px; max-width: 520px; display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
    <input type="text" id="buscar_empleado" name="buscar_empleado" value="<?php echo esc_attr($search_query ?? ''); ?>"
      class="input-mayus" placeholder="<?php esc_attr_e('Buscar por nombre, apellido, DNI o CUIL', 'midas-rrhh'); ?>" autocomplete="off" style="flex:1 1 280px;">
    <button id="btn-limpiar" class="button<?php echo empty($search_query) ? ' hidden' : ''; ?>">
      <?php esc_html_e('Limpiar', 'midas-rrhh'); ?>
    </button>
  </div>

  <button id="btn-abrir-crear" class="button button-primary" style="margin-bottom:16px;"><?php esc_html_e('Nuevo Empleado', 'midas-rrhh'); ?></button>

  <!-- Modal Crear -->
  <div id="modal-crear" class="modal-overlay" style="display:none;">
    <div class="modal-content">
      <button class="modal-close" id="cerrar-crear" aria-label="Cerrar">&times;</button>
      <h2><?php esc_html_e('Crear Nuevo Empleado', 'midas-rrhh'); ?></h2>

      <form method="post" id="form-crear-empleado" class="two-column-form" enctype="multipart/form-data" autocomplete="off" novalidate>
        <!-- Identificación -->
        <div class="form-field">
          <label for="crear-nombre"><strong>Nombre</strong></label>
          <input type="text" name="nombre" id="crear-nombre" class="input-mayus" required pattern="^[A-ZÁÉÍÓÚÑ ]+$" maxlength="40" autocomplete="given-name">
        </div>
        <div class="form-field">
          <label for="crear-apellido"><strong>Apellido</strong></label>
          <input type="text" name="apellido" id="crear-apellido" class="input-mayus" required pattern="^[A-ZÁÉÍÓÚÑ ]+$" maxlength="40" autocomplete="family-name">
        </div>
        <div class="form-field">
          <label for="crear-dni"><strong>DNI</strong></label>
          <input type="text" name="dni" id="crear-dni" class="input-mayus" required pattern="^[0-9]{8}$" maxlength="8" inputmode="numeric" title="Debe tener 8 dígitos" autocomplete="off">
        </div>
        <div class="form-field">
          <label for="crear-cuil"><strong>CUIL</strong></label>
          <input type="text" name="cuil" id="crear-cuil" class="input-mayus" required pattern="^[0-9]{11}$" maxlength="11" inputmode="numeric" title="Debe tener 11 dígitos" autocomplete="off">
        </div>
        <div class="form-field">
          <label for="fecha_nacimiento"><strong>Fecha de Nacimiento</strong></label>
          <input type="date" name="fecha_nacimiento" id="fecha_nacimiento" required autocomplete="bday">
        </div>

        <!-- Contacto -->
        <div class="form-field">
          <label for="crear-email"><strong>Email</strong></label>
          <input type="email" name="email" id="crear-email" maxlength="150" style="text-transform:lowercase" autocomplete="email">
        </div>
        <div class="form-field">
          <label for="crear-telefono"><strong>Teléfono</strong></label>
          <input type="text" name="telefono" id="crear-telefono" maxlength="10" inputmode="numeric" pattern="^[0-9]{0,10}$" class="input-mayus" autocomplete="tel" title="Hasta 10 dígitos">
        </div>
        <div class="form-field">
          <label for="crear-direccion"><strong>Dirección</strong></label>
          <input type="text" name="direccion" id="crear-direccion" maxlength="150" class="input-mayus" autocomplete="street-address">
        </div>
        <div class="form-field">
          <label for="crear-estado_civil"><strong>Estado Civil</strong></label>
          <input type="text" name="estado_civil" id="crear-estado_civil" maxlength="30" class="input-mayus" autocomplete="off">
        </div>

        <!-- Laboral -->
        <div class="form-field">
          <label for="crear-area"><strong>Área</strong></label>
          <select name="area" id="crear-area" required>
            <option value=""><?php esc_html_e('Seleccionar área', 'midas-rrhh'); ?></option>
            <?php foreach ($areas as $a): ?>
              <option value="<?php echo esc_attr($a->id); ?>">
                <?php echo esc_html($a->nombre . (!empty($a->rol) ? " ({$a->rol})" : "")); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-field">
          <label for="crear-tarea"><strong>Tarea</strong></label>
          <select name="tarea" id="crear-tarea" required>
            <option value=""><?php esc_html_e('Seleccionar tarea', 'midas-rrhh'); ?></option>
            <?php foreach ($tareas as $t): ?>
              <option value="<?php echo esc_attr($t->id); ?>"><?php echo esc_html($t->nombre); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-field">
          <label for="crear-user_id"><strong>Usuario WordPress</strong></label>
          <select name="user_id" id="crear-user_id">
            <option value="">— Ninguno —</option>
            <?php foreach ($all_users as $u): ?>
              <option value="<?php echo esc_attr($u->ID); ?>"><?php echo esc_html($u->user_login); ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- Fechas laborales -->
        <div class="form-field">
          <label for="fecha_inicio_laboral"><strong>Fecha de Inicio Laboral</strong></label>
          <input type="date" name="fecha_inicio_laboral" id="fecha_inicio_laboral" required autocomplete="off">
        </div>
        <div class="form-field">
          <label for="fecha_fin_laboral"><strong>Fecha de Fin Laboral</strong></label>
          <input type="date" name="fecha_fin_laboral" id="fecha_fin_laboral" autocomplete="off">
        </div>

        <!-- Foto -->
        <div class="form-field full">
          <label for="foto-crear"><strong>Foto del Empleado</strong></label>
          <input type="file" name="foto" id="foto-crear" accept=".jpg,.jpeg,.png,.webp" data-max="512000"><!-- 500KB -->
          <img class="foto-preview" src="" alt="" style="display:none;">
        </div>

        <div class="form-field full">
          <button type="submit" class="button button-primary fullwidth-btn">Crear</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Modal Editar -->
  <div id="modal-editar" class="modal-overlay" style="display:none;">
    <div class="modal-content">
      <button class="modal-close" id="cerrar-editar" aria-label="Cerrar">&times;</button>
      <h2><?php esc_html_e('Editar Empleado', 'midas-rrhh'); ?></h2>

      <form method="post" id="form-editar-empleado" class="two-column-form" enctype="multipart/form-data" autocomplete="off" novalidate>
        <input type="hidden" name="id" id="edit-id">
        <input type="hidden" name="foto_id_actual" id="edit-foto-id">

        <div class="form-field">
          <label for="edit-nombre"><strong>Nombre</strong></label>
          <input type="text" name="nombre" id="edit-nombre" class="input-mayus" required pattern="^[A-ZÁÉÍÓÚÑ ]+$" maxlength="40">
        </div>
        <div class="form-field">
          <label for="edit-apellido"><strong>Apellido</strong></label>
          <input type="text" name="apellido" id="edit-apellido" class="input-mayus" required pattern="^[A-ZÁÉÍÓÚÑ ]+$" maxlength="40">
        </div>
        <div class="form-field">
          <label for="edit-dni"><strong>DNI</strong></label>
          <input type="text" name="dni" id="edit-dni" class="input-mayus" required pattern="^[0-9]{8}$" maxlength="8" inputmode="numeric">
        </div>
        <div class="form-field">
          <label for="edit-cuil"><strong>CUIL</strong></label>
          <input type="text" name="cuil" id="edit-cuil" class="input-mayus" required pattern="^[0-9]{11}$" maxlength="11" inputmode="numeric">
        </div>
        <div class="form-field">
          <label for="edit-fecha_nacimiento"><strong>Fecha de Nacimiento</strong></label>
          <input type="date" name="fecha_nacimiento" id="edit-fecha_nacimiento" required>
        </div>

        <div class="form-field">
          <label for="edit-email"><strong>Email</strong></label>
          <input type="email" name="email" id="edit-email" maxlength="150" style="text-transform:lowercase">
        </div>
        <div class="form-field">
          <label for="edit-telefono"><strong>Teléfono</strong></label>
          <input type="text" name="telefono" id="edit-telefono" maxlength="10" inputmode="numeric" pattern="^[0-9]{0,10}$" class="input-mayus">
        </div>
        <div class="form-field">
          <label for="edit-direccion"><strong>Dirección</strong></label>
          <input type="text" name="direccion" id="edit-direccion" maxlength="150" class="input-mayus">
        </div>
        <div class="form-field">
          <label for="edit-estado_civil"><strong>Estado Civil</strong></label>
          <input type="text" name="estado_civil" id="edit-estado_civil" maxlength="30" class="input-mayus">
        </div>

        <div class="form-field">
          <label for="edit-area"><strong>Área</strong></label>
          <select name="area" id="edit-area" required>
            <option value=""><?php esc_html_e('Seleccionar área', 'midas-rrhh'); ?></option>
            <?php foreach ($areas as $a): ?>
              <option value="<?php echo esc_attr($a->id); ?>">
                <?php echo esc_html($a->nombre . (!empty($a->rol) ? " ({$a->rol})" : "")); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-field">
          <label for="edit-tarea"><strong>Tarea</strong></label>
          <select name="tarea" id="edit-tarea" required>
            <option value=""><?php esc_html_e('Seleccionar tarea', 'midas-rrhh'); ?></option>
            <?php foreach ($tareas as $t): ?>
              <option value="<?php echo esc_attr($t->id); ?>"><?php echo esc_html($t->nombre); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-field">
          <label for="edit-user_id"><strong>Usuario WordPress</strong></label>
          <select name="user_id" id="edit-user_id">
            <option value="">— Ninguno —</option>
            <?php foreach ($all_users as $u): ?>
              <option value="<?php echo esc_attr($u->ID); ?>"><?php echo esc_html($u->user_login); ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-field">
          <label for="edit-fecha_inicio_laboral"><strong>Fecha de Inicio Laboral</strong></label>
          <input type="date" name="fecha_inicio_laboral" id="edit-fecha_inicio_laboral" required>
        </div>
        <div class="form-field">
          <label for="edit-fecha_fin_laboral"><strong>Fecha de Fin Laboral</strong></label>
          <input type="date" name="fecha_fin_laboral" id="edit-fecha_fin_laboral">
        </div>

        <div class="form-field full foto-preview-container">
          <img id="foto-preview" src="" alt="Foto actual" class="foto-preview" style="display:none;">
        </div>
        <div class="form-field full">
          <label for="foto-editar"><strong>Cambiar Foto</strong></label>
          <input type="file" name="foto" id="foto-editar" accept=".jpg,.jpeg,.png,.webp" data-max="512000">
        </div>

        <div class="form-field full">
          <button type="submit" class="button button-primary fullwidth-btn">Guardar</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Tabla -->
  <div class="tabla-empleados-container">
    <table class="wp-list-table widefat fixed striped empleados-table">
      <thead>
        <tr>
          <th><?php esc_html_e('Foto', 'midas-rrhh'); ?></th>
          <th><?php esc_html_e('Nombre', 'midas-rrhh'); ?></th>
          <th><?php esc_html_e('Apellido', 'midas-rrhh'); ?></th>
          <th><?php esc_html_e('DNI', 'midas-rrhh'); ?></th>
          <th><?php esc_html_e('CUIL', 'midas-rrhh'); ?></th>
          <th><?php esc_html_e('Email', 'midas-rrhh'); ?></th>
          <th><?php esc_html_e('Teléfono', 'midas-rrhh'); ?></th>
          <th><?php esc_html_e('Fecha de Nacimiento', 'midas-rrhh'); ?></th>
          <th><?php esc_html_e('Dirección', 'midas-rrhh'); ?></th>
          <th><?php esc_html_e('Estado Civil', 'midas-rrhh'); ?></th>
          <th><?php esc_html_e('Fecha de Inicio Laboral', 'midas-rrhh'); ?></th>
          <th><?php esc_html_e('Fecha de Fin Laboral', 'midas-rrhh'); ?></th>
          <th><?php esc_html_e('Área', 'midas-rrhh'); ?></th>
          <th><?php esc_html_e('Tarea', 'midas-rrhh'); ?></th>
          <th><?php esc_html_e('Antigüedad', 'midas-rrhh'); ?></th>
          <th><?php esc_html_e('Usuario WP', 'midas-rrhh'); ?></th>
          <th><?php esc_html_e('Acciones', 'midas-rrhh'); ?></th>
        </tr>
      </thead>
      <tbody id="empleados-tbody">
        <tr id="empleados-loader-row">
          <td colspan="17">
            <div class="midas-cargando-empleados">
              <span class="midas-spinner"></span> Cargando empleados...
            </div>
          </td>
        </tr>
      </tbody>
    </table>
    <div class="tablenav bottom">
      <div id="empleados-paginacion" class="tablenav-pages pagination-flex"></div>
    </div>
  </div>

  <!-- Modal Nota -->
  <div id="modal-nota-empleado" class="modal-overlay" style="display:none;">
    <div class="modal-content">
      <button type="button" class="modal-close" id="cerrar-nota-empleado" aria-label="Cerrar">&times;</button>
      <h2 style="margin-top:0;"><?php esc_html_e('Nota de empleado', 'midas-rrhh'); ?></h2>
      <form id="form-nota-empleado">
        <input type="hidden" id="nota-empleado-id" name="empleado_id" value="">
        <textarea id="nota-textarea" name="nota" rows="5" class="input-mayus" placeholder="<?php esc_attr_e('ESCRIBE UNA NOTA…', 'midas-rrhh'); ?>" style="width:100%;"></textarea>
        <button type="submit" class="button button-primary fullwidth-btn" style="margin-top:8px;">
          <?php esc_html_e('Guardar Nota', 'midas-rrhh'); ?>
        </button>
      </form>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
  /* ===== Aplica paleta guardada a este scope ===== */
  const WRAP = document.getElementById('midasEmpleados') || document.querySelector('.midas-empleados');
  const SAVED = (window.midas_rrhh && window.midas_rrhh.user_palette) ? window.midas_rrhh.user_palette : null;
  const DEF = {
    cards:{ bg:'#ffffff', border:'#ccd0d4', headerBg:'#f7f7f7', headerTxt:'#1f2937', stripe:'#f9fafb' },
    text:{  txt:'#1e293b', muted:'#475569' }
  };
  const initial = (SAVED && typeof SAVED==='object')
    ? { cards:Object.assign({}, DEF.cards, SAVED.cards||{}), text:Object.assign({}, DEF.text, SAVED.text||{}) }
    : JSON.parse(localStorage.getItem('midas.palette.scoped')||'null') || DEF;

  function applyPaletteTo(el,p){
    if(!el) return;
    el.style.setProperty('--md-card-bg',         p.cards.bg);
    el.style.setProperty('--md-card-border',     p.cards.border);
    el.style.setProperty('--md-card-header-bg',  p.cards.headerBg);
    el.style.setProperty('--md-card-header-text',p.cards.headerTxt);
    el.style.setProperty('--md-table-stripe',    p.cards.stripe);
    el.style.setProperty('--md-text',            p.text.txt);
    el.style.setProperty('--md-muted',           p.text.muted);
  }
  applyPaletteTo(WRAP, initial);

  // si cambia en otra pestaña, refleja cambios
  window.addEventListener('storage', (e)=>{
    if(e.key==='midas.palette.scoped' && e.newValue){
      try{ applyPaletteTo(WRAP, JSON.parse(e.newValue)); }catch(_){}
    }
  });

  /* ===== Config segura ===== */
  const MIDAS = window.midas_rrhh || {};
  const AJAX_URL = MIDAS.ajax_url || (typeof window.ajaxurl !== 'undefined' ? window.ajaxurl : "<?php echo admin_url('admin-ajax.php'); ?>");
  const EMP_NONCE = (MIDAS.nonces && MIDAS.nonces.empleados) ? MIDAS.nonces.empleados : "<?php echo wp_create_nonce('midas_empleados_nonce'); ?>";
  const PLACEHOLDER_1PX = "<?php echo esc_js($tiny_placeholder); ?>";
  const ROWS_PER_PAGE = 20; // pide poco por request

  /* ===== Helpers UI ===== */
  function enforceUppercase(el){
    el.addEventListener('input', function(){
      let v = el.value.toUpperCase().replace(/[^A-ZÁÉÍÓÚÑ0-9 .\-\/]/g,'');
      el.value = v;
    });
  }
  document.querySelectorAll('.input-mayus').forEach(enforceUppercase);
  function enforceEmailLower(el){
    el.addEventListener('input', function(){
      el.value = el.value.toLowerCase().replace(/[^a-z0-9@\.\-\+_]/g,'');
    });
  }
  document.querySelectorAll('#crear-email,#edit-email').forEach(enforceEmailLower);
  function onlyDigits(el,max){ el.addEventListener('input',()=> el.value = (el.value.replace(/\D/g,'').slice(0,max))); }
  ['#crear-dni','#edit-dni'].forEach(s=>document.querySelectorAll(s).forEach(el=>onlyDigits(el,8)));
  ['#crear-cuil','#edit-cuil'].forEach(s=>document.querySelectorAll(s).forEach(el=>onlyDigits(el,11)));
  ['#crear-telefono','#edit-telefono'].forEach(s=>document.querySelectorAll(s).forEach(el=>onlyDigits(el,10)));

  /* ===== Toasts ===== */
  window.showSuccess = m => toast(m,'#27ae60');
  window.showError   = m => toast(m,'#c0392b');
  function toast(msg,bg){
    document.querySelectorAll('.midas-rrhh-aviso').forEach(n=>n.remove());
    const d=document.createElement('div');
    d.className='midas-rrhh-aviso';
    Object.assign(d.style,{position:'fixed',top:'30px',right:'30px',zIndex:9999,padding:'14px 24px',borderRadius:'8px',background:bg,color:'#fff',boxShadow:'0 6px 18px #0002',opacity:0,transition:'opacity .2s'});
    d.textContent=msg; document.body.appendChild(d); setTimeout(()=>d.style.opacity=1,10); setTimeout(()=>{d.style.opacity=0; setTimeout(()=>d.remove(),350)},2400);
  }

  /* ===== Tabla “stack” móvil ===== */
  function setStackLabels(table){
    if(!table) return;
    const headers=[...table.querySelectorAll('thead th')].map(th=>th.textContent.trim());
    const isMobile=window.matchMedia('(max-width: 860px)').matches;
    if(isMobile){ table.classList.add('is-stacked'); } else { table.classList.remove('is-stacked'); }
    if(!isMobile) return;
    table.querySelectorAll('tbody tr').forEach(tr=>{
      [...tr.children].forEach((td,i)=>{ if(headers[i]) td.setAttribute('data-label', headers[i]); });
    });
  }
  function refreshStackMode(){ setStackLabels(document.querySelector('.empleados-table')); }
  window.addEventListener('resize', refreshStackMode);

  /* ===== L A Z Y  I M A G E S ===== */
  function makeLazyImages(scope){
    const imgs = (scope || document).querySelectorAll('img.foto-empleado');
    imgs.forEach(img=>{
      if(!img.dataset.src && img.src){
        img.dataset.src = img.src;
        img.removeAttribute('src');
      }
      img.loading = 'lazy';
      img.decoding = 'async';
      img.fetchPriority = 'low';
      img.src = PLACEHOLDER_1PX;
      img.width = img.width || 60; img.height = img.height || 60;
    });

    if(!('IntersectionObserver' in window)){
      imgs.forEach(i=>{ if(i.dataset.src){ i.src = i.dataset.src; } });
      return;
    }
    const io = new IntersectionObserver(entries=>{
      entries.forEach(e=>{
        if(e.isIntersecting){
          const el = e.target;
          if(el.dataset.src){
            el.src = el.dataset.src;
            el.removeAttribute('data-src');
          }
          io.unobserve(el);
        }
      });
    }, { rootMargin: '200px 0px' });
    imgs.forEach(i=>io.observe(i));
  }

  /* ===== Buscador AJAX (ligero) ===== */
  const buscarInput=document.getElementById('buscar_empleado');
  const btnLimpiar=document.getElementById('btn-limpiar');
  const empleadosTbody=document.getElementById('empleados-tbody');
  const paginacionContainer=document.getElementById('empleados-paginacion');
  let typingTimer, currentQuery='', currentPage=1, currentAbort=null;

  function mostrarLoader(){
    if(empleadosTbody){
      empleadosTbody.innerHTML=`<tr id="empleados-loader-row"><td colspan="17"><div class="midas-cargando-empleados"><span class="midas-spinner"></span> Cargando empleados...</div></td></tr>`;
    }
    if (paginacionContainer) paginacionContainer.innerHTML='';
  }

  function extraerFilasDeTbody(html) {
    const m = html ? html.match(/<tbody[^>]*>([\s\S]*?)<\/tbody>/i) : null;
    return m ? m[1] : (html || '');
  }

  function buscarEmpleadosAJAX(query,page){
    mostrarLoader();
    if(currentAbort){ currentAbort.abort(); }
    currentAbort = new AbortController();

    const params = new URLSearchParams({
      action:'midas_buscar_empleados',
      buscar: query || '',
      paged: page || 1,
      per_page: ROWS_PER_PAGE,
      image_size: 'midas_avatar',
      webp: '1',
      nonce: EMP_NONCE,
      midas_empleados_nonce: EMP_NONCE
    });

    fetch(AJAX_URL, {
      method:'POST',
      credentials:'same-origin',
      headers:{'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},
      body: params.toString(),
      signal: currentAbort.signal
    })
    .then(r=>r.text())
    .then(t=>{
      let data;
      try { data = JSON.parse(t); }
      catch(e){ console.error('Respuesta no-JSON (posibles notices PHP):\n', t); throw new Error('Respuesta del servidor inválida'); }

      if(data && data.success && data.data){
        const filas = extraerFilasDeTbody(data.data.html || '');
        empleadosTbody.innerHTML = filas;
        if(paginacionContainer) paginacionContainer.innerHTML = data.data.pagination || '';
        makeLazyImages(empleadosTbody);
      }else{
        console.error('Respuesta AJAX inesperada:', data);
        empleadosTbody.innerHTML = '<tr><td colspan="17">No se encontraron empleados.</td></tr>';
        if(paginacionContainer) paginacionContainer.innerHTML='';
      }
      refreshStackMode();
    })
    .catch((err)=>{
      if (err.name === 'AbortError') return;
      console.error('Error buscarEmpleadosAJAX:', err);
      empleadosTbody.innerHTML = '<tr><td colspan="17">Error al buscar empleados.</td></tr>';
      if(paginacionContainer) paginacionContainer.innerHTML='';
      refreshStackMode();
    })
    .finally(()=>{ currentAbort=null; });
  }

  if (buscarInput){
    buscarInput.addEventListener('input', function(){
      clearTimeout(typingTimer);
      typingTimer=setTimeout(()=>{
        currentQuery=buscarInput.value.trim();
        currentPage=1;
        if(currentQuery.length === 1){ return; }
        buscarEmpleadosAJAX(currentQuery,currentPage);
        if(btnLimpiar) btnLimpiar.classList.toggle('hidden', !currentQuery);
      },260);
    });
    buscarInput.addEventListener('keydown', ()=> clearTimeout(typingTimer));
  }
  if (btnLimpiar){
    btnLimpiar.addEventListener('click', e=>{
      e.preventDefault();
      buscarInput.value=''; currentQuery=''; currentPage=1;
      buscarEmpleadosAJAX('',1); btnLimpiar.classList.add('hidden');
    });
  }
  if (paginacionContainer){
    paginacionContainer.addEventListener('click', e=>{
      const link=e.target.closest('a');
      if(!link || !link.hasAttribute('data-page')) return;
      e.preventDefault();
      currentPage=parseInt(link.getAttribute('data-page'),10)||1;
      buscarEmpleadosAJAX(currentQuery,currentPage);
      window.scrollTo({ top: (document.querySelector('.tabla-empleados-container')?.offsetTop||0)-70, behavior:'smooth' });
    });
  }

  /* ===== Modales ===== */
  const modalCrear=document.getElementById('modal-crear');
  const modalEditar=document.getElementById('modal-editar');
  const modalNota=document.getElementById('modal-nota-empleado');
  const btnAbrirCrear=document.getElementById('btn-abrir-crear');
  const cerrarCrear=document.getElementById('cerrar-crear');
  const cerrarEditar=document.getElementById('cerrar-editar');
  const cerrarNota=document.getElementById('cerrar-nota-empleado');

  function openModal(m){ m.style.display='flex'; }
  function closeModal(m){ m.style.display='none'; }
  if(btnAbrirCrear) btnAbrirCrear.addEventListener('click', e=>{ e.preventDefault(); openModal(modalCrear); });
  if(cerrarCrear) cerrarCrear.addEventListener('click', ()=> closeModal(modalCrear));
  if(cerrarEditar) cerrarEditar.addEventListener('click', ()=> closeModal(modalEditar));
  if(cerrarNota) cerrarNota.addEventListener('click', ()=> closeModal(modalNota));
  window.addEventListener('click', e=>{
    if(e.target===modalCrear) closeModal(modalCrear);
    if(e.target===modalEditar) closeModal(modalEditar);
    if(e.target===modalNota)   closeModal(modalNota);
  });
  window.addEventListener('keydown', e=>{ if(e.key==='Escape'){ closeModal(modalCrear); closeModal(modalEditar); closeModal(modalNota); } });

  /* ===== Validación + COMPRESIÓN de fotos antes de subir ===== */
  function validarArchivoLigero(input, maxBytes){
    const max=parseInt(maxBytes || input.getAttribute('data-max') || '512000', 10);
    const ok=['image/jpeg','image/png','image/webp'];
    const f=input.files && input.files[0] ? input.files[0] : null;
    if(!f) return true;
    if(f.size>max){ showError('La imagen es grande. Se optimizará automáticamente al guardar.'); }
    if(!ok.includes(f.type)){ showError('Formato no permitido (usa JPG/PNG/WebP).'); input.value=''; return false; }
    return true;
  }

  async function compressImageIfNeeded(file, {maxW=256, maxH=256, maxBytes=150*1024, quality=0.7} = {}){
    if(file.size <= maxBytes && (file.type === 'image/webp')) return file;
    const bitmap = await createImageBitmap(file).catch(()=>null);
    if(!bitmap){
      const img = await new Promise((res,rej)=>{ const i=new Image(); i.onload=()=>res(i); i.onerror=rej; i.src=URL.createObjectURL(file); });
      const canvas=document.createElement('canvas');
      const scale=Math.min(maxW/img.naturalWidth || 1, maxH/img.naturalHeight || 1, 1);
      canvas.width = Math.max(1, Math.round(img.naturalWidth*scale));
      canvas.height= Math.max(1, Math.round(img.naturalHeight*scale));
      const ctx=canvas.getContext('2d');
      ctx.drawImage(img,0,0,canvas.width,canvas.height);
      let blob = await new Promise(r=>canvas.toBlob(r,'image/webp',quality));
      let q=quality;
      while(blob && blob.size>maxBytes && q>0.45){
        q-=0.1;
        blob = await new Promise(r=>canvas.toBlob(r,'image/webp',q));
      }
      if(!blob) return file;
      return new File([blob],'foto.webp',{type:'image/webp'});
    }else{
      const canvas = (typeof OffscreenCanvas!=='undefined') ? new OffscreenCanvas(1,1) : document.createElement('canvas');
      const scale=Math.min(maxW/bitmap.width, maxH/bitmap.height, 1);
      const w=Math.max(1, Math.round(bitmap.width*scale));
      const h=Math.max(1, Math.round(bitmap.height*scale));
      canvas.width=w; canvas.height=h;
      const ctx=canvas.getContext('2d');
      ctx.drawImage(bitmap,0,0,w,h);
      async function toBlob(q){ return await new Promise(r=> (canvas.convertToBlob ? canvas.convertToBlob({type:'image/webp', quality:q}).then(r) : canvas instanceof OffscreenCanvas ? r(null) : canvas.toBlob(r,'image/webp',q))); }
      let blob = await toBlob(quality);
      if(!blob && !(canvas instanceof OffscreenCanvas)){
        blob = await new Promise(r=>canvas.toBlob(r,'image/webp',quality));
      }
      let q=quality;
      while(blob && blob.size>maxBytes && q>0.45){
        q-=0.1;
        if(canvas.convertToBlob){ blob = await canvas.convertToBlob({type:'image/webp',quality:q}); }
        else { blob = await new Promise(r=> (canvas instanceof OffscreenCanvas ? r(null) : canvas.toBlob(r,'image/webp',q))); }
      }
      if(!blob) return file;
      return new File([blob],'foto.webp',{type:'image/webp'});
    }
  }

  const fotoCrear=document.getElementById('foto-crear');
  if(fotoCrear){
    fotoCrear.addEventListener('change', function(){
      if(!validarArchivoLigero(this)) return;
      const prev=document.querySelector('#modal-crear .foto-preview');
      if(this.files && this.files[0] && prev){
        const rd=new FileReader(); rd.onload=e=>{ prev.src=e.target.result; prev.style.display=''; }; rd.readAsDataURL(this.files[0]);
      }
    });
  }
  const fotoEditar=document.getElementById('foto-editar');
  const fotoPreview=document.getElementById('foto-preview');
  if(fotoEditar && fotoPreview){
    fotoEditar.addEventListener('change', function(){
      if(!validarArchivoLigero(this)) return;
      if(this.files && this.files[0]){
        const rd=new FileReader(); rd.onload=e=>{ fotoPreview.src=e.target.result; fotoPreview.style.display=''; }; rd.readAsDataURL(this.files[0]);
      }
    });
  }

  /* ===== Crear (AJAX) ===== */
  const formCrear=document.getElementById('form-crear-empleado');
  if(formCrear){
    formCrear.addEventListener('submit', async function(e){
      e.preventDefault();
      const btn=formCrear.querySelector('button[type="submit"]');

      const nombre=formCrear.nombre.value.trim(), apellido=formCrear.apellido.value.trim();
      const dni=formCrear.dni.value.trim(), cuil=formCrear.cuil.value.trim(), tel=formCrear.telefono.value.trim();
      const errs=[];
      if(!/^[A-ZÁÉÍÓÚÑ ]+$/.test(nombre)) errs.push('Nombre inválido');
      if(!/^[A-ZÁÉÍÓÚÑ ]+$/.test(apellido)) errs.push('Apellido inválido');
      if(!/^[0-9]{8}$/.test(dni)) errs.push('DNI inválido');
      if(!/^[0-9]{11}$/.test(cuil)) errs.push('CUIL inválido');
      if(tel && !/^[0-9]{1,10}$/.test(tel)) errs.push('Teléfono inválido');
      if(errs.length){ showError(errs.join(', ')); return; }

      btn.disabled=true; btn.textContent='Guardando...';
      const fd=new FormData(formCrear);
      const fotoFile = formCrear.foto?.files?.[0];
      if(fotoFile){
        try{
          const compact = await compressImageIfNeeded(fotoFile, {maxW:256, maxH:256, maxBytes:150*1024, quality:0.72});
          fd.set('foto', compact, compact.name);
        }catch(_){}
      }
      fd.append('action','midas_crear_empleado');
      fd.append('nonce', EMP_NONCE);
      fd.append('midas_empleados_nonce', EMP_NONCE);

      fetch(AJAX_URL,{method:'POST',body:fd,credentials:'same-origin'})
        .then(r=>r.json())
        .then(d=>{ btn.disabled=false; btn.textContent='Crear';
          if(d?.success && d?.data?.empleado){ showSuccess('Empleado creado correctamente.'); location.reload(); }
          else{ console.error('Resp crear:', d); showError(d?.data?.message || 'No se pudo crear el empleado.'); }
        })
        .catch((err)=>{ console.error('Crear error:', err); btn.disabled=false; btn.textContent='Crear'; showError('Error en la comunicación AJAX.'); });
    });
  }

  /* ===== Editar (AJAX) ===== */
  const formEditar = document.getElementById('form-editar-empleado');
  if (formEditar) {
    formEditar.addEventListener('submit', async function(e){
      e.preventDefault();

      const btn = formEditar.querySelector('button[type="submit"]');

      const nombre = formEditar.nombre.value.trim();
      const apellido = formEditar.apellido.value.trim();
      const dni = formEditar.dni.value.trim();
      const cuil = formEditar.cuil.value.trim();
      const tel = formEditar.telefono.value.trim();
      const foto = document.getElementById('foto-editar');

      const errs = [];
      if(!/^[A-ZÁÉÍÓÚÑ ]+$/.test(nombre)) errs.push('Nombre inválido');
      if(!/^[A-ZÁÉÍÓÚÑ ]+$/.test(apellido)) errs.push('Apellido inválido');
      if(!/^[0-9]{8}$/.test(dni)) errs.push('DNI inválido');
      if(!/^[0-9]{11}$/.test(cuil)) errs.push('CUIL inválido');
      if(tel && !/^[0-9]{1,10}$/.test(tel)) errs.push('Teléfono inválido');
      if (errs.length){ showError(errs.join(', ')); return; }

      btn.disabled = true; btn.textContent = 'Guardando...';

      const fd = new FormData(formEditar);
      const f = foto?.files?.[0];
      if(f){
        try{
          const compact = await compressImageIfNeeded(f, {maxW:256, maxH:256, maxBytes:150*1024, quality:0.72});
          fd.set('foto', compact, compact.name);
        }catch(_){}
      }
      fd.append('action', 'midas_editar_empleado');
      fd.append('nonce', EMP_NONCE);
      fd.append('midas_empleados_nonce', EMP_NONCE);

      fetch(AJAX_URL, { method:'POST', body: fd, credentials:'same-origin' })
        .then(r => r.text())
        .then(t => {
          let d; try { d = JSON.parse(t); } catch(_) { throw new Error(t); }
          btn.disabled = false; btn.textContent = 'Guardar';

          if (d && d.success) {
            showSuccess('Empleado actualizado correctamente.');
            closeModal(document.getElementById('modal-editar'));
            buscarEmpleadosAJAX(currentQuery, currentPage);
          } else {
            console.error('Resp editar:', d);
            showError(d?.data?.message || d?.message || 'No se pudo guardar el empleado.');
          }
        })
        .catch(err => {
          console.error('Editar error:', err);
          btn.disabled = false; btn.textContent = 'Guardar';
          showError('Error en la comunicación AJAX.');
        });
    });
  }

  /* ===== Nota de empleado ===== */
  const formNota=document.getElementById('form-nota-empleado');
  const textarea=document.getElementById('nota-textarea');
  const empleadoIdInput=document.getElementById('nota-empleado-id');
  let burbujaActual=null;

  document.body.addEventListener('click', function(e){
    const burbuja=e.target.closest('.nota-burbuja-superpuesta, .nota-burbuja');
    if(burbuja){
      e.preventDefault?.();
      burbujaActual=burbuja;
      const id=burbuja.getAttribute('data-empleado-id')
          || burbuja.closest('[data-empleado-id]')?.getAttribute('data-empleado-id')
          || burbuja.closest('tr[data-id]')?.getAttribute('data-id');
      empleadoIdInput.value=id||'';
      openModal(document.getElementById('modal-nota-empleado'));
      textarea.value=''; textarea.placeholder='Cargando...';
      const url = AJAX_URL + '?action=midas_get_nota_empleado'
        + '&empleado_id=' + encodeURIComponent(id||'')
        + '&nonce=' + encodeURIComponent(EMP_NONCE)
        + '&midas_empleados_nonce=' + encodeURIComponent(EMP_NONCE);
      fetch(url, { credentials:'same-origin' })
        .then(r=>r.json())
        .then(d=>{ textarea.value=(d && d.success && d.data?.nota!=null)? d.data.nota : ''; textarea.placeholder='Escribe una nota…'; textarea.focus(); })
        .catch((err)=>{ console.error('Get nota error:', err); textarea.value=''; textarea.placeholder='No se pudo cargar la nota.'; showError('No se pudo cargar la nota.'); });
      return;
    }
    const btnEditar=e.target.closest('.editar-btn');
    if(btnEditar){
      if(btnEditar.tagName === 'A') e.preventDefault();
      openModal(document.getElementById('modal-editar'));
      const g=id=>btnEditar.dataset[id]||'';
      document.getElementById('edit-id').value=g('id');
      document.getElementById('edit-nombre').value=g('nombre');
      document.getElementById('edit-apellido').value=g('apellido');
      document.getElementById('edit-dni').value=g('dni');
      document.getElementById('edit-cuil').value=g('cuil');
      document.getElementById('edit-email').value=(g('email')||'').toLowerCase();
      document.getElementById('edit-telefono').value=g('telefono');
      document.getElementById('edit-fecha_nacimiento').value=g('fecha_nacimiento');
      document.getElementById('edit-direccion').value=g('direccion');
      document.getElementById('edit-estado_civil').value=g('estado_civil');
      document.getElementById('edit-fecha_inicio_laboral').value=g('fecha_inicio_laboral');
      document.getElementById('edit-fecha_fin_laboral').value=g('fecha_fin_laboral');
      document.getElementById('edit-user_id').value=g('user_id');
      document.getElementById('edit-foto-id').value=g('foto_id');
      document.getElementById('edit-area').value=g('area');
      document.getElementById('edit-tarea').value=g('tarea');
      const url=g('foto_url');
      const fotoPreview=document.getElementById('foto-preview');
      if(url){ fotoPreview.src=url; fotoPreview.style.display='block'; } else { fotoPreview.style.display='none'; }
      const fotoEditar=document.getElementById('foto-editar');
      if(fotoEditar) fotoEditar.value='';
      return;
    }
    const btnEliminar=e.target.closest('.btn-eliminar');
    if(btnEliminar){
      if(btnEliminar.tagName === 'A') e.preventDefault();
      if(!confirm('¿Estás seguro que deseas eliminar este empleado?')) return;
      const fd=new FormData();
      fd.append('action','midas_eliminar_empleado');
      fd.append('empleado_id', btnEliminar.dataset.id);
      fd.append('nonce', EMP_NONCE);
      fd.append('midas_empleados_nonce', EMP_NONCE);
      fetch(AJAX_URL,{method:'POST',body:fd,credentials:'same-origin'})
        .then(r=>r.json())
        .then(d=>{ if(d.success){ showSuccess('Empleado eliminado correctamente.'); btnEliminar.closest('tr')?.remove(); } else { console.error('Resp eliminar:', d); showError(d?.data?.message || 'Error al eliminar.'); } })
        .catch((err)=>{ console.error('Eliminar error:', err); showError('Error en la comunicación AJAX.'); });
      return;
    }
  });

  if(formNota){
    formNota.addEventListener('submit', function(e){
      e.preventDefault();
      const fd=new FormData(formNota);
      fd.append('action','midas_guardar_nota_empleado');
      fd.append('nonce', EMP_NONCE);
      fd.append('midas_empleados_nonce', EMP_NONCE);
      fetch(AJAX_URL,{method:'POST',body:fd,credentials:'same-origin'})
        .then(r=>r.json())
        .then(d=>{
          if(d.success){
            if(burbujaActual){
              const texto=burbujaActual.querySelector('.nota-texto') || (()=>{const s=document.createElement('span'); s.className='nota-texto'; burbujaActual.appendChild(s); return s;})();
              const val=(textarea.value||'').trim();
              if(val){ burbujaActual.classList.remove('vacia'); texto.textContent = val.length>60 ? val.slice(0,60)+'…' : val; }
              else{ burbujaActual.classList.add('vacia'); texto.textContent = 'Nota'; }
            }
            showSuccess('Nota guardada correctamente.');
            document.getElementById('modal-nota-empleado').style.display='none';
          }else{ console.error('Resp guardar nota:', d); showError('Error al guardar la nota.'); }
        })
        .catch((err)=>{ console.error('Guardar nota error:', err); showError('Error en la comunicación AJAX.'); });
    });
  }

  // Carga inicial + stack móvil + lazy imágenes
  buscarEmpleadosAJAX('',1);
  makeLazyImages(document);
});
</script>
