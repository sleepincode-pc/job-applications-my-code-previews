<?php
if (!defined('ABSPATH')) exit;

use MidasRRHH\Models\Recibo_Model;
use MidasRRHH\Models\Empleado_Model;

global $wpdb;

$empleado_model = new Empleado_Model();

/* ====== Paleta guardada por usuario (scope local a esta vista) ====== */
$ajax_url      = admin_url('admin-ajax.php');
$nonce_palette = wp_create_nonce('midas_palette_scoped_nonce');
$uid           = get_current_user_id();
$saved_palette = $uid ? get_user_meta($uid, 'midas_palette_scoped', true) : null;
if (!is_array($saved_palette)) $saved_palette = null;
?>
<!-- Inyecta config/nonce + paleta guardada -->
<script>
  window.midas_rrhh = window.midas_rrhh || {};
  midas_rrhh.ajax_url      = midas_rrhh.ajax_url      || "<?php echo esc_js($ajax_url); ?>";
  midas_rrhh.palette_nonce = midas_rrhh.palette_nonce || "<?php echo esc_js($nonce_palette); ?>";
  midas_rrhh.user_palette  = midas_rrhh.user_palette  || <?php echo wp_json_encode($saved_palette ?: (object)[]); ?>;
</script>

<style>
/* ====== Scope de paleta SOLO para Recibos ====== */
.midas-recibos{
  --md-card-bg:#ffffff;
  --md-card-border:#ccd0d4;
  --md-card-header-bg:#f7f7f7;
  --md-card-header-text:#1f2937;
  --md-table-stripe:#f9fafb;
  --md-text:#1e293b;
  --md-muted:#475569;

  color:var(--md-text);
}

/* ---- Modal ---- */
.midas-recibos .modal-overlay{
  position:fixed; inset:0; background:rgba(0,0,0,.5); z-index:9999;
  display:flex; justify-content:center; align-items:center;
}
.midas-recibos .modal-content{
  background:var(--md-card-bg); color:var(--md-text); padding:20px; border-radius:10px;
  width:min(480px,95%); box-sizing:border-box; position:relative; border:1px solid var(--md-card-border);
  box-shadow:0 10px 30px #0002;
}
.midas-recibos .modal-close{ position:absolute; top:8px; right:8px; background:transparent; border:none; font-size:20px; cursor:pointer; color:var(--md-muted); }
.midas-recibos .fade-in{ animation:fadeIn .2s ease-in-out; }
@keyframes fadeIn{ from{opacity:0} to{opacity:1} }
.midas-recibos .fullwidth-btn{ width:100%; margin-top:10px; }

/* ---- Tabla ---- */
.midas-recibos .tabla-recibos-container{ width:100%; overflow-x:auto; -webkit-overflow-scrolling:touch; }
.midas-recibos .empleados-table{
  width:100%; border-collapse:collapse; margin-top:12px; font-size:14px;
  background:var(--md-card-bg); color:var(--md-text);
  border:1px solid var(--md-card-border); box-shadow:0 0 5px rgba(0,0,0,.05);
}
.midas-recibos .empleados-table thead{ background:var(--md-card-header-bg); color:var(--md-card-header-text); }
.midas-recibos .empleados-table th, .midas-recibos .empleados-table td{
  padding:12px; text-align:left; border-bottom:1px solid var(--md-card-border); vertical-align:middle;
}
.midas-recibos .empleados-table.striped tbody tr:nth-child(odd){ background:var(--md-table-stripe) !important; }
.midas-recibos .empleados-table tbody tr:hover{ background:var(--md-table-stripe); }

/* ---- Botones y paginación ---- */
.midas-recibos .button-danger{ background-color:#dc3232; border-color:#dc3232; color:#fff; }
.midas-recibos .button-danger:hover{ background-color:#a32323; border-color:#a32323; }
.midas-recibos #paginacion-recibos{ margin-top:10px; text-align:right; }
.midas-recibos #paginacion-recibos a{
  display:inline-block; padding:4px 10px; margin:0 1px; border-radius:6px;
  background:var(--md-card-header-bg); color:#2271b1; text-decoration:none; border:1px solid var(--md-card-border); font-weight:600;
}
.midas-recibos #paginacion-recibos a.current,
.midas-recibos #paginacion-recibos a:hover{ background:#2271b1; color:#fff; }

/* ---- Utilidades ---- */
.midas-recibos .midas-busqueda-flex{ display:flex; flex-direction:row; align-items:center; gap:6px; }
.midas-recibos .input-mayus{ text-transform:uppercase; }
</style>

<div class="wrap midas-recibos" id="midasRecibos" data-midas-scope>
    <h1><?php esc_html_e('Gestión de Recibos', 'midas-rrhh'); ?></h1>

    <!-- Buscador AJAX -->
    <form id="form-buscar-recibo" style="margin-bottom: 20px; max-width: 400px;" autocomplete="off" onsubmit="return false;">
        <div class="midas-busqueda-flex">
            <input type="text" id="buscar_recibo" class="regular-text input-mayus" placeholder="Buscar por nombre, apellido, DNI, CUIL, tarea o área"
                   maxlength="80">
            <button type="button" id="btn-buscar-recibo" class="button">Buscar</button>
            <a href="#" id="btn-limpiar-recibo" class="button" style="display:none;">Limpiar</a>
        </div>
    </form>

    <!-- Botón Abrir Modal Crear -->
    <button id="btn-abrir-crear" class="button button-primary" style="margin-bottom: 20px;">
        <?php esc_html_e('Agregar Nuevo Recibo', 'midas-rrhh'); ?>
    </button>

    <!-- Modal Crear/Editar Recibo -->
    <div id="modal-crear" class="modal-overlay" style="display:none;">
        <div class="modal-content fade-in">
            <button class="modal-close" id="cerrar-crear">&times;</button>
            <h2 id="titulo-modal-recibo">Nuevo Recibo</h2>
            <form enctype="multipart/form-data" id="form-crear-recibo" novalidate>
                <!-- Nonce ALINEADO con el handler -->
                <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('midas_recibos_nonce'); ?>">
                <input type="hidden" name="edit_recibo_id" id="edit_recibo_id" value="">
                <table class="form-table">
                    <tr>
                        <th><label for="empleado_id">Empleado</label></th>
                        <td>
                            <select name="empleado_id" id="empleado_id" required class="regular-text"></select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="periodo">Periodo Liquidado</label></th>
                        <td>
                            <input type="text" name="periodo" id="periodo" required class="regular-text input-mayus"
                                   placeholder="Ej: JULIO 2025"
                                   maxlength="32"
                                   pattern="^[A-ZÁÉÍÓÚÑ0-9 \-\/]+$"
                                   title="Solo mayúsculas, números, espacio, guion y barra (/)">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="monto">Monto a Pagar</label></th>
                        <td>
                            <input type="number" name="monto" id="monto" step="0.01" min="0" required class="regular-text" placeholder="Ej: 12345.67">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="detalles">Detalle Anexos</label></th>
                        <td>
                            <!-- SIN pattern: solo exigimos MAYÚSCULAS en el front -->
                            <textarea name="detalles" id="detalles" class="regular-text input-mayus" rows="3" maxlength="600"
                                      placeholder="DETALLE DE ANEXOS, SI HAY"></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="archivo_pdf">Carga del Recibo (PDF)</label></th>
                        <td>
                            <input type="file" name="archivo_pdf" id="archivo_pdf" accept="application/pdf,.pdf" class="regular-text" data-max="8388608">
                            <small>Sólo se permite PDF (máx. 8 MB)</small>
                            <div id="pdf_actual" style="margin-top:8px;display:none"></div>
                        </td>
                    </tr>
                </table>
                <p><button type="submit" class="button button-primary fullwidth-btn">Guardar Recibo</button></p>
            </form>
        </div>
    </div>

    <!-- Tabla Recibos -->
    <div class="tabla-recibos-container">
        <table class="wp-list-table widefat fixed striped empleados-table" id="tabla-recibos">
            <thead>
                <tr>
                    <th><?php esc_html_e('ID', 'midas-rrhh'); ?></th>
                    <th><?php esc_html_e('Empleado', 'midas-rrhh'); ?></th>
                    <th><?php esc_html_e('Periodo', 'midas-rrhh'); ?></th>
                    <th><?php esc_html_e('Monto', 'midas-rrhh'); ?></th>
                    <th><?php esc_html_e('Detalle Anexos', 'midas-rrhh'); ?></th>
                    <th><?php esc_html_e('Recibo (PDF)', 'midas-rrhh'); ?></th>
                    <th><?php esc_html_e('Acciones', 'midas-rrhh'); ?></th>
                </tr>
            </thead>
            <tbody id="tbody-recibos">
            </tbody>
        </table>
        <div id="paginacion-recibos"></div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        /* ===== Aplica paleta guardada a este scope ===== */
        const WRAP = document.getElementById('midasRecibos') || document.querySelector('.midas-recibos');
        const SAVED = (window.midas_rrhh && window.midas_rrhh.user_palette) ? window.midas_rrhh.user_palette : null;
        const DEF = {
          cards:{ bg:'#ffffff', border:'#ccd0d4', headerBg:'#f7f7f7', headerTxt:'#1f2937', stripe:'#f9fafb' },
          text:{  txt:'#1e293b', muted:'#475569' }
        };
        const initial = (SAVED && typeof SAVED==='object')
          ? { cards:Object.assign({}, DEF.cards, SAVED.cards||{}), text:Object.assign({}, DEF.text, SAVED.text||{}) }
          : JSON.parse(localStorage.getItem('midas.palette.scoped')||'null') || DEF;

        function applyPaletteTo(el,p){
          if(!el) return;
          el.style.setProperty('--md-card-bg',          p.cards.bg);
          el.style.setProperty('--md-card-border',      p.cards.border);
          el.style.setProperty('--md-card-header-bg',   p.cards.headerBg);
          el.style.setProperty('--md-card-header-text', p.cards.headerTxt);
          el.style.setProperty('--md-table-stripe',     p.cards.stripe);
          el.style.setProperty('--md-text',             p.text.txt);
          el.style.setProperty('--md-muted',            p.text.muted);
        }
        applyPaletteTo(WRAP, initial);
        window.addEventListener('storage', (e)=>{
          if(e.key==='midas.palette.scoped' && e.newValue){
            try{ applyPaletteTo(WRAP, JSON.parse(e.newValue)); }catch(_){}
          }
        });

        // ===== Helpers de sanitización =====
        const ZERO_WIDTH = /[\u200B-\u200D\uFEFF]/g;
        function normalizeNFKC(s){ try{ return (s||'').normalize('NFKC'); }catch(_){ return (s||''); } }
        function toUpperSafe(s){ return normalizeNFKC(String(s||'').replace(ZERO_WIDTH,'')).toUpperCase(); }

        // Listas blancas por campo (mantenemos para buscador/periodo)
        const RE_BUSCAR   = /[^A-ZÁÉÍÓÚÑ0-9 .,\-_/()#%+]/g;   // buscador
        const RE_PERIODO  = /[^A-ZÁÉÍÓÚÑ0-9 \-\/]/g;           // periodo
        // NOTA: YA NO imponemos whitelist para DETALLES (solo MAYÚSCULAS)

        // Aplica mayúsculas + whitelist a un input/textarea (no para nonce/hidden)
        function bindUpperAndWhitelist(el, re, maxLen){
            if (!el) return;
            const isHiddenOrNonce = el.type === 'hidden' || el.name === 'nonce';
            if (isHiddenOrNonce) return; // jamás tocar nonces/hidden
            el.addEventListener('input', function(){
                let v = toUpperSafe(el.value).replace(re,'').replace(/\s+/g,' ');
                if (maxLen && v.length > maxLen) v = v.slice(0, maxLen);
                el.value = v.trimStart();
            });
            el.addEventListener('paste', function(e){
                e.preventDefault();
                let t = (e.clipboardData || window.clipboardData).getData('text') || '';
                t = toUpperSafe(t).replace(re,'').replace(/\s+/g,' ');
                const s = el.selectionStart, en = el.selectionEnd;
                el.value = (el.value||'').slice(0,s) + t + (el.value||'').slice(en);
                const pos = s + t.length; try{ el.setSelectionRange(pos,pos); }catch(_){}
                el.dispatchEvent(new Event('input'));
            });
        }

        // Solo MAYÚSCULAS (sin whitelist de caracteres)
        function bindUpperOnly(el, maxLen){
            if (!el) return;
            const isHiddenOrNonce = el.type === 'hidden' || el.name === 'nonce';
            if (isHiddenOrNonce) return;
            el.addEventListener('input', function(){
                let v = toUpperSafe(el.value);
                if (maxLen && v.length > maxLen) v = v.slice(0, maxLen);
                el.value = v;
            });
            el.addEventListener('paste', function(e){
                e.preventDefault();
                let t = (e.clipboardData || window.clipboardData).getData('text') || '';
                t = toUpperSafe(t);
                const s = el.selectionStart, en = el.selectionEnd;
                el.value = (el.value||'').slice(0,s) + t + (el.value||'').slice(en);
                const pos = s + t.length; try{ el.setSelectionRange(pos,pos); }catch(_){}
                el.dispatchEvent(new Event('input'));
            });
        }

        // ====== Select empleados ======
        var empleados = <?php echo json_encode(array_map(function($emp) {
            return [
                'id' => (int) $emp->id,
                'nombre' => $emp->nombre,
                'apellido' => $emp->apellido,
                'dni' => $emp->dni
            ];
        }, $empleado_model->get_all())); ?>;

        function escapeHtml(s){
            return String(s ?? '').replace(/[&<>"'`=\/]/g, function(c){
                return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;","/":"&#47;","`":"&#96;","=":"&#61;"}[c] || c;
            });
        }
        function escapeAttr(s){ return String(s ?? '').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }

        function renderSelectEmpleado(selectedId) {
            var s = document.getElementById('empleado_id');
            if (!s) return;
            s.innerHTML = '<option value="">Seleccione</option>';
            empleados.forEach(function(emp) {
                const texto = `${emp.nombre} ${emp.apellido} - ${emp.dni}`;
                s.innerHTML += `<option value="${emp.id}"${String(selectedId)==String(emp.id)?' selected':''}>${escapeHtml(texto)}</option>`;
            });
        }

        // ====== Buscador AJAX ======
        var inputBuscador = document.getElementById('buscar_recibo');
        var btnBuscar = document.getElementById('btn-buscar-recibo');
        var btnLimpiar = document.getElementById('btn-limpiar-recibo');
        var ultimoValor = "";

        bindUpperAndWhitelist(inputBuscador, RE_BUSCAR, 80);

        function cargarRecibosTabla(busqueda = "") {
            jQuery.post(ajaxurl, {
                action: 'midas_obtener_recibos_ajax',
                buscar_recibo: busqueda
            }, function(res) {
                if(res && res.success && Array.isArray(res.data.recibos)) {
                    renderRecibosEnTabla(res.data.recibos);
                } else {
                    document.getElementById('tbody-recibos').innerHTML = '<tr><td colspan="7">No se encontraron recibos.</td></tr>';
                }
            });
        }

        inputBuscador.addEventListener('input', function() {
            var val = inputBuscador.value.trim();
            cargarRecibosTabla(val);
            btnLimpiar.style.display = val.length ? "" : "none";
            ultimoValor = val;
        });
        btnBuscar.addEventListener('click', function(){
            var val = inputBuscador.value.trim();
            cargarRecibosTabla(val);
            btnLimpiar.style.display = val.length ? "" : "none";
            ultimoValor = val;
        });
        btnLimpiar.addEventListener('click', function(e){
            e.preventDefault();
            inputBuscador.value = "";
            cargarRecibosTabla('');
            btnLimpiar.style.display = "none";
        });

        function renderRecibosEnTabla(recibos) {
            var tbody = document.getElementById('tbody-recibos');
            if (!tbody) return;
            if (!recibos.length) {
                tbody.innerHTML = '<tr><td colspan="7">No se encontraron recibos.</td></tr>';
                return;
            }
            var html = '';
            recibos.forEach(function(recibo) {
                var pdf_url = recibo.archivo_id ? '<?php echo site_url(); ?>/?attachment_id=' + encodeURIComponent(recibo.archivo_id) : '';
                const empleadoTxt = escapeHtml(recibo.empleado_nombre || '');
                const periodoTxt  = escapeHtml(recibo.periodo || '');
                const detallesTxt = escapeHtml(recibo.detalles || '');
                const dataDetallesAttr = escapeAttr(recibo.detalles || '');
                html += `
                    <tr class="fila-recibo" data-id="${escapeAttr(recibo.id)}"
                        data-empleado="${escapeAttr(recibo.empleado_id)}"
                        data-periodo="${escapeAttr(recibo.periodo)}"
                        data-monto="${escapeAttr(recibo.monto)}"
                        data-detalles="${dataDetallesAttr}"
                        data-pdf="${escapeAttr(recibo.archivo_id)}">
                        <td>${escapeHtml(recibo.id)}</td>
                        <td>${empleadoTxt}</td>
                        <td>${periodoTxt}</td>
                        <td>$${Number(recibo.monto||0).toFixed(2)}</td>
                        <td>${detallesTxt}</td>
                        <td>
                            ${recibo.archivo_id ?
                                `<a href="${escapeAttr(pdf_url)}" target="_blank" class="button">Ver PDF</a>` :
                                '<span>No disponible</span>'}
                        </td>
                        <td style="white-space:nowrap">
                            <button type="button" class="button button-secondary btn-editar-recibo">Editar</button>
                            <button type="button" class="button button-danger btn-eliminar-recibo">Eliminar</button>
                        </td>
                    </tr>
                `;
            });
            tbody.innerHTML = html;
            activarBotonesRecibo();
        }

        function activarBotonesRecibo() {
            document.querySelectorAll('.btn-editar-recibo').forEach(function(btn) {
                btn.addEventListener('click', function(e) {
                    var tr = e.target.closest('tr');
                    renderSelectEmpleado(tr.dataset.empleado);
                    document.getElementById('edit_recibo_id').value = tr.dataset.id;
                    document.getElementById('periodo').value  = toUpperSafe(tr.dataset.periodo).replace(RE_PERIODO,''); // mantenemos whitelist en PERIODO
                    document.getElementById('monto').value    = tr.dataset.monto;
                    // DETALLES: solo MAYÚSCULAS (sin whitelist)
                    document.getElementById('detalles').value = toUpperSafe(tr.dataset.detalles);
                    document.getElementById('archivo_pdf').value = '';
                    var pdfActualDiv = document.getElementById('pdf_actual');
                    if(tr.dataset.pdf && tr.dataset.pdf != '0') {
                        pdfActualDiv.style.display = '';
                        let url = '<?php echo site_url(); ?>/?attachment_id=' + encodeURIComponent(tr.dataset.pdf);
                        pdfActualDiv.innerHTML = `<a href="${escapeAttr(url)}" target="_blank" class="button">Ver PDF Actual</a>`;
                    } else {
                        pdfActualDiv.style.display = 'none';
                        pdfActualDiv.innerHTML = '';
                    }
                    document.getElementById('titulo-modal-recibo').textContent = 'Editar Recibo';
                    document.getElementById('modal-crear').style.display = 'flex';
                });
            });

            document.querySelectorAll('.btn-eliminar-recibo').forEach(function(btn) {
                btn.addEventListener('click', function(e) {
                    var tr = e.target.closest('tr');
                    if (confirm('¿Seguro que deseas eliminar este recibo?')) {
                        jQuery.post(ajaxurl, {
                            action: 'midas_eliminar_recibo',
                            recibo_id: tr.dataset.id,
                            nonce: '<?php echo wp_create_nonce('midas_recibos_nonce'); ?>'
                        }, function(res) {
                            if(res && res.success) {
                                cargarRecibosTabla(ultimoValor);
                            } else {
                                alert(res && res.data && res.data.message ? res.data.message : 'Error al eliminar recibo');
                            }
                        });
                    }
                });
            });
        }

        // ===== Abrir modal =====
        document.getElementById('btn-abrir-crear').addEventListener('click', function () {
            document.getElementById('form-crear-recibo').reset();
            renderSelectEmpleado('');
            document.getElementById('edit_recibo_id').value = '';
            document.getElementById('titulo-modal-recibo').textContent = 'Nuevo Recibo';
            document.getElementById('pdf_actual').style.display = 'none';
            document.getElementById('pdf_actual').innerHTML = '';
            document.getElementById('modal-crear').style.display = 'flex';
        });

        // ===== Cerrar modal =====
        document.getElementById('cerrar-crear').addEventListener('click', function () {
            document.getElementById('modal-crear').style.display = 'none';
        });
        document.getElementById('modal-crear').addEventListener('click', function(e) {
            if (e.target === this) this.style.display = 'none';
        });
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') document.getElementById('modal-crear').style.display = 'none';
        });

        // ===== Forzar MAYÚSCULAS =====
        bindUpperAndWhitelist(document.getElementById('periodo'),  RE_PERIODO, 32); // mantenemos control de PERIODO
        bindUpperOnly(document.getElementById('detalles'), 600);                    // SOLO mayúsculas en DETALLES

        // ===== Validación de archivo (PDF) =====
        const archivoInput = document.getElementById('archivo_pdf');
        function validarPDF(input){
            const max = parseInt(input.getAttribute('data-max')||'0',10) || 8388608; // 8MB
            const f = input.files && input.files[0] ? input.files[0] : null;
            if (!f) return true;
            const nameOk = /\.pdf$/i.test(f.name || '');
            const typeOk = (f.type || '').toLowerCase() === 'application/pdf';
            if (!nameOk || !typeOk) { alert('Solo se permite PDF.'); input.value=''; return false; }
            if (f.size > max) { alert('El PDF supera el tamaño permitido (máx. 8 MB).'); input.value=''; return false; }
            return true;
        }
        if (archivoInput) archivoInput.addEventListener('change', function(){ validarPDF(this); });

        // ======= AJAX ENVÍO DE FORMULARIO (GUARDAR RECIBO) =======
        document.getElementById('form-crear-recibo').addEventListener('submit', function (e) {
            e.preventDefault();
            var form = this;

            const emp = document.getElementById('empleado_id').value.trim();
            const montoVal = document.getElementById('monto').value.trim();
            const p = document.getElementById('periodo').value.trim();
            const d = document.getElementById('detalles').value.trim();

            if (!emp) { alert('Seleccioná un empleado.'); return; }
            if (!montoVal || isNaN(montoVal)) { alert('Ingresá un monto válido.'); return; }
            if (!p || RE_PERIODO.test(''+p)) { alert('Periodo inválido.'); return; }
            // *** Quitamos la validación de caracteres en DETALLES ***
            if (archivoInput && archivoInput.files.length && !validarPDF(archivoInput)) return;

            var formData = new FormData(form);
            formData.append('action', 'midas_crear_recibo_frontend');

            jQuery.ajax({
                url: ajaxurl,
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                type: 'POST',
                dataType: 'json',
                beforeSend: function () {
                    const btn = form.querySelector('button[type="submit"]');
                    btn.disabled = true;
                    btn.textContent = 'Guardando...';
                },
                success: function (res, status, xhr) {
                    const btn = form.querySelector('button[type="submit"]');
                    btn.disabled = false;
                    btn.textContent = 'Guardar Recibo';
                    if (res && res.success) {
                        alert('Recibo guardado correctamente');
                        document.getElementById('modal-crear').style.display = 'none';
                        cargarRecibosTabla(ultimoValor);
                    } else {
                        const msg = (res && res.data && res.data.message) ? res.data.message : ('Error (' + xhr.status + ')');
                        console.warn('Guardar recibo :: respuesta no OK', res);
                        alert(msg);
                    }
                },
                error: function (xhr) {
                    const btn = form.querySelector('button[type="submit"]');
                    btn.disabled = false;
                    btn.textContent = 'Guardar Recibo';

                    let msg = 'Error de red o servidor';
                    try {
                        if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                            msg = xhr.responseJSON.data.message;
                        } else if (xhr.responseText) {
                            try {
                                const j = JSON.parse(xhr.responseText);
                                msg = (j && j.data && j.data.message) ? j.data.message : (xhr.status + ' ' + xhr.statusText);
                            } catch (_) {
                                msg = xhr.responseText || (xhr.status + ' ' + xhr.statusText);
                            }
                        } else {
                            msg = xhr.status + ' ' + xhr.statusText;
                        }
                    } catch (_) {
                        msg = xhr.status + ' ' + xhr.statusText;
                    }
                    console.error('Guardar recibo :: error XHR', xhr);
                    alert(msg);
                }
            });
        });

        // Inicializa el select y la carga inicial
        renderSelectEmpleado('');
        cargarRecibosTabla('');
    });
    </script>
</div>
