<?php
/**
 * Plantilla admin: Roles (roles.php)
 *
 * - Parte superior (por usuario): define las pestañas del BACKEND que NO verá cada usuario.
 * - Parte inferior (por rol): bloquea acciones del FRONT (licencia, carpeta médica, instancia).
 *
 * Requiere:
 *  - Rol_Controller::obtener_tabs_disponibles() y (opcional) guardar/obtener tabs por usuario.
 *  - admin-submenu-guard.php incluido para hacer cumplir lo de backend.
 */

use MidasRRHH\Controllers\Rol_Controller;

if (!defined('ABSPATH')) exit;

/* ---------------- Seguridad de pantalla ---------------- */
if (!current_user_can('rrhh_admin') && !current_user_can('administrator')) {
    wp_die(__('No tienes permisos para ver esta página.', 'midas-rrhh'));
}

/* ---------------- Helper local: normalizar claves de pestañas ---------------- */
if (!function_exists('midas_rrhh_normalize_tab_key')) {
    function midas_rrhh_normalize_tab_key($key) {
        $k = sanitize_key($key);
        $aliases = [
            'instancia'     => 'tickets',
            'instancias'    => 'tickets',
            'ticket'        => 'tickets',
            'informe'       => 'reportes',
            'informes'      => 'reportes',
            'configuracion' => 'ajustes',
        ];
        return isset($aliases[$k]) ? $aliases[$k] : $k;
    }
}

/* ---------------- Controlador de roles ---------------- */
$roles_controller = isset($roles_controller) ? $roles_controller : new Rol_Controller();

/**
 * Mapa CANÓNICO de pestañas -> slug del submenú (debe coincidir con Admin::add_admin_pages()).
 */
$TAB_MAP = [
    'dashboard'      => ['label' => __('Dashboard', 'midas-rrhh'),       'slug' => 'midas-rrhh'],
    'empleados'      => ['label' => __('Empleados', 'midas-rrhh'),       'slug' => 'midas-empleados'],
    'recibos'        => ['label' => __('Recibos', 'midas-rrhh'),         'slug' => 'midas-recibos'],
    'licencias'      => ['label' => __('Licencias', 'midas-rrhh'),       'slug' => 'midas-licencias'],
    'carpeta_medica' => ['label' => __('Carpeta Médica', 'midas-rrhh'),  'slug' => 'midas-carpeta-medica'],
    'tickets'        => ['label' => __('Instancias', 'midas-rrhh'),      'slug' => 'midas-tickets'],
    'reportes'       => ['label' => __('Reportes', 'midas-rrhh'),        'slug' => 'midas-reportes'],
    'ajustes'        => ['label' => __('Configuración', 'midas-rrhh'),   'slug' => 'midas-configuracion'],
    'roles'          => ['label' => __('Roles', 'midas-rrhh'),           'slug' => 'midas-roles'],
];

/* Tabs disponibles: base canónica + labels del controlador (si trae) */
$todos_los_tabs = array_map(fn($v) => $v['label'], $TAB_MAP);
try {
    $desde_ctrl = $roles_controller->obtener_tabs_disponibles();
    if (is_array($desde_ctrl) && !empty($desde_ctrl)) {
        $tmp_norm = [];
        foreach ($desde_ctrl as $k => $lbl) {
            $kk = midas_rrhh_normalize_tab_key($k);
            if (isset($todos_los_tabs[$kk]) && is_string($lbl) && $lbl !== '') $tmp_norm[$kk] = $lbl;
        }
        $todos_los_tabs = array_replace($todos_los_tabs, $tmp_norm);
    }
} catch (\Throwable $e) { /* noop */ }

$tab_keys_validas = array_map('sanitize_key', array_keys($todos_los_tabs));

/* ---------------- Usuarios agrupados por rol (para acordeón) ---------------- */
global $wp_roles;
if (!($wp_roles instanceof WP_Roles)) $wp_roles = wp_roles();
$roles_labels = $wp_roles ? $wp_roles->roles : [];

$usuarios_wp = get_users(['fields' => ['ID','display_name','user_email']]);
$usuarios_por_rol = [];
foreach ($usuarios_wp as $usuario) {
    $wp_user = get_userdata($usuario->ID);
    if (!empty($wp_user->roles) && is_array($wp_user->roles)) {
        foreach ($wp_user->roles as $rol) {
            $usuarios_por_rol[$rol][] = $usuario;
        }
    }
}

/* ---------------- Opciones bloqueadas (FRONT) ---------------- */
$all_bloqueadas = get_option('midas_rrhh_opciones_bloqueadas', []);
if (!is_array($all_bloqueadas)) $all_bloqueadas = [];

/* ---------------- Nonce ---------------- */
$roles_nonce = wp_create_nonce('midas_roles_nonce');

/* ---------------- Opciones FRONT ---------------- */
$opciones_rrhh = [
    'licencia' => __('Licencia', 'midas-rrhh'),
    'documento'=> __('Solicitar Carpeta Médica', 'midas-rrhh'),
    'ticket'   => __('Abrir Instancia', 'midas-rrhh'),
];
$opciones_front_validas = array_keys($opciones_rrhh);
?>
<style>
/* ======================== */
/* ESTILOS PANEL DE ROLES */
/* ======================== */
.accordion-role-header {
    background:#eaf4fb; cursor:pointer; font-weight:700; font-size:16px;
    padding:10px 14px; border:1px solid #d1e3f5; margin-bottom:0; transition:background .15s;
}
.accordion-role-header.active { background:#d3eaf9; }
.accordion-role-content { display:none; }
.accordion-role-content.active { display:table-row-group; }
.tabs-select { margin-top:3px; width:100%; min-height:120px; }
.inline-actions { margin-top:6px; display:flex; gap:8px; flex-wrap:wrap; }
.inline-actions .button { height:28px; line-height:26px; }

.tabla-opciones-bloqueadas {
    margin-top:48px; max-width:900px; border-collapse:collapse;
    background:#f9fafc; border:1px solid #c8e1f5;
}
.tabla-opciones-bloqueadas th,
.tabla-opciones-bloqueadas td {
    border:1px solid #e3edf7; padding:13px 11px; text-align:center; font-size:15px;
}
.tabla-opciones-bloqueadas th { background:#e9f4fc; font-size:16px; }
.tabla-opciones-bloqueadas td { font-weight:600; cursor:pointer; user-select:none; transition:background .18s, opacity .18s; }
.tabla-opciones-bloqueadas .bloqueada { color:#c0392b; background:#ffeaea; }
.tabla-opciones-bloqueadas .permitida { color:#29a329; background:#f2fff2; }

/* Avisos tipo toast */
.midas-toast{
  position:fixed; right:26px; top:26px; z-index:99999; padding:12px 16px;
  border-radius:8px; color:#fff; box-shadow:0 6px 22px rgba(0,0,0,.18);
  opacity:.98; transition:transform .2s ease, opacity .2s ease;
}
.midas-toast.success{ background:#2e7d32; }
.midas-toast.error{ background:#c62828; }
</style>

<div class="wrap">
    <h1><?php esc_html_e('Gestión de Roles y Pestañas', 'midas-rrhh'); ?></h1>
    <p>
        <strong><?php esc_html_e('Parte superior (por usuario):', 'midas-rrhh'); ?></strong>
        <?php esc_html_e('define las pestañas del plugin en el backend que NO verá cada usuario.', 'midas-rrhh'); ?><br>
        <strong><?php esc_html_e('Parte inferior (por rol):', 'midas-rrhh'); ?></strong>
        <?php esc_html_e('define qué acciones del panel del cliente (frontend) están bloqueadas por rol.', 'midas-rrhh'); ?>
    </p>

    <!-- ================== PRIMERA TABLA: pestañas no visibles por usuario ================== -->
    <table class="widefat striped" style="border-collapse:separate;">
        <thead>
            <tr>
                <th><?php esc_html_e('Usuario', 'midas-rrhh'); ?></th>
                <th><?php esc_html_e('Rol', 'midas-rrhh'); ?></th>
                <th><?php esc_html_e('Pestañas no visibles (BACKEND)', 'midas-rrhh'); ?></th>
            </tr>
        </thead>

        <?php foreach ($usuarios_por_rol as $rol_key => $usuarios):
            $rol_nombre = isset($roles_labels[$rol_key]['name']) ? $roles_labels[$rol_key]['name'] : $rol_key;
        ?>
            <tbody class="accordion-group">
                <tr>
                    <td colspan="3" style="padding:0;">
                        <div class="accordion-role-header" data-rol="<?php echo esc_attr($rol_key); ?>">
                            <?php echo esc_html($rol_nombre); ?>
                            <span style="float:right;color:#888;">
                                (<?php echo count($usuarios); ?> <?php echo (count($usuarios)!==1)?esc_html__('usuarios','midas-rrhh'):esc_html__('usuario','midas-rrhh'); ?>)
                            </span>
                        </div>
                    </td>
                </tr>
            </tbody>

            <tbody class="accordion-role-content" id="accordion-<?php echo esc_attr($rol_key); ?>">
                <?php foreach ($usuarios as $usuario):
                    $wp_user   = get_userdata($usuario->ID);
                    $rolesUser = is_array($wp_user->roles) ? $wp_user->roles : [];

                    // Leer pestañas NO visibles del usuario (normalizando alias)
                    $userTabs = $roles_controller->obtener_tabs_usuario($usuario->ID);
                    if (!is_array($userTabs)) $userTabs = [];
                    $userTabs = array_map('midas_rrhh_normalize_tab_key', $userTabs);
                    $userTabs = array_values(array_unique(array_filter(array_map('sanitize_key', $userTabs))));
                    $userTabs = array_values(array_intersect($userTabs, $tab_keys_validas));
                ?>
                <tr>
                    <td><?php echo esc_html($usuario->display_name); ?> (<?php echo esc_html($wp_user->user_email); ?>)</td>
                    <td><?php echo esc_html(implode(', ', $rolesUser)); ?></td>
                    <td>
                        <select multiple class="tabs-select" data-user-id="<?php echo esc_attr($usuario->ID); ?>">
                            <?php foreach ($todos_los_tabs as $key => $label): ?>
                                <option value="<?php echo esc_attr($key); ?>" <?php selected(in_array($key,$userTabs,true)); ?>>
                                    <?php echo esc_html($label); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="inline-actions">
                            <button type="button" class="button button-secondary btn-select-all" data-target="<?php echo esc_attr($usuario->ID); ?>">
                                <?php esc_html_e('Seleccionar todas', 'midas-rrhh'); ?>
                            </button>
                            <button type="button" class="button button-secondary btn-clear-all" data-target="<?php echo esc_attr($usuario->ID); ?>">
                                <?php esc_html_e('Limpiar selección', 'midas-rrhh'); ?>
                            </button>
                        </div>
                        <small style="display:block;margin-top:6px;color:#555;">
                            <?php esc_html_e('Ctrl/Cmd + click para seleccionar múltiples', 'midas-rrhh'); ?>
                        </small>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        <?php endforeach; ?>
    </table>

    <!-- ================== SEGUNDA TABLA: opciones bloqueadas por rol (FRONT) ================== -->
    <h2 style="margin-top:38px;margin-bottom:10px;"><?php esc_html_e('Opciones bloqueadas para cada rol (FRONTEND)', 'midas-rrhh'); ?></h2>
    <table class="tabla-opciones-bloqueadas">
        <thead>
            <tr>
                <th><?php esc_html_e('Rol', 'midas-rrhh'); ?></th>
                <?php foreach($opciones_rrhh as $key => $label): ?>
                    <th><?php echo esc_html($label); ?></th>
                <?php endforeach; ?>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($roles_labels as $rol_key => $rol_data):
            $bloqueadas = $all_bloqueadas[$rol_key] ?? [];
            if (!is_array($bloqueadas)) $bloqueadas = [];
            $bloqueadas = array_values(array_unique(array_filter(array_map('sanitize_key', $bloqueadas))));
            $bloqueadas = array_values(array_intersect($bloqueadas, $opciones_front_validas));
        ?>
            <tr>
                <td style="font-weight:700;"><?php echo esc_html($rol_data['name']); ?></td>
                <?php foreach($opciones_rrhh as $opcion => $label):
                    $is_bloqueada = in_array($opcion, $bloqueadas, true);
                ?>
                    <td
                        class="<?php echo $is_bloqueada ? 'bloqueada' : 'permitida'; ?>"
                        data-rol="<?php echo esc_attr($rol_key); ?>"
                        data-opcion="<?php echo esc_attr($opcion); ?>"
                        title="<?php echo esc_attr($is_bloqueada ? __('Click para permitir', 'midas-rrhh') : __('Click para bloquear', 'midas-rrhh')); ?>">
                        <?php echo esc_html($is_bloqueada ? __('Bloqueada', 'midas-rrhh') : __('Permitida', 'midas-rrhh')); ?>
                    </td>
                <?php endforeach; ?>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
/* Bootstrap midas_rrhh config */
(function() {
  if (typeof window.midas_rrhh === 'undefined') window.midas_rrhh = {};
  if (!midas_rrhh.ajax_url) {
    if (typeof ajaxurl !== 'undefined') { midas_rrhh.ajax_url = ajaxurl; }
    else { midas_rrhh.ajax_url = "<?php echo esc_js(admin_url('admin-ajax.php')); ?>"; }
  }
  if (!midas_rrhh.nonces) { midas_rrhh.nonces = {}; }
  midas_rrhh.nonces.roles = "<?php echo esc_js($roles_nonce); ?>";
})();
</script>

<script>
document.addEventListener('DOMContentLoaded', function () {
  const $ = (sel,root=document)=>root.querySelector(sel);
  const $$ = (sel,root=document)=>Array.from(root.querySelectorAll(sel));
  const on = (type, selector, handler) => {
    document.addEventListener(type, (e) => {
      const t = e.target.closest(selector);
      if (t) handler(e, t);
    });
  };
  const toast = (msg, type='success')=>{
    const d=document.createElement('div');
    d.className='midas-toast '+(type==='error'?'error':'success');
    d.textContent=msg;
    document.body.appendChild(d);
    requestAnimationFrame(()=>{ d.style.transform='translateY(0)'; });
    setTimeout(()=>{ d.style.opacity='.0'; d.style.transform='translateY(-6px)';
      setTimeout(()=>d.remove(),180);
    }, 2200);
  };

  /* ===== Acordeón (delegación robusta) ===== */
  on('click', '.accordion-role-header', (_e, header) => {
    const rolKey = header.getAttribute('data-rol');
    const tbody  = $('#accordion-'+rolKey);
    if (!tbody) return;
    $$('.accordion-role-content').forEach(el=>el.classList.remove('active'));
    $$('.accordion-role-header').forEach(el=>el.classList.remove('active'));
    tbody.classList.add('active');
    header.classList.add('active');
  });
  // Abrir el primero por defecto
  const firstHeader = $('.accordion-role-header'); if(firstHeader) firstHeader.click();

  /* ===== Select all / clear (delegación) ===== */
  on('click', '.btn-select-all', (_e, btn) => {
    const id = btn.getAttribute('data-target');
    const select = $('.tabs-select[data-user-id="'+CSS.escape(id)+'"]');
    if (!select) return;
    Array.from(select.options).forEach(opt => opt.selected = true);
    select.dispatchEvent(new Event('change', { bubbles:true }));
  });
  on('click', '.btn-clear-all', (_e, btn) => {
    const id = btn.getAttribute('data-target');
    const select = $('.tabs-select[data-user-id="'+CSS.escape(id)+'"]');
    if (!select) return;
    Array.from(select.options).forEach(opt => opt.selected = false);
    select.dispatchEvent(new Event('change', { bubbles:true }));
  });

  /* ===== Guardar pestañas no visibles (delegación + feedback + protección doble click) ===== */
  on('change', '.tabs-select', (e, select) => {
    if (select.dataset.saving === '1') return;
    select.dataset.saving = '1';
    select.style.opacity = '.6';

    const userId = select.dataset.userId;
    const tabs = Array.from(select.selectedOptions).map(o => o.value);

    fetch(midas_rrhh.ajax_url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        action: 'midas_guardar_tabs',
        user_id: userId,
        tabs: JSON.stringify(tabs),
        nonce: midas_rrhh.nonces.roles
      })
    })
    .then(r=>r.json())
    .then(r=>{
      if (r && r.success) {
        toast(r.data?.message || 'Pestañas actualizadas');
      } else {
        toast((r && (r.data?.message || r.message)) || 'No se pudo guardar', 'error');
      }
    })
    .catch(()=>toast('Error inesperado al guardar', 'error'))
    .finally(()=>{ select.style.opacity=''; select.dataset.saving=''; });
  });

  /* ===== Guardar opciones bloqueadas por rol (delegación + feedback + revert en error) ===== */
  on('click', '.tabla-opciones-bloqueadas td[data-rol][data-opcion]', (e, cell) => {
    const row = cell.closest('tr'); if(!row) return;
    const rol = cell.getAttribute('data-rol');
    const opcion = cell.getAttribute('data-opcion');

    // Construir estado actual leyendo la fila
    const tds = $$('td[data-rol][data-opcion]', row);
    const bloqueadas = new Set();
    tds.forEach(c => { if (c.classList.contains('bloqueada')) bloqueadas.add(c.getAttribute('data-opcion')); });

    // Alternar clic actual
    if (cell.classList.contains('bloqueada')) bloqueadas.delete(opcion);
    else bloqueadas.add(opcion);

    // UI: bloqueamos mientras guarda
    tds.forEach(c => c.style.opacity='.55');

    fetch(midas_rrhh.ajax_url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        action: 'midas_guardar_opciones_bloqueadas',
        rol: rol,
        opciones: JSON.stringify(Array.from(bloqueadas)),
        nonce: midas_rrhh.nonces.roles
      })
    })
    .then(r=>r.json())
    .then(r=>{
      if (r && r.success) {
        // Pintar según lo confirmado por el server (usamos nuestro set local)
        tds.forEach(c=>{
          const op = c.getAttribute('data-opcion');
          if (bloqueadas.has(op)) {
            c.classList.add('bloqueada'); c.classList.remove('permitida');
            c.textContent='Bloqueada'; c.title='Click para permitir';
          } else {
            c.classList.remove('bloqueada'); c.classList.add('permitida');
            c.textContent='Permitida'; c.title='Click para bloquear';
          }
        });
        toast(r.data?.message || 'Opciones actualizadas');
      } else {
        toast((r && (r.data?.message || r.message)) || 'Error al guardar', 'error');
      }
    })
    .catch(()=>toast('Error de red al guardar', 'error'))
    .finally(()=>{ tds.forEach(c => c.style.opacity=''); });
  });
});
</script>

<?php
/* ===========================================================
 * AJAX: GUARDAR PESTAÑAS NO VISIBLES POR USUARIO (BACKEND)
 * =========================================================== */
if (!has_action('wp_ajax_midas_guardar_tabs')) {
    add_action('wp_ajax_midas_guardar_tabs', function() use ($roles_controller, $tab_keys_validas) {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'midas_roles_nonce')) {
            wp_send_json_error(['message' => 'Nonce inválido. Intenta refrescar la página.'], 403);
        }
        if (!current_user_can('rrhh_admin') && !current_user_can('administrator')) {
            wp_send_json_error(['message' => 'No tienes permiso para hacer esto.'], 403);
        }

        $user_id = absint($_POST['user_id'] ?? 0);
        $tabs_in = $_POST['tabs'] ?? '[]';
        $tabs    = json_decode(stripslashes($tabs_in), true);
        if (!is_array($tabs)) $tabs = [];

        // Normalizar alias + sanitizar + filtrar a claves válidas
        $tabs = array_map('midas_rrhh_normalize_tab_key', $tabs);
        $tabs = array_values(array_unique(array_filter(array_map('sanitize_key', $tabs))));
        $tabs = array_values(array_intersect($tabs, $tab_keys_validas));

        if ($user_id <= 0 || !get_user_by('id', $user_id)) {
            wp_send_json_error(['message' => 'Usuario inválido.'], 400);
        }

        // Guardar usando el controlador si existe; de lo contrario en user_meta
        $ok = false;
        try {
            if (method_exists($roles_controller, 'guardar_tabs_usuario')) {
                $ok = (bool) $roles_controller->guardar_tabs_usuario($user_id, $tabs);
                if ($ok === false) {
                    $actual = method_exists($roles_controller, 'obtener_tabs_usuario')
                        ? (array) $roles_controller->obtener_tabs_usuario($user_id)
                        : (array) get_user_meta($user_id, 'midas_rrhh_tabs_ocultas', true);
                    $actual = array_map('midas_rrhh_normalize_tab_key', $actual);
                    $actual = array_values(array_unique(array_filter(array_map('sanitize_key', $actual))));
                    $actual = array_values(array_intersect($actual, $tab_keys_validas));
                    if ($actual === $tabs) $ok = true;
                }
            } else {
                $prev = (array) get_user_meta($user_id, 'midas_rrhh_tabs_ocultas', true);
                $prev = array_map('midas_rrhh_normalize_tab_key', $prev);
                $prev = array_values(array_unique(array_filter(array_map('sanitize_key', $prev))));
                $prev = array_values(array_intersect($prev, $tab_keys_validas));

                if ($prev === $tabs) {
                    $ok = true;
                } else {
                    $ok = (bool) update_user_meta($user_id, 'midas_rrhh_tabs_ocultas', $tabs);
                    if ($ok === false) {
                        $check = (array) get_user_meta($user_id, 'midas_rrhh_tabs_ocultas', true);
                        $check = array_map('midas_rrhh_normalize_tab_key', $check);
                        $check = array_values(array_unique(array_filter(array_map('sanitize_key', $check))));
                        $check = array_values(array_intersect($check, $tab_keys_validas));
                        if ($check === $tabs) $ok = true;
                    }
                }
            }
        } catch (\Throwable $e) {
            wp_send_json_error(['message' => 'Error interno al guardar.'], 500);
        }

        if (!$ok) wp_send_json_error(['message' => 'No se pudo guardar.'], 500);
        wp_send_json_success(['message' => 'Guardado correcto.']);
    });
}

/* ===================================================================
 * AJAX: GUARDAR OPCIONES BLOQUEADAS POR ROL (FRONTEND)
 * =================================================================== */
if (!has_action('wp_ajax_midas_guardar_opciones_bloqueadas')) {
    add_action('wp_ajax_midas_guardar_opciones_bloqueadas', function() use ($opciones_front_validas) {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'midas_roles_nonce')) {
            wp_send_json_error(['message' => 'Nonce inválido. Intenta refrescar la página.'], 403);
        }
        if (!current_user_can('rrhh_admin') && !current_user_can('administrator')) {
            wp_send_json_error(['message' => 'No tienes permiso para hacer esto.'], 403);
        }

        $rol      = sanitize_text_field($_POST['rol'] ?? '');
        $opciones = isset($_POST['opciones']) ? json_decode(stripslashes($_POST['opciones']), true) : [];
        if (!$rol) wp_send_json_error(['message' => 'Rol no especificado.'], 400);
        if (!is_array($opciones)) $opciones = [];

        $opciones = array_values(array_unique(array_filter(array_map('sanitize_key', $opciones))));
        $opciones = array_values(array_intersect($opciones, $opciones_front_validas));

        $all_bloqueadas = get_option('midas_rrhh_opciones_bloqueadas', []);
        if (!is_array($all_bloqueadas)) $all_bloqueadas = [];

        $prev = $all_bloqueadas[$rol] ?? [];
        $prev = array_values(array_unique(array_filter(array_map('sanitize_key', $prev))));
        $prev = array_values(array_intersect($prev, $opciones_front_validas));

        if ($prev === $opciones) {
            wp_send_json_success(['message' => 'Opciones bloqueadas actualizadas']);
        }

        $all_bloqueadas[$rol] = $opciones;
        $ok = update_option('midas_rrhh_opciones_bloqueadas', $all_bloqueadas, false);

        if ($ok === false) {
            $check = get_option('midas_rrhh_opciones_bloqueadas', []);
            $check_val = isset($check[$rol]) ? (array)$check[$rol] : [];
            $check_val = array_values(array_unique(array_filter(array_map('sanitize_key', $check_val))));
            $check_val = array_values(array_intersect($check_val, $opciones_front_validas));
            if ($check_val === $opciones) {
                wp_send_json_success(['message' => 'Opciones bloqueadas actualizadas']);
            }
            wp_send_json_error(['message' => 'Error al guardar opciones.'], 500);
        }

        wp_send_json_success(['message' => 'Opciones bloqueadas actualizadas']);
    });
}
