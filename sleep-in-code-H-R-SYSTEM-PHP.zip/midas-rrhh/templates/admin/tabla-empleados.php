<?php
if (!defined('ABSPATH')) exit;

use MidasRRHH\Models\Empleado_Model;

$empleado_model = new Empleado_Model();

$search_query = isset($_POST['buscar_empleado']) ? sanitize_text_field($_POST['buscar_empleado']) : '';
$empleados_data = $empleado_model->get_all(false);
$empleados = [];

foreach ($empleados_data as $empleado) {
    $match = true;
    if (!empty($search_query)) {
        $match = stripos($empleado->nombre, $search_query) !== false ||
                 stripos($empleado->apellido, $search_query) !== false ||
                 stripos($empleado->dni, $search_query) !== false ||
                 stripos($empleado->cuil, $search_query) !== false;
    }
    if ($match) {
        $empleados[] = $empleado;
    }
}
?>

<table class="wp-list-table widefat fixed striped empleados-table">
    <thead>
        <tr>
            <th><?php esc_html_e('Nombre', 'midas-rrhh'); ?></th>
            <th><?php esc_html_e('DNI', 'midas-rrhh'); ?></th>
            <th><?php esc_html_e('CUIL', 'midas-rrhh'); ?></th>
            <th><?php esc_html_e('Acciones', 'midas-rrhh'); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($empleados)) : ?>
            <?php foreach ($empleados as $empleado) : ?>
                <tr>
                    <td><?php echo esc_html($empleado->nombre . ' ' . $empleado->apellido); ?></td>
                    <td><?php echo esc_html($empleado->dni); ?></td>
                    <td><?php echo esc_html($empleado->cuil); ?></td>
                    <td>
                        <form method="post" style="display:inline;" onsubmit="return confirm('<?php echo esc_js(__('¿Seguro que deseas eliminar este empleado?', 'midas-rrhh')); ?>');">
                            <input type="hidden" name="delete_empleado_id" value="<?php echo esc_attr($empleado->id); ?>">
                            <button type="submit" class="button button-danger"><?php esc_html_e('Eliminar', 'midas-rrhh'); ?></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else : ?>
            <tr><td colspan="4"><?php esc_html_e('No se encontraron empleados.', 'midas-rrhh'); ?></td></tr>
        <?php endif; ?>
    </tbody>
</table>
