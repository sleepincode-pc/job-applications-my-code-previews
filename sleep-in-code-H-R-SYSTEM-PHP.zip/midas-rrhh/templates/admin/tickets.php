<?php
if (!defined('ABSPATH')) exit;

use MidasRRHH\Controllers\Ticket_Controller;
use MidasRRHH\Models\Empleado_Model;

/* ===========================
   0) Setup simple y futuro-prueba
   =========================== */

/* Dar la cap propia a administradores (idempotente) */
add_action('admin_init', function () {
    if ($role = get_role('administrator')) {
        if (!$role->has_cap('midas_open_for_all')) {
            $role->add_cap('midas_open_for_all');
        }
    }
});

/* ¿Puede elegir cualquier destinatario? (cap propia + fallback admin) */
if (!function_exists('midas_rrhh_can_open_for_all')) {
    function midas_rrhh_can_open_for_all($user_id = null) {
        $user_id = $user_id ?: get_current_user_id();
        $allowed = user_can($user_id, 'midas_open_for_all') || user_can($user_id, 'manage_options');
        return apply_filters('midas_rrhh_open_for_all', $allowed, $user_id);
    }
}

/* ===========================
   1) Helpers
   =========================== */

/** Acceso seguro objeto/array */
$g = function($row, $key) {
    if (is_object($row) && isset($row->$key)) return $row->$key;
    if (is_array($row)  && isset($row[$key])) return $row[$key];
    return null;
};

/** Nombre del admin que actuó sobre el ticket */
if (!function_exists('midas_rrhh_resolve_admin_nombre')) {
    function midas_rrhh_resolve_admin_nombre($row) {
        $nombre = '';
        if (is_object($row) && isset($row->admin_nombre)) {
            $nombre = (string) $row->admin_nombre;
        }
        if (trim($nombre) === '' && is_object($row) && !empty($row->admin_id)) {
            $u = get_user_by('ID', (int) $row->admin_id);
            if ($u) $nombre = $u->display_name;
        }
        return trim((string)$nombre);
    }
}

/** Resuelve ID WP de un empleado (varias claves + fallback por email) */
if (!function_exists('midas_rrhh_resolve_wp_user_id_from_empleado')) {
    function midas_rrhh_resolve_wp_user_id_from_empleado($row, callable $g) : int {
        $candidatos = ['user_id','usuario_id','wp_user_id','wp_id','id_usuario','wpuser_id'];
        foreach ($candidatos as $k) {
            $v = $g($row, $k);
            if (!empty($v) && (int)$v > 0) return (int)$v;
        }
        $email = (string)($g($row,'email') ?? $g($row,'correo') ?? $g($row,'mail') ?? '');
        if ($email !== '') {
            $u = get_user_by('email', $email);
            if ($u) return (int)$u->ID;
        }
        return 0;
    }
}

/* ===========================
   2) Datos base / permisos
   =========================== */

$empleado_model = new Empleado_Model();
$empleados      = method_exists($empleado_model, 'obtener_empleados_con_area_y_tarea')
                ? $empleado_model->obtener_empleados_con_area_y_tarea()
                : [];

$ticket_controller = new Ticket_Controller();
$user_id  = get_current_user_id();

/* listar todas / actuar */
$can_list = user_can($user_id,'manage_options') || user_can($user_id,'administrator') || user_can($user_id,'rrhh_admin');
$can_act  = $can_list || user_can($user_id,'rrhh_gestor');

/* elegir cualquier destinatario: cap propia + fallback admin */
$can_open_for_all = midas_rrhh_can_open_for_all($user_id);

if ($can_list) {
    $tickets_todos = $ticket_controller->obtener_todos();
} else {
    $tickets_usuario = $ticket_controller->obtener_tickets_usuario($user_id);
}

$tickets_nonce = wp_create_nonce('midas_tickets_nonce');

/* labels para móvil */
$LBL_USUARIO   = esc_attr__('Usuario WP', 'midas-rrhh');
$LBL_DEST      = esc_attr__('Destinatario', 'midas-rrhh');
$LBL_ASUNTO    = esc_attr__('Asunto', 'midas-rrhh');
$LBL_MENSAJE   = esc_attr__('Mensaje', 'midas-rrhh');
$LBL_ESTADO    = esc_attr__('Estado', 'midas-rrhh');
$LBL_RESPADMIN = esc_attr__('Respuesta/Admin', 'midas-rrhh');
$LBL_ACCIONES  = esc_attr__('Acciones', 'midas-rrhh');
?>

<div class="wrap midas-tickets-wrap">
    <h1><?php esc_html_e('Instancias', 'midas-rrhh'); ?></h1>

    <!-- BOTÓN ABRIR MODAL NUEVO TICKET -->
    <div class="midas-card" style="max-width:600px;margin-bottom:22px;">
        <button id="btn-abrir-modal-ticket" class="button button-primary" style="width:100%;max-width:350px;font-size:17px;">
            <?php esc_html_e('Abrir nueva instancia', 'midas-rrhh'); ?>
        </button>
    </div>

    <!-- MODAL CREAR NUEVO TICKET -->
    <div id="modal-nuevo-ticket" style="display:none;position:fixed;left:0;top:0;width:100vw;height:100vh;z-index:10002;background:rgba(20,25,33,0.18);align-items:center;justify-content:center;">
        <div style="background:#fff;padding:32px 28px 26px 28px;max-width:410px;width:96vw;margin:70px auto;border-radius:13px;box-shadow:0 8px 48px #0002;position:relative;">
            <button type="button" class="btn-cerrar-modal" data-target="#modal-nuevo-ticket" style="position:absolute;top:10px;right:18px;font-size:30px;color:#444;background:none;border:none;cursor:pointer;">&times;</button>
            <form id="form-nuevo-ticket" novalidate>
                <input type="text" name="website" value="" tabindex="-1" autocomplete="off" style="position:absolute;left:-10000px;height:0;width:0;opacity:0;">
                <input type="hidden" name="ts" value="<?php echo esc_attr(time()); ?>">

                <?php if ($can_open_for_all): ?>
                <?php
                /* armar selector destinatarios */
                $destinatarios = [];
                if (!empty($empleados)) {
                    foreach ($empleados as $emp) {
                        $uid = midas_rrhh_resolve_wp_user_id_from_empleado($emp, $g);
                        if ($uid <= 0) continue;

                        $nombre   = trim((string)($g($emp,'nombre') ?? ''));
                        $apellido = trim((string)($g($emp,'apellido') ?? ''));
                        $email    = trim((string)($g($emp,'email') ?? $g($emp,'correo') ?? ''));
                        $label    = trim(($nombre.' '.$apellido)) ?: '';

                        if ($label === '' || $email === '') {
                            $u = get_user_by('ID', $uid);
                            if ($u) {
                                if ($label === '') $label = $u->display_name;
                                if ($email === '') $email = $u->user_email;
                            }
                        }
                        if ($label === '' && $email !== '') $label = $email;
                        if ($label === '') $label = 'Usuario #'.$uid;

                        $destinatarios[$uid] = [
                            'label' => $label . ($email ? " ($email)" : ''),
                            'sort'  => strtolower($label ?: $email ?: ('zz'.$uid))
                        ];
                    }
                }
                /* fallback: usuarios WP si quedaron pocos */
                if (count($destinatarios) <= 1) {
                    $wp_users = get_users([
                        'orderby' => 'display_name',
                        'order'   => 'ASC',
                        'fields'  => ['ID','display_name','user_email'],
                        'number'  => 2000,
                    ]);
                    foreach ($wp_users as $u) {
                        $destinatarios[$u->ID] = [
                            'label' => trim($u->display_name . ($u->user_email ? " ($u->user_email)" : '')),
                            'sort'  => strtolower($u->display_name ?: $u->user_email ?: 'zzz')
                        ];
                    }
                }
                uasort($destinatarios, fn($a,$b) => $a['sort'] <=> $b['sort']);
                ?>
                <div style="margin-bottom:12px;">
                    <label for="destinatario_id"><?php esc_html_e('Seleccionar empleado destinatario', 'midas-rrhh'); ?></label>
                    <select name="destinatario_id" id="destinatario_id" class="widefat" required>
                        <option value=""><?php esc_html_e('Selecciona un empleado...', 'midas-rrhh'); ?></option>
                        <?php foreach ($destinatarios as $uid => $meta): ?>
                            <option value="<?php echo esc_attr($uid); ?>"><?php echo esc_html($meta['label']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>

                <div>
                    <label for="asunto"><?php esc_html_e('Asunto', 'midas-rrhh'); ?></label>
                    <input type="text" name="asunto" id="asunto" required class="widefat"
                           maxlength="120"
                           pattern="^[A-ZÁÉÍÓÚÑ0-9 .,;:¡!¿?\(\)\-_/#+%]{3,120}$"
                           title="<?php echo esc_attr__('Solo mayúsculas, números y puntuación básica. Mín. 3, máx. 120.', 'midas-rrhh'); ?>"
                           style="text-transform:uppercase;">
                </div>
                <div style="margin-top:12px;">
                    <label for="mensaje"><?php esc_html_e('Mensaje', 'midas-rrhh'); ?></label>
                    <textarea name="mensaje" id="mensaje" rows="4" required class="widefat" maxlength="2000"
                              title="<?php echo esc_attr__('Solo mayúsculas, números y puntuación básica. Máx. 2000.', 'midas-rrhh'); ?>"
                              style="text-transform:uppercase;"></textarea>
                </div>
                <button type="submit" class="button button-primary" id="btn-enviar-ticket" style="margin-top:14px;width:100%;">
                    <?php esc_html_e('Enviar Instancia', 'midas-rrhh'); ?>
                </button>
                <span id="ticket-mensaje-usuario" style="margin-left:0;display:block;margin-top:10px;color:#0073aa;font-weight:500;" aria-live="polite"></span>
            </form>
        </div>
    </div>

    <!-- MODALES RESPONDER / RECHAZAR -->
    <div id="modal-responder-ticket" style="display:none;position:fixed;left:0;top:0;width:100vw;height:100vh;z-index:10002;background:rgba(20,25,33,0.18);align-items:center;justify-content:center;">
        <div style="background:#fff;padding:24px;max-width:520px;width:96vw;margin:70px auto;border-radius:13px;box-shadow:0 8px 48px #0002;position:relative;">
            <button type="button" class="btn-cerrar-modal" data-target="#modal-responder-ticket" style="position:absolute;top:10px;right:18px;font-size:30px;color:#444;background:none;border:none;cursor:pointer;">&times;</button>
            <h2 style="margin-top:4px;"><?php esc_html_e('Responder instancia', 'midas-rrhh'); ?></h2>
            <form id="form-responder-ticket" novalidate>
                <input type="text" name="website" value="" tabindex="-1" autocomplete="off" style="position:absolute;left:-10000px;height:0;width:0;opacity:0;">
                <input type="hidden" name="ts" value="<?php echo esc_attr(time()); ?>">
                <input type="hidden" id="responder-ticket-id" name="ticket_id" value="">
                <label for="responder-valor"><?php esc_html_e('Respuesta', 'midas-rrhh'); ?></label>
                <textarea id="responder-valor" name="valor" rows="5" class="widefat" style="text-transform:uppercase;" required maxlength="2000"></textarea>
                <div style="margin-top:12px;text-align:right;">
                    <button type="submit" class="button button-primary" id="btn-responder"><?php esc_html_e('Enviar respuesta', 'midas-rrhh'); ?></button>
                </div>
                <div id="responder-msg" style="margin-top:10px;font-weight:500;" aria-live="polite"></div>
            </form>
        </div>
    </div>

    <div id="modal-rechazar-ticket" style="display:none;position:fixed;left:0;top:0;width:100vw;height:100vh;z-index:10002;background:rgba(20,25,33,0.18);align-items:center;justify-content:center;">
        <div style="background:#fff;padding:24px;max-width:520px;width:96vw;margin:70px auto;border-radius:13px;box-shadow:0 8px 48px #0002;position:relative;">
            <button type="button" class="btn-cerrar-modal" data-target="#modal-rechazar-ticket" style="position:absolute;top:10px;right:18px;font-size:30px;color:#444;background:none;border:none;cursor:pointer;">&times;</button>
            <h2 style="margin-top:4px;"><?php esc_html_e('Rechazar instancia', 'midas-rrhh'); ?></h2>
            <form id="form-rechazar-ticket" novalidate>
                <input type="text" name="website" value="" tabindex="-1" autocomplete="off" style="position:absolute;left:-10000px;height:0;width:0;opacity:0;">
                <input type="hidden" name="ts" value="<?php echo esc_attr(time()); ?>">
                <input type="hidden" id="rechazar-ticket-id" name="ticket_id" value="">
                <label for="rechazar-valor"><?php esc_html_e('Motivo de rechazo', 'midas-rrhh'); ?></label>
                <textarea id="rechazar-valor" name="valor" rows="5" class="widefat" style="text-transform:uppercase;" required maxlength="2000"></textarea>
                <div style="margin-top:12px;text-align:right;">
                    <button type="submit" class="button button-secondary" id="btn-rechazar"><?php esc_html_e('Rechazar', 'midas-rrhh'); ?></button>
                </div>
                <div id="rechazar-msg" style="margin-top:10px;font-weight:500;" aria-live="polite"></div>
            </form>
        </div>
    </div>

    <!-- LISTADO -->
    <div class="midas-card">
        <h2 style="margin-top:0;"><?php echo $can_list ? esc_html__('Todas las instancias', 'midas-rrhh') : esc_html__('Mis instancias', 'midas-rrhh'); ?></h2>
        <div class="table-card-body">
        <table class="widefat striped" id="tabla-tickets">
            <thead>
                <tr>
                    <?php if ($can_list): ?>
                        <th><?php _e('Usuario WP', 'midas-rrhh'); ?></th>
                        <th><?php _e('Destinatario', 'midas-rrhh'); ?></th>
                    <?php endif; ?>
                    <th><?php _e('Asunto', 'midas-rrhh'); ?></th>
                    <th><?php _e('Mensaje', 'midas-rrhh'); ?></th>
                    <th><?php _e('Estado', 'midas-rrhh'); ?></th>
                    <th><?php _e('Respuesta/Admin', 'midas-rrhh'); ?></th>
                    <th class="col-acciones"><?php _e('Acciones', 'midas-rrhh'); ?></th>
                </tr>
            </thead>
            <tbody>
            <?php if ($can_list): ?>
                <?php if (!empty($tickets_todos)): foreach ($tickets_todos as $t):
                    $wp_user      = get_user_by('ID', $t->user_id);
                    $destinatario = get_user_by('ID', $t->destinatario_id ?? 0);
                    $estado       = strtolower(trim($t->estado ?? ''));
                    $adminNombre  = midas_rrhh_resolve_admin_nombre($t);
                ?>
                <tr data-id="<?php echo esc_attr($t->id); ?>">
                    <td data-label="<?php echo $LBL_USUARIO; ?>">
                        <?php
                        if ($wp_user) {
                            echo esc_html($wp_user->display_name) . "<br><a href='mailto:" . esc_attr($wp_user->user_email) . "'>" . esc_html($wp_user->user_email) . "</a>";
                        } else {
                            echo '<em>' . esc_html__('Usuario eliminado', 'midas-rrhh') . '</em>';
                        }
                        ?>
                    </td>

                    <td data-label="<?php echo $LBL_DEST; ?>">
                        <?php
                        if ($destinatario && $destinatario->ID) {
                            echo esc_html($destinatario->display_name)
                                 . "<br><a href='mailto:" . esc_attr($destinatario->user_email) . "'>"
                                 . esc_html($destinatario->user_email) . "</a>";
                        } else {
                            if ($estado !== 'enviado') {
                                echo '<em>' . esc_html__('Equipo de Recursos Humanos', 'midas-rrhh') . '</em>';
                            } else {
                                echo '<em>' . esc_html__('No asignado', 'midas-rrhh') . '</em>';
                            }
                        }
                        ?>
                    </td>

                    <td data-label="<?php echo $LBL_ASUNTO; ?>"><?php echo esc_html($t->asunto); ?></td>
                    <td data-label="<?php echo $LBL_MENSAJE; ?>"><?php echo esc_html($t->mensaje); ?></td>
                    <td data-label="<?php echo $LBL_ESTADO; ?>">
                        <?php
                        if     ($estado === 'pendiente')   echo '<span style="color:#E67E22;font-weight:600;">' . esc_html__('Pendiente','midas-rrhh') . '</span>';
                        elseif ($estado === 'respondido')  echo '<span style="color:#27AE60;font-weight:600;">' . esc_html__('Aceptado','midas-rrhh') . '</span>';
                        elseif ($estado === 'rechazado')   echo '<span style="color:#C0392B;font-weight:600;">' . esc_html__('Rechazado','midas-rrhh') . '</span>';
                        elseif ($estado === 'enviado')     echo '<span style="color:#2980b9;font-weight:600;">' . esc_html__('Enviado','midas-rrhh') . '</span>';
                        else                                echo '<span>-</span>';
                        ?>
                    </td>
                    <td data-label="<?php echo $LBL_RESPADMIN; ?>">
                        <?php if ($estado == 'respondido'): ?>
                            <div style="font-size:13px;"><strong><?php esc_html_e('Respuesta:', 'midas-rrhh'); ?></strong> <?php echo esc_html($t->respuesta); ?></div>
                            <?php echo $adminNombre !== '' ? '<em>'.esc_html__('Por','midas-rrhh').' '.esc_html($adminNombre).'</em>' : '<em>-</em>'; ?>
                        <?php elseif ($estado == 'rechazado'): ?>
                            <div style="font-size:13px;"><strong><?php esc_html_e('Motivo:', 'midas-rrhh'); ?></strong> <?php echo esc_html($t->motivo_rechazo); ?></div>
                            <?php echo $adminNombre !== '' ? '<em>'.esc_html__('Por','midas-rrhh').' '.esc_html($adminNombre).'</em>' : '<em>-</em>'; ?>
                        <?php else: ?>
                            <em>-</em>
                        <?php endif; ?>
                    </td>
                    <td class="col-acciones" data-label="<?php echo $LBL_ACCIONES; ?>">
                        <?php if ($estado == 'pendiente' && $can_act): ?>
                            <button class="button button-secondary btn-responder-ticket" data-id="<?php echo esc_attr($t->id); ?>"><?php esc_html_e('Responder', 'midas-rrhh'); ?></button>
                            <button class="button button-secondary btn-rechazar-ticket"  data-id="<?php echo esc_attr($t->id); ?>"><?php esc_html_e('Rechazar',  'midas-rrhh'); ?></button>
                        <?php else: ?>
                            <span>-</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="7"><?php esc_html_e('No hay instancias.', 'midas-rrhh'); ?></td></tr>
                <?php endif; ?>
            <?php else: ?>
                <?php if (!empty($tickets_usuario)): foreach ($tickets_usuario as $t):
                    $estado = strtolower(trim($t->estado ?? ''));
                    $adminNombre  = midas_rrhh_resolve_admin_nombre($t);
                ?>
                <tr data-id="<?php echo esc_attr($t->id); ?>">
                    <td data-label="<?php echo $LBL_ASUNTO; ?>"><?php echo esc_html($t->asunto); ?></td>
                    <td data-label="<?php echo $LBL_MENSAJE; ?>"><?php echo esc_html($t->mensaje); ?></td>
                    <td data-label="<?php echo $LBL_ESTADO; ?>">
                        <?php
                        if     ($estado === 'pendiente')   echo '<span style="color:#E67E22;font-weight:600;">' . esc_html__('Pendiente','midas-rrhh') . '</span>';
                        elseif ($estado === 'respondido')  echo '<span style="color:#27AE60;font-weight:600;">' . esc_html__('Aceptado','midas-rrhh') . '</span>';
                        elseif ($estado === 'rechazado')   echo '<span style="color:#C0392B;font-weight:600;">' . esc_html__('Rechazado','midas-rrhh') . '</span>';
                        elseif ($estado === 'enviado')     echo '<span style="color:#2980b9;font-weight:600;">' . esc_html__('Enviado','midas-rrhh') . '</span>';
                        else                                echo '<span>-</span>';
                        ?>
                    </td>
                    <td data-label="<?php echo $LBL_RESPADMIN; ?>">
                        <?php if ($estado == 'respondido'): ?>
                            <div style="font-size:13px;"><strong><?php esc_html_e('Respuesta:', 'midas-rrhh'); ?></strong> <?php echo esc_html($t->respuesta); ?></div>
                            <?php echo $adminNombre !== '' ? '<em>'.esc_html__('Por','midas-rrhh').' '.esc_html($adminNombre).'</em>' : '<em>-</em>'; ?>
                        <?php elseif ($estado == 'rechazado'): ?>
                            <div style="font-size:13px;"><strong><?php esc_html_e('Motivo:', 'midas-rrhh'); ?></strong> <?php echo esc_html($t->motivo_rechazo); ?></div>
                            <?php echo $adminNombre !== '' ? '<em>'.esc_html__('Por','midas-rrhh').' '.esc_html($adminNombre).'</em>' : '<em>-</em>'; ?>
                        <?php else: ?>
                            <em>-</em>
                        <?php endif; ?>
                    </td>
                    <td class="col-acciones" data-label="<?php echo $LBL_ACCIONES; ?>"><span>-</span></td>
                </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="5"><?php esc_html_e('No tienes instancias.', 'midas-rrhh'); ?></td></tr>
                <?php endif; ?>
            <?php endif; ?>
            </tbody>
        </table>

        <!-- 📄 Contenedor de paginación (10 por página por defecto) -->
        <div id="tickets-pagination" class="tickets-pagination" data-per-page="10"></div>

        </div>
    </div>
</div>

<style>
.midas-tickets-wrap { max-width:100%; }
.midas-card { background:#fff; border:1px solid #ccd0d4; box-shadow:0 2px 7px #0001; margin-bottom:22px; padding:24px; border-radius:8px; }
.table-card-body { padding:0; overflow-x:visible; }
#tabla-tickets { width:100%; table-layout:fixed; }
#tabla-tickets th, #tabla-tickets td{ white-space:normal; overflow-wrap: break-word; word-break: break-word; vertical-align: top; }
#tabla-tickets .col-acciones{ width:140px; min-width:120px; white-space:normal; text-align:left; }
#tabla-tickets .col-acciones .button{ display:block; width:100%; box-sizing:border-box; margin:0 0 8px 0; }
#tabla-tickets .col-acciones .button:last-child{ margin-bottom:0; }
#form-nuevo-ticket input[type="text"], #form-nuevo-ticket textarea,
#form-responder-ticket textarea, #form-rechazar-ticket textarea { text-transform:uppercase; }
.midas-disabled { opacity:.6; pointer-events:none; }

/* 🔢 Estilos de paginación */
.tickets-pagination{
  display:flex; flex-wrap:wrap; gap:6px;
  justify-content:flex-end; padding:12px 8px 2px 8px;
}
.tickets-pagination .button{ padding:.42rem .7rem; }

/* Toasts */
.midas-toast{
  position:fixed; right:26px; top:26px; z-index:99999; padding:12px 16px;
  border-radius:8px; color:#fff; box-shadow:0 6px 22px rgba(0,0,0,.18);
  opacity:.98; transition:transform .2s ease, opacity .2s ease;
}
.midas-toast.success{ background:#2e7d32; }
.midas-toast.error{ background:#c62828; }

@media (max-width: 782px){
  #tabla-tickets { table-layout:auto; border:0; }
  #tabla-tickets thead{ position:absolute; left:-9999px; top:-9999px; height:0; width:0; overflow:hidden; }
  #tabla-tickets tr{ display:block; border:1px solid #e5e5e5; border-radius:8px; padding:8px 10px; margin-bottom:12px; background:#fff; }
  #tabla-tickets td{ display:flex; align-items:flex-start; gap:10px; padding:8px 6px; font-size:13px; }
  #tabla-tickets td::before{ content: attr(data-label); flex:0 0 44%; font-weight:600; color:#555; }
  #tabla-tickets td.col-acciones{ display:block; padding-top:10px; }
  #tabla-tickets td.col-acciones::before{ content:''; display:none; }
  #tabla-tickets td.col-acciones .button{ width:100%; }
  .tickets-pagination{ justify-content:center; }
}
</style>

<?php if (!isset($GLOBALS['ajaxurl'])): ?>
<script>var ajaxurl = "<?php echo esc_url( admin_url('admin-ajax.php') ); ?>";</script>
<?php endif; ?>

<script>
jQuery(function($){
    /* ===== Sanitizado ===== */
    const ZERO_WIDTH=/[\u200B-\u200D\uFEFF]/g;
    const SPACE_LIKE=/[\u00A0\u1680\u2000-\u200A\u202F\u205F\u3000]/g;
    const RE_ALLOWED=/[^A-ZÁÉÍÓÚÑ0-9 .,;:¡!¿?\(\)\-_/#+%]/g;
    const normalizeNFKC=s=>{try{return (s||'').normalize('NFKC')}catch(_){return(s||'')}};
    const normalizeSpaces=s=>String(s||'').replace(SPACE_LIKE,' ');
    const safeUpper=s=>normalizeNFKC(normalizeSpaces(String(s||'').replace(ZERO_WIDTH,''))).toUpperCase();
    const sanitizeValue=(v,maxLen)=>{ v=safeUpper(v).replace(/[<>]/g,'').replace(RE_ALLOWED,''); if(maxLen&&v.length>maxLen) v=v.slice(0,maxLen); return v; };
    const bindSanitizer=$el=>{ const max=parseInt($el.attr('maxlength')||'0',10)||null;
        $el.on('input blur',function(){ this.value=sanitizeValue(this.value,max); });
        $el.on('paste',function(e){ e.preventDefault(); let t=(e.originalEvent.clipboardData||window.clipboardData).getData('text')||''; t=sanitizeValue(t,max);
            const s=this.selectionStart,en=this.selectionEnd; this.value=this.value.slice(0,s)+t+this.value.slice(en); const pos=s+t.length; try{this.setSelectionRange(pos,pos)}catch(_){}})}
    ;

    /* ===== Toasts ===== */
    function toast(msg,type){ const d=$('<div class="midas-toast '+(type==='error'?'error':'success')+'"/>').text(msg).appendTo('body'); setTimeout(()=>{ d.css({opacity:.0,transform:'translateY(-6px)'}); setTimeout(()=>d.remove(),180); },2200); }

    /* ===== Modales ===== */
    const abrir = sel => $(sel).css('display','flex').hide().fadeIn(120);
    const cerrar = sel => $(sel).fadeOut(100);

    $('#btn-abrir-modal-ticket').on('click',()=>abrir('#modal-nuevo-ticket'));
    $(document).on('click','.btn-cerrar-modal',function(){ cerrar($(this).data('target')); });
    $('#modal-nuevo-ticket,#modal-responder-ticket,#modal-rechazar-ticket').on('click',function(e){ if(e.target===this) $(this).fadeOut(100); });
    $(document).on('keydown',function(e){ if(e.key==='Escape'){ $('#modal-nuevo-ticket,#modal-responder-ticket,#modal-rechazar-ticket').fadeOut(100); } });

    /* ===== Inputs ===== */
    bindSanitizer($('#asunto'));
    bindSanitizer($('#mensaje'));
    $('#destinatario_id').on('change',function(){ const v=String($(this).val()||'').replace(/\D/g,''); $(this).val(v); });

    /* ===== Crear ticket ===== */
    $('#form-nuevo-ticket').on('submit',function(e){
        e.preventDefault();
        const $btn=$('#btn-enviar-ticket');
        const $msg=$('#ticket-mensaje-usuario');
        const asunto=sanitizeValue($('#asunto').val(),120);
        const mensaje=sanitizeValue($('#mensaje').val(),2000);

        if(!asunto||asunto.length<3||!mensaje||mensaje.length<5){
            $msg.css('color','crimson').text('<?php echo esc_js(__('Completá asunto (min 3) y mensaje (min 5).','midas-rrhh')); ?>');
            return;
        }

        const payload={action:'midas_crear_ticket',asunto,mensaje,nonce:'<?php echo esc_js($tickets_nonce); ?>',ts:Math.floor(Date.now()/1000),website:''};

        <?php if ($can_open_for_all): ?>
        const dest=String($('#destinatario_id').val()||'').replace(/\D/g,'');
        if(!dest){
            $msg.css('color','crimson').text('<?php echo esc_js(__('Selecciona un destinatario.','midas-rrhh')); ?>');
            return;
        }
        payload.destinatario_id=dest;
        payload.estado='enviado';
        <?php endif; ?>

        $msg.css('color','#0073aa').text('<?php echo esc_js(__('Enviando...','midas-rrhh')); ?>');
        $btn.addClass('midas-disabled').attr('aria-busy','true').prop('disabled',true);

        $.post(ajaxurl,payload,function(res){
            if(res&&res.success){
                toast('<?php echo esc_js(__('Instancia enviada','midas-rrhh')); ?>','success');
                $msg.css('color','#2271b1').text('<?php echo esc_js(__('Instancia enviada','midas-rrhh')); ?>');
                setTimeout(()=>location.reload(),900);
            }else{
                const m=(res&&res.data)?(res.data.message||res.data):'<?php echo esc_js(__('Error al enviar la instancia','midas-rrhh')); ?>';
                toast(m,'error');
                $msg.css('color','crimson').text(m);
                $btn.removeClass('midas-disabled').removeAttr('aria-busy').prop('disabled',false);
            }
        }).fail(function(){
            toast('<?php echo esc_js(__('Error de red, intenta nuevamente.','midas-rrhh')); ?>','error');
            $msg.css('color','crimson').text('<?php echo esc_js(__('Error de red, intenta nuevamente.','midas-rrhh')); ?>');
            $btn.removeClass('midas-disabled').removeAttr('aria-busy').prop('disabled',false);
        });
    });

    /* ===== Delegación robusta botones ===== */
    $(document).on('click', function(e){
        const $btn = $(e.target).closest('.btn-responder-ticket, .btn-rechazar-ticket, .btn-cerrar-modal');
        if(!$btn.length) return;

        if($btn.hasClass('btn-cerrar-modal')){
            e.preventDefault();
            const target = $btn.data('target');
            if(target) $(target).fadeOut(100);
            return;
        }

        if($btn.hasClass('btn-responder-ticket')){
            e.preventDefault();
            $('#responder-ticket-id').val($btn.data('id'));
            $('#responder-valor').val(''); $('#responder-msg').text('');
            abrir('#modal-responder-ticket');
            return;
        }

        if($btn.hasClass('btn-rechazar-ticket')){
            e.preventDefault();
            $('#rechazar-ticket-id').val($btn.data('id'));
            $('#rechazar-valor').val(''); $('#rechazar-msg').text('');
            abrir('#modal-rechazar-ticket');
            return;
        }
    });

    /* ===== Responder ===== */
    bindSanitizer($('#responder-valor'));
    $('#responder-valor').on('keydown', function(e){ if((e.ctrlKey||e.metaKey) && e.key==='Enter'){ $('#form-responder-ticket').trigger('submit'); }});
    $('#form-responder-ticket').on('submit',function(e){
        e.preventDefault();
        const ticket_id=$('#responder-ticket-id').val();
        const valor=sanitizeValue($('#responder-valor').val(),2000);
        const $msg=$('#responder-msg'), $btn=$('#btn-responder');
        if(!valor||valor.length<2){ $msg.css('color','crimson').text('<?php echo esc_js(__('Ingresá una respuesta válida.','midas-rrhh')); ?>'); return; }
        $msg.css('color','#0073aa').text('<?php echo esc_js(__('Enviando...','midas-rrhh')); ?>');
        $btn.addClass('midas-disabled').attr('aria-busy','true').prop('disabled',true);

        $.post(ajaxurl,{action:'midas_responder_ticket',ticket_id:String(ticket_id).replace(/\D/g,''),valor,nonce:'<?php echo esc_js($tickets_nonce); ?>',ts:Math.floor(Date.now()/1000),website:''},function(res){
            if(res&&res.success){
                toast('<?php echo esc_js(__('Respuesta enviada','midas-rrhh')); ?>','success');
                $msg.css('color','#2271b1').text('<?php echo esc_js(__('Respuesta enviada','midas-rrhh')); ?>');
                setTimeout(()=>location.reload(),800);
            } else {
                const m=(res&&res.data)?(res.data.message||res.data):'<?php echo esc_js(__('Error al responder','midas-rrhh')); ?>';
                toast(m,'error');
                $msg.css('color','crimson').text(m);
                $btn.removeClass('midas-disabled').removeAttr('aria-busy').prop('disabled',false);
            }
        }).fail(function(){
            toast('<?php echo esc_js(__('Error de red, intenta nuevamente.','midas-rrhh')); ?>','error');
            $msg.css('color','crimson').text('<?php echo esc_js(__('Error de red, intenta nuevamente.','midas-rrhh')); ?>');
            $btn.removeClass('midas-disabled').removeAttr('aria-busy').prop('disabled',false);
        });
    });

    /* ===== Rechazar ===== */
    bindSanitizer($('#rechazar-valor'));
    $('#rechazar-valor').on('keydown', function(e){ if((e.ctrlKey||e.metaKey) && e.key==='Enter'){ $('#form-rechazar-ticket').trigger('submit'); }});
    $('#form-rechazar-ticket').on('submit',function(e){
        e.preventDefault();
        const ticket_id=$('#rechazar-ticket-id').val();
        const valor=sanitizeValue($('#rechazar-valor').val(),2000);
        const $msg=$('#rechazar-msg'), $btn=$('#btn-rechazar');
        if(!valor||valor.length<2){ $msg.css('color','crimson').text('<?php echo esc_js(__('Ingresá un motivo válido.','midas-rrhh')); ?>'); return; }
        $msg.css('color','#0073aa').text('<?php echo esc_js(__('Enviando...','midas-rrhh')); ?>');
        $btn.addClass('midas-disabled').attr('aria-busy','true').prop('disabled',true);

        $.post(ajaxurl,{action:'midas_rechazar_ticket',ticket_id:String(ticket_id).replace(/\D/g,''),valor,nonce:'<?php echo esc_js($tickets_nonce); ?>',ts:Math.floor(Date.now()/1000),website:''},function(res){
            if(res&&res.success){
                toast('<?php echo esc_js(__('Instancia rechazada','midas-rrhh')); ?>','success');
                $msg.css('color','#2271b1').text('<?php echo esc_js(__('Instancia rechazada','midas-rrhh')); ?>');
                setTimeout(()=>location.reload(),800);
            } else {
                const m=(res&&res.data)?(res.data.message||res.data):'<?php echo esc_js(__('Error al rechazar','midas-rrhh')); ?>';
                toast(m,'error');
                $msg.css('color','crimson').text(m);
                $btn.removeClass('midas-disabled').removeAttr('aria-busy').prop('disabled',false);
            }
        }).fail(function(){
            toast('<?php echo esc_js(__('Error de red, intenta nuevamente.','midas-rrhh')); ?>','error');
            $msg.css('color','crimson').text('<?php echo esc_js(__('Error de red, intenta nuevamente.','midas-rrhh')); ?>');
            $btn.removeClass('midas-disabled').removeAttr('aria-busy').prop('disabled',false);
        });
    });

    /* ========= 🔢 Paginación simple del listado ========== */
    function initTicketsPagination(){
        const $table = $('#tabla-tickets');
        const $tbody = $table.find('tbody');
        const $rows  = $tbody.find('tr[data-id]'); // solo filas de datos
        const total  = $rows.length;

        let $pager = $('#tickets-pagination');
        if (!$pager.length){
            $pager = $('<div id="tickets-pagination" class="tickets-pagination"/>');
            $table.after($pager);
        }

        let perPage = parseInt($pager.data('per-page'),10);
        if (!perPage || perPage < 1) perPage = 10;

        if (total <= perPage){
            $rows.show();
            $pager.empty();
            return;
        }

        const totalPages = Math.ceil(total / perPage);
        let current = 1;

        const btn = (txt, page, disabled=false, primary=false)=>{
            const $b=$('<button type="button" class="button"/>').text(txt);
            if(primary) $b.addClass('button-primary');
            if(disabled) $b.prop('disabled',true);
            $b.on('click',()=>render(page));
            return $b;
        };

        function paintControls(){
            $pager.empty();
            if (totalPages<=1) return;
            $pager.append(btn('Anterior', Math.max(1,current-1), current===1));
            for (let i=1;i<=totalPages;i++){
                $pager.append(btn(String(i), i, false, i===current));
            }
            $pager.append(btn('Siguiente', Math.min(totalPages,current+1), current===totalPages));
        }

        function render(page){
            current = Math.max(1, Math.min(totalPages, page));
            $rows.hide();
            const start = (current-1)*perPage;
            $rows.slice(start, start+perPage).show();
            paintControls();
            try{ $table[0].scrollIntoView({behavior:'smooth',block:'start'}); }catch(_){}
        }

        render(1);
    }

    initTicketsPagination();
});
</script>
