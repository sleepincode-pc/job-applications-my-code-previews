<?php
/**
 * Enforcer de visibilidad de pestañas (ADMIN)
 * - Oculta submenús por usuario (aunque sea admin)
 * - Bloquea acceso directo por URL con breaker anti-loop
 * - Fallbacks robustos para "Instancias" (tickets) y "Reportes"
 */

if (!defined('ABSPATH')) exit;

/* ========================== Config canónica ========================== */

if (!function_exists('midas_rrhh_parent_menu_slug')) {
    function midas_rrhh_parent_menu_slug() {
        return apply_filters('midas_rrhh_parent_menu_slug', 'midas-rrhh');
    }
}

if (!function_exists('midas_rrhh_get_submenu_items')) {
    function midas_rrhh_get_submenu_items($parent_slug) {
        global $submenu;
        return (isset($submenu[$parent_slug]) && is_array($submenu[$parent_slug])) ? $submenu[$parent_slug] : [];
    }
}

if (!function_exists('midas_rrhh_find_submenu_slug_by_title')) {
    function midas_rrhh_find_submenu_slug_by_title(array $items, array $patterns) {
        foreach ($items as $it) {
            $title = isset($it[0]) ? wp_strip_all_tags($it[0]) : '';
            $slug  = isset($it[2]) ? $it[2] : '';
            if (!$slug || $title === '') continue;
            $t = function_exists('mb_strtolower') ? mb_strtolower($title, 'UTF-8') : strtolower($title);
            foreach ($patterns as $p) {
                $p_l = function_exists('mb_strtolower') ? mb_strtolower($p, 'UTF-8') : strtolower($p);
                if (strpos($t, $p_l) !== false) return $slug;
            }
        }
        return '';
    }
}

/**
 * Autocorrección de slugs si el real difiere.
 * IMPORTANTE: solo intenta corregir si el hook admin_menu ya corrió,
 * para no depender de $submenu antes de tiempo (evita loops raros).
 */
if (!function_exists('midas_rrhh_fix_map_from_runtime')) {
    function midas_rrhh_fix_map_from_runtime(array $map) {
        if (!did_action('admin_menu')) {
            // Menú aún no está construido: no tocamos el mapa.
            return $map;
        }
        $parent   = midas_rrhh_parent_menu_slug();
        $items    = midas_rrhh_get_submenu_items($parent);
        $patterns = [
            'tickets'  => ['instancia','instancias','ticket','tickets'],
            'reportes' => ['reporte','reportes','informe','informes','report','reports'],
            'ajustes'  => ['ajustes','configuracion','configuración','settings'],
        ];
        $patterns = apply_filters('midas_rrhh_runtime_title_patterns', $patterns);
        foreach ($patterns as $key => $words) {
            if (!isset($map[$key])) continue;
            $slug = midas_rrhh_find_submenu_slug_by_title($items, (array)$words);
            if ($slug) $map[$key] = $slug;
        }
        return $map;
    }
}

/** Mapa clave => slug (debe coincidir con Admin::add_admin_pages) */
if (!function_exists('midas_rrhh_tab_map')) {
    function midas_rrhh_tab_map() {
        $map = [
            'dashboard'      => 'midas-rrhh',
            'empleados'      => 'midas-empleados',
            'recibos'        => 'midas-recibos',
            'licencias'      => 'midas-licencias',
            'carpeta_medica' => 'midas-carpeta-medica',
            'tickets'        => 'midas-tickets',        // UI: “Instancias”
            'reportes'       => 'midas-reportes',
            'ajustes'        => 'midas-configuracion',
            'roles'          => 'midas-roles',
        ];
        $map = apply_filters('midas_rrhh_tab_map', $map);
        // Autocorrección por títulos en runtime (solo si el menú ya existe)
        $map = midas_rrhh_fix_map_from_runtime($map);
        return $map;
    }
}

/* ==================== Normalización y lectura ==================== */

if (!function_exists('midas_rrhh_normalize_tab_key')) {
    function midas_rrhh_normalize_tab_key($key) {
        $k = sanitize_key($key);
        $aliases = [
            'instancia'     => 'tickets',
            'instancias'    => 'tickets',
            'ticket'        => 'tickets',
            'informe'       => 'reportes',
            'informes'      => 'reportes',
            'configuracion' => 'ajustes',
        ];
        return isset($aliases[$k]) ? $aliases[$k] : $k;
    }
}

if (!function_exists('midas_rrhh_get_user_hidden_tabs')) {
    function midas_rrhh_get_user_hidden_tabs($user_id) {
        $tabs = [];
        try {
            if (class_exists('\MidasRRHH\Controllers\Rol_Controller')) {
                $rc = new \MidasRRHH\Controllers\Rol_Controller();
                if (method_exists($rc, 'obtener_tabs_usuario')) {
                    $tabs = (array) $rc->obtener_tabs_usuario($user_id);
                }
            }
        } catch (\Throwable $e) {}
        if (empty($tabs)) {
            $tabs = (array) get_user_meta($user_id, 'midas_rrhh_tabs_ocultas', true);
        }
        $tabs  = array_map('midas_rrhh_normalize_tab_key', (array)$tabs);
        $tabs  = array_values(array_unique(array_filter(array_map('sanitize_key', $tabs))));
        $valid = array_keys(midas_rrhh_tab_map());
        return array_values(array_intersect($tabs, $valid));
    }
}

if (!function_exists('midas_rrhh_user_can_see_tab')) {
    function midas_rrhh_user_can_see_tab($tab_key, $user_id = 0) {
        $user_id = $user_id ?: get_current_user_id();
        $hidden  = midas_rrhh_get_user_hidden_tabs($user_id);
        return !in_array(midas_rrhh_normalize_tab_key($tab_key), $hidden, true);
    }
}

/* ============== Utilidades de eliminación “a prueba de balas” ============== */

/**
 * Elimina entradas del $submenu[$parent] por slug exacto y/o por match de título.
 */
if (!function_exists('midas_rrhh_hard_remove_submenu')) {
    function midas_rrhh_hard_remove_submenu($parent_slug, array $slugs = [], array $title_patterns = []) {
        global $submenu;
        if (!isset($submenu[$parent_slug]) || !is_array($submenu[$parent_slug])) return;

        $new = [];
        foreach ($submenu[$parent_slug] as $item) {
            // $item = [0 => title, 1 => cap, 2 => slug, ...]
            $title = isset($item[0]) ? wp_strip_all_tags($item[0]) : '';
            $slug  = isset($item[2]) ? $item[2] : '';
            $t     = function_exists('mb_strtolower') ? mb_strtolower($title,'UTF-8') : strtolower($title);

            $remove_by_slug  = $slug && in_array($slug, $slugs, true);
            $remove_by_title = $title && array_reduce($title_patterns, function($carry,$p) use($t){
                $p = function_exists('mb_strtolower') ? mb_strtolower($p,'UTF-8') : strtolower($p);
                return $carry || (strpos($t, $p) !== false);
            }, false);

            if ($remove_by_slug || $remove_by_title) {
                continue; // no lo copiamos
            }
            $new[] = $item;
        }
        $submenu[$parent_slug] = $new;
    }
}

/**
 * Elimina entradas del menú principal ($menu) con el texto o slug indicados.
 */
if (!function_exists('midas_rrhh_hard_remove_menu_top')) {
    function midas_rrhh_hard_remove_menu_top(array $slugs = [], array $title_patterns = []) {
        global $menu;
        if (!is_array($menu)) return;
        foreach ($menu as $idx => $m) {
            // $m = [0 => title, 2 => slug, ...]
            $title = isset($m[0]) ? wp_strip_all_tags($m[0]) : '';
            $slug  = isset($m[2]) ? $m[2] : '';
            $t     = function_exists('mb_strtolower') ? mb_strtolower($title,'UTF-8') : strtolower($title);

            $remove_by_slug  = $slug && in_array($slug, $slugs, true);
            $remove_by_title = $title && array_reduce($title_patterns, function($carry,$p) use($t){
                $p = function_exists('mb_strtolower') ? mb_strtolower($p,'UTF-8') : strtolower($p);
                return $carry || (strpos($t, $p) !== false);
            }, false);

            if ($remove_by_slug || $remove_by_title) {
                unset($menu[$idx]);
            }
        }
    }
}

/* =================== Ocultar submenús en el admin =================== */

if (!function_exists('midas_rrhh_hide_submenus_for_user')) {
    function midas_rrhh_hide_submenus_for_user() {
        if (!is_user_logged_in()) return;

        $hidden_tabs = midas_rrhh_get_user_hidden_tabs(get_current_user_id());
        if (empty($hidden_tabs)) return;

        $parent_slug = midas_rrhh_parent_menu_slug();
        $map         = midas_rrhh_tab_map();

        // 1) Intento normal (remove_submenu_page)
        foreach ($hidden_tabs as $tab_key) {
            if (!empty($map[$tab_key])) {
                remove_submenu_page($parent_slug, $map[$tab_key]);
            }
        }

        // 2) HARD DELETE para casos tercos (Instancias/Tickets, Reportes)
        $items = midas_rrhh_get_submenu_items($parent_slug);

        if (in_array('tickets', $hidden_tabs, true)) {
            $tickets_slug = !empty($map['tickets']) ? $map['tickets'] : midas_rrhh_find_submenu_slug_by_title($items, ['instancia','instancias','ticket','tickets']);
            midas_rrhh_hard_remove_submenu($parent_slug, array_filter([$tickets_slug]), ['instancia','instancias','ticket','tickets']);
            midas_rrhh_hard_remove_menu_top(array_filter([$tickets_slug]), ['instancia','instancias','ticket','tickets']);
        }

        if (in_array('reportes', $hidden_tabs, true)) {
            $reportes_slug = !empty($map['reportes']) ? $map['reportes'] : midas_rrhh_find_submenu_slug_by_title($items, ['reporte','reportes','informe','informes','report','reports']);
            midas_rrhh_hard_remove_submenu($parent_slug, array_filter([$reportes_slug]), ['reporte','reportes','informe','informes','report','reports']);
            midas_rrhh_hard_remove_menu_top(array_filter([$reportes_slug]), ['reporte','reportes','informe','informes','report','reports']);
        }

        // 3) Si TODAS están ocultas, ocultar el menú padre
        $all_keys = array_keys($map);
        if (!empty($all_keys) && empty(array_diff($all_keys, $hidden_tabs))) {
            remove_menu_page($parent_slug);
        }

        // 4) Último recurso: esconder por JS (si algo se inyectó post-menu)
        add_action('admin_print_footer_scripts', function() use ($hidden_tabs, $map) {
            ?>
            <script>
            (function(){
                try {
                    function killBy(texts, hrefParts){
                        var items = document.querySelectorAll('#adminmenu a');
                        for (var i=0;i<items.length;i++){
                            var a = items[i];
                            var t = (a.textContent||'').toLowerCase();
                            var h = (a.getAttribute('href')||'').toLowerCase();
                            var mt = texts.some(function(x){ return x && t.indexOf(x) !== -1; });
                            var mh = hrefParts.some(function(x){ return x && h.indexOf('page='+String(x).toLowerCase()) !== -1; });
                            if (mt || mh) {
                                var li = a.closest('li.menu-top, li.wp-has-submenu, li');
                                if (li && li.parentNode) li.parentNode.removeChild(li);
                            }
                        }
                    }
                    <?php if (in_array('tickets',$hidden_tabs,true)) : ?>
                        killBy(['instancia','instancias','ticket','tickets'], ['<?php echo esc_js($map['tickets'] ?? ''); ?>']);
                    <?php endif; ?>
                    <?php if (in_array('reportes',$hidden_tabs,true)) : ?>
                        killBy(['reporte','reportes','informe','informes','report','reports'], ['<?php echo esc_js($map['reportes'] ?? ''); ?>']);
                    <?php endif; ?>
                } catch(e){}
            })();
            </script>
            <?php
        });
    }
}
add_action('admin_menu',         'midas_rrhh_hide_submenus_for_user', 9999);
add_action('network_admin_menu', 'midas_rrhh_hide_submenus_for_user', 9999);

/* ============ Bloquear acceso directo por URL + redirección (con breaker) ============ */

if (!function_exists('midas_rrhh_block_direct_access_hidden_tabs')) {
    function midas_rrhh_block_direct_access_hidden_tabs() {
        if (defined('DOING_AJAX') && DOING_AJAX) return;
        if (!is_admin()) return;
        if (!is_user_logged_in()) return;

        $page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
        if ($page === '') return;

        $parent_slug = midas_rrhh_parent_menu_slug();
        $map         = midas_rrhh_tab_map();
        if (empty($map)) return;

        $hidden = midas_rrhh_get_user_hidden_tabs(get_current_user_id());

        // Si el menú ya existe podemos ajustar slugs para tickets/reportes
        if (did_action('admin_menu')) {
            $items = midas_rrhh_get_submenu_items($parent_slug);
            if (in_array('tickets', $hidden, true)) {
                $slug = midas_rrhh_find_submenu_slug_by_title($items, ['instancia','instancias','ticket','tickets']);
                if ($slug) $map['tickets'] = $slug;
            }
            if (in_array('reportes', $hidden, true)) {
                $slug = midas_rrhh_find_submenu_slug_by_title($items, ['reporte','reportes','informe','informes','report','reports']);
                if ($slug) $map['reportes'] = $slug;
            }
        }

        $all_slugs   = array_values($map);
        $visible_map = array_diff(array_keys($map), $hidden);

        // Primer slug visible (por orden del mapa)
        $first_visible_slug = '';
        foreach ($map as $k => $slug) {
            if (in_array($k, $visible_map, true) && !empty($slug)) { $first_visible_slug = $slug; break; }
        }

        $is_rrhh_page   = ($page === $parent_slug) || in_array($page, $all_slugs, true);
        $dashboard_key  = 'dashboard';
        $dashboard_slug = $map[$dashboard_key] ?? $parent_slug;
        $dashboard_hidden = in_array($dashboard_key, $hidden, true);

        if (!$is_rrhh_page) return;

        // Breaker anti-loop: si ya redirigimos una vez, no volvemos a redirigir.
        $already_redirected = isset($_GET['midas_rrhh_redir']);

        // 1) Si cae en el padre (dashboard container)
        if ($page === $parent_slug) {
            // Si el dashboard está oculto, o si el primer visible no es el padre, redirigimos.
            if (($dashboard_hidden || $first_visible_slug !== $parent_slug) && !empty($first_visible_slug) && $first_visible_slug !== $page) {
                if ($already_redirected) {
                    // Cortamos el loop con un 403 amable
                    wp_die(
                        esc_html__('No tienes permiso para acceder a esta sección.', 'midas-rrhh'),
                        esc_html__('Acceso denegado', 'midas-rrhh'),
                        ['response' => 403]
                    );
                }
                $dest = add_query_arg('midas_rrhh_redir', '1', admin_url('admin.php?page='.$first_visible_slug));
                wp_safe_redirect($dest);
                exit;
            }
            // Si llegamos aquí y el padre es visible, no redirigimos.
            return;
        }

        // 2) Si entra a una pestaña oculta, redirigir a la primera visible
        $slug_to_tab  = array_flip($map);
        $current_key  = $slug_to_tab[$page] ?? '';
        $current_is_hidden = $current_key && in_array($current_key, $hidden, true);

        if ($current_is_hidden) {
            if (!empty($first_visible_slug) && $first_visible_slug !== $page) {
                if ($already_redirected) {
                    wp_die(
                        esc_html__('No tienes permiso para acceder a esta sección.', 'midas-rrhh'),
                        esc_html__('Acceso denegado', 'midas-rrhh'),
                        ['response' => 403]
                    );
                }
                $dest = add_query_arg('midas_rrhh_redir', '1', admin_url('admin.php?page='.$first_visible_slug));
                wp_safe_redirect($dest);
                exit;
            }
            // Si no hay visible a donde ir, mostramos 403
            wp_die(
                esc_html__('No tienes permiso para acceder a esta sección.', 'midas-rrhh'),
                esc_html__('Acceso denegado', 'midas-rrhh'),
                ['response' => 403]
            );
        }
    }
}
add_action('admin_init', 'midas_rrhh_block_direct_access_hidden_tabs', 99);
