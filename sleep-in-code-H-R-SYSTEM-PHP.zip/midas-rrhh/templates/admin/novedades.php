<?php
/**
 * Admin > Novedades / Ampliaciones
 * Ruta: templates/admin/novedades-ampliaciones.php
 */
if (!defined('ABSPATH')) exit;

$ajax_url  = admin_url('admin-ajax.php');
$nov_nonce = wp_create_nonce('midas_nov_nonce');
?>
<div class="wrap midas-novedades-wrap" id="midasNovedadesWrap">
  <h1 style="display:flex;align-items:center;gap:10px;margin:14px 0;">
    <?php esc_html_e('Novedades / Ampliaciones', 'midas-rrhh'); ?>
    <span class="dashicons dashicons-megaphone" style="font-size:24px;line-height:1;"></span>
  </h1>

  <!-- Toolbar -->
  <div class="midas-nov-toolbar">
    <button type="button" class="button button-primary" id="nov-btn-new">
      <?php esc_html_e('Nueva novedad', 'midas-rrhh'); ?>
    </button>

    <span class="sep"></span>

    <input type="search" id="nov-search" class="regular-text" placeholder="<?php esc_attr_e('Buscar por título o contenido…','midas-rrhh');?>" />
    <select id="nov-filter-status">
      <option value=""><?php esc_html_e('Estado: todos','midas-rrhh'); ?></option>
      <option value="publish"><?php esc_html_e('Publicadas','midas-rrhh'); ?></option>
      <option value="draft"><?php esc_html_e('Borradores','midas-rrhh'); ?></option>
      <option value="closed"><?php esc_html_e('Cerradas','midas-rrhh'); ?></option>
    </select>
    <label style="display:inline-flex;gap:6px;align-items:center;">
      <input type="checkbox" id="nov-filter-visible" checked />
      <?php esc_html_e('Visible al cliente','midas-rrhh'); ?>
    </label>

    <button type="button" class="button" id="nov-btn-refresh">
      <?php esc_html_e('Actualizar','midas-rrhh'); ?>
    </button>

    <span id="nov-status" class="nov-status" aria-live="polite"></span>
  </div>

  <!-- Grid: listado + editor -->
  <div class="midas-nov-grid">
    <!-- LISTADO -->
    <div class="nov-list">
      <table class="widefat striped">
        <thead>
          <tr>
            <th style="width:80px;">ID</th>
            <th><?php esc_html_e('Título','midas-rrhh'); ?></th>
            <th style="width:120px;"><?php esc_html_e('Estado','midas-rrhh'); ?></th>
            <th style="width:90px;"><?php esc_html_e('Sticky','midas-rrhh'); ?></th>
            <th style="width:140px;"><?php esc_html_e('Visible cliente','midas-rrhh'); ?></th>
            <th style="width:160px;"><?php esc_html_e('Actualizado','midas-rrhh'); ?></th>
            <th style="width:160px;"><?php esc_html_e('Acciones','midas-rrhh'); ?></th>
          </tr>
        </thead>
        <tbody id="nov-tbody">
          <tr><td colspan="7"><?php esc_html_e('Cargando…','midas-rrhh'); ?></td></tr>
        </tbody>
      </table>

      <div class="tablenav bottom">
        <div class="tablenav-pages" id="nov-pagination"></div>
      </div>
    </div>

    <!-- EDITOR -->
    <div class="nov-editor" id="nov-editor">
      <div class="card">
        <h2 id="nov-editor-title"><?php esc_html_e('Nueva novedad','midas-rrhh'); ?></h2>

        <input type="hidden" id="nov-id" value="">

        <table class="form-table">
          <tr>
            <th><label for="nov-titulo"><?php esc_html_e('Título','midas-rrhh'); ?></label></th>
            <td><input type="text" id="nov-titulo" class="regular-text" placeholder="<?php esc_attr_e('Ej.: Lanzamiento portal clientes','midas-rrhh'); ?>"></td>
          </tr>
          <tr>
            <th><label for="nov-contenido"><?php esc_html_e('Contenido','midas-rrhh'); ?></label></th>
            <td><textarea id="nov-contenido" rows="8" class="large-text" placeholder="<?php esc_attr_e('Escribe la novedad…','midas-rrhh'); ?>"></textarea></td>
          </tr>
          <tr>
            <th><label for="nov-tags"><?php esc_html_e('Tags','midas-rrhh'); ?></label></th>
            <td><input type="text" id="nov-tags" class="regular-text" placeholder="<?php esc_attr_e('Ej.: portal, release, rrhh','midas-rrhh'); ?>"></td>
          </tr>
          <tr>
            <th><?php esc_html_e('Opciones','midas-rrhh'); ?></th>
            <td class="opt-row">
              <label><input type="checkbox" id="nov-sticky"> <?php esc_html_e('Fijar arriba (sticky)','midas-rrhh'); ?></label>
              <label><input type="checkbox" id="nov-visible" checked> <?php esc_html_e('Visible al cliente','midas-rrhh'); ?></label>
              <label style="display:inline-flex;gap:6px;align-items:center;">
                <?php esc_html_e('Estado:','midas-rrhh'); ?>
                <select id="nov-estado">
                  <option value="publish"><?php esc_html_e('Publicar','midas-rrhh'); ?></option>
                  <option value="draft"><?php esc_html_e('Borrador','midas-rrhh'); ?></option>
                  <option value="closed"><?php esc_html_e('Cerrado','midas-rrhh'); ?></option>
                </select>
              </label>
            </td>
          </tr>
        </table>

        <p class="submit">
          <button type="button" class="button button-primary" id="nov-btn-save"><?php esc_html_e('Guardar','midas-rrhh'); ?></button>
          <button type="button" class="button" id="nov-btn-cancel"><?php esc_html_e('Cancelar','midas-rrhh'); ?></button>
          <span id="nov-save-status" class="muted"></span>
        </p>
      </div>

      <!-- Respuestas -->
      <div class="card" id="nov-replies-card" style="display:none;">
        <h2><?php esc_html_e('Respuestas','midas-rrhh'); ?></h2>

        <div id="nov-replies-list" class="replies-list">
          <div class="muted"><?php esc_html_e('Sin respuestas aún.','midas-rrhh'); ?></div>
        </div>

        <div class="reply-new">
          <textarea id="nov-reply-new" rows="4" class="large-text" placeholder="<?php esc_attr_e('Escribe una respuesta…','midas-rrhh'); ?>"></textarea>
          <p class="submit">
            <button type="button" class="button button-primary" id="nov-btn-add-reply"><?php esc_html_e('Agregar respuesta','midas-rrhh'); ?></button>
            <span id="nov-reply-status" class="muted"></span>
          </p>
        </div>
      </div>
    </div>
  </div>
</div>

<style>
/* Toolbar */
.midas-nov-toolbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:12px}
.midas-nov-toolbar .sep{width:1px;height:24px;background:#d1d5db;margin:0 6px}
.midas-nov-toolbar .nov-status{margin-left:auto;font-weight:600;color:#475569}

/* ====== GRID ======
   Columna izquierda flexible (listado),
   derecha fija (editor) para que no estrangule la tabla */
.midas-nov-grid{
  display:grid;
  grid-template-columns: 1fr 420px;
  gap:16px;
  align-items:start;
}
.midas-nov-grid > .nov-list,
.midas-nov-grid > .nov-editor{min-width:0}

/* En pantallas angostas apilar */
@media (max-width:1100px){
  .midas-nov-grid{grid-template-columns:1fr}
}

/* Tabla: que calcule ancho natural y no “rompa” los encabezados */
.midas-novedades-wrap .widefat{table-layout:auto;width:100%}
.nov-list th, .nov-list td{white-space:nowrap}
.nov-list th:nth-child(2){white-space:normal} /* Título sí puede romperse */

/* Paginación */
.nov-list .tablenav.bottom{margin-top:8px}
#nov-pagination .page-numbers{display:inline-flex;gap:6px}
#nov-pagination .page-num{display:inline-block;padding:4px 8px;border:1px solid #ccd0d4;border-radius:4px;background:#fff;text-decoration:none}
#nov-pagination .page-num.active{background:#2271b1;color:#fff;border-color:#2271b1}

/* Editor */
.nov-editor .card{padding:12px;border:1px solid #d1d5db;border-radius:8px;background:#fff;margin-bottom:12px}
.nov-editor h2{margin:0 0 10px}
.opt-row{display:flex;flex-wrap:wrap;gap:12px;align-items:center}

/* Replies */
.muted{color:#6b7280}
.replies-list{display:flex;flex-direction:column;gap:10px;margin-top:8px}
.reply-item{border:1px solid #e5e7eb;border-radius:8px;padding:10px;background:#fff}
.reply-meta{font-size:12px;color:#6b7280;margin-bottom:6px;display:flex;justify-content:space-between}
.reply-actions{display:flex;gap:8px}

/* Badges */
.badge{display:inline-block;padding:2px 6px;border:1px solid #d1d5db;border-radius:999px;font-size:11px;background:#f9fafb}
.badge.ok{border-color:#22c55e;color:#16a34a;background:#f0fdf4}
.badge.warn{border-color:#f59e0b;color:#d97706;background:#fffbeb}
</style>

<script>
jQuery(function($){
  const AJAX = <?= wp_json_encode($ajax_url) ?>;
  const NONCE = <?= wp_json_encode($nov_nonce) ?>;

  let state = { page:1, per_page:10, status:'', visible:1, search:'', loading:false };
  const $status = $('#nov-status');
  const setStatus = (t)=> $status.text(t||'');

  /* ===== Listado ===== */
  function fetchList(){
    if (state.loading) return;
    state.loading = true;
    setStatus('<?php echo esc_js(__('Cargando…','midas-rrhh')); ?>');

    const data = {
      action: 'midas_nov_list_topics',
      page_num: state.page,
      per_page: state.per_page,
      cliente_visible: state.visible
    };
    if (state.status) data.estado = state.status;
    if (state.search) data.s = state.search;

    $.get(AJAX, data).done(res=>{
      if (!res || !res.success){ renderRows([],0); return; }
      renderRows(res.data.items || [], res.data.total || 0, res.data.page, res.data.per_page);
    }).fail(()=>{ renderRows([],0); })
      .always(()=>{ state.loading=false; setStatus(''); });
  }

  function renderRows(items, total, page=1, per_page=10){
    const $tb = $('#nov-tbody').empty();
    if (!items.length){
      $tb.append('<tr><td colspan="7"><?php echo esc_js(__('Sin resultados.','midas-rrhh')); ?></td></tr>');
      $('#nov-pagination').empty();
      return;
    }

    items.forEach(it=>{
      const badgeSticky = it.sticky ? '<span class="badge ok">Sticky</span>' : '';
      const badgeVisible = parseInt(it.cliente_visible) ? '<span class="badge ok"><?php echo esc_js(__('Sí','midas-rrhh')); ?></span>' : '<span class="badge warn"><?php echo esc_js(__('No','midas-rrhh')); ?></span>';
      const when = it.updated_at ? it.updated_at : it.created_at;

      const $tr = $(`
        <tr>
          <td>${it.id}</td>
          <td><strong>${escapeHtml(it.titulo||'')}</strong></td>
          <td>${escapeHtml(it.estado||'')}</td>
          <td>${badgeSticky}</td>
          <td>${badgeVisible}</td>
          <td>${when||''}</td>
          <td>
            <button class="button button-small nov-act-edit" data-id="${it.id}"><?php echo esc_js(__('Editar','midas-rrhh')); ?></button>
            <button class="button button-small nov-act-del" data-id="${it.id}"><?php echo esc_js(__('Eliminar','midas-rrhh')); ?></button>
          </td>
        </tr>
      `);
      $tb.append($tr);
    });

    renderPagination(total, page, per_page);
  }

  function renderPagination(total, page, per_page){
    const $pg = $('#nov-pagination').empty();
    const pages = Math.max(1, Math.ceil(total / per_page));
    if (pages <= 1) return;
    for (let i=1; i<=pages && i<=200; i++){
      const $a = $(`<a href="#" class="page-num ${i===page?'active':''}">${i}</a>`);
      $a.on('click', function(e){ e.preventDefault(); state.page=i; fetchList(); });
      $pg.append($a).append(' ');
    }
  }

  /* ===== Editor ===== */
  const $ed = $('#nov-editor');
  function resetEditor(){
    $('#nov-id').val('');
    $('#nov-titulo').val('');
    $('#nov-contenido').val('');
    $('#nov-tags').val('');
    $('#nov-sticky').prop('checked', false);
    $('#nov-visible').prop('checked', true);
    $('#nov-estado').val('publish');
    $('#nov-editor-title').text('<?php echo esc_js(__('Nueva novedad','midas-rrhh')); ?>');
    $('#nov-save-status').text('');
    $('#nov-replies-card').hide();
    $('#nov-replies-list').empty().append('<div class="muted"><?php echo esc_js(__('Sin respuestas aún.','midas-rrhh')); ?></div>');
    $('#nov-reply-new').val('');
    $('#nov-reply-status').text('');
  }

  function openEditor(topic){
    resetEditor();
    if (!topic){ $ed[0].scrollIntoView({behavior:'smooth', block:'start'}); return; }
    $('#nov-editor-title').text('<?php echo esc_js(__('Editar novedad','midas-rrhh')); ?>');
    $('#nov-id').val(topic.id);
    $('#nov-titulo').val(topic.titulo||'');
    $('#nov-contenido').val(topic.contenido||'');
    $('#nov-tags').val(topic.tags||'');
    $('#nov-sticky').prop('checked', parseInt(topic.sticky)===1);
    $('#nov-visible').prop('checked', parseInt(topic.cliente_visible)===1);
    $('#nov-estado').val(topic.estado||'publish');

    $('#nov-replies-card').show();
    renderReplies(topic.replies?.items || []);
    $ed[0].scrollIntoView({behavior:'smooth', block:'start'});
  }

  function saveTopic(){
    const id = parseInt($('#nov-id').val() || '0', 10);
    const payload = {
      titulo: $('#nov-titulo').val().trim(),
      contenido: $('#nov-contenido').val().trim(),
      tags: $('#nov-tags').val().trim(),
      sticky: $('#nov-sticky').is(':checked') ? 1 : 0,
      cliente_visible: $('#nov-visible').is(':checked') ? 1 : 0,
      estado: $('#nov-estado').val(),
      nonce: NONCE
    };
    if (!payload.titulo){
      $('#nov-save-status').text('<?php echo esc_js(__('El título es obligatorio.','midas-rrhh')); ?>');
      return;
    }
    $('#nov-btn-save').prop('disabled', true);
    $('#nov-save-status').text('<?php echo esc_js(__('Guardando…','midas-rrhh')); ?>');

    const action = id>0 ? 'midas_nov_update_topic' : 'midas_nov_create_topic';
    if (id>0) payload.id = id;

    $.post(AJAX, Object.assign({action}, payload)).done(res=>{
      if (!res || !res.success){
        $('#nov-save-status').text((res && res.data && res.data.message) || '<?php echo esc_js(__('Error al guardar','midas-rrhh')); ?>');
        return;
      }
      $('#nov-save-status').text('<?php echo esc_js(__('Guardado ✓','midas-rrhh')); ?>');
      state.page = 1;
      fetchList();
      if (action==='midas_nov_create_topic' && res.data && res.data.id){ loadTopic(res.data.id); }
    }).fail(()=>{ $('#nov-save-status').text('<?php echo esc_js(__('Error de red','midas-rrhh')); ?>'); })
      .always(()=>{ $('#nov-btn-save').prop('disabled', false); setTimeout(()=>$('#nov-save-status').text(''), 2000); });
  }

  function loadTopic(id){
    $.get(AJAX, {action:'midas_nov_get_topic', id}).done(res=>{
      if (res && res.success && res.data && res.data.topic){
        const topic = res.data.topic;
        topic.replies = res.data.replies || {items:[]};
        openEditor(topic);
      }
    });
  }

  function deleteTopic(id){
    if (!confirm('<?php echo esc_js(__('¿Eliminar esta novedad?','midas-rrhh')); ?>')) return;
    $.post(AJAX, {action:'midas_nov_delete_topic', id, nonce: NONCE}).done(res=>{
      if (!res || !res.success){
        alert((res && res.data && res.data.message) || '<?php echo esc_js(__('No se pudo eliminar','midas-rrhh')); ?>');
        return;
      }
      resetEditor();
      fetchList();
    }).fail(()=> alert('<?php echo esc_js(__('Error de red','midas-rrhh')); ?>'));
  }

  /* ===== Respuestas ===== */
  function renderReplies(items){
    const $list = $('#nov-replies-list').empty();
    if (!items || !items.length){
      $list.append('<div class="muted"><?php echo esc_js(__('Sin respuestas aún.','midas-rrhh')); ?></div>');
      return;
    }
    items.forEach(r=>{
      const metaLeft = `#${r.id} · ${r.created_at || ''}`;
      const $it = $(`
        <div class="reply-item" data-id="${r.id}">
          <div class="reply-meta">
            <span>${escapeHtml(metaLeft)}</span>
            <span class="reply-actions">
              <a href="#" class="reply-del"><?php echo esc_js(__('Eliminar','midas-rrhh')); ?></a>
            </span>
          </div>
          <div class="reply-body">${escapeHtml(r.contenido||'')}</div>
        </div>
      `);
      $list.append($it);
    });
  }

  function addReply(){
    const topicId = parseInt($('#nov-id').val()||'0',10);
    const body = $('#nov-reply-new').val().trim();
    if (topicId<=0) return;
    if (!body){ $('#nov-reply-status').text('<?php echo esc_js(__('Escribe una respuesta.','midas-rrhh')); ?>'); return; }

    $('#nov-btn-add-reply').prop('disabled', true);
    $('#nov-reply-status').text('<?php echo esc_js(__('Enviando…','midas-rrhh')); ?>');

    $.post(AJAX, {
      action: 'midas_nov_add_reply',
      topic_id: topicId,
      contenido: body,
      nonce: NONCE
    }).done(res=>{
      if (!res || !res.success){
        $('#nov-reply-status').text((res && res.data && res.data.message) || '<?php echo esc_js(__('No se pudo enviar','midas-rrhh')); ?>');
        return;
      }
      $('#nov-reply-new').val('');
      $('#nov-reply-status').text('<?php echo esc_js(__('Agregada ✓','midas-rrhh')); ?>');
      $.get(AJAX, {action:'midas_nov_list_replies', topic_id: topicId, page_num:1, per_page:50})
        .done(r2=>{ if (r2 && r2.success) renderReplies(r2.data.items || []); });
    }).fail(()=>{ $('#nov-reply-status').text('<?php echo esc_js(__('Error de red','midas-rrhh')); ?>'); })
      .always(()=>{ $('#nov-btn-add-reply').prop('disabled', false); setTimeout(()=>$('#nov-reply-status').text(''), 1800); });
  }

  $('#nov-replies-list').on('click', '.reply-del', function(e){
    e.preventDefault();
    const id = parseInt($(this).closest('.reply-item').data('id')||'0',10);
    if (!id) return;
    if (!confirm('<?php echo esc_js(__('¿Eliminar respuesta?','midas-rrhh')); ?>')) return;

    $.post(AJAX, {action:'midas_nov_delete_reply', id, nonce: NONCE}).done(res=>{
      if (!res || !res.success) { alert('<?php echo esc_js(__('No se pudo eliminar la respuesta','midas-rrhh')); ?>'); return; }
      $(e.target).closest('.reply-item').remove();
      if (!$('#nov-replies-list .reply-item').length){
        $('#nov-replies-list').append('<div class="muted"><?php echo esc_js(__('Sin respuestas aún.','midas-rrhh')); ?></div>');
      }
    }).fail(()=> alert('<?php echo esc_js(__('Error de red','midas-rrhh')); ?>'));
  });

  /* ===== Eventos UI ===== */
  $('#nov-btn-new').on('click', ()=> openEditor(null));
  $('#nov-btn-cancel').on('click', ()=> resetEditor());
  $('#nov-btn-save').on('click', ()=> saveTopic());
  $('#nov-btn-add-reply').on('click', ()=> addReply());
  $('#nov-btn-refresh').on('click', ()=>{ state.page=1; fetchList(); });

  $('#nov-search').on('keydown', function(e){ if (e.key==='Enter'){ state.search=this.value.trim(); state.page=1; fetchList(); }});
  $('#nov-filter-status').on('change', function(){ state.status=this.value; state.page=1; fetchList(); });
  $('#nov-filter-visible').on('change', function(){ state.visible = this.checked ? 1 : 0; state.page=1; fetchList(); });

  $('#nov-tbody').on('click', '.nov-act-edit', function(){
    const id = parseInt($(this).data('id')||'0',10);
    if (id>0) loadTopic(id);
  });
  $('#nov-tbody').on('click', '.nov-act-del', function(){
    const id = parseInt($(this).data('id')||'0',10);
    if (id>0) deleteTopic(id);
  });

  /* ===== Helpers ===== */
  function escapeHtml(s){
    if (s==null) return '';
    return String(s)
      .replaceAll('&','&amp;')
      .replaceAll('<','&lt;')
      .replaceAll('>','&gt;')
      .replaceAll('"','&quot;')
      .replaceAll("'",'&#039;');
  }

  // Init
  fetchList();
});
</script>
