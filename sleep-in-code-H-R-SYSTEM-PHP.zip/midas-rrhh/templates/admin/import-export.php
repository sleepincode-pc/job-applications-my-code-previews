<?php
if (!defined('ABSPATH')) exit;

$has_xlsx = class_exists('\PhpOffice\PhpSpreadsheet\IOFactory');

/* ===== Notificación resultado ===== */
$msg = isset($_GET['midas_msg']) ? sanitize_text_field($_GET['midas_msg']) : '';
$ok  = isset($_GET['ok']) ? intval($_GET['ok']) : 0;
$err = isset($_GET['err']) ? intval($_GET['err']) : 0;

$notice_class = '';
if ($msg) {
    if ($err > 0 && $ok > 0)       $notice_class = 'notice-warning';
    elseif ($err > 0 && $ok === 0) $notice_class = 'notice-error';
    else                           $notice_class = 'notice-success';
}

$accept  = '.csv' . ($has_xlsx ? ', .xlsx, .xls' : '');

/* ===== API (opcional) ===== */
$apiBase = rest_url('midas-rrhh/v1'); // termina en "/"
$keys    = get_option('midas_rrhh_api_keys', []);
if (!is_array($keys)) $keys = [];
$new_key  = isset($_GET['new_key'])   ? sanitize_text_field($_GET['new_key'])   : '';
$show_kid = isset($_GET['show_kid'])  ? sanitize_text_field($_GET['show_kid'])  : '';

/* ===== Placeholder de mapeo columnas (avanzado) ===== */
$default_mapping = <<<JSON
{
  "nombre":               ["nombre", "first_name", "Nombre"],
  "apellido":             ["apellido", "last_name", "Apellido"],
  "dni":                  ["dni", "documento", "DNI"],
  "cuil":                 ["cuil", "CUIL"],
  "email":                ["email", "correo", "Email"],
  "telefono":             ["telefono", "tel", "Phone"],
  "fecha_nacimiento":     ["fecha_nacimiento", "nacimiento", "dob", "fechaNac"],
  "direccion":            ["direccion", "address", "domicilio"],
  "estado_civil":         ["estado_civil", "civil"],
  "cv_id":                ["cv_id", "CV"],
  "fecha_inicio_laboral": ["fecha_inicio_laboral", "ingreso", "startDate"],
  "activo":               ["activo", "status", "estado", "enabled"]
}
JSON;
?>
<div class="wrap">
  <h1><?php esc_html_e('Importar / Exportar','midas-rrhh'); ?></h1>

  <?php if ($msg): ?>
    <div class="notice <?php echo esc_attr($notice_class); ?> is-dismissible">
      <p>
        <strong><?php echo esc_html($msg); ?></strong>
        <?php if ($ok || $err): ?>
          — <?php esc_html_e('Filas OK','midas-rrhh'); ?>: <?php echo intval($ok); ?>
          — <?php esc_html_e('Errores','midas-rrhh'); ?>: <?php echo intval($err); ?>
        <?php endif; ?>
      </p>
    </div>
  <?php endif; ?>

  <?php if ($new_key): ?>
    <div class="notice notice-success is-dismissible">
      <p><strong><?php esc_html_e('Tu nueva API Key (copiala ahora, se mostrará una sola vez aquí):','midas-rrhh'); ?></strong></p>
      <p><code style="font-size:14px;"><?php echo esc_html($new_key); ?></code></p>
    </div>
  <?php endif; ?>

  <?php if ($show_kid && isset($keys[$show_kid]['secret']) && empty($keys[$show_kid]['revoked'])): ?>
    <div class="notice notice-info is-dismissible">
      <p><strong><?php esc_html_e('Clave para la API seleccionada:','midas-rrhh'); ?></strong></p>
      <p><code style="font-size:14px;"><?php echo esc_html($keys[$show_kid]['secret']); ?></code></p>
    </div>
  <?php endif; ?>

  <!-- ==================== IMPORTADOR SIMPLE ==================== -->
  <div class="card midas-card" style="max-width:1000px;padding:16px 20px;margin-top:16px;">
    <h2><?php esc_html_e('Importar (simple)','midas-rrhh'); ?></h2>
    <p>
      <?php esc_html_e('Sube un archivo','midas-rrhh'); ?>
      <strong>CSV</strong> (<?php esc_html_e('recomendado; guarda tu Excel como CSV','midas-rrhh'); ?>)
      <?php if ($has_xlsx): ?>
        <?php esc_html_e('o un','midas-rrhh'); ?> <strong>XLSX</strong> (<?php esc_html_e('requiere PhpSpreadsheet','midas-rrhh'); ?>)
      <?php endif; ?>
      <?php esc_html_e('con la primera fila como encabezados.','midas-rrhh'); ?>
    </p>

    <form method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
      <input type="hidden" name="action" value="midas_ie_import">
      <?php wp_nonce_field('midas_ie_import'); ?>

      <table class="form-table" role="presentation">
        <tbody>
        <tr>
          <th scope="row"><label for="midas_ie_target"><?php esc_html_e('Destino','midas-rrhh'); ?></label></th>
          <td>
            <select id="midas_ie_target" name="target" required>
              <option value="empleados"><?php esc_html_e('Empleados','midas-rrhh'); ?></option>
              <option value="recibos"><?php esc_html_e('Recibos','midas-rrhh'); ?></option>
            </select>
            <p class="description">
              <?php esc_html_e('Las columnas deben coincidir con los campos del modelo.','midas-rrhh'); ?>
            </p>
          </td>
        </tr>
        <tr>
          <th scope="row"><label for="midas_ie_file"><?php esc_html_e('Archivo','midas-rrhh'); ?></label></th>
          <td>
            <input type="file" id="midas_ie_file" name="file" accept="<?php echo esc_attr($accept); ?>" required>
          </td>
        </tr>
        <tr>
          <th scope="row"><?php esc_html_e('Opciones','midas-rrhh'); ?></th>
          <td>
            <label><input type="checkbox" name="has_header" value="1" checked> <?php esc_html_e('La primera fila contiene encabezados','midas-rrhh'); ?></label><br>
            <label><input type="checkbox" name="dry_run" value="1"> <?php esc_html_e('Simular (no guarda, solo valida)','midas-rrhh'); ?></label>
          </td>
        </tr>
        </tbody>
      </table>
      <p>
        <button type="submit" class="button button-primary"><?php esc_html_e('Procesar importación','midas-rrhh'); ?></button>
      </p>
    </form>
  </div>

  <!-- ==================== IMPORTADOR AVANZADO ==================== -->
  <div class="card midas-card" style="max-width:1000px;padding:16px 20px;margin-top:16px;">
    <h2><?php esc_html_e('Importar (avanzado)','midas-rrhh'); ?></h2>
    <p class="description" style="margin-top:-6px">
      <?php esc_html_e('Para CSV exigentes o de otras plataformas. Permite ajustar delimitadores, comillas, codificación, decimales, fechas y mapear nombres de columnas.','midas-rrhh'); ?>
    </p>

    <form method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
      <input type="hidden" name="action" value="midas_ie_import_adv">
      <?php wp_nonce_field('midas_ie_import_adv'); ?>

      <table class="form-table" role="presentation">
        <tbody>
        <tr>
          <th scope="row"><label for="adv_target"><?php esc_html_e('Destino','midas-rrhh'); ?></label></th>
          <td>
            <select id="adv_target" name="adv_target" required>
              <option value="empleados"><?php esc_html_e('Empleados','midas-rrhh'); ?></option>
              <option value="recibos"><?php esc_html_e('Recibos','midas-rrhh'); ?></option>
            </select>
          </td>
        </tr>

        <tr>
          <th scope="row"><label for="adv_file"><?php esc_html_e('Archivo local','midas-rrhh'); ?></label></th>
          <td>
            <input type="file" id="adv_file" name="adv_file" accept="<?php echo esc_attr($accept); ?>">
            <p class="description"><?php esc_html_e('Opcionalmente podés pegar una URL directa al CSV (se prioriza el archivo si se sube).','midas-rrhh'); ?></p>
            <input type="url" id="adv_url" name="adv_url" placeholder="https://ejemplo.com/export.csv" style="min-width:320px;">
          </td>
        </tr>

        <tr>
          <th scope="row"><?php esc_html_e('Opciones de CSV (1/2)','midas-rrhh'); ?></th>
          <td>
            <div style="display:grid;grid-template-columns:280px 280px;gap:16px;align-items:center">
              <label><?php esc_html_e('Codificación','midas-rrhh'); ?>
                <select name="adv_encoding">
                  <option value="UTF-8" selected>UTF-8</option>
                  <option value="ISO-8859-1">ISO-8859-1</option>
                  <option value="Windows-1252">Windows-1252</option>
                </select>
              </label>

              <label><?php esc_html_e('Delimitador de campos','midas-rrhh'); ?>
                <select name="adv_delimiter">
                  <option value=",">, (coma)</option>
                  <option value=";">; (punto y coma)</option>
                  <option value="\t">\t (tab)</option>
                  <option value="|">| (pipe)</option>
                </select>
              </label>

              <label><?php esc_html_e('Carácter de comillas','midas-rrhh'); ?>
                <select name="adv_enclosure">
                  <option value='"'>" (doble comilla)</option>
                  <option value="'">' (comilla simple)</option>
                  <option value=""><?php esc_html_e('Sin comillas','midas-rrhh'); ?></option>
                </select>
              </label>

              <label><?php esc_html_e('Carácter de escape','midas-rrhh'); ?>
                <select name="adv_escape">
                  <option value="\" selected>\ (backslash)</option>
                  <option value=""><?php esc_html_e('Ninguno','midas-rrhh'); ?></option>
                </select>
              </label>
            </div>
          </td>
        </tr>

        <tr>
          <th scope="row"><?php esc_html_e('Opciones de CSV (2/2)','midas-rrhh'); ?></th>
          <td>
            <div style="display:grid;grid-template-columns:280px 280px;gap:16px;align-items:center">
              <label><?php esc_html_e('Separador decimal','midas-rrhh'); ?>
                <select name="adv_decimal">
                  <option value=".">. (punto)</option>
                  <option value=",">, (coma)</option>
                </select>
              </label>

              <label><?php esc_html_e('Formato de fecha por defecto','midas-rrhh'); ?>
                <input type="text" name="adv_date_format" value="Y-m-d" placeholder="Y-m-d" />
                <small class="description" style="display:block;margin-top:4px"><?php esc_html_e('Formato PHP: Y-m-d, d/m/Y, m/d/Y H:i, etc.','midas-rrhh'); ?></small>
              </label>

              <label><?php esc_html_e('Primera fila con encabezados','midas-rrhh'); ?>
                <select name="adv_has_header">
                  <option value="1" selected><?php esc_html_e('Sí','midas-rrhh'); ?></option>
                  <option value="0"><?php esc_html_e('No','midas-rrhh'); ?></option>
                </select>
              </label>

              <label><?php esc_html_e('Saltar primeras N filas (antes de los datos)','midas-rrhh'); ?>
                <input type="number" name="adv_skip_rows" min="0" value="0" />
              </label>

              <label><?php esc_html_e('Límite de filas (0 = sin límite)','midas-rrhh'); ?>
                <input type="number" name="adv_max_rows" min="0" value="0" />
              </label>

              <label><?php esc_html_e('Modo de importación','midas-rrhh'); ?>
                <select name="adv_mode">
                  <option value="insert" selected><?php esc_html_e('Solo insertar','midas-rrhh'); ?></option>
                  <option value="upsert"><?php esc_html_e('Insertar/Actualizar (upsert)','midas-rrhh'); ?></option>
                </select>
              </label>
            </div>
          </td>
        </tr>

        <tr>
          <th scope="row"><?php esc_html_e('Mapeo de columnas (JSON)','midas-rrhh'); ?></th>
          <td>
            <textarea name="adv_mapping" rows="12" style="width:100%;max-width:760px" placeholder='<?php echo esc_attr($default_mapping); ?>'></textarea>
            <p class="description">
              <?php esc_html_e('Podés especificar un objeto JSON donde cada clave es un campo del modelo y el valor es un string con la columna exacta o un array de posibles nombres (se usa el primero que exista).','midas-rrhh'); ?>
              <?php esc_html_e('Si se deja vacío, se intentará casar por nombre exacto del encabezado.','midas-rrhh'); ?>
            </p>
          </td>
        </tr>

        <tr>
          <th scope="row"><?php esc_html_e('Validación','midas-rrhh'); ?></th>
          <td>
            <label><input type="checkbox" name="adv_dry_run" value="1"> <?php esc_html_e('Simular (no guarda, solo valida)','midas-rrhh'); ?></label>
          </td>
        </tr>
        </tbody>
      </table>

      <p>
        <button type="submit" class="button button-primary"><?php esc_html_e('Procesar importación avanzada','midas-rrhh'); ?></button>
      </p>
    </form>
  </div>

  <!-- ==================== EXPORTAR ==================== -->
  <div class="card midas-card" style="max-width:1000px;padding:16px 20px;margin-top:16px;">
    <h2><?php esc_html_e('Exportar','midas-rrhh'); ?></h2>

    <iframe name="midas_export_iframe" style="display:none;width:0;height:0;border:0;"></iframe>

    <form method="post"
          action="<?php echo esc_url(admin_url('admin-post.php')); ?>"
          target="midas_export_iframe">
      <input type="hidden" name="action" value="midas_ie_export">
      <?php wp_nonce_field('midas_ie_export'); ?>

      <table class="form-table" role="presentation">
        <tbody>
        <tr>
          <th scope="row"><label for="midas_ee_target"><?php esc_html_e('Origen','midas-rrhh'); ?></label></th>
          <td>
            <select id="midas_ee_target" name="target" required>
              <option value="empleados"><?php esc_html_e('Empleados','midas-rrhh'); ?></option>
              <option value="recibos"><?php esc_html_e('Recibos','midas-rrhh'); ?></option>
            </select>
          </td>
        </tr>
        </tbody>
      </table>
      <p>
        <button type="submit" name="download" value="data" class="button button-primary">
          <?php esc_html_e('Descargar CSV','midas-rrhh'); ?>
        </button>
        <button type="submit" name="download" value="template" class="button">
          <?php esc_html_e('Descargar plantilla CSV','midas-rrhh'); ?>
        </button>
      </p>
    </form>
  </div>

  <!-- ==================== API / INTEGRACIONES (opcional) ==================== -->
  <div class="card midas-card" style="max-width:1000px;padding:16px 20px;margin-top:16px;">
    <h2><?php esc_html_e('API / Integraciones','midas-rrhh'); ?></h2>
    <p class="description">
      <?php esc_html_e('Usá estos endpoints para consumir datos desde otras webs o servicios. Autenticá cada request con el header','midas-rrhh'); ?>
      <code>X-Midas-Key</code>.
    </p>

    <table class="widefat striped" style="margin-top:10px;">
      <thead><tr><th><?php esc_html_e('Endpoint','midas-rrhh'); ?></th><th><?php esc_html_e('Ejemplo','midas-rrhh'); ?></th></tr></thead>
      <tbody>
        <tr>
          <td><code><?php echo esc_html($apiBase . 'employees'); ?></code></td>
          <td><code>curl -H "X-Midas-Key: TU_API_KEY" "<?php echo esc_html($apiBase . 'employees?per_page=20&page=1'); ?>"</code></td>
        </tr>
        <tr>
          <td><code><?php echo esc_html($apiBase . 'employees/{id}'); ?></code></td>
          <td><code>curl -H "X-Midas-Key: TU_API_KEY" "<?php echo esc_html($apiBase . 'employees/123'); ?>"</code></td>
        </tr>
        <tr>
          <td><code><?php echo esc_html($apiBase . 'recibos'); ?></code></td>
          <td><code>curl -H "X-Midas-Key: TU_API_KEY" "<?php echo esc_html($apiBase . 'recibos?empleado_id=123'); ?>"</code></td>
        </tr>
      </tbody>
    </table>

    <h3 style="margin-top:18px;"><?php esc_html_e('Claves de API','midas-rrhh'); ?></h3>

    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin:10px 0 16px;">
      <input type="hidden" name="action" value="midas_api_new_key">
      <?php wp_nonce_field('midas_api_new_key'); ?>
      <label>
        <?php esc_html_e('Etiqueta (opcional):','midas-rrhh'); ?>
        <input type="text" name="label" style="min-width:240px;">
      </label>
      <button type="submit" class="button button-primary"><?php esc_html_e('Crear nueva API Key','midas-rrhh'); ?></button>
    </form>

    <table class="widefat striped">
      <thead>
        <tr>
          <th><?php esc_html_e('Etiqueta','midas-rrhh'); ?></th>
          <th><?php esc_html_e('Creada','midas-rrhh'); ?></th>
          <th><?php esc_html_e('Último uso','midas-rrhh'); ?></th>
          <th><?php esc_html_e('Estado','midas-rrhh'); ?></th>
          <th style="width:260px;"><?php esc_html_e('Acción','midas-rrhh'); ?></th>
        </tr>
      </thead>
      <tbody>
        <?php if ($keys): foreach ($keys as $kid => $k): ?>
          <tr>
            <td><?php echo esc_html($k['label'] ?? 'API Key'); ?></td>
            <td><?php echo esc_html($k['created'] ?? '—'); ?></td>
            <td><?php echo esc_html($k['last_used'] ?? '—'); ?></td>
            <td><?php echo !empty($k['revoked']) ? 'Revocada' : 'Activa'; ?></td>
            <td>
              <?php if (empty($k['revoked'])): ?>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline-block;margin-right:6px;">
                  <input type="hidden" name="action" value="midas_api_show_key">
                  <input type="hidden" name="kid" value="<?php echo esc_attr($kid); ?>">
                  <?php wp_nonce_field('midas_api_show_key'); ?>
                  <button type="submit" class="button"><?php esc_html_e('Mostrar clave','midas-rrhh'); ?></button>
                </form>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline-block;">
                  <input type="hidden" name="action" value="midas_api_del_key">
                  <input type="hidden" name="kid" value="<?php echo esc_attr($kid); ?>">
                  <?php wp_nonce_field('midas_api_del_key'); ?>
                  <button type="submit" class="button"><?php esc_html_e('Revocar','midas-rrhh'); ?></button>
                </form>
              <?php else: ?>
                <span style="color:#777;">—</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; else: ?>
          <tr><td colspan="5"><?php esc_html_e('Aún no hay claves creadas.','midas-rrhh'); ?></td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <style>
    .midas-card h2{margin-top:0}
    .midas-card code{background:#f6f7f7;padding:2px 4px}
    .midas-card .description { color:#6b7280 }
    .midas-card select, .midas-card input[type="text"], .midas-card input[type="number"], .midas-card input[type="url"]{
      min-width: 180px;
    }
  </style>
</div>
