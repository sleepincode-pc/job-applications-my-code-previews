<?php
if (!defined('ABSPATH')) exit;

use MidasRRHH\Models\Empleado_Model;
use MidasRRHH\Controllers\Carpeta_Medica_Controller;

/**
 * ============================================================
 *  AJAX LIGERO: LISTADO PAGINADO + BÚSQUEDA POR PESTAÑA
 *  Devuelve SOLO <tbody> y metadatos de paginación.
 * ============================================================
 */

// Permisos de lectura (soporta varios roles/caps)
function midas_cm_can_read() : bool {
    if (!is_user_logged_in()) return false;
    return current_user_can('read_private_midas_carpeta_medica')
        || current_user_can('approve_midas_carpeta_medica')
        || current_user_can('rrhh_gestor')
        || current_user_can('rrhh_admin')
        || current_user_can('administrator')
        || current_user_can('manage_options');
}

add_action('wp_ajax_midas_cm_listar_docs', function () {
    // Evitar que notices rompan el JSON
    @ini_set('display_errors', 0);

    if (!midas_cm_can_read()) {
        wp_send_json_error(['message' => __('Permiso denegado', 'midas-rrhh')], 403);
    }

    // FIX: aceptar nonce en 'nonce' o 'midas_cm_nonce'
    $nonce = $_POST['nonce'] ?? $_POST['midas_cm_nonce'] ?? $_GET['nonce'] ?? $_GET['midas_cm_nonce'] ?? '';
    if (!$nonce || !wp_verify_nonce($nonce, 'midas_cm_nonce')) {
        wp_send_json_error(['message' => __('Nonce inválido.', 'midas-rrhh')], 403);
    }

    $estado    = sanitize_text_field($_POST['estado'] ?? 'pendientes'); // pendientes|aprobados|rechazados|historial
    $page      = max(1, intval($_POST['page'] ?? 1));
    $per_page  = min(50, max(5, intval($_POST['per_page'] ?? 10)));
    $q_raw     = wp_unslash($_POST['q'] ?? '');
    $q         = trim($q_raw);

    $ctl  = new Carpeta_Medica_Controller();
    $lista = [];

    switch ($estado) {
        case 'aprobados':  $lista = $ctl->obtener_documentos_aprobados();  break;
        case 'rechazados': $lista = $ctl->obtener_documentos_rechazados(); break;
        case 'historial':  $lista = $ctl->obtener_historial_documentos();  break;
        default:           $lista = $ctl->obtener_documentos_pendientes(); break;
    }

    if (is_wp_error($lista)) {
        wp_send_json_error(['message' => $lista->get_error_message()], 500);
    }
    if (!is_array($lista)) $lista = (array) $lista;

    // Normalizar URLs/fechas
    foreach ($lista as &$doc) {
        if (is_array($doc)) $doc = (object) $doc;
        if (!is_object($doc)) continue;

        if (empty($doc->documento_url) && !empty($doc->documento_id)) {
            $doc->documento_url = wp_get_attachment_url($doc->documento_id);
        }
        if (empty($doc->fecha_emision_formateada) && !empty($doc->fecha_emision)) {
            $ts = strtotime($doc->fecha_emision);
            if ($ts) $doc->fecha_emision_formateada = date_i18n('d/m/Y', $ts);
        }
    }
    unset($doc);

    // Búsqueda server-side
    if ($q !== '') {
        $q_l = function_exists('mb_strtolower') ? mb_strtolower($q, 'UTF-8') : strtolower($q);
        $lista = array_values(array_filter($lista, function ($d) use ($q_l) {
            if (is_array($d)) $d = (object) $d;

            // Texto indexable con fallback de varios campos de observación
            $obs = '';
            foreach (['observaciones','obs_gestion','observaciones_estado','motivo_rechazo','respuesta'] as $k) {
                if (isset($d->$k) && $d->$k !== '') { $obs = (string) $d->$k; break; }
            }

            $txt = (($d->empleado_nombre ?? '') . ' ' .
                    ($d->motivo_descripcion ?? '') . ' ' .
                    $obs . ' ' .
                    ($d->estado_descripcion ?? '') . ' ' .
                    ($d->fecha_emision_formateada ?? '') . ' ' .
                    ($d->fecha_emision ?? ''));
            $hay = function_exists('mb_strtolower') ? mb_strtolower($txt, 'UTF-8') : strtolower($txt);
            return strpos($hay, $q_l) !== false;
        }));
    }

    // Orden por fecha desc
    usort($lista, function ($a, $b) {
        if (is_array($a)) $a = (object) $a;
        if (is_array($b)) $b = (object) $b;
        $ta = !empty($a->fecha_emision) ? strtotime($a->fecha_emision) : 0;
        $tb = !empty($b->fecha_emision) ? strtotime($b->fecha_emision) : 0;
        return $tb <=> $ta;
    });

    // Paginación
    $total       = count($lista);
    $total_pages = max(1, (int) ceil($total / $per_page));
    $offset      = ($page - 1) * $per_page;
    $slice       = array_slice($lista, $offset, $per_page);

    // Render de filas
    ob_start();
    if (!empty($slice)) {
        foreach ($slice as $doc) {
            if (is_array($doc)) $doc = (object) $doc;

            // ✅ Fallback robusto para ID (evita data-id vacío)
            $row_id = (int)($doc->id ?? $doc->documento_medico_id ?? $doc->doc_id ?? 0);

            // Fallback de observaciones para mostrar lo que haya guardado el backend
            $obs_val = '-';
            foreach (['observaciones','obs_gestion','observaciones_estado','motivo_rechazo','respuesta'] as $k) {
                if (isset($doc->$k) && $doc->$k !== '') { $obs_val = (string) $doc->$k; break; }
            }

            $doc_js = wp_json_encode([
                'id'                 => $row_id,
                'empleado_id'        => $doc->empleado_id ?? '',
                'medico_id'          => $doc->medico_id ?? '',
                'motivo_id'          => $doc->motivo_id ?? '',
                'fecha_emision'      => $doc->fecha_emision ?? '',
                'dias_solicitados'   => $doc->dias_solicitados ?? '',
                'observaciones'      => $obs_val,
                'estado_descripcion' => $doc->estado_descripcion ?? '',
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

            $empleado = esc_html($doc->empleado_nombre ?? '-');
            $motivo   = esc_html($doc->motivo_descripcion ?? '-');
            $fecha    = esc_html($doc->fecha_emision_formateada ?? ($doc->fecha_emision ?? '-'));
            $dias     = esc_html($doc->dias_solicitados ?? '-');

            $obs   = esc_html($obs_val);
            $obs_t = esc_attr($obs_val);

            $archivo  = !empty($doc->documento_url)
                ? '<a class="button" target="_blank" href="'.esc_url($doc->documento_url).'">'.esc_html__('Ver archivo','midas-rrhh').'</a>'
                : '<em>-</em>';

            $estado_td = ($estado === 'historial') ? '<td>'.esc_html($doc->estado_descripcion ?? '-').'</td>' : '';

            echo '<tr data-id="'.esc_attr($row_id).'">';
            echo '<td>'.$empleado.'</td>';
            echo '<td>'.$motivo.'</td>';
            echo '<td>'.$fecha.'</td>';
            echo '<td>'.$dias.'</td>';
            echo '<td title="'.$obs_t.'">'.$obs.'</td>';
            echo '<td>'.$archivo.'</td>';
            echo '<td class="col-acciones">
                    <div class="acciones-doc-grid">
                      <a href="#" class="button editar-doc" data-doc="'.esc_attr($doc_js).'">'.esc_html__('Editar','midas-rrhh').'</a>
                      <a href="#" class="button eliminar-doc" data-id="'.esc_attr($row_id).'">'.esc_html__('Eliminar','midas-rrhh').'</a>';
            $est_l = strtolower($doc->estado_descripcion ?? 'pendiente');
            if ($est_l === 'pendiente' || $est_l === '') {
                echo '<a href="#" class="button aprobar-doc" data-id="'.esc_attr($row_id).'">'.esc_html__('Aprobar','midas-rrhh').'</a>
                      <a href="#" class="button rechazar-doc" data-id="'.esc_attr($row_id).'">'.esc_html__('Rechazar','midas-rrhh').'</a>';
            }
            echo   '</div>
                  </td>';
            echo $estado_td;
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="'.($estado==='historial' ? 8 : 7).'"><em>'.esc_html__('Sin datos','midas-rrhh').'</em></td></tr>';
    }
    $tbody_html = (string) ob_get_clean();

    wp_send_json_success([
        'tbody'       => $tbody_html,
        'page'        => (int) $page,
        'per_page'    => (int) $per_page,
        'total'       => (int) $total,
        'total_pages' => (int) $total_pages,
        'estado'      => (string) $estado,
    ]);
});

/* =======================
 *   PINTAR LA PÁGINA
 * ======================= */

$empleado_model = new Empleado_Model();
$empleados      = $empleado_model->obtener_empleados_con_area_y_tarea();

global $wpdb;
$motivos = $wpdb->get_results("SELECT id, descripcion FROM {$wpdb->prefix}midas_motivos_carpeta_medica ORDER BY id ASC");
$medicos = $wpdb->get_results("SELECT id, nombre, apellido FROM {$wpdb->prefix}midas_medicos ORDER BY nombre ASC");

$nonce_list = wp_create_nonce('midas_cm_nonce');
?>
<?php if (!isset($GLOBALS['ajaxurl'])): ?>
<script>var ajaxurl="<?= esc_js(admin_url('admin-ajax.php')) ?>";</script>
<?php endif; ?>

<div class="wrap midas-carpeta-medica">
  <h1 style="margin-bottom:25px;"><?php esc_html_e('Gestión de Documentos Médicos','midas-rrhh'); ?></h1>

  <div style="margin-bottom:20px;">
    <input id="buscador-docs" type="text"
           placeholder="<?php esc_attr_e('Buscar en la pestaña activa…','midas-rrhh'); ?>"
           style="width:400px;padding:8px;font-size:14px;border:1px solid #ccc;border-radius:4px;display:block;margin-bottom:10px;"
           maxlength="120"
           pattern="^[A-ZÁÉÍÓÚÑ0-9 .,:;¡!¿?\(\)\-_/#+%]*$" autocomplete="off">
    <button id="abrir-modal-doc" class="button button-primary">➕ <?php esc_html_e('Agregar documento','midas-rrhh'); ?></button>
  </div>

  <!-- MODAL CREAR/EDITAR -->
  <div id="modal-doc" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;">
    <div style="background:#fff;padding:20px;border-radius:6px;max-width:800px;margin:60px auto;position:relative;">
      <span id="cerrar-modal-doc" style="position:absolute;top:10px;right:15px;font-size:20px;cursor:pointer;">&times;</span>
      <h2 style="font-size:20px;margin-top:0;border-bottom:1px solid #ccc;padding-bottom:5px;"><?php esc_html_e('Documento Médico','midas-rrhh'); ?></h2>

      <form id="form-nuevo-doc" enctype="multipart/form-data" autocomplete="off">
        <?php wp_nonce_field('midas_empleados_nonce','midas_empleados_nonce'); ?>
        <input type="hidden" name="documento_id" value="">
        <div style="display:flex;flex-wrap:wrap;gap:15px;">
          <label style="flex:1 1 300px;">
            <strong><?php esc_html_e('Empleado:','midas-rrhh'); ?></strong><br>
            <select name="empleado_id" required style="width:100%;padding:6px;">
              <option value=""><?php esc_html_e('Seleccionar empleado','midas-rrhh'); ?></option>
              <?php foreach ($empleados as $emp): ?>
                <option value="<?= esc_attr($emp->id) ?>"><?= esc_html("{$emp->nombre} {$emp->apellido} - {$emp->dni}") ?></option>
              <?php endforeach; ?>
            </select>
          </label>

          <label style="flex:1 1 200px;">
            <strong><?php esc_html_e('Médico:','midas-rrhh'); ?></strong><br>
            <select name="medico_id" required style="width:100%;padding:6px;">
              <option value=""><?php esc_html_e('Seleccionar médico','midas-rrhh'); ?></option>
              <?php foreach ($medicos as $med): ?>
                <option value="<?= esc_attr($med->id) ?>"><?= esc_html("{$med->nombre} {$med->apellido}") ?></option>
              <?php endforeach; ?>
            </select>
          </label>

          <label style="flex:1 1 200px;">
            <strong><?php esc_html_e('Motivo:','midas-rrhh'); ?></strong><br>
            <select name="motivo_id" required style="width:100%;padding:6px;">
              <option value=""><?php esc_html_e('Seleccionar motivo','midas-rrhh'); ?></option>
              <?php foreach ($motivos as $mot): ?>
                <option value="<?= esc_attr($mot->id) ?>"><?= esc_html($mot->descripcion) ?></option>
              <?php endforeach; ?>
            </select>
          </label>

          <label style="flex:1 1 150px;">
            <strong><?php esc_html_e('Emisión:','midas-rrhh'); ?></strong><br>
            <input type="date" name="fecha_emision" required style="width:100%;padding:6px;">
          </label>

          <label style="flex:1 1 150px;">
            <strong><?php esc_html_e('Días solicitados:','midas-rrhh'); ?></strong><br>
            <input type="number" name="dias_solicitados" min="1" required style="width:100%;padding:6px;">
          </label>

          <label style="flex:1 1 300px;">
            <strong><?php esc_html_e('Observaciones:','midas-rrhh'); ?></strong><br>
            <input type="text" name="observaciones" id="observaciones-doc"
                   style="width:100%;padding:6px;" maxlength="2000"
                   pattern="^[A-ZÁÉÍÓÚÑ0-9 .,:;¡!¿?\(\)\-_/#+%]*$" autocomplete="off">
          </label>

          <label style="flex:1 1 300px;">
            <strong><?php esc_html_e('Archivo:','midas-rrhh'); ?></strong><br>
            <input type="file" name="documento" id="archivo-doc" accept="application/pdf,image/*" required>
            <small><?php esc_html_e('PDF / Imagen (máx. 5 MB)','midas-rrhh'); ?></small>
          </label>
        </div>

        <div style="margin-top:20px;">
          <button type="submit" class="button button-primary" style="width:100%;padding:10px;font-size:16px;"><?php esc_html_e('Guardar Documento','midas-rrhh'); ?></button>
        </div>
      </form>
    </div>
  </div>

  <h2 class="nav-tab-wrapper" style="margin-bottom:20px;">
    <a href="#pendientes" class="nav-tab nav-tab-active"><?php esc_html_e('Pendientes','midas-rrhh'); ?></a>
    <a href="#aprobados"  class="nav-tab"><?php esc_html_e('Aprobados','midas-rrhh'); ?></a>
    <a href="#rechazados" class="nav-tab"><?php esc_html_e('Rechazados','midas-rrhh'); ?></a>
    <a href="#historial"  class="nav-tab"><?php esc_html_e('Historial','midas-rrhh'); ?></a>
  </h2>

  <div id="contenedor-tablas-docs">
    <?php
    function render_tabla_docs($id){
      echo "<div id=\"$id\" class=\"midas-tab-content\" style=\"display:" . ($id==='pendientes'?'block':'none') . ";margin-bottom:40px;\">
        <table class=\"wp-list-table widefat fixed striped\" id=\"tabla-docs-$id\">
          <thead>
            <tr>
              <th>".esc_html__('Empleado','midas-rrhh')."</th>
              <th>".esc_html__('Motivo','midas-rrhh')."</th>
              <th>".esc_html__('Emisión','midas-rrhh')."</th>
              <th>".esc_html__('Días','midas-rrhh')."</th>
              <th>".esc_html__('Observaciones','midas-rrhh')."</th>
              <th>".esc_html__('Archivo','midas-rrhh')."</th>
              <th>".esc_html__('Acciones','midas-rrhh')."</th>";
      if ($id==='historial') echo "<th>".esc_html__('Estado','midas-rrhh')."</th>";
      echo "</tr></thead><tbody>
              <tr><td colspan=\"".($id==='historial' ? 8 : 7)."\"><em>".esc_html__('Cargando…','midas-rrhh')."</em></td></tr>
            </tbody>
        </table>
        <div class=\"paginacion\" data-tab=\"$id\" style=\"margin-top:10px;text-align:right;\"></div>
      </div>";
    }
    render_tabla_docs('pendientes');
    render_tabla_docs('aprobados');
    render_tabla_docs('rechazados');
    render_tabla_docs('historial');
    ?>
  </div>
</div>

<style>
.midas-carpeta-medica .midas-tab-content{ overflow-x:auto; }
.midas-carpeta-medica .wp-list-table{ min-width:780px; }
#modal-doc > div{ width:min(92vw,800px)!important; margin:40px auto!important; }
#buscador-docs{ width:min(100%,520px)!important; box-sizing:border-box; }
.midas-carpeta-medica .paginacion{ display:flex; flex-wrap:wrap; gap:6px; justify-content:flex-end; }
.midas-carpeta-medica .paginacion .button{ padding:.42rem .7rem; }

/* === Acciones centradas + mismo tamaño === */
.midas-carpeta-medica td.col-acciones{ min-width:260px; text-align:center; }
.midas-carpeta-medica .acciones-doc-grid{
  display:grid;
  /* Todas las columnas del mismo ancho, centradas */
  grid-template-columns: repeat(auto-fit, 115px);
  gap:8px 10px;
  justify-content:center;   /* centra el bloque completo dentro de la celda */
  align-items:center;
}
.midas-carpeta-medica .acciones-doc-grid .button{
  /* cada botón ocupa exactamente el ancho del track */
  width:115px;
  display:inline-flex;
  align-items:center;
  justify-content:center;
  text-align:center;
}

.midas-carpeta-medica .button.eliminar-doc{color:#e53935;}
.midas-carpeta-medica .button.aprobar-doc{color:#2e7d32;}
.midas-carpeta-medica .button.rechazar-doc{color:#ff9100;}

/* En móviles: una columna y ancho completo */
@media (max-width:560px){
  .midas-carpeta-medica .acciones-doc-grid{
    grid-template-columns:1fr;
    justify-content:stretch;
  }
  .midas-carpeta-medica .acciones-doc-grid .button{ width:100%; }
}

@media (max-width:1024px){ .midas-carpeta-medica .wp-list-table{ min-width:720px; } }
</style>

<script>
/* Guard de inicialización para evitar dobles cargas del script */
(function(){
  if (window.MidasRRHH_CM && window.MidasRRHH_CM._initDone) return;
  window.MidasRRHH_CM = window.MidasRRHH_CM || {};
  window.MidasRRHH_CM._initDone = true;

  document.addEventListener('DOMContentLoaded', () => {
    /* ===== Config AJAX ligera ===== */
    const CFG = {
      ajax: (window.midas_rrhh && midas_rrhh.ajax_url) || (typeof ajaxurl!=='undefined'?ajaxurl:''),
      nonce: "<?= esc_js($nonce_list) ?>",
      perPage: 10,
      state: { pendientes:{page:1,q:''}, aprobados:{page:1,q:''}, rechazados:{page:1,q:''}, historial:{page:1,q:''} },
      aborters: {}
    };

    /* ===== Elementos de UI (declarados UNA sola vez) ===== */
    const obsInput  = document.getElementById('observaciones-doc');
    const buscador  = document.getElementById('buscador-docs');
    const modal     = document.getElementById('modal-doc');
    const docForm   = document.getElementById('form-nuevo-doc');
    const inputFile = document.getElementById('archivo-doc');

    /* ===== Utils compat de payload ===== */
    function normalizePayload(resp){
      const d = resp && resp.data !== undefined ? resp.data : resp;
      if (typeof d === 'string') {
        return { tbody: d, page: 1, total_pages: 1, per_page: CFG.perPage, total: 0, estado: '' };
      }
      return {
        tbody: (d && typeof d.tbody === 'string') ? d.tbody : '<tr><td colspan="7"><em>Sin datos</em></td></tr>',
        page: Number(d && d.page) || 1,
        total_pages: Number(d && d.total_pages) || 1,
        per_page: Number(d && d.per_page) || CFG.perPage,
        total: Number(d && d.total) || 0,
        estado: (d && d.estado) || ''
      };
    }

    /* ===== Sanitizado ===== */
    const ZERO_WIDTH=/[\u200B-\u200D\uFEFF]/g, SPACE_LIKE=/[\u00A0\u1680\u2000-\u200A\u202F\u205F\u3000]/g;
    function normalizeNFKC(s){try{return (s||'').normalize('NFKC')}catch(_){return (s||'')}}
    function normalizeSpaces(s){return String(s||'').replace(SPACE_LIKE,' ')}
    const RE_ALLOWED=/[^A-ZÁÉÍÓÚÑ0-9 .,:;¡!¿?\(\)\-_/#+%]/g;
    function sanitizeUpper(v,max){v=normalizeNFKC(normalizeSpaces(String(v||'').replace(ZERO_WIDTH,''))).toUpperCase().replace(RE_ALLOWED,'').replace(/\s+/g,' ').trim(); if(max&&v.length>max)v=v.slice(0,max); return v;}
    function sanitizeUpperLive(v,max){v=normalizeNFKC(normalizeSpaces(String(v||'').replace(ZERO_WIDTH,''))).toUpperCase().replace(RE_ALLOWED,''); if(max&&v.length>max)v=v.slice(0,max); return v;}

    if(obsInput){
      const max=parseInt(obsInput.getAttribute('maxlength')||'0',10)||null;
      obsInput.addEventListener('input',()=>{ obsInput.value=sanitizeUpperLive(obsInput.value,max); });
      obsInput.addEventListener('blur',()=>{ obsInput.value=sanitizeUpper(obsInput.value,max); });
    }
    if(buscador){
      const max=parseInt(buscador.getAttribute('maxlength')||'0',10)||null;
      buscador.addEventListener('input',()=>{ buscador.value=sanitizeUpper(buscador.value,max); triggerSearch(); });
    }

    /* ===== Mensajes ===== */
    const toast=(msg,bg)=>{document.querySelectorAll('.midas-rrhh-aviso').forEach(n=>n.remove());const d=document.createElement('div');Object.assign(d.style,{position:'fixed',top:'30px',right:'30px',zIndex:9999,padding:'14px 24px',borderRadius:'8px',background:bg,color:'#fff',boxShadow:'0 6px 18px #0002',opacity:0,transition:'opacity .2s'});d.className='midas-rrhh-aviso';d.textContent=msg;document.body.appendChild(d);setTimeout(()=>d.style.opacity=1,10);setTimeout(()=>{d.style.opacity=0;setTimeout(()=>d.remove(),350)},2400);};
    window.showSuccess=m=>toast(m,'#27ae60'); window.showError=m=>toast(m,'#c0392b');

    /* ===== Render paginación (tolerante) ===== */
    function renderPagination(holder, estado, page, totalPages){
      holder.innerHTML=''; totalPages = Number(totalPages) || 1;
      if(totalPages<=1) return;
      const mk=(txt,cls,disabled,go)=>{const b=document.createElement('button'); b.textContent=txt; b.className='button'+(cls?(' '+cls):''); if(disabled){b.disabled=true;} b.addEventListener('click',()=>loadTab(estado,go)); holder.appendChild(b);};
      mk('<?= esc_js(__('Anterior','midas-rrhh')); ?>','',page===1,page-1);
      for(let i=1;i<=totalPages;i++){ mk(String(i), i===page?'button-primary':'', false, i); }
      mk('<?= esc_js(__('Siguiente','midas-rrhh')); ?>','',page===totalPages,page+1);
    }

    /* ===== Cargar pestaña (AJAX) ===== */
    function loadTab(estado, page){
      const table=document.getElementById('tabla-docs-'+estado); if(!table) return;
      const tbody=table.querySelector('tbody');
      const pag=document.querySelector('.paginacion[data-tab="'+estado+'"]');
      const st=CFG.state[estado] || (CFG.state[estado]={page:1,q:''});
      if(typeof page==='number') st.page=page;

      // Abort si hay petición en curso
      if(CFG.aborters[estado]) CFG.aborters[estado].abort();
      const ctrl=new AbortController(); CFG.aborters[estado]=ctrl;

      tbody.innerHTML='<tr><td colspan="'+(estado==='historial'?8:7)+'"><em><?= esc_js(__('Cargando…','midas-rrhh')); ?></em></td></tr>';
      if(pag) pag.innerHTML='';

      const body=new URLSearchParams({ action:'midas_cm_listar_docs', nonce:CFG.nonce, estado, page:String(st.page||1), per_page:String(CFG.perPage), q:st.q||'' });

      fetch(CFG.ajax,{method:'POST',body,credentials:'same-origin',signal:ctrl.signal,headers:{'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}})
        .then(r=>r.json())
        .then(resp=>{
          if(!resp || resp.success!==true) throw new Error((resp && (resp.message||resp.data&&resp.data.message)) || 'Error');
          const data = normalizePayload(resp);
          tbody.innerHTML = data.tbody;
          if(pag) renderPagination(pag, estado, data.page, data.total_pages);
        })
        .catch(err=>{
          if(err.name==='AbortError') return;
          tbody.innerHTML='<tr><td colspan="'+(estado==='historial'?8:7)+'">Error</td></tr>';
          if(pag) pag.innerHTML='';
          console.error('[midas_cm_listar_docs]', err);
        })
        .finally(()=>{ CFG.aborters[estado]=null; });
    }

    /* ===== Búsqueda con debounce ===== */
    let searchTimer=null;
    function triggerSearch(){
      clearTimeout(searchTimer);
      searchTimer=setTimeout(()=>{
        const estadoActivo = document.querySelector('.nav-tab.nav-tab-active')?.getAttribute('href')?.substring(1) || 'pendientes';
        CFG.state[estadoActivo].q = (buscador?.value || '').trim();
        CFG.state[estadoActivo].page = 1;
        loadTab(estadoActivo, 1);
      }, 260);
    }

    /* ===== Tabs ===== */
    document.querySelectorAll('.nav-tab').forEach(tab=>{
      tab.addEventListener('click',e=>{
        e.preventDefault();
        document.querySelectorAll('.nav-tab').forEach(t=>t.classList.remove('nav-tab-active'));
        document.querySelectorAll('.midas-tab-content').forEach(c=>c.style.display='none');
        tab.classList.add('nav-tab-active');
        const id=tab.getAttribute('href').substring(1);
        document.getElementById(id).style.display='block';
        loadTab(id, CFG.state[id]?.page || 1);
      });
    });

    /* ===== Carga inicial ===== */
    ['pendientes','aprobados','rechazados','historial'].forEach(estado=> loadTab(estado, 1));

    /* ===== Modal CRUD ===== */
    document.getElementById('abrir-modal-doc').onclick=()=>{ docForm.reset(); docForm.documento_id.value=''; docForm.querySelector('input[name="documento"]').required=true; modal.style.display='block'; };
    document.getElementById('cerrar-modal-doc').onclick=()=> modal.style.display='none';
    modal.addEventListener('click',e=>{ if(e.target===modal) modal.style.display='none'; });

    /* ===== Validación + PRECOMPRESIÓN DE IMÁGENES ===== */
    const MAX_MB=5, EXT=['pdf','jpg','jpeg','png','gif','webp'], MIME=['application/pdf','image/jpeg','image/png','image/gif','image/webp'];

    async function compressImageFile(file, {maxW=1600,maxH=1600,quality=0.82,mime='image/webp'}={}){
      const img=await new Promise((res,rej)=>{ const i=new Image(); i.onload=()=>res(i); i.onerror=rej; i.src=URL.createObjectURL(file); });
      const ratio=Math.min(maxW/img.width, maxH/img.height, 1);
      const cw=Math.round(img.width*ratio), ch=Math.round(img.height*ratio);
      const canvas=document.createElement('canvas'); canvas.width=cw; canvas.height=ch;
      canvas.getContext('2d').drawImage(img,0,0,cw,ch);
      let q=quality, blob=await new Promise(r=>canvas.toBlob(r, mime, q));
      for(let i=0;i<3 && blob && blob.size>900*1024; i++){ q=Math.max(0.5, q-0.12); blob=await new Promise(r=>canvas.toBlob(r, mime, q)); }
      if(blob && blob.size>=file.size){ blob=await new Promise(r=>canvas.toBlob(r, 'image/jpeg', 0.82)); }
      const ext = blob.type==='image/jpeg' ? 'jpg' : 'webp';
      return new File([blob], (file.name.replace(/\.[^.]+$/,'')||'imagen')+'.'+ext, {type:blob.type,lastModified:Date.now()});
    }

    inputFile?.addEventListener('change',async function(){
      const f=this.files && this.files[0] ? this.files[0] : null; if(!f) return;
      const ext=(f.name.split('.').pop()||'').toLowerCase();
      if(!EXT.includes(ext)){ alert('<?= esc_js(__('Formato no permitido. Usá PDF/JPG/PNG/GIF/WebP.','midas-rrhh')); ?>'); this.value=''; return; }
      if(f.type && !MIME.includes(f.type) && ext!=='pdf'){ alert('<?= esc_js(__('Archivo inválido.','midas-rrhh')); ?>'); this.value=''; return; }
      if(f.type.startsWith('image/')){
        try{ const compressed = await compressImageFile(f); const dt=new DataTransfer(); dt.items.add(compressed); this.files=dt.files; }catch(_){}
      }
      if(this.files[0].size > MAX_MB*1024*1024){ alert('<?= esc_js(__('El archivo supera 5MB tras comprimir.','midas-rrhh')); ?>'); this.value=''; }
    });

    /* ===== Modal Observaciones (aprob/rechazo) ===== */
    const modalObs=document.createElement('div');
    modalObs.id='modal-obs-doc';
    modalObs.style.cssText='display:none;position:fixed;inset:0;background:rgba(0,0,0,.33);z-index:99999;';
    modalObs.innerHTML=`
      <div style="background:#fff;border-radius:9px;box-shadow:0 8px 32px #0002;padding:24px 24px 18px;max-width:380px;margin:100px auto 0;position:relative;">
        <button id="cerrar-modal-obs-doc" style="position:absolute;top:8px;right:14px;font-size:19px;border:none;background:transparent;cursor:pointer;">&times;</button>
        <h3 id="titulo-modal-obs-doc" style="margin:0 0 7px;font-size:16px;font-weight:700;">Observaciones</h3>
        <textarea id="obs-textarea-doc" rows="4" style="width:100%;border-radius:7px;border:1px solid #e0e0e0;padding:9px;resize:none;font-size:14px;margin-bottom:10px;" maxlength="2000" placeholder="ESCRIBE AQUÍ"></textarea>
        <button id="enviar-modal-obs-doc" class="button button-primary" style="width:100%;font-size:15px;">Confirmar</button>
      </div>`;
    document.body.appendChild(modalObs);
    const obsArea=document.getElementById('obs-textarea-doc');
    if(obsArea){
      const max=parseInt(obsArea.getAttribute('maxlength')||'0',10)||null;
      obsArea.addEventListener('input',()=>{ obsArea.value=sanitizeUpperLive(obsArea.value,max); });
    }
    function mostrarModalObs({titulo,textoInicial,onConfirm}){
      modalObs.style.display='block';
      document.getElementById('titulo-modal-obs-doc').innerText=titulo||'Observaciones';
      obsArea.value=sanitizeUpperLive(textoInicial||'',2000); obsArea.focus();
      document.getElementById('cerrar-modal-obs-doc').onclick=()=>modalObs.style.display='none';
      document.getElementById('enviar-modal-obs-doc').onclick=()=>{ modalObs.style.display='none'; onConfirm(sanitizeUpper(obsArea.value,2000)); };
      modalObs.onclick=e=>{ if(e.target===modalObs) modalObs.style.display='none'; };
      document.addEventListener('keydown', function esc(e){ if(e.key==='Escape'){ modalObs.style.display='none'; document.removeEventListener('keydown',esc);} });
    }

    /* ===== Guardar / Editar ===== */
    docForm.addEventListener('submit',e=>{
      e.preventDefault();
      if(obsInput){ const max=parseInt(obsInput.getAttribute('maxlength')||'0',10)||null; obsInput.value=sanitizeUpper(obsInput.value,max); }
      const fd=new FormData(docForm);
      fd.append('action', (docForm.documento_id.value.trim() ? 'midas_editar_documento_medico' : 'midas_crear_documento_medico'));
      fd.set('midas_empleados_nonce', docForm.querySelector('[name="midas_empleados_nonce"]').value);
      // ✅ enviamos también el nonce de la lista por compatibilidad con handlers
      fd.append('midas_cm_nonce', CFG.nonce);

      fetch(CFG.ajax,{method:'POST',body:fd,credentials:'include'})
        .then(r=>r.json())
        .then(r=>{
          if(r && r.success){ showSuccess('<?= esc_js(__('Documento guardado correctamente.','midas-rrhh')); ?>'); }
          else { throw new Error(r && (r.message||r.data&&r.data.message) || 'Error'); }
          document.getElementById('modal-doc').style.display='none';
          ['pendientes','aprobados','rechazados','historial'].forEach(est=> loadTab(est, CFG.state[est].page || 1));
        })
        .catch(()=>showError('Error'));
    });

    /* ===== Editar (carga en modal) ===== */
    document.addEventListener('click',e=>{
      if(!e.target.classList.contains('editar-doc')) return;
      e.preventDefault();
      const doc=JSON.parse(e.target.dataset.doc);
      docForm.documento_id.value=doc.id||'';
      docForm.empleado_id.value=doc.empleado_id||'';
      docForm.medico_id.value=doc.medico_id||'';
      docForm.motivo_id.value=doc.motivo_id||'';
      docForm.fecha_emision.value=doc.fecha_emision||'';
      docForm.dias_solicitados.value=doc.dias_solicitados||'';
      docForm.observaciones.value=sanitizeUpperLive(doc.observaciones||'',2000);
      docForm.querySelector('input[name="documento"]').required=false;
      document.getElementById('modal-doc').style.display='block';
    });

    /* ===== Aprobar / Rechazar ===== */
    document.addEventListener('click',e=>{
      const aprobar=e.target.classList.contains('aprobar-doc');
      const rechazar=e.target.classList.contains('rechazar-doc');
      if(!aprobar && !rechazar) return;
      e.preventDefault();
      const id=e.target.dataset.id;
      const accion=aprobar?'midas_aprobar_documento_medico':'midas_rechazar_documento_medico';
      const titulo=aprobar?'OBSERVACIONES (OPCIONAL)':'MOTIVO DEL RECHAZO';
      let dias_aprobados=1;
      if(aprobar){
        const fila=e.target.closest('tr'); const t=fila?.querySelector('td:nth-child(4)')?.textContent.trim(); const n=parseInt(t||'1',10); if(!isNaN(n)&&n>0) dias_aprobados=n;
      }
      mostrarModalObs({
        titulo,
        textoInicial:'',
        onConfirm:function(obs){
          const fd=new FormData();
          fd.append('action',accion);
          fd.append('documento_id',id);
          // ✅ enviar ambos nonces
          fd.append('midas_empleados_nonce', document.querySelector('[name="midas_empleados_nonce"]').value);
          fd.append('midas_cm_nonce', CFG.nonce);
          // 👇 compat nombres
          fd.append('observaciones', obs || '');
          fd.append('respuesta',     obs || '');
          if(aprobar) fd.append('dias_aprobados', String(dias_aprobados));

          fetch(CFG.ajax,{method:'POST',body:fd,credentials:'include'})
            .then(async r=>{
              const text=await r.text(); let json;
              try{ json=JSON.parse(text);}catch(_){}
              if(!r.ok || !json || json.success!==true){
                const msg=(json && (json.message || json.data?.message)) || text || (`HTTP ${r.status}`);
                throw new Error(msg);
              }
              return json;
            })
            .then(()=>{
              showSuccess('<?= esc_js(__('Operación realizada correctamente.','midas-rrhh')); ?>');
              ['pendientes','aprobados','rechazados','historial'].forEach(est=> loadTab(est, CFG.state[est].page || 1));
            })
            .catch(err=>{ console.error('[midas_aprobar/rechazar_documento_medico]',err); showError(err.message||'Error'); });
        }
      });
    });

    /* ===== Eliminar ===== */
    document.addEventListener('click',e=>{
      if(!e.target.classList.contains('eliminar-doc')) return;
      e.preventDefault();
      const id=e.target.dataset.id || '';
      if(!id){ showError('ID de documento vacío.'); return; }
      if(!confirm('<?= esc_js(__('¿Seguro que deseas eliminar el documento?','midas-rrhh')); ?>')) return;

      const fd=new FormData();
      fd.append('action','midas_eliminar_documento_medico');
      fd.append('documento_id',id);
      // ✅ Enviar AMBOS nonces
      const formNonce = document.querySelector('[name="midas_empleados_nonce"]')?.value || '';
      if(formNonce) fd.append('midas_empleados_nonce', formNonce);
      fd.append('midas_cm_nonce', CFG.nonce);

      fetch(CFG.ajax,{method:'POST',body:fd,credentials:'include'})
        .then(async r=>{
          const text=await r.text(); let json;
          try{ json=JSON.parse(text);}catch(_){}
          if(!r.ok || !json || json.success!==true){
            const msg=(json && (json.message || json.data?.message)) || text || (`HTTP ${r.status}`);
            throw new Error(msg);
          }
          return json;
        })
        .then(()=>{
          showSuccess('<?= esc_js(__('Documento eliminado.','midas-rrhh')); ?>');
          ['pendientes','aprobados','rechazados','historial'].forEach(est=> loadTab(est, CFG.state[est].page || 1));
        })
        .catch(err=>{ console.error('[midas_eliminar_documento_medico]',err); showError(err.message||'Error'); });
    });
  });
})();
</script>
