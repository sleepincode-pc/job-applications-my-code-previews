<?php
/**
 * Template Admin: Gestión de Licencias (licencias.php)
 * Conectado al Ajax_Handler:
 *  - Listado:  action "midas_lic_listar" (nonce: midas_lic_nonce)
 *  - Crear:    action "midas_crear_licencia" (nonce: midas_empleados_nonce)
 *  - Editar:   action "midas_editar_licencia" (nonce: midas_empleados_nonce)
 *  - Aprobar:  action "midas_aprobar_licencia" (nonce: midas_empleados_nonce)
 *  - Rechazar: action "midas_rechazar_licencia" (nonce: midas_empleados_nonce)
 *  - Eliminar: action "midas_eliminar_licencia" (nonce: midas_empleados_nonce)
 *
 * Importante:
 *  - Este archivo NO registra ningún hook AJAX. Los hooks están en MidasRRHH\Ajax\Ajax_Handler.
 */
if (!defined('ABSPATH')) exit;

use MidasRRHH\Models\Empleado_Model;

// === DATOS BÁSICOS PARA EL FORM ===
$empleado_model = new Empleado_Model();
$empleados      = $empleado_model->obtener_empleados_con_area_y_tarea();

global $wpdb;
$licencia_tipos = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}midas_licencia_tipos ORDER BY id ASC");

// Nonces
$nonce_listar   = wp_create_nonce('midas_lic_nonce');       // para action=midas_lic_listar
$nonce_acciones = wp_create_nonce('midas_empleados_nonce'); // para CRUD (crear/editar/aprobar/rechazar/eliminar)

/* ====== Paleta guardada por usuario (scope local a esta vista) ====== */
$ajax_url      = admin_url('admin-ajax.php');
$nonce_palette = wp_create_nonce('midas_palette_scoped_nonce');
$uid           = get_current_user_id();
$saved_palette = $uid ? get_user_meta($uid, 'midas_palette_scoped', true) : null;
if (!is_array($saved_palette)) $saved_palette = null;
?>

<?php if (!isset($GLOBALS['ajaxurl'])): ?>
<script>var ajaxurl = "<?= esc_js(admin_url('admin-ajax.php')) ?>";</script>
<?php endif; ?>

<!-- Inyecta config/nonce + paleta guardada -->
<script>
  window.midas_rrhh = window.midas_rrhh || {};
  midas_rrhh.ajax_url      = midas_rrhh.ajax_url      || "<?= esc_js($ajax_url); ?>";
  midas_rrhh.palette_nonce = midas_rrhh.palette_nonce || "<?= esc_js($nonce_palette); ?>";
  midas_rrhh.user_palette  = midas_rrhh.user_palette  || <?php echo wp_json_encode($saved_palette ?: (object)[]); ?>;
</script>

<style>
/* ====== Scope de paleta SOLO para Licencias ====== */
.midas-licencias{
  --md-card-bg:#ffffff;
  --md-card-border:#ccd0d4;
  --md-card-header-bg:#f7f7f7;
  --md-card-header-text:#1f2937;
  --md-table-stripe:#f9fafb;
  --md-text:#1e293b;
  --md-muted:#475569;
  color:var(--md-text);
}
.midas-licencias .wp-list-table{
  background:var(--md-card-bg);
  color:var(--md-text);
  border:1px solid var(--md-card-border);
  box-shadow:0 0 5px rgba(0,0,0,.05);
}
.midas-licencias .wp-list-table thead{
  background:var(--md-card-header-bg);
  color:var(--md-card-header-text);
}
.midas-licencias .wp-list-table th,
.midas-licencias .wp-list-table td{
  border-bottom:1px solid var(--md-card-border);
}
.midas-licencias .wp-list-table.striped tbody tr:nth-child(odd){
  background:var(--md-table-stripe) !important;
}
.midas-licencias .wp-list-table tbody tr:hover{ background:var(--md-table-stripe); }

/* Modal (override de inline) */
#modal-licencia{ backdrop-filter: blur(0px); }
#modal-licencia > div{
  background:var(--md-card-bg) !important;
  color:var(--md-text) !important;
  border:1px solid var(--md-card-border) !important;
  box-shadow:0 10px 30px #0002 !important;
}
</style>

<div class="wrap midas-licencias" id="midasLicencias" data-midas-scope>
  <h1 style="margin-bottom:25px;"><?php esc_html_e('Gestión de Licencias','midas-rrhh'); ?></h1>

  <div style="margin-bottom:20px;">
    <input id="buscador-licencias" class="midas-input-mayus" type="text"
           placeholder="Buscar en la pestaña activa..."
           style="width:400px;padding:8px;font-size:14px;border:1px solid #ccc;border-radius:4px;display:block;margin-bottom:10px;"
           maxlength="120"
           pattern="^[A-ZÁÉÍÓÚÑ0-9 .,:;¡!¿?\(\)\-_/#+%]*$" autocomplete="off">
    <button id="abrir-modal-licencia" class="button button-primary">➕ Agregar nueva licencia</button>
  </div>

  <!-- MODAL CREAR/EDITAR -->
  <div id="modal-licencia" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:9999;">
    <div style="background:#fff;padding:20px;border-radius:6px;max-width:800px;margin:60px auto;position:relative;">
      <span id="cerrar-modal-licencia" style="position:absolute;top:10px;right:15px;font-size:20px;cursor:pointer;">&times;</span>
      <h2 style="font-size:20px;margin-top:0;border-bottom:1px solid #ccc;padding-bottom:5px;">Licencia</h2>

      <form id="form-nueva-licencia" enctype="multipart/form-data" autocomplete="off">
        <input type="hidden" name="licencia_id" value="">
        <input type="hidden" name="midas_empleados_nonce" value="<?= esc_attr($nonce_acciones) ?>">

        <div style="display:flex;flex-wrap:wrap;gap:15px;">
          <label style="flex:1 1 300px;">
            <strong>Empleado:</strong><br>
            <select name="empleado_id" required style="width:100%;padding:6px;">
              <option value="">Seleccionar empleado</option>
              <?php foreach ($empleados as $emp): ?>
                <option value="<?= esc_attr($emp->id) ?>"><?= esc_html("{$emp->nombre} {$emp->apellido} - {$emp->dni}") ?></option>
              <?php endforeach; ?>
            </select>
          </label>

          <label style="flex:1 1 200px;">
            <strong>Tipo:</strong><br>
            <select name="tipo" required style="width:100%;padding:6px;">
              <option value="">Seleccionar tipo</option>
              <?php foreach ($licencia_tipos as $tipo): ?>
                <option value="<?= esc_attr($tipo->tipo) ?>"><?= esc_html($tipo->tipo) ?></option>
              <?php endforeach; ?>
            </select>
          </label>

          <label style="flex:1 1 150px;">
            <strong>Inicio:</strong><br>
            <input type="date" name="fecha_inicio" required style="width:100%;padding:6px;">
          </label>

          <label style="flex:1 1 150px;">
            <strong>Fin:</strong><br>
            <input type="date" name="fecha_fin" required style="width:100%;padding:6px;">
          </label>

          <label style="flex:1 1 300px;">
            <strong>Observaciones:</strong><br>
            <input type="text" name="observaciones" id="observaciones"
                   class="midas-input-mayus" style="width:100%;padding:6px;"
                   maxlength="2000"
                   pattern="^[A-ZÁÉÍÓÚÑ0-9 .,:;¡!¿?\(\)\-_/#+%]*$" autocomplete="off">
          </label>

          <label style="flex:1 1 240px;">
            <strong>Documento adjunto:</strong><br>
            <input type="file" name="documento" id="documento"
                   accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" style="width:100%;padding:6px;">
            <small>PDF/JPG/PNG/DOC/DOCX (máx. 5 MB)</small>
          </label>
        </div>

        <div style="margin-top:20px;">
          <button type="submit" class="button button-primary" style="width:100%;padding:10px;font-size:16px;">Guardar Licencia</button>
        </div>
      </form>
    </div>
  </div>

  <h2 class="nav-tab-wrapper" style="margin-bottom:20px;">
    <a href="#pendientes" class="nav-tab nav-tab-active">Pendientes</a>
    <a href="#aprobadas"  class="nav-tab">Aprobadas</a>
    <a href="#rechazadas" class="nav-tab">Rechazadas</a>
    <a href="#historial"  class="nav-tab">Historial</a>
  </h2>

  <div id="contenedor-tablas">
    <?php
    function render_tabla($id) {
      echo "<div id=\"$id\" class=\"midas-tab-content\" style=\"display:" . ($id === 'pendientes' ? 'block' : 'none') . "; margin-bottom:40px;\">
        <table class=\"wp-list-table widefat fixed striped\" id=\"tabla-licencias-$id\">
          <thead>
            <tr>
              <th>Empleado</th>
              <th>Tipo</th>
              <th>Período</th>
              <th>Días</th>
              <th>Observaciones</th>
              <th>Archivo</th>
              <th>Acciones</th>";
      if ($id === 'historial') echo "<th>Estado</th>";
      echo "</tr>
          </thead><tbody></tbody>
        </table>
        <div class=\"paginacion\" data-tab=\"$id\" style=\"margin-top:10px;text-align:right;\"></div>
      </div>";
    }
    render_tabla('pendientes');
    render_tabla('aprobadas');
    render_tabla('rechazadas');
    render_tabla('historial');
    ?>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  /* ===== Aplica paleta guardada a este scope ===== */
  const WRAP = document.getElementById('midasLicencias') || document.querySelector('.midas-licencias');
  const SAVED = (window.midas_rrhh && window.midas_rrhh.user_palette) ? window.midas_rrhh.user_palette : null;
  const DEF = { cards:{ bg:'#ffffff', border:'#ccd0d4', headerBg:'#f7f7f7', headerTxt:'#1f2937', stripe:'#f9fafb' }, text:{ txt:'#1e293b', muted:'#475569' } };
  const initial = (SAVED && typeof SAVED==='object')
    ? { cards:Object.assign({}, DEF.cards, SAVED.cards||{}), text:Object.assign({}, DEF.text, SAVED.text||{}) }
    : JSON.parse(localStorage.getItem('midas.palette.scoped')||'null') || DEF;
  function applyPaletteTo(el,p){
    if(!el) return;
    el.style.setProperty('--md-card-bg',          p.cards.bg);
    el.style.setProperty('--md-card-border',      p.cards.border);
    el.style.setProperty('--md-card-header-bg',   p.cards.headerBg);
    el.style.setProperty('--md-card-header-text', p.cards.headerTxt);
    el.style.setProperty('--md-table-stripe',     p.cards.stripe);
    el.style.setProperty('--md-text',             p.text.txt);
    el.style.setProperty('--md-muted',            p.text.muted);
  }
  applyPaletteTo(WRAP, initial);
  window.addEventListener('storage', (e)=>{ if(e.key==='midas.palette.scoped' && e.newValue){ try{ applyPaletteTo(WRAP, JSON.parse(e.newValue)); }catch(_){}} });

  /* ===== Sanitizado ===== */
  const ZERO_WIDTH=/[\u200B-\u200D\uFEFF]/g, SPACE_LIKE=/[\u00A0\u1680\u2000-\u200A\u202F\u205F\u3000]/g, RE_ALLOWED=/[^A-ZÁÉÍÓÚÑ0-9 .,:;¡!¿?\(\)\-_/#+%]/g;
  const normalizeNFKC=s=>{try{return (s||'').normalize('NFKC')}catch(_){return (s||'')}};
  const normalizeSpaces=s=>String(s||'').replace(SPACE_LIKE,' ');
  const sanitizeUpper=(v,maxLen)=>{ v=normalizeNFKC(String(v||'')); v=normalizeSpaces(v).replace(ZERO_WIDTH,'').toUpperCase().replace(RE_ALLOWED,''); if(maxLen&&v.length>maxLen)v=v.slice(0,maxLen); return v; };
  const bindSanitizer=el=>{ if(!el) return; const max=parseInt(el.getAttribute('maxlength')||'0',10)||null;
    const h=()=>{ el.value=sanitizeUpper(el.value,max); };
    el.addEventListener('input',h); el.addEventListener('blur',h);
    el.addEventListener('paste',e=>{ e.preventDefault(); let t=(e.clipboardData||window.clipboardData).getData('text')||''; t=sanitizeUpper(t,max);
      const s=el.selectionStart,en=el.selectionEnd; el.value=el.value.slice(0,s)+t+el.value.slice(en); const pos=s+t.length; try{ el.setSelectionRange(pos,pos);}catch(_){}}); };
  bindSanitizer(document.getElementById('buscador-licencias'));
  bindSanitizer(document.getElementById('observaciones'));

  /* ===== Avisos ===== */
  window.showSuccess = m => aviso(m,'success');
  window.showError   = m => aviso(m,'error');
  function aviso(msg,tipo){
    document.querySelectorAll('.midas-rrhh-aviso').forEach(el=>el.remove());
    const color = tipo==='success' ? '#27ae60' : '#c0392b';
    const d = document.createElement('div');
    d.className='midas-rrhh-aviso';
    Object.assign(d.style,{position:'fixed',top:'30px',right:'30px',zIndex:9999,padding:'16px 32px',borderRadius:'8px',background:color,color:'#fff',fontSize:'16px',boxShadow:'0 4px 16px rgba(0,0,0,.2)',opacity:0,transition:'opacity .2s'});
    d.textContent=msg; document.body.appendChild(d);
    setTimeout(()=>d.style.opacity=1,10);
    setTimeout(()=>{ d.style.opacity=0; setTimeout(()=>d.remove(),400); },2500);
  }

  /* ===== Helpers ===== */
  const PER_PAGE=10;
  const $ = s => document.querySelector(s);
  const getActiveTab=()=>document.querySelector('.nav-tab.nav-tab-active')?.getAttribute('href')?.substring(1) || 'pendientes';
  const tbody = id => document.querySelector(`#tabla-licencias-${id} tbody`);
  const pagin = id => document.querySelector(`.paginacion[data-tab="${id}"]`);
  const parseLicAttr = s => { try{ return JSON.parse(String(s||'').replace(/&quot;/g,'"').replace(/&#39;/g,"'")); }catch(e){ return {}; } };

  /* ===== Carga por pestaña (AJAX -> Ajax_Handler::ajax_lic_listar) ===== */
  const state = { pendientes:{page:1}, aprobadas:{page:1}, rechazadas:{page:1}, historial:{page:1} };

  function loadTab(tab, page) {
    if (!tab) tab = getActiveTab();
    if (!page) page = state[tab]?.page || 1;

    const q = sanitizeUpper(document.getElementById('buscador-licencias').value, 120);
    const fd = new FormData();
    fd.append('action', 'midas_lic_listar');
    fd.append('nonce', "<?= esc_js($nonce_listar) ?>");
    fd.append('estado', tab);
    fd.append('page', page);
    fd.append('per_page', PER_PAGE);
    fd.append('q', q);

    fetch(ajaxurl, { method:'POST', body:fd })
      .then(r => r.json())
      .then(r => {
        if (!r || r.success!==true) throw new Error(r && (r.message||r.data&&r.data.message) || 'Error al listar');
        tbody(tab).innerHTML = r.data.tbody || '';
        renderPagination(tab, Number(r.data.page||1), Number(r.data.total_pages||1));
        state[tab].page = Number(r.data.page||1);
      })
      .catch(err => { showError(err.message || 'Error de conexión'); });
  }

  function renderPagination(tab, page, totalPages) {
    const cont = pagin(tab);
    cont.innerHTML = '';
    totalPages = Number(totalPages)||1;
    if(totalPages<=1) return;

    const mkBtn = (txt, p, disabled=false, primary=false) => {
      const b = document.createElement('button');
      b.textContent = txt;
      b.className = 'button' + (primary ? ' button-primary' : '');
      b.disabled = !!disabled;
      b.dataset.page = p;
      b.addEventListener('click', ()=>loadTab(tab, p));
      return b;
    };
    cont.appendChild(mkBtn('Anterior', Math.max(1, page-1), page===1));
    for (let i=1; i<=totalPages; i++) cont.appendChild(mkBtn(i, i, false, i===page));
    cont.appendChild(mkBtn('Siguiente', Math.min(totalPages, page+1), page===totalPages));
  }

  // Carga inicial
  ['pendientes','aprobadas','rechazadas','historial'].forEach(t=>loadTab(t,1));

  // Tabs
  document.querySelectorAll('.nav-tab').forEach(tab=>{
    tab.addEventListener('click', e=>{
      e.preventDefault();
      document.querySelectorAll('.nav-tab').forEach(t=>t.classList.remove('nav-tab-active'));
      document.querySelectorAll('.midas-tab-content').forEach(c=>c.style.display='none');
      tab.classList.add('nav-tab-active');
      const id = tab.getAttribute('href').substring(1);
      document.getElementById(id).style.display='block';
      loadTab(id, state[id]?.page || 1);
    });
  });

  // Buscador (debounce => recarga pestaña activa)
  const debounce=(fn,ms)=>{ let t; return (...a)=>{ clearTimeout(t); t=setTimeout(()=>fn(...a),ms); }; };
  document.getElementById('buscador-licencias').addEventListener('input', debounce(()=>loadTab(getActiveTab(),1), 150));

  // ===== Modal crear/editar =====
  const modal = document.getElementById('modal-licencia');
  const form  = document.getElementById('form-nueva-licencia');

  document.getElementById('abrir-modal-licencia').onclick=()=>{
    form.reset(); form.licencia_id.value='';
    form.querySelector('input[name="midas_empleados_nonce"]').value="<?= esc_js($nonce_acciones) ?>";
    modal.style.display='block';
  };
  document.getElementById('cerrar-modal-licencia').onclick = () => modal.style.display='none';
  modal.addEventListener('click',e=>{ if(e.target===modal) modal.style.display='none'; });
  document.addEventListener('keydown',e=>{ if(e.key==='Escape') modal.style.display='none'; });

  // Validación archivo
  const MAX_MB=5, ALLOWED_EXT=['pdf','jpg','jpeg','png','doc','docx'];
  const ALLOWED_MIME=['application/pdf','image/jpeg','image/png','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
  document.getElementById('documento')?.addEventListener('change',function(){
    const f=this.files&&this.files[0]?this.files[0]:null; if(!f) return;
    const okSize=f.size<=MAX_MB*1024*1024;
    const ext=(f.name.split('.').pop()||'').toLowerCase();
    const okExt=ALLOWED_EXT.includes(ext);
    const okMime=!f.type||ALLOWED_MIME.includes(f.type);
    if(!okSize||!okExt||!okMime){ alert('Archivo inválido. Formatos permitidos: PDF/JPG/PNG/DOC/DOCX y máx. 5 MB.'); this.value=''; }
  });

  // Guardar / Editar (y recargar listas)
  form.addEventListener('submit',e=>{
    e.preventDefault();
    const obs=form.querySelector('#observaciones');
    if(obs) obs.value = sanitizeUpper(obs.value, parseInt(obs.getAttribute('maxlength')||'0',10)||null);

    const fd=new FormData(form);
    if(form.licencia_id && form.licencia_id.value){
      fd.append('action','midas_editar_licencia');
      fd.set('midas_empleados_nonce',"<?= esc_js($nonce_acciones) ?>");
      fd.append('licencia_id', form.licencia_id.value);
    }else{
      fd.append('action','midas_crear_licencia');
      fd.set('midas_empleados_nonce',"<?= esc_js($nonce_acciones) ?>");
    }
    fetch(ajaxurl,{method:'POST',body:fd})
      .then(r=>r.json())
      .then(r=>{
        if(r && r.success){
          showSuccess('Licencia guardada correctamente.');
          modal.style.display='none';
          ['pendientes','aprobadas','rechazadas','historial'].forEach(t=>loadTab(t,1));
        }else{
          throw new Error(r && (r.message||r.data&&r.data.message) || 'Error al guardar licencia');
        }
      })
      .catch(err=>showError(err.message||'Error de conexión o servidor'));
  });

  /* ============================================================
   *  BOTONES DE ACCIÓN (EDITAR / APROBAR / RECHAZAR / ELIMINAR)
   *  ——— FIX: usar delegación con .closest() para que funcionen
   *           aunque el click sea sobre un <span>/<i> interno.
   * ============================================================ */
  // Modal Observaciones reutilizable
  const modalObs = document.createElement('div');
  modalObs.id='modal-observaciones-licencia';
  modalObs.style.cssText='display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,.33);z-index:99999;';
  modalObs.innerHTML=`
    <div style="background:#fff;border-radius:9px;box-shadow:0 8px 32px #0002;padding:24px 24px 18px;max-width:380px;margin:100px auto 0;position:relative;">
      <button id="cerrar-modal-obs" style="position:absolute;top:8px;right:14px;font-size:19px;border:none;background:transparent;cursor:pointer;">&times;</button>
      <h3 id="titulo-modal-obs" style="margin:0 0 7px;font-size:16px;font-weight:700;">Observaciones</h3>
      <textarea id="obs-textarea" rows="4" class="midas-input-mayus" style="width:100%;border-radius:7px;border:1px solid #e0e0e0;padding:9px;resize:none;font-size:14px;margin-bottom:10px;" maxlength="2000" placeholder="ESCRIBE AQUÍ"></textarea>
      <button id="enviar-modal-obs" class="button button-primary" style="width:100%;font-size:15px;">Confirmar</button>
    </div>`;
  document.body.appendChild(modalObs);
  bindSanitizer(modalObs.querySelector('#obs-textarea'));

  function showObsModal({titulo,textoInicial,onConfirm}){
    modalObs.style.display='block';
    document.getElementById('titulo-modal-obs').innerText=titulo||'Observaciones';
    const t=document.getElementById('obs-textarea'); t.value=sanitizeUpper(textoInicial||'', parseInt(t.getAttribute('maxlength')||'0',10)||null); t.focus();
    document.getElementById('cerrar-modal-obs').onclick=()=>modalObs.style.display='none';
    document.getElementById('enviar-modal-obs').onclick=()=>{ modalObs.style.display='none'; onConfirm(sanitizeUpper(t.value,2000)); };
    t.onkeydown=e=>{ if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)) document.getElementById('enviar-modal-obs').click(); };
    modalObs.onclick=e=>{ if(e.target===modalObs) modalObs.style.display='none'; };
    document.addEventListener('keydown', escClose);
    function escClose(e){ if(e.key==='Escape'){ modalObs.style.display='none'; document.removeEventListener('keydown', escClose); } }
  }

  // Delegación global
  document.addEventListener('click', (e) => {
    // Encuentra el botón relevante aunque el click sea en un hijo
    const btn = e.target.closest('[data-accion], .editar-licencia, .aprobar-licencia, .rechazar-licencia, .eliminar-licencia');
    if(!btn) return;

    // Evita navegaciones de <a href="#">
    if(btn.tagName === 'A') e.preventDefault();

    const tr = btn.closest('tr');
    const getId = () => btn.dataset.id || (tr && tr.dataset.id) || btn.getAttribute('data-id') || '';
    const getJSON = () => btn.dataset.lic || (tr && tr.dataset.lic) || '';

    // Determina la acción por data-accion o por clase
    const accion = (btn.dataset.accion)
      ? String(btn.dataset.accion)
      : (btn.classList.contains('editar-licencia')   ? 'editar'
        : btn.classList.contains('aprobar-licencia') ? 'aprobar'
        : btn.classList.contains('rechazar-licencia')? 'rechazar'
        : btn.classList.contains('eliminar-licencia')? 'eliminar'
        : '');

    if(!accion) return; // no reconocido

    // === EDITAR ===
    if(accion==='editar'){
      const raw = getJSON();
      const lic = raw ? parseLicAttr(raw) : {};
      form.licencia_id.value    = lic.id || (tr && tr.dataset.id) || '';
      form.empleado_id.value    = lic.empleado_id || '';
      form.tipo.value           = lic.tipo || '';
      form.fecha_inicio.value   = lic.fecha_inicio || '';
      form.fecha_fin.value      = lic.fecha_fin || '';
      form.observaciones.value  = sanitizeUpper(lic.observaciones || (tr && tr.dataset.observaciones) || '', 2000);
      form.querySelector('input[name="midas_empleados_nonce"]').value = "<?= esc_js($nonce_acciones) ?>";
      modal.style.display='block';
      return;
    }

    // === APROBAR / RECHAZAR ===
    if(accion==='aprobar' || accion==='rechazar'){
      const id = getId();
      if(!id){ showError('ID de licencia no encontrado.'); return; }
      const titulo = accion==='aprobar' ? 'OBSERVACIONES (OPCIONAL)' : 'MOTIVO DEL RECHAZO';
      showObsModal({
        titulo,
        textoInicial:'',
        onConfirm:function(obs){
          const fd=new FormData();
          fd.append('action', accion==='aprobar'?'midas_aprobar_licencia':'midas_rechazar_licencia');
          fd.append('licencia_id', id);
          fd.append('observaciones', sanitizeUpper(obs,2000));
          fd.append('midas_empleados_nonce', "<?= esc_js($nonce_acciones) ?>");
          fetch(ajaxurl,{method:'POST',body:fd})
            .then(r=>r.json())
            .then(r=>{
              if(r && r.success){
                showSuccess('Operación realizada correctamente.');
                ['pendientes','aprobadas','rechazadas','historial'].forEach(t=>loadTab(t,1));
              }else{
                throw new Error(r && (r.message||r.data&&r.data.message) || 'Error en la operación');
              }
            })
            .catch(()=>showError('Error de conexión o servidor'));
        }
      });
      return;
    }

    // === ELIMINAR ===
    if(accion==='eliminar'){
      const id = getId();
      if(!id){ showError('ID de licencia no encontrado.'); return; }
      if(!confirm('¿Seguro que deseas eliminar la licencia seleccionada? Esta acción no se puede deshacer.')) return;
      const fd=new FormData();
      fd.append('action','midas_eliminar_licencia');
      fd.append('licencia_id', id);
      fd.append('midas_empleados_nonce', "<?= esc_js($nonce_acciones) ?>");
      fetch(ajaxurl,{method:'POST',body:fd})
        .then(r=>r.json())
        .then(r=>{
          if(r && r.success){
            showSuccess('Licencia eliminada correctamente.');
            ['pendientes','aprobadas','rechazadas','historial'].forEach(t=>loadTab(t,1));
          }else{
            throw new Error(r && (r.message||r.data&&r.data.message) || 'Error al eliminar');
          }
        })
        .catch(()=>showError('Error de conexión o servidor'));
      return;
    }
  });
});
</script>

<style>
/* ===== General ===== */
.midas-input-mayus{ text-transform:uppercase; }

/* Contenedor de cada pestaña: permite scroll horizontal en pantallas angostas */
.midas-licencias .midas-tab-content{ overflow-x:auto; }
.midas-licencias .wp-list-table{ min-width:780px; }

/* Observaciones: respetar saltos de línea */
.midas-licencias table td:nth-child(5){ white-space:pre-wrap; word-break:break-word; }

/* Buscador: que nunca se corte */
#buscador-licencias{ width:min(100%,520px) !important; box-sizing:border-box; }

/* Modal responsive (override de inline) */
#modal-licencia > div{ width:min(92vw,800px) !important; margin:40px auto !important; }

/* Paginación */
.midas-licencias .paginacion{ display:flex; flex-wrap:wrap; gap:6px; justify-content:flex-end; }
.midas-licencias .paginacion .button{ padding:.42rem .7rem; }

/* ===== Botones de acciones ===== */
.midas-licencias td.col-acciones{ min-width:260px; text-align:center; }

.midas-licencias .acciones-licencia-grid{
  display:grid;
  grid-template-columns: repeat(auto-fit, 115px);
  gap:8px 10px;
  justify-content:center;
  justify-items:center;
  align-items:center;
}
.midas-licencias .acciones-licencia-grid .button{
  width:115px;
  display:inline-flex;
  align-items:center;
  justify-content:center;
  text-align:center;
}

/* Colores de acciones */
.midas-licencias .button.eliminar-licencia{ color:#e53935; }
.midas-licencias .button.aprobar-licencia { color:#2e7d32; }
.midas-licencias .button.rechazar-licencia{ color:#ff9100; }

/* ===== Responsive ===== */
@media (max-width: 1024px){
  .midas-licencias .wp-list-table{ min-width:720px; }
}
@media (max-width: 560px){
  .midas-licencias .acciones-licencia-grid{ grid-template-columns:1fr; }
  .midas-licencias .acciones-licencia-grid .button{ width:100%; }
}
</style>
