<?php
if (!defined('ABSPATH')) exit;

/**
 * CONFIGURACIÓN (ligera) + LISTADOS VIA AJAX
 * - Evita SELECT *.
 * - Server-side pagination + search.
 * - Devuelve solo el <tbody> necesario.
 */

global $wpdb, $wp_roles;

$nonce_cfg = wp_create_nonce('midas_cfg_nonce');

$smtp_settings = get_option('midas_rrhh_smtp_settings', []);

// Tablas
$tareas_table         = $wpdb->prefix . 'midas_tareas';
$areas_table          = $wpdb->prefix . 'midas_areas';
$enfermedades_table   = $wpdb->prefix . 'midas_enfermedades';
$medicos_table        = $wpdb->prefix . 'midas_medicos';
$licencia_tipos_table = $wpdb->prefix . 'midas_licencia_tipos';

// Roles WP
$roles = $wp_roles->roles;
?>
<style>
.midas-paginacion{display:flex;justify-content:flex-end;gap:8px;margin:12px 0;}
.midas-paginacion .button{margin:0 2px;}
.midas-buscar{margin-bottom:10px;display:flex;justify-content:flex-end}
.midas-buscar input{min-width:220px}
#midas-modal-agregar,#midas-modal-eliminar{display:none;position:fixed;z-index:99999;inset:0;align-items:center;justify-content:center;background:rgba(0,0,0,.4)}
.midas-modal-cuerpo{background:#fff;padding:30px 30px 10px;border-radius:12px;min-width:340px;max-width:90vw;box-shadow:0 4px 32px #0002;position:relative}
.midas-modal-cerrar{position:absolute;top:10px;right:10px;font-size:22px;border:none;background:none;cursor:pointer}
#form-crear-label{font-size:19px;margin-bottom:8px}
.button-danger{background:#d63638!important;color:#fff}

/* Visual: mayúsculas/minúsculas */
.midas-configuracion input[type="text"],
.midas-configuracion input[type="search"],
.midas-configuracion input:not([type]),
.midas-configuracion textarea{text-transform:uppercase}
.midas-configuracion input[type="email"]{text-transform:lowercase}

/* Loader simple en tbody */
.midas-tbody-loading{opacity:.6}
.midas-tbody-loader{padding:14px;text-align:center;color:#555}

/* Grid acciones */
.acciones-licencia-grid{display:flex;gap:6px;flex-wrap:wrap}
</style>

<!-- MODAL AGREGAR/EDITAR -->
<div id="midas-modal-agregar">
  <div class="midas-modal-cuerpo">
    <button class="midas-modal-cerrar" title="Cerrar" type="button">&times;</button>
    <form id="midas-form-agregar" autocomplete="off">
      <input type="hidden" name="tabla" id="midas-form-tabla">
      <input type="hidden" name="registro_id" id="midas-form-id">
      <div id="midas-form-contenido"></div>
      <div style="margin-top:18px; text-align:right;">
        <button type="submit" class="button button-primary"><?php esc_html_e('Guardar', 'midas-rrhh'); ?></button>
      </div>
    </form>
  </div>
</div>

<!-- MODAL ELIMINAR -->
<div id="midas-modal-eliminar">
  <div class="midas-modal-cuerpo">
    <button class="midas-modal-cerrar" title="Cerrar" type="button">&times;</button>
    <form id="midas-form-eliminar">
      <input type="hidden" name="tabla" id="eliminar-form-tabla">
      <input type="hidden" name="registro_id" id="eliminar-form-id">
      <div style="font-size:17px;margin-bottom:18px;"><?php esc_html_e('¿Seguro que quieres eliminar este registro?', 'midas-rrhh'); ?></div>
      <div style="margin-top:12px;text-align:right;">
        <button type="button" class="button" id="cancelar-eliminar"><?php esc_html_e('Cancelar', 'midas-rrhh'); ?></button>
        <button type="submit" class="button button-danger"><?php esc_html_e('Eliminar', 'midas-rrhh'); ?></button>
      </div>
    </form>
  </div>
</div>

<div class="wrap midas-configuracion">
  <h1><?php esc_html_e('Configuración Midas RRHH', 'midas-rrhh'); ?></h1>
  <?php settings_errors('midas_rrhh_messages'); ?>

  <form method="post" action="options.php">
    <?php settings_fields('midas_rrhh_smtp_settings'); ?>
    <h2><?php esc_html_e('Configuración SMTP', 'midas-rrhh'); ?></h2>
    <table class="form-table">
      <tr>
        <th scope="row"><label for="host"><?php esc_html_e('Servidor SMTP', 'midas-rrhh'); ?></label></th>
        <td>
          <input type="text" id="host" name="midas_rrhh_smtp_settings[host]" value="<?php echo esc_attr($smtp_settings['host'] ?? ''); ?>" class="regular-text" maxlength="255">
          <p class="description"><?php esc_html_e('Ejemplo: smtp.tudominio.com', 'midas-rrhh'); ?></p>
        </td>
      </tr>
      <tr>
        <th scope="row"><label for="port"><?php esc_html_e('Puerto', 'midas-rrhh'); ?></label></th>
        <td>
          <input type="number" id="port" name="midas_rrhh_smtp_settings[port]" value="<?php echo esc_attr($smtp_settings['port'] ?? ''); ?>" class="small-text">
          <p class="description"><?php esc_html_e('Normalmente 587 para TLS o 465 para SSL', 'midas-rrhh'); ?></p>
        </td>
      </tr>
      <tr>
        <th scope="row"><label for="from_email"><?php esc_html_e('Email Remitente', 'midas-rrhh'); ?></label></th>
        <td><input type="email" id="from_email" name="midas_rrhh_smtp_settings[from_email]" value="<?php echo esc_attr($smtp_settings['from_email'] ?? ''); ?>" class="regular-text" maxlength="255"></td>
      </tr>
    </table>
    <?php submit_button(__('Guardar Configuración', 'midas-rrhh')); ?>
  </form>

  <hr>

  <div class="midas-tabs">
    <ul class="nav-tab-wrapper">
      <li><a href="#midas-tab-tareas" class="nav-tab nav-tab-active"><?php esc_html_e('Tareas', 'midas-rrhh'); ?></a></li>
      <li><a href="#midas-tab-areas" class="nav-tab"><?php esc_html_e('Áreas', 'midas-rrhh'); ?></a></li>
    </ul>

    <!-- TAB TAREAS -->
    <div id="midas-tab-tareas" class="midas-tab-content" style="display:block;">
      <div class="midas-buscar">
        <input type="search" class="form-control midas-search" id="buscar-tareas" name="buscar-tareas" data-tabla="tabla-tareas" placeholder="<?php esc_attr_e('Buscar...', 'midas-rrhh'); ?>" maxlength="255">
      </div>
      <button type="button" class="button button-primary midas-btn-agregar" data-tabla="tabla-tareas" style="margin-bottom:10px;"><?php esc_html_e('Agregar nueva Tarea', 'midas-rrhh'); ?></button>
      <table class="wp-list-table widefat fixed striped midas-table" id="tabla-tareas">
        <thead>
          <tr>
            <th><?php esc_html_e('ID', 'midas-rrhh'); ?></th>
            <th><?php esc_html_e('Nombre', 'midas-rrhh'); ?></th>
            <th><?php esc_html_e('Descripción', 'midas-rrhh'); ?></th>
            <th><?php esc_html_e('Estado', 'midas-rrhh'); ?></th>
            <th><?php esc_html_e('Acciones', 'midas-rrhh'); ?></th>
          </tr>
        </thead>
        <tbody><tr><td colspan="5" class="midas-tbody-loader"><?php esc_html_e('Cargando…', 'midas-rrhh'); ?></td></tr></tbody>
      </table>
      <div class="midas-paginacion" data-tabla="tabla-tareas"></div>
    </div>

    <!-- TAB AREAS -->
    <div id="midas-tab-areas" class="midas-tab-content" style="display:none;">
      <div class="midas-buscar">
        <input type="search" class="form-control midas-search" id="buscar-areas" name="buscar-areas" data-tabla="tabla-areas" placeholder="<?php esc_attr_e('Buscar...', 'midas-rrhh'); ?>" maxlength="255">
      </div>
      <button type="button" class="button button-primary midas-btn-agregar" data-tabla="tabla-areas" style="margin-bottom:10px;"><?php esc_html_e('Agregar nueva Área', 'midas-rrhh'); ?></button>
      <table class="wp-list-table widefat fixed striped midas-table" id="tabla-areas">
        <thead>
          <tr>
            <th><?php esc_html_e('ID', 'midas-rrhh'); ?></th>
            <th><?php esc_html_e('Nombre', 'midas-rrhh'); ?></th>
            <th><?php esc_html_e('Rol', 'midas-rrhh'); ?></th>
            <th><?php esc_html_e('Estado', 'midas-rrhh'); ?></th>
            <th><?php esc_html_e('Acciones', 'midas-rrhh'); ?></th>
          </tr>
        </thead>
        <tbody><tr><td colspan="5" class="midas-tbody-loader"><?php esc_html_e('Cargando…', 'midas-rrhh'); ?></td></tr></tbody>
      </table>
      <div class="midas-paginacion" data-tabla="tabla-areas"></div>
    </div>
  </div>

  <!-- OTRAS TABLAS -->
  <h2 style="margin-top:40px;"><?php esc_html_e('Tipos de Enfermedad', 'midas-rrhh'); ?></h2>
  <div class="midas-buscar">
    <input type="search" class="form-control midas-search" id="buscar-enfermedades" name="buscar-enfermedades" data-tabla="tabla-enfermedades" placeholder="<?php esc_attr_e('Buscar...', 'midas-rrhh'); ?>" maxlength="255">
  </div>
  <button type="button" class="button button-primary midas-btn-agregar" data-tabla="tabla-enfermedades" style="margin-bottom:10px;"><?php esc_html_e('Agregar nueva Enfermedad', 'midas-rrhh'); ?></button>
  <table class="widefat striped midas-table" id="tabla-enfermedades">
    <thead>
      <tr>
        <th><?php esc_html_e('ID', 'midas-rrhh'); ?></th>
        <th><?php esc_html_e('Tipo', 'midas-rrhh'); ?></th>
        <th><?php esc_html_e('Descripción', 'midas-rrhh'); ?></th>
        <th><?php esc_html_e('Acciones', 'midas-rrhh'); ?></th>
      </tr>
    </thead>
    <tbody><tr><td colspan="4" class="midas-tbody-loader"><?php esc_html_e('Cargando…', 'midas-rrhh'); ?></td></tr></tbody>
  </table>
  <div class="midas-paginacion" data-tabla="tabla-enfermedades"></div>

  <h2><?php esc_html_e('Médicos', 'midas-rrhh'); ?></h2>
  <div class="midas-buscar">
    <input type="search" class="form-control midas-search" id="buscar-medicos" name="buscar-medicos" data-tabla="tabla-medicos" placeholder="<?php esc_attr_e('Buscar...', 'midas-rrhh'); ?>" maxlength="255">
  </div>
  <button type="button" class="button button-primary midas-btn-agregar" data-tabla="tabla-medicos" style="margin-bottom:10px;"><?php esc_html_e('Agregar nuevo Médico', 'midas-rrhh'); ?></button>
  <table class="widefat striped midas-table" id="tabla-medicos">
    <thead>
      <tr>
        <th><?php esc_html_e('ID', 'midas-rrhh'); ?></th>
        <th><?php esc_html_e('Nombre', 'midas-rrhh'); ?></th>
        <th><?php esc_html_e('Apellido', 'midas-rrhh'); ?></th>
        <th><?php esc_html_e('Especialidad', 'midas-rrhh'); ?></th>
        <th><?php esc_html_e('Matrícula', 'midas-rrhh'); ?></th>
        <th><?php esc_html_e('Acciones', 'midas-rrhh'); ?></th>
      </tr>
    </thead>
    <tbody><tr><td colspan="6" class="midas-tbody-loader"><?php esc_html_e('Cargando…', 'midas-rrhh'); ?></td></tr></tbody>
  </table>
  <div class="midas-paginacion" data-tabla="tabla-medicos"></div>

  <h2><?php esc_html_e('Tipos de Licencias', 'midas-rrhh'); ?></h2>
  <div class="midas-buscar">
    <input type="search" class="form-control midas-search" id="buscar-licencias" name="buscar-licencias" data-tabla="tabla-licencias" placeholder="<?php esc_attr_e('Buscar...', 'midas-rrhh'); ?>" maxlength="255">
  </div>
  <button type="button" class="button button-primary midas-btn-agregar" data-tabla="tabla-licencias" style="margin-bottom:10px;"><?php esc_html_e('Agregar nuevo Tipo de Licencia', 'midas-rrhh'); ?></button>
  <table class="widefat striped midas-table" id="tabla-licencias">
    <thead>
      <tr>
        <th><?php esc_html_e('ID', 'midas-rrhh'); ?></th>
        <th><?php esc_html_e('Tipo', 'midas-rrhh'); ?></th>
        <th><?php esc_html_e('Descripción', 'midas-rrhh'); ?></th>
        <th><?php esc_html_e('Acciones', 'midas-rrhh'); ?></th>
      </tr>
    </thead>
    <tbody><tr><td colspan="4" class="midas-tbody-loader"><?php esc_html_e('Cargando…', 'midas-rrhh'); ?></td></tr></tbody>
  </table>
  <div class="midas-paginacion" data-tabla="tabla-licencias"></div>
</div>

<script>
/* ====== Config ====== */
const MIDAS_CFG = {
  ajax: (window.midas_rrhh && midas_rrhh.ajax_url) || (typeof ajaxurl !== 'undefined' ? ajaxurl : ''),
  nonce: "<?php echo esc_js($nonce_cfg); ?>",
  perPage: 15,
  state: {
    'tabla-tareas':        { page: 1, q: '' },
    'tabla-areas':         { page: 1, q: '' },
    'tabla-enfermedades':  { page: 1, q: '' },
    'tabla-medicos':       { page: 1, q: '' },
    'tabla-licencias':     { page: 1, q: '' }
  },
  aborters: {}
};

/* ===== Helpers mayúsculas/minúsculas ===== */
const ZERO_WIDTH=/[\u200B-\u200D\uFEFF]/g;
function normalizeNFKC(s){ try{return (s||'').normalize('NFKC')}catch(_){return (s||'')} }
const RE_ALLOWED=/[^A-ZÁÉÍÓÚÑ0-9 .,:;¡!¿?\(\)\-_/#+%]/g;
function sanitizeUpper(v,maxLen){ v=normalizeNFKC(String(v||'')).toUpperCase().replace(ZERO_WIDTH,'').replace(RE_ALLOWED,''); if(maxLen&&v.length>maxLen) v=v.slice(0,maxLen); return v; }
function attachUppercaseAndWhitelist(root){
  (root||document).querySelectorAll('input[type="text"],input[type="search"],input:not([type]),textarea').forEach(el=>{
    const max=parseInt(el.getAttribute('maxlength')||'0',10)||null;
    const h=()=>{ el.value=sanitizeUpper(el.value,max); };
    h(); el.addEventListener('input',h); el.addEventListener('blur',h);
  });
}
function forceLowercaseEmail(el){ if(!el) return; const h=()=>{ el.value=String(el.value||'').toLowerCase().trim(); }; h(); el.addEventListener('input',h); el.addEventListener('blur',h); }

/* ===== Escapers mínimos (para construir formularios) ===== */
function h(t){return (t==null?'':String(t)).replace(/[&<>"'`=\/]/g,s=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;","/":"&#47;","`":"&#96;","=":"&#61;"}[s]))}
function hattr(t){return (t==null?'':String(t)).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/'/g,'&#39;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}

/* ===== Render paginación ===== */
function renderPagination(holder, tablaId, page, totalPages){
  holder.innerHTML='';
  if(totalPages<=1) return;
  const mk=(txt,cls,disabled,goPage)=>{ const b=document.createElement('button'); b.textContent=txt; b.className='button'+(cls?(' '+cls):''); if(disabled){b.disabled=true;} b.addEventListener('click',()=>loadTable(tablaId,goPage)); holder.appendChild(b); };
  mk('<?php echo esc_js(__('Anterior','midas-rrhh')); ?>','',page===1, page-1);
  for(let i=1;i<=totalPages;i++){ mk(String(i), i===page?'button-primary':'', false, i); }
  mk('<?php echo esc_js(__('Siguiente','midas-rrhh')); ?>','',page===totalPages, page+1);
}

/* ===== Cargar tabla (AJAX) ===== */
function loadTable(tablaId, page){
  const table=document.getElementById(tablaId);
  if(!table) return;

  const tbody=table.querySelector('tbody');
  const pagDiv=document.querySelector('.midas-paginacion[data-tabla="'+tablaId+'"]');
  const state=MIDAS_CFG.state[tablaId] || (MIDAS_CFG.state[tablaId]={page:1,q:''});
  if(typeof page==='number') state.page=page;

  // Abort si hay en curso
  if(MIDAS_CFG.aborters[tablaId]) MIDAS_CFG.aborters[tablaId].abort();
  const ctrl = new AbortController();
  MIDAS_CFG.aborters[tablaId]=ctrl;

  tbody.classList.add('midas-tbody-loading');
  tbody.innerHTML = '<tr><td colspan="'+table.tHead.rows[0].cells.length+'" class="midas-tbody-loader"><?php echo esc_js(__('Cargando…','midas-rrhh')); ?></td></tr>';
  if(pagDiv) pagDiv.innerHTML='';

  const body = new URLSearchParams({
    action: 'midas_cfg_list',
    nonce: MIDAS_CFG.nonce,
    tabla: tablaId,
    page: String(state.page||1),
    per_page: String(MIDAS_CFG.perPage),
    q: state.q || ''
  });

  fetch(MIDAS_CFG.ajax, {
    method:'POST',
    body,
    credentials:'same-origin',
    signal: ctrl.signal,
    headers:{'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}
  })
  .then(r=>r.json())
  .then(d=>{
    if(!d || !d.success){ throw new Error(d && (d.message||d.data && d.data.message) || 'Error'); }
    tbody.innerHTML=d.data.html || '<tr><td colspan="'+table.tHead.rows[0].cells.length+'"><em><?php echo esc_js(__('Sin datos','midas-rrhh')); ?></em></td></tr>';
    tbody.classList.remove('midas-tbody-loading');
    if(pagDiv) renderPagination(pagDiv, tablaId, d.data.page, d.data.total_pages);
  })
  .catch(err=>{
    if(err.name==='AbortError') return;
    tbody.innerHTML='<tr><td colspan="'+table.tHead.rows[0].cells.length+'">Error</td></tr>';
    tbody.classList.remove('midas-tbody-loading');
    if(pagDiv) pagDiv.innerHTML='';
    console.error('[midas_cfg_list]', err);
  })
  .finally(()=>{ MIDAS_CFG.aborters[tablaId]=null; });
}

/* ===== Buscador (debounce + server) ===== */
function wireSearch(tablaId){
  const input=document.querySelector('.midas-search[data-tabla="'+tablaId+'"]');
  if(!input) return;
  let t;
  input.addEventListener('input', ()=>{
    input.value = sanitizeUpper(input.value, parseInt(input.getAttribute('maxlength')||'0',10) || null);
    clearTimeout(t);
    t=setTimeout(()=>{
      MIDAS_CFG.state[tablaId].q = input.value.trim();
      MIDAS_CFG.state[tablaId].page = 1;
      loadTable(tablaId, 1);
    }, 260);
  });
}

/* ===== Inicialización ===== */
document.addEventListener('DOMContentLoaded', function(){
  attachUppercaseAndWhitelist(document);
  forceLowercaseEmail(document.getElementById('from_email'));

  // Tabs
  const tabs = document.querySelectorAll('.midas-tabs .nav-tab-wrapper a');
  const tabContents = document.querySelectorAll('.midas-tab-content');
  tabs.forEach(tab=>{
    tab.addEventListener('click', function(e){
      e.preventDefault();
      tabs.forEach(t=>t.classList.remove('nav-tab-active'));
      tabContents.forEach(c=>c.style.display='none');
      tab.classList.add('nav-tab-active');
      const target = tab.getAttribute('href');
      document.querySelector(target).style.display='block';
      // al cambiar de tab, recargar su tabla si está vacía
      const tableInTab = document.querySelector(target+' table.midas-table');
      if(tableInTab && tableInTab.querySelector('tbody .midas-tbody-loader')) {
        loadTable(tableInTab.id, 1);
      }
    });
  });

  // Cargar todas las tablas
  ['tabla-tareas','tabla-areas','tabla-enfermedades','tabla-medicos','tabla-licencias'].forEach(id=>{
    wireSearch(id);
    loadTable(id, 1);
  });

  /* ===== MODALES ===== */
  const modal = document.getElementById('midas-modal-agregar');
  const modalEliminar = document.getElementById('midas-modal-eliminar');
  const form = document.getElementById('midas-form-agregar');
  const formContenido = document.getElementById('midas-form-contenido');
  const formTabla = document.getElementById('midas-form-tabla');
  const formId = document.getElementById('midas-form-id');
  const formEliminar = document.getElementById('midas-form-eliminar');
  const formEliminarTabla = document.getElementById('eliminar-form-tabla');
  const formEliminarId = document.getElementById('eliminar-form-id');

  // Roles para selects (renderizados por PHP)
  const rolesSelectHtml = `<?php foreach ($roles as $key => $role) { echo '<option value="'.esc_attr($key).'">'.esc_html($role['name']).'</option>'; } ?>`;

  // abrir modal agregar
  document.querySelectorAll('.midas-btn-agregar').forEach(btn=>{
    btn.addEventListener('click', function(){
      const tabla = btn.getAttribute('data-tabla');
      formTabla.value = tabla; formId.value = '';
      let html='';
      if (tabla === 'tabla-tareas') {
        html = `<div id="form-crear-label"><b>Agregar nueva Tarea</b></div>
        <label>Nombre:</label><br><input type="text" name="nombre" class="regular-text" required maxlength="255"><br>
        <label>Descripción:</label><br><textarea name="descripcion" rows="2" class="regular-text" required maxlength="1000"></textarea><br>
        <label>Estado:</label><br><select name="activo" class="regular-text"><option value="1">Activo</option><option value="0">Inactivo</option></select>`;
      } else if (tabla === 'tabla-areas') {
        html = `<div id="form-crear-label"><b>Agregar nueva Área</b></div>
        <label>Nombre:</label><br><input type="text" name="nombre" class="regular-text" required maxlength="255"><br>
        <label>Rol:</label><br><select name="rol" class="regular-text">${rolesSelectHtml}</select><br>
        <label>Estado:</label><br><select name="activo" class="regular-text"><option value="1">Activo</option><option value="0">Inactivo</option></select>`;
      } else if (tabla === 'tabla-enfermedades') {
        html = `<div id="form-crear-label"><b>Agregar nueva Enfermedad</b></div>
        <label>Tipo:</label><br><input type="text" name="tipo" class="regular-text" required maxlength="255"><br>
        <label>Descripción:</label><br><textarea name="descripcion" rows="2" class="regular-text" required maxlength="1000"></textarea>`;
      } else if (tabla === 'tabla-medicos') {
        html = `<div id="form-crear-label"><b>Agregar nuevo Médico</b></div>
        <label>Nombre:</label><br><input type="text" name="nombre" class="regular-text" required maxlength="255"><br>
        <label>Apellido:</label><br><input type="text" name="apellido" class="regular-text" required maxlength="255"><br>
        <label>Especialidad:</label><br><input type="text" name="especialidad" class="regular-text" maxlength="255"><br>
        <label>Matrícula:</label><br><input type="text" name="matricula" class="regular-text" maxlength="255">`;
      } else if (tabla === 'tabla-licencias') {
        html = `<div id="form-crear-label"><b>Agregar nuevo Tipo de Licencia</b></div>
        <label>Tipo:</label><br><input type="text" name="tipo" class="regular-text" required maxlength="255"><br>
        <label>Descripción:</label><br><textarea name="descripcion" rows="2" class="regular-text" required maxlength="1000"></textarea>`;
      }
      formContenido.innerHTML = html;
      attachUppercaseAndWhitelist(formContenido);
      modal.style.display='flex';
    });
  });

  // abrir modal editar (toma valores de la fila)
  document.body.addEventListener('click', function(e){
    if (!e.target.classList.contains('midas-btn-editar')) return;
    const btn=e.target, tabla=btn.getAttribute('data-tabla'), id=btn.getAttribute('data-id');
    formTabla.value=tabla; formId.value=id;
    const tr=btn.closest('tr'); const td=tr.querySelectorAll('td'); let html='';
    if (tabla==='tabla-tareas') {
      html=`<div id="form-crear-label"><b>Editar Tarea</b></div>
      <label>Nombre:</label><br><input type="text" name="nombre" class="regular-text" required maxlength="255" value="${hattr(td[1].textContent)}"><br>
      <label>Descripción:</label><br><textarea name="descripcion" rows="2" class="regular-text" required maxlength="1000">${h(td[2].textContent)}</textarea><br>
      <label>Estado:</label><br><select name="activo" class="regular-text">
        <option value="1"${td[3].textContent.trim()==='Activo'?' selected':''}>Activo</option>
        <option value="0"${td[3].textContent.trim()!=='Activo'?' selected':''}>Inactivo</option></select>`;
    } else if (tabla==='tabla-areas') {
      const rolVal=td[2].textContent.trim();
      html=`<div id="form-crear-label"><b>Editar Área</b></div>
      <label>Nombre:</label><br><input type="text" name="nombre" class="regular-text" required maxlength="255" value="${hattr(td[1].textContent)}"><br>
      <label>Rol:</label><br><select name="rol" class="regular-text">${rolesSelectHtml.replace('value="'+rolVal+'"','value="'+hattr(rolVal)+'" selected')}</select><br>
      <label>Estado:</label><br><select name="activo" class="regular-text">
        <option value="1"${td[3].textContent.trim()==='Activo'?' selected':''}>Activo</option>
        <option value="0"${td[3].textContent.trim()!=='Activo'?' selected':''}>Inactivo</option></select>`;
    } else if (tabla==='tabla-enfermedades') {
      html=`<div id="form-crear-label"><b>Editar Enfermedad</b></div>
      <label>Tipo:</label><br><input type="text" name="tipo" class="regular-text" required maxlength="255" value="${hattr(td[1].textContent)}"><br>
      <label>Descripción:</label><br><textarea name="descripcion" rows="2" class="regular-text" required maxlength="1000">${h(td[2].textContent)}</textarea>`;
    } else if (tabla==='tabla-medicos') {
      html=`<div id="form-crear-label"><b>Editar Médico</b></div>
      <label>Nombre:</label><br><input type="text" name="nombre" class="regular-text" required maxlength="255" value="${hattr(td[1].textContent)}"><br>
      <label>Apellido:</label><br><input type="text" name="apellido" class="regular-text" required maxlength="255" value="${hattr(td[2].textContent)}"><br>
      <label>Especialidad:</label><br><input type="text" name="especialidad" class="regular-text" maxlength="255" value="${hattr(td[3].textContent)}"><br>
      <label>Matrícula:</label><br><input type="text" name="matricula" class="regular-text" maxlength="255" value="${hattr(td[4].textContent)}">`;
    } else if (tabla==='tabla-licencias') {
      html=`<div id="form-crear-label"><b>Editar Tipo de Licencia</b></div>
      <label>Tipo:</label><br><input type="text" name="tipo" class="regular-text" required maxlength="255" value="${hattr(td[1].textContent)}"><br>
      <label>Descripción:</label><br><textarea name="descripcion" rows="2" class="regular-text" required maxlength="1000">${h(td[2].textContent)}</textarea>`;
    }
    formContenido.innerHTML = html;
    attachUppercaseAndWhitelist(formContenido);
    modal.style.display='flex';
  });

  // cerrar modales
  document.querySelectorAll('.midas-modal-cerrar').forEach(btn=>{
    btn.addEventListener('click', ()=> btn.closest('.midas-modal-cuerpo').parentElement.style.display='none');
  });
  document.getElementById('cancelar-eliminar').addEventListener('click', e=>{ e.preventDefault(); modalEliminar.style.display='none'; });
  window.addEventListener('click', e=>{
    if(e.target===modal) modal.style.display='none';
    if(e.target===modalEliminar) modalEliminar.style.display='none';
  });

  // abrir eliminar
  document.body.addEventListener('click', function(e){
    if (!e.target.classList.contains('midas-btn-eliminar')) return;
    const btn=e.target;
    formEliminarTabla.value = btn.getAttribute('data-tabla');
    formEliminarId.value    = btn.getAttribute('data-id');
    modalEliminar.style.display='flex';
  });

  // guardar (agregar/editar)
  form.addEventListener('submit', function(e){
    e.preventDefault();
    const tabla = formTabla.value;
    const fd = new FormData(form);
    const actionName = formId.value ? 'midas_editar_configuracion' : 'midas_agregar_configuracion';
    fd.append('action', actionName);
    fd.append('nonce', MIDAS_CFG.nonce); // ⬅️ IMPORTANTE: nonce

    fetch(MIDAS_CFG.ajax, { method:'POST', body:fd, credentials:'same-origin' })
      .then(r=>r.json())
      .then(d=>{
        if(!d || !d.success){ throw new Error((d && (d.message||d.data&&d.data.message)) || 'Error'); }
        modal.style.display='none'; form.reset();
        // refrescar tabla actual
        loadTable(tabla, MIDAS_CFG.state[tabla].page || 1);
      })
      .catch(err=> alert((err && err.message) || String(err)));
  });

  // eliminar
  formEliminar.addEventListener('submit', function(e){
    e.preventDefault();
    const tabla = formEliminarTabla.value;
    const fd = new FormData(formEliminar);
    fd.append('action','midas_eliminar_configuracion');
    fd.append('nonce', MIDAS_CFG.nonce); // ⬅️ IMPORTANTE: nonce
    fetch(MIDAS_CFG.ajax, { method:'POST', body:fd, credentials:'same-origin' })
      .then(r=>r.json())
      .then(d=>{
        if(!d || !d.success){ throw new Error((d && (d.message||d.data&&d.data.message)) || 'Error'); }
        modalEliminar.style.display='none';
        loadTable(tabla, MIDAS_CFG.state[tabla].page || 1);
      })
      .catch(err=> alert((err && err.message) || String(err)));
  });
});
</script>
