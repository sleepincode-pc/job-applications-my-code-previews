<?php if (!defined('ABSPATH')) exit; ?>
<?php
$ajax_url = admin_url('admin-ajax.php');
$nonce    = wp_create_nonce('midas_orgchart_nonce');
?>
<div class="wrap midas-orgchart-wrap" id="midasOrgchartWrap">
  <h1 style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
    <?php esc_html_e('Organigrama', 'midas-rrhh'); ?>
    <span class="dashicons dashicons-networking" style="font-size:24px;line-height:1;"></span>
  </h1>

  <div class="midas-org-toolbar">
    <button type="button" class="button" id="org-new">Nuevo</button>
    <button type="button" class="button" id="org-load">Restaurar guardado</button>
    <button type="button" class="button button-primary" id="org-save">Guardar</button>
    <button type="button" class="button" id="org-save-local">Guardar versión</button>
    <span class="sep"></span>

    <button type="button" class="button" id="org-add-free">Añadir cuadro</button>
    <button type="button" class="button" id="org-add-child" disabled>Añadir hijo</button>
    <button type="button" class="button" id="org-connect" disabled>Conectar ➜</button>
    <button type="button" class="button" id="org-link" disabled>Flecha +</button>
    <button type="button" class="button" id="org-link-hr" disabled>Flecha HR</button>
    <button type="button" class="button" id="org-delete-node" disabled>Eliminar nodo</button>

    <span class="sep"></span>
    <button type="button" class="button" id="org-export-json">Exportar JSON</button>
    <label class="org-import-label button">
      Importar JSON
      <input type="file" id="org-import-json" accept="application/json" hidden>
    </label>
    <button type="button" class="button" id="org-download-png">Descargar PNG</button>
    <span id="org-status" class="org-status" aria-live="polite"></span>
  </div>

  <div class="midas-org-editor">
    <div id="orgchart">
      <svg id="org-edges" xmlns="http://www.w3.org/2000/svg"></svg>
      <div id="edge-btns"></div>
      <div id="org-nodes"></div>
    </div>

    <div class="org-side">
      <h3>Propiedades del nodo</h3>
      <div class="org-form">
        <label>ID
          <input type="text" id="f-id" placeholder="id único" readonly>
        </label>
        <label>Nombre
          <input type="text" id="f-name" placeholder="Ej.: Juan Pérez">
        </label>
        <label>Puesto / Título
          <input type="text" id="f-title" placeholder="Ej.: Gerente de RRHH">
        </label>
        <label>Color
          <input type="color" id="f-color" value="#1f2937">
        </label>
        <div class="small">
          Click en un nodo para editar y arrastrá para mover.<br>
          Uní nodos con <b>Conectar ➜</b> (jerárquica), <b>Flecha +</b> (extra punteada) y <b>Flecha HR</b> (mentoría).<br>
          También podés tocar una <b>línea</b> para conectar con su destino: <b>Shift</b>=jerárquica, <b>Alt</b>=HR, sin tecla=extra.
        </div>
        <button type="button" class="button button-primary" id="org-apply" disabled>Aplicar cambios</button>
      </div>
      <details style="margin-top:12px;">
        <summary>JSON (solo lectura)</summary>
        <textarea id="tree-json" readonly rows="10" style="width:100%;font-family:monospace;"></textarea>
      </details>
    </div>
  </div>

  <div class="org-saves">
    <h3>Versiones guardadas (local)</h3>
    <div id="saves-list" class="saves-list"></div>
  </div>
</div>

<style>
.midas-org-toolbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:10px 0 14px;}
.midas-org-toolbar .sep{width:1px;height:24px;background:#d1d5db;margin:0 6px;}
.midas-org-toolbar .org-status{margin-left:auto;font-weight:600;color:#475569;}
.midas-org-editor{display:grid;grid-template-columns:1fr 320px;gap:12px;}
#orgchart{
  min-height:560px;border:1px dashed #d1d5db;border-radius:8px;background:#fff;
  overflow:auto; position:relative;
}
/* stacking: SVG debajo de nodos para no bloquear el arrastre */
#org-edges{ position:absolute; inset:0; width:2000px; height:1400px; z-index:1; }
#org-nodes{ position:relative; width:2000px; height:1400px; z-index:2; }
#edge-btns{ position:absolute; inset:0; width:2000px; height:1400px; z-index:3; pointer-events:none; }

/* nodos */
.node{
  position:absolute; min-width:190px; max-width:240px;
  background:#f8fafc; color:#0f172a; border:2px solid #cbd5e1; border-radius:12px;
  box-shadow:0 1px 3px rgba(0,0,0,.08); cursor:grab; user-select:none;
}
.node:active{ cursor:grabbing; }
.node .title{color:#fff;font-weight:700;padding:8px 10px;border-radius:10px 10px 0 0;}
.node .content{padding:8px 10px;}
.node .tools{position:absolute; top:-8px; right:-8px; display:flex; gap:4px;}
.mini-btn{padding:0 6px;height:20px;font-size:11px;line-height:20px;border-radius:6px;border:1px solid #cbd5e1;background:#fff;}
.node.selected{box-shadow:0 0 0 2px #3b82f6 inset, 0 1px 6px rgba(0,0,0,.15);}

/* flechas */
.edge-path{fill:none; stroke:#64748b; stroke-width:2.2px; pointer-events:stroke;}
.edge-dashed{stroke-dasharray:6 6;}
.edge-hr{stroke:#16a34a; stroke-width:2.2px; stroke-dasharray:2 6;}
#org-edges defs marker#arrow>path{ fill:#64748b; }
#org-edges defs marker#arrow-hr>path{ fill:#16a34a; }

/* botones sobre flecha */
.edge-plus, .edge-insert, .edge-target{
  position:absolute; width:18px; height:18px; border-radius:50%;
  background:#fff; border:1.6px solid #64748b; color:#64748b; font-weight:700;
  line-height:16px; text-align:center; cursor:pointer; pointer-events:auto;
  transform:translate(-50%,-50%);
}
.edge-insert{ border-style:dashed; }
.edge-target{ font-size:12px; }

/* panel guardados */
.org-side{border:1px solid #d1d5db;border-radius:8px;padding:12px;background:#fff;}
.org-form label{display:block;margin:8px 0;font-weight:600;}
.org-form input{width:100%;}
.org-form .small{color:#6b7280;font-size:12px;margin-top:6px;}
.org-import-label{position:relative;overflow:hidden;}
.org-import-label input[type=file]{position:absolute;inset:0;opacity:0;cursor:pointer;}
@media (max-width:1100px){ .midas-org-editor{grid-template-columns:1fr;} .org-side{order:-1;} }

.org-saves{margin-top:18px;}
.saves-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:10px;}
.save-card{border:1px solid #e5e7eb;border-radius:10px;padding:10px;background:#fff;display:flex;flex-direction:column;gap:8px}
.save-title{font-weight:700}
.save-actions{display:flex;flex-wrap:wrap;gap:6px}
.save-actions .button{height:28px;line-height:26px;padding:0 8px}
.save-meta{color:#6b7280;font-size:12px}
.muted{color:#9ca3af}
</style>

<script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>

<script>
jQuery(function($){
  const AJAX  = <?= wp_json_encode($ajax_url) ?>;
  const NONCE = <?= wp_json_encode($nonce) ?>;

  let chartData  = null;
  let selectedId = null;
  let connectMode = false;   // jerárquica
  let linkMode    = false;   // extra (punteada)
  let hrLinkMode  = false;   // HR (verde)
  let connectSource = null;

  const $status = $('#org-status');
  const setStatus = t => $status.text(t||'');

  /* ==== Datos / helpers ==== */
  const makeDefaultTree = () => ({
    id:'root', name:'Empresa', title:'Dirección General',
    color:'#1f2937',
    pos:{x:80,y:60}, links:[], hrLinks:[], children:[]
  });
  const uid = ()=>'n_'+Math.random().toString(36).slice(2,9);
  const defaultColor = (ref)=> (ref && ref.color) || (chartData && chartData.color) || '#1f2937';

  const normalize = (n)=>{
    if (!n || typeof n!=='object') return makeDefaultTree();
    n.id=String(n.id||uid());
    n.name=String(n.name||'Sin nombre');
    n.title= typeof n.title==='string'? n.title: '';
    n.color=/^#([0-9a-f]{3}){1,2}$/i.test(n.color||'')? n.color:'#1f2937';
    n.pos=n.pos&&typeof n.pos.x==='number'&&typeof n.pos.y==='number'? n.pos : {x:100,y:100};
    n.links=Array.isArray(n.links)? Array.from(new Set(n.links.map(String))):[];
    n.hrLinks=Array.isArray(n.hrLinks)? Array.from(new Set(n.hrLinks.map(String))):[];
    n.orphan=!!n.orphan;
    n.children=Array.isArray(n.children)? n.children.map(normalize):[];
    return n;
  };
  const ensureTree = t=> normalize(t||makeDefaultTree());
  const walk = (node,fn,parent=null)=>{ if(!node) return false; if(fn(node,parent)===false) return false; if(Array.isArray(node.children)) for(const ch of node.children){ if(walk(ch,fn,node)===false) return false;} return true; };
  const findById=(id)=>{ let hit=null,parent=null; walk(chartData,(n,p)=>{ if(n.id===id){ hit=n; parent=p; return false; } }); return {node:hit,parent}; };
  const isDescendant=(aId,bId)=>{ let yes=false; const {node:a}=findById(aId); walk(a,(n)=>{ if(n.id===bId){ yes=true; return false; } }); return yes; };
  const removeFromParent=(id)=>{ const {node,parent}=findById(id); if(!node||!parent) return null; parent.children=parent.children.filter(ch=>ch.id!==id); return node; };
  const moveAsChild=(childId,newParentId)=>{ if(childId===newParentId) return false; if(childId===chartData.id) return false; if(isDescendant(childId,newParentId)) return false; const moved=removeFromParent(childId); if(!moved) return false; const {node:p}=findById(newParentId); if(!p) return false; p.children=p.children||[]; moved.pos={x:p.pos.x+240+Math.round(Math.random()*40-20), y:p.pos.y+100+Math.round(Math.random()*40-20)}; moved.orphan=false; moved.color=moved.color||defaultColor(p); p.children.push(moved); return true; };
  const addLink=(src,dst)=>{ const {node:s}=findById(src); if(!s) return false; s.links=s.links||[]; if(!s.links.includes(dst)) s.links.push(dst); return true; };
  const addHrLink=(src,dst)=>{ const {node:s}=findById(src); if(!s) return false; s.hrLinks=s.hrLinks||[]; if(!s.hrLinks.includes(dst)) s.hrLinks.push(dst); return true; };
  const removeLinksTo=(victimId)=>{ walk(chartData,(n)=>{ n.links=(n.links||[]).filter(t=>t!==victimId); n.hrLinks=(n.hrLinks||[]).filter(t=>t!==victimId); }); };
  const syncJsonViewer=()=> $('#tree-json').val(JSON.stringify(chartData,null,2));

  /* ==== Render ==== */
  const $nodes=$('#org-nodes'), $svg=$('#org-edges'), $edgeBtns=$('#edge-btns');

  const svgEnsureDefs=()=>{
    if ($svg.find('defs').length) return;
    const defs=document.createElementNS('http://www.w3.org/2000/svg','defs');

    const m1=document.createElementNS('http://www.w3.org/2000/svg','marker');
    m1.setAttribute('id','arrow'); m1.setAttribute('markerWidth','10'); m1.setAttribute('markerHeight','7');
    m1.setAttribute('refX','10'); m1.setAttribute('refY','3.5'); m1.setAttribute('orient','auto');
    const p1=document.createElementNS('http://www.w3.org/2000/svg','path'); p1.setAttribute('d','M0,0 L10,3.5 L0,7 Z'); m1.appendChild(p1);

    const m2=document.createElementNS('http://www.w3.org/2000/svg','marker');
    m2.setAttribute('id','arrow-hr'); m2.setAttribute('markerWidth','10'); m2.setAttribute('markerHeight','7');
    m2.setAttribute('refX','10'); m2.setAttribute('refY','3.5'); m2.setAttribute('orient','auto');
    const p2=document.createElementNS('http://www.w3.org/2000/svg','path'); p2.setAttribute('d','M0,0 L10,3.5 L0,7 Z'); m2.appendChild(p2);

    defs.appendChild(m1); defs.appendChild(m2); $svg[0].appendChild(defs);
  };

  function cubicPoint(t, P0, P1, P2, P3){
    const u=1-t;
    return {
      x: u*u*u*P0.x + 3*u*u*t*P1.x + 3*u*t*t*P2.x + t*t*t*P3.x,
      y: u*u*u*P0.y + 3*u*u*t*P1.y + 3*u*t*t*P2.y + t*t*t*P3.y
    };
  }

  const drawEdges=()=>{
    svgEnsureDefs();
    $svg.find('path').remove();
    $edgeBtns.empty();

    const makeEdge=(srcId,dstId,a,b,type='tree')=>{
      const midY=(a.y+b.y)/2, c1={x:a.x,y:midY}, c2={x:b.x,y:midY};
      const d=`M ${a.x} ${a.y} C ${c1.x} ${c1.y}, ${c2.x} ${c2.y}, ${b.x} ${b.y}`;

      const p=document.createElementNS('http://www.w3.org/2000/svg','path');
      p.setAttribute('d',d);
      p.dataset.src=srcId; p.dataset.dst=dstId; p.dataset.type=type;
      p.classList.add('edge-path','edge-click');
      if (type==='tree'){ p.setAttribute('marker-end','url(#arrow)'); }
      else if (type==='link'){ p.classList.add('edge-dashed'); p.setAttribute('marker-end','url(#arrow)'); }
      else { p.classList.add('edge-hr'); p.setAttribute('marker-end','url(#arrow-hr)'); }
      $svg[0].appendChild(p);

      const m=cubicPoint(0.5,a,c1,c2,b);

      const plus=document.createElement('button');
      plus.className='edge-plus'; plus.textContent='+'; plus.title='Conectar desde el origen';
      plus.dataset.src=srcId; plus.style.left=m.x+'px'; plus.style.top=m.y+'px'; $edgeBtns[0].appendChild(plus);

      const ins=document.createElement('button');
      ins.className='edge-insert'; ins.textContent='⊕'; ins.title='Insertar nodo intermedio';
      ins.dataset.src=srcId; ins.dataset.dst=dstId; ins.dataset.type=type;
      ins.style.left=(m.x+22)+'px'; ins.style.top=m.y+'px'; $edgeBtns[0].appendChild(ins);

      const tgt=document.createElement('button');
      tgt.className='edge-target'; tgt.textContent='→'; tgt.title='Conectar seleccionado → destino (Shift=jerárquica, Alt=HR)';
      tgt.dataset.dst=dstId; tgt.style.left=(m.x-22)+'px'; tgt.style.top=m.y+'px'; $edgeBtns[0].appendChild(tgt);
    };

    const getCenter=id=>{
      const el=$nodes.find('.node[data-id="'+id+'"]')[0];
      if (!el) return {x:0,y:0};
      return {x: el.offsetLeft+el.offsetWidth/2, y: el.offsetTop+el.offsetHeight/2};
    };

    walk(chartData,(n)=>{
      (n.children||[]).forEach(ch=>{
        if (ch.orphan) return;
        makeEdge(n.id,ch.id,getCenter(n.id),getCenter(ch.id),'tree');
      });
      (n.links||[]).forEach(t=>{
        makeEdge(n.id,t,getCenter(n.id),getCenter(t),'link');
      });
      (n.hrLinks||[]).forEach(t=>{
        makeEdge(n.id,t,getCenter(n.id),getCenter(t),'hr');
      });
    });
  };

  const renderNodes=()=>{
    $nodes.empty();
    const build=n=>{
      const $el=$(`
        <div class="node" data-id="${n.id}">
          <div class="title"></div>
          <div class="content"></div>
          <div class="tools">
            <button class="mini-btn btn-add" title="Añadir hijo">+</button>
            <button class="mini-btn btn-del" title="Eliminar">×</button>
          </div>
        </div>
      `);
      $el.css({left:n.pos.x+'px', top:n.pos.y+'px', borderColor:n.color});
      $el.find('.title').text(n.name||'').css('background', n.color);
      $el.find('.content').text(n.title||'');
      $nodes.append($el);
      (n.children||[]).forEach(build);
    };
    build(chartData);
    if (selectedId) highlightSelection();
    drawEdges();
    syncJsonViewer();
  };

  const highlightSelection=()=>{
    $nodes.find('.node').removeClass('selected');
    if (selectedId) $nodes.find('.node[data-id="'+selectedId+'"]').addClass('selected');
    toggleButtons();
  };

  const selectNode=id=>{
    selectedId=id;
    const {node}=findById(id);
    if (!node) return;
    $('#f-id').val(node.id);
    $('#f-name').val(node.name||'');
    $('#f-title').val(node.title||'');
    $('#f-color').val(node.color||'#1f2937');
    setStatus(id===chartData.id ? 'Nodo raíz seleccionado.' : 'Nodo seleccionado.');
    highlightSelection();
  };

  /* ==== Crear nodos (heredan color) ==== */
  const addChild=parentId=>{
    const {node:parent}=findById(parentId);
    const ref=parent||chartData;
    connectMode=false; linkMode=false; hrLinkMode=false; connectSource=null; toggleButtons();

    const child={
      id:uid(), name:'Nuevo integrante', title:'Puesto',
      color: defaultColor(ref),
      pos:{x:ref.pos.x+240+Math.round(Math.random()*20-10), y:ref.pos.y+120+Math.round(Math.random()*20-10)},
      links:[], hrLinks:[], orphan:true, children:[]
    };
    chartData.children=chartData.children||[];
    chartData.children.push(child);
    renderNodes(); selectNode(child.id);
    setStatus('Cuadro añadido (sin conexión). Usá Conectar/Flecha/HR para vincular.');
  };

  const addFreeNode=()=>{
    connectMode=false; linkMode=false; hrLinkMode=false; connectSource=null; toggleButtons();
    const child={
      id:uid(), name:'Nuevo integrante', title:'Puesto',
      color: defaultColor(chartData),
      pos:{x:160+Math.round(Math.random()*400), y:140+Math.round(Math.random()*240)},
      links:[], hrLinks:[], orphan:true, children:[]
    };
    chartData.children=chartData.children||[];
    chartData.children.push(child);
    renderNodes(); selectNode(child.id);
    setStatus('Cuadro añadido (sin conexión).');
  };

  const deleteNode=id=>{
    if (chartData && chartData.id===id){ setStatus('No se puede eliminar la raíz.'); return; }
    removeLinksTo(id);
    const {parent}=findById(id);
    if (!parent || !Array.isArray(parent.children)) return;
    parent.children=parent.children.filter(n=>n.id!==id);
    renderNodes(); selectNode(chartData.id);
    $('#f-id,#f-name,#f-title').val('');
    setStatus('Nodo eliminado.');
  };

  const toggleButtons=()=>{
    const has=!!selectedId;
    $('#org-apply,#org-add-child,#org-delete-node,#org-connect,#org-link,#org-link-hr').prop('disabled', !has);
    $('#org-connect').toggleClass('button-primary', connectMode && !linkMode && !hrLinkMode);
    $('#org-link').toggleClass('button-primary', linkMode);
    $('#org-link-hr').toggleClass('button-primary', hrLinkMode);
  };

  /* ==== Interacción con nodos ==== */
  $nodes.on('click','.node', function(e){
    e.stopPropagation();
    const id=$(this).data('id');

    if (connectMode){
      if (!connectSource){ connectSource=selectedId||id; setStatus('Elegí el nodo destino.'); return; }
      if (connectSource===id){ setStatus('No podés conectar un nodo consigo mismo.'); return; }

      let ok=false;
      if (linkMode||hrLinkMode){
        ok = hrLinkMode ? addHrLink(connectSource, id) : addLink(connectSource, id);
        setStatus(ok?'Conexión creada.':'No se pudo conectar.');
      } else {
        if (connectSource===chartData.id){ setStatus('La raíz no puede cambiar de padre.'); return; }
        if (isDescendant(connectSource, id)){ setStatus('No podés conectar con un descendiente.'); return; }
        ok = moveAsChild(connectSource, id);
        setStatus(ok?'Conectado ✓':'No se pudo conectar.');
      }
      const back=connectSource; connectMode=false; linkMode=false; hrLinkMode=false; connectSource=null;
      renderNodes(); selectNode(back);
      return;
    }

    selectNode(id);
  });

  $nodes.on('click','.btn-add', function(e){ e.stopPropagation(); const id=$(this).closest('.node').data('id'); addChild(id); });
  $nodes.on('click','.btn-del', function(e){ e.stopPropagation(); const id=$(this).closest('.node').data('id'); if(confirm('¿Eliminar este nodo?')) deleteNode(id); });

  /* ==== Botones sobre flechas ==== */
  $('#edge-btns').on('click','.edge-plus', function(e){
    e.stopPropagation();
    const src=this.dataset.src;
    const {node}=findById(src);
    linkMode=true; hrLinkMode=false; connectMode=true; connectSource=src; toggleButtons();
    setStatus(`Modo flecha extra desde “${node?.name||src}”: elegí el destino.`);
  });

  $('#edge-btns').on('click','.edge-insert', function(e){
    e.stopPropagation();
    const src=this.dataset.src, dst=this.dataset.dst, type=this.dataset.type;
    const x=parseFloat(this.style.left), y=parseFloat(this.style.top);
    const midNode={ id:uid(), name:'Nuevo integrante', title:'Puesto', color: defaultColor(findById(src).node||chartData),
      pos:{x:x-90, y:y-30}, links:[], hrLinks:[], orphan:false, children:[] };

    if (type==='tree'){
      const {node:s}=findById(src); const {node:child,parent:par}=findById(dst); if(!s||!child||!par) return;
      par.children=par.children.filter(n=>n.id!==dst); s.children=s.children||[]; s.children.push(midNode); midNode.children.push(child);
    }else if(type==='link'){
      const {node:s}=findById(src); if(!s) return;
      s.links=(s.links||[]).filter(t=>t!==dst); chartData.children=chartData.children||[]; chartData.children.push(midNode); s.links.push(midNode.id); midNode.links.push(dst);
    }else{
      const {node:s}=findById(src); if(!s) return;
      s.hrLinks=(s.hrLinks||[]).filter(t=>t!==dst); chartData.children=chartData.children||[]; chartData.children.push(midNode); s.hrLinks.push(midNode.id); midNode.hrLinks.push(dst);
    }
    renderNodes(); selectNode(midNode.id); setStatus('Nodo intermedio insertado.');
  });

  $('#edge-btns').on('click','.edge-target', function(e){
    e.stopPropagation();
    const dst=this.dataset.dst;
    let src = connectMode && connectSource ? connectSource : selectedId;
    if (!src || src===dst) return;

    let ok=false;
    if (e.altKey){ ok=addHrLink(src,dst); setStatus('Conexión HR creada.'); }
    else if (e.shiftKey){ if(src===chartData.id||isDescendant(src,dst)){ setStatus('No válido como jerárquico.'); return; } ok=moveAsChild(src,dst); setStatus(ok?'Conectado (jerárquico).':'No se pudo conectar.'); }
    else { ok=addLink(src,dst); setStatus('Conexión extra creada.'); }

    connectMode=false; linkMode=false; hrLinkMode=false; connectSource=null;
    renderNodes(); selectNode(src);
  });

  /* ==== NUEVO: click en la línea para conectar al DESTINO ==== */
  $('#org-edges').on('click','path.edge-click', function(e){
    const dst=this.dataset.dst, type=this.dataset.type;
    let src = connectMode && connectSource ? connectSource : selectedId;
    if (!src || src===dst) return;

    // Modos con teclas: Alt=HR, Shift=jerárquica, Default=extra
    if (e.altKey){
      addHrLink(src,dst); setStatus('Conexión HR creada (click en línea).');
    }else if(e.shiftKey){
      if(src===chartData.id||isDescendant(src,dst)){ setStatus('No válido como jerárquico.'); return; }
      const ok=moveAsChild(src,dst); setStatus(ok?'Conectado (jerárquico, clic en línea).':'No se pudo conectar.');
    }else{
      addLink(src,dst); setStatus('Conexión extra creada (clic en línea).');
    }
    connectMode=false; linkMode=false; hrLinkMode=false; connectSource=null;
    renderNodes(); selectNode(src);
  });

  /* ==== Arrastrar ==== */
  let drag=null;
  $nodes.on('mousedown','.node', function(e){
    const id=$(this).data('id'); const {node}=findById(id); if(!node) return;
    drag={ id, startX:e.pageX, startY:e.pageY, origX:node.pos.x, origY:node.pos.y };
    $(document).on('mousemove.orgdrag', onDrag); $(document).on('mouseup.orgdrag', endDrag);
  });
  function onDrag(e){
    if (!drag) return;
    const {node}=findById(drag.id); if(!node) return;
    node.pos.x=Math.max(0, drag.origX+(e.pageX-drag.startX));
    node.pos.y=Math.max(0, drag.origY+(e.pageY-drag.startY));
    $nodes.find('.node[data-id="'+drag.id+'"]').css({left:node.pos.x+'px', top:node.pos.y+'px'});
    drawEdges();
  }
  function endDrag(){ $(document).off('.orgdrag'); drag=null; syncJsonViewer(); }

  $('#orgchart').on('click', function(){ selectedId=null; highlightSelection(); $('#f-id,#f-name,#f-title').val(''); });

  /* ==== Guardados locales ==== */
  const LS_KEY='midas_org_saves_v1';
  const clone=o=>JSON.parse(JSON.stringify(o||{}));
  const loadLocalSaves=()=>{ try{return JSON.parse(localStorage.getItem(LS_KEY)||'[]');}catch(e){return[];} };
  const writeLocalSaves=arr=>localStorage.setItem(LS_KEY, JSON.stringify(arr));
  const fmtDate=ts=>new Date(ts).toLocaleString();

  function saveSnapshot(name){
    const saves=loadLocalSaves();
    const nm=name||prompt('Nombre de la versión','Versión '+new Date().toLocaleString())||('Versión '+new Date().toLocaleString());
    saves.unshift({ id:uid(), name:nm, ts:Date.now(), tree:clone(chartData) });
    writeLocalSaves(saves); renderSaves(); setStatus('Versión guardada localmente.');
  }
  function renderSaves(){
    const $list=$('#saves-list').empty();
    const saves=loadLocalSaves();
    if(!saves.length){ $list.html('<div class="muted">No hay versiones guardadas.</div>'); return; }
    saves.forEach(sv=>{
      const $c=$(`
        <div class="save-card" data-id="${sv.id}">
          <div class="save-title">${sv.name}</div>
          <div class="save-meta">${fmtDate(sv.ts)}</div>
          <div class="save-actions">
            <button class="button button-primary act-load">Cargar</button>
            <button class="button act-rename">Renombrar</button>
            <button class="button act-export">Exportar</button>
            <button class="button act-delete">Eliminar</button>
          </div>
        </div>
      `);
      $list.append($c);
    });
  }
  $('#saves-list').on('click','.act-load', function(){
    const id=$(this).closest('.save-card').data('id');
    const sv=loadLocalSaves().find(x=>x.id===id); if(!sv) return;
    chartData=ensureTree(clone(sv.tree)); renderNodes(); selectNode(chartData.id); setStatus('Versión cargada.');
  });
  $('#saves-list').on('click','.act-rename', function(){
    const id=$(this).closest('.save-card').data('id'); const saves=loadLocalSaves(); const sv=saves.find(x=>x.id===id); if(!sv) return;
    const nm=prompt('Nuevo nombre', sv.name)||sv.name; sv.name=nm; writeLocalSaves(saves); renderSaves();
  });
  $('#saves-list').on('click','.act-export', function(){
    const id=$(this).closest('.save-card').data('id'); const sv=loadLocalSaves().find(x=>x.id===id); if(!sv) return;
    const blob=new Blob([JSON.stringify(sv.tree,null,2)],{type:'application/json'});
    const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=(sv.name.replace(/\s+/g,'_')+'.json'); a.click(); URL.revokeObjectURL(a.href);
  });
  $('#saves-list').on('click','.act-delete', function(){
    const id=$(this).closest('.save-card').data('id'); const saves=loadLocalSaves().filter(x=>x.id!==id); writeLocalSaves(saves); renderSaves();
  });

  /* ==== Botonera ==== */
  $('#org-add-child').on('click', ()=>{ if (selectedId) addChild(selectedId); });
  $('#org-add-free').on('click', ()=> addFreeNode());
  $('#org-delete-node').on('click', ()=>{ if (selectedId && confirm('¿Eliminar este nodo?')) deleteNode(selectedId); });

  $('#org-connect').on('click', ()=>{
    if (!selectedId) return;
    connectMode=!connectMode; linkMode=false; hrLinkMode=false; connectSource=connectMode?selectedId:null;
    toggleButtons(); setStatus(connectMode? 'Modo conectar (padre): elegí el destino.' : 'Modo conectar desactivado.');
  });

  $('#org-link').on('click', ()=>{
    if (!selectedId) return;
    linkMode=!linkMode; hrLinkMode=false; connectMode=linkMode; connectSource=linkMode?selectedId:null;
    toggleButtons(); setStatus(linkMode? 'Modo flecha extra: elegí el destino.' : 'Flecha extra desactivada.');
  });

  $('#org-link-hr').on('click', ()=>{
    if (!selectedId) return;
    hrLinkMode=!hrLinkMode; linkMode=false; connectMode=hrLinkMode; connectSource=hrLinkMode?selectedId:null;
    toggleButtons(); setStatus(hrLinkMode? 'Modo Flecha HR: elegí el destino.' : 'Flecha HR desactivada.');
  });

  $('#org-apply').on('click', ()=>{
    if (!selectedId) return; const {node}=findById(selectedId); if(!node) return;
    node.name=$('#f-name').val().trim()||node.name||'Sin nombre';
    node.title=$('#f-title').val().trim()||'';
    node.color=$('#f-color').val().trim()||node.color||'#1f2937';
    renderNodes(); selectNode(selectedId); setStatus('Cambios aplicados.');
  });

  $('#org-new').on('click', ()=>{
    if (!confirm('¿Crear un organigrama nuevo? Perderás cambios no guardados.')) return;
    chartData=makeDefaultTree(); renderNodes(); selectNode(chartData.id); setStatus('Nuevo organigrama.');
  });

  $('#org-export-json').on('click', ()=>{
    const blob=new Blob([JSON.stringify(chartData,null,2)],{type:'application/json'});
    const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='organigrama.json'; a.click(); URL.revokeObjectURL(a.href);
  });

  $('#org-import-json').on('change', function(){
    const f=this.files[0]; if(!f) return;
    const rd=new FileReader();
    rd.onload=()=>{
      try{ chartData=ensureTree(JSON.parse(rd.result)); renderNodes(); selectNode(chartData.id); setStatus('Importado.'); }
      catch(e){ alert('JSON inválido: '+e.message); }
      this.value='';
    };
    rd.readAsText(f);
  });

  $('#org-download-png').on('click', ()=>{
    html2canvas(document.querySelector('#orgchart')).then(canvas=>{
      const a=document.createElement('a'); a.download='organigrama.png'; a.href=canvas.toDataURL('image/png'); a.click();
    });
  });

  $('#org-save').on('click', ()=>{
    setStatus('Guardando…');
    $.post(AJAX, { action:'midas_orgchart_save', nonce: NONCE, tree: JSON.stringify(chartData) })
      .done(res=>{ if(!res?.success){ alert(res?.data?.message||'Error al guardar'); setStatus(''); return; } setStatus('✓ Guardado.'); })
      .fail(()=>{ alert('Error de red al guardar'); setStatus(''); });
  });

  $('#org-save-local').on('click', ()=> saveSnapshot());

  // init
  chartData=makeDefaultTree();
  renderNodes(); selectNode(chartData.id);
  (function renderSavesInit(){ const saves=loadLocalSaves(); if(saves) renderSaves(); })();
  $('#org-load').trigger('click');
});
</script>
