<?php
if (!defined('ABSPATH')) exit;

// Nonces locales
$nonce_docs  = wp_create_nonce('midas_documentaciones_nonce');
$nonce_tipos = wp_create_nonce('midas_doc_tipos_nonce');

// Helpers mínimos para selects
global $wpdb;
$empleados = $wpdb->get_results("SELECT id, CONCAT(nombre,' ',apellido) AS nombre FROM {$wpdb->prefix}midas_empleados ORDER BY apellido,nombre");
$tipos     = $wpdb->get_results("SELECT id, descripcion FROM {$wpdb->prefix}midas_doc_tipos ORDER BY descripcion");
?>
<div class="wrap midas-wrap">
  <h1><?php esc_html_e('DOCUMENTACIÓN CON VENCIMIENTO', 'midas-rrhh'); ?></h1>

  <h2 class="nav-tab-wrapper" style="margin-top:16px;">
    <a href="#" class="nav-tab nav-tab-active" data-tab="docs">Documentos</a>
    <a href="#" class="nav-tab" data-tab="tipos">Tipos</a>
  </h2>

  <!-- ====== TAB DOCUMENTOS ====== -->
  <div id="tab-docs" class="midas-tab active">
    <div class="midas-filters">
      <input type="text" id="doc-q" class="force-upper secure-input" autocomplete="off" inputmode="text" spellcheck="false" placeholder="<?php esc_attr_e('Buscar por empleado, tipo o descripción...', 'midas-rrhh'); ?>">
      <select id="doc-estado">
        <option value="todos"><?php esc_html_e('Todos los estados', 'midas-rrhh'); ?></option>
        <option value="vigentes"><?php esc_html_e('Vigentes', 'midas-rrhh'); ?></option>
        <option value="por-vencer"><?php esc_html_e('Por vencer (≤30 días)', 'midas-rrhh'); ?></option>
        <option value="vencidos"><?php esc_html_e('Vencidos', 'midas-rrhh'); ?></option>
      </select>
      <select id="doc-tipo">
        <option value="0"><?php esc_html_e('Todos los tipos', 'midas-rrhh'); ?></option>
        <?php foreach ($tipos as $t): ?>
          <option value="<?php echo (int)$t->id; ?>"><?php echo esc_html($t->descripcion); ?></option>
        <?php endforeach; ?>
      </select>
      <button class="button" id="doc-buscar"><?php esc_html_e('Buscar','midas-rrhh'); ?></button>
      <button class="button button-primary" id="doc-nuevo"><?php esc_html_e('Nuevo documento','midas-rrhh'); ?></button>
      <div class="midas-perpage">
        <span><?php esc_html_e('por página','midas-rrhh'); ?>:</span>
        <select id="doc-per-page"><option>10</option><option>20</option><option>50</option></select>
      </div>
    </div>

    <div class="table-wrap">
      <table class="widefat fixed striped midas-table" id="doc-table">
        <thead>
          <tr>
            <th><?php esc_html_e('Empleado','midas-rrhh'); ?></th>
            <th><?php esc_html_e('Tipo','midas-rrhh'); ?></th>
            <th><?php esc_html_e('Descripción','midas-rrhh'); ?></th>
            <th><?php esc_html_e('Inicio','midas-rrhh'); ?></th>
            <th><?php esc_html_e('Fin','midas-rrhh'); ?></th>
            <th><?php esc_html_e('Estado','midas-rrhh'); ?></th>
            <th><?php esc_html_e('Archivo','midas-rrhh'); ?></th>
            <th style="width:120px;"><?php esc_html_e('Acciones','midas-rrhh'); ?></th>
          </tr>
        </thead>
        <tbody id="doc-tbody">
          <tr><td colspan="8"><?php esc_html_e('Cargando...','midas-rrhh'); ?></td></tr>
        </tbody>
      </table>
    </div>
    <div class="midas-paginacion" id="doc-pag"></div>
  </div>

  <!-- ====== TAB TIPOS ====== -->
  <div id="tab-tipos" class="midas-tab" style="display:none;">
    <div class="midas-filters">
      <input type="text" id="tipo-q" class="force-upper secure-input" autocomplete="off" inputmode="text" spellcheck="false" placeholder="<?php esc_attr_e('Buscar descripción de tipo...', 'midas-rrhh'); ?>">
      <button class="button" id="tipo-buscar"><?php esc_html_e('Buscar','midas-rrhh'); ?></button>
      <button class="button button-primary" id="tipo-nuevo"><?php esc_html_e('Nuevo tipo','midas-rrhh'); ?></button>
      <div class="midas-perpage">
        <span><?php esc_html_e('por página','midas-rrhh'); ?>:</span>
        <select id="tipo-per-page"><option>10</option><option>20</option><option>50</option></select>
      </div>
    </div>

    <div class="table-wrap">
      <table class="widefat fixed striped midas-table" id="tipo-table">
        <thead>
          <tr>
            <th><?php esc_html_e('Descripción','midas-rrhh'); ?></th>
            <th><?php esc_html_e('Plazo','midas-rrhh'); ?></th>
            <th style="width:120px;"><?php esc_html_e('Acciones','midas-rrhh'); ?></th>
          </tr>
        </thead>
        <tbody id="tipo-tbody">
          <tr><td colspan="3"><?php esc_html_e('Cargando...','midas-rrhh'); ?></td></tr>
        </tbody>
      </table>
    </div>
    <div class="midas-paginacion" id="tipo-pag"></div>
  </div>
</div>

<!-- ===== MODAL DOCUMENTO ===== -->
<div id="modal-doc" class="midas-modal-overlay" style="display:none;">
  <div class="midas-modal">
    <h2 id="modal-doc-title"><?php esc_html_e('Nuevo documento','midas-rrhh'); ?></h2>
    <form id="form-doc" enctype="multipart/form-data">
      <input type="hidden" name="action" value="midas_doc_crear">
      <input type="hidden" name="midas_documentaciones_nonce" value="<?php echo esc_attr($nonce_docs); ?>">
      <input type="hidden" name="id" id="doc-id" value="">
      <table class="form-table">
        <tr>
          <th><?php esc_html_e('Empleado','midas-rrhh'); ?></th>
          <td>
            <select class="narrow-select" name="empleado_id" id="doc-empleado" required>
              <option value=""><?php esc_html_e('Seleccionar...','midas-rrhh'); ?></option>
              <?php foreach ($empleados as $e): ?>
                <option value="<?php echo (int)$e->id; ?>"><?php echo esc_html($e->nombre); ?></option>
              <?php endforeach; ?>
            </select>
          </td>
        </tr>
        <tr>
          <th><?php esc_html_e('Tipo','midas-rrhh'); ?></th>
          <td>
            <select class="narrow-select" name="tipo_id" id="doc-tipo-id">
              <option value=""><?php esc_html_e('Sin tipo (manual)','midas-rrhh'); ?></option>
              <?php foreach ($tipos as $t): ?>
                <option value="<?php echo (int)$t->id; ?>"><?php echo esc_html($t->descripcion); ?></option>
              <?php endforeach; ?>
            </select>
            <p class="description"><?php esc_html_e('Si el tipo tiene plazo, la fecha de fin se calcula automáticamente desde la fecha de inicio.','midas-rrhh'); ?></p>
          </td>
        </tr>
        <tr>
          <th><?php esc_html_e('Descripción','midas-rrhh'); ?></th>
          <td><textarea name="descripcion" id="doc-descripcion" class="force-upper secure-input" rows="3"></textarea></td>
        </tr>
        <tr>
          <th><?php esc_html_e('Fecha de inicio','midas-rrhh'); ?></th>
          <td><input type="date" name="fecha_inicio" id="doc-inicio" required></td>
        </tr>
        <tr>
          <th><?php esc_html_e('Fecha de fin','midas-rrhh'); ?></th>
          <td><input type="date" name="fecha_fin" id="doc-fin" placeholder="<?php esc_attr_e('Opcional (se calcula si el tipo tiene plazo)','midas-rrhh'); ?>"></td>
        </tr>
        <tr>
          <th><?php esc_html_e('Archivo','midas-rrhh'); ?></th>
          <td>
            <input type="file" name="archivo" id="doc-archivo" accept=".pdf,image/*">
            <small class="description"><?php esc_html_e('Solo PDF/PNG/JPG/GIF/WEBP. Máx 10MB.','midas-rrhh'); ?></small>
          </td>
        </tr>
      </table>
      <p class="submit modal-actions">
        <button type="submit" class="button button-primary" id="doc-guardar"><?php esc_html_e('Guardar','midas-rrhh'); ?></button>
        <button type="button" class="button" id="doc-cancelar"><?php esc_html_e('Cancelar','midas-rrhh'); ?></button>
      </p>
    </form>
  </div>
</div>

<!-- ===== MODAL TIPO ===== -->
<div id="modal-tipo" class="midas-modal-overlay" style="display:none;">
  <div class="midas-modal">
    <h2 id="modal-tipo-title"><?php esc_html_e('Nuevo tipo','midas-rrhh'); ?></h2>
    <form id="form-tipo">
      <input type="hidden" name="action" value="midas_docv_tipo_guardar">
      <input type="hidden" name="midas_doc_tipos_nonce" value="<?php echo esc_attr($nonce_tipos); ?>">
      <input type="hidden" name="id" id="tipo-id" value="">
      <table class="form-table">
        <tr>
          <th><?php esc_html_e('Descripción','midas-rrhh'); ?></th>
          <td><input type="text" name="descripcion" id="tipo-descripcion" class="force-upper secure-input" required></td>
        </tr>
        <tr>
          <th><?php esc_html_e('Plazo','midas-rrhh'); ?></th>
          <td class="plazo-row">
            <input type="number" min="0" name="plazo_numero" id="plazo-numero">
            <select class="narrow-select" name="plazo_unidad" id="plazo-unidad">
              <option value=""><?php esc_html_e('—','midas-rrhh'); ?></option>
              <option value="dias"><?php esc_html_e('Días','midas-rrhh'); ?></option>
              <option value="meses"><?php esc_html_e('Meses','midas-rrhh'); ?></option>
              <option value="anios"><?php esc_html_e('Años','midas-rrhh'); ?></option>
            </select>
          </td>
        </tr>
      </table>
      <p class="submit modal-actions">
        <button type="submit" class="button button-primary" id="tipo-guardar"><?php esc_html_e('Guardar','midas-rrhh'); ?></button>
        <button type="button" class="button" id="tipo-cancelar"><?php esc_html_e('Cancelar','midas-rrhh'); ?></button>
      </p>
    </form>
  </div>
</div>

<style>
/* ===== Layout / filtros ===== */
.midas-wrap .midas-filters{ display:flex; flex-wrap:wrap; gap:8px; align-items:center; margin:12px 0; }
.midas-wrap .midas-filters input[type="text"], .midas-wrap .midas-filters select{ min-width:180px }
.midas-wrap .midas-perpage{ margin-left:auto; display:flex; align-items:center; gap:6px }

/* ===== Responsive table wrapper ===== */
.table-wrap{ width:100%; overflow-x:auto }

/* ===== Modal & base ===== */
.midas-tab.active{display:block}
.midas-modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.45);display:none;align-items:center;justify-content:center;z-index:9999;padding:10px}
.midas-modal{
  background:#fff;border:1px solid #ccd0d4;box-shadow:0 8px 30px rgba(0,0,0,.2);
  border-radius:12px;padding:16px;width:100%;max-width:560px;
  max-height:90vh;overflow:auto;
}
.midas-modal h2{ margin:0 0 10px 0; font-size:18px; line-height:1.3 }
.modal-actions{ display:flex; gap:8px; flex-wrap:wrap; justify-content:flex-end; margin-top:8px }
.plazo-row{ display:flex; gap:8px; align-items:center; flex-wrap:wrap }
.badge{display:inline-block;padding:2px 6px;border-radius:4px;font-size:11px}
.badge.grey{background:#e2e8f0}
.badge.green{background:#c6f6d5}
.badge.orange{background:#fbd38d}
.badge.red{background:#feb2b2}

/* Campos */
.midas-modal input[type="text"],
.midas-modal input[type="date"],
.midas-modal input[type="number"],
.midas-modal input[type="file"],
.midas-modal select,
.midas-modal textarea{ width:100%; max-width:100%; box-sizing:border-box }

/* Form-table compacto en desktop */
.midas-modal .form-table{ width:100%; border-collapse:separate; border-spacing:0 8px }
.midas-modal .form-table th{ width:36%; padding:0; vertical-align:top }
.midas-modal .form-table td{ padding:0 }

/* ====== Selects compactos y que NO se salgan ====== */
.midas-modal .narrow-select{
  max-width:360px;
  white-space:nowrap;
  overflow:hidden;
  text-overflow:ellipsis;
  font-size:13px;
  padding:.35rem .5rem;
}
.midas-modal select option{
  white-space:normal;
  word-break:break-word;
  overflow-wrap:anywhere;
}

/* ===== Tablas responsivas (cards en móvil) ===== */
.midas-table{ table-layout:auto; width:100% }
.midas-paginacion{ display:flex; justify-content:flex-end; gap:8px; margin:12px 0 }

/* Campos en mayúscula */
.force-upper { text-transform: uppercase; }

@media (max-width: 900px){
  .midas-wrap .midas-perpage{ margin-left:0 }
  .midas-wrap .midas-filters input[type="text"],
  .midas-wrap .midas-filters select,
  .midas-wrap .midas-filters button{ flex:1 1 160px }

  .midas-table thead{ display:none }
  .midas-table, .midas-table tbody, .midas-table tr, .midas-table td{ display:block; width:100% }
  .midas-table tr{
    margin:0 0 12px 0; border:1px solid #e5e7eb; border-radius:10px; background:#fff; overflow:hidden
  }
  .midas-table td{
    padding:10px 12px; display:flex; gap:10px; justify-content:space-between; align-items:flex-start;
    word-break:break-word
  }
  .midas-table td::before{
    content: attr(data-label);
    font-weight:600; flex:0 0 46%; max-width:50%; white-space:normal
  }
  .midas-table td:last-child{ border-bottom:0 }
}

/* Modal en móviles: label arriba + selects a 100% */
@media (max-width: 600px){
  .midas-modal{ max-width:480px; padding:14px }
  .midas-modal .form-table tr{ display:block; margin-bottom:10px }
  .midas-modal .form-table th{ display:block; width:auto; margin:0 0 4px 0 }
  .midas-modal .form-table td{ display:block }
  .midas-modal .narrow-select{ max-width:100%; }
}
</style>

<script>
jQuery(function($){
  const ajax = window.midas_rrhh ? midas_rrhh.ajax_url : ajaxurl;

  /* ===== Sanitizador seguro del HTML devuelto en tbody ===== */
  function sanitizeHTML(html){
    try{
      const tpl = document.createElement('template');
      tpl.innerHTML = String(html || '');
      const rmTags = new Set(['SCRIPT','IFRAME','OBJECT','EMBED','META','LINK','STYLE','FORM']);
      const safeHref = url => {
        if (!url) return '#';
        const u = String(url).trim(); const lower = u.toLowerCase();
        if (lower.startsWith('javascript:') || lower.startsWith('data:')) return '#';
        return u;
      };
      const walker = document.createTreeWalker(tpl.content, NodeFilter.SHOW_ELEMENT, null, false);
      let node = walker.nextNode();
      while(node){
        const tag=node.tagName;
        if (rmTags.has(tag)){ const rm=node; node = walker.nextNode(); rm.remove(); continue; }
        Array.from(node.attributes).forEach(attr=>{
          const name=attr.name.toLowerCase();
          if (name.startsWith('on') || name==='style' || name==='srcdoc') node.removeAttribute(attr.name);
        });
        if (tag==='A'){
          node.setAttribute('href', safeHref(node.getAttribute('href')));
          node.setAttribute('target','_blank');
          node.setAttribute('rel','noopener noreferrer nofollow');
        }
        if (tag==='IMG'){
          const src=(node.getAttribute('src')||'').toLowerCase();
          const ok = src.startsWith('http://') || src.startsWith('https://') || src.startsWith('data:image/');
          if (!ok) node.setAttribute('src','');
          node.setAttribute('loading','lazy');
          node.setAttribute('referrerpolicy','no-referrer');
        }
        node = walker.nextNode();
      }
      return tpl.innerHTML;
    }catch(e){ return ''; }
  }

  // Inputs seguros en MAYÚSCULAS
  const toUpper = s => (s||'').toString().toLocaleUpperCase('es-AR');
  const sanitizeTextInput = s => toUpper(s).replace(/[\u0000-\u001F\u007F]/g,'').replace(/[<>`]/g,'');
  function bindUpperAndSanitize(selector){
    $(document).on('input', selector, function(){
      const el=this, start=el.selectionStart, end=el.selectionEnd, oldLen=el.value.length;
      const cleaned = sanitizeTextInput(el.value);
      if (el.value!==cleaned){
        el.value=cleaned;
        if (start!=null && end!=null){
          const delta = cleaned.length-oldLen;
          el.setSelectionRange(start+delta, end+delta);
        }
      }
    });
    $(selector).attr({'autocapitalize':'characters','spellcheck':'false'});
  }
  bindUpperAndSanitize('.secure-input');

  // Validación de archivos
  const MAX_MB = 10;
  const ALLOWED_EXT = ['pdf','png','jpg','jpeg','gif','webp'];
  const BAD_EXT = ['php','js','html','htm','svg','exe','sh','bat','ps1','dll'];
  function getExt(n){ const i=String(n||'').lastIndexOf('.'); return i>=0?String(n).slice(i+1).toLowerCase():''; }
  function allowedByExt(n){ const e=getExt(n); if(!e) return false; if(BAD_EXT.includes(e)) return false; return ALLOWED_EXT.includes(e); }
  function allowedByType(t){ return ['application/pdf','image/png','image/jpeg','image/gif','image/webp'].includes(t); }
  function readBytes(file,len=16){ return new Promise((res,rej)=>{ const fr=new FileReader(); fr.onload=()=>res(new Uint8Array(fr.result)); fr.onerror=rej; fr.readAsArrayBuffer(file.slice(0,len)); }); }
  async function sniffFileType(file){
    const b=await readBytes(file,16), s=a=>String.fromCharCode(...a);
    if (b[0]===0x25&&b[1]===0x50&&b[2]===0x44&&b[3]===0x46) return 'pdf';
    const PNG=[0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A]; if (PNG.every((v,i)=>b[i]===v)) return 'png';
    if (b[0]===0xFF&&b[1]===0xD8&&b[2]===0xFF) return 'jpg';
    if (s(b.slice(0,4))==='GIF8') return 'gif';
    if (s(b.slice(0,4))==='RIFF' && s(b.slice(8,12))==='WEBP') return 'webp';
    return null;
  }
  async function isSafeFile(file){
    if(!file) return true;
    if (file.size > MAX_MB*1024*1024) return false;
    if (!allowedByExt(file.name)) return false;
    if (!allowedByType(file.type)) return false;
    const sniff=await sniffFileType(file);
    if(!sniff) return false;
    const ext=getExt(file.name); if (ext==='jpg'||ext==='jpeg') return sniff==='jpg'; return sniff===ext;
  }

  /* ===== Tabs ===== */
  $('.nav-tab').on('click', function(e){
    e.preventDefault();
    $('.nav-tab').removeClass('nav-tab-active'); $(this).addClass('nav-tab-active');
    const tab=$(this).data('tab'); $('.midas-tab').hide().removeClass('active'); $('#tab-'+tab).show().addClass('active');
  });

  /* ===== Paginación ===== */
  function pagina(curr,total,per,clickCb){
    const pages=Math.max(1,Math.ceil(total/per)); let html='';
    const mk=(p,txt,dis=false)=>`<button class="button ${dis?'disabled':''}" data-p="${p}" ${dis?'disabled':''}>${txt}</button>`;
    html+=mk(1,'«',curr<=1); html+=mk(Math.max(1,curr-1),'‹',curr<=1);
    html+=`<span style="padding:6px 8px;">${curr} / ${pages}</span>`;
    html+=mk(Math.min(pages,curr+1),'›',curr>=pages); html+=mk(pages,'»',curr>=pages);
    const $c=$(clickCb.container).html(html);
    $c.find('button').on('click',function(){ if($(this).is('.disabled'))return; clickCb.go(parseInt($(this).data('p'),10)); });
  }

  /* ===== Utilidades ===== */
  const normTxt = s => (s||'').toString().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
  const toYMD = s => { const str=(s||'').trim(); let m=str.match(/^(\d{2})\/(\d{2})\/(\d{4})$/); if(m) return `${m[3]}-${m[2]}-${m[1]}`; m=str.match(/^(\d{4})-(\d{2})-(\d{2})$/); if(m) return str; return ''; };
  function selectByText($sel, txt){
    const want = normTxt(txt); let found=false, idxContains=-1;
    $sel.find('option').each(function(i){ const opt=normTxt($(this).text()); if(opt===want){ $(this).prop('selected',true); found=true; return false; } if(!found && idxContains===-1 && opt.indexOf(want)!==-1) idxContains=i; });
    if(!found){ if(idxContains>=0) $sel.prop('selectedIndex',idxContains); else $sel.prop('selectedIndex',0); }
    $sel.trigger('change');
  }
  function applyResponsiveLabels($table){
    const headers=[]; $table.find('thead th').each(function(){ headers.push($(this).text().trim()); });
    $table.find('tbody tr').each(function(){
      const $tds=$(this).children('td');
      if ($tds.length !== headers.length) return;
      $tds.each(function(i){ $(this).attr('data-label', headers[i] || ''); });
    });
  }

  /* ===== Orden descendente por ID (respaldo en cliente) ===== */
  function sortTbodyByIdDesc($tbody){
    const rows = $tbody.children('tr').get();
    rows.sort((a,b)=>{ const ai = parseInt($(a).data('id'), 10) || 0; const bi = parseInt($(b).data('id'), 10) || 0; return bi - ai; });
    $tbody.append(rows);
  }
  function sortTiposTbodyByIdDesc($tbody){
    const rows = $tbody.children('tr').get();
    rows.sort((a,b)=>{ const ai = parseInt($(a).find('.tipo-edit').data('id') || $(a).find('.tipo-del').data('id'), 10) || 0; const bi = parseInt($(b).find('.tipo-edit').data('id') || $(b).find('.tipo-del').data('id'), 10) || 0; return bi - ai; });
    $tbody.append(rows);
  }

  /* ====== DOCUMENTOS ====== */
  let docState={q:'',estado:'todos',tipo_id:0,page:1,per:10};

  function loadDocs(){
    $('#doc-tbody').html(`<tr><td colspan="8"><?php echo esc_js(__('Cargando...', 'midas-rrhh')); ?></td></tr>`);
    $.post(ajax,{
      action:'midas_docv_listar',
      q:docState.q, estado:docState.estado||'todos', tipo_id:docState.tipo_id||0,
      page:docState.page, per_page:docState.per,
      order_by:'id_desc'
    },function(resp){
      if(!resp || !resp.success){ $('#doc-tbody').text('Error'); return; }
      const {tbody,total,page,per_page}=resp.data;
      const safe = tbody ? sanitizeHTML(tbody) : '';
      $('#doc-tbody').html(safe || `<tr><td colspan="8"><?php echo esc_js(__('Sin datos','midas-rrhh')); ?></td></tr>`);
      sortTbodyByIdDesc($('#doc-tbody'));
      applyResponsiveLabels($('#doc-table'));
      pagina(page,total,per_page,{container:'#doc-pag',go:function(p){ docState.page=p; loadDocs(); }});
    },'json').fail(function(){ $('#doc-tbody').text('Error'); });
  }

  // Buscar (click + debounce)
  $('#doc-buscar').on('click',function(){
    docState.q=$('#doc-q').val(); docState.estado=$('#doc-estado').val()||'todos';
    docState.tipo_id=parseInt($('#doc-tipo').val()||'0',10); docState.page=1;
    docState.per=parseInt($('#doc-per-page').val(),10)||10; loadDocs();
  });
  let docKeyTimer=null;
  $('#doc-q').on('keyup', function(e){
    if(e.key==='Enter'){ clearTimeout(docKeyTimer); docState.q=this.value; docState.page=1; loadDocs(); return; }
    clearTimeout(docKeyTimer);
    docKeyTimer=setTimeout(()=>{ docState.q=$('#doc-q').val(); docState.page=1; loadDocs(); }, 350);
  });
  $('#doc-estado').on('change', function(){ docState.estado=$(this).val()||'todos'; docState.page=1; loadDocs(); });
  $('#doc-tipo').on('change', function(){ docState.tipo_id=parseInt($(this).val()||'0',10); docState.page=1; loadDocs(); });
  $('#doc-per-page').on('change',function(){ docState.per=parseInt($(this).val(),10)||10; docState.page=1; loadDocs(); });

  // Nuevo
  $('#doc-nuevo').on('click', function(){
    $('#form-doc')[0].reset();
    $('#doc-id').val('');
    $('#modal-doc-title').text('<?php echo esc_js(__('Nuevo documento','midas-rrhh')); ?>');
    $('#form-doc [name=action]').val('midas_doc_crear');
    $('#doc-inicio').prop('required', true);
    $('#modal-doc').css('display','flex');
  });
  $('#doc-cancelar').on('click', ()=> $('#modal-doc').hide() );

  // Editar
  $(document).on('click','.doc-edit, .editar-doc', function(e){
    e.preventDefault();
    const $btn=$(this); const id=$btn.data('id')||''; let payload=$btn.data('doc');
    if(!payload){
      const $tr=$btn.closest('tr'), cols=$tr.children('td');
      const empTxtFull=$(cols[0]).text().trim(), empTxtName=empTxtFull.split(' - ')[0]||empTxtFull;
      const tipoTxt=$(cols[1]).text().trim(), desTxt=$(cols[2]).text().trim();
      const fIniTxt=$(cols[3]).text().trim(), fFinTxt=$(cols[4]).text().trim();
      payload={ id, empleado_nombre:empTxtName, tipo_nombre:tipoTxt, descripcion:desTxt, fecha_inicio:toYMD(fIniTxt), fecha_fin:toYMD(fFinTxt) };
    }
    $('#doc-id').val(payload.id||'');
    if(payload.empleado_id){ $('#doc-empleado').val(String(payload.empleado_id)).trigger('change'); }
    else if(payload.empleado_nombre){ selectByText($('#doc-empleado'), payload.empleado_nombre); }
    else { const fallback = ($(this).closest('tr').children('td').eq(0).text()||'').split(' - ')[0]; selectByText($('#doc-empleado'), fallback); }
    if(payload.tipo_id){ $('#doc-tipo-id').val(String(payload.tipo_id)).trigger('change'); }
    else if(payload.tipo_nombre){ selectByText($('#doc-tipo-id'), payload.tipo_nombre); }
    else { $('#doc-tipo-id').val('').trigger('change'); }
    $('#doc-descripcion').val(sanitizeTextInput(payload.descripcion||'')); $('#doc-inicio').val(payload.fecha_inicio||''); $('#doc-fin').val(payload.fecha_fin||'');
    $('#modal-doc-title').text('<?php echo esc_js(__('Editar documento','midas-rrhh')); ?>');
    $('#form-doc [name=action]').val('midas_doc_editar'); $('#doc-inicio').prop('required', false);
    $('#modal-doc').css('display','flex');
  });

  // Guardar doc
  $('#form-doc').on('submit', async function(e){
    e.preventDefault();
    const $desc=$('#doc-descripcion'); $desc.val(sanitizeTextInput($desc.val()));
    const file=$('#doc-archivo')[0].files[0];
    if(file){ const ok=await isSafeFile(file); if(!ok){ alert('Archivo no permitido. Solo PDF/PNG/JPG/GIF/WEBP y hasta 10MB.'); return; } }
    const fd=new FormData(this); const isEdit=$('#doc-id').val()!==''; if(isEdit) fd.set('action','midas_doc_editar');
    if(fd.has('descripcion')) fd.set('descripcion', sanitizeTextInput(fd.get('descripcion')));
    $.ajax({ url:ajax, method:'POST', data:fd, processData:false, contentType:false, dataType:'json' })
    .done(function(resp){ if(!resp||!resp.success){ alert((resp&&resp.data&&resp.data.message)||'Error'); return; } $('#modal-doc').hide(); docState.page=1; loadDocs(); })
    .fail(function(){ alert('Error'); });
  });

  /* ====== TIPOS ====== */
  let tipoState={q:'',page:1,per:10};

  function loadTipos(){
    $('#tipo-tbody').html(`<tr><td colspan="3"><?php echo esc_js(__('Cargando...', 'midas-rrhh')); ?></td></tr>`);
    $.post(ajax,{
      action:'midas_docv_tipos_listar',
      q:tipoState.q, page:tipoState.page, per_page:tipoState.per,
      order_by:'id_desc'
    }, function(resp){
      if(!resp||!resp.success){ $('#tipo-tbody').text('Error'); return; }
      const {tbody,total,page,per_page}=resp.data;
      const safe=tbody?sanitizeHTML(tbody):'';
      $('#tipo-tbody').html(safe || `<tr><td colspan="3"><?php echo esc_js(__('Sin datos','midas-rrhh')); ?></td></tr>`);
      sortTiposTbodyByIdDesc($('#tipo-tbody'));
      applyResponsiveLabels($('#tipo-table'));
      pagina(page,total,per_page,{container:'#tipo-pag',go:function(p){ tipoState.page=p; loadTipos(); }});
    },'json').fail(function(){ $('#tipo-tbody').text('Error'); });
  }

  $('#tipo-buscar').on('click',function(){ tipoState.q=$('#tipo-q').val(); tipoState.page=1; tipoState.per=parseInt($('#tipo-per-page').val(),10)||10; loadTipos(); });
  let tipoKeyTimer=null;
  $('#tipo-q').on('keyup', function(e){
    if(e.key==='Enter'){ clearTimeout(tipoKeyTimer); tipoState.q=this.value; tipoState.page=1; loadTipos(); return; }
    clearTimeout(tipoKeyTimer);
    tipoKeyTimer=setTimeout(()=>{ tipoState.q=$('#tipo-q').val(); tipoState.page=1; loadTipos(); }, 350);
  });
  $('#tipo-per-page').on('change',function(){ tipoState.per=parseInt($(this).val(),10)||10; tipoState.page=1; loadTipos(); });

  // ===== Helpers: mantener selects de documentos actualizados con los Tipos =====
  function upsertOptionSorted($sel, id, text, keepFirst=false){
    const val = String(id);
    const $exist = $sel.find(`option[value="${val}"]`);
    if ($exist.length){ $exist.text(text); return; }
    const $opt = $('<option>').val(val).text(text);
    const $opts = $sel.find('option');
    let inserted=false;
    $opts.each(function(i){
      if (keepFirst && i===0) return; // reservar "Todos los tipos"
      const t=$(this).text().trim().toLocaleLowerCase('es');
      if (text.trim().toLocaleLowerCase('es') < t){ $(this).before($opt); inserted=true; return false; }
    });
    if(!inserted) $sel.append($opt);
  }
  function refreshDocTipoOptionsFromResp(resp){
    // ID devuelto (crear/editar). Si no viene, uso el del form.
    const idFromResp = resp && resp.data && (resp.data.id || (resp.data.tipo && resp.data.tipo.id));
    const id = parseInt(idFromResp || $('#tipo-id').val() || 0, 10);
    const desc = (resp && resp.data && (resp.data.descripcion || (resp.data.tipo && resp.data.tipo.descripcion))) || $('#tipo-descripcion').val();
    if (!id || !desc) return;

    // Actualizar selects
    upsertOptionSorted($('#doc-tipo-id'), id, desc, false);
    upsertOptionSorted($('#doc-tipo'), id, desc, true);

    // Si el modal de documento está abierto, dejo preseleccionado el nuevo/actualizado
    const isModalOpen = $('#modal-doc').is(':visible');
    if (isModalOpen){
      $('#doc-tipo-id').val(String(id)).trigger('change');
    }
  }

  // Nuevo tipo
  $('#tipo-nuevo').on('click', function(){
    $('#form-tipo')[0].reset(); $('#tipo-id').val('');
    $('#modal-tipo-title').text('<?php echo esc_js(__('Nuevo tipo','midas-rrhh')); ?>');
    $('#form-tipo [name=action]').val('midas_docv_tipo_guardar'); $('#modal-tipo').css('display','flex');
  });
  $('#tipo-cancelar').on('click', ()=> $('#modal-tipo').hide() );

  // Editar tipo
  $(document).on('click','.tipo-edit', function(e){
    e.preventDefault();
    $('#tipo-id').val($(this).data('id'));
    $('#tipo-descripcion').val(sanitizeTextInput($(this).data('des')||''));
    $('#plazo-numero').val($(this).data('n')||'');
    $('#plazo-unidad').val($(this).data('u')||'');
    $('#modal-tipo-title').text('<?php echo esc_js(__('Editar tipo','midas-rrhh')); ?>');
    $('#form-tipo [name=action]').val('midas_docv_tipo_guardar');
    $('#modal-tipo').css('display','flex');
  });

  // Guardar tipo (crear/editar) + refrescar selects de Documentos inmediatamente
  $('#form-tipo').on('submit', function(e){
    e.preventDefault();
    const $d=$('#tipo-descripcion'); $d.val(sanitizeTextInput($d.val()));
    const data=$(this).serialize();
    $.post(ajax, data, function(resp){
      if(!resp||!resp.success){ alert((resp&&resp.data&&resp.data.message)||'Error'); return; }
      $('#modal-tipo').hide();
      tipoState.page=1; loadTipos();            // refresca la tabla de Tipos
      refreshDocTipoOptionsFromResp(resp);      // <-- actualiza selects sin recargar
    },'json').fail(function(){ alert('Error'); });
  });

  // Eliminar tipo (y quitar de los selects)
  $(document).on('click','.tipo-del', function(e){
    e.preventDefault();
    if(!confirm('<?php echo esc_js(__('¿Eliminar este tipo? Esto no borra documentos existentes.','midas-rrhh')); ?>')) return;
    const id=$(this).data('id');
    $.post(ajax, { action:'midas_docv_tipo_eliminar', id:id, midas_doc_tipos_nonce:'<?php echo esc_js($nonce_tipos); ?>' }, function(resp){
      if(!resp||!resp.success){ alert((resp&&resp.data&&resp.data.message)||'Error'); return; }
      // Quitar opción de ambos selects
      $('#doc-tipo-id option[value="'+id+'"]').remove();
      $('#doc-tipo option[value="'+id+'"]').remove();
      tipoState.page=1; loadTipos();
    },'json').fail(function(){ alert('Error'); });
  });

  // Cerrar modal click afuera / ESC
  $('#modal-doc, #modal-tipo').on('click', function(e){ if(e.target===this) $(this).hide(); });
  $(document).on('keyup', function(e){ if(e.key==='Escape'){ $('#modal-doc, #modal-tipo').hide(); } });

  // Cargas iniciales
  loadDocs(); loadTipos();
});
</script>
