<?php
if (!defined('ABSPATH')) exit;

use MidasRRHH\Models\Empleado_Model;
use MidasRRHH\Models\Recibo_Model;
use MidasRRHH\Controllers\Carpeta_Medica_Controller;
use MidasRRHH\Controllers\Licencia_Controller;

/* ========= AJAX: guardar paleta por usuario ========= */
if (is_admin() && defined('WP_ADMIN')) {
  add_action('wp_ajax_midas_save_palette_scoped', function () {
    if (!check_ajax_referer('midas_palette_scoped_nonce', 'nonce', false)) {
      wp_send_json_error(['message' => 'Nonce inválido o faltante.'], 403);
    }
    $uid = get_current_user_id();
    if (!$uid) wp_send_json_error(['message' => 'Sin usuario'], 403);

    $raw  = wp_unslash($_POST['palette'] ?? '');
    $data = json_decode($raw, true);
    if (!is_array($data)) wp_send_json_error(['message' => 'Payload inválido'], 400);

    $is_hex = fn($v) => is_string($v) && preg_match('/^#[0-9A-Fa-f]{6}$/', $v);
    $clean = [
      'cards' => [
        'bg'        => $is_hex($data['cards']['bg'] ?? '')        ? $data['cards']['bg']        : '#ffffff',
        'border'    => $is_hex($data['cards']['border'] ?? '')    ? $data['cards']['border']    : '#ccd0d4',
        'headerBg'  => $is_hex($data['cards']['headerBg'] ?? '')  ? $data['cards']['headerBg']  : '#f7f7f7',
        'headerTxt' => $is_hex($data['cards']['headerTxt'] ?? '') ? $data['cards']['headerTxt'] : '#1f2937',
        'stripe'    => $is_hex($data['cards']['stripe'] ?? '')    ? $data['cards']['stripe']    : '#f9fafb',
      ],
      'text' => [
        'txt'   => $is_hex($data['text']['txt'] ?? '')   ? $data['text']['txt']   : '#1e293b',
        'muted' => $is_hex($data['text']['muted'] ?? '') ? $data['text']['muted'] : '#475569',
      ],
      'btn' => [
        'bg'  => $is_hex($data['btn']['bg']  ?? '') ? $data['btn']['bg']  : '#2271b1',
        'txt' => $is_hex($data['btn']['txt'] ?? '') ? $data['btn']['txt'] : '#ffffff',
      ],
    ];

    update_user_meta($uid, 'midas_palette_scoped', $clean);
    wp_send_json_success(['saved' => $clean]);
  });

  /* ========= AJAX: Conectores de métricas externas ========= */
  add_action('wp_ajax_midas_connect_ext_metric', function () {
    if (!check_ajax_referer('midas_connectors_nonce', 'nonce', false)) {
      wp_send_json_error(['message'=>'Nonce inválido'], 403);
    }
    $uid = get_current_user_id();
    if (!$uid) wp_send_json_error(['message'=>'Usuario no autenticado'], 403);

    $provider = sanitize_key($_POST['provider'] ?? '');
    $token    = trim(wp_unslash($_POST['token'] ?? ''));
    if (!$provider) wp_send_json_error(['message'=>'Proveedor faltante'], 400);

    $allowed = ['ga4','gsc','facebook_ads','instagram','linkedin_ads','twitter_ads','shopify','woocommerce','stripe','paypal','hubspot','zendesk','jira','github','notion','sheets'];
    if (!in_array($provider, $allowed, true)) wp_send_json_error(['message'=>'Proveedor no permitido'], 400);

    $store = get_user_meta($uid, 'midas_ext_metrics_tokens', true);
    if (!is_array($store)) $store = [];
    $store[$provider] = $token ?: 'DEMO'; // DEMO: guarda lo que peguen
    update_user_meta($uid, 'midas_ext_metrics_tokens', $store);

    wp_send_json_success(['provider'=>$provider, 'connected'=>true]);
  });

  add_action('wp_ajax_midas_disconnect_ext_metric', function () {
    if (!check_ajax_referer('midas_connectors_nonce', 'nonce', false)) {
      wp_send_json_error(['message'=>'Nonce inválido'], 403);
    }
    $uid = get_current_user_id();
    if (!$uid) wp_send_json_error(['message'=>'Usuario no autenticado'], 403);

    $provider = sanitize_key($_POST['provider'] ?? '');
    if (!$provider) wp_send_json_error(['message'=>'Proveedor faltante'], 400);

    $store = get_user_meta($uid, 'midas_ext_metrics_tokens', true);
    if (!is_array($store)) $store = [];
    unset($store[$provider]);
    update_user_meta($uid, 'midas_ext_metrics_tokens', $store);

    wp_send_json_success(['provider'=>$provider, 'connected'=>false]);
  });

  add_action('wp_ajax_midas_fetch_ext_metrics', function () {
    if (!check_ajax_referer('midas_connectors_nonce', 'nonce', false)) {
      wp_send_json_error(['message'=>'Nonce inválido'], 403);
    }
    $uid = get_current_user_id();
    if (!$uid) wp_send_json_error(['message'=>'Usuario no autenticado'], 403);

    $providers = isset($_POST['providers']) ? (array) $_POST['providers'] : [];
    $providers = array_map('sanitize_key', $providers);
    $providers = array_values(array_filter($providers));

    $store = get_user_meta($uid, 'midas_ext_metrics_tokens', true);
    if (!is_array($store)) $store = [];

    // Labels (últimos 6 meses)
    $labels = [];
    for ($i=5; $i>=0; $i--) $labels[] = date_i18n('M Y', strtotime("-{$i} months"));

    $colors = [
      'ga4' => '#4285F4','gsc'=>'#34A853','facebook_ads'=>'#1877F2','instagram'=>'#E4405F',
      'linkedin_ads'=>'#0A66C2','twitter_ads'=>'#1DA1F2','shopify'=>'#95BF47','woocommerce'=>'#7F54B3',
      'stripe'=>'#635BFF','paypal'=>'#00457C','hubspot'=>'#FF7A59','zendesk'=>'#03363D',
      'jira'=>'#2684FF','github'=>'#24292F','notion'=>'#000000','sheets'=>'#0F9D58'
    ];

    $human = [
      'ga4'=>'Google Analytics 4','gsc'=>'Search Console','facebook_ads'=>'Facebook Ads','instagram'=>'Instagram',
      'linkedin_ads'=>'LinkedIn Ads','twitter_ads'=>'Twitter/X Ads','shopify'=>'Shopify','woocommerce'=>'WooCommerce',
      'stripe'=>'Stripe','paypal'=>'PayPal','hubspot'=>'HubSpot','zendesk'=>'Zendesk',
      'jira'=>'Jira','github'=>'GitHub','notion'=>'Notion','sheets'=>'Google Sheets'
    ];

    $datasets = [];
    $connected = [];

    foreach ($providers as $p) {
      $connected[$p] = isset($store[$p]);
      if (!$connected[$p]) continue;

      // DEMO: genera serie reproducible por mes
      $seed = crc32($p . gmdate('Y-m'));
      mt_srand($seed);
      $series = [];
      for ($i=0; $i<count($labels); $i++) {
        $base = match ($p) {
          'ga4','gsc' => 1000,
          'facebook_ads','instagram','linkedin_ads','twitter_ads' => 400,
          'shopify','woocommerce' => 250,
          'stripe','paypal' => 300,
          'hubspot' => 120,
          'zendesk','jira' => 160,
          'github' => 90,
          'notion','sheets' => 60,
          default => 80,
        };
        $series[] = $base + mt_rand(0, $base);
      }
      $datasets[] = [
        'label' => $human[$p] ?? strtoupper($p),
        'data'  => $series,
        'borderColor' => $colors[$p] ?? '#2271b1',
        'backgroundColor' => ($colors[$p] ?? '#2271b1') . '99',
        'fill' => false
      ];
    }

    wp_send_json_success([
      'labels'   => $labels,
      'datasets' => $datasets,
      'connected'=> $connected
    ]);
  });
}

/* ===================== Datos (métricas locales) ===================== */
$empleado_model            = new Empleado_Model();
$recibo_model              = new Recibo_Model();
$carpeta_medica_controller = new Carpeta_Medica_Controller();
$licencia_controller       = new Licencia_Controller();

$total_empleados       = $empleado_model->get_all();
$licencias_pendientes  = $licencia_controller->obtener_licencias_pendientes();
$documentos_pendientes = $carpeta_medica_controller->obtener_documentos_pendientes();
if (is_wp_error($documentos_pendientes)) $documentos_pendientes = [];
$recibos         = $recibo_model->get_all();
$ultimos_recibos = [];

if (!is_array($licencias_pendientes))  $licencias_pendientes = [];
if (!is_array($documentos_pendientes)) $documentos_pendientes = [];
if (!is_array($recibos))               $recibos = [];

foreach ($recibos as $recibo) {
  $empleado = $empleado_model->get($recibo->empleado_id);
  $recibo->empleado_nombre = $empleado ? "{$empleado->nombre} {$empleado->apellido}" : 'Empleado no encontrado';
  $timestamp = strtotime($recibo->periodo);
  $recibo->periodo_formateado = $timestamp ? date_i18n('F Y', $timestamp) : $recibo->periodo;
  $ultimos_recibos[] = $recibo;
}

/* ===================== Nonces / Ajax ===================== */
$nonce_emp      = wp_create_nonce('midas_empleados_nonce');
$nonce_cm       = function_exists('wp_create_nonce') ? wp_create_nonce('midas_cm_nonce') : $nonce_emp;
$ajax_url       = admin_url('admin-ajax.php');
$nonce_palette  = wp_create_nonce('midas_palette_scoped_nonce');
$nonce_connect  = wp_create_nonce('midas_connectors_nonce');
$uid            = get_current_user_id();
$saved_palette  = $uid ? get_user_meta($uid, 'midas_palette_scoped', true) : null;
if (!is_array($saved_palette)) $saved_palette = null;
$tokens         = $uid ? get_user_meta($uid, 'midas_ext_metrics_tokens', true) : [];
if (!is_array($tokens)) $tokens = [];
$connected_keys = array_keys($tokens);
?>
<script>
  window.midas_rrhh = window.midas_rrhh || {};
  midas_rrhh.ajax_url        = "<?= esc_js($ajax_url) ?>";
  midas_rrhh.nonce_emp       = "<?= esc_js($nonce_emp) ?>";
  midas_rrhh.nonce_cm        = "<?= esc_js($nonce_cm) ?>";
  midas_rrhh.palette_nonce   = "<?= esc_js($nonce_palette) ?>";
  midas_rrhh.connectors_nonce= "<?= esc_js($nonce_connect) ?>";
  midas_rrhh.user_palette    = <?= wp_json_encode($saved_palette ?: (object)[]) ?>;
  midas_rrhh.connected_providers = <?= wp_json_encode($connected_keys) ?>;
</script>

<input type="hidden" id="midas-ajax-url"  value="<?php echo esc_url( admin_url('admin-ajax.php') ); ?>">
<input type="hidden" id="midas-nonce-emp" value="<?php echo esc_attr( $nonce_emp ); ?>">
<input type="hidden" id="midas-nonce-cm"  value="<?php echo esc_attr( $nonce_cm ); ?>">
<input type="hidden" id="midas-nonce-palette" value="<?php echo esc_attr( $nonce_palette ); ?>">
<input type="hidden" id="midas-nonce-connect" value="<?php echo esc_attr( $nonce_connect ); ?>">

<div class="wrap midas-rrhh-dashboard" id="midasDashboard">
  <h1><?php esc_html_e('Dashboard Midas RRHH', 'midas-rrhh'); ?></h1>

  <!-- ===== Métricas (locales) ===== -->
  <div class="midas-card metrics-card" id="metricsCard">
    <div class="metrics-header">
      <h3 class="metrics-title">Métricas generales</h3>
      <div class="metrics-toolbar">
        <label class="mt-inline">Tipo:
          <select id="metricType" class="mt-select">
            <option value="bar">Barras</option>
            <option value="line">Línea</option>
            <option value="doughnut">Dona</option>
          </select>
        </label>
        <div class="metrics-toggles">
          <span>Mostrar:</span>
          <label><input type="checkbox" data-idx="0" checked> Empleados</label>
          <label><input type="checkbox" data-idx="1" checked> Licencias</label>
          <label><input type="checkbox" data-idx="2" checked> Doc. médicos</label>
          <label><input type="checkbox" data-idx="3" checked> Recibos</label>
        </div>
        <button type="button" id="metricZoomReset" class="button button-small">Reset zoom</button>
        <button type="button" id="metricDownload"  class="button button-small">Descargar PNG</button>
        <button type="button" id="metricExpand"    class="button button-small">Pantalla completa</button>

        <span class="mt-inline">
          Alto:
          <input type="range" id="metricHeight" class="mt-range" min="220" max="900" step="10">
          <span id="metricHeightVal">320</span>px
          <button type="button" id="metricSizeReset" class="button button-small">Tamaño por defecto</button>
        </span>
      </div>
    </div>

    <details class="metrics-help">
      <summary>¿Qué puedo hacer con estas métricas?</summary>
      <ul>
        <li><strong>Cambiar tipo</strong> (Barras, Línea, Dona).</li>
        <li><strong>Zoom</strong> con la rueda del mouse o pellizco en touch.</li>
        <li><strong>Pan</strong> manteniendo <kbd>Shift</kbd> y arrastrando.</li>
        <li><strong>Reset zoom</strong> con el botón o tecla <kbd>0</kbd>.</li>
        <li><strong>Pantalla completa</strong> (botón, doble click o tecla <kbd>F</kbd> — salir con <kbd>Esc</kbd>).</li>
        <li><strong>Descargar PNG</strong> del gráfico.</li>
        <li><strong>Mostrar / ocultar</strong> categorías con los checkboxes.</li>
        <li><strong>Redimensionar alto</strong> arrastrando la manija <b>⤡</b> o usando el control de <b>Alto</b>.</li>
      </ul>
    </details>

    <div class="metrics-canvas-wrap" id="metricsCanvasWrap">
      <canvas id="midasDashboardChart"></canvas>
      <span class="metrics-resize-handle" title="Arrastrá para cambiar el alto">⤡</span>
    </div>
  </div>

  <!-- ===== MÉTRICAS EXTERNAS ===== -->
  <div class="midas-card metrics-card ext-metrics-card" id="extMetricsCard">
    <div class="metrics-header">
      <h3 class="metrics-title">Métricas externas (conexiones)</h3>
      <div class="metrics-toolbar">
        <label class="mt-inline">Tipo:
          <select id="extMetricType" class="mt-select">
            <option value="bar">Barras</option>
            <option value="line">Línea</option>
            <option value="doughnut">Dona</option>
          </select>
        </label>

        <div class="metrics-toggles" id="extProviderToggles">
          <span>Proveedores:</span>
          <!-- se pobla por JS -->
        </div>

        <button type="button" id="extConnectSelected" class="button button-small">Conectar seleccionados</button>
        <button type="button" id="extDisconnectSelected" class="button button-small">Desconectar seleccionados</button>
        <button type="button" id="extRefresh" class="button button-small">Refrescar</button>
        <button type="button" id="extZoomReset" class="button button-small">Reset zoom</button>
        <button type="button" id="extDownload"  class="button button-small">Descargar PNG</button>
        <button type="button" id="extExpand"    class="button button-small">Pantalla completa</button>

        <span class="mt-inline">
          Alto:
          <input type="range" id="extMetricHeight" class="mt-range" min="220" max="900" step="10">
          <span id="extMetricHeightVal">320</span>px
          <button type="button" id="extMetricSizeReset" class="button button-small">Tamaño por defecto</button>
        </span>
      </div>
    </div>

    <details class="metrics-help">
      <summary>Gestionar conexiones</summary>
      <div class="connectors-grid" id="connectorsGrid"></div>
      <p class="muted">Tip: pegá cualquier texto como “token” para modo demo. Luego reemplazá por credenciales reales en <code>midas_fetch_ext_metrics</code>.</p>
    </details>

    <div class="metrics-canvas-wrap" id="extMetricsCanvasWrap">
      <canvas id="extMetricsChart"></canvas>
      <span class="metrics-resize-handle" title="Arrastrá para cambiar el alto">⤡</span>
    </div>
    <div class="ext-status" id="extStatus" aria-live="polite" style="padding:8px 12px;color:#4b5563;"></div>
  </div>

  <div id="metricsOverlay" class="metrics-overlay" style="display:none"></div>

  <div class="midas-column-row">
    <!-- Licencias -->
    <div class="midas-card min-table-card">
      <h3 style="margin-bottom:0;">Licencias pendientes</h3>
      <div class="midas-card-body table-card-body">
        <table class="wp-list-table widefat fixed striped midas-table" id="tabla-licencias-pendientes">
          <thead>
            <tr>
              <th>Empleado</th><th>Asunto</th><th>Periodo</th><th>Días solicitados</th><th>Observaciones</th><th>Acción</th>
            </tr>
          </thead>
          <tbody id="tbody-licencias">
          <?php
          if (!empty($licencias_pendientes)) {
            usort($licencias_pendientes, fn($a,$b)=>strtotime($b->fecha_creacion ?? $b->fecha_inicio ?? '') <=> strtotime($a->fecha_creacion ?? $a->fecha_inicio ?? ''));
            foreach ($licencias_pendientes as $lic):
              $empleado_nombre = $lic->empleado_nombre ?? '-';
              $asunto   = $lic->tipo ?? '-';
              $fecha_ini = $lic->fecha_inicio ?? '';
              $fecha_fin = $lic->fecha_fin ?? '';
              $dias     = $lic->dias_solicitados ?? '-';
              $obs      = $lic->observaciones ?? '-';
              $periodo  = trim(
                ($fecha_ini ? date_i18n('d/m/Y', strtotime($fecha_ini)) : '-') . ' - ' .
                ($fecha_fin ? date_i18n('d/m/Y', strtotime($fecha_fin)) : '-')
              );
          ?>
            <tr class="fila-lic" id="lic-<?php echo esc_attr($lic->id); ?>" data-id="<?php echo esc_attr($lic->id); ?>">
              <td data-label="Empleado"><?php echo esc_html($empleado_nombre); ?></td>
              <td data-label="Asunto"><?php echo esc_html($asunto); ?></td>
              <td data-label="Periodo"><?php echo esc_html($periodo); ?></td>
              <td data-label="Días solicitados"><?php echo esc_html($dias); ?></td>
              <td data-label="Observaciones"><?php echo esc_html($obs); ?></td>
              <td data-label="Acción"><button type="button" class="button btn-visto-lic" data-id="<?php echo esc_attr($lic->id); ?>">Visto</button></td>
            </tr>
          <?php endforeach; } else { echo '<tr><td colspan="6">No hay licencias pendientes.</td></tr>'; } ?>
          </tbody>
        </table>
        <div id="paginacion-licencias" class="midas-pagination" style="margin-top:10px;text-align:right;"></div>
      </div>
    </div>

    <!-- Documentos -->
    <div class="midas-card min-table-card">
      <h3 style="margin-bottom:0;">Documentos pendientes</h3>
      <div class="midas-card-body table-card-body">
        <table class="wp-list-table widefat fixed striped midas-table" id="tabla-documentos-pendientes">
          <thead>
            <tr>
              <th>Empleado</th><th>Motivo</th><th>Médico</th><th>Fecha emisión</th><th>Vence</th><th>Acción</th>
            </tr>
          </thead>
          <tbody id="tbody-documentos">
            <?php if (!empty($documentos_pendientes)) { foreach ($documentos_pendientes as $doc): ?>
              <tr class="fila-doc" id="doc-<?php echo esc_attr($doc->id); ?>" data-id="<?php echo esc_attr($doc->id); ?>">
                <td data-label="Empleado"><?php echo esc_html($doc->empleado_nombre); ?></td>
                <td data-label="Motivo"><?php echo esc_html($doc->motivo_nombre ?? '-'); ?></td>
                <td data-label="Médico"><?php echo esc_html(trim(($doc->medico_nombre ?? '') . ' ' . ($doc->medico_apellido ?? '')) ?: '-'); ?></td>
                <td data-label="Fecha emisión"><?php echo esc_html(date_i18n('d/m/Y', strtotime($doc->fecha_emision))); ?></td>
                <td data-label="Vence"><?php echo esc_html($doc->fecha_vencimiento ? date_i18n('d/m/Y', strtotime($doc->fecha_vencimiento)) : '-'); ?></td>
                <td data-label="Acción"><button type="button" class="button btn-visto-doc" data-id="<?php echo esc_attr($doc->id); ?>">Visto</button></td>
              </tr>
            <?php endforeach; } else { echo '<tr><td colspan="6">No hay documentos pendientes.</td></tr>'; } ?>
          </tbody>
        </table>
        <div id="paginacion-documentos" class="midas-pagination" style="margin-top:10px;text-align:right;"></div>
      </div>
    </div>

    <!-- Recibos -->
    <div class="midas-card min-table-card">
      <h3>Últimos Recibos Cargados</h3>
      <div class="midas-card-body table-card-body">
        <table class="wp-list-table widefat fixed striped midas-table" id="tabla-recibos">
          <thead>
            <tr><th>Empleado</th><th>Mes / Año</th><th>Monto Neto</th><th>Acción</th></tr>
          </thead>
          <tbody id="tbody-recibos">
            <?php if (!empty($ultimos_recibos)) {
              usort($ultimos_recibos, fn($a,$b)=>strtotime($b->periodo) <=> strtotime($a->periodo));
              foreach ($ultimos_recibos as $recibo): ?>
              <tr class="fila-rec" id="rec-<?php echo esc_attr($recibo->id); ?>" data-id="<?php echo esc_attr($recibo->id); ?>">
                <td data-label="Empleado"><?php echo esc_html($recibo->empleado_nombre); ?></td>
                <td data-label="Mes / Año"><?php echo esc_html($recibo->periodo_formateado); ?></td>
                <td data-label="Monto Neto"><?php echo esc_html(number_format((float)$recibo->monto, 2, ',', '.')); ?></td>
                <td data-label="Acción"><button type="button" class="button btn-visto-rec" data-id="<?php echo esc_attr($recibo->id); ?>">Visto</button></td>
              </tr>
            <?php endforeach; } else { echo '<tr><td colspan="4">No hay recibos generados.</td></tr>'; } ?>
          </tbody>
        </table>
        <div id="paginacion-recibos" class="midas-pagination" style="margin-top:10px;text-align:right;"></div>
      </div>
    </div>
  </div>
</div>

<!-- ===== Modal de Paleta ===== -->
<div id="midasPaletteModal" class="midas-modal-overlay" style="display:none;" aria-hidden="true" aria-modal="true" role="dialog">
  <div class="midas-modal" role="document">
    <h2 class="midas-modal-title" title="Arrastra para mover">🎨 Paleta de colores</h2>
    <p class="midas-modal-sub">Afecta tarjetas, textos y <strong>botones (.button)</strong> del dashboard.</p>

    <div class="midas-modal-grid">
      <div class="mmg-col">
        <h4>Tarjetas</h4>
        <label>Fondo <input type="color" id="c-bg" value="#ffffff"></label>
        <label>Borde <input type="color" id="c-border" value="#ccd0d4"></label>
        <label>Cabecera <input type="color" id="c-hbg" value="#f7f7f7"></label>
        <label>Texto cabecera <input type="color" id="c-htxt" value="#1f2937"></label>
        <label>Renglón zebra <input type="color" id="c-stripe" value="#f9fafb"></label>
      </div>
      <div class="mmg-col">
        <h4>Textos</h4>
        <label>Texto principal <input type="color" id="t-main" value="#1e293b"></label>
        <label>Texto atenuado <input type="color" id="t-muted" value="#475569"></label>
        <hr>
        <h4>Botones (.button)</h4>
        <label>Fondo botón <input type="color" id="b-bg" value="#2271b1"></label>
        <label>Texto botón <input type="color" id="b-txt" value="#ffffff"></label>
      </div>
    </div>

    <div class="midas-modal-actions">
      <button type="button" class="button" id="pal-reset">Restablecer</button>
      <button type="button" class="button" id="pal-save">Guardar</button>
      <button type="button" class="button" id="pal-close">Cerrar</button>
      <span id="pal-status" class="pal-status" aria-live="polite"></span>
    </div>
  </div>
</div>

<style>
/* ====== Scope: SOLO dashboard ====== */
#midasDashboard{
  --md-card-bg:#ffffff;
  --md-card-border:#ccd0d4;
  --md-card-header-bg:#f7f7f7;
  --md-card-header-text:#1f2937;
  --md-table-stripe:#f9fafb;
  --md-text:#1e293b;
  --md-muted:#475569;
  --md-btn-bg:#2271b1;
  --md-btn-text:#ffffff;
  color:var(--md-text);
}
#midasDashboard .midas-card{ background:var(--md-card-bg); border:1px solid var(--md-card-border); }
#midasDashboard .midas-card h3{ background:var(--md-card-header-bg); color:var(--md-card-header-text); border-bottom:1px solid var(--md-card-border); margin:0; padding:15px; }
#midasDashboard .midas-card,
#midasDashboard .midas-card-body,
#midasDashboard table.wp-list-table,
#midasDashboard table.wp-list-table td,
#midasDashboard table.wp-list-table th{ color:var(--md-text); }

/* Zebra */
#midasDashboard .midas-table tbody tr:nth-child(odd){ background:var(--md-table-stripe) !important; }
#midasDashboard .midas-table > tbody > tr > td{ background: var(--md-table-stripe) !important; }
#midasDashboard .midas-table td::before{ color:var(--md-muted); }

/* Botones en dashboard */
#midasDashboard .button{ background:var(--md-btn-bg) !important; border-color:var(--md-btn-bg) !important; color:var(--md-btn-text) !important; }
#midasDashboard .button:hover{ filter:brightness(0.95); }

/* ===== Métricas UI ===== */
.metrics-card .metrics-header{ display:flex; align-items:center; justify-content:space-between; gap:12px; }
.metrics-title{ margin:0; }
.metrics-toolbar{ display:flex; flex-wrap:wrap; align-items:center; gap:8px; padding:10px 12px; }
.mt-inline{ display:inline-flex; align-items:center; gap:6px; }
.mt-select{ min-width:120px; }
.mt-range{ width:180px; }

.metrics-toggles{ display:flex; flex-wrap:wrap; align-items:center; gap:10px; }
.metrics-toggles label{ display:inline-flex; gap:4px; align-items:center; }

/* ====== inline links para proveedores ====== */
.prov-item{ display:inline-flex; align-items:center; gap:6px; margin-right:8px; padding:2px 6px; border-radius:6px; }
.prov-item .prov-dot{ width:8px; height:8px; border-radius:999px; background:#d1d5db; display:inline-block; }
.prov-item .prov-dot.on{ background:#10b981; }
.prov-inline-actions a{ font-size:11px; text-decoration:underline; color:var(--md-card-header-text); }
.prov-inline-actions a:hover{ opacity:.9; }

/* Ayuda */
.metrics-help{ margin:0 12px 4px; color:#4b5563; }
.metrics-help summary{ cursor:pointer; user-select:none; padding:6px 0; }

.metrics-canvas-wrap{ position:relative; height:320px; padding:10px 12px 16px; }
.metrics-canvas-wrap canvas{ width:100% !important; height:100% !important; display:block; }
.metrics-resize-handle{ position:absolute; right:10px; bottom:8px; user-select:none; font-size:14px; opacity:.65; cursor:nwse-resize; }

/* Fullscreen */
.metrics-overlay{ position:fixed; inset:0; background:rgba(0,0,0,.5); z-index:9997; }
.metrics-card.metrics-fullscreen{ position:fixed; left:2vw; top:3vh; width:96vw; z-index:9998; }
.metrics-card.metrics-fullscreen .metrics-canvas-wrap{ height:72vh; }

/* ===== Modal ===== */
#midasPaletteModal{ --md-btn-bg:#2271b1; --md-btn-text:#ffffff; }
.midas-modal-overlay{
  position:fixed; inset:0; background:rgba(0,0,0,.45);
  display:none; align-items:center; justify-content:center; z-index:10000; padding:12px;
}
.midas-modal{
  position:fixed;
  width:min(760px, 95vw);
  max-height:calc(96vh - 24px);
  background:#fff; border:1px solid #d0d7de;
  border-radius:12px; box-shadow:0 12px 36px rgba(0,0,0,.25);
  padding:16px; overflow:auto;
}
.midas-modal-title{ margin:0 0 6px; font-size:18px; cursor:move; user-select:none; }
.midas-modal-sub{ margin:0 0 12px; color:#4b5563; }
.midas-modal.dragging{ cursor:grabbing; }

.midas-modal-grid{ display:grid; grid-template-columns:1fr 1fr; gap:16px; }
.mmg-col{ background:#fafafa; border:1px solid #e5e7eb; padding:12px; border-radius:8px; }
.mmg-col h4{ margin:0 0 10px; }
.mmg-col label{ display:flex; align-items:center; justify-content:space-between; gap:10px; padding:6px 0; }
.mmg-col input[type="color"]{ width:44px; height:32px; padding:0; border:1px solid #c8d1dc; border-radius:4px; }

.midas-modal-actions{ display:flex; gap:8px; align-items:center; justify-content:flex-end; margin-top:12px; }
.pal-status{ min-width:120px; font-weight:600; }

/* Layout tablas */
.midas-column-row{ display:flex; flex-direction:column; gap:24px; margin-bottom:20px; }
.min-table-card{ width:100%; margin-bottom:0; }
.midas-card{ margin-bottom:20px; display:flex; flex-direction:column; }
.midas-card-body{ padding:20px; text-align:center; flex:1 1 auto; }
.table-card-body{ overflow-x:auto; }

.midas-pagination a{ display:inline-block; padding:4px 10px; margin:0 1px; border-radius:5px; background:#f7f7f7; color:#2271b1; text-decoration:none; border:1px solid #ccd0d4; font-weight:600; }
.midas-pagination a.current, .midas-pagination a:hover{ background:#2271b1; color:#fff; }

@media (max-width:782px){
  #midasDashboard .midas-table thead{ position:absolute!important; height:1px; width:1px; overflow:hidden; clip:rect(1px,1px,1px,1px); clip-path:inset(50%); white-space:nowrap; }
  #midasDashboard .midas-table tbody tr{ display:block; border:1px solid var(--md-card-border); border-radius:10px; padding:8px 10px; margin-bottom:10px; box-shadow:0 1px 4px rgba(0,0,0,.04); background:transparent !important; }
  #midasDashboard .midas-table tbody tr > td{ background:var(--md-table-stripe) !important; }
  #midasDashboard .midas-table td{ display:grid; grid-template-columns:46% 1fr; gap:8px; align-items:center; padding:8px 0; border:0; border-bottom:1px dashed #eee; word-break:break-word; overflow-wrap:anywhere; text-align:left; }
  #midasDashboard .midas-table td:last-child{ border-bottom:0 }
}
@media (max-width:560px){ .midas-modal-grid{ grid-template-columns:1fr; } }

/* Barra para agrupar Dark Mode + Paleta */
.midas-actions-bar{ display:inline-flex; align-items:center; gap:8px; margin-left:8px; }
.midas-btn{ display:inline-flex; align-items:center; gap:6px; height:32px; line-height:30px; padding:0 12px; border-radius:4px; box-sizing:border-box; font-weight:600; text-decoration:none !important; border:1px solid transparent; white-space:nowrap; }
.midas-btn:hover{ filter:brightness(0.95); }
.midas-dark-skin{ text-decoration:none !important; }

/* FAB por si no hay botón de modo oscuro en el admin */
.midas-palette-fab{
  position:fixed; right:16px; bottom:16px;
  background:var(--md-btn-bg); color:var(--md-btn-text);
  border:1px solid var(--md-btn-bg); border-radius:999px;
  padding:8px 12px; font-weight:700; cursor:pointer;
  box-shadow:0 6px 18px rgba(0,0,0,.18); z-index:10001;
}

/* ===== Conectores (Métricas externas) ===== */
.connectors-grid{
  display:grid; gap:10px;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  margin:10px 0 4px;
}
.connector{
  border:1px solid var(--md-card-border); border-radius:10px;
  padding:10px; background:#fff; display:flex; flex-direction:column; gap:8px;
}
.connector h5{ margin:0; font-size:14px; }
.connector .conn-actions{ display:flex; gap:6px; flex-wrap:wrap; }
.connector .conn-status{ font-size:12px; color:#475569; }
.ext-metrics-card .muted{ color:#6b7280; font-size:12px; margin-top:6px; display:block; }
</style>

<!-- Carga robusta de scripts y lógica -->
<script>
document.addEventListener('DOMContentLoaded', function(){
  const AJAX_URL = window.midas_rrhh?.ajax_url || document.getElementById('midas-ajax-url')?.value || window.ajaxurl;
  const NONCE_EMP = window.midas_rrhh?.nonce_emp || document.getElementById('midas-nonce-emp')?.value || '';
  const NONCE_CM  = window.midas_rrhh?.nonce_cm  || document.getElementById('midas-nonce-cm')?.value  || '';
  const NONCE_PAL = window.midas_rrhh?.palette_nonce || document.getElementById('midas-nonce-palette')?.value || '';
  const NONCE_CON = window.midas_rrhh?.connectors_nonce || document.getElementById('midas-nonce-connect')?.value || '';
  const SAVED     = window.midas_rrhh?.user_palette || null;

  const WRAP  = document.getElementById('midasDashboard');
  const MODAL_OVERLAY = document.getElementById('midasPaletteModal');
  const MODAL = MODAL_OVERLAY.querySelector('.midas-modal');

  function loadScript(src){ return new Promise((res,rej)=>{ const s=document.createElement('script'); s.src=src; s.async=true; s.onload=res; s.onerror=()=>rej(new Error('No se pudo cargar '+src)); document.head.appendChild(s); }); }

  /* ====== Paleta ====== */
  const inlineBtn = document.createElement('button'); inlineBtn.type='button'; inlineBtn.className='button midas-palette-inline-btn midas-btn'; inlineBtn.textContent='🎨 Paleta';
  const fab = document.createElement('div'); fab.className='midas-palette-fab'; fab.title='Elegir paleta'; fab.textContent='🎨';
  function findDarkModeButton(){
    const el=document.querySelector('.wp-dark-mode-switch, .wp-dark-mode-switcher, #wp-dark-mode-switch, .wp-admin-dark-mode-toggle, #wp-dark-mode-toggle');
    if (el) return el;
    for (const n of document.querySelectorAll('a,button,label,.wp-dark-mode-switch, .wp-admin-dark-mode-toggle')){
      const t=((n.textContent||'')+' '+(n.getAttribute('aria-label')||'')).toLowerCase();
      if (t.includes('modo oscuro')||t.includes('dark mode')) return n;
    }
    return null;
  }
  const darkBtn = findDarkModeButton();
  if (darkBtn){
    const bar = document.createElement('span'); bar.className = 'midas-actions-bar';
    darkBtn.insertAdjacentElement('beforebegin', bar); bar.appendChild(darkBtn); bar.appendChild(inlineBtn);
  } else { document.body.appendChild(fab); }
  function hardCenter(){
    MODAL.style.transform = 'none';
    MODAL.style.left = '0px'; MODAL.style.top = '0px';
    const r = MODAL.getBoundingClientRect();
    const left = Math.max(8, Math.round((window.innerWidth  - r.width)  / 2));
    const top  = Math.max(8, Math.round((window.innerHeight - r.height) / 2));
    MODAL.style.left = left+'px';
    MODAL.style.top  = top +'px';
  }
  function openModal(){ MODAL_OVERLAY.style.display='flex'; MODAL_OVERLAY.setAttribute('aria-hidden','false'); requestAnimationFrame(hardCenter); }
  function closeModal(){ MODAL_OVERLAY.style.display='none'; MODAL_OVERLAY.setAttribute('aria-hidden','true'); MODAL.style.left=''; MODAL.style.top=''; MODAL.style.transform=''; MODAL.classList.remove('dragging'); }
  inlineBtn.addEventListener('click', openModal); fab.addEventListener('click', openModal);
  document.getElementById('pal-close')?.addEventListener('click', closeModal);
  MODAL_OVERLAY.addEventListener('click', (e)=>{ if(e.target===MODAL_OVERLAY) closeModal(); });
  document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') closeModal(); });
  window.addEventListener('resize', ()=>{ if (MODAL_OVERLAY.style.display!=='none' && !MODAL.classList.contains('dragging')) hardCenter(); });
  const dragHandle = MODAL.querySelector('.midas-modal-title');
  let dragging=false, startX=0, startY=0, startLeft=0, startTop=0, dragW=0, dragH=0;
  function dragStart(ev){
    const e = ev.touches ? ev.touches[0] : ev;
    const r = MODAL.getBoundingClientRect();
    dragging = true; dragW=r.width; dragH=r.height; startLeft=r.left; startTop=r.top; startX=e.clientX; startY=e.clientY;
    MODAL.classList.add('dragging'); MODAL.style.transform='none'; MODAL.style.left=startLeft+'px'; MODAL.style.top=startTop+'px';
    document.addEventListener('mousemove', dragMove); document.addEventListener('touchmove', dragMove, {passive:false});
    document.addEventListener('mouseup', dragEnd); document.addEventListener('touchend', dragEnd);
  }
  function dragMove(ev){ if(!dragging) return; if (ev.cancelable) ev.preventDefault();
    const e = ev.touches ? ev.touches[0] : ev; let left=startLeft+(e.clientX-startX), top=startTop+(e.clientY-startY);
    const vw=window.innerWidth, vh=window.innerHeight, pad=8; left=Math.max(pad, Math.min(vw-dragW-pad, left)); top=Math.max(pad, Math.min(vh-dragH-pad, top));
    MODAL.style.left=left+'px'; MODAL.style.top=top+'px';
  }
  function dragEnd(){ dragging=false; MODAL.classList.remove('dragging');
    document.removeEventListener('mousemove', dragMove); document.removeEventListener('touchmove', dragMove);
    document.removeEventListener('mouseup', dragEnd); document.removeEventListener('touchend', dragEnd); }
  if (dragHandle){ dragHandle.addEventListener('mousedown', dragStart); dragHandle.addEventListener('touchstart', dragStart, {passive:false}); }

  const DEF = { cards:{ bg:'#ffffff', border:'#ccd0d4', headerBg:'#f7f7f7', headerTxt:'#1f2937', stripe:'#f9fafb' }, text:{ txt:'#1e293b', muted:'#475569' }, btn:{ bg:'#2271b1', txt:'#ffffff' } };
  const LS = (()=>{ try { return JSON.parse(localStorage.getItem('midas.palette.scoped') || 'null'); } catch(e){ return null; }})();
  const base = (SAVED && typeof SAVED==='object') ? SAVED : (LS||{});
  const initial = { cards:Object.assign({}, DEF.cards, base.cards||{}), text:Object.assign({}, DEF.text, base.text||{}), btn:Object.assign({}, DEF.btn, base.btn||{}) };
  function applyVars(node,p){
    if(!node) return;
    node.style.setProperty('--md-card-bg', p.cards.bg);
    node.style.setProperty('--md-card-border', p.cards.border);
    node.style.setProperty('--md-card-header-bg', p.cards.headerBg);
    node.style.setProperty('--md-card-header-text', p.cards.headerTxt);
    node.style.setProperty('--md-table-stripe', p.cards.stripe);
    node.style.setProperty('--md-text', p.text.txt);
    node.style.setProperty('--md-muted', p.text.muted);
    node.style.setProperty('--md-btn-bg', p.btn.bg);
    node.style.setProperty('--md-btn-text', p.btn.txt);
    localStorage.setItem('midas.palette.scoped', JSON.stringify(p));
  }
  applyVars(WRAP, initial);
  applyVars(MODAL_OVERLAY, initial);

  const palStatus = document.getElementById('pal-status');
  const btnSave   = document.getElementById('pal-save');
  const btnReset  = document.getElementById('pal-reset');
  const $ = (id)=>document.getElementById(id);
  const I = { cBg:$('c-bg'), cBorder:$('c-border'), cHbg:$('c-hbg'), cHtxt:$('c-htxt'), cStripe:$('c-stripe'),
              tMain:$('t-main'), tMuted:$('t-muted'), bBg:$('b-bg'), bTxt:$('b-txt') };
  function setInputsFrom(p){ I.cBg.value=p.cards.bg; I.cBorder.value=p.cards.border; I.cHbg.value=p.cards.headerBg; I.cHtxt.value=p.cards.headerTxt; I.cStripe.value=p.cards.stripe; I.tMain.value=p.text.txt; I.tMuted.value=p.text.muted; I.bBg.value=p.btn.bg; I.bTxt.value=p.btn.txt; }
  function currentFromInputs(){ return { cards:{ bg:I.cBg.value, border:I.cBorder.value, headerBg:I.cHbg.value, headerTxt:I.cHtxt.value, stripe:I.cStripe.value }, text:{ txt:I.tMain.value, muted:I.tMuted.value }, btn:{ bg:I.bBg.value, txt:I.bTxt.value } }; }
  setInputsFrom(initial);
  Object.values(I).forEach(el=> el?.addEventListener('input', ()=>{ const p=currentFromInputs(); applyVars(WRAP,p); applyVars(MODAL_OVERLAY,p); palStatus.textContent='Cambios sin guardar…'; }));
  btnSave?.addEventListener('click', async ()=>{
    const payload = currentFromInputs(); palStatus.textContent='Guardando…';
    try{
      const r = await fetch(AJAX_URL,{ method:'POST', credentials:'include', headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},
        body:new URLSearchParams({ action:'midas_save_palette_scoped', nonce:NONCE_PAL, palette:JSON.stringify(payload) })});
      const j = await r.json(); if(!r.ok||!j?.success) throw new Error(j?.data?.message||j?.message||'Error al guardar');
      const saved = j.data?.saved || payload; localStorage.setItem('midas.palette.scoped', JSON.stringify(saved));
      applyVars(WRAP, saved); applyVars(MODAL_OVERLAY, saved); palStatus.textContent='✓ Guardado';
    }catch(e){ palStatus.textContent='Error: '+(e.message||e); }
  });
  btnReset?.addEventListener('click', ()=>{ setInputsFrom(DEF); applyVars(WRAP, DEF); applyVars(MODAL_OVERLAY, DEF); localStorage.removeItem('midas.palette.scoped'); palStatus.textContent='Restablecida (clic en Guardar para persistir)'; });

  /* ================== MÉTRICAS LOCALES ================== */
  const labelsBase = ['Empleados','Licencias pendientes','Documentos médicos pendientes','Recibos'];
  const dataBase   = [<?php echo is_array($total_empleados) ? count($total_empleados) : 0; ?>, <?php echo count($licencias_pendientes); ?>, <?php echo count($documentos_pendientes); ?>, <?php echo is_array($recibos) ? count($recibos) : 0; ?>];
  const colorsBase = ['#2271b1','#ffbe76','#f93e3e','#2ecc71'];

  const ctx = document.getElementById('midasDashboardChart')?.getContext('2d');
  const wrap = document.getElementById('metricsCanvasWrap');
  const typeSelect = document.getElementById('metricType');
  const toggles = document.querySelectorAll('.metrics-toggles input[type="checkbox"]');
  const btnResetZoom = document.getElementById('metricZoomReset');
  const btnDownload = document.getElementById('metricDownload');
  const btnExpand = document.getElementById('metricExpand');
  const overlay = document.getElementById('metricsOverlay');
  const card = document.getElementById('metricsCard');
  const handle = document.querySelector('#metricsCard .metrics-resize-handle');

  const clamp = (n,min,max)=>Math.min(max,Math.max(min,n));
  const heightRange = document.getElementById('metricHeight');
  const heightVal   = document.getElementById('metricHeightVal');
  const btnSizeReset = document.getElementById('metricSizeReset');
  const H_DEFAULT = 320;
  let savedH = parseInt(localStorage.getItem('midas.metrics.height')||H_DEFAULT, 10);
  if (Number.isNaN(savedH)) savedH = H_DEFAULT;
  savedH = clamp(savedH, 220, 900);
  wrap.style.height = savedH+'px';
  heightRange.value = savedH;
  heightVal.textContent = savedH;

  function buildConfigLocal(t, idxs){
    const lbls = idxs.map(i=>labelsBase[i]);
    const vals = idxs.map(i=>dataBase[i]);
    const cols = idxs.map(i=>colorsBase[i]);
    return {
      type: t,
      data:{ labels: lbls, datasets:[{ label:'Cantidad', data: vals, backgroundColor: t==='line'? cols.map(c=>c+'cc'):cols, borderColor: cols, borderWidth:2, fill:(t==='line') }] },
      options:{ responsive:true, maintainAspectRatio:false,
        plugins:{ legend:{display:false}, tooltip:{enabled:true}, zoom:{ pan:{enabled:true, modifierKey:'shift'}, zoom:{wheel:{enabled:true}, pinch:{enabled:true}, mode:'xy'} } },
        scales: (t==='doughnut')? {} : { y:{beginAtZero:true,ticks:{stepSize:1}}, x:{ticks:{maxRotation:25,minRotation:0}} }
      }
    };
  }
  function setHeight(h, persist=true){
    h = clamp(parseInt(h,10), 220, 900);
    wrap.style.height = h+'px';
    heightRange.value = h;
    heightVal.textContent = h;
    if (persist) localStorage.setItem('midas.metrics.height', String(h));
    if (chartLocal) chartLocal.resize();
  }
  heightRange.addEventListener('input', ()=> setHeight(heightRange.value, true));
  btnSizeReset.addEventListener('click', ()=> setHeight(H_DEFAULT, true));
  function setHeightControlEnabled(enabled){ heightRange.disabled = !enabled; btnSizeReset.disabled = !enabled; heightRange.style.opacity = enabled ? '1' : '.6'; }

  let chartLocal=null;
  function initChartLocal(type){
    const idxs = Array.from(toggles).filter(c=>c.checked).map(c=>+c.dataset.idx);
    if (!idxs.length){ toggles[0].checked = true; return initChartLocal(type); }
    if (chartLocal) { try{ chartLocal.destroy(); }catch(e){} }
    chartLocal = new window.Chart(ctx, buildConfigLocal(type, idxs));
    chartLocal.resize();
  }

  (async ()=>{
    try{
      if (!window.Chart) await loadScript('https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js');
      try{ await loadScript('https://cdn.jsdelivr.net/npm/chartjs-plugin-zoom@2.0.1/dist/chartjs-plugin-zoom.umd.min.js'); if (window.ChartZoom) window.Chart.register(window.ChartZoom); }catch(e){}
      let chartType = localStorage.getItem('midas.metrics.type') || 'bar';
      typeSelect.value = chartType;
      initChartLocal(chartType);

      typeSelect.addEventListener('change', ()=>{ chartType = typeSelect.value; localStorage.setItem('midas.metrics.type', chartType); initChartLocal(chartType); });
      toggles.forEach(c=> c.addEventListener('change', ()=> initChartLocal(chartType)));
      btnDownload.addEventListener('click', ()=>{ const a=document.createElement('a'); a.download='metricas-internas.png'; a.href=chartLocal.toBase64Image('image/png',1); a.click(); });
      btnResetZoom.addEventListener('click', ()=>{ if (typeof chartLocal?.resetZoom==='function') chartLocal.resetZoom(); });

      function enterFS(cardEl,chart){ overlay.style.display='block'; cardEl.classList.add('metrics-fullscreen'); setHeightControlEnabled(false); chart?.resize(); }
      function exitFS(cardEl,chart){ overlay.style.display='none'; cardEl.classList.remove('metrics-fullscreen'); setHeightControlEnabled(true); chart?.resize(); }
      let fs=false;
      btnExpand.addEventListener('click', ()=>{ fs?exitFS(card,chartLocal):enterFS(card,chartLocal); fs=!fs; });
      overlay.addEventListener('click', ()=>{ if(fs){ exitFS(card,chartLocal); fs=false; }});
      ctx.canvas.addEventListener('dblclick', ()=>{ fs?exitFS(card,chartLocal):enterFS(card,chartLocal); fs=!fs; });
      document.addEventListener('keydown', (e)=>{ if(e.key==='F'||e.key==='f'){ fs?exitFS(card,chartLocal):enterFS(card,chartLocal); fs=!fs; } if(e.key==='Escape'&&fs){ exitFS(card,chartLocal); fs=false; } if(e.key==='0'&&typeof chartLocal?.resetZoom==='function'){ chartLocal.resetZoom(); }});

      // arrastre de alto
      let draggingH=false, startY=0, startH=0;
      handle.addEventListener('mousedown', (ev)=>{ draggingH=true; startY=ev.clientY; startH=wrap.getBoundingClientRect().height; document.body.style.userSelect='none'; });
      window.addEventListener('mousemove', (ev)=>{ if (!draggingH) return; const h=Math.max(220, Math.min(900, startH + (ev.clientY-startY))); wrap.style.height=h+'px'; heightRange.value=h; heightVal.textContent=h; chartLocal?.resize(); });
      window.addEventListener('mouseup', ()=>{ if (!draggingH) return; draggingH=false; document.body.style.userSelect=''; localStorage.setItem('midas.metrics.height', String(parseInt(wrap.style.height,10))); });

    }catch(err){ console.error('No se pudo inicializar métricas internas:', err); }
  })();

  /* ================== MÉTRICAS EXTERNAS (conectores) ================== */
  function wpAdminURL(path){
    try{ return window.location.origin + path; }catch(e){ return path; }
  }
  const PROVIDERS = [
    {id:'ga4',          name:'Google Analytics 4', url:'https://analytics.google.com/analytics/web/'},
    {id:'gsc',          name:'Search Console',     url:'https://search.google.com/search-console'},
    {id:'facebook_ads', name:'Facebook Ads',       url:'https://business.facebook.com/adsmanager'},
    {id:'instagram',    name:'Instagram',          url:'https://www.instagram.com/'},
    {id:'linkedin_ads', name:'LinkedIn Ads',       url:'https://www.linkedin.com/campaignmanager/'},
    {id:'twitter_ads',  name:'Twitter/X Ads',      url:'https://ads.twitter.com/'},
    {id:'shopify',      name:'Shopify',            url:'https://www.shopify.com/login'},
    {id:'woocommerce',  name:'WooCommerce',        url: wpAdminURL('/wp-admin/admin.php?page=wc-admin')},
    {id:'stripe',       name:'Stripe',             url:'https://dashboard.stripe.com/'},
    {id:'paypal',       name:'PayPal',             url:'https://www.paypal.com/businessmanage/home'},
    {id:'hubspot',      name:'HubSpot',            url:'https://app.hubspot.com/login'},
    {id:'zendesk',      name:'Zendesk',            url:'https://www.zendesk.com/login/'},
    {id:'jira',         name:'Jira',               url:'https://id.atlassian.com/login'},
    {id:'github',       name:'GitHub',             url:'https://github.com/login'},
    {id:'notion',       name:'Notion',             url:'https://www.notion.so/login'},
    {id:'sheets',       name:'Google Sheets',      url:'https://sheets.google.com/'}
  ];
  const connectedInit = new Set(window.midas_rrhh?.connected_providers || []);
  const extWrap   = document.getElementById('extMetricsCanvasWrap');
  const extCtx    = document.getElementById('extMetricsChart')?.getContext('2d');
  const extType   = document.getElementById('extMetricType');
  const extTogBox = document.getElementById('extProviderToggles');
  const extGrid   = document.getElementById('connectorsGrid');
  const extStatus = document.getElementById('extStatus');
  const extHRange = document.getElementById('extMetricHeight');
  const extHVal   = document.getElementById('extMetricHeightVal');
  const extHReset = document.getElementById('extMetricSizeReset');
  const extReset  = document.getElementById('extZoomReset');
  const extDown   = document.getElementById('extDownload');
  const extFSBtn  = document.getElementById('extExpand');
  const extCard   = document.getElementById('extMetricsCard');
  const extHandle = document.querySelector('#extMetricsCard .metrics-resize-handle');
  const extRefreshBtn = document.getElementById('extRefresh');
  const extConnSel = document.getElementById('extConnectSelected');
  const extDiscSel = document.getElementById('extDisconnectSelected');

  const H2_DEFAULT = 320;
  let savedH2 = parseInt(localStorage.getItem('midas.extmetrics.height')||H2_DEFAULT, 10);
  savedH2 = clamp(Number.isNaN(savedH2)?H2_DEFAULT:savedH2, 220, 900);
  extWrap.style.height = savedH2+'px';
  extHRange.value = savedH2; extHVal.textContent = savedH2;

  function setHeight2(h, persist=true){
    h = clamp(parseInt(h,10), 220, 900);
    extWrap.style.height = h+'px';
    extHRange.value = h; extHVal.textContent = h;
    if (persist) localStorage.setItem('midas.extmetrics.height', String(h));
    if (chartExt) chartExt.resize();
  }
  extHRange.addEventListener('input', ()=> setHeight2(extHRange.value, true));
  extHReset.addEventListener('click', ()=> setHeight2(H2_DEFAULT, true));
  function setExtHeightControlEnabled(enabled){
    extHRange.disabled = !enabled; extHReset.disabled = !enabled; extHRange.style.opacity = enabled ? '1' : '.6';
  }

  // ===== Proveedores inline (checkbox + links) =====
  function renderProviderToggles(){
    const selected = getSelectedProviders();
    const html = ['<span>Proveedores:</span>'].concat(PROVIDERS.map(p=>{
      const connected = connectedInit.has(p.id);
      const checked   = selected.includes(p.id) || connected;
      const dot       = `<span class="prov-dot ${connected?'on':''}" title="${connected?'Conectado':'Desconectado'}"></span>`;
      const label     = `<label><input type="checkbox" data-prov="${p.id}" ${checked?'checked':''}> ${p.name}</label>`;
      const actions   = connected
        ? `<span class="prov-inline-actions">· <a href="#" class="prov-disconnect" data-prov="${p.id}">Desconectar</a> · <a href="${p.url}" target="_blank" rel="noopener" class="prov-open" data-prov="${p.id}">Abrir</a></span>`
        : `<span class="prov-inline-actions">· <a href="#" class="prov-connect" data-prov="${p.id}">Conectar</a></span>`;
      return `<span class="prov-item" data-prov="${p.id}">${dot}${label}${actions}</span>`;
    })).join(' ');
    extTogBox.innerHTML = html;
  }
  function renderConnectorsGrid(){
    extGrid.innerHTML = PROVIDERS.map(p=>{
      const connected = connectedInit.has(p.id);
      const st = connected ? 'Conectado ✓' : 'Desconectado';
      return `
        <div class="connector" data-prov="${p.id}">
          <h5>${p.name}</h5>
          <div class="conn-actions">
            <button type="button" class="button button-small btn-prov-connect" data-prov="${p.id}">${connected?'Reconectar':'Conectar'}</button>
            <button type="button" class="button button-small btn-prov-disconnect" data-prov="${p.id}" ${connected?'':'disabled'}>Desconectar</button>
            <a href="${p.url}" target="_blank" rel="noopener" class="button button-small" style="text-decoration:none;">Abrir</a>
          </div>
          <span class="conn-status">Estado: <strong>${st}</strong></span>
        </div>
      `;
    }).join('');
  }
  function getSelectedProviders(){
    return Array.from(extTogBox.querySelectorAll('input[type="checkbox"]'))
      .filter(el=>el.checked).map(el=>el.dataset.prov);
  }

  // Conectar / Desconectar
  async function connectProvider(prov){
    const token = window.prompt(`Pegá el token/clave de ${prov} (deja vacío para DEMO):`, '');
    try{
      const r = await fetch(AJAX_URL,{ method:'POST', credentials:'include',
        headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},
        body:new URLSearchParams({ action:'midas_connect_ext_metric', nonce:NONCE_CON, provider:prov, token: token||'' })});
      const j = await r.json();
      if(!r.ok || !j?.success) throw new Error(j?.data?.message||j?.message||'Error al conectar');
      connectedInit.add(prov);
      renderProviderToggles(); renderConnectorsGrid(); bindConnectorButtons();
      extStatus.textContent = `✓ Conectado ${prov}`;
      await refreshExtMetrics();
    }catch(e){ extStatus.textContent = 'Error: ' + (e.message || e); }
  }
  async function disconnectProvider(prov){
    try{
      const r = await fetch(AJAX_URL,{ method:'POST', credentials:'include',
        headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},
        body:new URLSearchParams({ action:'midas_disconnect_ext_metric', nonce:NONCE_CON, provider:prov })});
      const j = await r.json();
      if(!r.ok || !j?.success) throw new Error(j?.data?.message||j?.message||'Error al desconectar');
      connectedInit.delete(prov);
      renderProviderToggles(); renderConnectorsGrid(); bindConnectorButtons();
      extStatus.textContent = `– Desconectado ${prov}`;
      await refreshExtMetrics();
    }catch(e){ extStatus.textContent = 'Error: ' + (e.message || e); }
  }
  function bindConnectorButtons(){
    // Grid (detalle)
    extGrid.querySelectorAll('.btn-prov-connect').forEach(btn=>{
      btn.addEventListener('click', ()=> connectProvider(btn.dataset.prov));
    });
    extGrid.querySelectorAll('.btn-prov-disconnect').forEach(btn=>{
      btn.addEventListener('click', ()=> disconnectProvider(btn.dataset.prov));
    });
  }

  // Delegación de eventos en la barra de proveedores (checkbox + links)
  extTogBox.addEventListener('click', (e)=>{
    const a = e.target.closest('a');
    if (!a) return;
    e.preventDefault();
    const prov = a.dataset.prov;
    if (a.classList.contains('prov-connect'))   return connectProvider(prov);
    if (a.classList.contains('prov-disconnect'))return disconnectProvider(prov);
  });

  // Chart externo
  let chartExt=null;
  function buildExtConfig(t, payload){
    if (!payload?.datasets?.length){
      return {
        type:'bar',
        data:{ labels:['Sin datos'], datasets:[{label:'Conecta un proveedor', data:[0]}] },
        options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}} }
      };
    }
    if (t==='doughnut'){
      const sums = payload.datasets.map(ds => (ds.data||[]).reduce((a,b)=>a+(+b||0),0));
      const labels = payload.datasets.map(ds=>ds.label);
      const bg = payload.datasets.map(ds=>ds.backgroundColor || '#2271b199');
      const br = payload.datasets.map(ds=>ds.borderColor || '#2271b1');
      return {
        type:'doughnut',
        data:{ labels, datasets:[{ label:'Total', data:sums, backgroundColor:bg, borderColor:br, borderWidth:2 }] },
        options:{ responsive:true, maintainAspectRatio:false, plugins:{ legend:{display:true}, tooltip:{enabled:true} } }
      };
    }
    return {
      type:t,
      data:{ labels: payload.labels, datasets: payload.datasets.map(ds=>({ ...ds, fill:(t==='line') })) },
      options:{ responsive:true, maintainAspectRatio:false,
        plugins:{ legend:{display:true}, tooltip:{enabled:true}, zoom:{ pan:{enabled:true, modifierKey:'shift'}, zoom:{wheel:{enabled:true}, pinch:{enabled:true}, mode:'xy'} } },
        scales: { y:{ beginAtZero:true }, x:{ ticks:{maxRotation:25,minRotation:0} } }
      }
    };
  }

  async function refreshExtMetrics(){
    const selected = getSelectedProviders().filter(p=>connectedInit.has(p));
    if (!selected.length){
      if (chartExt){ try{ chartExt.destroy(); }catch(e){} }
      chartExt = new window.Chart(extCtx, buildExtConfig('bar', null));
      // CTA para conectar rápido
      extStatus.innerHTML = 'Conectá al menos un proveedor para ver datos. <a href="#" id="openConnectors">Conectar ahora</a>';
      document.getElementById('openConnectors')?.addEventListener('click',(ev)=>{ ev.preventDefault(); document.querySelector('#extMetricsCard details').open = true; });
      return;
    }
    extStatus.textContent = 'Cargando…';
    try{
      const r = await fetch(AJAX_URL,{ method:'POST', credentials:'include',
        headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},
        body:new URLSearchParams({ action:'midas_fetch_ext_metrics', nonce:NONCE_CON, providers: selected })});
      const j = await r.json();
      if (!r.ok || !j?.success) throw new Error(j?.data?.message||j?.message||'Error al obtener métricas');
      const t = localStorage.getItem('midas.extmetrics.type') || 'bar';
      if (chartExt){ try{ chartExt.destroy(); }catch(e){} }
      chartExt = new window.Chart(extCtx, buildExtConfig(t, j.data));
      chartExt.resize();
      extStatus.textContent = `Datos listos (${selected.length} proveedor${selected.length>1?'es':''}).`;
    }catch(e){
      extStatus.textContent = 'Error: ' + (e.message || e);
    }
  }

  (async ()=>{
    try{
      if (!window.Chart) await loadScript('https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js');
      try{ await loadScript('https://cdn.jsdelivr.net/npm/chartjs-plugin-zoom@2.0.1/dist/chartjs-plugin-zoom.umd.min.js'); if (window.ChartZoom) window.Chart.register(window.ChartZoom); }catch(e){}

      renderProviderToggles();
      renderConnectorsGrid();
      bindConnectorButtons();

      // Cambios de tipo
      let t = localStorage.getItem('midas.extmetrics.type') || 'bar';
      extType.value = t;
      extType.addEventListener('change', ()=>{ t = extType.value; localStorage.setItem('midas.extmetrics.type', t); refreshExtMetrics(); });

      // Cambios en toggles (solo checkbox)
      extTogBox.addEventListener('change', (e)=>{ if (e.target?.type==='checkbox'){ refreshExtMetrics(); } });

      // Acciones
      document.getElementById('extDownload')?.addEventListener('click', ()=>{ const a=document.createElement('a'); a.download='metricas-externas.png'; a.href=chartExt.toBase64Image('image/png',1); a.click(); });
      extReset?.addEventListener('click', ()=>{ if (typeof chartExt?.resetZoom==='function') chartExt.resetZoom(); });

      let fs2=false;
      function enterFS2(){ document.getElementById('metricsOverlay').style.display='block'; extCard.classList.add('metrics-fullscreen'); setExtHeightControlEnabled(false); chartExt?.resize(); }
      function exitFS2(){ document.getElementById('metricsOverlay').style.display='none'; extCard.classList.remove('metrics-fullscreen'); setExtHeightControlEnabled(true); chartExt?.resize(); }
      extFSBtn?.addEventListener('click', ()=>{ fs2?exitFS2():enterFS2(); fs2=!fs2; });
      document.getElementById('metricsOverlay').addEventListener('click', ()=>{ if(fs2){ exitFS2(); fs2=false; } });
      extCtx.canvas.addEventListener('dblclick', ()=>{ fs2?exitFS2():enterFS2(); fs2=!fs2; });
      document.addEventListener('keydown', (e)=>{ if (e.key==='F'||e.key==='f'){ fs2?exitFS2():enterFS2(); fs2=!fs2; } if(e.key==='Escape'&&fs2){ exitFS2(); fs2=false; } if(e.key==='0'&&typeof chartExt?.resetZoom==='function'){ chartExt.resetZoom(); } });

      // arrastre de alto
      let draggingH=false, startY=0, startH=0;
      extHandle.addEventListener('mousedown', (ev)=>{ draggingH=true; startY=ev.clientY; startH=extWrap.getBoundingClientRect().height; document.body.style.userSelect='none'; });
      window.addEventListener('mousemove', (ev)=>{ if (!draggingH) return; const h=Math.max(220, Math.min(900, startH + (ev.clientY-startY))); extWrap.style.height=h+'px'; extHRange.value=h; extHVal.textContent=h; chartExt?.resize(); });
      window.addEventListener('mouseup', ()=>{ if (!draggingH) return; draggingH=false; document.body.style.userSelect=''; localStorage.setItem('midas.extmetrics.height', String(parseInt(extWrap.style.height,10))); });

      // conectar / desconectar seleccionados
      function selectedAll(){ return getSelectedProviders(); }
      extConnSel.addEventListener('click', async ()=>{
        const sel = selectedAll().filter(p=>!connectedInit.has(p));
        if (!sel.length){ extStatus.textContent='No hay proveedores seleccionados para conectar.'; return; }
        for (const p of sel){ await connectProvider(p); }
      });
      extDiscSel.addEventListener('click', async ()=>{
        const sel = selectedAll().filter(p=>connectedInit.has(p));
        if (!sel.length){ extStatus.textContent='No hay proveedores seleccionados para desconectar.'; return; }
        for (const p of sel){ await disconnectProvider(p); }
      });

      // botón refrescar
      extRefreshBtn.addEventListener('click', refreshExtMetrics);

      // primer render
      await refreshExtMetrics();
    }catch(err){ console.error('No se pudo inicializar métricas externas:', err); extStatus.textContent='Error inicializando métricas externas.'; }
  })();

  /* ======= Paginaciones y acciones (tablas) ======= */
  const showAjaxError = async (r,p)=>{ try{ const t=p?null:await r.text(); alert((p&&(p.message||p?.data?.message))||t||'Error'); }catch(e){ alert('Error'); } };
  function ensureNonceOrWarn(type){ const ok=(type==='emp')?!!NONCE_EMP:!!NONCE_CM; if(!ok){ alert('Falta nonce. Recargá la página.'); } return ok; }

  // Documentos
  const filasDoc=[...document.querySelectorAll('#tbody-documentos .fila-doc')]; const perDoc=10; let pagDoc=1;
  function renderDocs(p){ pagDoc=p; const tp=Math.ceil(filasDoc.length/perDoc)||1;
    filasDoc.forEach((f,i)=> f.style.display=(i>=(p-1)*perDoc && i<p*perDoc)?'':'none');
    const $p=document.getElementById('paginacion-documentos'); if(tp<=1){ $p.innerHTML=''; return; }
    let h=''; if(p>1)h+=`<a href="#" data-pag="${p-1}" class="pagin-btn">&laquo; Anterior</a> `;
    for(let i=1;i<=tp;i++) h+=`<a href="#" data-pag="${i}" class="pagin-btn${i===p?' current':''}">${i}</a> `;
    if(p<tp) h+=`<a href="#" data-pag="${p+1}" class="pagin-btn">Siguiente &raquo;</a>`; $p.innerHTML=h;
  }
  document.getElementById('paginacion-documentos')?.addEventListener('click',e=>{ if(e.target.classList.contains('pagin-btn')){ e.preventDefault(); renderDocs(+e.target.dataset.pag); }});
  if(filasDoc.length) renderDocs(1);

  document.querySelectorAll('.btn-visto-doc').forEach(btn=>{
    btn.addEventListener('click', function(e){
      e.preventDefault();
      const id=this.dataset.id; if(!ensureNonceOrWarn('cm')) return;
      if(!confirm('¿Marcar este documento como visto?')) return;
      fetch(AJAX_URL,{ method:'POST', credentials:'include', headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},
        body:new URLSearchParams({ action:'midas_marcar_documento_visto', documento_id:id, midas_cm_nonce: NONCE_CM }) })
      .then(async r=>{ let p=null; try{ p=await r.json(); }catch(e){} if(!r.ok||!p?.success){ await showAjaxError(r,p); return; }
        const row=document.getElementById('doc-'+id); if(row){ row.style.opacity=0; setTimeout(()=>{ row.remove(); renderDocs(Math.max(1,pagDoc)); },220); } })
      .catch(()=>alert('Error al marcar como visto'));
    });
  });

  // Licencias
  const filasLic=[...document.querySelectorAll('#tbody-licencias .fila-lic')]; const perLic=10; let pagLic=1;
  function renderLic(p){ pagLic=p; const tp=Math.ceil(filasLic.length/perLic)||1;
    filasLic.forEach((f,i)=> f.style.display=(i>=(p-1)*perLic && i<p*perLic)?'':'none');
    const $p=document.getElementById('paginacion-licencias'); if(tp<=1){ $p.innerHTML=''; return; }
    let h=''; if(p>1)h+=`<a href="#" data-pag="${p-1}" class="pagin-btn-lic">&laquo; Anterior</a> `;
    for(let i=1;i<=tp;i++) h+=`<a href="#" data-pag="${i}" class="pagin-btn-lic${i===p?' current':''}">${i}</a> `;
    if(p<tp) h+=`<a href="#" data-pag="${p+1}" class="pagin-btn-lic">Siguiente &raquo;</a>`; $p.innerHTML=h;
  }
  document.getElementById('paginacion-licencias')?.addEventListener('click',e=>{ if(e.target.classList.contains('pagin-btn-lic')){ e.preventDefault(); renderLic(+e.target.dataset.pag); }});
  if(filasLic.length) renderLic(1);

  document.querySelectorAll('.btn-visto-lic').forEach(btn=>{
    btn.addEventListener('click', function(e){
      e.preventDefault();
      const id=this.dataset.id; if(!ensureNonceOrWarn('emp')) return;
      if(!confirm('¿Marcar esta licencia como gestionada/vista?')) return;
      fetch(AJAX_URL,{ method:'POST', credentials:'include', headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},
        body:new URLSearchParams({ action:'midas_marcar_licencia_vista', licencia_id:id, midas_empleados_nonce: NONCE_EMP }) })
      .then(async r=>{ let p=null; try{ p=await r.json(); }catch(e){} if(!r.ok||!p?.success){ await showAjaxError(r,p); return; }
        const row=document.getElementById('lic-'+id); if(row){ row.style.opacity=0; setTimeout(()=>{ row.remove(); renderLic(Math.max(1,pagLic)); },220); } })
      .catch(()=>alert('Error al marcar licencia como vista'));
    });
  });

  // Recibos
  const filasRec=[...document.querySelectorAll('#tbody-recibos .fila-rec')]; const perRec=10; let pagRec=1;
  function renderRec(p){ pagRec=p; const tp=Math.ceil(filasRec.length/perRec)||1;
    filasRec.forEach((f,i)=> f.style.display=(i>=(p-1)*perRec && i<p*perRec)?'':'none');
    const $p=document.getElementById('paginacion-recibos'); if(tp<=1){ $p.innerHTML=''; return; }
    let h=''; if(p>1)h+=`<a href="#" data-pag="${p-1}" class="pagin-btn-rec">&laquo; Anterior</a> `;
    for(let i=1;i<=tp;i++) h+=`<a href="#" data-pag="${i}" class="pagin-btn-rec${i===p?' current':''}">${i}</a> `;
    if(p<tp) h+=`<a href="#" data-pag="${p+1}" class="pagin-btn-rec">Siguiente &raquo;</a>`; $p.innerHTML=h;
  }
  document.getElementById('paginacion-recibos')?.addEventListener('click',e=>{ if(e.target.classList.contains('pagin-btn-rec')){ e.preventDefault(); renderRec(+e.target.dataset.pag); }});
  if(filasRec.length) renderRec(1);
  document.querySelectorAll('.btn-visto-rec').forEach(btn=>{
    btn.addEventListener('click', function(e){
      e.preventDefault();
      const id=this.dataset.id; if(!ensureNonceOrWarn('emp')) return;
      if(!confirm('¿Marcar este recibo como visto?')) return;
      fetch(AJAX_URL,{ method:'POST', credentials:'include', headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},
        body:new URLSearchParams({ action:'midas_marcar_recibo_visto', recibo_id:id, midas_empleados_nonce: NONCE_EMP }) })
      .then(async r=>{ let p=null; try{ p=await r.json(); }catch(e){} if(!r.ok||!p?.success){ await showAjaxError(r,p); return; }
        const row=document.getElementById('rec-'+id); if(row){ row.style.opacity=0; setTimeout(()=>{ row.remove(); renderRec(Math.max(1,pagRec)); },220); } })
      .catch(()=>alert('Error al marcar recibo como visto'));
    });
  });
});
</script>
