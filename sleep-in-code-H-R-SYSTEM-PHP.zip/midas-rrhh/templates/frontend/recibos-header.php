<?php if (!defined('ABSPATH')) exit; ?>
<h2 class="midas-panel-title"><?php esc_html_e('Recibos de Sueldo', 'midas-rrhh'); ?></h2>
