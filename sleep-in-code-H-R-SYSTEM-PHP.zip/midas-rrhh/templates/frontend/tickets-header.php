<?php if (!defined('ABSPATH')) exit; ?>
<h2 class="midas-panel-title"><?php esc_html_e('Abrir una Instancia', 'midas-rrhh'); ?></h2>
