<?php
if (!defined('ABSPATH')) exit;

// SIN "use": instanciamos con FQCN para evitar colisiones
$empleado_model = new \MidasRRHH\Models\Empleado_Model();
$controller     = new \MidasRRHH\Controllers\Carpeta_Medica_Controller();

$empleado = $empleado_model->get_by_user_id(get_current_user_id());

global $wpdb;
$enfermedades = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}midas_enfermedades ORDER BY tipo ASC");
$medicos      = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}midas_medicos ORDER BY nombre ASC");
?>
<?php if (!isset($GLOBALS['ajaxurl'])): ?>
<script>var ajaxurl = "<?= esc_url( admin_url('admin-ajax.php') ) ?>";</script>
<?php endif; ?>

<style>
/* Visual: MAYÚSCULAS solo en Observaciones (no afecta al valor real) */
#form-documento-medico input[name="observaciones"] { text-transform: uppercase; }

.midas-msg-ok   { padding:10px 14px; background:#e8fff0; border:1px solid #bfe8cf; color:#207245; border-radius:6px; margin-bottom:12px; }
.midas-msg-err  { padding:10px 14px; background:#fff1f1; border:1px solid #f2b4b4; color:#a32020; border-radius:6px; margin-bottom:12px; }
.midas-btn-principal { display:inline-block; padding:10px 16px; background:#2271b1; color:#fff; border:none; border-radius:6px; cursor:pointer; }
.midas-btn-principal:hover { background:#185a8d; }
.midas-disabled { opacity:.6; pointer-events:none; }

/* Ayudas y link-botón */
.midas-help{display:block;margin-top:6px;color:#555;font-size:.92em}
.midas-link-btn{background:none;border:0;padding:0;margin:8px 0 2px 0;color:#2271b1;text-decoration:underline;cursor:pointer;font-size:.92em}
.midas-link-btn:hover{color:#134e8a}

/* Mini formulario para nuevo médico */
#midas-add-medico{border:1px solid #dce1e6;background:#fafbfc;border-radius:8px;padding:12px; margin:8px 0 0 0}
#midas-add-medico[hidden]{display:none}
#midas-add-medico .row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
@media (max-width:600px){ #midas-add-medico .row{grid-template-columns:1fr} }
#midas-add-medico label{display:grid;gap:4px;font-size:.92em}
#midas-add-medico input{padding:7px;border:1px solid #c8d0d8;border-radius:6px}
#midas-add-medico .actions{display:flex;gap:8px;justify-content:flex-end;margin-top:8px}
.midas-btn-sec{background:#f6f7f7;border:1px solid #cdd3d8;border-radius:6px;padding:7px 12px;cursor:pointer}
.midas-btn-sec:hover{background:#eef0f2}
</style>

<div class="midas-panel-section midas-panel-datos">
  <div class="midas-form-wrapper">
    <div id="documento-medico-result"></div>

    <?php if (!$empleado): ?>
      <div style="padding:20px; max-width:480px; margin: 30px auto; border: 1px solid #cc3232; background: #fff0f0; color: #cc3232; font-weight: 700; text-align: center; border-radius: 8px; font-size: 1.05em;">
        <?php esc_html_e('NO ERES UN EMPLEADO DE RECURSOS HUMANOS PARA HACER ESTO', 'midas-rrhh'); ?>
      </div>
    <?php else: ?>
      <form id="form-documento-medico" method="post" enctype="multipart/form-data" autocomplete="off" novalidate>
        <?php wp_nonce_field('midas_empleados_nonce', 'midas_empleados_nonce'); ?>
        <input type="hidden" name="empleado_id" value="<?= esc_attr($empleado->id) ?>">
        <!-- Honeypot anti-bots -->
        <input type="text" name="website" value="" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px;height:0;width:0;opacity:0;">

        <!-- MÉDICO (mostrar matrícula como “nombre”) -->
        <div class="midas-form-group">
          <label>
            <span><strong><?php esc_html_e('Médico (selección por matrícula):', 'midas-rrhh'); ?></strong></span>
            <select name="medico_id" id="medico-select">
              <option value=""><?php esc_html_e('Seleccionar médico por matrícula', 'midas-rrhh'); ?></option>
              <?php foreach ($medicos as $med):
                $mat = trim($med->matricula ?: '');
                $label = $mat !== '' ? $mat : "{$med->apellido}, {$med->nombre}";
              ?>
                <option
                  value="<?= esc_attr($med->id) ?>"
                  data-nombre="<?= esc_attr($med->nombre) ?>"
                  data-apellido="<?= esc_attr($med->apellido) ?>"
                  data-especialidad="<?= esc_attr($med->especialidad) ?>"
                  data-matricula="<?= esc_attr($mat) ?>"
                ><?= esc_html($label) ?></option>
              <?php endforeach; ?>
            </select>
          </label>
          <small id="medico-seleccion-info" class="midas-help"></small>

          <!-- Enlace: no está mi médico -->
          <button type="button" id="toggle-add-medico" class="midas-link-btn">No existe Médico? (Ingresar)</button>

          <!-- Mini form: alta de médico (sin botón propio; se envía con el submit principal) -->
          <div id="midas-add-medico" hidden>
            <div class="row">
              <label>Nombre
                <input type="text" id="add-nombre" maxlength="191">
              </label>
              <label>Apellido
                <input type="text" id="add-apellido" maxlength="191">
              </label>
              <label>Especialidad
                <input type="text" id="add-especialidad" maxlength="191">
              </label>
              <label>Matrícula
                <input type="text" id="add-matricula" maxlength="191" placeholder="Ej: MN 12345">
              </label>
            </div>
            <div class="actions">
              <button type="button" class="midas-btn-sec" id="cancel-add-medico">Cancelar</button>
            </div>
          </div>
        </div>

        <div class="midas-form-group">
          <label>
            <span><strong><?php esc_html_e('Motivo (Tipo de enfermedad):', 'midas-rrhh'); ?></strong></span>
            <select name="motivo_id" id="motivo-enfermedad-select" required>
              <option value=""><?php esc_html_e('Seleccionar motivo', 'midas-rrhh'); ?></option>
              <?php foreach ($enfermedades as $enf): ?>
                <option value="<?= esc_attr($enf->id) ?>" data-desc="<?= esc_attr($enf->descripcion) ?>">
                  <?= esc_html($enf->tipo) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </label>
          <div id="desc-motivo-enfermedad" style="margin-top: 8px; color: #226; min-height: 16px;"></div>
        </div>

        <div class="midas-form-group">
          <label>
            <span><strong><?php esc_html_e('Fecha de emisión:', 'midas-rrhh'); ?></strong></span>
            <input type="date" name="fecha_emision" required>
          </label>
        </div>

        <div class="midas-form-group">
          <label>
            <span><strong><?php esc_html_e('Días solicitados:', 'midas-rrhh'); ?></strong></span>
            <input type="number" name="dias_solicitados" min="1" max="365" step="1" inputmode="numeric" required>
          </label>
        </div>

        <div class="midas-form-group">
          <label>
            <span><strong><?php esc_html_e('Observaciones:', 'midas-rrhh'); ?></strong></span>
            <input
              type="text"
              name="observaciones"
              maxlength="300"
              pattern="^[A-ZÁÉÍÓÚÑ0-9 .,;:¡!¿?\(\)\-_/#+%]*$"
              title="Solo letras mayúsculas (incluye tildes), números y . , ; : ¡ ! ¿ ? ( ) - _ / # + % (máx. 300).">
          </label>
        </div>

        <div class="midas-form-group">
          <label>
            <span><strong><?php esc_html_e('Archivo adjunto:', 'midas-rrhh'); ?></strong></span>
            <input
              type="file"
              name="documento"
              id="doc-file"
              accept="application/pdf,image/jpeg,image/png,image/webp"
              data-max-bytes="5242880"
              required>
          </label>
          <small id="doc-help" class="midas-help">PDF, JPG, PNG o WEBP. Tamaño máx. 5 MB.</small>
        </div>

        <button type="submit" class="midas-btn-principal" id="btn-submit-doc">
          <?php esc_html_e('Subir Documento', 'midas-rrhh'); ?>
        </button>
      </form>
    <?php endif; ?>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const resultDiv = document.getElementById('documento-medico-result');

  // ===== Helpers =====
  const ZERO_WIDTH = /[\u200B-\u200D\uFEFF]/g;
  const SPACE_LIKE = /[\u00A0\u1680\u2000-\u200A\u202F\u205F\u3000]/g;
  function normalizeNFKC(s){ try { return (s || '').normalize('NFKC'); } catch(_){ return (s||''); } }
  function toUpper(s){ return normalizeNFKC((s||'').replace(ZERO_WIDTH,'').replace(SPACE_LIKE,' ')).toUpperCase(); }
  const showOK   = (msg)=> resultDiv.innerHTML = '<div class="midas-msg-ok">'+(msg||'OK')+'</div>';
  const showError= (msg)=> resultDiv.innerHTML = '<div class="midas-msg-err">'+(msg||'Ocurrió un error')+'</div>';

  // ====== MÉDICOS: mostrar info y alta rápida ======
  const selMedico   = document.getElementById('medico-select');
  const infoMedico  = document.getElementById('medico-seleccion-info');
  const toggleBtn   = document.getElementById('toggle-add-medico');
  const formAdd     = document.getElementById('midas-add-medico');
  const btnCancel   = document.getElementById('cancel-add-medico');

  function paintMedicoInfo(){
    const opt = selMedico.options[selMedico.selectedIndex];
    if (!opt || !opt.value) { infoMedico.textContent = ''; return; }
    const nombre = opt.getAttribute('data-nombre') || '';
    const apellido = opt.getAttribute('data-apellido') || '';
    const esp = opt.getAttribute('data-especialidad') || '';
    const mat = opt.getAttribute('data-matricula') || '';
    infoMedico.textContent = `${apellido}, ${nombre}${esp?(' · '+esp):''}${mat?(' · Matrícula: '+mat):''}`;
  }
  selMedico?.addEventListener('change', paintMedicoInfo);
  paintMedicoInfo();

  // Toggle mini form
  toggleBtn?.addEventListener('click', ()=>{ formAdd.hidden = !formAdd.hidden; });
  btnCancel?.addEventListener('click', ()=>{ formAdd.hidden = true; });

  // ===== Select Motivo (ayuda) =====
  const selMotivo = document.getElementById('motivo-enfermedad-select');
  const descDiv   = document.getElementById('desc-motivo-enfermedad');
  selMotivo?.addEventListener('change', function() {
    const selected = selMotivo.options[selMotivo.selectedIndex];
    const desc = selected ? (selected.getAttribute('data-desc') || '') : '';
    descDiv.textContent = desc ? 'Descripción: ' + desc : '';
  });

  // ===== Fecha =====
  const fechaInput = document.querySelector('input[name="fecha_emision"]');
  function setFechaDefaultIfEmpty() {
    if (!fechaInput) return;
    const today = new Date();
    const y = today.getFullYear();
    const m = String(today.getMonth()+1).padStart(2,'0');
    const d = String(today.getDate()).padStart(2,'0');
    const todayStr = `${y}-${m}-${d}`;
    fechaInput.max = todayStr;
    fechaInput.min = '2000-01-01';
    if (!fechaInput.value) fechaInput.value = todayStr; // valor por defecto = hoy
  }
  setFechaDefaultIfEmpty();

  // ===== Días =====
  const diasInput = document.querySelector('input[name="dias_solicitados"]');
  if (diasInput) {
    const clamp = () => {
      let v = normalizeNFKC(diasInput.value).replace(/\D/g,''); if (!v) v = '1';
      let n = Math.max(1, Math.min(365, parseInt(v,10) || 1));
      diasInput.value = String(n); diasInput.setCustomValidity('');
    };
    diasInput.addEventListener('input', clamp);
    diasInput.addEventListener('blur', clamp);
  }

  // ===== Observaciones =====
  const obsInput = document.querySelector('#form-documento-medico input[name="observaciones"]');
  const OBS_ALLOWED = /[^A-ZÁÉÍÓÚÑ0-9 .,;:¡!¿?\(\)\-_/#+%]/g;
  function sanitizeObsFinal(v){
    v = toUpper(v).replace(/[<>]/g, '').replace(OBS_ALLOWED,'').replace(/\s+/g,' ').trim();
    if (v.length > 300) v = v.slice(0,300); return v;
  }
  function sanitizeObsSoft(v){
    v = toUpper(v).replace(/[<>]/g,'').replace(OBS_ALLOWED,''); if (v.length>300) v=v.slice(0,300); return v;
  }
  if (obsInput){
    obsInput.addEventListener('input', ()=>{
      const s=obsInput.selectionStart, e=obsInput.selectionEnd;
      const clean = sanitizeObsSoft(obsInput.value); obsInput.value = clean;
      try{ obsInput.setSelectionRange(s,e); }catch(_){}
    });
    obsInput.addEventListener('blur', ()=>{ obsInput.value = sanitizeObsFinal(obsInput.value); });
    obsInput.addEventListener('paste', (e)=>{
      e.preventDefault();
      const t=(e.clipboardData||window.clipboardData).getData('text')||'';
      const s=obsInput.selectionStart, en=obsInput.selectionEnd; const insert=sanitizeObsSoft(t);
      obsInput.value = obsInput.value.slice(0,s) + insert + obsInput.value.slice(en);
      const pos=s+insert.length; obsInput.setSelectionRange(pos,pos);
    });
  }

  // ===== Archivo =====
  const fileInput = document.getElementById('doc-file');
  const btnSubmit = document.getElementById('btn-submit-doc');
  const ALLOWED_MIMES = new Set(['application/pdf','image/jpeg','image/png','image/webp']);
  const ALLOWED_EXTS  = new Set(['pdf','jpg','jpeg','png','webp']);
  const MAX_BYTES     = fileInput ? parseInt(fileInput.getAttribute('data-max-bytes') || '5242880', 10) : 5242880;

  function getExt(name){ const m = (name||'').toLowerCase().match(/\.([a-z0-9]+)$/); return m ? m[1] : ''; }
  function readHead(file, bytes){
    return new Promise((resolve, reject)=>{
      const fr = new FileReader();
      fr.onerror = () => reject(new Error('read error'));
      fr.onload  = () => resolve(new Uint8Array(fr.result || new ArrayBuffer(0)));
      fr.readAsArrayBuffer(file.slice(0, bytes));
    });
  }
  async function hasValidMagic(file){
    try {
      const head = await readHead(file, 12);
      if (head.length >= 5 && head[0]===0x25 && head[1]===0x50 && head[2]===0x44 && head[3]===0x46 && head[4]===0x2D) return true; // %PDF-
      if (head.length >= 3 && head[0]===0xFF && head[1]===0xD8 && head[2]===0xFF) return true; // JPEG
      const pngSig = [0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A];
      if (head.length >= 8 && pngSig.every((b,i)=> head[i]===b)) return true; // PNG
      if (head.length >= 12) {
        const riff = String.fromCharCode(head[0],head[1],head[2],head[3]);
        const webp = String.fromCharCode(head[8],head[9],head[10],head[11]);
        if (riff === 'RIFF' && webp === 'WEBP') return true; // WEBP
      }
    } catch(_){}
    return false;
  }
  function invalidFile(msg){
    fileInput.value = ''; fileInput.setCustomValidity(msg || 'Archivo inválido.'); showError(msg || 'Archivo inválido.');
  }
  function validFile(){ fileInput.setCustomValidity(''); }
  async function validateFileInput(){
    const f = fileInput.files && fileInput.files[0];
    if (!f) { invalidFile('Debes seleccionar un archivo.'); return false; }
    if (f.size > MAX_BYTES) { invalidFile('Archivo demasiado grande (máx. 5 MB).'); return false; }
    const ext  = getExt(f.name);
    const type = (f.type || '').toLowerCase();
    if (!ALLOWED_EXTS.has(ext) || (type && !ALLOWED_MIMES.has(type))) { invalidFile('Tipo no permitido. Usa PDF, JPG, PNG o WEBP.'); return false; }
    if (!(await hasValidMagic(f))) { invalidFile('El contenido del archivo no coincide con su tipo.'); return false; }
    validFile(); return true;
  }
  fileInput?.addEventListener('change', validateFileInput);

  // ===== Submit principal =====
  const form = document.getElementById('form-documento-medico');
  const selMotivosSet = new Set(Array.from(document.querySelectorAll('#motivo-enfermedad-select option')).map(o=>o.value).filter(Boolean));
  const selMedicosSet = new Set(Array.from(document.querySelectorAll('#medico-select option')).map(o=>o.value).filter(Boolean));

  function validateSelectMembership(selectEl, validSet, msg){
    const val = (selectEl.value || '').trim();
    if (!val || !validSet.has(val)) { selectEl.setCustomValidity(msg||'Selección inválida.'); return false; }
    selectEl.setCustomValidity(''); return true;
  }

  if (form) {
    form.addEventListener('submit', async function(e) {
      e.preventDefault();

      // Honeypot
      const honeypot = form.querySelector('input[name="website"]');
      if (honeypot && honeypot.value) { showError('Error de validación.'); return; }

      // Forzar validación HTML5 (required/pattern/etc.)
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }

      // Observaciones (normalización final)
      if (obsInput) obsInput.value = sanitizeObsFinal(obsInput.value);

      // Archivo (firma + tamaño + tipo)
      if (!(await validateFileInput())) return;

      // ¿Usaremos alta de médico inline?
      const nombreN = toUpper(document.getElementById('add-nombre')?.value || '').trim();
      const apellidoN = toUpper(document.getElementById('add-apellido')?.value || '').trim();
      const especialidadN = toUpper(document.getElementById('add-especialidad')?.value || '').trim();
      const matriculaN = toUpper(document.getElementById('add-matricula')?.value || '').trim();
      const usingNuevoMedico = !formAdd.hidden && (nombreN || apellidoN || matriculaN);

      // Validaciones de médico
      if (usingNuevoMedico) {
        if (!nombreN || !apellidoN || !matriculaN) {
          showError('Completá Nombre, Apellido y Matrícula del médico.');
          return;
        }
        selMedico.setCustomValidity('');
      } else {
        if (!validateSelectMembership(selMedico, selMedicosSet, 'Médico inválido.')) {
          selMedico.reportValidity(); return;
        }
      }

      // Motivo (pertenencia)
      if (!validateSelectMembership(document.getElementById('motivo-enfermedad-select'), selMotivosSet, 'Motivo inválido.')) {
        document.getElementById('motivo-enfermedad-select').reportValidity(); return;
      }

      // Enviar
      btnSubmit.classList.add('midas-disabled'); btnSubmit.setAttribute('aria-busy','true');
      showOK('Enviando...');

      const formData = new FormData(form);
      formData.append('action', 'midas_crear_documento_medico');

      // Si hay alta inline de médico, adjuntamos campos especiales
      if (usingNuevoMedico) {
        formData.set('medico_id', '');
        formData.append('nuevo_medico_flag', '1');
        formData.append('nuevo_medico_nombre', nombreN);
        formData.append('nuevo_medico_apellido', apellidoN);
        formData.append('nuevo_medico_especialidad', especialidadN);
        formData.append('nuevo_medico_matricula', matriculaN);
      }

      try {
        const res = await fetch(ajaxurl, { method:'POST', body:formData, credentials:'include', headers:{'X-Requested-With':'XMLHttpRequest'} });
        const data = await res.json().catch(()=>null);

        btnSubmit.classList.remove('midas-disabled'); btnSubmit.removeAttribute('aria-busy');

        if (res.ok && data && data.success) {
          showOK('Documento subido correctamente.');
          form.reset();
          setFechaDefaultIfEmpty(); // volver a poner la fecha en "hoy" tras reset
          document.getElementById('desc-motivo-enfermedad').textContent = '';
          validFile();
          infoMedico.textContent='';
          formAdd.hidden = true; // cerramos mini-form
        } else {
          let errorMsg = 'Error al subir el documento médico';
          if (data) {
            if (typeof data.data === 'string') errorMsg = data.data;
            else if (data.data && data.data.message) errorMsg = data.data.message;
          }
          showError(errorMsg);
        }
      } catch(_){
        btnSubmit.classList.remove('midas-disabled'); btnSubmit.removeAttribute('aria-busy');
        showError('Error inesperado, intente de nuevo.');
      }
    });
  }
});
</script>
