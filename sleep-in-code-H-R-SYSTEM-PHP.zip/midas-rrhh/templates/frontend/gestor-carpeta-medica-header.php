<?php if (!defined('ABSPATH')) exit; ?>
<h2 class="midas-panel-title"><?php esc_html_e('Gestión de Documentos Médicos', 'midas-rrhh'); ?></h2>
