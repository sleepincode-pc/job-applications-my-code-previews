<?php
if (!defined('ABSPATH')) exit;

use MidasRRHH\Models\Recibo_Model;
use MidasRRHH\Models\Empleado_Model;

/* === Usuario actual === */
$current_user = wp_get_current_user();

/* === Empleado asociado al usuario actual === */
$empleado_model = new Empleado_Model();
$empleado       = $empleado_model->get_by_user_id($current_user->ID);

/* === Recibos: SIEMPRE solo los del usuario actual === */
$recibo_model = new Recibo_Model();
$recibos      = [];

if ($empleado && isset($empleado->id)) {
    $emp_id = (int) $empleado->id;
    if (method_exists($recibo_model, 'get_by_empleado_id')) {
        $recibos = (array) $recibo_model->get_by_empleado_id($emp_id);
    } elseif (method_exists($recibo_model, 'get_for_empleado')) {
        $recibos = (array) $recibo_model->get_for_empleado($emp_id);
    } else {
        $todos = (array) $recibo_model->get_all();
        foreach ($todos as $r) if ((int)($r->empleado_id ?? 0) === $emp_id) $recibos[] = $r;
    }
} else {
    echo '<div style="color:#e74c3c;font-size:1.1em;margin:24px 0;text-align:center;">'
        . esc_html__('No tienes un perfil de empleado asociado.', 'midas-rrhh')
        . '</div>';
    return;
}

/* === Helper (compatibilidad) === */
if (!function_exists('midas_resolver_empleado_label')) {
function midas_resolver_empleado_label($empleado_id){
    $empleado_id = (int)$empleado_id; if ($empleado_id <= 0) return '-';
    static $cache = []; if (isset($cache[$empleado_id])) return $cache[$empleado_id];
    $label = '#'.$empleado_id;
    try {
        if (class_exists('\MidasRRHH\Models\Empleado_Model')) {
            $em = new \MidasRRHH\Models\Empleado_Model();
            $e  = method_exists($em,'get_by_id') ? $em->get_by_id($empleado_id) : (method_exists($em,'get') ? $em->get($empleado_id) : null);
            if ($e && (isset($e->nombre) || isset($e->apellido))) {
                $n = trim(($e->nombre ?? '') . ' ' . ($e->apellido ?? ''));
                if ($n !== '') $label = $n;
            }
        }
    } catch (\Throwable $th) {}
    return $cache[$empleado_id] = $label;
}}
/* === Tabla de recibos (sin columna empleado) === */
if (!function_exists('midas_tabla_recibos')) {
function midas_tabla_recibos($recibos, $is_admin = false) { ?>
    <div class="midas-table-responsive" style="margin:8px 0;">
        <table class="midas-table midas-table-mini">
            <thead>
                <tr>
                    <?php if ($is_admin): /* no se usa aquí */ ?>
                        <th><?php _e('Empleado', 'midas-rrhh'); ?></th>
                    <?php endif; ?>
                    <th><?php _e('Periodo', 'midas-rrhh'); ?></th>
                    <th><?php _e('Monto', 'midas-rrhh'); ?></th>
                    <th><?php _e('Detalle', 'midas-rrhh'); ?></th>
                    <th><?php _e('Archivo', 'midas-rrhh'); ?></th>
                </tr>
            </thead>
            <tbody>
            <?php if (!empty($recibos)): foreach ($recibos as $recibo):
                $periodo = $recibo->periodo ?? '-';
                $monto   = isset($recibo->monto) ? number_format((float)$recibo->monto, 2, ',', '.') : '-';
                $det     = $recibo->detalles ?? '';
                $aid     = (int)($recibo->archivo_id ?? 0);
                $eid     = (int)($recibo->empleado_id ?? 0);
                $urlpdf  = $aid ? wp_get_attachment_url($aid) : '';
            ?>
                <tr>
                    <?php if ($is_admin): /* no se mostrará */ ?>
                        <td><?php echo esc_html(midas_resolver_empleado_label($eid)); ?></td>
                    <?php endif; ?>
                    <td><?php echo esc_html($periodo); ?></td>
                    <td>$<?php echo esc_html($monto); ?></td>
                    <td><?php echo esc_html($det); ?></td>
                    <td>
                        <?php if ($urlpdf): ?>
                            <a href="<?php echo esc_url($urlpdf); ?>" target="_blank" class="midas-card-btn" rel="noopener">
                                <span class="lbl"><?php _e('Ver PDF', 'midas-rrhh'); ?></span><span class="lbl-short">PDF</span>
                            </a>
                        <?php else: ?><em>-</em><?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; else: ?>
                <tr><td colspan="4"><em><?php _e('No hay recibos disponibles.', 'midas-rrhh'); ?></em></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php } } // fin función
?>
<style>
/* ===== Modal compacto con scroll interno ===== */
.midas-modal-lic{display:none;position:fixed;z-index:1005;left:0;top:0;width:100vw;height:100vh;justify-content:center;align-items:center;background:rgba(36,39,48,.17)}
.midas-modal-lic .midas-modal-bg{position:absolute;inset:0;background:rgba(36,39,48,.23);backdrop-filter:blur(1.5px)}
.midas-modal-lic .midas-modal-content{position:relative;background:#fff;border-radius:16px;box-shadow:0 8px 44px #0002;padding:18px 16px;min-width:300px;max-width:520px;width:92%;max-height:min(680px,calc(100vh - 80px));display:flex;flex-direction:column;gap:8px;z-index:2}
.midas-modal-lic .midas-modal-close{position:absolute;right:8px;top:6px;background:transparent;border:none;font-size:1.6em;color:#bd2839;font-weight:700;cursor:pointer;line-height:1}
.midas-modal-lic h2{font-size:1.05rem;margin:0 24px 6px 2px;text-align:center}

/* Área scrolleable dentro del modal */
.midas-table-responsive{width:100%;overflow:auto;-webkit-overflow-scrolling:touch;flex:1 1 auto;border:1px solid #f0f0f0;border-radius:10px}

/* ===== Tabla compacta ===== */
.midas-table.midas-table-mini{width:100%;border-collapse:separate;border-spacing:0}
.midas-table.midas-table-mini th,.midas-table.midas-table-mini td{padding:6px 8px;border-bottom:1px solid #eee;font-size:.95em;line-height:1.25;text-align:left;color:#333;background:#fff}
.midas-table.midas-table-mini th{background:#f4f8fb;color:#26324b;font-weight:700;position:sticky;top:0;z-index:1}
.midas-table.midas-table-mini tr:last-child td{border-bottom:none}

/* Botón PDF */
.midas-card-btn{display:inline-block;padding:5px 12px;background:#488DDE!important;color:#fff!important;border-radius:10px;text-decoration:none;font-weight:700;font-size:.9em;transition:filter .18s;border:none;cursor:pointer}
.midas-card-btn:hover{filter:brightness(0.95)}
.midas-card-btn .lbl-short{display:none}

/* ===== CTA centrada tipo “Mis instancias” ===== */
.midas-cta-center{
  width:100%;
  display:flex;
  justify-content:center;
  align-items:center;
  /* Altura adaptable para centrar verticalmente dentro del panel */
  min-height:48vh;              /* centra en pantallas comunes */
  padding:24px 0;
}
@media (min-height:900px){ .midas-cta-center{ min-height:60vh; } }
@media (max-width:600px){ .midas-cta-center{ min-height:38vh; } }

.midas-btn-principal{
  background:#488DDE!important;color:#fff!important;border:none!important;border-radius:14px!important;
  padding:16px 40px;font-size:1.2em;font-weight:700;cursor:pointer;transition:filter .18s;box-shadow:0 4px 18px #0001;margin:0 auto
}
.midas-btn-principal:hover{filter:brightness(0.95)}
/* Ancho grande como el de “Mis instancias” */
.midas-btn-lg{width:570px;max-width:92vw;text-align:center}

body.midas-modal-lic-open{overflow:hidden}

/* Mobile */
@media (max-width:600px){
 .midas-modal-lic .midas-modal-content{max-height:calc(100vh - 60px);padding:14px 12px}
 .midas-modal-lic h2{font-size:1rem}
 .midas-table.midas-table-mini th,.midas-table.midas-table-mini td{padding:6px 6px;font-size:.88em}
 .midas-card-btn{padding:4px 10px;font-size:.85em;border-radius:8px}
 .midas-card-btn .lbl{display:none}
 .midas-card-btn .lbl-short{display:inline}
}
</style>

<div class="midas-panel-section midas-panel-datos">
    <div class="midas-cta-center">
        <button class="midas-btn-principal midas-btn-lg" onclick="abrirModalRecibos()">
            <?php echo esc_html__('Ver Recibos', 'midas-rrhh') . ' (' . count($recibos) . ')'; ?>
        </button>
    </div>

    <!-- MODAL -->
    <div id="modal-recibos" class="midas-modal-lic" style="display:none;">
        <div class="midas-modal-bg" onclick="cerrarModalRecibos()"></div>
        <div class="midas-modal-content">
            <button onclick="cerrarModalRecibos()" class="midas-modal-close" aria-label="<?php esc_attr_e('Cerrar', 'midas-rrhh'); ?>">&times;</button>
            <h2><?php _e('Recibos de Sueldo', 'midas-rrhh'); ?></h2>
            <?php midas_tabla_recibos($recibos, false); ?>
        </div>
    </div>
</div>

<script>
function abrirModalRecibos(){
    const sbw = window.innerWidth - document.documentElement.clientWidth;
    document.body.classList.add('midas-modal-lic-open');
    if (sbw > 0) document.body.style.paddingRight = sbw + 'px';
    document.getElementById('modal-recibos').style.display='flex';
}
function cerrarModalRecibos(){
    document.body.classList.remove('midas-modal-lic-open');
    document.body.style.paddingRight = '';
    document.getElementById('modal-recibos').style.display='none';
}
document.addEventListener('keydown', e => { if(e.key === 'Escape') cerrarModalRecibos(); });
</script>
