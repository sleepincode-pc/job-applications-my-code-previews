<?php if (!defined('ABSPATH')) exit; ?>

<?php
// ================= Helpers =================

// Antigüedad
if (!function_exists('midas_calcular_antiguedad')) {
    function midas_calcular_antiguedad($inicio, $fin = null) {
        if (!$inicio || $inicio === '0000-00-00') return '—';
        try {
            $date_inicio = new DateTime($inicio);
            $date_fin    = ($fin && $fin !== '0000-00-00') ? new DateTime($fin) : new DateTime('now');
            if ($date_fin < $date_inicio) return '—';
            $int  = $date_inicio->diff($date_fin);
            $y    = $int->y;
            $dias = $int->days - ($y * 365);
            if ($dias < 0) $dias = 0;
            if ($y > 0 && $dias > 0)  return "{$y} años, {$dias} días";
            if ($y > 0)               return "{$y} años";
            if ($dias > 0)            return "{$dias} días";
            return 'Menos de 1 día';
        } catch (Exception $e) { return '—'; }
    }
}

/**
 * Busca y normaliza la "Documentación con Vencimiento" del empleado,
 * autodetectando tablas/columnas: robusto ante cambios de esquema.
 * Devuelve objetos: (titulo, vence [Y-m-d|null], estado|null)
 */
if (!function_exists('midas_docv_obtener_para_empleado')) {
    function midas_docv_obtener_para_empleado($empleado_id) {
        global $wpdb;
        $px = $wpdb->prefix;

        // Tablas candidatas (documentos)
        $doc_tables = [
            "{$px}midas_docv_documentos",
            "{$px}midas_docv_docs",
            "{$px}midas_documentaciones",
            "{$px}midas_documentos_vencimiento",
            "{$px}midas_doc_documentos",
            "{$px}midas_docv",
            "{$px}midas_documentos",
        ];
        // Tablas candidatas (tipos)
        $type_tables = [
            "{$px}midas_docv_tipos",
            "{$px}midas_doc_tipos",
            "{$px}midas_documentos_tipos",
        ];

        // Helpers
        $first_existing_table = function(array $cands) use ($wpdb) {
            foreach ($cands as $t) {
                if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t))) return $t;
            }
            return null;
        };
        $get_columns = function($table) use ($wpdb) {
            $rows = $wpdb->get_results("SHOW COLUMNS FROM `{$table}`");
            if (!$rows) return [];
            return array_map(function($r){ return $r->Field ?? $r->COLUMN_NAME ?? ''; }, $rows);
        };
        $first_present = function(array $wanted, array $cols) {
            foreach ($wanted as $w) if (in_array($w, $cols, true)) return $w;
            return null;
        };

        // Detectar tabla de documentos
        $tb_docs = $first_existing_table($doc_tables);
        if (!$tb_docs) return [];

        // Columnas existentes
        $cols = $get_columns($tb_docs);
        if (empty($cols)) return [];

        // Columna del empleado (en orden de preferencia)
        $emp_col = $first_present(['empleado_id','id_empleado','empleado','user_id','usuario_id','persona_id'], $cols);
        if (!$emp_col) return []; // no hay forma de filtrar por empleado

        // Columna de tipo (para join)
        $tipo_id_col = $first_present(['tipo_id','id_tipo','doc_tipo_id','documento_tipo_id','tipo'], $cols);

        // Columnas de fecha de FIN/VENCIMIENTO (en preferencia)
        $date_end_candidates = ['fecha_vencimiento','vencimiento','fecha_fin','fecha_final','fin','vence','fecha_hasta'];
        $date_end_cols = array_values(array_filter($date_end_candidates, fn($c)=>in_array($c,$cols,true)));

        // Tabla de tipos (si existe)
        $tb_types = $first_existing_table($type_tables);
        $type_cols = $tb_types ? $get_columns($tb_types) : [];
        $type_name_col = $tb_types ? $first_present(['descripcion','nombre','tipo','titulo'], $type_cols) : null;

        // SELECT
        $select = "SELECT d.*";
        $join   = "";
        if ($tb_types && $tipo_id_col && $type_name_col && in_array('id', $type_cols, true)) {
            $select .= ", t.`{$type_name_col}` AS tipo_nombre";
            $join    = " LEFT JOIN `{$tb_types}` t ON t.`id` = d.`{$tipo_id_col}` ";
        }

        // ORDER BY
        $order_expr = "d.`id` DESC";
        if (!empty($date_end_cols)) {
            $coalesce = implode(", ", array_map(fn($c)=>"d.`{$c}`", $date_end_cols));
            $order_expr = "COALESCE({$coalesce}) ASC";
        }

        // WHERE
        $sql = "
            {$select}
            FROM `{$tb_docs}` d
            {$join}
            WHERE d.`{$emp_col}` = %d
            ORDER BY {$order_expr}
        ";

        $rows = $wpdb->get_results($wpdb->prepare($sql, (int)$empleado_id));
        if (empty($rows)) return [];

        // Normalizar
        $out = [];
        foreach ($rows as $r) {
            // Título
            $titulo = '';
            foreach (['tipo_nombre','titulo','tipo','nombre','documento','descripcion','detalle'] as $k) {
                if (isset($r->$k) && $r->$k !== '') { $titulo = (string)$r->$k; break; }
            }
            if ($titulo === '') $titulo = 'Documento';

            // Fecha de fin/vencimiento
            $vence = null;
            foreach (array_unique(array_merge($date_end_candidates, ['fecha'])) as $k) {
                if (!empty($r->$k) && $r->$k !== '0000-00-00' && $r->$k !== '0000-00-00 00:00:00') {
                    $vence = substr((string)$r->$k, 0, 10);
                    break;
                }
            }

            // Estado (si existe)
            $estado = null;
            foreach (['estado','status'] as $k) {
                if (isset($r->$k) && $r->$k !== '') { $estado = (string)$r->$k; break; }
            }

            $out[] = (object)[ 'titulo' => $titulo, 'vence' => $vence, 'estado' => $estado ];
        }
        return $out;
    }
}
?>

<h3 class="midas-panel-section-title"><?php esc_html_e('Mis Datos Personales', 'midas-rrhh'); ?></h3>

<?php
// Traer documentación con vencimiento
$docv_items = !empty($empleado->id) ? midas_docv_obtener_para_empleado((int)$empleado->id) : [];
// Elegir el principal: el de vencimiento más próximo con fecha válida, o el primero disponible
$principal = null;
foreach ($docv_items as $it) { if (!empty($it->vence)) { $principal = $it; break; } }
if (!$principal && !empty($docv_items)) $principal = $docv_items[0];

// Preparar textos del badge
$badge_txt = '';
$badge_cls = 'vigente';
$vence_txt = '—';
if ($principal && !empty($principal->vence)) {
    $hoy = date_i18n('Y-m-d');
    $vence_txt = date_i18n('d/m/Y', strtotime($principal->vence));
    if ($principal->vence < $hoy) {
        $badge_txt = __('Vencido', 'midas-rrhh'); $badge_cls = 'vencido';
    } else {
        $dias = (int) floor((strtotime($principal->vence) - strtotime($hoy)) / DAY_IN_SECONDS);
        if ($dias <= 60) { $badge_txt = sprintf(__('Vence en %d días', 'midas-rrhh'), max(0,$dias)); $badge_cls = 'proximo'; }
        else { $badge_txt = __('Vigente', 'midas-rrhh'); $badge_cls = 'vigente'; }
    }
}
?>

<style>
/* Badge chiquito para la grilla */
.midas-docv-badge{display:inline-block;font-size:11px;border-radius:999px;padding:2px 8px;margin-left:6px;vertical-align:middle}
.midas-docv-badge.vigente{background:#e6f7ef;color:#167a4a;border:1px solid #bde6d1}
.midas-docv-badge.proximo{background:#fff7e6;color:#ad6800;border:1px solid #ffe1b0}
.midas-docv-badge.vencido{background:#fff1f0;color:#a8071a;border:1px solid #ffccc7}
.midas-docv-date{display:block;margin-top:4px;opacity:.85}
</style>

<div class="midas-datos-grid">
    <div>
        <strong><?php esc_html_e('Nombre:', 'midas-rrhh'); ?></strong>
        <span><?php echo esc_html($empleado->nombre); ?></span>
    </div>
    <div>
        <strong><?php esc_html_e('Apellido:', 'midas-rrhh'); ?></strong>
        <span><?php echo esc_html($empleado->apellido); ?></span>
    </div>
    <div>
        <strong><?php esc_html_e('DNI:', 'midas-rrhh'); ?></strong>
        <span><?php echo esc_html($empleado->dni); ?></span>
    </div>
    <div>
        <strong><?php esc_html_e('Correo:', 'midas-rrhh'); ?></strong>
        <span><?php echo esc_html($empleado->email); ?></span>
    </div>
    <div>
        <strong><?php esc_html_e('Área:', 'midas-rrhh'); ?></strong>
        <span><?php echo esc_html($empleado->area_nombre); ?></span>
    </div>
    <div>
        <strong><?php esc_html_e('Tarea:', 'midas-rrhh'); ?></strong>
        <span><?php echo esc_html($empleado->tarea_nombre); ?></span>
    </div>
    <div>
        <strong><?php esc_html_e('Fecha de inicio laboral:', 'midas-rrhh'); ?></strong>
        <span>
            <?php 
                echo !empty($empleado->fecha_inicio_laboral) 
                    ? esc_html(date_i18n('d/m/Y', strtotime($empleado->fecha_inicio_laboral))) 
                    : '-';
            ?>
        </span>
    </div>
    <div>
        <strong><?php esc_html_e('Fecha de fin laboral:', 'midas-rrhh'); ?></strong>
        <span>
            <?php 
                echo !empty($empleado->fecha_fin_laboral) && $empleado->fecha_fin_laboral !== '0000-00-00'
                    ? esc_html(date_i18n('d/m/Y', strtotime($empleado->fecha_fin_laboral)))
                    : esc_html__('Activo', 'midas-rrhh');
            ?>
        </span>
    </div>
    <div>
        <strong><?php esc_html_e('Antigüedad:', 'midas-rrhh'); ?></strong>
        <span>
            <?php
                echo esc_html(midas_calcular_antiguedad(
                    $empleado->fecha_inicio_laboral ?? '',
                    $empleado->fecha_fin_laboral ?? null
                ));
            ?>
        </span>
    </div>

    <!-- ====== NUEVO ITEM EN LA GRILLA ====== -->
    <div>
        <strong><?php esc_html_e('Doc. con vencimiento:', 'midas-rrhh'); ?></strong>
        <span>
            <?php if (!$principal): ?>
                —
            <?php else: ?>
                <?php echo esc_html($principal->titulo); ?>
                <?php if ($badge_txt): ?>
                    <span class="midas-docv-badge <?php echo esc_attr($badge_cls); ?>"><?php echo esc_html($badge_txt); ?></span>
                <?php endif; ?>
                <span class="midas-docv-date">
                    <strong><?php esc_html_e('VENCE EL:', 'midas-rrhh'); ?></strong>
                    <?php echo ' ' . esc_html($vence_txt); ?>
                </span>
            <?php endif; ?>
        </span>
    </div>
</div>

<?php
// Pie "Creado el"
if (!empty($empleado->created_at) && $empleado->created_at !== '0000-00-00 00:00:00') {
    $fecha_creado = DateTime::createFromFormat('Y-m-d H:i:s', $empleado->created_at);
    if ($fecha_creado) {
        echo '<div style="margin-top:16px;font-size:15px;color:#1976d2;font-weight:600;">
            <span style="opacity:.7;">' . esc_html__('Creado el', 'midas-rrhh') . ' ' . esc_html($fecha_creado->format('d/m/Y H:i')) . '</span>
        </div>';
    }
}
?>
