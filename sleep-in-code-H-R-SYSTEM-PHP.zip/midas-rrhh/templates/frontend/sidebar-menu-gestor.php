<?php
// Sidebar de GESTOR RRHH (sin submenús, solo accesos directos)
$rrhh_url = site_url('/recursos-humanos/');

if (!function_exists('midas_is_active_panel_gestor')) {
    function midas_is_active_panel_gestor($panel) {
        $current = isset($_GET['panel_gestor']) ? $_GET['panel_gestor'] : 'gestionar-licencias';
        return $current === $panel;
    }
}
?>

<nav class="midas-sidebar">
    <ul class="midas-menu">
        <li class="midas-menu-item">
            <a href="<?php echo esc_url($rrhh_url . '?panel_gestor=gestionar-recibos'); ?>"
               class="<?php echo midas_is_active_panel_gestor('gestionar-recibos') ? 'active' : ''; ?>">
                <span class="dashicons dashicons-media-document"></span> Ver Recibos
            </a>
        </li>
        <li class="midas-menu-item">
            <a href="<?php echo esc_url($rrhh_url . '?panel_gestor=gestionar-licencias'); ?>"
               class="<?php echo midas_is_active_panel_gestor('gestionar-licencias') ? 'active' : ''; ?>">
                <span class="dashicons dashicons-calendar-alt"></span> Ver Licencias
            </a>
        </li>
        <li class="midas-menu-item">
            <a href="<?php echo esc_url($rrhh_url . '?panel_gestor=gestionar-carpeta-medica'); ?>"
               class="<?php echo midas_is_active_panel_gestor('gestionar-carpeta-medica') ? 'active' : ''; ?>">
                <span class="dashicons dashicons-clipboard"></span> Ver Carpetas Médicas
            </a>
        </li>
        <li class="midas-menu-item">
            <a href="<?php echo esc_url($rrhh_url . '?panel_gestor=gestionar-tickets'); ?>"
               class="<?php echo midas_is_active_panel_gestor('gestionar-tickets') ? 'active' : ''; ?>">
                <span class="dashicons dashicons-tickets-alt"></span> Ver Instancias
            </a>
        </li>
        <li class="midas-menu-item">
            <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>">
                <span class="dashicons dashicons-migrate"></span> Cerrar Sesión
            </a>
        </li>
    </ul>
</nav>

<style>
/* Aplica la regla pedida solo dentro del sidebar, con fallback en la variable */
.midas-sidebar ul,
.midas-sidebar ol {
    margin: 0 0 var(--global-md-spacing, 1rem);
    padding-left: 2em;
    position: relative;
    right: 10px; /* mueve 10px a la izquierda */
}
</style>
