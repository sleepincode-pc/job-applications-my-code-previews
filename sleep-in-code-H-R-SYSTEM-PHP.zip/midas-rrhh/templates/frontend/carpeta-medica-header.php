<?php if (!defined('ABSPATH')) exit; ?>
<h2 class="midas-panel-title"><?php esc_html_e('Mi carpeta médica', 'midas-rrhh'); ?></h2>
