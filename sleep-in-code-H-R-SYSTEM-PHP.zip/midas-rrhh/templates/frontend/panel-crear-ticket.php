<?php
if (!defined('ABSPATH')) exit;

$user_id = get_current_user_id();
$msg = '';

/** ========== Procesar creación (solo des-escapar y validar longitudes) ========== */
if (
  ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST'
  && isset($_POST['crear_ticket_nonce'])
  && wp_verify_nonce($_POST['crear_ticket_nonce'], 'midas_crear_ticket')
) {
  if (!$user_id) {
    $msg = '<div class="midas-msg-err">' . esc_html__('Debes iniciar sesión para crear un ticket.', 'midas-rrhh') . '</div>';
  } else {
    // Anti-bot simple: honeypot + timestamp
    $honeypot = trim((string)($_POST['website'] ?? ''));
    $ts = (int)($_POST['ts'] ?? 0);
    $now = time();

    if ($honeypot !== '' || $ts <= 0 || $ts > $now || ($now - $ts) < 2 || ($now - $ts) > 4*3600) {
      $msg = '<div class="midas-msg-err">' . esc_html__('Validación fallida. Vuelve a intentarlo.', 'midas-rrhh') . '</div>';
    } else {
      // ⬇️ Solo des-escapar y validar longitudes. Nada de sanitizar acá.
      $asunto_raw  = isset($_POST['asunto'])  ? (function_exists('wp_unslash') ? wp_unslash($_POST['asunto'])  : $_POST['asunto'])  : '';
      $mensaje_raw = isset($_POST['mensaje']) ? (function_exists('wp_unslash') ? wp_unslash($_POST['mensaje']) : $_POST['mensaje']) : '';

      $lenA = function_exists('mb_strlen') ? mb_strlen(trim($asunto_raw), 'UTF-8')  : strlen(trim($asunto_raw));
      $lenM = function_exists('mb_strlen') ? mb_strlen(trim($mensaje_raw), 'UTF-8') : strlen(trim($mensaje_raw));

      $errors = [];
      if ($lenA < 3) $errors[] = __('El asunto debe tener al menos 3 caracteres.', 'midas-rrhh');
      if ($lenM < 5) $errors[] = __('El mensaje debe tener al menos 5 caracteres.', 'midas-rrhh');

      if ($errors) {
        $msg = '<div class="midas-msg-err">' . esc_html(implode(' ', $errors)) . '</div>';
      } else {
        // Usar el Controller (ahí se sanea definitivamente)
        $controller = new \MidasRRHH\Controllers\Ticket_Controller();
        $res = $controller->crear_ticket($user_id, $asunto_raw, $mensaje_raw);

        if (is_wp_error($res)) {
          $msg = '<div class="midas-msg-err">' . esc_html($res->get_error_message()) . '</div>';
        } else {
          if (function_exists('midas_clear_tickets_cache')) midas_clear_tickets_cache();
          $msg = '<div class="midas-msg-ok">' . esc_html__('Ticket creado correctamente.', 'midas-rrhh') . '</div>';
        }
      }
    }
  }
}
?>

<?php echo $msg; ?>

<style>
#form-crear-ticket input[type="text"], #form-crear-ticket textarea { text-transform: none; } /* sin forzar mayúsculas */
.midas-msg-ok   { padding:10px 14px; background:#e8fff0; border:1px solid #bfe8cf; color:#207245; border-radius:6px; margin-bottom:12px; }
.midas-msg-err  { padding:10px 14px; background:#fff1f1; border:1px solid #f2b4b4; color:#a32020; border-radius:6px; margin-bottom:12px; }
.midas-btn-principal { display:inline-block; padding:10px 16px; background:#2271b1; color:#fff; border:none; border-radius:6px; cursor:pointer; }
.midas-btn-principal:hover { background:#185a8d; }
.midas-disabled { opacity:.6; pointer-events:none; }
</style>

<div class="midas-form-wrapper">
  <form id="form-crear-ticket" method="post" autocomplete="off" novalidate>
    <?php wp_nonce_field('midas_crear_ticket', 'crear_ticket_nonce'); ?>
    <!-- honeypot + timestamp -->
    <input type="hidden" name="ts" value="<?php echo esc_attr(time()); ?>">
    <input type="text" name="website" value="" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px;height:0;width:0;opacity:0;">

    <div class="midas-form-group">
      <label for="asunto"><strong><?php esc_html_e('Asunto', 'midas-rrhh'); ?></strong>
        <input type="text" name="asunto" id="asunto" required maxlength="120">
      </label>
    </div>

    <div class="midas-form-group">
      <label for="mensaje"><strong><?php esc_html_e('Mensaje', 'midas-rrhh'); ?></strong>
        <textarea name="mensaje" id="mensaje" rows="4" required maxlength="2000"></textarea>
      </label>
    </div>

    <button type="submit" class="midas-btn-principal" id="btn-ticket-submit">
      <?php esc_html_e('Abrir instancia', 'midas-rrhh'); ?>
    </button>
  </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  // Validación mínima en cliente (sin sanitizar ni transformar)
  const form    = document.getElementById('form-crear-ticket');
  const asunto  = document.getElementById('asunto');
  const mensaje = document.getElementById('mensaje');
  const btn     = document.getElementById('btn-ticket-submit');

  form?.addEventListener('submit', (e) => {
    const a = (asunto?.value || '').trim();
    const m = (mensaje?.value || '').trim();
    if (a.length < 3 || m.length < 5) {
      e.preventDefault();
      if (a.length < 3 && asunto?.reportValidity) asunto.reportValidity();
      else if (mensaje) {
        mensaje.setCustomValidity('<?php echo esc_js(__('El mensaje debe tener al menos 5 caracteres.', 'midas-rrhh')); ?>');
        mensaje.reportValidity?.();
        setTimeout(() => mensaje.setCustomValidity(''), 400);
      }
      return;
    }
    btn?.classList.add('midas-disabled');
    btn?.setAttribute('aria-busy','true');
  });
});
</script>
