<?php
// Sidebar de EMPLEADO RRHH (solo accesos directos requeridos)
$rrhh_url = site_url('/recursos-humanos/');

// Helper: ¿Panel activo?
if (!function_exists('midas_is_active_panel_empleado')) {
    function midas_is_active_panel_empleado($panel) {
        $current = isset($_GET['panel_empleado']) ? $_GET['panel_empleado'] : 'mi-perfil';
        return $current === $panel;
    }
}

// Helper: ¿Opción permitida para el usuario actual según su rol?
if (!function_exists('midas_rrhh_opcion_permitida')) {
    function midas_rrhh_opcion_permitida($opcion) {
        $user = wp_get_current_user();
        if (!$user || empty($user->ID)) return false;
        $roles = (array) $user->roles;
        if (!$roles) return false;

        $bloqueadas = get_option('midas_rrhh_opciones_bloqueadas', []);
        foreach ($roles as $rol) {
            if (!isset($bloqueadas[$rol])) continue;
            if (in_array($opcion, $bloqueadas[$rol])) return false; // Bloqueada en este rol
        }
        return true;
    }
}
?>

<nav class="midas-sidebar">
    <ul class="midas-menu">
        <li class="midas-menu-item">
            <a href="<?php echo esc_url($rrhh_url . '?panel_empleado=mi-perfil'); ?>"
               class="<?php echo midas_is_active_panel_empleado('mi-perfil') ? 'active' : ''; ?>">
                <span class="dashicons dashicons-admin-users"></span> Mi Perfil
            </a>
        </li>
        <?php if (midas_rrhh_opcion_permitida('licencia')): ?>
        <li class="midas-menu-item">
            <a href="<?php echo esc_url($rrhh_url . '?panel_empleado=solicitar-licencia'); ?>"
               class="<?php echo midas_is_active_panel_empleado('solicitar-licencia') ? 'active' : ''; ?>">
                <span class="dashicons dashicons-calendar"></span> Licencia
            </a>
        </li>
        <?php endif; ?>
        <?php if (midas_rrhh_opcion_permitida('documento')): ?>
        <li class="midas-menu-item">
            <a href="<?php echo esc_url($rrhh_url . '?panel_empleado=mi-carpeta-medica'); ?>"
               class="<?php echo midas_is_active_panel_empleado('mi-carpeta-medica') ? 'active' : ''; ?>">
                <span class="dashicons dashicons-clipboard"></span> Solicitar Carpeta Médica
            </a>
        </li>
        <?php endif; ?>
        <?php if (midas_rrhh_opcion_permitida('ticket')): ?>
        <li class="midas-menu-item">
            <a href="<?php echo esc_url($rrhh_url . '?panel_empleado=ver-tickets'); ?>"
               class="<?php echo midas_is_active_panel_empleado('ver-tickets') ? 'active' : ''; ?>">
                <span class="dashicons dashicons-tickets-alt"></span> Abrir Instancia
            </a>
        </li>
        <?php endif; ?>
        <li class="midas-menu-item">
            <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>">
                <span class="dashicons dashicons-migrate"></span> Cerrar Sesión
            </a>
        </li>
    </ul>
</nav>

<style>
/* Aplica la regla pedida solo dentro del sidebar, con fallback en la variable */
.midas-sidebar ul,
.midas-sidebar ol {
    margin: 0 0 var(--global-md-spacing, 1rem);
    padding-left: 2em;
    position: relative;
    right: 10px; /* mueve 10px a la izquierda (relative + right desplaza hacia la izquierda) */
}
</style>
