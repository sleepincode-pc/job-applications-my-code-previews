<?php
if (!defined('ABSPATH')) exit;

use MidasRRHH\Controllers\Licencia_Controller;
use MidasRRHH\Models\Empleado_Model;

$licencia_controller = new Licencia_Controller();
$empleado_model      = new Empleado_Model();

/* === Usuario WP actual -> empleado === */
$current_user = wp_get_current_user();
$empleado     = $empleado_model->get_by_user_id($current_user->ID);

if (!$empleado || empty($empleado->id)) {
    echo '<div style="color:#e74c3c;font-size:1.2em;margin:40px 0;text-align:center;">'
        . esc_html__('No tienes un perfil de empleado asociado.', 'midas-rrhh')
        . '</div>';
    return;
}

/* === Cargar licencias por estado y filtrar SOLO las mías === */
$solo_mias = function($lics) use ($empleado) {
    $out = [];
    $my  = (int)$empleado->id;
    foreach ((array)$lics as $l) {
        if (is_array($l)) $l = (object)$l;
        if (!is_object($l)) continue;
        if ((int)($l->empleado_id ?? 0) === $my) $out[] = $l;
    }
    return $out;
};

$pendientes_all = $licencia_controller->obtener_licencias_pendientes();
$aprobadas_all  = $licencia_controller->obtener_licencias_aprobadas();
$rechazadas_all = $licencia_controller->obtener_licencias_rechazadas();

$pendientes = $solo_mias($pendientes_all);
$aprobadas  = $solo_mias($aprobadas_all);
$rechazadas = $solo_mias($rechazadas_all);

/* === Mapeo de tipos de licencia a descripción === */
global $wpdb;
$tipos_licencia = $wpdb->get_results("SELECT tipo, descripcion FROM {$wpdb->prefix}midas_licencia_tipos");
$mapa_motivos = [];
foreach ((array)$tipos_licencia as $t) {
    if (is_object($t) && isset($t->tipo)) {
        $mapa_motivos[$t->tipo] = $t->descripcion ?? '';
    }
}

/* ===== Tabla de licencias (sin columna Empleado) ===== */
if (!function_exists('midas_tabla_licencias_personales')) :
function midas_tabla_licencias_personales($licencias, $mapa_motivos) { ?>
  <div class="midas-table-responsive" style="margin:10px 0;">
    <table class="midas-table midas-table-mini">
      <thead>
        <tr>
          <th><?php _e('Tipo', 'midas-rrhh'); ?></th>
          <th><?php _e('Motivo/Descripción', 'midas-rrhh'); ?></th>
          <th><?php _e('Período', 'midas-rrhh'); ?></th>
          <th><?php _e('Días', 'midas-rrhh'); ?></th>
          <th><?php _e('Estado', 'midas-rrhh'); ?></th>
          <th><?php _e('Observaciones', 'midas-rrhh'); ?></th>
          <th><?php _e('Archivo', 'midas-rrhh'); ?></th>
        </tr>
      </thead>
      <tbody>
      <?php if (!empty($licencias)): foreach ($licencias as $lic):
        if (is_array($lic)) $lic = (object)$lic;

        $tipo    = $lic->tipo ?? '-';
        $motivo  = $mapa_motivos[$tipo] ?? '-';
        $periodo = trim(($lic->fecha_inicio_formateada ?? '-') . ' - ' . ($lic->fecha_fin_formateada ?? '-'));
        $dias    = $lic->dias_aprobados ?? $lic->dias_solicitados ?? '-';
        $estado  = strtolower(trim($lic->estado ?? 'pendiente'));

        $archivo_url = '';
        if (!empty($lic->documento_url)) {
            $archivo_url = $lic->documento_url;
        } elseif (!empty($lic->documento_id) && function_exists('wp_get_attachment_url')) {
            $archivo_url = wp_get_attachment_url((int)$lic->documento_id) ?: '';
        }

        if ($estado === 'aprobado')      { $estado_label = __('Aprobado', 'midas-rrhh'); }
        elseif ($estado === 'rechazado') { $estado_label = __('Rechazado','midas-rrhh'); }
        else                             { $estado_label = __('Pendiente','midas-rrhh'); }
      ?>
        <tr>
          <td><?php echo esc_html($tipo); ?></td>
          <td><?php echo esc_html($motivo); ?></td>
          <td><?php echo esc_html($periodo); ?></td>
          <td><?php echo esc_html($dias); ?></td>
          <td>
            <span class="midas-badge-estado midas-badge-<?php echo esc_attr($estado); ?>">
              <?php echo esc_html($estado_label); ?>
            </span>
          </td>
          <td><?php echo !empty($lic->observaciones) ? esc_html($lic->observaciones) : '-'; ?></td>
          <td>
            <?php if (!empty($archivo_url)): ?>
              <a href="<?php echo esc_url($archivo_url); ?>" target="_blank" class="button" rel="noopener">
                <?php _e('Ver', 'midas-rrhh'); ?>
              </a>
            <?php else: ?>
              <em>-</em>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; else: ?>
        <tr>
          <td colspan="7"><em><?php _e('No hay licencias en este estado.', 'midas-rrhh'); ?></em></td>
        </tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
<?php } // fin función
endif;
?>

<style>
/* ====== MODALES (mismo look & feel que el otro módulo) ====== */
.midas-modal-lic{display:none;position:fixed !important;left:0;top:0;width:100vw;height:100vh;z-index:2147483647 !important;align-items:center;justify-content:center;overflow-y:auto;}
.midas-modal-lic[style*="display: flex"]{display:flex !important;}
.midas-modal-bg{position:absolute;inset:0;background:rgba(32,38,60,.37) !important;backdrop-filter:blur(2.8px);z-index:0;}
.midas-modal-content{position:relative;z-index:1;background:#fff !important;border-radius:16px;box-shadow:0 10px 60px #0002;min-width:340px;max-width:92vw;width:1100px;padding:40px 32px 32px;margin:25px 0;color:#232e3c !important;font-family:'Inter','Segoe UI',Arial,sans-serif !important;font-size:1.23em;}
.midas-modal-content h2{margin:0 0 28px 0;font-weight:600;letter-spacing:-1px;font-size:2em;text-align:center;}
.midas-modal-close{position:absolute;top:22px;right:24px;font-size:2em;font-weight:bold;border:none;background:none;color:#4b5161 !important;opacity:.64;cursor:pointer;z-index:10;line-height:1;}
.midas-modal-close:hover{color:#e04141 !important;opacity:1;}

/* ====== TABLAS ====== */
.midas-table-responsive{width:100%;overflow-x:auto;}
.midas-table{border-collapse:collapse;width:100%;background:#fff;table-layout:fixed;}
.midas-table th,.midas-table td{padding:10px 12px;border-bottom:1px solid #e6e9f0;font-size:1em;vertical-align:top;word-break:break-word;overflow-wrap:anywhere;white-space:normal;}
.midas-table th{background:#f4f8fb;color:#26324b;font-weight:600;}
.midas-table-mini td{font-size:.98em;}

/* ====== Botones ====== */
.midas-btn-principal{background:#488DDE !important;color:#fff !important;font-weight:bold;border:none !important;border-radius:8px !important;cursor:pointer;transition:background .2s;}
.midas-btn-principal:hover{background:#488DDE !important;}
.btn-lic-menu{font-size:1.2em !important;padding:16px 40px !important;width:570px !important;display:inline-block;}

/* ====== Badges de estado ====== */
.midas-badge-estado{display:inline-block;padding:.2rem .6rem;border-radius:.4rem;font-weight:600;font-size:.9em;}
.midas-badge-pendiente{background:#fff4e5;color:#a15c00;}
.midas-badge-aprobado{background:#e9f7ef;color:#1e7e34;}
.midas-badge-rechazado{background:#fdecea;color:#b71c1c;}

/* ====== QUITAR SCROLL DEL PANEL DERECHO ======
   En algunos temas, el contenedor del contenido tiene max-height y overflow:auto.
   Lo anulamos para que el scroll sea solo el de la página, no interno. */
.midas-panel-section.midas-panel-datos{
  overflow: visible !important;
  height: auto !important;
  max-height: none !important;
}

/* Responsive */
@media (max-width:700px){
  .midas-modal-content{max-width:99vw;width:98vw;min-width:0;padding:18px 4vw;}
  .midas-table th,.midas-table td{font-size:.93em;padding:6px 6px;}
  .midas-modal-close{right:14px;top:14px;font-size:1.6em;}
  .btn-lic-menu{width:92vw !important;}
}
</style>

<div class="midas-panel-section midas-panel-datos" style="text-align:center; overflow:visible; height:auto; max-height:none;">
  <div style="display:flex;flex-direction:column;align-items:center;gap:24px;margin:36px 0;">
    <button class="midas-btn-principal btn-lic-menu" onclick="abrirModalTablaLic('pendientes')">
      <?php _e('Pendientes', 'midas-rrhh'); ?> (<?php echo count($pendientes); ?>)
    </button>
    <button class="midas-btn-principal btn-lic-menu" onclick="abrirModalTablaLic('aprobadas')">
      <?php _e('Aprobadas', 'midas-rrhh'); ?> (<?php echo count($aprobadas); ?>)
    </button>
    <button class="midas-btn-principal btn-lic-menu" onclick="abrirModalTablaLic('rechazadas')">
      <?php _e('Rechazadas', 'midas-rrhh'); ?> (<?php echo count($rechazadas); ?>)
    </button>
  </div>

  <!-- Modales (solo MIS licencias) -->
  <div id="modal-pendientes" class="midas-modal-lic">
    <div class="midas-modal-bg" onclick="cerrarModalTablaLic('pendientes')"></div>
    <div class="midas-modal-content">
      <button onclick="cerrarModalTablaLic('pendientes')" class="midas-modal-close" aria-label="<?php esc_attr_e('Cerrar', 'midas-rrhh'); ?>">&times;</button>
      <h2><?php _e('Licencias Pendientes', 'midas-rrhh'); ?></h2>
      <?php midas_tabla_licencias_personales($pendientes, $mapa_motivos); ?>
    </div>
  </div>

  <div id="modal-aprobadas" class="midas-modal-lic">
    <div class="midas-modal-bg" onclick="cerrarModalTablaLic('aprobadas')"></div>
    <div class="midas-modal-content">
      <button onclick="cerrarModalTablaLic('aprobadas')" class="midas-modal-close" aria-label="<?php esc_attr_e('Cerrar', 'midas-rrhh'); ?>">&times;</button>
      <h2><?php _e('Licencias Aprobadas', 'midas-rrhh'); ?></h2>
      <?php midas_tabla_licencias_personales($aprobadas, $mapa_motivos); ?>
    </div>
  </div>

  <div id="modal-rechazadas" class="midas-modal-lic">
    <div class="midas-modal-bg" onclick="cerrarModalTablaLic('rechazadas')"></div>
    <div class="midas-modal-content">
      <button onclick="cerrarModalTablaLic('rechazadas')" class="midas-modal-close" aria-label="<?php esc_attr_e('Cerrar', 'midas-rrhh'); ?>">&times;</button>
      <h2><?php _e('Licencias Rechazadas', 'midas-rrhh'); ?></h2>
      <?php midas_tabla_licencias_personales($rechazadas, $mapa_motivos); ?>
    </div>
  </div>
</div>

<script>
function abrirModalTablaLic(tipo){
  // Compensar scrollbar para evitar salto del layout
  const sbw = window.innerWidth - document.documentElement.clientWidth;
  document.body.style.overflow = 'hidden';
  if (sbw > 0) document.body.style.paddingRight = sbw + 'px';
  const el = document.getElementById('modal-' + tipo);
  if (el) el.style.display = 'flex';
}
function cerrarModalTablaLic(tipo){
  document.body.style.overflow = '';
  document.body.style.paddingRight = '';
  const el = document.getElementById('modal-' + tipo);
  if (el) el.style.display = 'none';
}
document.addEventListener('keydown', function(e){
  if (e.key === 'Escape') ['pendientes','aprobadas','rechazadas'].forEach(cerrarModalTablaLic);
});
</script>
