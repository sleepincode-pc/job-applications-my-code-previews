<?php
if (!defined('ABSPATH')) exit;

use MidasRRHH\Controllers\Ticket_Controller;
use MidasRRHH\Models\Empleado_Model;

/* === Usuario actual === */
$user_id = get_current_user_id();
if (!$user_id) {
  echo '<div style="color:#e74c3c;font-size:1.1em;margin:24px 0;text-align:center;">'
     . esc_html__('Debes iniciar sesión para ver tus instancias.', 'midas-rrhh')
     . '</div>';
  return;
}

/* === Empleado asociado (para comparar empleado_id si el ticket lo usa) === */
$empleado_model = new Empleado_Model();
$empleado       = method_exists($empleado_model, 'get_by_user_id') ? $empleado_model->get_by_user_id($user_id) : null;
$empleado_id    = (int)($empleado->id ?? 0);

/* === SIEMPRE: solo mis instancias === */
$ticket_controller = new Ticket_Controller();
$instancias = [];

/* Preferimos la API del controller; si no existe, hacemos fallback y filtramos */
if (method_exists($ticket_controller, 'obtener_tickets_usuario')) {
  $instancias = (array) $ticket_controller->obtener_tickets_usuario($user_id);
} elseif (method_exists($ticket_controller, 'obtener_todos')) {
  $all = (array) $ticket_controller->obtener_todos();
  $instancias = $all; // las filtramos más abajo
}

/* ===== Filtro defensivo: asegurar que solo queden las del usuario actual ===== */
$belongs_to_me = function($t) use ($user_id, $empleado_id) {
  if (is_array($t)) $t = (object)$t;
  if (!is_object($t)) return false;

  $candidatos_usuario = [
    (int)($t->user_id ?? 0),
    (int)($t->usuario_id ?? 0),
    (int)($t->author_id ?? 0),
    (int)($t->creator_id ?? 0),
    (int)($t->creado_por ?? 0),
    (int)($t->solicitante_user_id ?? 0),
  ];
  if (in_array($user_id, $candidatos_usuario, true)) return true;

  // Algunos modelos guardan el vínculo por empleado
  if ($empleado_id > 0 && (int)($t->empleado_id ?? 0) === $empleado_id) return true;

  return false;
};
$instancias = array_values(array_filter((array)$instancias, $belongs_to_me));

$modal_title = __('Mis instancias', 'midas-rrhh');

/* ========= Utilidades SQL para última acción (respuesta/motivo/admin) ========= */
if (!function_exists('midas_rrhh_table_exists')) {
  function midas_rrhh_table_exists($table){
    global $wpdb;
    return $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table)) === $table;
  }
}
if (!function_exists('midas_rrhh_ultima_accion_ticket')) {
  function midas_rrhh_ultima_accion_ticket($ticket_id){
    global $wpdb;
    $out = ['respuesta'=>'', 'motivo'=>'', 'admin_nombre'=>''];

    $tr = $wpdb->prefix.'midas_tickets_respuestas';
    if (midas_rrhh_table_exists($tr)) {
      $row = $wpdb->get_row(
        $wpdb->prepare(
          "SELECT COALESCE(r.respuesta, r.valor, r.respuesta_texto, r.texto, '') AS respuesta,
                  u.display_name AS admin_nombre
           FROM $tr r
           LEFT JOIN $wpdb->users u ON u.ID = r.admin_id
           WHERE r.ticket_id = %d
           ORDER BY r.id DESC
           LIMIT 1",
          (int)$ticket_id
        )
      );
      if ($row){
        $out['respuesta']    = trim((string)$row->respuesta);
        $out['admin_nombre'] = trim((string)($row->admin_nombre ?? ''));
      }
    }

    $tj = $wpdb->prefix.'midas_tickets_rechazos';
    if (midas_rrhh_table_exists($tj)) {
      $row = $wpdb->get_row(
        $wpdb->prepare(
          "SELECT COALESCE(j.motivo_rechazo, j.motivo, j.valor, j.razon, j.texto, '') AS motivo,
                  u.display_name AS admin_nombre
           FROM $tj j
           LEFT JOIN $wpdb->users u ON u.ID = j.admin_id
           WHERE j.ticket_id = %d
           ORDER BY j.id DESC
           LIMIT 1",
          (int)$ticket_id
        )
      );
      if ($row){
        $out['motivo'] = trim((string)$row->motivo);
        if ($out['admin_nombre'] === '') $out['admin_nombre'] = trim((string)($row->admin_nombre ?? ''));
      }
    }
    return $out;
  }
}
?>

<!-- BOTÓN CENTRADO (solo mis instancias) -->
<div class="midas-btn-center-wrap">
  <button id="btn-ver-todas" class="midas-btn-principal btn-lic-menu">
    <?php echo esc_html($modal_title); ?> (<?php echo count($instancias); ?>)
  </button>
</div>

<!-- MODAL -->
<div id="modal-todas" class="midas-modal-lic" style="display:none;">
  <div class="midas-modal-bg"></div>
  <div class="midas-modal-content">
    <button type="button" class="midas-modal-close" aria-label="<?php esc_attr_e('Cerrar', 'midas-rrhh'); ?>">&times;</button>
    <h2><?php echo esc_html($modal_title); ?></h2>

    <div class="midas-table-responsive" style="margin:10px 0;">
      <table class="midas-table midas-table-mini" id="tabla-tickets-modal">
        <thead>
          <tr>
            <th><?php _e('Asunto', 'midas-rrhh'); ?></th>
            <th><?php _e('Mensaje', 'midas-rrhh'); ?></th>
            <th><?php _e('Estado', 'midas-rrhh'); ?></th>
            <th><?php _e('Respuesta/Instanciador', 'midas-rrhh'); ?></th>
          </tr>
        </thead>
        <tbody>
        <?php if (!empty($instancias)): foreach ($instancias as $i):
          $estado = strtolower(trim($i->estado ?? ''));

          // 1) Intento directo desde el SELECT enriquecido del controller
          $resp   = '';
          foreach (['respuesta','resp_ultima','valor','respuesta_texto','texto'] as $k) {
            if (isset($i->$k) && trim((string)$i->$k) !== '') { $resp = trim((string)$i->$k); break; }
          }
          $motivo = '';
          foreach (['motivo_rechazo','motivo_ultimo','motivo','valor','razon','texto'] as $k) {
            if (isset($i->$k) && trim((string)$i->$k) !== '') { $motivo = trim((string)$i->$k); break; }
          }

          // Admin que actuó
          $adminN = trim((string)($i->admin_nombre ?? ''));
          if ($adminN === '' && !empty($i->admin_id)) {
            $u = get_user_by('ID', (int)$i->admin_id);
            if ($u) $adminN = $u->display_name;
          }

          // 2) Fallback histórico
          if ( ($estado === 'respondido' && $resp === '') ||
               ($estado === 'rechazado' && $motivo === '') ||
               $adminN === '' ) {
            $last = midas_rrhh_ultima_accion_ticket($i->id);
            if ($resp   === '') $resp   = $last['respuesta'];
            if ($motivo === '') $motivo = $last['motivo'];
            if ($adminN === '' && $last['admin_nombre'] !== '') $adminN = $last['admin_nombre'];
          }
        ?>
          <tr data-id="<?php echo esc_attr($i->id); ?>">
            <td><?php echo esc_html($i->asunto); ?></td>
            <td><?php echo esc_html($i->mensaje); ?></td>
            <td>
              <?php
                if     ($estado === 'pendiente')  echo '<span class="midas-badge-pendiente">' . esc_html__('Pendiente', 'midas-rrhh') . '</span>';
                elseif ($estado === 'respondido') echo '<span class="midas-badge-aprobado">'  . esc_html__('Aceptada',  'midas-rrhh') . '</span>';
                elseif ($estado === 'rechazado')  echo '<span class="midas-badge-rechazado">'. esc_html__('Rechazada','midas-rrhh') . '</span>';
                elseif ($estado === 'enviado')    echo '<span class="midas-badge-enviado">'  . esc_html__('Enviado',   'midas-rrhh') . '</span>';
                else                               echo '<span>-</span>';
              ?>
            </td>
            <td>
              <?php if ($estado == 'respondido'): ?>
                <div style="font-size:13px;"><strong><?php esc_html_e('Respuesta:', 'midas-rrhh'); ?></strong> <?php echo $resp !== '' ? esc_html($resp) : '<em>-</em>'; ?></div>
                <em><?php echo $adminN !== '' ? sprintf(esc_html__('Por %s', 'midas-rrhh'), esc_html($adminN)) : '<span>-</span>'; ?></em>
              <?php elseif ($estado == 'rechazado'): ?>
                <div style="font-size:13px;"><strong><?php esc_html_e('Motivo:', 'midas-rrhh'); ?></strong> <?php echo $motivo !== '' ? esc_html($motivo) : '<em>-</em>'; ?></div>
                <em><?php echo $adminN !== '' ? sprintf(esc_html__('Por %s', 'midas-rrhh'), esc_html($adminN)) : '<span>-</span>'; ?></em>
              <?php else: ?>
                <em>-</em>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; else: ?>
          <tr><td colspan="4"><em><?php esc_html_e('No hay instancias.', 'midas-rrhh'); ?></em></td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<style>
:root { --midas-offset: 240px; }
.midas-btn-center-wrap{ display:flex; align-items:center; justify-content:center; min-height: calc(100dvh - var(--midas-offset)); padding: 36px 0 48px; box-sizing:border-box; }
@supports not (height: 1dvh){ .midas-btn-center-wrap{ min-height: calc(100vh - var(--midas-offset)); } }
.midas-btn-principal{ background:#488DDE !important; color:#fff !important; font-weight:bold; border:none !important; border-radius:8px !important; cursor:pointer; transition:background .2s; }
.midas-btn-principal:hover{ background:#488DDE !important; }
.btn-lic-menu{ font-size:1.2em !important; padding:16px 40px !important; width:570px !important; display:inline-block; }

.midas-modal-lic{ display:none; position:fixed !important; left:0; top:0; width:100vw; height:100vh; z-index:2147483647 !important; align-items:center; justify-content:center; overflow-y:auto; }
.midas-modal-lic[style*="display: flex"]{ display:flex !important; }
.midas-modal-bg{ position:absolute; inset:0; background:rgba(32,38,60,.37) !important; backdrop-filter:blur(2.8px); z-index:0; }
.midas-modal-content{ position:relative; z-index:1; background:#fff !important; border-radius:16px; box-shadow:0 10px 60px #0002; min-width:340px; max-width:92vw; width:1100px; padding:40px 32px 32px; margin:25px 0; color:#232e3c !important; font-family:'Inter','Segoe UI',Arial,sans-serif !important; font-size:1.23em; }
.midas-modal-content h2{ margin:0 0 28px 0; font-weight:600; letter-spacing:-1px; font-size:2em; text-align:center; }
.midas-modal-close{ position:absolute; top:22px; right:24px; font-size:2em; font-weight:bold; border:none; background:none; color:#4b5161 !important; opacity:.64; cursor:pointer; z-index:10; line-height:1; }
.midas-modal-close:hover{ color:#e04141 !important; opacity:1; }

.midas-table-responsive{ width:100%; overflow-x:auto; }
.midas-table{ border-collapse:collapse; width:100%; background:#fff; table-layout:fixed; }
.midas-table th,.midas-table td{ padding:10px 12px; border-bottom:1px solid #e6e9f0; font-size:1em; vertical-align:top; word-break:break-word; overflow-wrap:anywhere; white-space:normal; }
.midas-table th{ background:#f4f8fb; color:#26324b; font-weight:600; }
.midas-table-mini td{ font-size:.98em; }

.midas-badge-pendiente{display:inline-block;padding:.15rem .5rem;border-radius:.35rem;background:#fff4e5;color:#a15c00;font-weight:600;font-size:.9em}
.midas-badge-aprobado{display:inline-block;padding:.15rem .5rem;border-radius:.35rem;background:#e9f7ef;color:#1e7e34;font-weight:600;font-size:.9em}
.midas-badge-rechazado{display:inline-block;padding:.15rem .5rem;border-radius:.35rem;background:#fdecea;color:#b71c1c;font-weight:600;font-size:.9em}
.midas-badge-enviado{display:inline-block;padding:.15rem .5rem;border-radius:.35rem;background:#e6f2ff;color:#0a58ca;font-weight:600;font-size:.9em}

@media (max-width:700px){
  .midas-modal-content{ max-width:99vw; width:98vw; min-width:0; padding:18px 4vw; }
  .midas-table th,.midas-table td{ font-size:.93em; padding:6px 6px; }
  .midas-modal-close{ right:14px; top:14px; font-size:1.6em; }
  .btn-lic-menu{ width:92vw !important; }
}
</style>

<script>
(function(){
  const openBtn  = document.getElementById('btn-ver-todas');
  const modal    = document.getElementById('modal-todas');
  const closeBtn = modal.querySelector('.midas-modal-close');
  const bg       = modal.querySelector('.midas-modal-bg');

  function abrir(){
    const sbw = window.innerWidth - document.documentElement.clientWidth;
    document.body.style.overflow = 'hidden';
    if (sbw > 0) document.body.style.paddingRight = sbw + 'px';
    modal.style.display = 'flex';
  }
  function cerrar(){
    modal.style.display = 'none';
    document.body.style.overflow = '';
    document.body.style.paddingRight = '';
  }

  openBtn?.addEventListener('click', abrir);
  closeBtn.addEventListener('click', cerrar);
  bg.addEventListener('click', cerrar);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') cerrar(); });
})();
</script>
