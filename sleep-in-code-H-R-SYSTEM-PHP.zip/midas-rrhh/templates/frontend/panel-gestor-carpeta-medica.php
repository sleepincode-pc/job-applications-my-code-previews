<?php
if (!defined('ABSPATH')) exit;

use MidasRRHH\Controllers\Carpeta_Medica_Controller;
use MidasRRHH\Models\Empleado_Model;

$carpeta_controller = new Carpeta_Medica_Controller();
$empleado_model     = new Empleado_Model();

/* === Usuario WP actual -> empleado === */
$current_user = wp_get_current_user();
$empleado     = $empleado_model->get_by_user_id($current_user->ID);

if (!$empleado || empty($empleado->id)) {
    echo '<div style="color:#e74c3c;font-size:1.2em;margin:40px 0;text-align:center;">'
        . esc_html__('No tienes un perfil de empleado asociado.', 'midas-rrhh')
        . '</div>';
    return;
}

/* ===========================
 * Helpers de datos/estado
 * =========================== */
$solo_mios = function($docs) use ($empleado) {
    $out = []; $my = (int)$empleado->id;
    foreach ((array)$docs as $d) {
        if (is_array($d)) $d = (object)$d;
        if (!is_object($d)) continue;
        if ((int)($d->empleado_id ?? 0) === $my) $out[] = $d;
    }
    return $out;
};

function midas_normalizar_estado($doc) : int {
    // 1: pendiente | 2: aprobado | 3: rechazado
    if (isset($doc->estado_id)) {
        $v = (int)$doc->estado_id;
        if (in_array($v, [1,2,3], true)) return $v;
    }
    $candidatos = [
        strtolower((string)($doc->estado ?? '')),
        strtolower((string)($doc->status ?? '')),
        strtolower((string)($doc->estado_nombre ?? '')),
    ];
    foreach ($candidatos as $s) {
        if ($s === '') continue;
        if (in_array($s, ['pendiente','pending'], true)) return 1;
        if (in_array($s, ['aprobado','approved'], true)) return 2;
        if (in_array($s, ['rechazado','rejected'], true)) return 3;
    }
    return 1; // por defecto: pendiente
}

function midas_doc_key($doc) : string {
    if (isset($doc->id))           return 'i:'.(int)$doc->id;
    if (isset($doc->documento_id)) return 'd:'.(int)$doc->documento_id;
    if (isset($doc->archivo_id))   return 'a:'.(int)$doc->archivo_id;
    // Fallback robusto
    $parts = [
        (int)($doc->empleado_id ?? 0),
        (int)($doc->motivo_id ?? 0),
        (int)($doc->medico_id ?? 0),
        (string)($doc->fecha_emision ?? ''),
        (string)($doc->observaciones ?? ''),
        (int)($doc->dias ?? ($doc->dias_solicitados ?? 0)),
    ];
    return 'h:'.md5(implode('|', array_map('strval', $parts)));
}

/* ===========================
 * Recolección y partición
 * =========================== */
// Si el controlador expone "todos", úsalo; si no, unimos por estado y luego desduplicamos.
$raw = [];
if (method_exists($carpeta_controller, 'obtener_documentos_empleado_todos')) {
    $raw = $solo_mios($carpeta_controller->obtener_documentos_empleado_todos($empleado->id));
} else {
    $p = $solo_mios($carpeta_controller->obtener_documentos_empleado($empleado->id, 1)); // pendientes
    $a = $solo_mios($carpeta_controller->obtener_documentos_empleado($empleado->id, 2)); // aprobados
    $r = $solo_mios($carpeta_controller->obtener_documentos_empleado($empleado->id, 3)); // rechazados
    $raw = array_merge((array)$p, (array)$a, (array)$r);
}

/* Desduplicar y quedarnos con el estado de mayor prioridad (aprob/rechazan sacan de pendientes) */
$prioridad = [1 => 1, 2 => 3, 3 => 3]; // 3>1 y 2>1
$byKey = []; $estadoKey = [];
foreach ((array)$raw as $d) {
    if (is_array($d)) $d = (object)$d;
    if (!is_object($d)) continue;
    $k = midas_doc_key($d);
    $e = midas_normalizar_estado($d);
    if (!isset($byKey[$k]) || $prioridad[$e] >= ($prioridad[$estadoKey[$k]] ?? 0)) {
        $byKey[$k]    = $d;
        $estadoKey[$k]= $e;
    }
}

/* Particionar en colecciones exclusivas */
$pendientes = $aprobados = $rechazados = [];
foreach ($byKey as $k => $doc) {
    $e = $estadoKey[$k];
    if ($e === 2)      $aprobados[]  = $doc;
    elseif ($e === 3)  $rechazados[] = $doc;
    else               $pendientes[] = $doc;
}

/* =====+ Helpers visuales ===== */
function midas_first_nonempty($obj, array $keys){
    foreach ($keys as $k) {
        if (isset($obj->$k)) {
            $v = (string)$obj->$k;
            if (trim($v) !== '') return $v;
        }
    }
    return '';
}
function midas_resolver_medico($doc){
    $nombre   = midas_first_nonempty($doc, ['medico_nombre','nombre_medico','medico']);
    $apellido = midas_first_nonempty($doc, ['medico_apellido','apellido_medico']);
    if ($nombre !== '' || $apellido !== '') return trim("$nombre $apellido");
    if (!empty($doc->medico_id)) {
        static $cacheMed = [];
        $id = (int)$doc->medico_id;
        if (!isset($cacheMed[$id])) {
            global $wpdb; $t = $wpdb->prefix . 'midas_medicos';
            $cacheMed[$id] = $wpdb->get_row($wpdb->prepare("SELECT nombre, apellido FROM $t WHERE id=%d", $id));
        }
        if (!empty($cacheMed[$id])) return trim(($cacheMed[$id]->nombre ?? '').' '.($cacheMed[$id]->apellido ?? ''));
    }
    return '';
}
function midas_resolver_motivo($doc){
    $m = midas_first_nonempty($doc, ['motivo_descripcion','descripcion_motivo','motivo']);
    if ($m !== '') return $m;
    if (!empty($doc->motivo_id)) {
        static $cacheMot = [];
        $id = (int)$doc->motivo_id;
        if (!isset($cacheMot[$id])) {
            global $wpdb; $t = $wpdb->prefix . 'midas_motivos_carpeta_medica';
            $cacheMot[$id] = $wpdb->get_var($wpdb->prepare("SELECT descripcion FROM $t WHERE id=%d", $id));
        }
        if (!empty($cacheMot[$id])) return $cacheMot[$id];
    }
    return '';
}
function midas_resolver_archivo_url($doc){
    $url = midas_first_nonempty($doc, ['documento_url','archivo_url','url']);
    if ($url !== '') return $url;
    if (!empty($doc->documento_id) && function_exists('wp_get_attachment_url')) {
        $u = wp_get_attachment_url((int)$doc->documento_id);
        if ($u) return $u;
    }
    return '';
}
?>

<style>
/* ===== Panel sin scroll forzado ===== */
.midas-panel-section.midas-panel-datos{overflow:visible !important;height:auto !important;max-height:none !important}

/* ===== MODALES ===== */
.midas-modal-lic{display:none;position:fixed !important;left:0;top:0;width:100vw;height:100vh;z-index:2147483647 !important;align-items:center;justify-content:center;overflow-y:auto}
.midas-modal-lic[style*="display: flex"]{display:flex !important}
.midas-modal-bg{position:absolute;inset:0;background:rgba(32,38,60,.37) !important;backdrop-filter:blur(2.8px);z-index:0}
.midas-modal-content{position:relative;z-index:1;background:#fff !important;border-radius:16px;box-shadow:0 10px 60px #0002;min-width:340px;max-width:92vw;width:1100px;padding:40px 32px 32px;margin:25px 0;color:#232e3c !important;font-family:'Inter','Segoe UI',Arial,sans-serif !important;font-size:1.23em}
.midas-modal-content h2{margin:0 0 28px 0;font-weight:600;letter-spacing:-1px;font-size:2em;text-align:center}
.midas-modal-close{position:absolute;top:22px;right:24px;font-size:2em;font-weight:bold;border:none;background:none;color:#4b5161 !important;opacity:.64;cursor:pointer;z-index:10;line-height:1}
.midas-modal-close:hover{color:#e04141 !important;opacity:1}

/* ===== TABLAS ===== */
.midas-table-responsive{width:100%;overflow-x:auto}
.midas-table{border-collapse:collapse;width:100%;background:#fff;table-layout:fixed}
.midas-table th,.midas-table td{padding:10px 12px;border-bottom:1px solid #e6e9f0;font-size:1em;vertical-align:top;word-break:break-word;overflow-wrap:anywhere;white-space:normal}
.midas-table th{background:#f4f8fb;color:#26324b;font-weight:600}
.midas-table-mini td{font-size:.98em}

/* ===== Botones ===== */
.midas-btn-principal{background:#488DDE !important;color:#fff !important;font-weight:bold;border:none !important;border-radius:8px !important;cursor:pointer;transition:background .2s}
.midas-btn-principal:hover{background:#488DDE !important}
.btn-lic-menu{font-size:1.2em !important;padding:16px 40px !important;width:570px !important;display:inline-block}

/* Botón "Ver archivo" */
.midas-table a.button{background:#488DDE !important;color:#fff !important;border:none !important;border-radius:8px !important;padding:8px 14px !important;font-weight:600}

@media (max-width:700px){
  .midas-modal-content{max-width:99vw;width:98vw;min-width:0;padding:18px 4vw}
  .midas-table th,.midas-table td{font-size:.93em;padding:6px 6px}
  .midas-modal-close{right:14px;top:14px;font-size:1.6em}
  .btn-lic-menu{width:92vw !important}
}
</style>

<div class="midas-panel-section midas-panel-datos" style="text-align:center">
  <div style="display:flex;flex-direction:column;align-items:center;gap:24px;margin:36px 0">
    <button class="midas-btn-principal btn-lic-menu" onclick="abrirModalTablaDocs('pendientes')">
      <?php _e('Pendientes', 'midas-rrhh'); ?> (<?php echo count($pendientes); ?>)
    </button>
    <button class="midas-btn-principal btn-lic-menu" onclick="abrirModalTablaDocs('aprobados')">
      <?php _e('Aprobados', 'midas-rrhh'); ?> (<?php echo count($aprobados); ?>)
    </button>
    <button class="midas-btn-principal btn-lic-menu" onclick="abrirModalTablaDocs('rechazados')">
      <?php _e('Rechazados', 'midas-rrhh'); ?> (<?php echo count($rechazados); ?>)
    </button>
  </div>

  <!-- MODALS (solo mis docs, sin duplicados entre estados) -->
  <div id="modal-pendientes" class="midas-modal-lic">
    <div class="midas-modal-bg" onclick="cerrarModalTablaDocs('pendientes')"></div>
    <div class="midas-modal-content">
      <button onclick="cerrarModalTablaDocs('pendientes')" class="midas-modal-close" aria-label="Cerrar">&times;</button>
      <h2><?php _e('Documentos Pendientes', 'midas-rrhh'); ?></h2>
      <?php midas_tabla_documentos_medicos($pendientes); ?>
    </div>
  </div>
  <div id="modal-aprobados" class="midas-modal-lic">
    <div class="midas-modal-bg" onclick="cerrarModalTablaDocs('aprobados')"></div>
    <div class="midas-modal-content">
      <button onclick="cerrarModalTablaDocs('aprobados')" class="midas-modal-close" aria-label="Cerrar">&times;</button>
      <h2><?php _e('Documentos Aprobados', 'midas-rrhh'); ?></h2>
      <?php midas_tabla_documentos_medicos($aprobados); ?>
    </div>
  </div>
  <div id="modal-rechazados" class="midas-modal-lic">
    <div class="midas-modal-bg" onclick="cerrarModalTablaDocs('rechazados')"></div>
    <div class="midas-modal-content">
      <button onclick="cerrarModalTablaDocs('rechazados')" class="midas-modal-close" aria-label="Cerrar">&times;</button>
      <h2><?php _e('Documentos Rechazados', 'midas-rrhh'); ?></h2>
      <?php midas_tabla_documentos_medicos($rechazados); ?>
    </div>
  </div>
</div>

<?php
/* ===== Tabla SIN columna “Empleado” (siempre es el propio usuario) ===== */
function midas_tabla_documentos_medicos($documentos) { ?>
  <div class="midas-table-responsive" style="margin:10px 0">
    <table class="midas-table midas-table-mini">
      <thead>
        <tr>
          <th><?php _e('Médico', 'midas-rrhh'); ?></th>
          <th><?php _e('Motivo', 'midas-rrhh'); ?></th>
          <th><?php _e('Fecha Emisión', 'midas-rrhh'); ?></th>
          <th><?php _e('Días', 'midas-rrhh'); ?></th>
          <th><?php _e('Observaciones', 'midas-rrhh'); ?></th>
          <th><?php _e('Archivo', 'midas-rrhh'); ?></th>
        </tr>
      </thead>
      <tbody>
      <?php if (!empty($documentos)): foreach ($documentos as $doc):
        $medico = midas_resolver_medico($doc);
        $motivo = midas_resolver_motivo($doc);
        $fecha  = midas_first_nonempty($doc, ['fecha_emision_formateada','fecha_emision']);
        $dias   = isset($doc->dias_solicitados) ? $doc->dias_solicitados : (isset($doc->dias) ? $doc->dias : '');
        $obs    = midas_first_nonempty($doc, ['observaciones']);
        $file   = midas_resolver_archivo_url($doc);
      ?>
        <tr>
          <td><?php echo esc_html($medico); ?></td>
          <td><?php echo esc_html($motivo); ?></td>
          <td><?php echo esc_html($fecha); ?></td>
          <td><?php echo esc_html($dias); ?></td>
          <td><?php echo esc_html($obs); ?></td>
          <td>
            <?php if ($file !== ''): ?>
              <a href="<?php echo esc_url($file); ?>" target="_blank" class="button">
                <?php _e('Ver archivo', 'midas-rrhh'); ?>
              </a>
            <?php else: ?><em>-</em><?php endif; ?>
          </td>
        </tr>
      <?php endforeach; else: ?>
        <tr><td colspan="6"><em><?php _e('No hay documentos.', 'midas-rrhh'); ?></em></td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
<?php } ?>

<script>
function abrirModalTablaDocs(tipo){
  const sbw = window.innerWidth - document.documentElement.clientWidth;
  document.body.style.overflow = 'hidden';
  if (sbw > 0) document.body.style.paddingRight = sbw + 'px';
  document.getElementById('modal-' + tipo).style.display = 'flex';
}
function cerrarModalTablaDocs(tipo){
  document.body.style.overflow = '';
  document.body.style.paddingRight = '';
  document.getElementById('modal-' + tipo).style.display = 'none';
}
document.addEventListener('keydown', e=>{
  if (e.key === 'Escape') ['pendientes','aprobados','rechazados'].forEach(cerrarModalTablaDocs);
});
</script>
