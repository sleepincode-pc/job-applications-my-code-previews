<?php if (!defined('ABSPATH')) exit; ?>
<h2 class="midas-panel-title"><?php esc_html_e('Gestión de Licencias', 'midas-rrhh'); ?></h2>
