<?php if (!defined('ABSPATH')) exit; ?>
<div class="midas-panel-header">
    <div class="midas-user-info">
        <?php if (!empty($empleado->foto_url)): ?>
            <img src="<?php echo esc_url($empleado->foto_url); ?>" alt="<?php echo esc_attr($empleado->nombre . ' ' . $empleado->apellido); ?>" class="midas-user-avatar">
        <?php endif; ?>
        <div>
            <h2 class="midas-panel-title" style="margin:0 0 2px 0;">
                <?php echo esc_html($empleado->nombre . ' ' . $empleado->apellido); ?>
            </h2>
            <p class="midas-user-meta">
                <span><?php echo esc_html($empleado->area_nombre); ?></span>
                <?php if (!empty($empleado->tarea_nombre)) : ?>
                    • <span><?php echo esc_html($empleado->tarea_nombre); ?></span>
                <?php endif; ?>
            </p>
        </div>
    </div>
    <a href="<?php echo wp_logout_url(home_url()); ?>" class="midas-logout-btn"><?php esc_html_e('Cerrar Sesión', 'midas-rrhh'); ?></a>
</div>
