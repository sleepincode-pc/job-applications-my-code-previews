<?php
if (!defined('ABSPATH')) exit;

// SIN "use": instanciamos con el FQCN para evitar colisiones
$empleado_model = new \MidasRRHH\Models\Empleado_Model();
$controller     = new \MidasRRHH\Controllers\Licencia_Controller();

$empleado = $empleado_model->get_by_user_id(get_current_user_id());

global $wpdb;
$tipos_licencia = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}midas_licencia_tipos ORDER BY tipo ASC");
?>
<?php if (!isset($GLOBALS['ajaxurl'])): ?>
<script>
var ajaxurl = "<?= esc_url( admin_url('admin-ajax.php') ) ?>";
</script>
<?php endif; ?>

<style>
.midas-msg-ok   { padding:10px 14px; background:#e8fff0; border:1px solid #bfe8cf; color:#207245; border-radius:6px; margin-bottom:12px; }
.midas-msg-err  { padding:10px 14px; background:#fff1f1; border:1px solid #f2b4b4; color:#a32020; border-radius:6px; margin-bottom:12px; }
.midas-btn-principal { display:inline-block; padding:10px 16px; background:#2271b1; color:#fff; border:none; border-radius:6px; cursor:pointer; }
.midas-btn-principal:hover { background:#185a8d; }

/* Visual: MAYÚSCULAS solo en Observaciones */
#form-solicitar-licencia input[name="observaciones"] { text-transform: uppercase; }
</style>

<div class="midas-panel-section midas-panel-datos">
  <div class="midas-form-wrapper">
    <div id="licencia-result"></div>
    <?php if (!$empleado): ?>
      <div style="padding:20px; max-width:400px; margin: 30px auto; border: 1px solid #cc3232; background: #fff0f0; color: #cc3232; font-weight: 700; text-align: center; border-radius: 8px; font-size: 1.15em;">
        <?php esc_html_e('NO ERES UN EMPLEADO DE RECURSOS HUMANOS PARA HACER ESTO', 'midas-rrhh'); ?>
      </div>
    <?php else: ?>
      <form id="form-solicitar-licencia" method="post" enctype="multipart/form-data" autocomplete="off" novalidate>
        <!-- IMPORTANTE: este nonce debe coincidir con guard_licencias() -->
        <?php wp_nonce_field('midas_empleados_nonce', 'midas_empleados_nonce'); ?>
        <input type="hidden" name="empleado_id" value="<?= esc_attr($empleado->id) ?>">
        <!-- Honeypot anti-bots -->
        <input type="text" name="website" value="" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px;height:0;width:0;opacity:0;">

        <div class="midas-form-group">
          <label>
            <span><strong><?php esc_html_e('Tipo de licencia', 'midas-rrhh'); ?>:</strong></span>
            <select name="tipo" id="tipo-licencia-select" required>
              <option value=""><?php esc_html_e('Seleccionar tipo', 'midas-rrhh'); ?></option>
              <?php foreach ($tipos_licencia as $tipo): ?>
                <option value="<?= esc_attr($tipo->tipo) ?>" data-desc="<?= esc_attr($tipo->descripcion) ?>">
                  <?= esc_html($tipo->tipo) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </label>
          <div id="desc-licencia" style="margin-top: 8px; color: #226; min-height: 16px;"></div>
        </div>

        <div class="midas-form-group">
          <label>
            <span><strong><?php esc_html_e('Fecha de inicio', 'midas-rrhh'); ?>:</strong></span>
            <input type="date" name="fecha_inicio" id="fecha_inicio" required>
          </label>
        </div>

        <div class="midas-form-group">
          <label>
            <span><strong><?php esc_html_e('Fecha de fin', 'midas-rrhh'); ?>:</strong></span>
            <input type="date" name="fecha_fin" id="fecha_fin" required>
          </label>
        </div>

        <div class="midas-form-group">
          <label>
            <span><strong><?php esc_html_e('Observaciones', 'midas-rrhh'); ?>:</strong></span>
            <input
              type="text"
              name="observaciones"
              maxlength="300"
              pattern="^[A-ZÁÉÍÓÚÑ0-9 .,;:¡!¿?\(\)\-_/#+%]*$"
              title="SOLO LETRAS MAYÚSCULAS (INCLUYE TILDES), NÚMEROS Y . , ; : ¡ ! ¿ ? ( ) - _ / # + % (MÁX. 300).">
          </label>
        </div>

        <div class="midas-form-group">
          <label>
            <span><strong><?php esc_html_e('Archivo adjunto', 'midas-rrhh'); ?>:</strong></span>
            <input type="file" name="documento" id="lic-file" accept="application/pdf,image/*" data-max-bytes="5242880">
            <small style="display:block;margin-top:6px;color:#555">PDF, JPG, PNG o WEBP. Tamaño máx. 5 MB.</small>
          </label>
        </div>

        <button type="submit" class="midas-btn-principal">
          <?php esc_html_e('Solicitar Licencia', 'midas-rrhh'); ?>
        </button>
      </form>
    <?php endif; ?>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const resultDiv = document.getElementById('licencia-result');

  // ===== Helpers =====
  const ZERO_WIDTH = /[\u200B-\u200D\uFEFF]/g;
  const SPACE_LIKE = /[\u00A0\u1680\u2000-\u200A\u202F\u205F\u3000]/g;
  function normalizeNFKC(s){ try { return (s || '').normalize('NFKC'); } catch(_){ return (s||''); } }
  function toUpper(s){ return normalizeNFKC((s||'').replace(ZERO_WIDTH,'').replace(SPACE_LIKE,' ')).toUpperCase(); }

  // ===== Tipo + descripción =====
  const selectTipo = document.getElementById('tipo-licencia-select');
  const descDiv    = document.getElementById('desc-licencia');

  function buildSetFromSelect(sel){
    const set = new Set();
    sel?.querySelectorAll('option').forEach(o=>{
      const v = (o.value || '').trim(); if (v) set.add(v);
    });
    return set;
  }
  const validTipos = buildSetFromSelect(selectTipo);

  function validateSelectMembership(sel, validSet, msg){
    const val = (sel.value || '').trim();
    if (!val || !validSet.has(val)) { sel.setCustomValidity(msg || 'Selección inválida.'); return false; }
    sel.setCustomValidity(''); return true;
  }

  selectTipo?.addEventListener('change', function() {
    const selected = selectTipo.options[selectTipo.selectedIndex];
    const desc = selected ? (selected.getAttribute('data-desc') || '') : '';
    descDiv.textContent = desc ? 'Motivo: ' + desc : '';
    validateSelectMembership(selectTipo, validTipos, 'Tipo de licencia inválido.');
  });

  // ===== Observaciones (permitir espacios al tipear) =====
  const form = document.getElementById('form-solicitar-licencia');
  const obsInput = form ? form.querySelector('input[name="observaciones"]') : null;
  const OBS_FORBIDDEN = /[^A-ZÁÉÍÓÚÑ0-9 .,;:¡!¿?\(\)\-_/#+%]/g;

  function sanitizeObsSoft(v){
    v = toUpper(v);
    v = v.replace(/[<>]/g,'').replace(OBS_FORBIDDEN,'');
    if (v.length > 300) v = v.slice(0,300);
    return v; // sin colapsar espacios aquí
  }
  function sanitizeObsFinal(v){
    v = toUpper(v);
    v = v.replace(/[<>]/g,'').replace(OBS_FORBIDDEN,'');
    v = v.replace(/\s+/g,' ').trim(); // colapsar al final
    if (v.length > 300) v = v.slice(0,300);
    return v;
  }

  if (obsInput) {
    obsInput.addEventListener('beforeinput', (e)=>{
      if (e.inputType !== 'insertText') return;
      const ch = toUpper(e.data || '');
      if (ch && /[^A-ZÁÉÍÓÚÑ0-9 .,:;¡!¿?\(\)\-_/#+%]/.test(ch)) e.preventDefault();
    });
    obsInput.addEventListener('input', ()=>{
      const s = obsInput.selectionStart, e = obsInput.selectionEnd;
      const clean = sanitizeObsSoft(obsInput.value);
      obsInput.value = clean;
      try { obsInput.setSelectionRange(s,e); } catch(_){}
      obsInput.setCustomValidity('');
    });
    obsInput.addEventListener('blur', ()=>{ obsInput.value = sanitizeObsFinal(obsInput.value); });
    obsInput.addEventListener('paste', (e)=>{
      e.preventDefault();
      const t = (e.clipboardData || window.clipboardData).getData('text') || '';
      const s = obsInput.selectionStart, en = obsInput.selectionEnd;
      const insert = sanitizeObsSoft(t);
      obsInput.value = obsInput.value.slice(0,s) + insert + obsInput.value.slice(en);
      const pos = s + insert.length; obsInput.setSelectionRange(pos,pos);
    });
  }

  // ===== Fechas =====
  const fInicio = document.getElementById('fecha_inicio');
  const fFin    = document.getElementById('fecha_fin');
  function setDateBounds(){
    if (!fInicio || !fFin) return;
    fInicio.min = fFin.min = '2000-01-01';
    fInicio.max = fFin.max = '2100-12-31';
  }
  setDateBounds();
  function validarRangoFechas(){
    if (!fInicio || !fFin) return true;
    const vi = fInicio.value, vf = fFin.value;
    if (vi && vf && vi > vf) { fFin.setCustomValidity('La fecha de fin no puede ser anterior a la de inicio.'); return false; }
    fFin.setCustomValidity(''); return true;
  }
  fInicio?.addEventListener('change', validarRangoFechas);
  fFin?.addEventListener('change', validarRangoFechas);

  // ===== Archivo =====
  const fileInput = document.getElementById('lic-file');
  const ALLOWED_MIMES = new Set(['application/pdf','image/jpeg','image/png','image/webp']);
  const ALLOWED_EXTS  = new Set(['pdf','jpg','jpeg','png','webp']);
  const MAX_BYTES     = fileInput ? parseInt(fileInput.getAttribute('data-max-bytes') || '5242880', 10) : 5242880;

  function getExt(name){ const m = (name||'').toLowerCase().match(/\.([a-z0-9]+)$/); return m ? m[1] : ''; }
  function readHead(file, bytes){
    return new Promise((resolve, reject)=>{
      const fr = new FileReader();
      fr.onerror = () => reject(new Error('read error'));
      fr.onload  = () => resolve(new Uint8Array(fr.result || new ArrayBuffer(0)));
      fr.readAsArrayBuffer(file.slice(0, bytes));
    });
  }
  async function hasValidMagic(file){
    try {
      const head = await readHead(file, 12);
      if (head.length >= 5 && head[0]===0x25 && head[1]===0x50 && head[2]===0x44 && head[3]===0x46 && head[4]===0x2D) return true; // %PDF-
      if (head.length >= 3 && head[0]===0xFF && head[1]===0xD8 && head[2]===0xFF) return true; // JPEG
      const pngSig = [0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A];
      if (head.length >= 8 && pngSig.every((b,i)=> head[i]===b)) return true; // PNG
      if (head.length >= 12) {
        const riff = String.fromCharCode(head[0],head[1],head[2],head[3]);
        const webp = String.fromCharCode(head[8],head[9],head[10],head[11]);
        if (riff === 'RIFF' && webp === 'WEBP') return true; // WEBP
      }
    } catch(_){}
    return false;
  }
  function showOK(msg){ resultDiv.innerHTML = '<div class="midas-msg-ok">'+(msg||'OK')+'</div>'; }
  function showError(msg){ resultDiv.innerHTML = '<div class="midas-msg-err">'+(msg||'Ocurrió un error')+'</div>'; }

  function invalidFile(msg){
    if (fileInput) {
      fileInput.value = '';
      fileInput.setCustomValidity(msg || 'Archivo inválido.');
    }
    showError(msg || 'Archivo inválido.');
  }
  function validFile(){ if (fileInput) fileInput.setCustomValidity(''); }

  async function validateFileInput(){
    const f = fileInput && fileInput.files ? fileInput.files[0] : null;
    if (!f) { validFile(); return true; } // opcional
    if (f.size > MAX_BYTES) { invalidFile('Archivo demasiado grande (máx. 5 MB).'); return false; }
    const ext  = getExt(f.name);
    const type = (f.type || '').toLowerCase();
    if (!ALLOWED_EXTS.has(ext) || (type && !ALLOWED_MIMES.has(type))) {
      invalidFile('Tipo de archivo no permitido. Usa PDF, JPG, PNG o WEBP.'); return false;
    }
    if (!(await hasValidMagic(f))) { invalidFile('El contenido del archivo no coincide con su tipo.'); return false; }
    validFile(); return true;
  }
  fileInput?.addEventListener('change', validateFileInput);

  // ===== Submit =====
  if (form) {
    form.addEventListener('submit', async function(e) {
      e.preventDefault();

      // Honeypot
      const honeypot = form.querySelector('input[name="website"]');
      if (honeypot && honeypot.value) { showError('Error de validación.'); return; }

      // Select
      if (selectTipo && !validateSelectMembership(selectTipo, validTipos, 'Tipo de licencia inválido.')) {
        selectTipo.reportValidity(); return;
      }

      if (!validarRangoFechas()) { fFin.reportValidity(); return; }

      // Observaciones: normalización final
      if (obsInput) obsInput.value = sanitizeObsFinal(obsInput.value);

      // Archivo
      if (!(await validateFileInput())) return;

      showOK('Enviando...');

      const formData = new FormData(form);
      // IMPORTANTE: usar el action que existe en Ajax_Handler
      formData.append('action', 'midas_crear_licencia');

      fetch(ajaxurl, { method:'POST', body:formData, credentials:'include' })
        .then(r => r.json().catch(()=>({success:false})))
        .then(data => {
          if (data.success) {
            showOK(data.data?.message || 'Licencia solicitada correctamente.');
            form.reset(); descDiv && (descDiv.textContent = ''); validFile();
          } else {
            let msg = 'Error al solicitar licencia';
            if (typeof data.data === 'string') msg = data.data;
            else if (data.data && data.data.message) msg = data.data.message;
            showError(msg);
          }
        })
        .catch(() => showError('Error inesperado, intente de nuevo.'));
    });
  }
});
</script>
