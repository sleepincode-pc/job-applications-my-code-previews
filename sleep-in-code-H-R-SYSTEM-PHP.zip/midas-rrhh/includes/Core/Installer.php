<?php
namespace MidasRRHH\Core;

use MidasRRHH\Controllers\WelcomeController;

if (!defined('ABSPATH')) exit;

class Installer {
    public static function init() {
        add_action('admin_init', [WelcomeController::class, 'maybe_show_welcome']);
        if (method_exists(WelcomeController::class, 'set_login_logo')) {
            add_action('login_enqueue_scripts', [WelcomeController::class, 'set_login_logo']);
        }

        // Registrar el auditor de logins (funciona también en wp-login.php/frontend)
        add_action('init', function () {
            if (!class_exists('\MidasRRHH\Controllers\Login_Audit_Controller')) {
                if (defined('MIDAS_RRHH_PLUGIN_DIR')) {
                    $candidates = [
                        MIDAS_RRHH_PLUGIN_DIR . 'Controllers/Login_Audit_Controller.php',
                        MIDAS_RRHH_PLUGIN_DIR . 'controllers/Login_Audit_Controller.php',
                        MIDAS_RRHH_PLUGIN_DIR . 'includes/Controllers/Login_Audit_Controller.php',
                    ];
                    foreach ($candidates as $f) { if (file_exists($f)) { require_once $f; break; } }
                }
            }
            if (class_exists('\MidasRRHH\Controllers\Login_Audit_Controller')) {
                \MidasRRHH\Controllers\Login_Audit_Controller::init();
            }
        });

        // === AJAX Organigrama (admin-ajax.php) ===
        add_action('wp_ajax_midas_orgchart_get',  [__CLASS__, 'ajax_orgchart_get']);
        add_action('wp_ajax_midas_orgchart_save', [__CLASS__, 'ajax_orgchart_save']);
    }

    public static function activate() {
        self::create_tables();
        self::create_roles();
        self::set_default_options();
        self::schedule_cron_events();
        update_option('midas_rrhh_show_welcome', true);

        // Migraciones no destructivas
        self::migrar_campos_empleados();
        self::eliminar_indice_unique_user_id_empleados();
        self::insertar_datos_por_defecto();
        self::migrar_columnas_visto();

        // === Asegurar columnas de auditoría + BACKFILL (docs / tipos)
        self::migrar_auditoria_docs_y_tipos();

        if (method_exists(__CLASS__, 'migrar_campo_gestor_id_licencias')) self::migrar_campo_gestor_id_licencias();
        if (method_exists(__CLASS__, 'migrar_campo_monto_recibos')) self::migrar_campo_monto_recibos();
        if (method_exists(__CLASS__, 'migrar_detalles_recibos')) self::migrar_detalles_recibos();
        if (method_exists(__CLASS__, 'migrar_dias_solicitados_carpeta_medica')) self::migrar_dias_solicitados_carpeta_medica();
        if (method_exists(__CLASS__, 'migrar_campo_rol_en_tareas_y_areas')) self::migrar_campo_rol_en_tareas_y_areas();

        // Páginas necesarias
        self::crear_paginas_rrhh();

        // Asegurar esquemas
        self::ensure_tickets_schema();
        self::ensure_organigrama_schema();

        // Limpieza de tablas de tickets legacy
        self::drop_legacy_ticket_history_tables();
    }

    public static function deactivate() {
        self::clear_cron_events();
    }

    public static function uninstall() {
        self::clear_cron_events();
        if (defined('MIDAS_RRHH_PURGE_ON_UNINSTALL') && MIDAS_RRHH_PURGE_ON_UNINSTALL) {
            self::drop_tables();
            self::remove_roles();
            self::remove_options();
        }
    }

    /** Limpieza manual opcional (no borra documentaciones ni tipos) */
    public static function drop_bad_tables() {
        global $wpdb;
        $tablas = [
            'midas_medicos',
            'midas_enfermedades',
            'midas_licencia_tipos',
            'midas_tickets_respuestas', // legacy
            'midas_tickets_rechazos',   // legacy
            'midas_empleado_area',
            // (intencionalmente NO incluimos midas_doc_tipos ni midas_documentaciones)
        ];
        foreach ($tablas as $t) $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}$t");
    }

    // ===================== CREATE TABLES =====================
    private static function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = [
            // EMPLEADOS
            "CREATE TABLE {$wpdb->prefix}midas_empleados (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                nombre VARCHAR(191) NOT NULL,
                apellido VARCHAR(191) NOT NULL,
                dni VARCHAR(20),
                cuil VARCHAR(20),
                email VARCHAR(150),
                telefono VARCHAR(50),
                fecha_nacimiento DATE,
                direccion TEXT,
                estado_civil VARCHAR(50),
                fecha_inicio_laboral DATE,
                fecha_fin_laboral DATE NULL,
                foto_id BIGINT UNSIGNED,
                user_id BIGINT UNSIGNED,
                tarea_id BIGINT UNSIGNED,
                area_id BIGINT UNSIGNED,
                area VARCHAR(255),
                tarea VARCHAR(255),
                antiguedad_reconocida INT NULL,
                activo TINYINT(1) DEFAULT 1,
                cv_id BIGINT UNSIGNED,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                created_by BIGINT UNSIGNED,
                updated_by BIGINT UNSIGNED,
                PRIMARY KEY (id),
                KEY user_idx (user_id),
                KEY area_idx (area_id),
                KEY tarea_idx (tarea_id)
            ) $charset_collate;",

            // AREAS
            "CREATE TABLE {$wpdb->prefix}midas_areas (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                nombre VARCHAR(191) NOT NULL,
                descripcion TEXT,
                rol VARCHAR(100) DEFAULT '',
                activo TINYINT(1) DEFAULT 1,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $charset_collate;",

            // TAREAS
            "CREATE TABLE {$wpdb->prefix}midas_tareas (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                nombre VARCHAR(191) NOT NULL,
                descripcion TEXT,
                rol VARCHAR(100) DEFAULT '',
                activo TINYINT(1) DEFAULT 1,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $charset_collate;",

            // LICENCIAS
            "CREATE TABLE {$wpdb->prefix}midas_licencias (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                empleado_id BIGINT UNSIGNED NOT NULL,
                tipo VARCHAR(191) NOT NULL,
                fecha_inicio DATE,
                fecha_fin DATE,
                dias_solicitados INT NULL,
                dias_aprobados INT NULL,
                documento_id BIGINT UNSIGNED NULL,
                observaciones TEXT,
                gestor_id BIGINT UNSIGNED DEFAULT NULL,
                estado ENUM('pendiente','aprobado','rechazado') DEFAULT 'pendiente',
                visto TINYINT(1) DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY empleado_idx (empleado_id),
                KEY gestor_idx (gestor_id)
            ) $charset_collate;",

            // RECIBOS
            "CREATE TABLE {$wpdb->prefix}midas_recibos (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                empleado_id BIGINT UNSIGNED NOT NULL,
                periodo VARCHAR(32) NOT NULL,
                archivo_id BIGINT UNSIGNED,
                monto DECIMAL(15,2) NOT NULL DEFAULT 0,
                detalles TEXT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY empleado_idx (empleado_id)
            ) $charset_collate;",

            // CARPETA MÉDICA
            "CREATE TABLE {$wpdb->prefix}midas_carpeta_medica (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                empleado_id BIGINT UNSIGNED NOT NULL,
                motivo_id BIGINT UNSIGNED,
                medico_id BIGINT UNSIGNED,
                documento_id BIGINT UNSIGNED NULL,
                fecha_emision DATE,
                dias_solicitados INT NULL,
                dias_aprobados INT NULL,
                fecha_vencimiento DATE,
                estado_id BIGINT UNSIGNED,
                fecha_solicitud DATETIME,
                gestor_id BIGINT UNSIGNED,
                observaciones TEXT,
                visto TINYINT(1) DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY empleado_idx (empleado_id)
            ) $charset_collate;",

            // CATÁLOGOS
            "CREATE TABLE {$wpdb->prefix}midas_estados_carpeta_medica (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                descripcion VARCHAR(191) NOT NULL,
                PRIMARY KEY (id)
            ) $charset_collate;",
            "CREATE TABLE {$wpdb->prefix}midas_motivos_carpeta_medica (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                descripcion VARCHAR(191) NOT NULL,
                PRIMARY KEY (id)
            ) $charset_collate;",
            "CREATE TABLE {$wpdb->prefix}midas_medicos (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                nombre VARCHAR(191) NOT NULL,
                apellido VARCHAR(191) NOT NULL,
                especialidad VARCHAR(191) NULL,
                matricula VARCHAR(191) NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $charset_collate;",
            "CREATE TABLE {$wpdb->prefix}midas_enfermedades (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                tipo VARCHAR(191) NOT NULL,
                descripcion TEXT,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $charset_collate;",
            "CREATE TABLE {$wpdb->prefix}midas_licencia_tipos (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                tipo VARCHAR(191) NOT NULL,
                descripcion TEXT,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $charset_collate;",

            // TICKETS (ÚNICA tabla de tickets)
            "CREATE TABLE {$wpdb->prefix}midas_tickets (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id BIGINT UNSIGNED NOT NULL,
                destinatario_id BIGINT UNSIGNED NULL,
                asunto VARCHAR(191) NOT NULL,
                mensaje TEXT NOT NULL,
                estado ENUM('pendiente','enviado','respondido','rechazado') DEFAULT 'pendiente',
                respuesta TEXT,
                fecha_creacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                fecha_respuesta DATETIME NULL,
                admin_id BIGINT UNSIGNED NULL,
                admin_nombre VARCHAR(191) NULL,
                motivo_rechazo TEXT,
                visto TINYINT(1) DEFAULT 0,
                PRIMARY KEY (id),
                KEY user_idx (user_id),
                KEY dest_idx (destinatario_id),
                KEY admin_idx (admin_id),
                KEY estado_idx (estado)
            ) $charset_collate;",

            // RELACIONES/NOTAS
            "CREATE TABLE {$wpdb->prefix}midas_empleado_area (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                empleado_id BIGINT UNSIGNED NOT NULL,
                area_id BIGINT UNSIGNED NOT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY empleado_idx (empleado_id),
                KEY area_idx (area_id)
            ) $charset_collate;",
            "CREATE TABLE {$wpdb->prefix}midas_empleado_notas (
                empleado_id BIGINT UNSIGNED NOT NULL,
                nota TEXT NULL,
                PRIMARY KEY (empleado_id)
            ) $charset_collate;",

            // ARCHIVOS MÉDICOS
            "CREATE TABLE {$wpdb->prefix}midas_archivos_medicos (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                carpeta_medica_id BIGINT UNSIGNED NOT NULL,
                file_url VARCHAR(255) NOT NULL,
                file_type VARCHAR(50),
                descripcion TEXT NULL,
                uploaded_by BIGINT UNSIGNED,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY carpeta_medica_idx (carpeta_medica_id)
            ) $charset_collate;",

            /* ===================== DOCUMENTACIÓN CON VENCIMIENTO ===================== */
            "CREATE TABLE {$wpdb->prefix}midas_doc_tipos (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                descripcion VARCHAR(191) NOT NULL,
                plazo_numero INT NULL,
                plazo_unidad ENUM('dias','meses','anios') NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                created_by BIGINT UNSIGNED NULL,
                updated_by BIGINT UNSIGNED NULL,
                PRIMARY KEY (id),
                KEY desc_idx (descripcion)
            ) $charset_collate;",
            "CREATE TABLE {$wpdb->prefix}midas_documentaciones (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                empleado_id BIGINT UNSIGNED NOT NULL,
                tipo_id BIGINT UNSIGNED NULL,
                descripcion TEXT NULL,
                fecha_inicio DATE NOT NULL,
                fecha_fin DATE NULL,
                archivo_id BIGINT UNSIGNED NULL,
                borrado TINYINT(1) DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                created_by BIGINT UNSIGNED NULL,
                updated_by BIGINT UNSIGNED NULL,
                PRIMARY KEY (id),
                KEY empleado_idx (empleado_id),
                KEY tipo_idx (tipo_id),
                KEY fin_idx (fecha_fin),
                KEY borrado_idx (borrado)
            ) $charset_collate;",

            /* ===================== AUDITORÍA DE ACCESOS (LOGINS) ===================== */
            "CREATE TABLE {$wpdb->prefix}midas_login_audit (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id BIGINT UNSIGNED NOT NULL,
                login_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                ip VARCHAR(45) NULL,
                ua TEXT NULL,
                device VARCHAR(191) NULL,
                browser VARCHAR(100) NULL,
                os VARCHAR(100) NULL,
                city VARCHAR(191) NULL,
                region VARCHAR(191) NULL,
                country VARCHAR(191) NULL,
                lat DECIMAL(10,6) NULL,
                lon DECIMAL(10,6) NULL,
                PRIMARY KEY (id),
                KEY user_idx (user_id),
                KEY login_idx (login_at)
            ) $charset_collate;",

            /* ===================== ORGANIGRAMA ===================== */
            "CREATE TABLE {$wpdb->prefix}midas_org_nodes (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                nombre VARCHAR(191) NOT NULL,
                puesto VARCHAR(191) NULL,
                empleado_id BIGINT UNSIGNED NULL,
                area_id BIGINT UNSIGNED NULL,
                tarea_id BIGINT UNSIGNED NULL,
                email VARCHAR(150) NULL,
                telefono VARCHAR(50) NULL,
                foto_id BIGINT UNSIGNED NULL,
                parent_id BIGINT UNSIGNED NULL,
                orden INT NOT NULL DEFAULT 0,
                color VARCHAR(7) NULL,
                meta LONGTEXT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                created_by BIGINT UNSIGNED NULL,
                updated_by BIGINT UNSIGNED NULL,
                PRIMARY KEY (id),
                KEY parent_idx (parent_id),
                KEY empleado_idx (empleado_id),
                KEY area_idx (area_id),
                KEY tarea_idx (tarea_id)
            ) $charset_collate;"
        ];

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        foreach ($sql as $query) {
            dbDelta($query);
        }

        // Endurecer/asegurar esquema para instalaciones existentes
        self::ensure_tickets_schema();
        self::ensure_organigrama_schema();

        // Purgar tablas de historial de tickets si quedaron de versiones anteriores
        self::drop_legacy_ticket_history_tables();

        // Seed opcional del nodo raíz del organigrama si no hay registros
        $tabla_org = "{$wpdb->prefix}midas_org_nodes";
        $existe_org = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tabla_org));
        if ($existe_org) {
            $count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$tabla_org}");
            if ($count === 0) {
                $wpdb->insert($tabla_org, [
                    'nombre'     => 'Organigrama',
                    'puesto'     => 'Dirección',
                    'parent_id'  => null,
                    'orden'      => 0,
                    'color'      => '#2271b1',
                    'created_by' => get_current_user_id() ?: null,
                    'updated_by' => get_current_user_id() ?: null,
                ]);
            }
        }
    }

    /** Helper: existe columna */
    private static function col_exists($table, $col) {
        global $wpdb;
        return (bool)$wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$table` LIKE %s", $col));
    }

    /** Asegura SOLO la tabla principal de tickets */
    private static function ensure_tickets_schema() {
        global $wpdb;
        $t = $wpdb->prefix . 'midas_tickets';

        $existe_t = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t));
        if ($existe_t) {
            if (!self::col_exists($t, 'destinatario_id'))  $wpdb->query("ALTER TABLE `$t` ADD COLUMN `destinatario_id` BIGINT(20) UNSIGNED NULL AFTER `user_id`");
            if (!self::col_exists($t, 'fecha_respuesta'))  $wpdb->query("ALTER TABLE `$t` ADD COLUMN `fecha_respuesta` DATETIME NULL AFTER `fecha_creacion`");
            if (!self::col_exists($t, 'admin_nombre'))     $wpdb->query("ALTER TABLE `$t` ADD COLUMN `admin_nombre` VARCHAR(191) NULL AFTER `admin_id`");

            // Estado incluye 'enviado'
            $col_estado = $wpdb->get_row("SHOW COLUMNS FROM `$t` LIKE 'estado'");
            if ($col_estado && isset($col_estado->Type) && stripos($col_estado->Type, "'enviado'") === false) {
                $wpdb->query("ALTER TABLE `$t` MODIFY COLUMN `estado` ENUM('pendiente','enviado','respondido','rechazado') DEFAULT 'pendiente'");
            }

            // Índices
            $idx = $wpdb->get_results("SHOW INDEX FROM `$t`", ARRAY_A);
            $names = array_map(fn($i) => $i['Key_name'], $idx);
            if (!in_array('user_idx', $names, true))   $wpdb->query("ALTER TABLE `$t` ADD KEY `user_idx` (`user_id`)");
            if (!in_array('dest_idx', $names, true))   $wpdb->query("ALTER TABLE `$t` ADD KEY `dest_idx` (`destinatario_id`)");
            if (!in_array('admin_idx', $names, true))  $wpdb->query("ALTER TABLE `$t` ADD KEY `admin_idx` (`admin_id`)");
            if (!in_array('estado_idx', $names, true)) $wpdb->query("ALTER TABLE `$t` ADD KEY `estado_idx` (`estado`)");

            // Normaliza estados vacíos
            $wpdb->query("UPDATE `$t` SET estado='pendiente' WHERE estado IS NULL OR estado=''");
        }

        if (!empty($wpdb->last_error)) {
            error_log('[Installer::ensure_tickets_schema] DB error: ' . $wpdb->last_error);
        }
    }

    /** Asegura el esquema del organigrama */
    private static function ensure_organigrama_schema() {
        global $wpdb;
        $t = $wpdb->prefix . 'midas_org_nodes';
        $existe = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t));
        if (!$existe) return;

        $add = function($col, $def) use ($wpdb, $t) {
            if (!self::col_exists($t, $col)) $wpdb->query("ALTER TABLE `$t` ADD COLUMN `$col` $def");
        };

        $add('puesto',     "VARCHAR(191) NULL AFTER `nombre`");
        $add('empleado_id',"BIGINT(20) UNSIGNED NULL AFTER `puesto`");
        $add('area_id',    "BIGINT(20) UNSIGNED NULL AFTER `empleado_id`");
        $add('tarea_id',   "BIGINT(20) UNSIGNED NULL AFTER `area_id`");
        $add('email',      "VARCHAR(150) NULL AFTER `tarea_id`");
        $add('telefono',   "VARCHAR(50) NULL AFTER `email`");
        $add('foto_id',    "BIGINT(20) UNSIGNED NULL AFTER `telefono`");
        $add('parent_id',  "BIGINT(20) UNSIGNED NULL AFTER `foto_id`");
        $add('orden',      "INT NOT NULL DEFAULT 0 AFTER `parent_id`");
        $add('color',      "VARCHAR(7) NULL AFTER `orden`");
        $add('meta',       "LONGTEXT NULL AFTER `color`");
        $add('created_by', "BIGINT(20) UNSIGNED NULL AFTER `updated_at`");
        $add('updated_by', "BIGINT(20) UNSIGNED NULL AFTER `created_by`");

        // Índices mínimos
        $idx = $wpdb->get_results("SHOW INDEX FROM `$t`", ARRAY_A);
        $names = array_map(fn($i) => $i['Key_name'], $idx);
        if (!in_array('parent_idx', $names, true))   $wpdb->query("ALTER TABLE `$t` ADD KEY `parent_idx` (`parent_id`)");
        if (!in_array('empleado_idx', $names, true)) $wpdb->query("ALTER TABLE `$t` ADD KEY `empleado_idx` (`empleado_id`)");

        if (!empty($wpdb->last_error)) {
            error_log('[Installer::ensure_organigrama_schema] DB error: ' . $wpdb->last_error);
        }
    }

    /** Elimina SIEMPRE las tablas legacy de historial de tickets */
    private static function drop_legacy_ticket_history_tables() {
        global $wpdb;
        $legacy = [
            "{$wpdb->prefix}midas_tickets_respuestas",
            "{$wpdb->prefix}midas_tickets_rechazos",
        ];
        foreach ($legacy as $table) {
            $wpdb->query("DROP TABLE IF EXISTS `$table`");
        }
    }

    private static function eliminar_indice_unique_user_id_empleados() {
        global $wpdb;
        $table = $wpdb->prefix . 'midas_empleados';
        $index = $wpdb->get_results("SHOW INDEX FROM $table WHERE Column_name = 'user_id' AND Non_unique = 0");
        if ($index) {
            foreach ($index as $idx) {
                $key_name = $idx->Key_name;
                if (strtolower($key_name) != 'primary') {
                    $wpdb->query("ALTER TABLE $table DROP INDEX `$key_name`");
                }
            }
        }
    }

    // ===================== INSERTAR DATOS POR DEFECTO =====================
    private static function insertar_datos_por_defecto() {
        global $wpdb;

        $tabla_estados = "{$wpdb->prefix}midas_estados_carpeta_medica";
        $estados = ['PENDIENTE', 'APROBADO', 'DENEGADO', 'REVISIÓN'];
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tabla_estados))) {
            foreach ($estados as $estado) {
                $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $tabla_estados WHERE descripcion = %s", $estado));
                if (!$exists) $wpdb->insert($tabla_estados, ['descripcion' => $estado]);
            }
        }

        $tabla_motivos = "{$wpdb->prefix}midas_motivos_carpeta_medica";
        $motivos = ['REPOSO', 'ESTUDIOS MÉDICOS', 'INTERNACIÓN', 'CONSULTA EXTERNA'];
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tabla_motivos))) {
            foreach ($motivos as $motivo) {
                $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $tabla_motivos WHERE descripcion = %s", $motivo));
                if (!$exists) $wpdb->insert($tabla_motivos, ['descripcion' => $motivo]);
            }
        }

        $tabla_enfermedades = "{$wpdb->prefix}midas_enfermedades";
        $enfermedades = [
            ['tipo' => 'GRIPE/INFLUENZA', 'descripcion' => 'INFECCIÓN VIRAL RESPIRATORIA COMÚN.'],
            ['tipo' => 'COVID-19', 'descripcion' => 'ENFERMEDAD RESPIRATORIA CAUSADA POR CORONAVIRUS.'],
            ['tipo' => 'GASTROENTERITIS', 'descripcion' => 'INFECCIÓN INTESTINAL.'],
            ['tipo' => 'BRONQUITIS', 'descripcion' => 'INFLAMACIÓN DE LOS BRONQUIOS.'],
            ['tipo' => 'SINUSITIS', 'descripcion' => 'INFLAMACIÓN DE LOS SENOS NASALES.'],
            ['tipo' => 'MIGRAÑA', 'descripcion' => 'DOLOR DE CABEZA INTENSO.'],
            ['tipo' => 'ACCIDENTE LABORAL', 'descripcion' => 'LESIÓN EN HORARIO DE TRABAJO.'],
            ['tipo' => 'ENFERMEDAD CRÓNICA', 'descripcion' => 'CONDICIÓN DE LARGA DURACIÓN.'],
            ['tipo' => 'ALERGIA ESTACIONAL', 'descripcion' => 'REACCIÓN ALÉRGICA POR ESTACIÓN.'],
            ['tipo' => 'VARICELA', 'descripcion' => 'ENFERMEDAD VIRAL.'],
            ['tipo' => 'INFECCIÓN URINARIA', 'descripcion' => 'INFECCIÓN DEL TRACTO URINARIO.'],
            ['tipo' => 'ENFERMEDAD CARDIOVASCULAR', 'descripcion' => 'PROBLEMAS CARDIOVASCULARES.'],
            ['tipo' => 'LICENCIA POR MATERNIDAD', 'descripcion' => 'PERIODO PRE/POST PARTO.'],
            ['tipo' => 'LICENCIA POR PATERNIDAD', 'descripcion' => 'NACIMIENTO DE HIJO/A.'],
            ['tipo' => 'LICENCIA POR DUELO', 'descripcion' => 'FALLECIMIENTO DE FAMILIAR DIRECTO.'],
            ['tipo' => 'CUIDADO DE FAMILIAR', 'descripcion' => 'CUIDADO DE FAMILIAR ENFERMO.'],
            ['tipo' => 'VACUNACIÓN', 'descripcion' => 'PERMISO PARA VACUNARSE.'],
            ['tipo' => 'CONSULTA MÉDICA', 'descripcion' => 'CONTROL/CONSULTA.'],
        ];
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tabla_enfermedades))) {
            foreach ($enfermedades as $e) {
                $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $tabla_enfermedades WHERE tipo = %s", $e['tipo']));
                if (!$exists) $wpdb->insert($tabla_enfermedades, $e);
            }
        }

        $tabla_medicos = "{$wpdb->prefix}midas_medicos";
        $medicos = [
            ['nombre' => 'ANA', 'apellido' => 'GÓMEZ', 'especialidad' => 'CLÍNICA MÉDICA', 'matricula' => 'MN 12345'],
            ['nombre' => 'CARLOS', 'apellido' => 'PÉREZ', 'especialidad' => 'TRAUMATOLOGÍA', 'matricula' => 'MN 67890'],
            ['nombre' => 'LUCÍA', 'apellido' => 'RAMOS', 'especialidad' => 'PEDIATRÍA', 'matricula' => 'MN 11223'],
            ['nombre' => 'DIEGO', 'apellido' => 'FERNÁNDEZ', 'especialidad' => 'MEDICINA LABORAL', 'matricula' => 'MN 44556'],
            ['nombre' => 'VERÓNICA', 'apellido' => 'SOSA', 'especialidad' => 'OTORRINO', 'matricula' => 'MN 77889'],
        ];
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tabla_medicos))) {
            foreach ($medicos as $m) {
                $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $tabla_medicos WHERE nombre = %s AND apellido = %s", $m['nombre'], $m['apellido']));
                if (!$exists) $wpdb->insert($tabla_medicos, $m);
            }
        }

        $tabla_licencias = "{$wpdb->prefix}midas_licencia_tipos";
        $licencias = [
            ['tipo' => 'ENFERMEDAD', 'descripcion' => 'LICENCIA POR ENFERMEDAD COMÚN O ACCIDENTE NO LABORAL'],
            ['tipo' => 'ACCIDENTE DE TRABAJO', 'descripcion' => 'LICENCIA POR ACCIDENTE LABORAL'],
            ['tipo' => 'MATERNIDAD', 'descripcion' => 'LICENCIA PRE Y POSTNATAL'],
            ['tipo' => 'PATERNIDAD', 'descripcion' => 'LICENCIA POR NACIMIENTO DE HIJO/A'],
            ['tipo' => 'DUELO', 'descripcion' => 'LICENCIA POR FALLECIMIENTO DE FAMILIAR DIRECTO'],
            ['tipo' => 'EXAMEN', 'descripcion' => 'LICENCIA PARA RENDIR EXÁMENES'],
            ['tipo' => 'ESTUDIO', 'descripcion' => 'LICENCIA PARA CURSADA REGULAR'],
            ['tipo' => 'VACACIONES', 'descripcion' => 'DESCANSO ANUAL'],
            ['tipo' => 'CASAMIENTO', 'descripcion' => 'LICENCIA POR MATRIMONIO'],
            ['tipo' => 'DONACIÓN DE SANGRE', 'descripcion' => 'LICENCIA PARA DONAR SANGRE'],
            ['tipo' => 'FUERZA MAYOR', 'descripcion' => 'CAUSAS JUSTIFICADAS'],
            ['tipo' => 'ADOPCIÓN', 'descripcion' => 'LICENCIA POR ADOPCIÓN'],
            ['tipo' => 'CUIDADO DE FAMILIAR ENFERMO', 'descripcion' => 'CUIDADO DE FAMILIAR GRAVE'],
            ['tipo' => 'ATENCIÓN MÉDICA', 'descripcion' => 'TURNOS/CONTROLES MÉDICOS'],
            ['tipo' => 'MUDANZA', 'descripcion' => 'CAMBIO DE DOMICILIO'],
            ['tipo' => 'VACUNACIÓN', 'descripcion' => 'APLICACIÓN DE VACUNAS'],
            ['tipo' => 'CITACIONES OFICIALES', 'descripcion' => 'AUTORIDAD PÚBLICA/JUDICIAL'],
            ['tipo' => 'SIN GOCE DE SUELDO', 'descripcion' => 'ESPECIAL SIN HABERES'],
        ];
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tabla_licencias))) {
            foreach ($licencias as $l) {
                $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $tabla_licencias WHERE tipo = %s", $l['tipo']));
                if (!$exists) $wpdb->insert($tabla_licencias, $l);
            }
        }
    }

    // ===================== MIGRAR CAMPOS EMPLEADOS =====================
    private static function migrar_campos_empleados() {
        global $wpdb;
        $table = $wpdb->prefix . 'midas_empleados';
        if (!$wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table))) return;

        $campos = [
            'user_id' => "BIGINT(20) UNSIGNED DEFAULT NULL AFTER `id`",
            'email' => "VARCHAR(150) NOT NULL AFTER `apellido`",
            'telefono' => "VARCHAR(50) NULL AFTER `email`",
            'fecha_nacimiento' => "DATE NOT NULL AFTER `telefono`",
            'foto_id' => "BIGINT(20) UNSIGNED NULL AFTER `fecha_nacimiento`",
            'direccion' => "TEXT NULL AFTER `foto_id`",
            'estado_civil' => "VARCHAR(50) NULL AFTER `direccion`",
            'cv_id' => "BIGINT(20) UNSIGNED NULL AFTER `estado_civil`",
            'fecha_inicio_laboral' => "DATE NOT NULL AFTER `cv_id`",
            'fecha_fin_laboral' => "DATE NULL AFTER `fecha_inicio_laboral`",
            'tarea_id' => "BIGINT(20) UNSIGNED NULL AFTER `fecha_fin_laboral`",
            'area_id' => "BIGINT(20) UNSIGNED NULL AFTER `tarea_id`",
            'area' => "VARCHAR(255) NULL AFTER `area_id`",
            'tarea' => "VARCHAR(255) NULL AFTER `area`",
            'antiguedad_reconocida' => "INT NULL AFTER `tarea`",
            'activo' => "TINYINT(1) DEFAULT 1 AFTER `antiguedad_reconocida`",
            'created_at' => "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `activo`",
            'updated_at' => "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`",
            'created_by' => "BIGINT(20) UNSIGNED NULL AFTER `updated_at`",
            'updated_by' => "BIGINT(20) UNSIGNED NULL AFTER `created_by`"
        ];
        foreach ($campos as $campo => $def) {
            $exists = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$table` LIKE %s", $campo));
            if (!$exists) $wpdb->query("ALTER TABLE `$table` ADD `$campo` $def");
        }
    }

    // ===================== MIGRAR COLUMNAS VISTO =====================
    public static function migrar_columnas_visto() {
        global $wpdb;
        $tablas = [
            "{$wpdb->prefix}midas_licencias",
            "{$wpdb->prefix}midas_tickets"
        ];
        foreach ($tablas as $tabla) {
            if (!$wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tabla))) continue;
            $existe = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$tabla` LIKE %s", 'visto'));
            if (!$existe) $wpdb->query("ALTER TABLE `$tabla` ADD COLUMN `visto` TINYINT(1) DEFAULT 0");
        }
    }

    // ===================== NUEVO: auditoría + backfill en documentaciones y tipos =====================
    private static function migrar_auditoria_docs_y_tipos() {
        global $wpdb;
        $prefix = $wpdb->prefix;

        $t_docs  = "{$prefix}midas_documentaciones";
        $t_tipos = "{$prefix}midas_doc_tipos";

        $table_exists = function(string $t) use ($wpdb) {
            return (bool) $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t));
        };
        $col_exists = function(string $t, string $c) use ($wpdb) {
            return (bool) $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$t` LIKE %s", $c));
        };

        // DOCUMENTACIONES: columnas created_by / updated_by
        if ($table_exists($t_docs)) {
            if (!$col_exists($t_docs, 'created_by')) {
                $wpdb->query("ALTER TABLE `$t_docs` ADD COLUMN `created_by` BIGINT(20) UNSIGNED NULL AFTER `created_at`");
            }
            if (!$col_exists($t_docs, 'updated_by')) {
                $wpdb->query("ALTER TABLE `$t_docs` ADD COLUMN `updated_by` BIGINT(20) UNSIGNED NULL AFTER `updated_at`");
            }
        }

        // TIPOS: asegurar updated_at + created_by/updated_by
        if ($table_exists($t_tipos)) {
            if (!$col_exists($t_tipos, 'updated_at')) {
                $wpdb->query("ALTER TABLE `$t_tipos` ADD COLUMN `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`");
            }
            if (!$col_exists($t_tipos, 'created_by')) {
                $wpdb->query("ALTER TABLE `$t_tipos` ADD COLUMN `created_by` BIGINT(20) UNSIGNED NULL AFTER `updated_at`");
            }
            if (!$col_exists($t_tipos, 'updated_by')) {
                $wpdb->query("ALTER TABLE `$t_tipos` ADD COLUMN `updated_by` BIGINT(20) UNSIGNED NULL AFTER `created_by`");
            }
        }

        // BACKFILL: asignar un user_id válido si están NULL
        $uid = (int) get_current_user_id();
        if ($uid <= 0) {
            // primer admin disponible
            $uid = (int) $wpdb->get_var("
                SELECT u.ID
                FROM {$wpdb->users} u
                INNER JOIN {$wpdb->usermeta} um
                    ON um.user_id = u.ID AND um.meta_key = 'wp_capabilities'
                WHERE um.meta_value LIKE '%administrator%'
                ORDER BY u.ID ASC
                LIMIT 1
            ");
            if ($uid <= 0) {
                // cualquier usuario como último recurso
                $uid = (int) $wpdb->get_var("SELECT ID FROM {$wpdb->users} ORDER BY ID ASC LIMIT 1");
            }
        }

        if ($uid > 0) {
            if ($table_exists($t_docs)) {
                $wpdb->query($wpdb->prepare("UPDATE `$t_docs`  SET created_by=%d WHERE created_by IS NULL", $uid));
                $wpdb->query($wpdb->prepare("UPDATE `$t_docs`  SET updated_by=%d WHERE updated_by IS NULL", $uid));
            }
            if ($table_exists($t_tipos)) {
                $wpdb->query($wpdb->prepare("UPDATE `$t_tipos` SET created_by=%d WHERE created_by IS NULL", $uid));
                $wpdb->query($wpdb->prepare("UPDATE `$t_tipos` SET updated_by=%d WHERE updated_by IS NULL", $uid));
            }
        }

        if (!empty($wpdb->last_error)) {
            error_log('[Installer::migrar_auditoria_docs_y_tipos] DB error: ' . $wpdb->last_error);
        }
    }

    // ===================== DROP TABLES (uninstall) =====================
    private static function drop_tables() {
        global $wpdb;
        $tables = [
            'midas_empleados',
            'midas_empleado_notas',
            'midas_recibos',
            'midas_licencias',
            'midas_carpeta_medica',
            'midas_tareas',
            'midas_areas',
            'midas_documentos', // legacy, se elimina si existe
            'midas_medicos',
            'midas_estados_carpeta_medica',
            'midas_motivos_carpeta_medica',
            'midas_novedades',
            'midas_tickets',
            'midas_tickets_respuestas', // por si quedaron en instalaciones viejas
            'midas_tickets_rechazos',   // por si quedaron en instalaciones viejas
            'midas_enfermedades',
            'midas_licencia_tipos',
            'midas_empleado_area',
            'midas_empleados_historial',
            'midas_historial_empleados',
            'midas_archivos_medicos',
            'midas_doc_tipos',
            'midas_documentaciones',
            // NUEVO: auditoría de accesos
            'midas_login_audit',
            // NUEVO: organigrama
            'midas_org_nodes'
        ];
        $wpdb->query("SET FOREIGN_KEY_CHECKS = 0;");
        foreach ($tables as $table) $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}{$table}");
        $wpdb->query("SET FOREIGN_KEY_CHECKS = 1;");
    }

    // ===================== ROLES =====================
    private static function create_roles() { /* Implementado en Roles */ }
    private static function remove_roles() { /* Implementado en Roles */ }

    // ===================== OPCIONES =====================
    private static function set_default_options() {
        if (!get_option('midas_rrhh_version')) {
            update_option('midas_rrhh_version', defined('MIDAS_RRHH_VERSION') ? MIDAS_RRHH_VERSION : '1.0.0');
        }
        if (!get_option('midas_rrhh_smtp_settings')) {
            update_option('midas_rrhh_smtp_settings', [
                'from_email' => get_option('admin_email'),
                'from_name'  => get_bloginfo('name'),
                'notify_gestores' => get_option('admin_email')
            ]);
        }
        // Default organigrama tree
        if (get_option('midas_orgchart_tree', null) === null) {
            update_option('midas_orgchart_tree', self::default_org_tree(), false);
        }
    }
    private static function remove_options() {
        delete_option('midas_rrhh_version');
        delete_option('midas_rrhh_smtp_settings');
        delete_option('midas_rrhh_show_welcome');
        delete_option('midas_rrhh_custom_logo_url');
        delete_option('midas_orgchart_tree');
    }

    // ===================== CRON =====================
    private static function schedule_cron_events() {
        if (!wp_next_scheduled('midas_rrhh_daily_tasks')) {
            wp_schedule_event(time(), 'daily', 'midas_rrhh_daily_tasks');
        }
    }
    private static function clear_cron_events() {
        if (!function_exists('wp_clear_scheduled_hook')) return;
        wp_clear_scheduled_hook('midas_rrhh_daily_tasks');
    }

    // ===================== LIMPIEZAS =====================
    private static function eliminar_empleados_duplicados() {
        global $wpdb;
        $table = $wpdb->prefix . 'midas_empleados';
        if (!$wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table))) return;

        $dni_duplicados = $wpdb->get_col("SELECT dni FROM $table WHERE dni IS NOT NULL AND dni != '' GROUP BY dni HAVING COUNT(*) > 1");
        foreach ($dni_duplicados as $dni) {
            $ids = $wpdb->get_col($wpdb->prepare("SELECT id FROM $table WHERE dni = %s ORDER BY id ASC", $dni));
            if (count($ids) > 1) { array_shift($ids); $wpdb->query("DELETE FROM $table WHERE id IN (" . implode(',', array_map('intval', $ids)) . ")"); }
        }

        $cuil_duplicados = $wpdb->get_col("SELECT cuil FROM $table WHERE cuil IS NOT NULL AND cuil != '' GROUP BY cuil HAVING COUNT(*) > 1");
        foreach ($cuil_duplicados as $cuil) {
            $ids = $wpdb->get_col($wpdb->prepare("SELECT id FROM $table WHERE cuil = %s ORDER BY id ASC", $cuil));
            if (count($ids) > 1) { array_shift($ids); $wpdb->query("DELETE FROM $table WHERE id IN (" . implode(',', array_map('intval', $ids)) . ")"); }
        }

        $email_duplicados = $wpdb->get_col("SELECT email FROM $table WHERE email IS NOT NULL AND email != '' GROUP BY email HAVING COUNT(*) > 1");
        foreach ($email_duplicados as $email) {
            $ids = $wpdb->get_col($wpdb->prepare("SELECT id FROM $table WHERE email = %s ORDER BY id ASC", $email));
            if (count($ids) > 1) { array_shift($ids); $wpdb->query("DELETE FROM $table WHERE id IN (" . implode(',', array_map('intval', $ids)) . ")"); }
        }
    }

    // ===================== PÁGINAS =====================
    private static function crear_paginas_rrhh() {
        $paginas = [
            ['slug'=>'mi-perfil',          'titulo'=>'Mi Perfil',           'shortcode'=>'[midas_panel_empleado]',     'option'=>'midas_rrhh_pagina_mi_perfil_id'],
            ['slug'=>'mis-recibos',        'titulo'=>'Mis Recibos',         'shortcode'=>'[midas_panel_recibos]',      'option'=>'midas_rrhh_pagina_mis_recibos_id'],
            ['slug'=>'mis-licencias',      'titulo'=>'Mis Licencias',       'shortcode'=>'[midas_panel_licencias]',    'option'=>'midas_rrhh_pagina_mis_licencias_id'],
            ['slug'=>'mi-carpeta-medica',  'titulo'=>'Mi Carpeta Médica',   'shortcode'=>'[midas_panel_carpeta_medica]','option'=>'midas_rrhh_pagina_mi_carpeta_medica_id'],
            ['slug'=>'subir-recibo',       'titulo'=>'Subir Recibo',        'shortcode'=>'[midas_subir_recibo]',       'option'=>'midas_rrhh_pagina_subir_recibo_id'],
            ['slug'=>'solicitar-licencia', 'titulo'=>'Solicitar Licencia',  'shortcode'=>'[midas_solicitar_licencia]', 'option'=>'midas_rrhh_pagina_solicitar_licencia_id'],
            ['slug'=>'subir-documento-medico','titulo'=>'Subir Documento Médico','shortcode'=>'[midas_subir_documento_medico]','option'=>'midas_rrhh_pagina_subir_documento_medico_id'],
        ];

        foreach ($paginas as $p) {
            $pagina = get_page_by_path($p['slug']);
            if ($pagina) { update_option($p['option'], $pagina->ID); continue; }
            $pagina_id = wp_insert_post([
                'post_title'   => $p['titulo'],
                'post_name'    => $p['slug'],
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_content' => $p['shortcode'],
                'post_author'  => 1,
                'comment_status' => 'closed',
            ]);
            if ($pagina_id && !is_wp_error($pagina_id)) update_option($p['option'], $pagina_id);
        }
    }

    // ===================== ORGCHART HELPERS & AJAX =====================

    /** Árbol por defecto para organigrama. */
    private static function default_org_tree(): array {
        return [
            'id' => 'root',
            'name' => 'Empresa',
            'title' => 'Dirección General',
            'children' => [],
        ];
    }

    /** Sanitiza profundamente el árbol (id, name, title y children). */
    private static function sanitize_tree($node) {
        if (!is_array($node)) return null;
        $out = [
            'id'    => isset($node['id'])    ? sanitize_text_field((string)$node['id'])    : '',
            'name'  => isset($node['name'])  ? sanitize_text_field((string)$node['name'])  : '',
            'title' => isset($node['title']) ? sanitize_text_field((string)$node['title']) : '',
        ];
        $children = [];
        if (!empty($node['children']) && is_array($node['children'])) {
            foreach ($node['children'] as $ch) {
                $san = self::sanitize_tree($ch);
                if ($san) $children[] = $san;
            }
        }
        if ($children) $out['children'] = $children;
        return $out;
    }

    /** Valida estructura mínima del árbol. */
    private static function validate_tree($node): bool {
        if (!is_array($node)) return false;
        if (!isset($node['id']) || $node['id'] === '' || !isset($node['name'])) return false;
        if (isset($node['children'])) {
            if (!is_array($node['children'])) return false;
            foreach ($node['children'] as $ch) {
                if (!self::validate_tree($ch)) return false;
            }
        }
        return true;
    }

    /** GET: devuelve el árbol guardado. */
    public static function ajax_orgchart_get() {
        check_ajax_referer('midas_orgchart_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permisos insuficientes.'], 403);
        }
        $tree = get_option('midas_orgchart_tree', null);
        if (!is_array($tree)) $tree = self::default_org_tree();
        wp_send_json_success(['tree' => $tree]);
    }

    /** SAVE: guarda el árbol recibido. */
    public static function ajax_orgchart_save() {
        check_ajax_referer('midas_orgchart_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permisos insuficientes.'], 403);
        }
        $raw = isset($_POST['tree']) ? wp_unslash($_POST['tree']) : '';
        if ($raw === '') {
            wp_send_json_error(['message' => 'Falta el parámetro tree.'], 400);
        }
        $decoded = json_decode($raw, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            wp_send_json_error(['message' => 'JSON inválido.'], 400);
        }
        $san = self::sanitize_tree($decoded);
        if (!$san || !self::validate_tree($san)) {
            wp_send_json_error(['message' => 'Estructura de árbol no válida.'], 422);
        }

        update_option('midas_orgchart_tree', $san, false);
        wp_send_json_success(['message' => 'Guardado.']);
    }
}
