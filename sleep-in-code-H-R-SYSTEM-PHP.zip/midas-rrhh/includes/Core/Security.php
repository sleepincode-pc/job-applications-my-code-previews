<?php
namespace MidasRRHH\Core;

class Security {
    public function __construct() {
        // Inicializar hooks de seguridad si quieres activar prevent_direct_access global
        add_action('init', [$this, 'prevent_direct_access']);
    }

    /**
     * Evita el acceso directo a archivos del plugin.
     * Para protección más segura, se recomienda poner 
     * if (!defined('ABSPATH')) exit; al inicio de cada archivo PHP.
     */
    public function prevent_direct_access() {
        if (!defined('DOING_AJAX') && !defined('DOING_CRON') && !defined('WP_CLI')) {
            if (!defined('ABSPATH')) {
                wp_die(__('Acceso denegado', 'midas-rrhh'));
            }
        }
    }

    public function sanitize_dni($dni) {
        $dni = preg_replace('/[^0-9]/', '', $dni);
        return substr($dni, 0, 20); // Limitar longitud
    }

    public function sanitize_cuil($cuil) {
        $cuil = preg_replace('/[^0-9-]/', '', $cuil);
        return substr($cuil, 0, 20); // Limitar longitud
    }

    public function sanitize_date($date) {
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            return $date;
        }
        return '';
    }

    /**
     * Verifica nonce con logging en caso de error
     * @param string $nonce El valor nonce recibido
     * @param string $action La acción nonce esperada
     * @param string $context Descripción del contexto para loguear
     * @return bool
     */
    public function verify_nonce($nonce, $action, $context = '') {
        $valid = wp_verify_nonce($nonce, $action);
        if (!$valid) {
            error_log("[Security::verify_nonce] Nonce inválido en contexto: {$context}, acción: {$action}");
        }
        return $valid;
    }

    public function create_nonce($action) {
        return wp_create_nonce($action);
    }

    public function check_capability($capability) {
        return current_user_can($capability);
    }

    /**
     * Valida un archivo subido (tamaño, extensión, MIME)
     * @param array $file Arreglo $_FILES['...']
     * @param array $allowed_types Extensiones permitidas
     * @return true|\WP_Error
     */
    public function validate_file_upload($file, $allowed_types = ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx']) {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return new \WP_Error('upload_error', $this->get_upload_error_message($file['error']));
        }

        // Verificar tamaño máximo (5MB)
        $max_size = 5 * 1024 * 1024;
        if ($file['size'] > $max_size) {
            return new \WP_Error('file_too_large', __('El archivo es demasiado grande. Tamaño máximo permitido: 5MB', 'midas-rrhh'));
        }

        // Verificar extensión
        $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($file_ext, $allowed_types)) {
            return new \WP_Error('invalid_file_type', __('Tipo de archivo no permitido', 'midas-rrhh'));
        }

        // Verificar contenido real del archivo con finfo
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if (!$finfo) {
            return new \WP_Error('finfo_error', __('No se pudo validar el archivo por error interno', 'midas-rrhh'));
        }
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        $allowed_mimes = [
            'jpg'  => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png'  => 'image/png',
            'pdf'  => 'application/pdf',
            'doc'  => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        ];

        // Verificar que el MIME coincida con la extensión
        if (!isset($allowed_mimes[$file_ext]) || $mime !== $allowed_mimes[$file_ext]) {
            return new \WP_Error('invalid_mime_type', __('El tipo MIME del archivo no coincide con la extensión o no es válido', 'midas-rrhh'));
        }

        return true;
    }

    private function get_upload_error_message($error_code) {
        $errors = [
            UPLOAD_ERR_INI_SIZE   => __('El archivo excede el tamaño máximo permitido por el servidor', 'midas-rrhh'),
            UPLOAD_ERR_FORM_SIZE  => __('El archivo excede el tamaño máximo permitido por el formulario', 'midas-rrhh'),
            UPLOAD_ERR_PARTIAL    => __('El archivo fue subido parcialmente', 'midas-rrhh'),
            UPLOAD_ERR_NO_FILE    => __('No se subió ningún archivo', 'midas-rrhh'),
            UPLOAD_ERR_NO_TMP_DIR => __('Falta la carpeta temporal', 'midas-rrhh'),
            UPLOAD_ERR_CANT_WRITE => __('Error al escribir el archivo en el disco', 'midas-rrhh'),
            UPLOAD_ERR_EXTENSION  => __('Una extensión de PHP detuvo la subida del archivo', 'midas-rrhh')
        ];

        return $errors[$error_code] ?? __('Error desconocido al subir el archivo', 'midas-rrhh');
    }

    /**
     * Escapa la salida para prevenir XSS, soporta arrays recursivos
     */
    public function escape_output($output) {
        if (is_array($output)) {
            return array_map([$this, 'escape_output'], $output);
        } elseif (is_object($output)) {
            // Retorna objeto sin cambios o implementa lógica para objetos
            return $output;
        }
        return htmlspecialchars($output, ENT_QUOTES, 'UTF-8');
    }

    public function validate_email($email) {
        return sanitize_email($email);
    }

    /**
     * Loguea evento de seguridad, guarda último 100 eventos en opción WP
     * @param string $event Descripción del evento
     * @param array $details Datos adicionales
     */
    public function log_security_event($event, $details = []) {
        $log_entry = [
            'timestamp' => current_time('mysql'),
            'event'     => $event,
            'user_id'   => get_current_user_id(),
            'ip'        => $this->get_client_ip(),
            'details'   => $details
        ];

        $log = get_option('midas_rrhh_security_log', []);
        $log[] = $log_entry;

        // Mantener solo últimos 100 eventos
        if (count($log) > 100) {
            $log = array_slice($log, -100);
        }

        update_option('midas_rrhh_security_log', $log, false);
    }

    /**
     * Obtiene la IP real del cliente, tomando primera válida en caso de proxies
     * @return string IP válida o vacía
     */
    private function get_client_ip() {
        if (!empty($_SERVER['HTTP_CLIENT_IP']) && filter_var($_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP)) {
            return $_SERVER['HTTP_CLIENT_IP'];
        }

        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            foreach ($ips as $ip) {
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }

        if (!empty($_SERVER['REMOTE_ADDR']) && filter_var($_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP)) {
            return $_SERVER['REMOTE_ADDR'];
        }

        return '';
    }
}
