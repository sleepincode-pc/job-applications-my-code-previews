<?php
namespace MidasRRHH\Core;

use MidasRRHH\Models\Empleado_Model;
use MidasRRHH\Models\Licencia_Model;
use MidasRRHH\Models\Carpeta_Medica_Model;

if (!defined('ABSPATH')) exit;

class Notificaciones {
    public function __construct() {
        // Configurar el filtro de wp_mail para usar SMTP si está configurado
        add_action('phpmailer_init', [$this, 'configure_smtp']);
    }

    public function configure_smtp($phpmailer) {
        $smtp_settings = get_option('midas_rrhh_smtp_settings');
        if (!$smtp_settings) return;

        // Defaults para que nunca falte un campo
        $smtp_settings = array_merge([
            'host'        => '',
            'port'        => 587,
            'username'    => '',
            'password'    => '',
            'encryption'  => 'tls',
            'from_email'  => get_option('admin_email'),
            'from_name'   => get_bloginfo('name')
        ], $smtp_settings);

        if (!empty($smtp_settings['host'])) {
            $phpmailer->isSMTP();
            $phpmailer->Host       = $smtp_settings['host'];
            $phpmailer->SMTPAuth   = true;
            $phpmailer->Port       = $smtp_settings['port'];
            $phpmailer->Username   = $smtp_settings['username'];
            $phpmailer->Password   = $smtp_settings['password'];
            $phpmailer->SMTPSecure = $smtp_settings['encryption'];

            if (!empty($smtp_settings['from_email'])) {
                $phpmailer->From     = $smtp_settings['from_email'];
                $phpmailer->FromName = $smtp_settings['from_name'];
            }
        }
    }

    public function enviar_notificacion($to, $subject, $message, $headers = '', $attachments = []) {
        $smtp_settings = get_option('midas_rrhh_smtp_settings');
        $from_name  = $smtp_settings['from_name']  ?? get_bloginfo('name');
        $from_email = $smtp_settings['from_email'] ?? get_option('admin_email');

        $default_headers = [
            'Content-Type: text/plain; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>'
        ];
        $headers = array_merge($default_headers, (array)$headers);

        return wp_mail($to, $subject, $message, $headers, $attachments);
    }

    // ===== LICENCIAS =====
    public function enviar_notificacion_licencia_pendiente($licencia_id) {
        $licencia_model = new Licencia_Model();
        $empleado_model = new Empleado_Model();

        $licencia = $licencia_model->get($licencia_id);
        if (!$licencia) return false;

        $empleado = $empleado_model->get($licencia->empleado_id);
        if (!$empleado) return false;

        $gestores = $this->obtener_gestores_rrhh();
        if (empty($gestores)) return false;

        $subject = __('Nueva solicitud de licencia pendiente', 'midas-rrhh');
        $message = sprintf(
            __("Hay una nueva solicitud de licencia pendiente de revisión:\n\nEmpleado: %s %s\nTipo: %s\nPeríodo: %s a %s\nDías solicitados: %d\n\nPor favor, ingresa al sistema para revisarla.", 'midas-rrhh'),
            $empleado->nombre,
            $empleado->apellido,
            $this->traducir_tipo_licencia($licencia->tipo),
            date_i18n('d/m/Y', strtotime($licencia->fecha_inicio)),
            date_i18n('d/m/Y', strtotime($licencia->fecha_fin)),
            $licencia->dias_solicitados
        );
        $admin_url = admin_url('admin.php?page=midas-licencias');

        foreach ($gestores as $gestor) {
            $personalized_message = $message . "\n\n" . __('Accede al sistema:', 'midas-rrhh') . " " . $admin_url;
            $this->enviar_notificacion($gestor->user_email, $subject, $personalized_message);
        }
        return true;
    }

    public function enviar_notificacion_licencia_aprobada($licencia_id) {
        $licencia_model = new Licencia_Model();
        $empleado_model = new Empleado_Model();

        $licencia = $licencia_model->get($licencia_id);
        if (!$licencia) return false;

        $empleado = $empleado_model->get($licencia->empleado_id);
        if (!$empleado || !$empleado->user_id) return false;

        $user = get_user_by('id', $empleado->user_id);
        if (!$user) return false;

        $subject = __('Tu solicitud de licencia ha sido aprobada', 'midas-rrhh');
        $message = sprintf(
            __("Tu solicitud de licencia ha sido aprobada:\n\nTipo: %s\nPeríodo: %s a %s\nDías aprobados: %d\nObservaciones: %s\n\nSaludos cordiales,\nEl equipo de RRHH", 'midas-rrhh'),
            $this->traducir_tipo_licencia($licencia->tipo),
            date_i18n('d/m/Y', strtotime($licencia->fecha_inicio)),
            date_i18n('d/m/Y', strtotime($licencia->fecha_fin)),
            $licencia->dias_aprobados,
            $licencia->observaciones ?: __('Ninguna', 'midas-rrhh')
        );

        return $this->enviar_notificacion($user->user_email, $subject, $message);
    }

    public function enviar_notificacion_licencia_rechazada($licencia_id) {
        $licencia_model = new Licencia_Model();
        $empleado_model = new Empleado_Model();

        $licencia = $licencia_model->get($licencia_id);
        if (!$licencia) return false;

        $empleado = $empleado_model->get($licencia->empleado_id);
        if (!$empleado || !$empleado->user_id) return false;

        $user = get_user_by('id', $empleado->user_id);
        if (!$user) return false;

        $subject = __('Tu solicitud de licencia ha sido rechazada', 'midas-rrhh');
        $message = sprintf(
            __("Lamentamos informarte que tu solicitud de licencia ha sido rechazada:\n\nTipo: %s\nPeríodo: %s a %s\nMotivo: %s\n\nPor favor, contacta con RRHH si necesitas más información.\n\nSaludos cordiales,\nEl equipo de RRHH", 'midas-rrhh'),
            $this->traducir_tipo_licencia($licencia->tipo),
            date_i18n('d/m/Y', strtotime($licencia->fecha_inicio)),
            date_i18n('d/m/Y', strtotime($licencia->fecha_fin)),
            $licencia->observaciones ?: __('No especificado', 'midas-rrhh')
        );

        return $this->enviar_notificacion($user->user_email, $subject, $message);
    }

    // ===== DOCUMENTOS MÉDICOS =====
    public function enviar_notificacion_documento_medico_pendiente($documento_id) {
        $carpeta_model = new Carpeta_Medica_Model();
        $empleado_model = new Empleado_Model();

        $documento = $carpeta_model->get($documento_id);
        if (!$documento) return false;

        $empleado = $empleado_model->get($documento->empleado_id);
        if (!$empleado) return false;

        $gestores = $this->obtener_gestores_rrhh();
        if (empty($gestores)) return false;

        $subject = __('Nuevo documento médico pendiente de revisión', 'midas-rrhh');
        $message = sprintf(
            __("Hay un nuevo documento médico pendiente de revisión:\n\nEmpleado: %s %s\nTipo: %s\nFecha del documento: %s\nDías solicitados: %s\n\nPor favor, ingresa al sistema para revisarlo.", 'midas-rrhh'),
            $empleado->nombre,
            $empleado->apellido,
            $this->traducir_tipo_documento($documento->tipo_documento ?? $documento->tipo),
            date_i18n('d/m/Y', strtotime($documento->fecha_documento ?? $documento->fecha_emision)),
            $documento->dias_solicitados ?: __('No especificado', 'midas-rrhh')
        );
        $admin_url = admin_url('admin.php?page=midas-carpeta-medica');

        foreach ($gestores as $gestor) {
            $personalized_message = $message . "\n\n" . __('Accede al sistema:', 'midas-rrhh') . " " . $admin_url;
            $this->enviar_notificacion($gestor->user_email, $subject, $personalized_message);
        }
        return true;
    }

    public function enviar_notificacion_documento_medico_aprobado($documento_id) {
        $carpeta_model = new Carpeta_Medica_Model();
        $empleado_model = new Empleado_Model();

        $documento = $carpeta_model->get($documento_id);
        if (!$documento) return false;

        $empleado = $empleado_model->get($documento->empleado_id);
        if (!$empleado || !$empleado->user_id) return false;

        $user = get_user_by('id', $empleado->user_id);
        if (!$user) return false;

        $subject = __('Tu documento médico ha sido aprobado', 'midas-rrhh');
        $message = sprintf(
            __("Tu documento médico ha sido aprobado:\n\nTipo: %s\nFecha del documento: %s\nDías aprobados: %d\nObservaciones: %s\n\nSaludos cordiales,\nEl equipo de RRHH", 'midas-rrhh'),
            $this->traducir_tipo_documento($documento->tipo_documento ?? $documento->tipo),
            date_i18n('d/m/Y', strtotime($documento->fecha_documento ?? $documento->fecha_emision)),
            $documento->dias_aprobados,
            $documento->observaciones ?: __('Ninguna', 'midas-rrhh')
        );

        return $this->enviar_notificacion($user->user_email, $subject, $message);
    }

    public function enviar_notificacion_documento_medico_rechazado($documento_id) {
        $carpeta_model = new Carpeta_Medica_Model();
        $empleado_model = new Empleado_Model();

        $documento = $carpeta_model->get($documento_id);
        if (!$documento) return false;

        $empleado = $empleado_model->get($documento->empleado_id);
        if (!$empleado || !$empleado->user_id) return false;

        $user = get_user_by('id', $empleado->user_id);
        if (!$user) return false;

        $subject = __('Tu documento médico ha sido rechazado', 'midas-rrhh');
        $message = sprintf(
            __("Lamentamos informarte que tu documento médico ha sido rechazado:\n\nTipo: %s\nFecha del documento: %s\nMotivo: %s\n\nPor favor, contacta con RRHH si necesitas más información.\n\nSaludos cordiales,\nEl equipo de RRHH", 'midas-rrhh'),
            $this->traducir_tipo_documento($documento->tipo_documento ?? $documento->tipo),
            date_i18n('d/m/Y', strtotime($documento->fecha_documento ?? $documento->fecha_emision)),
            $documento->observaciones ?: __('No especificado', 'midas-rrhh')
        );

        return $this->enviar_notificacion($user->user_email, $subject, $message);
    }

    // ===== RECIBOS =====
    public function enviar_notificacion_nuevo_recibo($empleado_id, $periodo, $archivo_id) {
        $empleado_model = new Empleado_Model();
        $empleado = $empleado_model->get($empleado_id);
        if (!$empleado || !$empleado->user_id) return false;

        $user = get_user_by('id', $empleado->user_id);
        if (!$user) return false;

        $to = $user->user_email;
        $subject = __('Nuevo recibo de sueldo disponible', 'midas-rrhh');

        $periodo_obj = \DateTime::createFromFormat('Y-m-d', $periodo);
        $periodo_formateado = $periodo_obj ? $periodo_obj->format('F Y') : $periodo;

        $recibo_url = wp_get_attachment_url($archivo_id);
        $login_url = wp_login_url();

        $message = sprintf(
            __("Hola %s,\n\nTienes un nuevo recibo de sueldo correspondiente al período %s.\n\nPuedes descargarlo aquí:\n%s\n\nPara acceder al sistema, ingresa aquí: %s\n\nSaludos cordiales,\nEl equipo de RRHH", 'midas-rrhh'),
            $user->display_name,
            $periodo_formateado,
            $recibo_url,
            $login_url
        );

        return $this->enviar_notificacion($to, $subject, $message);
    }

    // ===== AUXILIARES =====
    private function obtener_gestores_rrhh() {
        $gestores = get_users([
            'role' => 'gestor_rrhh',
            'fields' => ['ID', 'user_email', 'display_name']
        ]);
        // Si no hay gestores, notificar a los administradores
        if (empty($gestores)) {
            $gestores = get_users([
                'role' => 'administrator',
                'fields' => ['ID', 'user_email', 'display_name']
            ]);
        }
        return $gestores;
    }

    private function traducir_tipo_licencia($tipo) {
        $traducciones = [
            'enfermedad' => __('Enfermedad', 'midas-rrhh'),
            'maternidad' => __('Maternidad', 'midas-rrhh'),
            'paternidad' => __('Paternidad', 'midas-rrhh'),
            'maternidad/paternidad' => __('Maternidad/Paternidad', 'midas-rrhh'),
            'vacaciones' => __('Vacaciones', 'midas-rrhh'),
            'duelo' => __('Duelo', 'midas-rrhh'),
            'particular' => __('Particular', 'midas-rrhh')
        ];
        return $traducciones[strtolower($tipo)] ?? $tipo;
    }

    private function traducir_tipo_documento($tipo) {
        $traducciones = [
            'receta' => __('Receta médica', 'midas-rrhh'),
            'certificado' => __('Certificado médico', 'midas-rrhh'),
            'estudio' => __('Estudio médico', 'midas-rrhh'),
            'otro' => __('Otro documento', 'midas-rrhh')
        ];
        return $traducciones[strtolower($tipo)] ?? $tipo;
    }
}
