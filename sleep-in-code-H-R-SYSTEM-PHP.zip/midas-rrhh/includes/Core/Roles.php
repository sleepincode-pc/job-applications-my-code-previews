<?php
namespace MidasRRHH\Core;

if (!defined('ABSPATH')) exit;

class Roles {
    public static function init() {
        // Ya no registramos roles nuevos.
        add_action('init', [__CLASS__, 'add_custom_roles']);
    }

    /**
     * No crea roles. Dejado intencionalmente vacío.
     */
    public static function add_custom_roles() {
        // Intencionalmente vacío: NO se crean roles personalizados.
    }

    /**
     * Elimina todos los roles personalizados RRHH conocidos
     * y, por seguridad, cualquier rol cuyo slug empiece con rrhh_.
     */
    public static function remove_custom_roles() {
        $roles_conocidos = [
            'rrhh_empleado','rrhh_supervisor','rrhh_lider_equipo','rrhh_gestor','rrhh_medico','rrhh_auditor',
            'rrhh_admin','rrhh_reclutador','rrhh_sindicato','rrhh_recepcion','rrhh_soporte_tecnico','rrhh_externo',
            'rrhh_jefe_area','rrhh_jefe_personal','rrhh_payroll','rrhh_capacitador','rrhh_bienestar','rrhh_legales',
            'rrhh_prensa','rrhh_seguridad','rrhh_relaciones_laborales','rrhh_archivo','rrhh_planificacion',
            'rrhh_invitado','rrhh_executive'
        ];

        foreach ($roles_conocidos as $r) {
            if (get_role($r)) {
                remove_role($r);
            }
        }

        // Extra: por si hubiera otros roles rrhh_* definidos en otra versión.
        global $wp_roles;
        if (isset($wp_roles) && is_object($wp_roles) && !empty($wp_roles->roles)) {
            foreach ($wp_roles->roles as $slug => $def) {
                if (strpos($slug, 'rrhh_') === 0) {
                    remove_role($slug);
                }
            }
        }
    }

    /**
     * Quita del rol 'administrator' todas las capacidades extra que
     * se habían añadido por este archivo en versiones anteriores.
     */
    public static function remove_admin_caps() {
        $admin = get_role('administrator');
        if (!$admin) return;

        $admin_caps = [
            'manage_rrhh', 'manage_options', 'edit_midas_empleados', 'edit_others_midas_empleados', 'delete_midas_empleados',
            'publish_midas_empleados', 'read_private_midas_empleados', 'edit_midas_recibos', 'edit_others_midas_recibos',
            'publish_midas_recibos', 'read_private_midas_recibos', 'edit_midas_licencias', 'edit_others_midas_licencias',
            'publish_midas_licencias', 'approve_midas_licencias', 'read_private_midas_licencias', 'edit_midas_carpeta_medica',
            'edit_others_midas_carpeta_medica', 'publish_midas_carpeta_medica', 'read_private_midas_carpeta_medica',
            'edit_midas_tareas', 'edit_midas_areas', 'export_midas_reports', 'edit_documents', 'manage_rrhh_postulaciones',
            'edit_postulaciones', 'read_postulaciones', 'read_sindicato_docs', 'digitalizar_rrhh_docs', 'cargar_nuevo_empleado',
            'leer_logs_rrhh', 'ver_reportes_uso', 'edit_contratos_rrhh', 'dar_alta_empleado', 'dar_baja_empleado',
            'gestionar_capacitaciones_rrhh', 'ver_listado_capacitaciones', 'gestionar_beneficios_rrhh', 'encuestas_rrhh',
            'ver_legajos_legales', 'gestionar_documentos_legales', 'publicar_anuncios_rrhh', 'ver_anuncios_rrhh',
            'reportar_incidentes_rrhh', 'ver_incidentes_rrhh', 'gestionar_conflictos_rrhh', 'ver_conflictos_rrhh',
            'ver_estadisticas_rrhh', 'ver_dashboard_rrhh', 'ver_reportes_ejecutivos_rrhh'
        ];

        foreach ($admin_caps as $cap) {
            $admin->remove_cap($cap);
        }
    }

    // ===== Métodos para Installer / Activador =====
    // Ahora create_roles() no hace nada (no se crean roles).
    public static function create_roles() {
        self::add_custom_roles();
    }

    // remove_roles() elimina roles personalizados y limpia las caps extra de admin.
    public static function remove_roles() {
        self::remove_custom_roles();
        self::remove_admin_caps();
    }
}
