<?php
// archivo: includes/class-autoloader.php

// Seguridad: evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

spl_autoload_register(function ($class) {
    // Namespace raíz del plugin
    $prefix = 'MidasRRHH\\';
    $base_dir = MIDAS_RRHH_PLUGIN_DIR . 'includes/';

    // Verifica si la clase pertenece a nuestro namespace
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    // Parte relativa de la clase (sin el namespace principal)
    $relative_class = substr($class, $len);

    // Convertir namespace a ruta de archivo respetando mayúsculas/minúsculas
    // Ejemplo: MidasRRHH\Controllers\Empleado_Controller => includes/Controllers/Empleado_Controller.php
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

    // Si el archivo existe, se carga
    if (file_exists($file)) {
        require_once $file;
        return;
    }

    // **Modo fallback en minúsculas** para servidores Linux
    // Ejemplo: includes/controllers/empleado_controller.php
    $lower_path = strtolower(str_replace('\\', '/', $relative_class));
    $fallback_file = $base_dir . $lower_path . '.php';

    if (file_exists($fallback_file)) {
        require_once $fallback_file;
        return;
    }

    // Log de error para debug
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log("Autoloader: Clase no encontrada '$class'. Archivos buscados: $file y $fallback_file");
    }
});
