<?php
namespace MidasRRHH\Frontend;

use MidasRRHH\Controllers\Empleado_Controller;
use MidasRRHH\Controllers\Recibo_Controller;
use MidasRRHH\Controllers\Licencia_Controller;
use MidasRRHH\Controllers\Carpeta_Medica_Controller;
use MidasRRHH\Controllers\Ticket_Controller;

class Frontend {
    public function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_shortcode('midas_panel_empleado', [$this, 'render_main_panel']);
        add_shortcode('midas_panel_gestor', [$this, 'render_panel_gestor']);
        add_shortcode('midas_panel_empleado_y_gestor', [$this, 'render_panel_empleado_y_gestor']);
        add_action('init', [$this, 'crear_pagina_rrhh_si_no_existe']);
        add_filter('wp_nav_menu_items', [$this, 'agregar_menu_rrhh_navbar'], 10, 2);

        // Ocultar el título “Recursos Humanos” si no hay perfil de empleado
        add_filter('the_title', [$this, 'ocultar_titulo_rrhh'], 10, 2);
        add_action('wp_head', [$this, 'ocultar_css_titulo_rrhh']);
    }

    public static function init() {
        return new self();
    }

    /* =========================
     * Helpers
     * ========================= */

    /** Obtiene el objeto empleado del usuario actual (o null si no existe) */
    private function get_current_empleado_full() {
        if (!is_user_logged_in()) return null;

        $current_user = wp_get_current_user();
        $empleado_controller = new Empleado_Controller();

        $empleado_data = $empleado_controller->get_by_user_id($current_user->ID);
        if (!$empleado_data || empty($empleado_data->id)) {
            return null;
        }

        $empleado = $empleado_controller->get_by_id_con_area_y_tarea($empleado_data->id);
        if (is_wp_error($empleado)) {
            return null;
        }
        return $empleado;
    }

    /* =========================
     * Assets
     * ========================= */
    public function enqueue_assets() {
        wp_enqueue_style(
            'midas-rrhh-frontend',
            MIDAS_RRHH_PLUGIN_URL . 'assets/css/frontend.css',
            [],
            MIDAS_RRHH_VERSION
        );
        wp_enqueue_script(
            'midas-rrhh-frontend',
            MIDAS_RRHH_PLUGIN_URL . 'assets/js/frontend.js',
            ['jquery', 'wp-util'],
            MIDAS_RRHH_VERSION,
            true
        );
        wp_localize_script('midas-rrhh-frontend', 'midas_rrhh', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonces' => [
                'licencias' => wp_create_nonce('midas_licencias_nonce'),
                'carpeta_medica' => wp_create_nonce('midas_carpeta_medica_nonce'),
            ],
            'i18n' => [
                'error' => __('Error', 'midas-rrhh'),
                'success' => __('Éxito', 'midas-rrhh'),
            ],
        ]);
        wp_enqueue_script('jquery-ui-datepicker');
        wp_enqueue_style('jquery-ui', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
    }

    /* =========================
     * Página RRHH
     * ========================= */
    public function crear_pagina_rrhh_si_no_existe() {
        if (get_option('midas_rrhh_pagina_rrhh_id')) return;

        $pagina_id = wp_insert_post([
            'post_title'   => 'Recursos Humanos',
            'post_name'    => 'recursos-humanos',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_content' => '[midas_panel_empleado_y_gestor]',
            'post_author'  => 1,
            'comment_status' => 'closed',
        ]);

        if ($pagina_id && !is_wp_error($pagina_id)) {
            update_option('midas_rrhh_pagina_rrhh_id', $pagina_id);
        }
    }

    /* =========================
     * Navbar
     * ========================= */
    public function agregar_menu_rrhh_navbar($items, $args) {
        $pagina_id = get_option('midas_rrhh_pagina_rrhh_id');
        if (!$pagina_id) return $items;

        $permalink = get_permalink($pagina_id);

        if (is_user_logged_in()) {
            $current_user = wp_get_current_user();
            $empleado_controller = new \MidasRRHH\Controllers\Empleado_Controller();
            $empleado = $empleado_controller->get_by_user_id($current_user->ID);

            // Mostrar “Recursos Humanos” SOLO si el usuario tiene perfil de empleado.
            // (TODOS los roles están habilitados si están asignados en un empleado creado)
            if ($empleado && !empty($empleado->id)) {
                $items .= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-recursos-humanos">
                    <a href="'.esc_url($permalink).'">'.__('Recursos Humanos', 'midas-rrhh').'</a>
                </li>';
            }
        }

        return $items;
    }

    /* =========================
     * Ocultar título si no hay perfil
     * ========================= */
    public function ocultar_titulo_rrhh($title, $post_id) {
        $pagina_id = (int) get_option('midas_rrhh_pagina_rrhh_id');
        if (!$pagina_id) return $title;

        if ((int)$post_id !== $pagina_id) return $title;
        if (is_admin()) return $title;
        if (!in_the_loop() || !is_main_query()) return $title;

        $empleado = $this->get_current_empleado_full();
        if (!$empleado) {
            return '';
        }
        return $title;
    }

    public function ocultar_css_titulo_rrhh() {
        if (is_admin()) return;

        $pagina_id = (int) get_option('midas_rrhh_pagina_rrhh_id');
        if (!$pagina_id) return;

        if (!function_exists('is_page') || !is_page($pagina_id)) return;

        $empleado = $this->get_current_empleado_full();
        if ($empleado) return;

        echo '<style id="midas-rrhh-hide-title">.page-id-' . esc_attr($pagina_id) . ' .entry-title, .page-id-' . esc_attr($pagina_id) . ' h1.entry-title, .page-id-' . esc_attr($pagina_id) . ' header .entry-title {display:none!important; visibility:hidden!important;}</style>';
    }

    /* =========================
     * Panel Empleado (todos los roles con perfil)
     * ========================= */
    public function render_main_panel() {
        if (!is_user_logged_in()) {
            return __('Debes iniciar sesión para acceder a esta página', 'midas-rrhh');
        }

        // Cualquier rol puede acceder si tiene perfil de empleado
        $empleado = $this->get_current_empleado_full();
        if (!$empleado) {
            return '';
        }

        $panel = isset($_GET['panel_empleado']) ? sanitize_text_field($_GET['panel_empleado']) : 'mi-perfil';

        $licencia_controller = new Licencia_Controller();
        $carpeta_controller  = new Carpeta_Medica_Controller();
        $ticket_controller   = class_exists('MidasRRHH\Controllers\Ticket_Controller') ? new Ticket_Controller() : null;

        ob_start();
        ?>
        <div class="midas-rrhh-layout">
            <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/sidebar-menu-empleado.php'; ?>
            <main class="midas-rrhh-main-content">
                <?php
                switch ($panel) {
                    case 'mi-perfil':
                        ?>
                        <div class="midas-panel-empleado">
                            <header class="midas-panel-header">
                                <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/empleado-header.php'; ?>
                            </header>
                            <section class="midas-panel-section">
                                <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/panel-datos.php'; ?>
                            </section>
                        </div>
                        <?php
                        break;

                    case 'solicitar-licencia':
                        ?>
                        <div class="midas-panel-solicitar-licencia">
                            <header class="midas-panel-header">
                                <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/solicitar-licencia-header.php'; ?>
                            </header>
                            <section class="midas-panel-section">
                                <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/panel-solicitar-licencia.php'; ?>
                            </section>
                        </div>
                        <?php
                        break;

                    case 'mi-carpeta-medica':
                        $documentos = $carpeta_controller->obtener_documentos_empleado($empleado->id);
                        if (is_wp_error($documentos)) $documentos = [];
                        ?>
                        <div class="midas-panel-carpeta-medica">
                            <header class="midas-panel-header">
                                <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/carpeta-medica-header.php'; ?>
                            </header>
                            <section class="midas-panel-section">
                                <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/panel-subir-documento-medico.php'; ?>
                            </section>
                        </div>
                        <?php
                        break;

                    case 'ver-tickets':
                        $tickets = $ticket_controller ? $ticket_controller->obtener_tickets_empleado($empleado->id) : [];
                        ?>
                        <div class="midas-panel-tickets">
                            <header class="midas-panel-header">
                                <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/tickets-header.php'; ?>
                            </header>
                            <section class="midas-panel-section">
                                <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/panel-crear-ticket.php'; ?>
                            </section>
                        </div>
                        <?php
                        break;

                    default:
                        ?>
                        <div class="midas-panel-empleado">
                            <section class="midas-panel-section">
                                <div style="padding:40px;"><?php _e('Panel desconocido.', 'midas-rrhh'); ?></div>
                            </section>
                        </div>
                        <?php
                }
                ?>
            </main>
        </div>
        <?php
        return ob_get_clean();
    }

    /* =========================
     * Panel Gestor (todos los roles con perfil)
     * ========================= */
    public function render_panel_gestor() {
        if (!is_user_logged_in()) {
            return __('Debes iniciar sesión para acceder a esta página', 'midas-rrhh');
        }

        // Debe existir perfil de empleado
        $empleado = $this->get_current_empleado_full();
        if (!$empleado) {
            return '';
        }

        // IMPORTANTE: Se eliminó la verificación de capacidades.
        // Cualquier rol con perfil de empleado puede ver este panel en el front.
        // (Ten en cuenta que las acciones backend pueden seguir verificando permisos)

        $panel = isset($_GET['panel_gestor']) ? sanitize_text_field($_GET['panel_gestor']) : 'gestionar-licencias';

        $empleado_controller = new Empleado_Controller();
        $licencia_controller = new Licencia_Controller();
        $carpeta_controller  = new Carpeta_Medica_Controller();

        ob_start();
        ?>
        <div class="midas-rrhh-layout">
            <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/sidebar-menu-gestor.php'; ?>
            <main class="midas-rrhh-main-content">
                <?php
                switch ($panel) {
                    case 'gestionar-recibos':
                        ?>
                        <div class="midas-panel-recibos">
                            <header class="midas-panel-header">
                                <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/recibos-header.php'; ?>
                            </header>
                            <section class="midas-panel-section">
                                <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/panel-ver-recibos.php'; ?>
                            </section>
                        </div>
                        <?php
                        break;

                    case 'gestionar-licencias':
                        ?>
                        <div class="midas-panel-licencias">
                            <header class="midas-panel-header">
                                <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/licencias-header.php'; ?>
                            </header>
                            <section class="midas-panel-section">
                                <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/panel-licencias.php'; ?>
                            </section>
                        </div>
                        <?php
                        break;

                    case 'gestionar-carpeta-medica':
                        ?>
                        <div class="midas-panel-carpeta-medica">
                            <header class="midas-panel-header">
                                <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/gestor-carpeta-medica-header.php'; ?>
                            </header>
                            <section class="midas-panel-section">
                                <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/panel-gestor-carpeta-medica.php'; ?>
                            </section>
                        </div>
                        <?php
                        break;

                    case 'gestionar-tickets':
                        ?>
                        <div class="midas-panel-tickets">
                            <header class="midas-panel-header">
                                <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/tickets-header.php'; ?>
                            </header>
                            <section class="midas-panel-section">
                                <?php include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/panel-ver-tickets.php'; ?>
                            </section>
                        </div>
                        <?php
                        break;

                    default:
                        ?>
                        <div class="midas-panel-gestor">
                            <section class="midas-panel-section">
                                <div style="padding:40px;"><?php _e('Seleccione una sección de gestión en el menú.', 'midas-rrhh'); ?></div>
                            </section>
                        </div>
                        <?php
                }
                ?>
            </main>
        </div>
        <?php
        return ob_get_clean();
    }

    /* =========================
     * Panel combinado
     * ========================= */
    public function render_panel_empleado_y_gestor() {
        if (!is_user_logged_in()) {
            return __('Debes iniciar sesión para acceder a esta página', 'midas-rrhh');
        }

        // Debe existir perfil de empleado para renderizar algo
        $empleado = $this->get_current_empleado_full();
        if (!$empleado) {
            return '';
        }

        // Renderizamos ambos (el gestor ya no requiere capacidades en el front)
        $main_panel   = $this->render_main_panel();
        $gestor_panel = $this->render_panel_gestor();

        return '
        <div class="midas-rrhh-layout-doble">
            <div class="midas-panel-empleado-completo">' . $main_panel . '</div>
            <div class="midas-panel-gestor-completo" style="margin-top:32px;">' . $gestor_panel . '</div>
        </div>';
    }
}
