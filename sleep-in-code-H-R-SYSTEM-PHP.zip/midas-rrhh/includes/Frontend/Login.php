<?php
namespace MidasRRHH\Frontend;

class Login {
    public static function render_login_form() {
        if (is_user_logged_in()) {
            $current_user = wp_get_current_user();
            
            if (in_array('empleado', $current_user->roles)) {
                return do_shortcode('[midas_panel_empleado]');
            } elseif (in_array('gestor_rrhh', $current_user->roles) || in_array('administrator', $current_user->roles)) {
                return do_shortcode('[midas_panel_gestor]');
            }
            
            return __('Ya has iniciado sesión, pero no tienes un rol válido para este sistema', 'midas-rrhh');
        }

        // Manejar errores de login
        $errors = [];
        if (isset($_GET['login']) && $_GET['login'] === 'failed') {
            $errors[] = __('Usuario o contraseña incorrectos', 'midas-rrhh');
        } elseif (isset($_GET['login']) && $_GET['login'] === 'empty') {
            $errors[] = __('Por favor, completa todos los campos', 'midas-rrhh');
        }

        // Redirección después del login
        $redirect_to = '';
        if (isset($_GET['redirect_to'])) {
            $redirect_to = esc_url($_GET['redirect_to']);
        } else {
            // Redirigir a la página actual después del login
            $redirect_to = esc_url(home_url($_SERVER['REQUEST_URI']));
        }

        ob_start();
        include MIDAS_RRHH_PLUGIN_DIR . 'templates/frontend/login-form.php';
        return ob_get_clean();
    }
}