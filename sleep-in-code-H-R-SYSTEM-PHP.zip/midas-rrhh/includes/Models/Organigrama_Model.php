<?php
namespace MidasRRHH\Models;

if (!defined('ABSPATH')) exit;

/*──────────────────────────────────────────────────────────────────────────────
  MIDAS RRHH — ORGANIGRAMA: Modelo
  Cambios clave:
  - Compatibilidad con opción LEGACY 'midas_orgchart_tree' (fallback de handlers).
  - Lee tanto JSON (string) como array (versiones previas) y migra a JSON.
  - Sanitiza 'name' y 'title' recursivamente antes de guardar.
  - Valida y limita el tamaño máximo guardado (MAX_BYTES).
──────────────────────────────────────────────────────────────────────────────*/

class Organigrama_Model {
    /** Opción "oficial" donde se guarda el árbol (JSON) */
    const OPTION = 'midas_rrhh_orgchart';

    /** Opción de compatibilidad usada por el fallback de handlers anteriores */
    const LEGACY_OPTION = 'midas_orgchart_tree';

    /** Límite de tamaño en bytes del JSON almacenado */
    const MAX_BYTES = 500000; // ~500KB por seguridad

    /**
     * Devuelve el árbol actual. Tolera:
     *  - JSON en OPTION
     *  - array o JSON en LEGACY_OPTION
     * Realiza migración a OPTION si encuentra el árbol en la opción legacy.
     */
    public function get_tree(): array {
        $tree = $this->read_option_flexible(self::OPTION);

        // Si no hay árbol válido en la opción principal, intentamos legacy y migramos
        if (!is_array($tree) || !$this->validate_tree($tree)) {
            $legacy = $this->read_option_flexible(self::LEGACY_OPTION);
            if (is_array($legacy) && $this->validate_tree($legacy)) {
                // Migra a la opción oficial como JSON
                $this->save_tree($legacy);
                delete_option(self::LEGACY_OPTION);
                $tree = $legacy;
            } else {
                $tree = $this->default_tree();
            }
        }

        return $tree;
    }

    /**
     * Guarda el árbol (JSON en OPTION), con sanitizado y validación.
     * Borra la opción legacy si existe.
     */
    public function save_tree(array $tree): bool {
        $sanitized = $this->sanitize_tree($tree);
        if (!$this->validate_tree($sanitized)) return false;

        $json = wp_json_encode($sanitized);
        if (!$json || strlen($json) > self::MAX_BYTES) return false;

        $ok = update_option(self::OPTION, $json, false);

        // Limpieza de compatibilidad: si existiera la opción legacy, eliminarla
        if (get_option(self::LEGACY_OPTION, null) !== null) {
            delete_option(self::LEGACY_OPTION);
        }

        return (bool) $ok;
    }

    /** Árbol por defecto mínimo */
    public function default_tree(): array {
        return [
            'id' => 'root',
            'name' => 'Empresa',
            'title' => 'Dirección General',
            'children' => []
        ];
    }

    /**
     * Validación mínima recursiva de estructura
     * Requisitos:
     *  - id: string no vacío
     *  - name: string no vacío
     *  - title: (opcional) string
     *  - children: (opcional) array de nodos válidos
     */
    public function validate_tree($node): bool {
        if (!is_array($node)) return false;

        if (empty($node['id']) || !is_string($node['id'])) return false;
        if (empty($node['name']) || !is_string($node['name'])) return false;
        if (isset($node['title']) && !is_string($node['title'])) return false;

        if (isset($node['children'])) {
            if (!is_array($node['children'])) return false;
            foreach ($node['children'] as $child) {
                if (!$this->validate_tree($child)) return false;
            }
        }

        return true;
    }

    /* ===================== Helpers internos ===================== */

    /**
     * Lee una opción que podría estar guardada como:
     *  - string JSON (formato esperado)
     *  - array (versiones antiguas o guardado por fallbacks)
     * Devuelve array válido o null.
     */
    private function read_option_flexible(string $option_name) {
        $raw = get_option($option_name, null);

        if (is_array($raw)) {
            // Guardado antiguo como array
            return $raw;
        }

        if (is_string($raw) && $raw !== '') {
            $decoded = json_decode($raw, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                return $decoded;
            }
        }

        return null;
    }

    /**
     * Sanitiza recursivamente 'name' y 'title'. Asegura 'children' array.
     * No fuerza un formato específico de 'id' para no romper integraciones;
     * si faltara, genera uno.
     */
    private function sanitize_tree($node): array {
        if (!is_array($node)) {
            return $this->default_tree();
        }

        $out = [
            'id'   => isset($node['id']) && is_scalar($node['id'])
                        ? (string) $node['id']
                        : 'node_' . wp_generate_uuid4(),
            'name' => isset($node['name']) ? sanitize_text_field((string) $node['name']) : '',
        ];

        if (isset($node['title'])) {
            $out['title'] = sanitize_text_field((string) $node['title']);
        }

        $out['children'] = [];
        if (!empty($node['children']) && is_array($node['children'])) {
            foreach ($node['children'] as $child) {
                $out['children'][] = $this->sanitize_tree($child);
            }
        }

        return $out;
    }
}
