<?php
namespace MidasRRHH\Models;

if (!defined('ABSPATH')) exit;

class Ticket_Model {
    private $table;

    public function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'midas_tickets';
    }

    /** Limpieza mínima: sin etiquetas ni bytes de control, preserva espacios y signos */
    private static function clean_plain($s) {
        $s = (string)($s ?? '');
        // quita etiquetas
        $s = wp_strip_all_tags($s, true);
        // quita bytes de control (deja \r\n por si vienen del controller)
        $s = preg_replace('/[\x00-\x09\x0B\x0C\x0E-\x1F\x7F]/u', '', $s);
        return $s;
    }

    /**
     * crear($user_id, $asunto, $mensaje)
     * crear($user_id, $asunto, $mensaje, $estado)
    *  crear($user_id, $asunto, $mensaje, $estado, $destinatario_id)
     */
    public function crear($user_id, $asunto, $mensaje, $estado = 'pendiente', $destinatario_id = 0) {
        global $wpdb;

        $allowed = ['pendiente','enviado','respondido','rechazado'];
        $estado  = strtolower((string)$estado);
        if (!in_array($estado, $allowed, true)) $estado = 'pendiente';

        $user_id         = (int) $user_id;
        $destinatario_id = (int) $destinatario_id;

        // no uses sanitize_text_field / wp_kses_post: preservamos espacios y signos
        $asunto  = self::clean_plain($asunto);
        $mensaje = self::clean_plain($mensaje);

        $data = [
            'user_id'        => $user_id,
            'asunto'         => $asunto,
            'mensaje'        => $mensaje,
            'estado'         => $estado,
            'fecha_creacion' => current_time('mysql'),
            'visto'          => 0,
        ];
        $formats = ['%d','%s','%s','%s','%s','%d'];

        if ($destinatario_id > 0) {
            $data['destinatario_id'] = $destinatario_id;
            $formats[] = '%d';
        }

        $res = $wpdb->insert($this->table, $data, $formats);
        if ($res === false) {
            error_log('[Ticket_Model::crear] DB error: ' . $wpdb->last_error);
            return false;
        }
        return (int) $wpdb->insert_id;
    }

    public function get($ticket_id, $current_user_id = null) {
        global $wpdb;
        $sql = "SELECT * FROM {$this->table} WHERE id = %d";
        $params = [(int) $ticket_id];
        if ($current_user_id !== null) {
            $sql .= " AND user_id = %d";
            $params[] = (int) $current_user_id;
        }
        return $wpdb->get_row($wpdb->prepare($sql, ...$params));
    }

    public function get_by_user($user_id) {
        global $wpdb;
        $user_id = (int) $user_id;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table}
             WHERE user_id = %d OR (destinatario_id IS NOT NULL AND destinatario_id = %d)
             ORDER BY fecha_creacion DESC",
            $user_id, $user_id
        ));
    }

    public function get_pendientes($limite = null) {
        global $wpdb;
        if ($limite !== null) {
            $limite = (int) $limite;
            return $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$this->table} WHERE estado = 'pendiente' ORDER BY fecha_creacion DESC LIMIT %d",
                $limite
            ));
        }
        return $wpdb->get_results("SELECT * FROM {$this->table} WHERE estado = 'pendiente' ORDER BY fecha_creacion DESC");
    }

    public function get_all($estado = null) {
        global $wpdb;
        if ($estado !== null && $estado !== '') {
            return $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$this->table} WHERE estado = %s ORDER BY fecha_creacion DESC",
                $estado
            ));
        }
        return $wpdb->get_results("SELECT * FROM {$this->table} ORDER BY fecha_creacion DESC");
    }

    public function responder($ticket_id, $respuesta, $admin_id, $admin_nombre, $fecha_respuesta) {
        global $wpdb;
        $data = [
            'estado'          => 'respondido',
            'respuesta'       => self::clean_plain($respuesta),
            'admin_id'        => (int) $admin_id,
            'admin_nombre'    => sanitize_text_field($admin_nombre),
            'fecha_respuesta' => $fecha_respuesta,
        ];
        $where   = [ 'id' => (int) $ticket_id ];
        $formats = ['%s','%s','%d','%s','%s'];
        $where_f = ['%d'];

        $res = $wpdb->update($this->table, $data, $where, $formats, $where_f);

        if ($res === false) {
            error_log('[Ticket_Model::responder] DB error: ' . $wpdb->last_error);
        }
        // éxito real sólo si afectó filas
        return ($res !== false && $res > 0);
    }

    public function rechazar($ticket_id, $motivo, $admin_id, $admin_nombre, $fecha_respuesta) {
        global $wpdb;
        $data = [
            'estado'          => 'rechazado',
            'motivo_rechazo'  => self::clean_plain($motivo),
            'admin_id'        => (int) $admin_id,
            'admin_nombre'    => sanitize_text_field($admin_nombre),
            'fecha_respuesta' => $fecha_respuesta,
        ];
        $where   = [ 'id' => (int) $ticket_id ];
        $formats = ['%s','%s','%d','%s','%s'];
        $where_f = ['%d'];

        $res = $wpdb->update($this->table, $data, $where, $formats, $where_f);

        if ($res === false) {
            error_log('[Ticket_Model::rechazar] DB error: ' . $wpdb->last_error);
        }
        // éxito real sólo si afectó filas
        return ($res !== false && $res > 0);
    }

    public function eliminar($ticket_id, $user_id = null) {
        global $wpdb;
        $where   = [ 'id' => (int) $ticket_id ];
        $where_f = ['%d'];
        if ($user_id) {
            $where['user_id'] = (int) $user_id;
            $where_f[] = '%d';
        }
        return $wpdb->delete($this->table, $where, $where_f);
    }
}
