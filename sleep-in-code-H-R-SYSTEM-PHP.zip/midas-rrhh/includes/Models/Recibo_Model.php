<?php
namespace MidasRRHH\Models;

if (!defined('ABSPATH')) exit;

class Recibo_Model extends Base_Model {
    protected $table = 'midas_recibos';
    protected $primary_key = 'id';
    protected $allowed_fields = [
        'empleado_id', 'periodo', 'archivo_id', 'monto', 'detalles'
    ];

    public function __construct() {
        if (method_exists(get_parent_class($this), '__construct')) {
            parent::__construct();
        }
        global $wpdb;
        $this->wpdb = $wpdb;
    }

    // Obtener un recibo por ID
    public function get($id) {
        return $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->wpdb->prefix}{$this->table} WHERE {$this->primary_key} = %d",
                $id
            )
        );
    }

    // Insertar un nuevo recibo
    public function insert($data) {
        $data = array_intersect_key($data, array_flip($this->allowed_fields));
        $result = $this->wpdb->insert(
            $this->wpdb->prefix . $this->table,
            $data
        );
        if ($result === false) {
            return false;
        }
        return $this->wpdb->insert_id;
    }

    // Actualizar un recibo existente
    public function update($id, $data) {
        $data = array_intersect_key($data, array_flip($this->allowed_fields));
        return $this->wpdb->update(
            $this->wpdb->prefix . $this->table,
            $data,
            [$this->primary_key => $id]
        );
    }

    // Eliminar un recibo por ID
    public function delete($id) {
        return $this->wpdb->delete(
            $this->wpdb->prefix . $this->table,
            [$this->primary_key => $id]
        );
    }

    // Obtener todos los recibos
    public function get_all() {
        return $this->wpdb->get_results(
            "SELECT * FROM {$this->wpdb->prefix}{$this->table} ORDER BY periodo DESC"
        );
    }

    // Obtener recibos por ID de empleado
    public function get_by_empleado($empleado_id) {
        return $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->wpdb->prefix}{$this->table} 
                WHERE empleado_id = %d 
                ORDER BY periodo DESC",
                $empleado_id
            )
        );
    }

    // Obtener recibos por período
    public function get_by_periodo($periodo) {
        return $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->wpdb->prefix}{$this->table} 
                WHERE periodo = %s 
                ORDER BY empleado_id",
                $periodo
            )
        );
    }

    // Buscar recibos filtrando por nombre, apellido, DNI o CUIL del empleado
    public function buscar_por_empleado_info($termino) {
        $like = '%' . $this->wpdb->esc_like($termino) . '%';

        $query = $this->wpdb->prepare("
            SELECT r.*, e.nombre, e.apellido, e.dni, e.cuil 
            FROM {$this->wpdb->prefix}midas_recibos AS r
            INNER JOIN {$this->wpdb->prefix}midas_empleados AS e
                ON r.empleado_id = e.id
            WHERE 
                e.nombre LIKE %s OR
                e.apellido LIKE %s OR
                e.dni LIKE %s OR
                e.cuil LIKE %s
            ORDER BY r.periodo DESC
        ", $like, $like, $like, $like);

        return $this->wpdb->get_results($query);
    }

    // Obtener todos los recibos con datos del empleado
    public function get_all_with_empleado_data() {
        return $this->wpdb->get_results("
            SELECT r.*, e.nombre, e.apellido, e.dni, e.cuil 
            FROM {$this->wpdb->prefix}midas_recibos AS r
            INNER JOIN {$this->wpdb->prefix}midas_empleados AS e
                ON r.empleado_id = e.id
            ORDER BY r.periodo DESC
        ");
    }
}
