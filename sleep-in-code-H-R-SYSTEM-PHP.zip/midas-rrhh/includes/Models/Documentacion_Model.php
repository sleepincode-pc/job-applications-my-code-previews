<?php
namespace MidasRRHH\Models;

if (!defined('ABSPATH')) exit;

class Documentacion_Model {
    private $wpdb, $table_docs, $table_tipos, $table_empleados;

    // Flags de compatibilidad (columnas opcionales)
    private $docs_has_created_by = false;
    private $docs_has_updated_by = false;
    private $tipos_has_created_by = false;
    private $tipos_has_updated_by = false;
    private $tipos_has_updated_at = false;

    public function __construct() {
        global $wpdb;
        $this->wpdb            = $wpdb;
        $this->table_docs      = $wpdb->prefix . 'midas_documentaciones';
        $this->table_tipos     = $wpdb->prefix . 'midas_doc_tipos';
        $this->table_empleados = $wpdb->prefix . 'midas_empleados';

        // Detectar columnas (por si la instalación es antigua)
        $cols_docs  = (array) $this->wpdb->get_col("SHOW COLUMNS FROM `{$this->table_docs}`", 0);
        $cols_tipos = (array) $this->wpdb->get_col("SHOW COLUMNS FROM `{$this->table_tipos}`", 0);

        $this->docs_has_created_by = in_array('created_by', $cols_docs, true);
        $this->docs_has_updated_by = in_array('updated_by', $cols_docs, true);

        $this->tipos_has_created_by = in_array('created_by', $cols_tipos, true);
        $this->tipos_has_updated_by = in_array('updated_by', $cols_tipos, true);
        $this->tipos_has_updated_at = in_array('updated_at', $cols_tipos, true);
    }

    /* ========================= TIPOS ========================= */

    public function crear_tipo(string $descripcion, ?int $plazo_numero, ?string $plazo_unidad, ?int $user_id = 0) {
        $u   = self::norm_unidad($plazo_unidad);
        $num = ($plazo_numero && $plazo_numero > 0) ? (int)$plazo_numero : null;
        if (!$num || !$u) { $num = null; $u = null; }

        $now = current_time('mysql', true);
        $uid = (int) ($user_id ?: 0);

        $data = [
            'descripcion'  => sanitize_text_field($descripcion),
            'plazo_numero' => $num, // NULL real si es null (omitido en insert_dynamic)
            'plazo_unidad' => $u,   // NULL real si es null (omitido en insert_dynamic)
            'created_at'   => $now,
        ];

        // Auditoría si existen las columnas
        if ($this->tipos_has_updated_at) $data['updated_at'] = $now;
        if ($uid > 0 && $this->tipos_has_created_by) $data['created_by'] = $uid;
        if ($uid > 0 && $this->tipos_has_updated_by) $data['updated_by'] = $uid;

        return $this->insert_dynamic($this->table_tipos, $data);
    }

    public function editar_tipo(int $id, string $descripcion, ?int $plazo_numero, ?string $plazo_unidad, ?int $user_id = 0) {
        $u   = self::norm_unidad($plazo_unidad);
        $num = ($plazo_numero && $plazo_numero > 0) ? (int)$plazo_numero : null;
        if (!$num || !$u) { $num = null; $u = null; }

        $data = [
            'descripcion'  => sanitize_text_field($descripcion),
            'plazo_numero' => $num, // si es null => SET NULL
            'plazo_unidad' => $u,   // si es null => SET NULL
        ];

        if ($this->tipos_has_updated_at) $data['updated_at'] = current_time('mysql', true);
        $uid = (int) ($user_id ?: 0);
        if ($uid > 0 && $this->tipos_has_updated_by) $data['updated_by'] = $uid;

        return $this->update_with_nulls($this->table_tipos, $data, ['id' => $id]);
    }

    public function eliminar_tipo(int $id) {
        return $this->wpdb->delete($this->table_tipos, ['id' => $id], ['%d']) !== false;
    }

    public function obtener_tipo(int $id) {
        return $this->wpdb->get_row($this->wpdb->prepare("SELECT * FROM {$this->table_tipos} WHERE id=%d", $id));
    }

    public function listar_tipos(string $q = '', int $paged = 1, int $per_page = 10) {
        $cols   = (array) $this->wpdb->get_col("SHOW COLUMNS FROM `{$this->table_tipos}`", 0);
        $c_desc = in_array('descripcion', $cols, true) ? 'descripcion' : (in_array('nombre', $cols, true) ? 'nombre' : 'descripcion');

        $where  = 'WHERE 1=1';
        $params = [];

        if ($q !== '') {
            $where   .= " AND {$c_desc} LIKE %s";
            $params[] = '%' . $this->wpdb->esc_like($q) . '%';
        }

        if ($params) {
            $total = (int) $this->wpdb->get_var($this->wpdb->prepare("SELECT COUNT(*) FROM {$this->table_tipos} $where", ...$params));
        } else {
            $total = (int) $this->wpdb->get_var("SELECT COUNT(*) FROM {$this->table_tipos} $where");
        }

        $offset = max(0, ($paged - 1) * $per_page);

        $sql  = "SELECT * FROM {$this->table_tipos} $where ORDER BY id DESC LIMIT %d OFFSET %d";
        $rows = $this->wpdb->get_results($this->wpdb->prepare($sql, ...array_merge($params, [$per_page, $offset])));

        return ['items' => $rows, 'total' => $total, 'paged' => $paged, 'per_page' => $per_page];
    }

    /* ======================= DOCUMENTOS ======================= */

    public function crear_doc(
        int $empleado_id,
        ?int $tipo_id,
        string $descripcion,
        string $fecha_inicio,
        ?string $fecha_fin,
        ?int $archivo_id,
        ?int $user_id = 0
    ) {
        $empleado_id  = (int) $empleado_id;
        $tipo_id      = ($tipo_id && $tipo_id > 0) ? (int)$tipo_id : null;
        $descripcion  = wp_kses_post($descripcion);
        $fecha_inicio = self::safe_date($fecha_inicio);
        $fecha_fin    = $fecha_fin ? self::safe_date($fecha_fin) : null;

        // Si no mandan fecha_fin, calcular desde tipo (si aplica)
        if (!$fecha_fin && $tipo_id) {
            $t = $this->obtener_tipo($tipo_id);
            if ($t) {
                $fecha_fin = self::calc_fecha_fin($fecha_inicio, (int)$t->plazo_numero, (string)$t->plazo_unidad);
            }
        }

        $now = current_time('mysql', true);
        $uid = (int) ($user_id ?: 0);

        $data = [
            'empleado_id'  => $empleado_id,
            'tipo_id'      => $tipo_id, // null => omitido (queda NULL real)
            'descripcion'  => $descripcion,
            'fecha_inicio' => $fecha_inicio,
            'fecha_fin'    => $fecha_fin, // null => omitido (queda NULL real)
            'archivo_id'   => ($archivo_id && $archivo_id > 0) ? (int)$archivo_id : null, // null => omitido
            'borrado'      => 0,
            'created_at'   => $now,
            'updated_at'   => $now,
        ];

        // Auditoría si existen columnas
        if ($uid > 0 && $this->docs_has_created_by) $data['created_by'] = $uid;
        if ($uid > 0 && $this->docs_has_updated_by) $data['updated_by'] = $uid;

        $id = $this->insert_dynamic($this->table_docs, $data);
        return $id ?: false;
    }

    public function editar_doc(int $id, array $patch, ?int $user_id = 0) {
        $id = (int) $id;

        // Leer fila actual para defaults y recálculo
        $actual = $this->wpdb->get_row($this->wpdb->prepare("SELECT * FROM {$this->table_docs} WHERE id=%d", $id));
        if (!$actual) return false;

        $data = [];

        if (array_key_exists('empleado_id', $patch))  $data['empleado_id']  = (int)$patch['empleado_id'];
        if (array_key_exists('tipo_id', $patch)) {
            $v = $patch['tipo_id'];
            $data['tipo_id'] = ($v && (int)$v > 0) ? (int)$v : null; // null => SET NULL
        }
        if (array_key_exists('descripcion', $patch))  $data['descripcion']  = wp_kses_post($patch['descripcion']);
        if (array_key_exists('fecha_inicio', $patch)) $data['fecha_inicio'] = self::safe_date($patch['fecha_inicio']);
        if (array_key_exists('fecha_fin', $patch))    $data['fecha_fin']    = self::safe_date($patch['fecha_fin']); // null => SET NULL
        if (array_key_exists('archivo_id', $patch)) {
            $v = $patch['archivo_id'];
            $data['archivo_id'] = ($v && (int)$v > 0) ? (int)$v : null; // null => SET NULL
        }
        if (array_key_exists('borrado', $patch))      $data['borrado']      = ((string)$patch['borrado']==='1'||$patch['borrado']===1)?1:0;

        // Recalcular fecha_fin si NO vino explícita y tenemos inicio+tipo
        if (!array_key_exists('fecha_fin', $patch) || $patch['fecha_fin'] === '' || $patch['fecha_fin'] === null) {
            $inicio  = $data['fecha_inicio'] ?? (string)($actual->fecha_inicio ?? null);
            $tipo_id = array_key_exists('tipo_id', $data)
                ? $data['tipo_id']
                : ((isset($actual->tipo_id) && (int)$actual->tipo_id > 0) ? (int)$actual->tipo_id : null);
            if ($inicio && $tipo_id) {
                $t = $this->obtener_tipo((int)$tipo_id);
                if ($t) {
                    $data['fecha_fin'] = self::calc_fecha_fin($inicio, (int)$t->plazo_numero, (string)$t->plazo_unidad);
                }
            }
        }

        $data['updated_at'] = current_time('mysql', true);
        $uid = (int) ($user_id ?: 0);
        if ($uid > 0 && $this->docs_has_updated_by) $data['updated_by'] = $uid;

        return $this->update_with_nulls($this->table_docs, $data, ['id'=>$id]);
    }

    public function soft_delete_doc(int $id, ?int $user_id = 0) {
        $data = [
            'borrado'    => 1,
            'updated_at' => current_time('mysql', true),
        ];
        $uid = (int) ($user_id ?: 0);
        if ($uid > 0 && $this->docs_has_updated_by) $data['updated_by'] = $uid;

        return $this->update_with_nulls($this->table_docs, $data, ['id' => (int)$id]);
    }

    public function obtener_doc(int $id) {
        $sql = $this->base_select_docs() . " WHERE d.id=%d AND d.borrado=0";
        return $this->wpdb->get_row($this->wpdb->prepare($sql, $id));
    }

    public function listar_docs(array $args) {
        $q           = isset($args['q'])           ? (string)$args['q'] : '';
        $empleado_id = isset($args['empleado_id']) ? (int)$args['empleado_id'] : 0;
        $tipo_id     = isset($args['tipo_id'])     ? (int)$args['tipo_id'] : 0;
        $estado_raw  = isset($args['estado'])      ? (string)$args['estado'] : '';
        $estado      = $this->norm_estado($estado_raw);

        $paged = max(1, (int)($args['paged'] ?? $args['page'] ?? 1));
        $per   = max(1, min(100, (int)($args['per_page'] ?? $args['per'] ?? 10)));

        // Orden configurable (por defecto: últimos insertados primero)
        $orden = isset($args['orden']) ? sanitize_key($args['orden']) : 'recientes';

        $where  = "WHERE d.borrado=0";
        $params = [];

        if ($q !== '') {
            $like    = '%' . $this->wpdb->esc_like($q) . '%';
            $where  .= " AND (d.descripcion LIKE %s OR t.descripcion LIKE %s OR CONCAT_WS(' ', e.nombre, e.apellido) LIKE %s)";
            array_push($params, $like, $like, $like);
        }
        if ($empleado_id > 0) { $where .= " AND d.empleado_id=%d"; $params[] = $empleado_id; }
        if ($tipo_id     > 0) { $where .= " AND d.tipo_id=%d";     $params[] = $tipo_id; }

        if ($estado !== '') {
            $today = current_time('Y-m-d');

            switch ($estado) {
                case 'vencido':
                    $where  .= " AND d.fecha_fin IS NOT NULL AND d.fecha_fin < %s";
                    $params[] = $today;
                    break;

                case 'por_vencer':
                    $where  .= " AND d.fecha_fin IS NOT NULL AND d.fecha_fin >= %s AND d.fecha_fin <= DATE_ADD(%s, INTERVAL 30 DAY)";
                    array_push($params, $today, $today);
                    break;

                case 'vigente':
                    $where  .= " AND (d.fecha_fin IS NULL OR d.fecha_fin > DATE_ADD(%s, INTERVAL 30 DAY))";
                    $params[] = $today;
                    break;
            }
        }

        // Total
        if ($params) {
            $total = (int) $this->wpdb->get_var($this->wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->table_docs} d
                 LEFT JOIN {$this->table_tipos} t ON t.id=d.tipo_id
                 LEFT JOIN {$this->table_empleados} e ON e.id=d.empleado_id
                 $where", ...$params
            ));
        } else {
            $total = (int) $this->wpdb->get_var(
                "SELECT COUNT(*) FROM {$this->table_docs} d
                 LEFT JOIN {$this->table_tipos} t ON t.id=d.tipo_id
                 LEFT JOIN {$this->table_empleados} e ON e.id=d.empleado_id
                 $where"
            );
        }

        $offset = max(0, ($paged - 1) * $per);

        // ORDER BY según criterio
        switch ($orden) {
            case 'inicio_desc':
                $orderBy = "ORDER BY d.fecha_inicio DESC, d.id DESC";
                break;
            case 'fin_asc':
                $orderBy = "ORDER BY d.fecha_fin IS NULL DESC, d.fecha_fin ASC, d.id DESC";
                break;
            case 'fin_desc':
                $orderBy = "ORDER BY d.fecha_fin IS NULL DESC, d.fecha_fin DESC, d.id DESC";
                break;
            case 'recientes':
            default:
                $orderBy = "ORDER BY d.id DESC"; // último insertado primero
                break;
        }

        $sql  = $this->base_select_docs() . " $where
                $orderBy
                LIMIT %d OFFSET %d";

        $rows = $this->wpdb->get_results($this->wpdb->prepare($sql, ...array_merge($params, [$per, $offset])));

        $todayDt = new \DateTime(current_time('Y-m-d'));
        foreach ($rows as $r) {
            $r->estado                = $this->estado_doc($r->fecha_fin, $todayDt);
            $r->dias_para_vencimiento = $this->dias_diff($todayDt, $r->fecha_fin);
        }

        return ['items' => $rows, 'total' => $total, 'paged' => $paged, 'per_page' => $per];
    }

    /* ======================= Helpers ======================= */

    private function base_select_docs() {
        return "SELECT d.*,
                       t.descripcion AS tipo_descripcion, t.plazo_numero, t.plazo_unidad,
                       e.nombre AS emp_nombre, e.apellido AS emp_apellido
                FROM {$this->table_docs} d
                LEFT JOIN {$this->table_tipos} t ON t.id=d.tipo_id
                LEFT JOIN {$this->table_empleados} e ON e.id=d.empleado_id";
    }

    private function estado_doc(?string $fecha_fin, \DateTime $today) {
        if (empty($fecha_fin)) return 'sin_vencimiento';
        $fin = \DateTime::createFromFormat('Y-m-d', $fecha_fin);
        if (!$fin) return 'desconocido';
        if ($fin < $today) return 'vencido';
        $diff = (int) $today->diff($fin)->format('%r%a');
        return ($diff <= 30) ? 'por_vencer' : 'vigente';
    }

    private function dias_diff(\DateTime $today, ?string $fecha_fin) {
        if (empty($fecha_fin)) return null;
        $fin = \DateTime::createFromFormat('Y-m-d', $fecha_fin);
        if (!$fin) return null;
        return (int) $today->diff($fin)->format('%r%a');
    }

    public static function safe_date(?string $d) {
        if (!$d) return null;
        $ts = strtotime($d);
        return $ts ? gmdate('Y-m-d', $ts) : null;
    }

    public static function calc_fecha_fin(?string $inicio, ?int $n, ?string $u) {
        if (!$inicio || !$n || !$u) return null;
        $inicio = self::safe_date($inicio);
        if (!$inicio) return null;

        $dt = \DateTime::createFromFormat('Y-m-d', $inicio);
        if (!$dt) return null;

        $u = self::norm_unidad($u);
        if ($u === 'dias')        $dt->modify("+{$n} day");
        elseif ($u === 'meses')   $dt->modify("+{$n} month");
        elseif ($u === 'anios')   $dt->modify("+{$n} year");

        return $dt->format('Y-m-d');
    }

    private static function norm_unidad(?string $u) {
        $u = strtolower((string) $u);
        if (in_array($u, ['dias', 'días'], true))  return 'dias';
        if ($u === 'meses')                        return 'meses';
        if (in_array($u, ['anios', 'años'], true)) return 'anios';
        return null;
    }

    private function norm_estado(string $estado) {
        $estado = strtolower(trim($estado));
        if ($estado === '' || $estado === 'todos') return '';
        if ($estado === 'vencido' || $estado === 'vencidos') return 'vencido';
        if ($estado === 'vigente' || $estado === 'vigentes') return 'vigente';
        if ($estado === 'por_vencer' || $estado === 'por-vencer') return 'por_vencer';
        return '';
    }

    /* ===== Helpers internos para INSERT/UPDATE con NULL reales ===== */

    private function ph($v){
        if (is_int($v) || is_bool($v)) return '%d';
        if (is_string($v) && preg_match('/^-?\d+$/', $v)) return '%d';
        return '%s';
    }

    private function insert_dynamic(string $table, array $data) {
        // Omite claves con null => quedan NULL en DB
        $cols = []; $phs = []; $vals = [];
        foreach ($data as $k=>$v) {
            if ($v === null) continue;
            $cols[] = "`$k`";
            $phs[]  = $this->ph($v);
            $vals[] = $v;
        }
        if (!$cols) return false; // nada para insertar
        $sql = "INSERT INTO $table (".implode(',', $cols).") VALUES (".implode(',', $phs).")";
        $ok  = $this->wpdb->query($this->wpdb->prepare($sql, ...$vals));
        return $ok ? (int)$this->wpdb->insert_id : false;
    }

    private function update_with_nulls(string $table, array $data, array $where): bool {
        $sets = []; $vals = [];
        foreach ($data as $k=>$v) {
            if ($v === null) {
                $sets[] = "`$k` = NULL";
            } else {
                $sets[] = "`$k` = ".$this->ph($v);
                $vals[] = $v;
            }
        }
        if (!$sets) return true; // nada que actualizar
        $wheres = []; $wvals = [];
        foreach ($where as $k=>$v) {
            $wheres[] = "`$k` = ".$this->ph($v);
            $wvals[]  = $v;
        }
        $sql = "UPDATE $table SET ".implode(', ', $sets)." WHERE ".implode(' AND ', $wheres);
        return $this->wpdb->query($this->wpdb->prepare($sql, ...array_merge($vals, $wvals))) !== false;
    }
}
