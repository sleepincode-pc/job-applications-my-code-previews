<?php
namespace MidasRRHH\Models;

if (!defined('ABSPATH')) exit;

/**
 * Modelo de Novedades / Ampliaciones (tipo foro)
 * - Crea/actualiza tablas
 * - CRUD de temas y respuestas
 */
class Novedades_Model {
    /** @var \wpdb */
    private $db;
    private $tbl_topics;
    private $tbl_replies;

    public function __construct() {
        global $wpdb;
        $this->db = $wpdb;
        $this->tbl_topics  = $wpdb->prefix . 'midas_novedades';
        $this->tbl_replies = $wpdb->prefix . 'midas_novedades_respuestas';
    }

    /** Crea/actualiza las tablas (llamar en activación del plugin) */
    public function create_tables() {
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $this->db->get_charset_collate();

        $sql1 = "CREATE TABLE {$this->tbl_topics} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            titulo VARCHAR(255) NOT NULL,
            contenido LONGTEXT NULL,
            estado VARCHAR(20) NOT NULL DEFAULT 'publish', /* publish|draft|closed */
            sticky TINYINT(1) NOT NULL DEFAULT 0,
            tags TEXT NULL,
            cliente_visible TINYINT(1) NOT NULL DEFAULT 1,
            autor_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY estado (estado),
            KEY sticky (sticky),
            KEY cliente_visible (cliente_visible),
            KEY autor_id (autor_id)
        ) $charset;";

        $sql2 = "CREATE TABLE {$this->tbl_replies} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            topic_id BIGINT(20) UNSIGNED NOT NULL,
            contenido LONGTEXT NOT NULL,
            estado VARCHAR(20) NOT NULL DEFAULT 'publish', /* publish|hidden */
            autor_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY topic_id (topic_id),
            KEY estado (estado),
            KEY autor_id (autor_id),
            CONSTRAINT fk_topic
                FOREIGN KEY (topic_id) REFERENCES {$this->tbl_topics}(id)
                ON DELETE CASCADE
        ) $charset;";

        dbDelta($sql1);
        dbDelta($sql2);
    }

    /* ================= Temas ================= */

    public function create_topic(array $data): int {
        $now = current_time('mysql');
        $row = [
            'titulo'          => sanitize_text_field($data['titulo'] ?? ''),
            'contenido'       => wp_kses_post($data['contenido'] ?? ''),
            'estado'          => in_array(($data['estado'] ?? 'publish'), ['publish','draft','closed'], true) ? $data['estado'] : 'publish',
            'sticky'          => empty($data['sticky']) ? 0 : 1,
            'tags'            => sanitize_text_field($data['tags'] ?? ''),
            'cliente_visible' => empty($data['cliente_visible']) ? 0 : 1,
            'autor_id'        => intval($data['autor_id'] ?? get_current_user_id()),
            'created_at'      => $now,
            'updated_at'      => $now,
        ];
        $ok = $this->db->insert($this->tbl_topics, $row);
        return $ok ? intval($this->db->insert_id) : 0;
    }

    public function update_topic(int $id, array $data): bool {
        if ($id <= 0) return false;
        $row = [
            'titulo'          => array_key_exists('titulo',$data) ? sanitize_text_field($data['titulo']) : null,
            'contenido'       => array_key_exists('contenido',$data) ? wp_kses_post($data['contenido']) : null,
            'estado'          => array_key_exists('estado',$data) && in_array($data['estado'], ['publish','draft','closed'], true) ? $data['estado'] : null,
            'sticky'          => array_key_exists('sticky',$data) ? (empty($data['sticky'])?0:1) : null,
            'tags'            => array_key_exists('tags',$data) ? sanitize_text_field($data['tags']) : null,
            'cliente_visible' => array_key_exists('cliente_visible',$data) ? (empty($data['cliente_visible'])?0:1) : null,
            'updated_at'      => current_time('mysql'),
        ];
        $row = array_filter($row, function($v){ return !is_null($v); });
        if (!$row) return true;
        return (bool) $this->db->update($this->tbl_topics, $row, ['id'=>$id], null, ['%d']);
    }

    public function delete_topic(int $id): bool {
        if ($id <= 0) return false;
        return (bool) $this->db->delete($this->tbl_topics, ['id'=>$id], ['%d']);
    }

    public function get_topic(int $id) {
        if ($id <= 0) return null;
        return $this->db->get_row(
            $this->db->prepare("SELECT * FROM {$this->tbl_topics} WHERE id=%d", $id),
            ARRAY_A
        );
    }

    public function list_topics(array $args = []): array {
        $page   = max(1, intval($args['page']   ?? 1));
        $pp     = max(1, min(100, intval($args['per_page'] ?? 20)));
        $offset = ($page-1)*$pp;

        $where  = "WHERE 1=1";
        $params = [];

        if (isset($args['estado']) && in_array($args['estado'], ['publish','draft','closed'], true)){
            $where .= " AND estado = %s"; $params[] = $args['estado'];
        }
        if (isset($args['cliente_visible'])) {
            $where .= " AND cliente_visible = %d"; $params[] = empty($args['cliente_visible'])?0:1;
        }
        if (!empty($args['s'])) {
            $like = '%' . $this->db->esc_like($args['s']) . '%';
            $where .= " AND (titulo LIKE %s OR contenido LIKE %s)";
            $params[] = $like; $params[] = $like;
        }

        $order_by = " ORDER BY sticky DESC, updated_at DESC";
        $sql = "SELECT SQL_CALC_FOUND_ROWS * FROM {$this->tbl_topics} {$where}{$order_by} LIMIT %d OFFSET %d";
        $params[] = $pp; $params[] = $offset;

        $query = $this->db->prepare($sql, $params);
        $items = $this->db->get_results($query, ARRAY_A) ?: [];
        $total = (int) $this->db->get_var("SELECT FOUND_ROWS()");
        return ['items'=>$items, 'total'=>$total, 'page'=>$page, 'per_page'=>$pp];
    }

    /* ================= Respuestas ================= */

    public function add_reply(int $topic_id, array $data): int {
        if ($topic_id <= 0) return 0;
        $now = current_time('mysql');
        $row = [
            'topic_id'   => $topic_id,
            'contenido'  => wp_kses_post($data['contenido'] ?? ''),
            'estado'     => in_array(($data['estado'] ?? 'publish'), ['publish','hidden'], true) ? $data['estado'] : 'publish',
            'autor_id'   => intval($data['autor_id'] ?? get_current_user_id()),
            'created_at' => $now,
            'updated_at' => $now,
        ];
        $ok = $this->db->insert($this->tbl_replies, $row);
        if ($ok) {
            // tocar updated_at del tema
            $this->db->update($this->tbl_topics, ['updated_at'=>$now], ['id'=>$topic_id]);
        }
        return $ok ? intval($this->db->insert_id) : 0;
    }

    public function list_replies(int $topic_id, array $args = []): array {
        if ($topic_id <= 0) return ['items'=>[], 'total'=>0, 'page'=>1, 'per_page'=>20];

        $page   = max(1, intval($args['page']   ?? 1));
        $pp     = max(1, min(200, intval($args['per_page'] ?? 20)));
        $offset = ($page-1)*$pp;

        $estado = isset($args['estado']) && in_array($args['estado'], ['publish','hidden'], true) ? $args['estado'] : null;
        $params = [$topic_id];
        $where  = "WHERE topic_id=%d";
        if ($estado) { $where .= " AND estado=%s"; $params[] = $estado; }

        $sql = "SELECT SQL_CALC_FOUND_ROWS * FROM {$this->tbl_replies} {$where} ORDER BY created_at ASC LIMIT %d OFFSET %d";
        $params[] = $pp; $params[] = $offset;

        $query  = $this->db->prepare($sql, $params);
        $items  = $this->db->get_results($query, ARRAY_A) ?: [];
        $total  = (int) $this->db->get_var("SELECT FOUND_ROWS()");
        return ['items'=>$items, 'total'=>$total, 'page'=>$page, 'per_page'=>$pp];
    }

    public function delete_reply(int $id): bool {
        if ($id <= 0) return false;
        return (bool) $this->db->delete($this->tbl_replies, ['id'=>$id], ['%d']);
    }
}
