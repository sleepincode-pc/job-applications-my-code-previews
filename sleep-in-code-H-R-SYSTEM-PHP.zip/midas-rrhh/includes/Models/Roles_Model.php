<?php
namespace MidasRRHH\Models;

class Roles_Model {

    /**
     * Devuelve todos los usuarios agrupados por rol.
     */
    public function get_usuarios_por_rol() {
        $users = get_users();
        $result = [];
        foreach ($users as $user) {
            foreach ($user->roles as $role) {
                $result[$role][] = $user;
            }
        }
        return $result;
    }

    /**
     * Devuelve todos los roles disponibles en WordPress.
     */
    public function get_todos_los_roles() {
        global $wp_roles;
        if (!isset($wp_roles)) {
            $wp_roles = wp_roles();
        }
        return $wp_roles->roles;
    }

    /**
     * Devuelve todas las pestañas posibles del plugin.
     */
    public function get_todos_los_tabs() {
        return [
            'dashboard' => __('Dashboard', 'midas-rrhh'),
            'empleados' => __('Empleados', 'midas-rrhh'),
            'recibos'   => __('Recibos', 'midas-rrhh'),
            'licencias' => __('Licencias', 'midas-rrhh'),
            'carpeta'   => __('Carpeta Médica', 'midas-rrhh'),
            'tareas'    => __('Tareas y Áreas', 'midas-rrhh'),
            'reportes'  => __('Reportes', 'midas-rrhh'),
            'config'    => __('Configuración', 'midas-rrhh'),
            'roles'     => __('Roles', 'midas-rrhh'),
        ];
    }

    /**
     * Guarda las pestañas que el usuario NO debe ver.
     * 
     * @param int $user_id
     * @param array $tabs
     */
    public function guardar_tabs_no_visibles($user_id, $tabs) {
        if (!get_user_by('id', $user_id)) {
            return new \WP_Error('no_user', __('Usuario no existe', 'midas-rrhh'));
        }
        // Validar las pestañas
        $todos_los_tabs = array_keys($this->get_todos_los_tabs());
        $tabs = array_intersect($todos_los_tabs, (array)$tabs);
        update_user_meta($user_id, 'midas_rrhh_tabs', $tabs);
        return true;
    }

    /**
     * Devuelve las pestañas NO visibles para el usuario.
     */
    public function get_tabs_no_visibles_usuario($user_id) {
        $saved = get_user_meta($user_id, 'midas_rrhh_tabs', true);
        return is_array($saved) ? $saved : [];
    }

    /**
     * Devuelve las pestañas VISIBLES para el usuario (para usar en el menú).
     */
    public function get_tabs_visibles_usuario($user_id) {
        $todos_los_tabs = $this->get_todos_los_tabs();
        $no_visibles = $this->get_tabs_no_visibles_usuario($user_id);
        // Filtrar las que SÍ puede ver
        $visibles = [];
        foreach ($todos_los_tabs as $key => $label) {
            if (!in_array($key, $no_visibles)) {
                $visibles[$key] = $label;
            }
        }
        return $visibles;
    }

    // ====== NUEVO: Opciones bloqueadas por rol usando update_option ======

    /**
     * Guarda las opciones bloqueadas por rol en la base global.
     * @param array $bloqueadas ['rol' => ['opcion1', ...], ...]
     */
    public function guardar_opciones_bloqueadas($bloqueadas) {
        update_option('midas_rrhh_opciones_bloqueadas', $bloqueadas);
        return true;
    }

    /**
     * Devuelve las opciones bloqueadas para un rol (array de keys).
     * @param string $rol
     */
    public function get_opciones_bloqueadas_rol($rol) {
        $all = get_option('midas_rrhh_opciones_bloqueadas', []);
        return isset($all[$rol]) ? $all[$rol] : [];
    }

    /**
     * Devuelve todas las opciones principales RRHH posibles.
     */
    public function get_todas_las_opciones_rrhh() {
        return [
            'recibo'   => __('Subir Recibo', 'midas-rrhh'),
            'licencia' => __('Solicitar Licencia', 'midas-rrhh'),
            'documento'=> __('Subir Documento Médico', 'midas-rrhh'),
            'ticket'   => __('Crear Ticket', 'midas-rrhh')
        ];
    }
}
