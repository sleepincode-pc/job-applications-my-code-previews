<?php
namespace MidasRRHH\Models;

if (!defined('ABSPATH')) exit;

class Licencia_Model extends Base_Model {
    protected $table = 'midas_licencias';
    protected $primary_key = 'id';
    protected $allowed_fields = [
        'empleado_id', 'tipo', 'fecha_inicio', 'fecha_fin', 
        'dias_solicitados', 'dias_aprobados', 'estado', 
        'documento_id', 'observaciones', 'gestor_id'
    ];

    public function __construct() {
        parent::__construct();
        global $wpdb;
        $this->wpdb = $wpdb;
    }

    // Obtener licencias por empleado ordenadas por fecha_inicio descendente
    public function get_by_empleado($empleado_id) {
        return $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->wpdb->prefix}{$this->table} 
                WHERE empleado_id = %d 
                ORDER BY fecha_inicio DESC",
                $empleado_id
            )
        );
    }

    // Obtener licencias con estado pendiente
    public function get_pendientes() {
        return $this->wpdb->get_results(
            "SELECT * FROM {$this->wpdb->prefix}{$this->table} 
            WHERE estado = 'pendiente' 
            ORDER BY fecha_inicio ASC"
        );
    }

    // Obtener licencias aprobadas con filtro opcional por rango de fechas
    public function get_aprobadas($fecha_inicio = null, $fecha_fin = null) {
        $where = " WHERE estado = 'aprobado'";
        if ($fecha_inicio && $fecha_fin) {
            $where .= $this->wpdb->prepare(
                " AND fecha_inicio >= %s AND fecha_fin <= %s",
                $fecha_inicio, $fecha_fin
            );
        }
        return $this->wpdb->get_results(
            "SELECT * FROM {$this->wpdb->prefix}{$this->table}{$where} 
            ORDER BY fecha_inicio DESC"
        );
    }

    // Obtener licencias rechazadas
    public function get_rechazadas() {
        return $this->wpdb->get_results(
            "SELECT * FROM {$this->wpdb->prefix}{$this->table} 
            WHERE estado = 'rechazado' 
            ORDER BY fecha_inicio DESC"
        );
    }

    // Obtener todas las licencias sin filtro
    public function get_todas() {
        return $this->wpdb->get_results(
            "SELECT * FROM {$this->wpdb->prefix}{$this->table} 
            ORDER BY fecha_inicio DESC"
        );
    }

    // Insertar una nueva licencia
    public function insert($data) {
        $data = array_intersect_key($data, array_flip($this->allowed_fields));
        $result = $this->wpdb->insert($this->wpdb->prefix . $this->table, $data);
        if ($result === false) {
            return false;
        }
        return $this->wpdb->insert_id;
    }

    // Actualizar licencia por ID
    public function update($id, $data) {
        $data = array_intersect_key($data, array_flip($this->allowed_fields));
        return $this->wpdb->update(
            $this->wpdb->prefix . $this->table,
            $data,
            [$this->primary_key => $id]
        );
    }

    // Eliminar licencia por ID
    public function delete($id) {
        return $this->wpdb->delete(
            $this->wpdb->prefix . $this->table,
            [$this->primary_key => $id]
        );
    }
}
