<?php
namespace MidasRRHH\Models;

class Area_Model extends Base_Model {
    protected $table = 'midas_areas';
    protected $primary_key = 'id';
    protected $allowed_fields = ['nombre', 'descripcion', 'activo'];

    // MÉTODO REQUERIDO POR CONTROLLER Y AJAX
    public function insert($data) {
        $result = $this->wpdb->insert(
            "{$this->wpdb->prefix}{$this->table}",
            [
                'nombre'      => sanitize_text_field($data['nombre']),
                'descripcion' => isset($data['descripcion']) ? sanitize_text_field($data['descripcion']) : '',
                'activo'      => isset($data['activo']) ? intval($data['activo']) : 1,
                'created_at'  => current_time('mysql'),
                'updated_at'  => current_time('mysql'),
            ]
        );
        return $result ? $this->wpdb->insert_id : false;
    }

    public function get_all($active_only = true) {
        $where = $active_only ? " WHERE activo = 1" : "";
        return $this->wpdb->get_results(
            "SELECT * FROM {$this->wpdb->prefix}{$this->table}{$where} ORDER BY nombre"
        );
    }

    // Puedes mantener este método especial si alguna vez creás un área con empleados asignados en un solo paso.
    public function create_with_empleados($data, $empleado_ids = []) {
        $inserted = $this->insert($data); // Reutiliza insert aquí
        if ($inserted) {
            $area_id = $inserted;
            // Asignar el área a los empleados
            foreach ($empleado_ids as $empleado_id) {
                $this->wpdb->update(
                    "{$this->wpdb->prefix}midas_empleados",
                    ['area_id' => $area_id],
                    ['id' => intval($empleado_id)]
                );
            }
            return $area_id;
        }
        return false;
    }

    public function obtener_areas_activas() {
        return $this->wpdb->get_results(
            "SELECT id, nombre FROM {$this->wpdb->prefix}{$this->table} WHERE activo = 1 ORDER BY nombre"
        );
    }
}
