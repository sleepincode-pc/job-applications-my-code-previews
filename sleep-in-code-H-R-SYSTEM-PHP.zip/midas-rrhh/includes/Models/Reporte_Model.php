<?php
namespace MidasRRHH\Models;

if (!defined('ABSPATH')) exit;

class Reporte_Model {

    private $table_empleados;
    private $table_areas;
    private $table_tareas;

    // NUEVO: tablas actuales de documentación y tipos
    private $table_documentaciones;
    private $table_doc_tipos;

    // (legacy) mantenemos referencia por compat si la usas en otro lado
    private $table_documentos;

    // wp_users (con prefijo real de la instalación)
    private $table_users;

    public function __construct() {
        global $wpdb;
        $this->table_empleados        = $wpdb->prefix . 'midas_empleados';
        $this->table_areas            = $wpdb->prefix . 'midas_areas';
        $this->table_tareas           = $wpdb->prefix . 'midas_tareas';

        // actuales
        $this->table_documentaciones  = $wpdb->prefix . 'midas_documentaciones';
        $this->table_doc_tipos        = $wpdb->prefix . 'midas_doc_tipos';

        // legacy (por si existe en algún template viejo)
        $this->table_documentos       = $wpdb->prefix . 'midas_documentos';

        // nombre físico de wp_users según la instalación
        $this->table_users            = $wpdb->users;
    }

    public function obtener_areas() {
        global $wpdb;
        $query = "SELECT id, nombre FROM {$this->table_areas}";
        return $wpdb->get_results($query);
    }

    public function obtener_empleados($area_id = null) {
        global $wpdb;

        $sql = "
            SELECT 
                e.id, 
                e.nombre, 
                e.apellido, 
                e.dni, 
                e.fecha_inicio_laboral,
                e.created_at,
                e.updated_at,
                e.created_by,
                e.updated_by,
                a.nombre AS area_nombre, 
                t.nombre AS tarea_nombre
            FROM {$this->table_empleados} e
            LEFT JOIN {$this->table_areas} a  ON e.area_id  = a.id
            LEFT JOIN {$this->table_tareas} t ON e.tarea_id = t.id
        ";

        if ($area_id) {
            $sql .= $wpdb->prepare(" WHERE e.area_id = %d", $area_id);
        }

        // más reciente primero
        $sql .= " ORDER BY e.updated_at DESC, e.created_at DESC";

        return $wpdb->get_results($sql);
    }

    /**
     * NUEVO: Feed de “Movimientos (Actividad)”
     * Une altas/actualizaciones de:
     *  - Documentaciones (midas_documentaciones)
     *  - Tipos de documentación (midas_doc_tipos)
     * Resuelve el usuario con wp_users tomando created_by / updated_by.
     */
    public function obtener_movimientos_actividad(int $limit = 200) {
        global $wpdb;

        $limit = max(10, min(1000, (int)$limit));

        // Armamos un UNION ALL y luego ordenamos por fecha_hora desc
        $sql = "
            SELECT * FROM (
                /* Documentación creada */
                SELECT 
                    d.created_at                          AS fecha_hora,
                    'DOCUMENTACIÓN'                       AS modulo,
                    'CREADA'                               AS accion,
                    TRIM(CONCAT_WS(' - ',
                        NULLIF(t.descripcion,''),
                        NULLIF(d.descripcion,'')
                    ))                                     AS detalle,
                    u.display_name                         AS usuario_wp
                FROM {$this->table_documentaciones} d
                LEFT JOIN {$this->table_doc_tipos} t ON t.id = d.tipo_id
                LEFT JOIN {$this->table_users} u     ON u.ID = d.created_by

                UNION ALL

                /* Documentación actualizada */
                SELECT 
                    d.updated_at                          AS fecha_hora,
                    'DOCUMENTACIÓN'                       AS modulo,
                    'ACTUALIZADA'                          AS accion,
                    TRIM(CONCAT_WS(' - ',
                        NULLIF(t.descripcion,''),
                        NULLIF(d.descripcion,'')
                    ))                                     AS detalle,
                    u2.display_name                        AS usuario_wp
                FROM {$this->table_documentaciones} d
                LEFT JOIN {$this->table_doc_tipos} t ON t.id = d.tipo_id
                LEFT JOIN {$this->table_users} u2    ON u2.ID = d.updated_by

                UNION ALL

                /* Tipo creado */
                SELECT 
                    tt.created_at                         AS fecha_hora,
                    'TIPOS (DOC.)'                        AS modulo,
                    'CREADO'                               AS accion,
                    NULLIF(tt.descripcion,'')             AS detalle,
                    uu.display_name                        AS usuario_wp
                FROM {$this->table_doc_tipos} tt
                LEFT JOIN {$this->table_users} uu   ON uu.ID = tt.created_by

                UNION ALL

                /* Tipo actualizado */
                SELECT 
                    tt.updated_at                         AS fecha_hora,
                    'TIPOS (DOC.)'                        AS modulo,
                    'ACTUALIZADO'                          AS accion,
                    NULLIF(tt.descripcion,'')             AS detalle,
                    uu2.display_name                       AS usuario_wp
                FROM {$this->table_doc_tipos} tt
                LEFT JOIN {$this->table_users} uu2  ON uu2.ID = tt.updated_by
            ) mov
            WHERE fecha_hora IS NOT NULL
            ORDER BY fecha_hora DESC
            LIMIT %d
        ";

        return $wpdb->get_results($wpdb->prepare($sql, $limit));
    }

    /**
     * (Legacy) Si aún usas una vista que pide documentos aprobados en la tabla vieja.
     * Si la tabla no existe simplemente retorna arreglo vacío.
     */
    public function obtener_documentos_aprobados() {
        global $wpdb;

        $existe = (bool) $wpdb->get_var($wpdb->prepare(
            "SHOW TABLES LIKE %s", $this->table_documentos
        ));
        if (!$existe) return [];

        $sql = "SELECT * FROM {$this->table_documentos} WHERE estado = %s";
        return $wpdb->get_results($wpdb->prepare($sql, 'aprobado'), ARRAY_A);
    }
}
