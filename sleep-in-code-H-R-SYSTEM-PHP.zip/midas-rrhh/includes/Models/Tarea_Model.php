<?php
namespace MidasRRHH\Models;

if (!defined('ABSPATH')) exit;

class Tarea_Model extends Base_Model {
    protected $table = 'midas_tareas';
    protected $primary_key = 'id';
    protected $allowed_fields = ['nombre', 'descripcion', 'activo'];

    // Obtener todas las tareas (por defecto solo activas)
    public function get_all($active_only = true) {
        $where = $active_only ? " WHERE activo = 1" : "";
        return $this->wpdb->get_results(
            "SELECT * FROM {$this->wpdb->prefix}{$this->table}{$where} ORDER BY nombre"
        );
    }

    // Crear tarea y asignar a empleados (por array de IDs)
    public function create_with_empleados($data, $empleado_ids = []) {
        $inserted = $this->wpdb->insert(
            "{$this->wpdb->prefix}{$this->table}",
            [
                'nombre'      => sanitize_text_field($data['nombre']),
                'descripcion' => isset($data['descripcion']) ? sanitize_text_field($data['descripcion']) : '',
                'activo'      => isset($data['activo']) ? intval($data['activo']) : 1,
                'created_at'  => current_time('mysql'),
                'updated_at'  => current_time('mysql'),
            ]
        );

        if ($inserted) {
            $tarea_id = $this->wpdb->insert_id;

            // Asignar la tarea a los empleados
            foreach ($empleado_ids as $empleado_id) {
                $this->wpdb->update(
                    "{$this->wpdb->prefix}midas_empleados",
                    ['tarea_id' => $tarea_id],
                    ['id' => intval($empleado_id)]
                );
            }

            return $tarea_id;
        }

        return false;
    }

    // Obtener solo tareas activas (id + nombre)
    public function obtener_tareas_activas() {
        return $this->wpdb->get_results(
            "SELECT id, nombre FROM {$this->wpdb->prefix}{$this->table} WHERE activo = 1 ORDER BY nombre"
        );
    }

    // Obtener tareas con cantidad de empleados asignados a cada una
    public function tareas_con_conteo_empleados() {
        $query = "
            SELECT t.*, COUNT(e.id) as cantidad_empleados
            FROM {$this->wpdb->prefix}{$this->table} t
            LEFT JOIN {$this->wpdb->prefix}midas_empleados e ON e.tarea_id = t.id
            GROUP BY t.id
            ORDER BY t.nombre
        ";
        return $this->wpdb->get_results($query);
    }

    // Obtener una tarea por ID
    public function get($id) {
        return $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->wpdb->prefix}{$this->table} WHERE id = %d LIMIT 1", $id
            )
        );
    }

    // Editar una tarea
    public function update($id, $data) {
        $fields = [];
        if (isset($data['nombre']))       $fields['nombre'] = sanitize_text_field($data['nombre']);
        if (isset($data['descripcion'])) $fields['descripcion'] = sanitize_text_field($data['descripcion']);
        if (isset($data['activo']))       $fields['activo'] = intval($data['activo']);
        $fields['updated_at'] = current_time('mysql');
        return $this->wpdb->update(
            "{$this->wpdb->prefix}{$this->table}", $fields, ['id' => intval($id)]
        );
    }

    // ================================
    // ELIMINAR TAREA Y DESASIGNAR EMPLEADOS
    // ================================
    /**
     * Elimina una tarea y desasigna la tarea de los empleados relacionados.
     * @param int $id
     * @return bool
     */
    public function eliminar($id) {
        $id = intval($id);
        if (!$id) return false;

        // Desasignar la tarea de los empleados
        $this->wpdb->update(
            "{$this->wpdb->prefix}midas_empleados",
            ['tarea_id' => null],
            ['tarea_id' => $id]
        );

        // Eliminar la tarea
        $deleted = $this->wpdb->delete(
            "{$this->wpdb->prefix}{$this->table}",
            ['id' => $id]
        );

        return (bool) $deleted;
    }

    /**
     * Asigna múltiples tareas a un array de empleados (sobrescribe las tareas anteriores).
     * @param array $empleado_ids
     * @param int $tarea_id
     * @return int Cantidad de empleados actualizados
     */
    public function asignar_a_empleados($empleado_ids, $tarea_id) {
        $tarea_id = intval($tarea_id);
        if (!$tarea_id || empty($empleado_ids) || !is_array($empleado_ids)) return 0;
        $count = 0;
        foreach ($empleado_ids as $empleado_id) {
            $result = $this->wpdb->update(
                "{$this->wpdb->prefix}midas_empleados",
                ['tarea_id' => $tarea_id],
                ['id' => intval($empleado_id)]
            );
            if ($result !== false) $count++;
        }
        return $count;
    }
}
