<?php
namespace MidasRRHH\Models;

class Empleado_Model {
    private $table_name;
    private $wpdb;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->table_name = $wpdb->prefix . 'midas_empleados';
    }

    private function sanitizar_data(array $data): array {
        $sanitized = [];

        if (isset($data['dni']))             $sanitized['dni'] = strtoupper(sanitize_text_field($data['dni']));
        if (isset($data['cuil']))            $sanitized['cuil'] = strtoupper(sanitize_text_field($data['cuil']));
        if (isset($data['nombre']))          $sanitized['nombre'] = strtoupper(sanitize_text_field($data['nombre']));
        if (isset($data['apellido']))        $sanitized['apellido'] = strtoupper(sanitize_text_field($data['apellido']));
        if (isset($data['email'])) {
            $email = sanitize_email($data['email']);
            if (is_email($email)) $sanitized['email'] = $email;
        }
        if (isset($data['telefono']))        $sanitized['telefono'] = sanitize_text_field($data['telefono']);
        if (isset($data['fecha_nacimiento']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $data['fecha_nacimiento'])) $sanitized['fecha_nacimiento'] = $data['fecha_nacimiento'];
        if (isset($data['direccion']))       $sanitized['direccion'] = sanitize_textarea_field($data['direccion']);
        if (isset($data['estado_civil']))    $sanitized['estado_civil'] = strtoupper(sanitize_text_field($data['estado_civil']));
        if (isset($data['fecha_inicio_laboral']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $data['fecha_inicio_laboral'])) $sanitized['fecha_inicio_laboral'] = $data['fecha_inicio_laboral'];
        if (isset($data['fecha_fin_laboral']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $data['fecha_fin_laboral'])) $sanitized['fecha_fin_laboral'] = $data['fecha_fin_laboral'];
        if (isset($data['foto_id']))         $sanitized['foto_id'] = intval($data['foto_id']);
        if (isset($data['user_id']))         $sanitized['user_id'] = intval($data['user_id']);
        if (isset($data['tarea']))           $sanitized['tarea'] = intval($data['tarea']);
        if (isset($data['area']))            $sanitized['area'] = intval($data['area']);

        // Nuevo: Antigüedad reconocida (siempre INT, entre 0 y 50)
        if (isset($data['antiguedad_reconocida'])) {
            $ant = intval($data['antiguedad_reconocida']);
            if ($ant < 0) $ant = 0;
            if ($ant > 50) $ant = 50;
            $sanitized['antiguedad_reconocida'] = $ant;
        }

        return $sanitized;
    }

    public function insert($data) {
        $data = $this->sanitizar_data($data);

        $dni   = $data['dni'] ?? '';
        $cuil  = $data['cuil'] ?? '';
        $email = $data['email'] ?? '';

        $existe = $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT id FROM {$this->table_name} WHERE dni = %s OR cuil = %s OR email = %s",
            $dni, $cuil, $email
        ));

        if ($existe) {
            return new \WP_Error('empleado_duplicado', __('Ya existe un empleado con el mismo DNI, CUIL o Email.', 'midas-rrhh'));
        }

        $data['created_by'] = get_current_user_id();
        $result = $this->wpdb->insert($this->table_name, $data);

        if ($result === false) {
            return false;
        }

        return $this->wpdb->insert_id;
    }

    public function update($id, $data) {
        $data = $this->sanitizar_data($data);

        $data['updated_at'] = current_time('mysql');
        $data['updated_by'] = get_current_user_id();

        $where = [ 'id' => intval($id) ];
        return $this->wpdb->update($this->table_name, $data, $where);
    }

    public function get($id) {
        // Siempre devolver con nombres de área, tarea y user_login, antigüedad y fecha_fin_laboral
        return $this->get_by_id_con_area_y_tarea($id);
    }

    public function get_all($activos_only = true) {
        return $this->obtener_empleados_con_area_y_tarea_ordenados();
    }

    public function obtener_empleados_con_area_y_tarea($activos_only = false) {
        $where = $activos_only ? "WHERE e.activo = 1" : "";
        $query = "
            SELECT e.*, a.nombre AS area_nombre, t.nombre AS tarea_nombre, e.antiguedad_reconocida, e.fecha_fin_laboral
            FROM {$this->table_name} e
            LEFT JOIN {$this->wpdb->prefix}midas_areas a ON e.area = a.id
            LEFT JOIN {$this->wpdb->prefix}midas_tareas t ON e.tarea = t.id
            $where
            ORDER BY e.apellido ASC, e.nombre ASC
        ";
        $result = $this->wpdb->get_results($query);
        foreach ($result as $emp) {
            $emp->foto_url = $emp->foto_id ? wp_get_attachment_url($emp->foto_id) : '';
            if (!empty($emp->user_id)) {
                $user = get_userdata($emp->user_id);
                $emp->user_login = $user ? $user->user_login : '';
            } else {
                $emp->user_login = '';
            }
        }
        return $result;
    }

    public function obtener_empleados_con_area_y_tarea_ordenados() {
        return $this->obtener_empleados_con_area_y_tarea(false);
    }

    /**
     * Obtener empleado por ID y devolver también nombre de área y tarea (usado en AJAX)
     */
    public function get_by_id_con_area_y_tarea($id) {
        $query = $this->wpdb->prepare("
            SELECT e.*, a.nombre AS area_nombre, t.nombre AS tarea_nombre, e.antiguedad_reconocida, e.fecha_fin_laboral
            FROM {$this->table_name} e
            LEFT JOIN {$this->wpdb->prefix}midas_areas a ON e.area = a.id
            LEFT JOIN {$this->wpdb->prefix}midas_tareas t ON e.tarea = t.id
            WHERE e.id = %d
            LIMIT 1
        ", $id);
        $emp = $this->wpdb->get_row($query);
        if ($emp) {
            $emp->foto_url = $emp->foto_id ? wp_get_attachment_url($emp->foto_id) : '';
            if (!empty($emp->user_id)) {
                $user = get_userdata($emp->user_id);
                $emp->user_login = $user ? $user->user_login : '';
            } else {
                $emp->user_login = '';
            }
        }
        return $emp;
    }

    /**
     * Obtener empleado por user_id de usuario WP (para frontend)
     */
    public function get_by_user_id($user_id) {
        // Devuelve con area_nombre y tarea_nombre siempre
        $emp_id = $this->wpdb->get_var($this->wpdb->prepare("SELECT id FROM {$this->table_name} WHERE user_id = %d LIMIT 1", $user_id));
        return $emp_id ? $this->get_by_id_con_area_y_tarea($emp_id) : null;
    }
}
