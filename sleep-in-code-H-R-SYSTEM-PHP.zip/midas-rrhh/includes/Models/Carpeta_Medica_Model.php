<?php
namespace MidasRRHH\Models;

if (!defined('ABSPATH')) exit;

class Carpeta_Medica_Model extends Base_Model {
    protected $table = 'midas_carpeta_medica';
    protected $primary_key = 'id';
    protected $allowed_fields = [
        'empleado_id',
        'motivo_id',           // Ahora referencia a midas_enfermedades
        'medico_id',
        'documento_id',
        'fecha_solicitud',
        'fecha_emision',
        'dias_aprobados',
        'dias_solicitados',
        'estado_id',
        'observaciones',
        'fecha_vencimiento',
        'gestor_id',
        'created_at',
        'updated_at',
        'documento_url'
    ];

    public function __construct() {
        parent::__construct();
        global $wpdb;
        $this->wpdb = $wpdb;
    }

    public function get($id) {
        error_log("[MODELO][get] id=$id");
        return $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->wpdb->prefix}{$this->table} WHERE {$this->primary_key} = %d",
                $id
            )
        );
    }

    public function get_by_empleado($empleado_id) {
        error_log("[MODELO][get_by_empleado] empleado_id=$empleado_id");
        return $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->wpdb->prefix}{$this->table} WHERE empleado_id = %d ORDER BY fecha_solicitud DESC",
                $empleado_id
            )
        );
    }

    public function get_with_empleado($id) {
        error_log("[MODELO][get_with_empleado] id=$id");
        $table      = $this->wpdb->prefix . $this->table;
        $empleados  = $this->wpdb->prefix . 'midas_empleados';
        $enfermedad = $this->wpdb->prefix . 'midas_enfermedades';
        $medicos    = $this->wpdb->prefix . 'midas_medicos';
        $estados    = $this->wpdb->prefix . 'midas_estados_carpeta_medica';

        $query = $this->wpdb->prepare("
            SELECT cm.*,
                   CONCAT(e.nombre, ' ', e.apellido) AS empleado_nombre,
                   CONCAT(enf.tipo, IF(enf.descripcion != '', CONCAT(' — ', enf.descripcion), '')) AS motivo_descripcion,
                   CONCAT(m.nombre, ' ', m.apellido) AS medico_nombre,
                   es.descripcion AS estado_descripcion
            FROM $table cm
            LEFT JOIN $empleados e  ON cm.empleado_id = e.id
            LEFT JOIN $enfermedad enf ON cm.motivo_id = enf.id
            LEFT JOIN $medicos m    ON cm.medico_id = m.id
            LEFT JOIN $estados es   ON cm.estado_id = es.id
            WHERE cm.{$this->primary_key} = %d
            LIMIT 1
        ", $id);

        $doc = $this->wpdb->get_row($query);

        // AGREGADO: documento_url
        if ($doc && isset($doc->documento_id) && $doc->documento_id) {
            $doc->documento_url = wp_get_attachment_url($doc->documento_id);
        } else {
            $doc->documento_url = null;
        }

        return $doc;
    }

    public function get_por_estado_con_empleado($estado_id) {
        error_log("[MODELO][get_por_estado_con_empleado] estado_id=$estado_id");
        $table      = $this->wpdb->prefix . $this->table;
        $empleados  = $this->wpdb->prefix . 'midas_empleados';
        $enfermedad = $this->wpdb->prefix . 'midas_enfermedades';
        $medicos    = $this->wpdb->prefix . 'midas_medicos';
        $estados    = $this->wpdb->prefix . 'midas_estados_carpeta_medica';

        $query = $this->wpdb->prepare("
            SELECT cm.*,
                   CONCAT(e.nombre, ' ', e.apellido) AS empleado_nombre,
                   CONCAT(enf.tipo, IF(enf.descripcion != '', CONCAT(' — ', enf.descripcion), '')) AS motivo_descripcion,
                   CONCAT(m.nombre, ' ', m.apellido) AS medico_nombre,
                   es.descripcion AS estado_descripcion
            FROM $table cm
            LEFT JOIN $empleados e  ON cm.empleado_id = e.id
            LEFT JOIN $enfermedad enf ON cm.motivo_id = enf.id
            LEFT JOIN $medicos m    ON cm.medico_id = m.id
            LEFT JOIN $estados es   ON cm.estado_id = es.id
            WHERE cm.estado_id = %d
            ORDER BY cm.fecha_solicitud DESC
        ", $estado_id);

        $docs = $this->wpdb->get_results($query);

        // AGREGADO: documento_url para cada uno
        foreach ($docs as $doc) {
            if ($doc && isset($doc->documento_id) && $doc->documento_id) {
                $doc->documento_url = wp_get_attachment_url($doc->documento_id);
            } else {
                $doc->documento_url = null;
            }
        }

        return $docs;
    }

    public function get_all_con_empleado() {
        error_log("[MODELO][get_all_con_empleado]");
        $table      = $this->wpdb->prefix . $this->table;
        $empleados  = $this->wpdb->prefix . 'midas_empleados';
        $enfermedad = $this->wpdb->prefix . 'midas_enfermedades';
        $medicos    = $this->wpdb->prefix . 'midas_medicos';
        $estados    = $this->wpdb->prefix . 'midas_estados_carpeta_medica';

        $query = "
            SELECT cm.*,
                   CONCAT(e.nombre, ' ', e.apellido) AS empleado_nombre,
                   CONCAT(enf.tipo, IF(enf.descripcion != '', CONCAT(' — ', enf.descripcion), '')) AS motivo_descripcion,
                   CONCAT(m.nombre, ' ', m.apellido) AS medico_nombre,
                   es.descripcion AS estado_descripcion
            FROM $table cm
            LEFT JOIN $empleados e  ON cm.empleado_id = e.id
            LEFT JOIN $enfermedad enf ON cm.motivo_id = enf.id
            LEFT JOIN $medicos m    ON cm.medico_id = m.id
            LEFT JOIN $estados es   ON cm.estado_id = es.id
            ORDER BY cm.fecha_solicitud DESC
        ";

        $docs = $this->wpdb->get_results($query);

        // AGREGADO: documento_url para cada uno
        foreach ($docs as $doc) {
            if ($doc && isset($doc->documento_id) && $doc->documento_id) {
                $doc->documento_url = wp_get_attachment_url($doc->documento_id);
            } else {
                $doc->documento_url = null;
            }
        }

        return $docs;
    }

    // CRUD
    public function insert($data) {
        error_log("[MODELO][insert] data=" . json_encode($data));
        $insert_data = array_intersect_key($data, array_flip($this->allowed_fields));
        $result = $this->wpdb->insert("{$this->wpdb->prefix}{$this->table}", $insert_data);
        error_log("[MODELO][insert] result=" . var_export($result, true));
        if ($result === false) {
            error_log("[MODELO][insert] ERROR al insertar datos");
            return new \WP_Error('db_error', __('Error al insertar los datos', 'midas-rrhh'));
        }
        return $this->wpdb->insert_id;
    }

    public function update($id, $data) {
        error_log("[MODELO][update] id=$id data=" . json_encode($data));
        $update_data = array_intersect_key($data, array_flip($this->allowed_fields));
        error_log("[MODELO][update] Campos permitidos: " . json_encode(array_keys($update_data)));
        $result = $this->wpdb->update(
            "{$this->wpdb->prefix}{$this->table}",
            $update_data,
            [$this->primary_key => $id]
        );
        error_log("[MODELO][update] resultado update: " . var_export($result, true));
        if ($result === false) {
            error_log("[MODELO][update] ERROR DB");
            return new \WP_Error('db_error', __('Error al actualizar los datos', 'midas-rrhh'));
        }
        return true;
    }

    // Métodos utilitarios adicionales (empleados, médicos, motivos, áreas, etc)
    public function get_all_medicos() {
        $table = $this->wpdb->prefix . 'midas_medicos';
        return $this->wpdb->get_results("SELECT * FROM $table WHERE id > 0 ORDER BY nombre ASC");
    }

    // DEVUELVE TIPOS DE ENFERMEDADES (no motivos viejos)
    public function get_all_motivos() {
        $table = $this->wpdb->prefix . 'midas_enfermedades';
        return $this->wpdb->get_results("SELECT * FROM $table WHERE id > 0 ORDER BY tipo ASC");
    }

    public function get_all_empleado_areas() {
        $table     = $this->wpdb->prefix . 'midas_empleado_area';
        $empleados = $this->wpdb->prefix . 'midas_empleados';
        $areas     = $this->wpdb->prefix . 'midas_areas';
        return $this->wpdb->get_results("
            SELECT ea.id, ea.empleado_id, ea.area_id, 
                   e.nombre AS empleado_nombre, 
                   a.nombre AS area_nombre
            FROM $table ea
            LEFT JOIN $empleados e ON ea.empleado_id = e.id
            LEFT JOIN $areas a ON ea.area_id = a.id
            ORDER BY ea.id ASC
        ");
    }

    public function add_empleado_area($empleado_id, $area_id) {
        $table = $this->wpdb->prefix . 'midas_empleado_area';
        return $this->wpdb->insert($table, [
            'empleado_id' => intval($empleado_id),
            'area_id'     => intval($area_id)
        ], ['%d', '%d']);
    }

    public function update_empleado_area($id, $empleado_id, $area_id) {
        $table = $this->wpdb->prefix . 'midas_empleado_area';
        return $this->wpdb->update($table, [
            'empleado_id' => intval($empleado_id),
            'area_id'     => intval($area_id)
        ], ['id' => intval($id)], ['%d', '%d'], ['%d']);
    }

    public function delete_empleado_area($id) {
        $table = $this->wpdb->prefix . 'midas_empleado_area';
        return $this->wpdb->delete($table, ['id' => intval($id)], ['%d']);
    }
}
