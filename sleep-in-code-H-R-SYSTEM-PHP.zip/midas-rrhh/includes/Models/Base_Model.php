<?php
namespace MidasRRHH\Models;

abstract class Base_Model {
    protected $table;
    protected $primary_key = 'id';
    protected $wpdb;
    protected $allowed_fields = [];

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
    }

    public function get($id) {
        return $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->wpdb->prefix}{$this->table} WHERE {$this->primary_key} = %d",
                $id
            )
        );
    }

    public function insert($data) {
        $data = $this->sanitize_data($data);
        $this->wpdb->insert("{$this->wpdb->prefix}{$this->table}", $data);
        return $this->wpdb->insert_id;
    }

    public function update($id, $data) {
        $data = $this->sanitize_data($data);
        return $this->wpdb->update(
            "{$this->wpdb->prefix}{$this->table}",
            $data,
            [$this->primary_key => $id]
        );
    }

    public function delete($id) {
        return $this->wpdb->delete(
            "{$this->wpdb->prefix}{$this->table}",
            [$this->primary_key => $id]
        );
    }

    protected function sanitize_data($data) {
        $sanitized = [];
        foreach ($data as $key => $value) {
            if (in_array($key, $this->allowed_fields)) {
                $sanitized[$key] = $this->sanitize_field($key, $value);
            }
        }
        return $sanitized;
    }

    protected function sanitize_field($key, $value) {
        if (is_string($value)) {
            return sanitize_text_field($value);
        } elseif (is_int($value)) {
            return intval($value);
        } elseif (is_float($value)) {
            return floatval($value);
        } elseif (is_array($value)) {
            return array_map('sanitize_text_field', $value);
        }
        return $value;
    }
}
