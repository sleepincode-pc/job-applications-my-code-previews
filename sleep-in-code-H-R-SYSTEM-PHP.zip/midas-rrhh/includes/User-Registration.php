<?php
// File: includes/User-Registration.php

// Mostrar campos adicionales en el formulario de registro
add_action('register_form', 'midas_agregar_campos_personalizados');
function midas_agregar_campos_personalizados() {
    ?>
    <p><label for="dni">DNI<br><input type="text" name="dni" id="dni" class="input" required></label></p>
    <p><label for="cuil">CUIL<br><input type="text" name="cuil" id="cuil" class="input" required></label></p>
    <p><label for="nombre">Nombre<br><input type="text" name="nombre" id="nombre" class="input" required></label></p>
    <p><label for="apellido">Apellido<br><input type="text" name="apellido" id="apellido" class="input" required></label></p>
    <p><label for="email">Email<br><input type="email" name="email" id="email" class="input" required></label></p>
    <p><label for="telefono">Teléfono<br><input type="text" name="telefono" id="telefono" class="input"></label></p>
    <p><label for="fecha_nacimiento">Fecha de Nacimiento<br><input type="date" name="fecha_nacimiento" id="fecha_nacimiento" required></label></p>
    <p><label for="domicilio">Domicilio<br><input type="text" name="domicilio" id="domicilio"></label></p>
    <p><label for="estado_civil">Estado Civil<br><input type="text" name="estado_civil" id="estado_civil"></label></p>
    <p><label for="fecha_inicio_laboral">Fecha Inicio Laboral<br><input type="date" name="fecha_inicio_laboral" id="fecha_inicio_laboral" required></label></p>
    <?php
}

// Validar campos personalizados del registro
add_filter('registration_errors', 'midas_validar_campos_personalizados', 10, 3);
function midas_validar_campos_personalizados($errors, $sanitized_user_login, $user_email) {
    $required_fields = ['dni', 'cuil', 'nombre', 'apellido', 'email', 'fecha_nacimiento', 'fecha_inicio_laboral'];

    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            $errors->add('missing_' . $field, "<strong>Error</strong>: El campo $field es obligatorio.");
        }
    }

    return $errors;
}

// Guardar campos personalizados y auto login
add_action('user_register', 'midas_guardar_datos_usuario_personalizados', 10, 1);
function midas_guardar_datos_usuario_personalizados($user_id) {
    global $wpdb;
    $tabla = $wpdb->prefix . 'midas_empleados';

    $dni = sanitize_text_field($_POST['dni']);
    $cuil = sanitize_text_field($_POST['cuil']);
    $nombre = sanitize_text_field($_POST['nombre']);
    $apellido = sanitize_text_field($_POST['apellido']);
    $email = sanitize_email($_POST['email']);
    $telefono = sanitize_text_field($_POST['telefono']);
    $fecha_nacimiento = sanitize_text_field($_POST['fecha_nacimiento']);
    $direccion = sanitize_textarea_field($_POST['domicilio']);
    $estado_civil = sanitize_text_field($_POST['estado_civil']);
    $fecha_inicio_laboral = sanitize_text_field($_POST['fecha_inicio_laboral']);

    // Valores por defecto (podés modificarlos para capturarlos más adelante)
    $foto_id = null;
    $cv_id = null;
    $tarea_id = null;
    $area_id = null;

    // Guardar en user_meta (opcional)
    update_user_meta($user_id, 'dni', $dni);
    update_user_meta($user_id, 'cuil', $cuil);
    update_user_meta($user_id, 'nombre', $nombre);
    update_user_meta($user_id, 'apellido', $apellido);
    update_user_meta($user_id, 'email', $email);
    update_user_meta($user_id, 'telefono', $telefono);
    update_user_meta($user_id, 'fecha_nacimiento', $fecha_nacimiento);
    update_user_meta($user_id, 'domicilio', $direccion);
    update_user_meta($user_id, 'estado_civil', $estado_civil);
    update_user_meta($user_id, 'fecha_inicio_laboral', $fecha_inicio_laboral);

    // Insertar en tabla personalizada
    $wpdb->insert($tabla, [
        'user_id' => $user_id,
        'dni' => $dni,
        'cuil' => $cuil,
        'nombre' => $nombre,
        'apellido' => $apellido,
        'email' => $email,
        'telefono' => $telefono,
        'fecha_nacimiento' => $fecha_nacimiento,
        'foto_id' => $foto_id,
        'direccion' => $direccion,
        'estado_civil' => $estado_civil,
        'cv_id' => $cv_id,
        'fecha_inicio_laboral' => $fecha_inicio_laboral,
        'tarea_id' => $tarea_id,
        'area_id' => $area_id,
        'activo' => 1,
        'created_at' => current_time('mysql'),
        'updated_at' => current_time('mysql'),
    ]);

    // Auto login
    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id);
}
