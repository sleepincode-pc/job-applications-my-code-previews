<?php
namespace MidasRRHH\Ajax;

if (!defined('ABSPATH')) exit;

use MidasRRHH\Controllers\Empleado_Controller;
use MidasRRHH\Controllers\Recibo_Controller;
use MidasRRHH\Controllers\Licencia_Controller;
use MidasRRHH\Controllers\Carpeta_Medica_Controller;
use MidasRRHH\Controllers\Ticket_Controller;
use MidasRRHH\Core\Security;

// ==== Funciones de limpieza de cache ====

// Licencias
if (!function_exists('MidasRRHH\Ajax\midas_clear_licencias_cache')) {
    function midas_clear_licencias_cache() {
        delete_transient('midas_licencias_cache');
        delete_transient('midas_licencias_pendientes');
        delete_transient('midas_licencias_aprobadas');
        delete_transient('midas_licencias_rechazadas');
        delete_transient('midas_licencias_historial');
    }
}

// Empleados
if (!function_exists('MidasRRHH\Ajax\midas_clear_empleados_cache')) {
    function midas_clear_empleados_cache() {
        delete_transient('midas_empleados_cache');
        delete_transient('midas_empleados_paginados');
        delete_transient('midas_empleados_areas');
        delete_transient('midas_empleados_tareas');
    }
}

// Recibos
if (!function_exists('MidasRRHH\Ajax\midas_clear_recibos_cache')) {
    function midas_clear_recibos_cache() {
        delete_transient('midas_recibos_cache');
        delete_transient('midas_recibos_empleado');
    }
}

// Tickets
if (!function_exists('MidasRRHH\Ajax\midas_clear_tickets_cache')) {
    function midas_clear_tickets_cache() {
        delete_transient('midas_tickets_cache');
        delete_transient('midas_tickets_dashboard');
    }
}

// Carpeta médica
if (!function_exists('MidasRRHH\Ajax\midas_clear_carpeta_medica_cache')) {
    function midas_clear_carpeta_medica_cache() {
        delete_transient('midas_carpeta_medica_cache');
        delete_transient('midas_documentos_pendientes');
        delete_transient('midas_documentos_aprobados');
        delete_transient('midas_documentos_rechazados');
        delete_transient('midas_documentos_historial');
    }
}

class Ajax_Handler {
    private static $instance = null;
    private $security;

    private function __construct() {
        $this->security = new Security();
        $this->init_ajax_handlers();
    }

    private function __clone() {}
    public function __wakeup() {}

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public static function init() {
        self::get_instance();
    }
private function init_ajax_handlers() {
    /** Fallback 501 si no existe el método */
    $missing = function () {
        wp_send_json_error(['message' => __('Endpoint no disponible o no implementado.', 'midas-rrhh')], 501);
    };

    /** Toma el primer callback existente o usa $missing */
    $pick_cb = function (array $candidates) use ($missing) {
        foreach ($candidates as $m) {
            if (is_callable([self::class, $m])) {
                return [self::class, $m];
            }
        }
        return $missing;
    };

    // ===== CONFIGURACIÓN (listas + CRUD ligero)
    add_action('wp_ajax_midas_cfg_list',               $pick_cb(['cfg_list']));
    add_action('wp_ajax_midas_agregar_configuracion',  $pick_cb(['cfg_guardar']));
    add_action('wp_ajax_midas_editar_configuracion',   $pick_cb(['cfg_guardar']));
    add_action('wp_ajax_midas_eliminar_configuracion', $pick_cb(['cfg_eliminar']));

    // ===== EMPLEADOS
    add_action('wp_ajax_midas_crear_empleado',        $pick_cb(['crear_empleado']));
    add_action('wp_ajax_midas_actualizar_empleado',   $pick_cb(['actualizar_empleado']));
    add_action('wp_ajax_midas_editar_empleado',       $pick_cb(['actualizar_empleado'])); // alias
    add_action('wp_ajax_midas_eliminar_empleado',     $pick_cb(['eliminar_empleado']));
    add_action('wp_ajax_midas_obtener_empleado',      $pick_cb(['obtener_empleado']));
    add_action('wp_ajax_midas_buscar_empleados',      $pick_cb(['buscar_empleados']));
    add_action('wp_ajax_midas_guardar_nota_empleado', $pick_cb(['guardar_nota_empleado']));
    add_action('wp_ajax_midas_get_nota_empleado',     $pick_cb(['get_nota_empleado']));

    // ===== RECIBOS
    add_action('wp_ajax_midas_obtener_recibos_ajax',     $pick_cb(['obtener_recibos_ajax']));
    add_action('wp_ajax_midas_generar_recibo',           $pick_cb(['generar_recibo']));
    add_action('wp_ajax_midas_obtener_recibos_empleado', $pick_cb(['obtener_recibos_empleado']));
    add_action('wp_ajax_midas_obtener_recibo',           $pick_cb(['obtener_recibo']));
    add_action('wp_ajax_midas_eliminar_recibo',          $pick_cb(['eliminar_recibo']));
    add_action('wp_ajax_midas_crear_recibo_frontend',    $pick_cb(['crear_recibo_frontend']));

    // ===== LICENCIAS
    add_action('wp_ajax_midas_crear_licencia',    $pick_cb(['ajax_crear_licencia']));
    add_action('wp_ajax_midas_editar_licencia',   $pick_cb(['ajax_editar_licencia']));
    add_action('wp_ajax_midas_aprobar_licencia',  $pick_cb(['ajax_aprobar_licencia']));
    add_action('wp_ajax_midas_rechazar_licencia', $pick_cb(['ajax_rechazar_licencia']));
    add_action('wp_ajax_midas_eliminar_licencia', $pick_cb(['ajax_eliminar_licencia']));
    add_action('wp_ajax_midas_lic_listar',        $pick_cb(['ajax_lic_listar']));

    // ===== CARPETA MÉDICA (CRUD + listados)
    add_action('wp_ajax_midas_crear_documento_medico',        $pick_cb(['crear_documento_medico']));
    add_action('wp_ajax_nopriv_midas_crear_documento_medico', $pick_cb(['crear_documento_medico']));
    add_action('wp_ajax_midas_crear_medico',                   $pick_cb(['ajax_crear_medico']));
    add_action('wp_ajax_nopriv_midas_crear_medico',            $pick_cb(['ajax_crear_medico']));
    add_action('wp_ajax_midas_editar_documento_medico',        $pick_cb(['editar_documento_medico']));
    add_action('wp_ajax_midas_aprobar_documento_medico',       $pick_cb(['aprobar_documento_medico']));
    add_action('wp_ajax_midas_rechazar_documento_medico',      $pick_cb(['rechazar_documento_medico']));
    add_action('wp_ajax_midas_obtener_documentos_empleado',    $pick_cb(['obtener_documentos_empleado']));
    add_action('wp_ajax_midas_obtener_documento_medico',       $pick_cb(['obtener_documento_medico']));
    add_action('wp_ajax_midas_obtener_documentos_pendientes',  $pick_cb(['obtener_documentos_pendientes']));
    add_action('wp_ajax_midas_obtener_documentos_aprobados',   $pick_cb(['obtener_documentos_aprobados']));
    add_action('wp_ajax_midas_obtener_documentos_rechazados',  $pick_cb(['obtener_documentos_rechazados']));
    add_action('wp_ajax_midas_obtener_historial_documentos',   $pick_cb(['obtener_historial_documentos']));
    add_action('wp_ajax_midas_cm_listar_docs',                 $pick_cb(['cm_listar_docs']));

    // ===== DOCUMENTACIÓN CON VENCIMIENTO — Listas
    add_action('wp_ajax_midas_docv_listar',       $pick_cb(['docv_listar']));
    add_action('wp_ajax_midas_docv_tipos_listar', $pick_cb(['docv_tipos_listar']));

    // ===== DOCUMENTACIÓN CON VENCIMIENTO — Tipos (nuevos + alias)
    add_action('wp_ajax_midas_docv_tipo_guardar',  $pick_cb(['docv_tipo_guardar']));
    add_action('wp_ajax_midas_docv_tipo_eliminar', $pick_cb(['docv_tipo_eliminar']));
    add_action('wp_ajax_midas_doc_tipo_crear',     $pick_cb(['docv_tipo_guardar']));
    add_action('wp_ajax_midas_doc_tipo_editar',    $pick_cb(['docv_tipo_guardar']));
    add_action('wp_ajax_midas_doc_tipo_eliminar',  $pick_cb(['docv_tipo_eliminar']));

    // ===== DOCUMENTACIÓN CON VENCIMIENTO — Documentos
    add_action('wp_ajax_midas_doc_crear',    $pick_cb(['doc_crear']));
    add_action('wp_ajax_midas_doc_editar',   $pick_cb(['doc_editar']));
    add_action('wp_ajax_midas_doc_eliminar', $pick_cb(['doc_eliminar']));

    // ===== TICKETS
    add_action('wp_ajax_midas_crear_ticket',        $pick_cb(['crear_ticket']));
    add_action('wp_ajax_nopriv_midas_crear_ticket', $pick_cb(['crear_ticket']));
    add_action('wp_ajax_midas_responder_ticket',    $pick_cb(['responder_ticket']));
    add_action('wp_ajax_midas_rechazar_ticket',     $pick_cb(['rechazar_ticket']));
    add_action('wp_ajax_midas_obtener_tickets',     $pick_cb(['obtener_tickets']));

    // ===== PALETA (scoped al plugin) — endpoints + alias compat
    add_action('wp_ajax_midas_palette_get',         $pick_cb(['palette_get']));
    add_action('wp_ajax_midas_palette_save',        $pick_cb(['palette_save']));
    add_action('wp_ajax_midas_get_palette_scoped',  $pick_cb(['palette_get']));   // alias compat
    add_action('wp_ajax_midas_save_palette_scoped', $pick_cb(['palette_save']));  // alias compat

    // ===== DASHBOARD: conectados dentro de Midas RRHH
    add_action('wp_ajax_midas_dash_ping',        $pick_cb(['dash_ping']));        // marca al usuario como "activo"
    add_action('wp_ajax_midas_dash_conectados',  $pick_cb(['dash_conectados']));  // devuelve lista/conteo de conectados

    // ===== ORGANIGRAMA (nuevo: centralizamos handlers aquí)
    add_action('wp_ajax_midas_orgchart_get',  $pick_cb(['orgchart_get']));
    add_action('wp_ajax_midas_orgchart_save', $pick_cb(['orgchart_save']));
}







    /**
     * Verificación de nonce flexible: acepta 1 acción o un array de acciones válidas.
     * Busca el token en 'nonce' o 'midas_empleados_nonce'.
     */
    private static function verify_request($nonce_action) {
        if (defined('DOING_AJAX') && DOING_AJAX) { @ini_set('display_errors', 0); }

        $actions = is_array($nonce_action) ? $nonce_action : [$nonce_action];
        $tokens  = [
            $_POST['nonce'] ?? null,
            $_GET['nonce'] ?? null,
            $_POST['midas_empleados_nonce'] ?? null,
            $_GET['midas_empleados_nonce'] ?? null,
        ];

        $ok = false;
        foreach ($tokens as $t) {
            if (!$t) continue;
            foreach ($actions as $act) {
                if (wp_verify_nonce($t, $act)) { $ok = true; break 2; }
            }
        }
        if (!$ok) {
            wp_send_json_error(['message' => __('Nonce inválido.', 'midas-rrhh')], 403);
        }
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Debes iniciar sesión para realizar esta acción', 'midas-rrhh')], 401);
        }
    }

    // ✅ Permite listar sin nonce (solo lectura) pero exige login
    private static function verify_read_only() {
        if (defined('DOING_AJAX') && DOING_AJAX) { @ini_set('display_errors', 0); }
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Debes iniciar sesión.', 'midas-rrhh')], 401);
        }
    }

    private static function verify_request_front($nonce_field, $nonce_action) {
        if (!isset($_POST[$nonce_field]) || !wp_verify_nonce($_POST[$nonce_field], $nonce_action)) {
            wp_send_json_error(['message' => 'Nonce inválido. Intenta refrescar la página.'], 403);
        }
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'Debes iniciar sesión para realizar esta acción'], 401);
        }
    }

    /**
     * Normaliza textos (respuesta/motivo/observaciones).
     */
    private static function normalize_observaciones($text, $maxLen = 2000) {
        $t = is_string($text) ? $text : '';
        if (class_exists('\Normalizer')) {
            $t = \Normalizer::normalize($t, \Normalizer::FORM_KC);
            if ($t === false) { $t = (string)$text; }
        }
        $t = preg_replace('/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $t); // zero-width
        $t = preg_replace('/[\x{00A0}\x{1680}\x{2000}-\x{200A}\x{202F}\x{205F}\x{3000}]/u', ' ', $t); // espacios raros
        $t = preg_replace('/\s+/u', ' ', $t);
        $t = trim($t);
        if (function_exists('mb_strtoupper')) $t = mb_strtoupper($t, 'UTF-8'); else $t = strtoupper($t);
        $t = preg_replace('/[^A-ZÁÉÍÓÚÑ0-9 .,:;¡!¿?\(\)\-_\/#+%]/u', '', $t);
        if ($maxLen > 0) $t = function_exists('mb_substr') ? mb_substr($t, 0, $maxLen, 'UTF-8') : substr($t, 0, $maxLen);
        return $t;
    }

    /* === NUEVO: parseo flexible de fechas -> 'Y-m-d' o null si inválida === */
    private static function parse_date_flex($s) {
        $s = trim((string)$s);
        if ($s === '') return null;

        // dd/mm/yyyy
        if (preg_match('/^(\d{2})\/(\d{2})\/(\d{4})$/', $s, $m)) {
            $d = (int)$m[1]; $M = (int)$m[2]; $y = (int)$m[3];
            if (checkdate($M, $d, $y)) return sprintf('%04d-%02d-%02d', $y, $M, $d);
            return null;
        }
        // yyyy-mm-dd
        if (preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $s, $m)) {
            $y = (int)$m[1]; $M = (int)$m[2]; $d = (int)$m[3];
            if (checkdate($M, $d, $y)) return sprintf('%04d-%02d-%02d', $y, $M, $d);
            return null;
        }
        // fallback strtotime (e.g. 2025/01/31, 31-01-2025, etc.)
        $ts = strtotime($s);
        if ($ts !== false) return date('Y-m-d', $ts);
        return null;
    }

    // ================== MÉTODOS ===================
    // --- EMPLEADOS ---
    public static function crear_empleado() {
        self::verify_request(['midas_empleados_nonce','midas_cm_nonce']);
        if (!current_user_can('rrhh_gestor') && !current_user_can('rrhh_admin') && !current_user_can('administrator')) {
            wp_send_json_error(['message' => __('No tienes permiso para crear empleados.', 'midas-rrhh')], 403);
        }

        $empleado_controller = new Empleado_Controller();
        $data = [
            'nombre'                => sanitize_text_field($_POST['nombre'] ?? ''),
            'apellido'              => sanitize_text_field($_POST['apellido'] ?? ''),
            'dni'                   => sanitize_text_field($_POST['dni'] ?? ''),
            'cuil'                  => sanitize_text_field($_POST['cuil'] ?? ''),
            'email'                 => sanitize_email($_POST['email'] ?? ''),
            'telefono'              => sanitize_text_field($_POST['telefono'] ?? ''),
            'fecha_nacimiento'      => sanitize_text_field($_POST['fecha_nacimiento'] ?? ''),
            'direccion'             => sanitize_textarea_field($_POST['direccion'] ?? ''),
            'estado_civil'          => sanitize_text_field($_POST['estado_civil'] ?? ''),
            'fecha_inicio_laboral'  => sanitize_text_field($_POST['fecha_inicio_laboral'] ?? ''),
            'fecha_fin_laboral'     => sanitize_text_field($_POST['fecha_fin_laboral'] ?? ''),
            'user_id'               => (intval($_POST['user_id'] ?? 0) ?: null),
            'area'                  => isset($_POST['area'])  ? intval($_POST['area'])  : 0,
            'tarea'                 => isset($_POST['tarea']) ? intval($_POST['tarea']) : 0,
        ];

        // Subida de imagen con media_handle_upload
        $foto_id = null;
        if (!empty($_FILES['foto']['name']) && (int)($_FILES['foto']['error'] ?? UPLOAD_ERR_OK) === UPLOAD_ERR_OK) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            $attachment_id = media_handle_upload('foto', 0);
            if (is_wp_error($attachment_id)) {
                wp_send_json_error(['message' => 'Error al subir la imagen: ' . $attachment_id->get_error_message()], 400);
            }
            $foto_id = (int) $attachment_id;
        }
        $data['foto_id'] = $foto_id;

        $result = $empleado_controller->crear_empleado($data);
        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()], 400);
        }

        $empleado_model = new \MidasRRHH\Models\Empleado_Model();
        $empleado = $empleado_model->get_by_id_con_area_y_tarea($result);
        if ($empleado) {
            $empleado->foto_url = $foto_id ? wp_get_attachment_url($foto_id) : '';
        }

        if (function_exists(__NAMESPACE__.'\\midas_clear_empleados_cache')) midas_clear_empleados_cache();

        wp_send_json_success([
            'message'  => __('Empleado creado correctamente', 'midas-rrhh'),
            'empleado' => $empleado
        ]);
    }

    public static function actualizar_empleado() {
        self::verify_request(['midas_empleados_nonce','midas_cm_nonce']);
        if (!current_user_can('rrhh_gestor') && !current_user_can('rrhh_admin') && !current_user_can('administrator')) {
            wp_send_json_error(['message' => __('No tienes permiso para editar empleados.', 'midas-rrhh')], 403);
        }

        $empleado_id = intval($_POST['empleado_id'] ?? $_POST['id'] ?? 0);
        if ($empleado_id <= 0) {
            wp_send_json_error(['message' => __('ID de empleado no válido', 'midas-rrhh')], 400);
        }

        $empleado_controller = new Empleado_Controller();
        $data = [
            'nombre'                => sanitize_text_field($_POST['nombre'] ?? ''),
            'apellido'              => sanitize_text_field($_POST['apellido'] ?? ''),
            'dni'                   => sanitize_text_field($_POST['dni'] ?? ''),
            'cuil'                  => sanitize_text_field($_POST['cuil'] ?? ''),
            'email'                 => sanitize_email($_POST['email'] ?? ''),
            'telefono'              => sanitize_text_field($_POST['telefono'] ?? ''),
            'fecha_nacimiento'      => sanitize_text_field($_POST['fecha_nacimiento'] ?? ''),
            'direccion'             => sanitize_textarea_field($_POST['direccion'] ?? ''),
            'estado_civil'          => sanitize_text_field($_POST['estado_civil'] ?? ''),
            'fecha_inicio_laboral'  => sanitize_text_field($_POST['fecha_inicio_laboral'] ?? ''),
            'fecha_fin_laboral'     => sanitize_text_field($_POST['fecha_fin_laboral'] ?? ''),
            'user_id'               => (intval($_POST['user_id'] ?? 0) ?: null),
            'area'                  => isset($_POST['area'])  ? intval($_POST['area'])  : 0,
            'tarea'                 => isset($_POST['tarea']) ? intval($_POST['tarea']) : 0,
        ];

        // Subida/actualización de foto
        if (!empty($_FILES['foto']['name']) && (int)($_FILES['foto']['error'] ?? UPLOAD_ERR_OK) === UPLOAD_ERR_OK) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            $attachment_id = media_handle_upload('foto', 0);
            if (is_wp_error($attachment_id)) {
                wp_send_json_error(['message' => 'Error al subir la imagen: ' . $attachment_id->get_error_message()], 400);
            }
            $data['foto_id'] = (int) $attachment_id;
        } elseif (!empty($_POST['foto_id_actual'])) {
            $data['foto_id'] = intval($_POST['foto_id_actual']);
        }

        $result = $empleado_controller->actualizar_empleado($empleado_id, $data);
        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()], 400);
        }

        $empleado_model = new \MidasRRHH\Models\Empleado_Model();
        $empleado = $empleado_model->get_by_id_con_area_y_tarea($empleado_id);
        if ($empleado) {
            $empleado->foto_url = $empleado->foto_id ? wp_get_attachment_url($empleado->foto_id) : '';
        }

        if (function_exists(__NAMESPACE__.'\\midas_clear_empleados_cache')) midas_clear_empleados_cache();

        wp_send_json_success([
            'message'  => __('Empleado actualizado correctamente', 'midas-rrhh'),
            'empleado' => $empleado
        ]);
    }

    public static function eliminar_empleado() {
        self::verify_request(['midas_empleados_nonce','midas_cm_nonce']);
        if (!current_user_can('rrhh_gestor') && !current_user_can('rrhh_admin') && !current_user_can('administrator')) {
            wp_send_json_error(['message' => __('No tienes permiso para eliminar empleados.', 'midas-rrhh')], 403);
        }
        $empleado_id = intval($_POST['empleado_id'] ?? 0);
        if (!$empleado_id) {
            wp_send_json_error(['message' => __('ID de empleado no válido', 'midas-rrhh')], 400);
        }
        $empleado_controller = new Empleado_Controller();
        $result = $empleado_controller->eliminar_empleado($empleado_id);

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()], 400);
        }

        if (function_exists(__NAMESPACE__.'\\midas_clear_empleados_cache')) midas_clear_empleados_cache();

        wp_send_json_success(['message' => __('Empleado eliminado correctamente', 'midas-rrhh')]);
    }

    public static function obtener_empleado() {
        self::verify_request(['midas_empleados_nonce','midas_cm_nonce']);
        $empleado_id = intval($_POST['empleado_id'] ?? $_GET['empleado_id'] ?? 0);
        if (!$empleado_id) {
            wp_send_json_error(['message' => __('ID de empleado no válido', 'midas-rrhh')], 400);
        }
        $empleado_controller = new Empleado_Controller();
        $empleado = $empleado_controller->obtener_empleado($empleado_id);
        if (is_wp_error($empleado)) {
            wp_send_json_error(['message' => $empleado->get_error_message()], 400);
        }
        if (!isset($empleado['estado_civil']) || !isset($empleado['fecha_inicio_laboral']) || !isset($empleado['fecha_fin_laboral'])) {
            global $wpdb;
            $tabla = $wpdb->prefix . 'midas_empleados';
            $datos_extra = $wpdb->get_row(
                $wpdb->prepare("SELECT estado_civil, fecha_inicio_laboral, fecha_fin_laboral FROM $tabla WHERE id = %d", $empleado_id),
                ARRAY_A
            );
            if ($datos_extra) $empleado = array_merge($empleado, $datos_extra);
        }
        wp_send_json_success($empleado);
    }

    public static function buscar_empleados() {
        self::verify_request(['midas_empleados_nonce','midas_cm_nonce']);
        $buscar = sanitize_text_field($_POST['buscar'] ?? '');
        $paged  = intval($_POST['paged'] ?? 1);

        $empleado_controller = new Empleado_Controller();
        $result = $empleado_controller->buscar_empleados_ajax($buscar, $paged);

        $empleados       = !empty($result['empleados']) ? $result['empleados'] : [];
        $areas_map       = !empty($result['areas_map']) ? $result['areas_map'] : [];
        $tareas_map      = !empty($result['tareas_map']) ? $result['tareas_map'] : [];
        $notas_empleados = !empty($result['notas_empleados']) ? $result['notas_empleados'] : [];
        $pagination      = $result['pagination'] ?? '';

        $html = '';
        try {
            ob_start();
            $GLOBALS['empleados']       = $empleados;
            $GLOBALS['areas_map']       = $areas_map;
            $GLOBALS['tareas_map']      = $tareas_map;
            $GLOBALS['notas_empleados'] = $notas_empleados;
            include MIDAS_RRHH_PLUGIN_DIR . 'templates/admin/partials/empleado-fila.php';
            $html = ob_get_clean();
        } catch (\Throwable $e) {
            if (ob_get_length()) { ob_end_clean(); }
            $html = '<tr><td colspan="16">Error interno al renderizar empleados.<br>' . esc_html($e->getMessage()) . '</td></tr>';
            error_log('[MidasRRHH][buscar_empleados] ERROR: ' . $e->getMessage());
        }

        wp_send_json_success(['html' => $html, 'pagination' => $pagination]);
    }

    public static function guardar_nota_empleado() {
        self::verify_request(['midas_empleados_nonce','midas_cm_nonce']);
        if (!current_user_can('rrhh_gestor') && !current_user_can('rrhh_admin') && !current_user_can('administrator')) {
            wp_send_json_error(['message' => __('No tienes permiso para editar notas.', 'midas-rrhh')], 403);
        }
        global $wpdb;
        $empleado_id = intval($_POST['empleado_id'] ?? 0);
        $nota        = sanitize_textarea_field($_POST['nota'] ?? '');
        if ($empleado_id) {
            $exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}midas_empleado_notas WHERE empleado_id = %d", $empleado_id));
            if ($exists) {
                $wpdb->update("{$wpdb->prefix}midas_empleado_notas", ['nota' => $nota], ['empleado_id' => $empleado_id]);
            } else {
                $wpdb->insert("{$wpdb->prefix}midas_empleado_notas", ['empleado_id' => $empleado_id, 'nota' => $nota]);
            }
            wp_send_json_success(['nota' => $nota]);
        }
        wp_send_json_error(['message' => 'Error al guardar la nota.']);
    }

    public static function get_nota_empleado() {
        self::verify_request(['midas_empleados_nonce','midas_cm_nonce']);
        global $wpdb;
        $empleado_id = intval($_GET['empleado_id'] ?? 0);
        $nota = '';
        if ($empleado_id) {
            $nota = $wpdb->get_var($wpdb->prepare("SELECT nota FROM {$wpdb->prefix}midas_empleado_notas WHERE empleado_id = %d", $empleado_id));
        }
        wp_send_json_success(['nota' => (string)$nota]);
    }

    // --------- RECIBOS ---------
    private static function can_manage_recibos() {
        return current_user_can('rrhh_gestor')
            || current_user_can('rrhh_admin')
            || current_user_can('manage_options')
            || is_super_admin();
    }

    public static function generar_recibo() { self::crear_recibo_frontend(); }

    public static function obtener_recibos_empleado() {
        check_ajax_referer('midas_recibos_nonce', 'nonce');
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Debes iniciar sesión.', 'midas-rrhh')], 401);
        }

        $empleado_id = intval($_POST['empleado_id'] ?? $_GET['empleado_id'] ?? 0);
        if ($empleado_id <= 0) {
            $empleado_model = new \MidasRRHH\Models\Empleado_Model();
            $emp = $empleado_model->get_by_user_id(get_current_user_id());
            if ($emp && !is_wp_error($emp)) $empleado_id = (int)$emp->id;
        }
        if ($empleado_id <= 0) {
            wp_send_json_error(['message' => __('Empleado no válido.', 'midas-rrhh')], 400);
        }

        $can_read_any = self::can_manage_recibos();
        if (!$can_read_any) {
            $empleado_model = new \MidasRRHH\Models\Empleado_Model();
            $emp = $empleado_model->get_by_user_id(get_current_user_id());
            if (!$emp || (int)$emp->id !== $empleado_id) {
                wp_send_json_error(['message' => __('No tienes permiso para ver estos recibos.', 'midas-rrhh')], 403);
            }
        }

        $recibos = null;
        if (class_exists(Recibo_Controller::class)) {
            try {
                $rc = new Recibo_Controller();
                if (method_exists($rc, 'obtener_recibos_empleado')) {
                    $recibos = $rc->obtener_recibos_empleado($empleado_id);
                    if (is_wp_error($recibos)) {
                        wp_send_json_error(['message' => $recibos->get_error_message()], 400);
                    }
                }
            } catch (\Throwable $e) { /* fallback abajo */ }
        }

        if ($recibos === null) {
            global $wpdb;
            $t = $wpdb->prefix . 'midas_recibos';
            $rows = $wpdb->get_results($wpdb->prepare("SELECT id, empleado_id, periodo, monto, detalles, archivo_id FROM $t WHERE empleado_id=%d ORDER BY id DESC", $empleado_id));
            $recibos = array_map(function($r){
                return [
                    'id' => (int)$r->id,
                    'empleado_id' => (int)$r->empleado_id,
                    'periodo' => (string)$r->periodo,
                    'monto' => (float)$r->monto,
                    'detalles' => (string)($r->detalles ?? ''),
                    'archivo_id' => (int)($r->archivo_id ?? 0),
                ];
            }, $rows ?: []);
        }

        wp_send_json_success(['recibos' => $recibos]);
    }

    public static function obtener_recibo() {
        check_ajax_referer('midas_recibos_nonce', 'nonce');
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Debes iniciar sesión.', 'midas-rrhh')], 401);
        }
        $id = intval($_POST['recibo_id'] ?? $_GET['recibo_id'] ?? 0);
        if ($id <= 0) wp_send_json_error(['message' => __('ID inválido.', 'midas-rrhh')], 400);

        $recibo = null;
        $empleado_id = 0;

        if (class_exists(Recibo_Controller::class)) {
            try {
                $rc = new Recibo_Controller();
                if (method_exists($rc, 'obtener_recibo')) {
                    $recibo = $rc->obtener_recibo($id);
                    if (is_wp_error($recibo)) {
                        wp_send_json_error(['message' => $recibo->get_error_message()], 400);
                    }
                    if (is_object($recibo)) {
                        $empleado_id = intval($recibo->empleado_id ?? 0);
                    } elseif (is_array($recibo)) {
                        $empleado_id = intval($recibo['empleado_id'] ?? 0);
                    }
                }
            } catch (\Throwable $e) { /* fallback abajo */ }
        }

        if ($recibo === null) {
            global $wpdb;
            $t = $wpdb->prefix . 'midas_recibos';
            $row = $wpdb->get_row($wpdb->prepare("SELECT id, empleado_id, periodo, monto, detalles, archivo_id FROM $t WHERE id=%d", $id));
            if (!$row) wp_send_json_error(['message' => __('No encontrado.', 'midas-rrhh')], 404);
            $recibo = [
                'id' => (int)$row->id,
                'empleado_id' => (int)$row->empleado_id,
                'periodo' => (string)$row->periodo,
                'monto' => (float)$row->monto,
                'detalles' => (string)($row->detalles ?? ''),
                'archivo_id' => (int)($row->archivo_id ?? 0),
            ];
            $empleado_id = (int)$row->empleado_id;
        }

        if (!self::can_manage_recibos()) {
            $empleado_model = new \MidasRRHH\Models\Empleado_Model();
            $emp = $empleado_model->get_by_user_id(get_current_user_id());
            if (!$emp || (int)$emp->id !== $empleado_id) {
                wp_send_json_error(['message' => __('No tienes permiso para ver este recibo.', 'midas-rrhh')], 403);
            }
        }

        wp_send_json_success(['recibo' => $recibo]);
    }

    public static function crear_recibo_frontend() {
        check_ajax_referer('midas_recibos_nonce', 'nonce');
        if (!is_user_logged_in() || !self::can_manage_recibos()) {
            wp_send_json_error(['message' => __('No tienes permiso para crear/editar recibos.', 'midas-rrhh')], 403);
        }

        global $wpdb;
        $tabla = $wpdb->prefix . 'midas_recibos';

        $recibo_id   = intval($_POST['edit_recibo_id'] ?? 0);
        $empleado_id = intval($_POST['empleado_id']    ?? 0);
        $periodo     = strtoupper(wp_strip_all_tags((string)($_POST['periodo'] ?? '')));
        $monto       = (float) str_replace(',', '.', (string)($_POST['monto'] ?? '0'));

        $detalles_raw = (string)($_POST['detalles'] ?? '');
        $detalles     = strtoupper(wp_strip_all_tags($detalles_raw));
        $detalles     = function_exists('mb_substr') ? mb_substr($detalles, 0, 600, 'UTF-8') : substr($detalles, 0, 600);

        if ($empleado_id <= 0) wp_send_json_error(['message' => __('Seleccioná un empleado.', 'midas-rrhh')], 400);
        $periodo = trim($periodo);
        if ($periodo === '' || strlen($periodo) > 32 || !preg_match('/^[A-ZÁÉÍÓÚÑ0-9 \-\/]+$/u', $periodo)) {
            wp_send_json_error(['message' => __('Periodo inválido.', 'midas-rrhh')], 400);
        }
        if ($monto < 0) wp_send_json_error(['message' => __('El monto es inválido.', 'midas-rrhh')], 400);

        $archivo_id = 0;
        if (!empty($_FILES['archivo_pdf']['name'])) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';

            add_filter('upload_mimes', function($m){ $m['pdf'] = 'application/pdf'; return $m; });
            $f = $_FILES['archivo_pdf'];
            $ok_size = (isset($f['size']) && (int)$f['size'] <= 8*1024*1024);
            $ok_ext  = isset($f['name']) && preg_match('/\.pdf$/i', $f['name']);
            if (!$ok_size || !$ok_ext) {
                wp_send_json_error(['message' => __('El archivo debe ser PDF y no superar 8 MB.', 'midas-rrhh')], 400);
            }

            $attachment_id = media_handle_upload('archivo_pdf', 0);
            if (is_wp_error($attachment_id)) {
                wp_send_json_error(['message' => 'No se pudo subir el PDF: ' . $attachment_id->get_error_message()], 500);
            }
            $archivo_id = (int)$attachment_id;
        }

        $data = [
            'empleado_id' => $empleado_id,
            'periodo'     => $periodo,
            'monto'       => $monto,
            'detalles'    => $detalles,
        ];
        $format = ['%d','%s','%f','%s'];
        if ($archivo_id) { $data['archivo_id'] = $archivo_id; $format[] = '%d'; }

        if ($recibo_id > 0) {
            $ok = $wpdb->update($tabla, $data, ['id' => $recibo_id], $format, ['%d']);
            if ($ok === false) wp_send_json_error(['message' => __('No se pudo actualizar el recibo.', 'midas-rrhh')], 500);
            if (function_exists(__NAMESPACE__.'\\midas_clear_recibos_cache')) midas_clear_recibos_cache();
            wp_send_json_success(['id' => $recibo_id]);
        } else {
            $ok = $wpdb->insert($tabla, $data, $format);
            if (!$ok) wp_send_json_error(['message' => __('No se pudo crear el recibo.', 'midas-rrhh')], 500);
            if (function_exists(__NAMESPACE__.'\\midas_clear_recibos_cache')) midas_clear_recibos_cache();
            wp_send_json_success(['id' => (int)$wpdb->insert_id]);
        }
    }

    public static function obtener_recibos_ajax() {
        if (!is_user_logged_in() || !self::can_manage_recibos()) {
            wp_send_json_error(['message' => __('No tienes permisos suficientes.', 'midas-rrhh')], 403);
        }

        global $wpdb;
        $t_rec  = $wpdb->prefix . 'midas_recibos';
        $t_emp  = $wpdb->prefix . 'midas_empleados';
        $buscar = strtoupper(wp_strip_all_tags((string)($_POST['buscar_recibo'] ?? '')));
        $buscar = trim($buscar);

        $sql = "
            SELECT r.id, r.empleado_id, r.periodo, r.monto, r.detalles, r.archivo_id,
                   CONCAT(COALESCE(e.nombre,''),' ',COALESCE(e.apellido,''),' - ',COALESCE(e.dni,'')) AS empleado_nombre
            FROM $t_rec r
            LEFT JOIN $t_emp e ON e.id = r.empleado_id
        ";
        $params = [];
        if ($buscar !== '') {
            $like = '%' . $wpdb->esc_like($buscar) . '%';
            $sql .= " WHERE
                UPPER(COALESCE(e.nombre,''))   LIKE %s OR
                UPPER(COALESCE(e.apellido,'')) LIKE %s OR
                UPPER(COALESCE(e.dni,''))      LIKE %s OR
                UPPER(COALESCE(e.cuil,''))     LIKE %s OR
                UPPER(COALESCE(e.area,''))     LIKE %s OR
                UPPER(COALESCE(e.tarea,''))    LIKE %s OR
                UPPER(COALESCE(r.periodo,''))  LIKE %s
            ";
            $params = array_fill(0, 7, $like);
        }
        $sql .= " ORDER BY r.id DESC LIMIT 500";
        $rows = $params ? $wpdb->get_results($wpdb->prepare($sql, ...$params)) : $wpdb->get_results($sql);

        $out = [];
        foreach ($rows as $r) {
            $out[] = [
                'id'              => (int)$r->id,
                'empleado_id'     => (int)$r->empleado_id,
                'empleado_nombre' => (string)$r->empleado_nombre,
                'periodo'         => (string)$r->periodo,
                'monto'           => (float)$r->monto,
                'detalles'        => (string)($r->detalles ?? ''),
                'archivo_id'      => (int)($r->archivo_id ?? 0),
            ];
        }

        wp_send_json_success(['recibos' => $out]);
    }

    public static function eliminar_recibo() {
        check_ajax_referer('midas_recibos_nonce', 'nonce');
        if (!is_user_logged_in() || !self::can_manage_recibos()) {
            wp_send_json_error(['message' => __('No tienes permiso para eliminar recibos.', 'midas-rrhh')], 403);
        }
        global $wpdb;
        $tabla = $wpdb->prefix . 'midas_recibos';
        $id    = intval($_POST['recibo_id'] ?? 0);
        if ($id <= 0) {
            wp_send_json_error(['message' => __('ID inválido.', 'midas-rrhh')], 400);
        }
        $ok = $wpdb->delete($tabla, ['id' => $id], ['%d']);
        if (!$ok) {
            wp_send_json_error(['message' => __('No se pudo eliminar el recibo.', 'midas-rrhh')], 500);
        }
        if (function_exists(__NAMESPACE__.'\\midas_clear_recibos_cache')) midas_clear_recibos_cache();
        wp_send_json_success(['deleted' => $id]);
    }

    // =================== LICENCIAS (CRUD) ===================
    private static function guard_licencias() {
        if (defined('DOING_AJAX') && DOING_AJAX) { @ini_set('display_errors', 0); }
        // ✅ FLEX: acepta 'nonce' o 'midas_empleados_nonce' con acción 'midas_empleados_nonce'
        $token = $_POST['nonce'] ?? $_GET['nonce'] ?? $_POST['midas_empleados_nonce'] ?? $_GET['midas_empleados_nonce'] ?? '';
        if (!$token || !wp_verify_nonce($token, 'midas_empleados_nonce')) {
            wp_send_json_error(['message'=>'Nonce inválido.'], 403);
        }
        if (!is_user_logged_in()) {
            wp_send_json_error(['message'=>'Debes iniciar sesión.'], 401);
        }
    }

    // Guard para el listado (acepta 'nonce' propio o compat)
    private static function guard_listar_licencias() {
        if (defined('DOING_AJAX') && DOING_AJAX) { @ini_set('display_errors', 0); }

        $token = $_POST['nonce'] ?? $_GET['nonce'] ?? null;
        $ok = false;

        if ($token && wp_verify_nonce($token, 'midas_lic_nonce')) {
            $ok = true;
        } elseif (!empty($_POST['midas_empleados_nonce']) && wp_verify_nonce($_POST['midas_empleados_nonce'], 'midas_empleados_nonce')) {
            $ok = true;
        }

        if (!$ok) {
            wp_send_json_error(['message' => __('Nonce inválido.', 'midas-rrhh')], 403);
        }
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Debes iniciar sesión.', 'midas-rrhh')], 401);
        }
    }

    public static function ajax_crear_licencia() {
        self::guard_licencias();

        // Datos esperados por el controlador
        $empleado_id   = intval($_POST['empleado_id'] ?? 0);
        $tipo          = sanitize_text_field($_POST['tipo'] ?? '');

        // === NUEVO: parseo tolerante de fechas ===
        $fi_iso        = self::parse_date_flex($_POST['fecha_inicio'] ?? '');
        $ff_iso        = self::parse_date_flex($_POST['fecha_fin'] ?? '');

        $observaciones = self::normalize_observaciones($_POST['observaciones'] ?? '', 2000);
        $archivo       = (!empty($_FILES['documento']) && is_array($_FILES['documento'])) ? $_FILES['documento'] : null;

        if ($empleado_id <= 0 || $tipo === '' || !$fi_iso || !$ff_iso) {
            wp_send_json_error(['message' => 'Faltan datos obligatorios o fechas inválidas.'], 400);
        }
        if (strtotime($ff_iso) < strtotime($fi_iso)) {
            wp_send_json_error(['message' => 'Fechas inválidas: la fecha fin es anterior al inicio.'], 400);
        }

        try {
            $controller = new Licencia_Controller();

            if (!method_exists($controller, 'solicitar_licencia')) {
                wp_send_json_error(['message' => 'Controlador de licencias no disponible.'], 500);
            }

            // Intento 1: firma extendida (empleado_id, tipo, fecha_inicio, fecha_fin, archivo, observaciones)
            try {
                $res = $controller->solicitar_licencia($empleado_id, $tipo, $fi_iso, $ff_iso, $archivo, $observaciones);
            } catch (\ArgumentCountError $e1) {
                // Intento 2: sin archivo (empleado_id, tipo, fecha_inicio, fecha_fin, observaciones)
                try {
                    $res = $controller->solicitar_licencia($empleado_id, $tipo, $fi_iso, $ff_iso, $observaciones);
                } catch (\ArgumentCountError $e2) {
                    // Intento 3: firma básica (empleado_id, tipo, fecha_inicio, fecha_fin)
                    $res = $controller->solicitar_licencia($empleado_id, $tipo, $fi_iso, $ff_iso);
                }
            }

            if (is_wp_error($res)) {
                wp_send_json_error(['message' => $res->get_error_message()], 400);
            }

            if (function_exists(__NAMESPACE__.'\\midas_clear_licencias_cache')) midas_clear_licencias_cache();
            wp_send_json_success(['message' => 'Licencia creada correctamente.', 'licencia' => $res]);
        } catch (\Throwable $e) {
            error_log('[MidasRRHH][ajax_crear_licencia] ' . $e->getMessage());
            wp_send_json_error(['message' => 'Error interno al crear licencia.'], 500);
        }
    }

    public static function ajax_aprobar_licencia() {
        self::guard_licencias();
        $controller = new Licencia_Controller();
        $controller->aprobar_licencia(intval($_POST['licencia_id'] ?? 0), sanitize_textarea_field($_POST['observaciones'] ?? ''));
        if (function_exists(__NAMESPACE__.'\\midas_clear_licencias_cache')) midas_clear_licencias_cache();
        wp_send_json_success(['message'=>'Licencia aprobada correctamente.']);
    }

    public static function ajax_rechazar_licencia() {
        self::guard_licencias();
        $controller = new Licencia_Controller();
        $controller->rechazar_licencia(intval($_POST['licencia_id'] ?? 0), sanitize_textarea_field($_POST['observaciones'] ?? ''));
        if (function_exists(__NAMESPACE__.'\\midas_clear_licencias_cache')) midas_clear_licencias_cache();
        wp_send_json_success(['message'=>'Licencia rechazada correctamente.']);
    }

public static function ajax_editar_licencia() {
    self::guard_licencias();

    $licencia_id   = intval($_POST['licencia_id'] ?? 0);
    $tipo          = sanitize_text_field($_POST['tipo'] ?? '');

    // parseo tolerante -> 'Y-m-d'
    $fi_iso        = self::parse_date_flex($_POST['fecha_inicio'] ?? '');
    $ff_iso        = self::parse_date_flex($_POST['fecha_fin'] ?? '');

    $observaciones = self::normalize_observaciones($_POST['observaciones'] ?? '', 2000);
    $archivo       = (!empty($_FILES['documento']) && is_array($_FILES['documento'])) ? $_FILES['documento'] : null;

    if ($licencia_id <= 0) {
        wp_send_json_error(['message' => 'ID de licencia inválido.'], 400);
    }
    if (!$fi_iso || !$ff_iso) {
        wp_send_json_error(['message' => 'Fechas inválidas. Usa formato DD/MM/YYYY o YYYY-MM-DD.'], 400);
    }
    if (strtotime($ff_iso) < strtotime($fi_iso)) {
        wp_send_json_error(['message' => 'Fechas inválidas: fin no puede ser menor que inicio.'], 400);
    }

    try {
        $controller = new \MidasRRHH\Controllers\Licencia_Controller();

        if (!method_exists($controller, 'editar_licencia')) {
            wp_send_json_error(['message' => 'Método editar_licencia no disponible.'], 500);
        }

        // ✅ Firma correcta del controller actual:
        try {
            $res = $controller->editar_licencia($licencia_id, $tipo, $fi_iso, $ff_iso, $archivo, $observaciones);
        } catch (\ArgumentCountError $e) {
            // Fallback legacy sin $documento
            $res = $controller->editar_licencia($licencia_id, $tipo, $fi_iso, $ff_iso, $observaciones);
        }

        if (is_wp_error($res)) {
            wp_send_json_error(['message' => $res->get_error_message()], 400);
        }

        if (function_exists(__NAMESPACE__.'\\midas_clear_licencias_cache')) midas_clear_licencias_cache();
        wp_send_json_success(['message' => 'Licencia editada correctamente.', 'licencia' => $res]);

    } catch (\Throwable $e) {
        error_log('[MidasRRHH][ajax_editar_licencia] ' . $e->getMessage());
        wp_send_json_error(['message' => 'Error interno al editar licencia.'], 500);
    }
}


    public static function ajax_eliminar_licencia() {
        self::guard_licencias();
        $controller = new Licencia_Controller();
        $controller->eliminar_licencia(intval($_POST['licencia_id'] ?? 0));
        if (function_exists(__NAMESPACE__.'\\midas_clear_licencias_cache')) midas_clear_licencias_cache();
        wp_send_json_success(['message'=>'Licencia eliminada correctamente.']);
    }

    // Listado con búsqueda y paginación (devuelve tbody + meta)
    public static function ajax_lic_listar() {
        if (defined('DOING_AJAX') && DOING_AJAX) { @ini_set('display_errors', 0); }
        self::guard_listar_licencias();

        // Parámetros
        $estado   = sanitize_key($_POST['estado'] ?? 'pendientes'); // pendientes|aprobadas|rechazadas|historial
        $page     = max(1, (int)($_POST['page'] ?? 1));
        $per_page = min(50, max(5, (int)($_POST['per_page'] ?? 10)));
        $q_raw    = (string)($_POST['q'] ?? '');
        $q        = function_exists('mb_strtoupper') ? mb_strtoupper(trim(wp_unslash($q_raw)), 'UTF-8') : strtoupper(trim(wp_unslash($q_raw)));

        global $wpdb;
        $t_lic = $wpdb->prefix . 'midas_licencias';
        $t_emp = $wpdb->prefix . 'midas_empleados';

        // Detectar columnas disponibles (documento_id / archivo_id)
        $cols = (array) $wpdb->get_col("SHOW COLUMNS FROM `$t_lic`", 0);
        $has_documento_id = in_array('documento_id', $cols, true);
        $has_archivo_id   = in_array('archivo_id',   $cols, true);

        if ($has_documento_id && $has_archivo_id) {
            $doc_select = "COALESCE(l.documento_id, l.archivo_id, 0) AS doc_id";
        } elseif ($has_documento_id) {
            $doc_select = "l.documento_id AS doc_id";
        } elseif ($has_archivo_id) {
            $doc_select = "l.archivo_id AS doc_id";
        } else {
            $doc_select = "0 AS doc_id";
        }

        // Filtro por estado
        $where = [];
        if ($estado === 'pendientes') {
            $where[] = "(l.estado IS NULL OR l.estado='' OR l.estado IN ('pendiente','PENDIENTE','0'))";
        } elseif ($estado === 'aprobadas') {
            $where[] = "(l.estado IN ('aprobada','APROBADA','aprobado','APROBADO','1'))";
        } elseif ($estado === 'rechazadas') {
            $where[] = "(l.estado IN ('rechazada','RECHAZADA','rechazado','RECHAZADO','-1'))";
        } // historial => sin filtro

        // Filtro por búsqueda
        $params = [];
        if ($q !== '') {
            $like = '%' . $wpdb->esc_like($q) . '%';
            $where[] = "(UPPER(COALESCE(e.nombre,'')) LIKE %s
                     OR UPPER(COALESCE(e.apellido,'')) LIKE %s
                     OR UPPER(COALESCE(e.dni,'')) LIKE %s
                     OR UPPER(COALESCE(l.tipo,'')) LIKE %s
                     OR UPPER(COALESCE(l.observaciones,'')) LIKE %s)";
            $params = array_fill(0, 5, $like);
        }

        $where_sql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

        // Total para paginación
        $sql_count = "
            SELECT COUNT(*)
            FROM $t_lic l
            LEFT JOIN $t_emp e ON e.id = l.empleado_id
            $where_sql
        ";
        $total = (int) ($params ? $wpdb->get_var($wpdb->prepare($sql_count, ...$params)) : $wpdb->get_var($sql_count));

        // Página
        $offset = ($page - 1) * $per_page;
        $sql_rows = "
            SELECT 
                l.id, l.empleado_id, l.tipo, l.fecha_inicio, l.fecha_fin, l.observaciones, l.estado,
                $doc_select,
                CONCAT(COALESCE(e.nombre,''),' ',COALESCE(e.apellido,''),' - ',COALESCE(e.dni,'')) AS empleado_nombre
            FROM $t_lic l
            LEFT JOIN $t_emp e ON e.id = l.empleado_id
            $where_sql
            ORDER BY COALESCE(l.fecha_inicio, l.id) DESC, l.id DESC
            LIMIT %d OFFSET %d
        ";

        $rows = $params
            ? $wpdb->get_results($wpdb->prepare($sql_rows, ...array_merge($params, [$per_page, $offset])))
            : $wpdb->get_results($wpdb->prepare($sql_rows, $per_page, $offset));

        // Render <tbody>
        ob_start();
        if (!empty($rows)) {
            foreach ($rows as $r) {
                $fi = $r->fecha_inicio ? strtotime($r->fecha_inicio) : 0;
                $ff = $r->fecha_fin    ? strtotime($r->fecha_fin)    : 0;

                $periodo = ($fi ? date_i18n('d/m/Y', $fi) : '-') . ' al ' . ($ff ? date_i18n('d/m/Y', $ff) : '-');
                $dias    = ($fi && $ff) ? max(1, (int) floor(($ff - $fi) / DAY_IN_SECONDS) + 1) : '-';

                $doc_id  = (int) ($r->doc_id ?? 0);
                $doc_url = $doc_id ? wp_get_attachment_url($doc_id) : '';
                $archivo_td = $doc_url
                    ? '<a class="button" target="_blank" href="'.esc_url($doc_url).'">'.esc_html__('Ver archivo','midas-rrhh').'</a>'
                    : '<em>-</em>';

                $lic_js = wp_json_encode([
                    'id'            => (int)$r->id,
                    'empleado_id'   => (int)$r->empleado_id,
                    'tipo'          => (string)($r->tipo ?? ''),
                    'fecha_inicio'  => (string)($r->fecha_inicio ?? ''),
                    'fecha_fin'     => (string)($r->fecha_fin ?? ''),
                    'observaciones' => (string)($r->observaciones ?? ''),
                ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

                $est_l = strtolower((string)($r->estado ?? ''));
                $acciones = '
                  <div class="acciones-licencia-grid">
                    <a href="#" class="button editar-licencia"   data-lic="' . esc_attr($lic_js) . '">'.esc_html__('Editar','midas-rrhh').'</a>
                    <a href="#" class="button eliminar-licencia" data-id="' . (int)$r->id . '">'.esc_html__('Eliminar','midas-rrhh').'</a>';

                if ($estado === 'pendientes' || $est_l === '' || $est_l === 'pendiente' || $est_l === '0') {
                    $acciones .= '
                    <a href="#" class="button aprobar-licencia"  data-id="' . (int)$r->id . '">'.esc_html__('Aprobar','midas-rrhh').'</a>
                    <a href="#" class="button rechazar-licencia" data-id="' . (int)$r->id . '">'.esc_html__('Rechazar','midas-rrhh').'</a>';
                }
                $acciones .= '</div>';

                echo '<tr data-id="'.(int)$r->id.'">
                    <td>'.esc_html($r->empleado_nombre ?? '-').'</td>
                    <td>'.esc_html($r->tipo ?? '-').'</td>
                    <td>'.esc_html($periodo).'</td>
                    <td>'.esc_html($dias).'</td>
                    <td title="'.esc_attr($r->observaciones ?? '').'">'.esc_html(($r->observaciones ?? '') !== '' ? $r->observaciones : '-').'</td>
                    <td>'.$archivo_td.'</td>
                    <td class="col-acciones">'.$acciones.'</td>' .
                    ($estado === 'historial' ? '<td>'.esc_html(ucfirst($est_l)).'</td>' : '') .
                '</tr>';
            }
        } else {
            echo '<tr><td colspan="'.($estado==='historial' ? 8 : 7).'"><em>'.esc_html__('Sin datos','midas-rrhh').'</em></td></tr>';
        }
        $tbody_html = (string) ob_get_clean();

        $total_pages = max(1, (int)ceil($total / $per_page));

        wp_send_json_success([
            'tbody'       => $tbody_html,
            'page'        => (int)$page,
            'per_page'    => (int)$per_page,
            'total'       => (int)$total,
            'total_pages' => (int)$total_pages,
            'estado'      => (string)$estado,
        ]);
    }

// --- CARPETA MÉDICA (CRUD) ---
public static function crear_documento_medico() {
    error_log("--- [AJAX] crear_documento_medico POST: " . print_r($_POST, true));
    error_log("--- [AJAX] crear_documento_medico FILES: " . print_r($_FILES, true));

    // Acepta cualquiera de estos tokens: midas_empleados_nonce, midas_cm_nonce, nonce
    $token = $_POST['midas_empleados_nonce'] ?? $_GET['midas_empleados_nonce']
          ?? $_POST['midas_cm_nonce']        ?? $_GET['midas_cm_nonce']
          ?? $_POST['nonce']                 ?? $_GET['nonce']                 ?? '';
    if (!$token || !(wp_verify_nonce($token, 'midas_empleados_nonce') || wp_verify_nonce($token, 'midas_cm_nonce'))) {
        error_log("--- [AJAX] crear_documento_medico: NONCE INVALIDO");
        wp_send_json_error(['message' => 'Nonce inválido.'], 403);
    }
    if (!is_user_logged_in()) {
        error_log("--- [AJAX] USUARIO NO LOGUEADO");
        wp_send_json_error(['message' => 'Debes iniciar sesión.'], 401);
    }

    $empleado_id      = intval($_POST['empleado_id'] ?? 0);
    $motivo_id        = intval($_POST['motivo_id'] ?? 0);
    $medico_id        = intval($_POST['medico_id'] ?? 0);
    $fecha_emision_in = sanitize_text_field($_POST['fecha_emision'] ?? '');
    $dias_solicitados = max(1, intval($_POST['dias_solicitados'] ?? 1));

    // Normalizar fecha (acepta DD/MM/YYYY o YYYY-MM-DD)
    $fi_iso = self::parse_date_flex($fecha_emision_in);

    // Aceptar alias (compat): 'observaciones' o 'respuesta'
    $obs_raw          = $_POST['observaciones'] ?? $_POST['respuesta'] ?? '';
    $observaciones    = self::normalize_observaciones($obs_raw, 2000);

    $archivo          = !empty($_FILES['documento']) ? $_FILES['documento'] : null;

    error_log("--- [AJAX] ARGUMENTOS PRE CONTROLADOR: empleado_id=$empleado_id, motivo_id=$motivo_id, medico_id=$medico_id, fecha_emision_in=$fecha_emision_in (iso=$fi_iso), dias_solicitados=$dias_solicitados, archivo: " . ($archivo ? json_encode($archivo) : 'NULL'));

    /**
     * ALTA INLINE DE MÉDICO (cuando no viene medico_id pero sí datos del nuevo médico).
     * Campos esperados:
     *   - nuevo_medico_flag (1)
     *   - nuevo_medico_nombre, nuevo_medico_apellido, nuevo_medico_especialidad (opcional), nuevo_medico_matricula
     * Lógica:
     *   - Si existe por matrícula, se reutiliza.
     *   - Si no existe, se inserta y se usa su ID.
     */
    $nuevo_flag = !empty($_POST['nuevo_medico_flag']) || (!empty($_POST['nuevo_medico_matricula']) && empty($medico_id));
    if ($nuevo_flag && !$medico_id) {
        // Normalizador a MAYÚSCULAS y longitud segura
        $to_upper = function ($v, $max = 191) {
            $v = wp_strip_all_tags((string)$v);
            $v = trim(preg_replace('/\s+/u', ' ', $v));
            if (function_exists('mb_strtoupper')) $v = mb_strtoupper($v, 'UTF-8'); else $v = strtoupper($v);
            if ($max > 0) {
                if (function_exists('mb_substr')) $v = mb_substr($v, 0, $max, 'UTF-8'); else $v = substr($v, 0, $max);
            }
            return $v;
        };

        $n_nombre       = $to_upper($_POST['nuevo_medico_nombre'] ?? '');
        $n_apellido     = $to_upper($_POST['nuevo_medico_apellido'] ?? '');
        $n_especialidad = $to_upper($_POST['nuevo_medico_especialidad'] ?? '');
        $n_matricula    = $to_upper($_POST['nuevo_medico_matricula'] ?? '');

        if ($n_nombre === '' || $n_apellido === '' || $n_matricula === '') {
            error_log("--- [AJAX] crear_documento_medico: Datos de nuevo médico incompletos");
            wp_send_json_error(['message' => 'Completá Nombre, Apellido y Matrícula del médico.'], 400);
        }

        global $wpdb;
        $tabla_medicos = $wpdb->prefix . 'midas_medicos';

        // ¿Existe ya por matrícula?
        $row = $wpdb->get_row($wpdb->prepare("SELECT id FROM {$tabla_medicos} WHERE UPPER(matricula)=UPPER(%s) LIMIT 1", $n_matricula));
        if ($row && isset($row->id)) {
            $medico_id = (int)$row->id;
            error_log("--- [AJAX] crear_documento_medico: Reutilizando médico existente id={$medico_id} (matrícula {$n_matricula})");
        } else {
            // Insertar nuevo
            $ok = $wpdb->insert(
                $tabla_medicos,
                [
                    'nombre'       => $n_nombre,
                    'apellido'     => $n_apellido,
                    'especialidad' => $n_especialidad,
                    'matricula'    => $n_matricula,
                ],
                ['%s','%s','%s','%s']
            );
            if ($ok === false) {
                $err = $wpdb->last_error ? ' Detalle: ' . $wpdb->last_error : '';
                error_log("--- [AJAX] crear_documento_medico: ERROR insert médico{$err}");
                wp_send_json_error(['message' => 'No se pudo crear el médico.' . $err], 500);
            }
            $medico_id = (int)$wpdb->insert_id;
            error_log("--- [AJAX] crear_documento_medico: Médico creado id={$medico_id}");
        }
    }

    // Validación final (con posible alta inline ya resuelta)
    if (!$empleado_id || !$motivo_id || !$medico_id || !$fi_iso) {
        error_log("--- [AJAX] FALTAN PARAMETROS OBLIGATORIOS");
        wp_send_json_error(['message' => 'Faltan parámetros obligatorios o la fecha es inválida.'], 400);
    }

    $controller = new Carpeta_Medica_Controller();
    $res = $controller->crear_documento_medico(
        $empleado_id,
        $motivo_id,
        $medico_id,
        $fi_iso,               // fecha normalizada
        $archivo,
        $dias_solicitados,
        $observaciones
    );

    if (is_wp_error($res)) {
        error_log("--- [AJAX] ERROR CONTROLADOR: " . $res->get_error_message());
        wp_send_json_error(['message' => $res->get_error_message()], 400);
    }

    if (function_exists(__NAMESPACE__.'\\midas_clear_carpeta_medica_cache')) midas_clear_carpeta_medica_cache();
    error_log("--- [AJAX] EXITO CONTROLADOR: " . json_encode($res));
    wp_send_json_success(['documento' => $res]);
}

/**
 * QUICK-ADD de MÉDICO (para el botón "¿No está mi médico?")
 * action: midas_crear_medico
 * datos:  nombre, apellido, especialidad (opcional), matricula
 * retorna: { id, message, duplicado? }
 */
public static function ajax_crear_medico() {
    // Reutilizamos la verificación flexible ya usada en carpeta médica
    $token = $_POST['midas_empleados_nonce'] ?? $_GET['midas_empleados_nonce']
          ?? $_POST['midas_cm_nonce']        ?? $_GET['midas_cm_nonce']
          ?? $_POST['nonce']                 ?? $_GET['nonce']                 ?? '';
    if (!$token || !(wp_verify_nonce($token, 'midas_empleados_nonce') || wp_verify_nonce($token, 'midas_cm_nonce'))) {
        wp_send_json_error(['message' => 'Nonce inválido.'], 403);
    }
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Debes iniciar sesión.'], 401);
    }
    // Permisos: los mismos que editar/crear en esta sección (ajústalo si querés menos restrictivo)
    if (!current_user_can('rrhh_gestor') && !current_user_can('rrhh_admin') && !current_user_can('administrator') && !current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'No tienes permiso para crear médicos.'], 403);
    }

    // Normalizador a MAYÚSCULAS consistente con el resto del plugin
    $UP = function ($s) {
        $s = sanitize_text_field(wp_unslash((string)$s));
        $s = trim($s);
        return function_exists('mb_strtoupper') ? mb_strtoupper($s, 'UTF-8') : strtoupper($s);
    };

    $nombre       = $UP($_POST['nombre']       ?? '');
    $apellido     = $UP($_POST['apellido']     ?? '');
    $especialidad = $UP($_POST['especialidad'] ?? '');
    $matricula    = $UP($_POST['matricula']    ?? '');

    if ($nombre === '' || $apellido === '' || $matricula === '') {
        wp_send_json_error(['message' => 'Faltan datos: Nombre, Apellido y Matrícula son obligatorios.'], 400);
    }

    global $wpdb;
    $tabla = $wpdb->prefix . 'midas_medicos';

    // ¿ya existe esa matrícula?
    $dup_id = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM $tabla WHERE UPPER(matricula)=UPPER(%s) LIMIT 1", $matricula));
    if ($dup_id > 0) {
        // Devolvemos éxito para que el front seleccione el existente sin romper el flujo
        wp_send_json_success([
            'id'         => $dup_id,
            'duplicado'  => true,
            'message'    => 'La matrícula ya existía, se seleccionó el médico existente.'
        ]);
    }

    $ok = $wpdb->insert(
        $tabla,
        [
            'nombre'       => $nombre,
            'apellido'     => $apellido,
            'especialidad' => $especialidad,
            'matricula'    => $matricula,
        ],
        ['%s','%s','%s','%s']
    );

    if ($ok === false) {
        error_log('[midas_crear_medico] DB error: ' . $wpdb->last_error);
        wp_send_json_error(['message' => 'No se pudo guardar el médico.'], 500);
    }

    wp_send_json_success([
        'id'      => (int) $wpdb->insert_id,
        'message' => 'Médico creado correctamente.'
    ]);
}

public static function obtener_documentos_empleado() {
    self::verify_request(['midas_carpeta_medica_read','midas_empleados_nonce','midas_cm_nonce']);

    $empleado_id = intval($_POST['empleado_id'] ?? $_GET['empleado_id'] ?? 0);
    $empleado_model = new \MidasRRHH\Models\Empleado_Model();

    $can_read = current_user_can('read_private_midas_carpeta_medica')
        || current_user_can('approve_midas_carpeta_medica')
        || current_user_can('rrhh_gestor')
        || current_user_can('rrhh_admin')
        || current_user_can('administrator')
        || current_user_can('manage_options');

    if ($empleado_id <= 0) {
        $emp = $empleado_model->get_by_user_id(get_current_user_id());
        if ($emp && !is_wp_error($emp)) $empleado_id = (int)$emp->id;
    }

    if ($empleado_id <= 0) {
        wp_send_json_error(['message' => 'Empleado no válido.'], 400);
    }

    if (!$can_read) {
        $emp = $empleado_model->get_by_user_id(get_current_user_id());
        if (!$emp || (int)$emp->id !== $empleado_id) {
            wp_send_json_error(['message' => 'No tienes permiso para ver estos documentos.'], 403);
        }
    }

    $ctl = new Carpeta_Medica_Controller();
    $list = method_exists($ctl,'obtener_documentos_empleado') ? $ctl->obtener_documentos_empleado($empleado_id) : [];
    if (is_wp_error($list)) wp_send_json_error(['message' => $list->get_error_message()], 400);

    wp_send_json_success(['documentos' => $list]);
}

public static function obtener_documento_medico() {
    self::verify_request(['midas_carpeta_medica_read','midas_empleados_nonce','midas_cm_nonce']);

    $documento_id = intval($_POST['documento_id'] ?? $_GET['documento_id'] ?? 0);
    if ($documento_id <= 0) {
        wp_send_json_error(['message' => 'ID de documento inválido.'], 400);
    }

    $ctl = new Carpeta_Medica_Controller();
    $doc = method_exists($ctl,'obtener_documento') ? $ctl->obtener_documento($documento_id) : null;

    if (is_wp_error($doc) || !$doc) {
        wp_send_json_error(['message' => is_wp_error($doc) ? $doc->get_error_message() : 'No encontrado.'], 404);
    }

    $can_read = current_user_can('read_private_midas_carpeta_medica')
        || current_user_can('approve_midas_carpeta_medica')
        || current_user_can('rrhh_gestor')
        || current_user_can('rrhh_admin')
        || current_user_can('administrator')
        || current_user_can('manage_options');

    if (!$can_read) {
        $empleado_model = new \MidasRRHH\Models\Empleado_Model();
        $emp = $empleado_model->get_by_user_id(get_current_user_id());
        $doc_emp_id = (int)($doc->empleado_id ?? 0);
        if (!$emp || (int)$emp->id !== $doc_emp_id) {
            wp_send_json_error(['message' => 'No tienes permiso para ver este documento.'], 403);
        }
    }

    wp_send_json_success(['documento' => $doc]);
}

public static function obtener_documentos_pendientes() {
    self::verify_request(['midas_carpeta_medica_read','midas_empleados_nonce','midas_cm_nonce']);
    if (!current_user_can('approve_midas_carpeta_medica') && !current_user_can('rrhh_gestor') && !current_user_can('rrhh_admin') && !current_user_can('administrator') && !current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'No tienes permiso para ver pendientes.'], 403);
    }
    $ctl = new Carpeta_Medica_Controller();
    $list = $ctl->obtener_documentos_pendientes();
    if (is_wp_error($list)) wp_send_json_error(['message' => $list->get_error_message()], 400);
    wp_send_json_success(['documentos' => $list]);
}

public static function obtener_documentos_aprobados() {
    self::verify_request(['midas_carpeta_medica_read','midas_empleados_nonce','midas_cm_nonce']);
    $ctl = new Carpeta_Medica_Controller();
    $list = $ctl->obtener_documentos_aprobados();
    if (is_wp_error($list)) wp_send_json_error(['message' => $list->get_error_message()], 400);
    wp_send_json_success(['documentos' => $list]);
}

public static function obtener_documentos_rechazados() {
    self::verify_request(['midas_carpeta_medica_read','midas_empleados_nonce','midas_cm_nonce']);
    $ctl = new Carpeta_Medica_Controller();
    $list = $ctl->obtener_documentos_rechazados();
    if (is_wp_error($list)) wp_send_json_error(['message' => $list->get_error_message()], 400);
    wp_send_json_success(['documentos' => $list]);
}

public static function obtener_historial_documentos() {
    self::verify_request(['midas_carpeta_medica_read','midas_empleados_nonce','midas_cm_nonce']);
    $ctl = new Carpeta_Medica_Controller();
    $list = $ctl->obtener_historial_documentos();
    if (is_wp_error($list)) wp_send_json_error(['message' => $list->get_error_message()], 400);
    wp_send_json_success(['documentos' => $list]);
}

public static function editar_documento_medico() {
    // Acepta múltiples nonces
    $token = $_POST['midas_empleados_nonce'] ?? $_GET['midas_empleados_nonce']
          ?? $_POST['midas_cm_nonce']        ?? $_GET['midas_cm_nonce']
          ?? $_POST['nonce']                 ?? $_GET['nonce']                 ?? '';
    if (!$token || !(wp_verify_nonce($token, 'midas_empleados_nonce') || wp_verify_nonce($token, 'midas_cm_nonce'))) {
        wp_send_json_error(['message' => 'Nonce inválido. Intenta refrescar la página.'], 403);
    }
    if (!current_user_can('rrhh_gestor') && !current_user_can('rrhh_admin') && !current_user_can('administrator')) {
        wp_send_json_error(['message' => 'No tienes permiso para editar documentos médicos.'], 403);
    }

    $documento_id = intval($_POST['documento_id'] ?? 0);
    if ($documento_id <= 0) {
        wp_send_json_error(['message' => 'ID de documento inválido.'], 400);
    }

    $controller = new Carpeta_Medica_Controller();

    $doc_prev = $controller->obtener_documento($documento_id);
    $estado_previo = null;
    if (!is_wp_error($doc_prev)) {
        $estado_previo = strtolower($doc_prev->estado_descripcion ?? $doc_prev->estado ?? '');
    }

    // Normalizar fechas si vienen
    $fe_in  = sanitize_text_field($_POST['fecha_emision'] ?? '');
    $fv_in  = sanitize_text_field($_POST['fecha_vencimiento'] ?? '');

    $fi_iso = $fe_in !== '' ? self::parse_date_flex($fe_in) : '';
    $fv_iso = $fv_in !== '' ? self::parse_date_flex($fv_in) : '';

    if ($fe_in !== '' && !$fi_iso) {
        wp_send_json_error(['message' => 'Fecha de emisión inválida. Usa DD/MM/YYYY o YYYY-MM-DD.'], 400);
    }
    if ($fv_in !== '' && !$fv_iso) {
        wp_send_json_error(['message' => 'Fecha de vencimiento inválida. Usa DD/MM/YYYY o YYYY-MM-DD.'], 400);
    }

    $post_data = [
        'motivo_id'         => intval($_POST['motivo_id'] ?? 0),
        'medico_id'         => intval($_POST['medico_id'] ?? 0),
        'fecha_emision'     => $fi_iso ?: $fe_in,     // normalizada si aplica
        'fecha_vencimiento' => $fv_iso ?: $fv_in,     // normalizada si aplica
        'dias_solicitados'  => max(1, intval($_POST['dias_solicitados'] ?? 1)),
        // también aceptamos alias aquí por si el front cambia:
        'observaciones'     => self::normalize_observaciones(($_POST['observaciones'] ?? $_POST['respuesta'] ?? ''), 2000),
        'documento_id'      => $documento_id,
    ];
    $archivo = !empty($_FILES['documento']) ? $_FILES['documento'] : null;

    $res = $controller->editar_documento_medico($post_data, $archivo);
    if (is_wp_error($res)) {
        wp_send_json_error(['message' => $res->get_error_message()], 400);
    }

    if (function_exists(__NAMESPACE__.'\\midas_clear_carpeta_medica_cache')) midas_clear_carpeta_medica_cache();

    $doc = $controller->obtener_documento($documento_id);
    if (is_wp_error($doc)) {
        wp_send_json_error(['message' => $doc->get_error_message()], 400);
    }

    wp_send_json_success([
        'message'       => 'Documento médico editado correctamente',
        'documento'     => $doc,
        'estado_previo' => $estado_previo
    ]);
}

public static function aprobar_documento_medico() {
    // Acepta múltiples nonces
    $token = $_POST['midas_empleados_nonce'] ?? $_GET['midas_empleados_nonce']
          ?? $_POST['midas_cm_nonce']        ?? $_GET['midas_cm_nonce']
          ?? $_POST['nonce']                 ?? $_GET['nonce']                 ?? '';
    if (!$token || !(wp_verify_nonce($token, 'midas_empleados_nonce') || wp_verify_nonce($token, 'midas_cm_nonce'))) {
        wp_send_json_error(['message' => 'Nonce inválido. Intenta refrescar la página.'], 403);
    }
    if (!current_user_can('approve_midas_carpeta_medica') && !current_user_can('rrhh_admin') && !current_user_can('administrator') && !is_super_admin()) {
        wp_send_json_error(['message' => __('No tienes permiso para aprobar documentos médicos.', 'midas-rrhh')], 403);
    }

    $documento_id    = intval($_POST['documento_id'] ?? 0);
    if ($documento_id <= 0) {
        wp_send_json_error(['message' => 'ID de documento inválido.'], 400);
    }
    $dias_aprobados  = intval($_POST['dias_aprobados'] ?? 0);
    $observaciones   = self::normalize_observaciones(($_POST['observaciones'] ?? $_POST['respuesta'] ?? ''), 2000);

    $controller = new Carpeta_Medica_Controller();
    $res = $controller->aprobar_documento_medico($documento_id, $dias_aprobados, $observaciones);

    if (is_wp_error($res)) {
        wp_send_json_error(['message' => $res->get_error_message()], 400);
    }

    $doc = $controller->obtener_documento($documento_id);
    if (is_wp_error($doc)) {
        wp_send_json_error(['message' => $doc->get_error_message()], 400);
    }

    if (function_exists(__NAMESPACE__.'\\midas_clear_carpeta_medica_cache')) midas_clear_carpeta_medica_cache();
    wp_send_json_success(['message' => 'Documento aprobado correctamente', 'documento' => $doc]);
}

public static function rechazar_documento_medico() {
    // Acepta múltiples nonces
    $token = $_POST['midas_empleados_nonce'] ?? $_GET['midas_empleados_nonce']
          ?? $_POST['midas_cm_nonce']        ?? $_GET['midas_cm_nonce']
          ?? $_POST['nonce']                 ?? $_GET['nonce']                 ?? '';
    if (!$token || !(wp_verify_nonce($token, 'midas_empleados_nonce') || wp_verify_nonce($token, 'midas_cm_nonce'))) {
        wp_send_json_error(['message' => 'Nonce inválido. Intenta refrescar la página.'], 403);
    }
    if (!current_user_can('approve_midas_carpeta_medica') && !current_user_can('rrhh_admin') && !current_user_can('administrator') && !is_super_admin()) {
        wp_send_json_error(['message' => __('No tienes permiso para rechazar documentos médicos.', 'midas-rrhh')], 403);
    }

    $documento_id  = intval($_POST['documento_id'] ?? 0);
    if ($documento_id <= 0) {
        wp_send_json_error(['message' => 'ID de documento inválido.'], 400);
    }
    $observaciones = self::normalize_observaciones(($_POST['observaciones'] ?? $_POST['respuesta'] ?? ''), 2000);

    $controller = new Carpeta_Medica_Controller();
    $res = $controller->rechazar_documento_medico($documento_id, $observaciones);

    if (is_wp_error($res)) {
        wp_send_json_error(['message' => $res->get_error_message()], 400);
    }

    $doc = $controller->obtener_documento($documento_id);
    if (is_wp_error($doc)) {
        wp_send_json_error(['message' => $doc->get_error_message()], 400);
    }

    if (function_exists(__NAMESPACE__.'\\midas_clear_carpeta_medica_cache')) midas_clear_carpeta_medica_cache();
    wp_send_json_success(['message' => 'Documento rechazado correctamente', 'documento' => $doc]);
}

public static function eliminar_documento_medico() {
    error_log('--- [AJAX] eliminar_documento_medico: POST='.print_r($_POST,true));

    // Acepta múltiples nonces (clave del error 400)
    $token = $_POST['midas_empleados_nonce'] ?? $_GET['midas_empleados_nonce']
          ?? $_POST['midas_cm_nonce']        ?? $_GET['midas_cm_nonce']
          ?? $_POST['nonce']                 ?? $_GET['nonce']                 ?? '';
    if (!$token || !(wp_verify_nonce($token, 'midas_empleados_nonce') || wp_verify_nonce($token, 'midas_cm_nonce'))) {
        error_log('--- [AJAX] eliminar_documento_medico: NONCE INVALIDO');
        wp_send_json_error(['message' => 'Nonce inválido. Intenta refrescar la página.'], 403);
    }

    if (
        !current_user_can('rrhh_gestor') &&
        !current_user_can('rrhh_admin') &&
        !current_user_can('administrator') &&
        !current_user_can('manage_options') // opcional, quítalo si no corresponde
    ) {
        error_log('--- [AJAX] eliminar_documento_medico: PERMISO DENEGADO');
        wp_send_json_error(['message' => __('No tienes permiso para eliminar documentos médicos.', 'midas-rrhh')], 403);
    }

    $documento_id = intval($_POST['documento_id'] ?? 0);
    if ($documento_id <= 0) {
        wp_send_json_error(['message' => 'ID de documento no válido.'], 400);
    }

    $controller = new Carpeta_Medica_Controller();

    // Comprobación explícita + opcional borrado de adjunto aquí (por si el controller no lo hace)
    $doc = $controller->obtener_documento($documento_id);
    if (is_wp_error($doc)) {
        $code = $doc->get_error_code() === 'not_found' ? 404 : 400;
        wp_send_json_error(['message' => $doc->get_error_message()], $code);
    }
    if (!empty($doc->documento_id)) {
        try { wp_delete_attachment((int)$doc->documento_id, true); } catch (\Throwable $e) { /* noop */ }
    }

    $res = $controller->eliminar_documento_medico($documento_id);
    if (is_wp_error($res)) {
        error_log('--- [AJAX] eliminar_documento_medico: ERROR '.$res->get_error_message());
        wp_send_json_error(['message' => $res->get_error_message()], 400);
    }

    if (function_exists(__NAMESPACE__.'\\midas_clear_carpeta_medica_cache')) midas_clear_carpeta_medica_cache();
    error_log('--- [AJAX] eliminar_documento_medico: OK id='.$documento_id);
    wp_send_json_success(['message' => 'Documento médico eliminado correctamente', 'id' => $documento_id]);
}

/**
 * Endpoint que usa la vista (action=midas_cm_listar_docs)
 * Devuelve SOLO <tbody> + metadatos para paginar en el front.
 */
public static function cm_listar_docs() {
    if (defined('DOING_AJAX') && DOING_AJAX) {
        @ini_set('display_errors', 0);
    }

    // Acepta nonce del front: 'midas_cm_nonce', 'nonce' o 'midas_empleados_nonce'
    $token = $_POST['midas_cm_nonce']        ?? $_GET['midas_cm_nonce']
          ?? $_POST['nonce']                 ?? $_GET['nonce']
          ?? $_POST['midas_empleados_nonce'] ?? $_GET['midas_empleados_nonce'] ?? '';
    $ok = false;
    if ($token && wp_verify_nonce($token, 'midas_cm_nonce'))       $ok = true;
    if (!$ok && $token && wp_verify_nonce($token, 'midas_empleados_nonce')) $ok = true;
    if (!$ok) wp_send_json_error(['message' => __('Nonce inválido.', 'midas-rrhh')], 403);

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => __('Debes iniciar sesión.', 'midas-rrhh')], 401);
    }

    $can_read = current_user_can('read_private_midas_carpeta_medica')
        || current_user_can('approve_midas_carpeta_medica')
        || current_user_can('rrhh_gestor')
        || current_user_can('rrhh_admin')
        || current_user_can('administrator')
        || current_user_can('manage_options');

    if (!$can_read) {
        wp_send_json_error(['message' => __('Permiso denegado', 'midas-rrhh')], 403);
    }

    // Flags de permisos para acciones (para NO mostrar botones a quien no puede)
    $can_edit_delete = current_user_can('rrhh_gestor')
        || current_user_can('rrhh_admin')
        || current_user_can('administrator')
        || current_user_can('manage_options');

    $can_approve = current_user_can('approve_midas_carpeta_medica')
        || current_user_can('rrhh_admin')
        || current_user_can('administrator')
        || current_user_can('manage_options');

    $estado   = sanitize_text_field($_POST['estado'] ?? 'pendientes'); // pendientes|aprobados|rechazados|historial
    $page     = max(1, (int)($_POST['page'] ?? 1));
    $per_page = min(50, max(5, (int)($_POST['per_page'] ?? 10)));
    $q_raw    = wp_unslash($_POST['q'] ?? '');
    $q        = trim((string)$q_raw);

    $ctl = new Carpeta_Medica_Controller();
    switch ($estado) {
        case 'aprobados':  $lista = $ctl->obtener_documentos_aprobados();  break;
        case 'rechazados': $lista = $ctl->obtener_documentos_rechazados(); break;
        case 'historial':  $lista = $ctl->obtener_historial_documentos();  break;
        default:           $lista = $ctl->obtener_documentos_pendientes(); break;
    }

    if (is_wp_error($lista)) {
        wp_send_json_error(['message' => $lista->get_error_message()], 500);
    }
    if (!is_array($lista)) $lista = (array) $lista;

    // Normalización + campos derivados
    foreach ($lista as &$d) {
        if (is_array($d)) $d = (object) $d;
        if (!is_object($d)) continue;

        if (empty($d->documento_url) && !empty($d->documento_id)) {
            $d->documento_url = wp_get_attachment_url((int)$d->documento_id);
        }
        if (empty($d->fecha_emision_formateada) && !empty($d->fecha_emision)) {
            $ts = strtotime($d->fecha_emision);
            if ($ts) $d->fecha_emision_formateada = date_i18n('d/m/Y', $ts);
        }

        // Fallback unificado para OBSERVACIONES
        $obs_val = '-';
        foreach (['observaciones','obs_gestion','observaciones_estado','motivo_rechazo','respuesta'] as $k) {
            if (isset($d->$k) && $d->$k !== '') { $obs_val = (string) $d->$k; break; }
        }
        $d->_obs_text = $obs_val;
    }
    unset($d);

    // Búsqueda incluyendo _obs_text
    if ($q !== '') {
        $q_l = function_exists('mb_strtolower') ? mb_strtolower($q, 'UTF-8') : strtolower($q);
        $lista = array_values(array_filter($lista, function ($d) use ($q_l) {
            if (is_array($d)) $d = (object) $d;
            $txt = (($d->empleado_nombre ?? '') . ' ' .
                    ($d->motivo_descripcion ?? '') . ' ' .
                    ($d->_obs_text ?? '') . ' ' .
                    ($d->estado_descripcion ?? '') . ' ' .
                    ($d->fecha_emision_formateada ?? '') . ' ' .
                    ($d->fecha_emision ?? ''));
            $hay = function_exists('mb_strtolower') ? mb_strtolower($txt, 'UTF-8') : strtolower($txt);
            return strpos($hay, $q_l) !== false;
        }));
    }

    // Orden por fecha desc
    usort($lista, function ($a, $b) {
        if (is_array($a)) $a = (object) $a;
        if (is_array($b)) $b = (object) $b;
        $ta = !empty($a->fecha_emision) ? strtotime($a->fecha_emision) : 0;
        $tb = !empty($b->fecha_emision) ? strtotime($b->fecha_emision) : 0;
        return $tb <=> $ta;
    });

    // Paginación
    $total       = count($lista);
    $total_pages = max(1, (int) ceil($total / $per_page));
    $offset      = ($page - 1) * $per_page;
    $slice       = array_slice($lista, $offset, $per_page);

    // Render de filas
    ob_start();
    if (!empty($slice)) {
        foreach ($slice as $d) {
            if (is_array($d)) $d = (object) $d;

            // Para EDITAR: ya mandamos el fallback en 'observaciones'
            $doc_js = wp_json_encode([
                'id'                 => $d->id ?? '',
                'empleado_id'        => $d->empleado_id ?? '',
                'medico_id'          => $d->medico_id ?? '',
                'motivo_id'          => $d->motivo_id ?? '',
                'fecha_emision'      => $d->fecha_emision ?? '',
                'dias_solicitados'   => $d->dias_solicitados ?? '',
                'observaciones'      => $d->_obs_text ?? '',
                'estado_descripcion' => $d->estado_descripcion ?? '',
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

            $empleado = esc_html($d->empleado_nombre ?? '-');
            $motivo   = esc_html($d->motivo_descripcion ?? '-');
            $fecha    = esc_html($d->fecha_emision_formateada ?? ($d->fecha_emision ?? '-'));
            $dias     = esc_html($d->dias_solicitados ?? '-');

            $obs   = esc_html($d->_obs_text ?? '-');
            $obs_t = esc_attr($d->_obs_text ?? '-');

            $archivo  = !empty($d->documento_url)
                ? '<a class="button" target="_blank" href="'.esc_url($d->documento_url).'">'.esc_html__('Ver archivo','midas-rrhh').'</a>'
                : '<em>-</em>';

            $estado_td = ($estado === 'historial') ? '<td>'.esc_html($d->estado_descripcion ?? '-').'</td>' : '';

            echo '<tr data-id="'.esc_attr($d->id ?? '').'">';
            echo '<td>'.$empleado.'</td>';
            echo '<td>'.$motivo.'</td>';
            echo '<td>'.$fecha.'</td>';
            echo '<td>'.$dias.'</td>';
            echo '<td title="'.$obs_t.'">'.$obs.'</td>';
            echo '<td>'.$archivo.'</td>';

            echo '<td class="col-acciones"><div class="acciones-doc-grid acciones-licencia-grid">';
            if ($can_edit_delete) {
                echo '<a href="#" class="button editar-doc" data-doc="'.esc_attr($doc_js).'">'.esc_html__('Editar','midas-rrhh').'</a>';
                echo '<a href="#" class="button eliminar-doc" data-id="'.esc_attr($d->id ?? '').'">'.esc_html__('Eliminar','midas-rrhh').'</a>';
            }
            $est_l = strtolower($d->estado_descripcion ?? 'pendiente');
            if (($est_l === 'pendiente' || $est_l === '') && $can_approve) {
                echo '<a href="#" class="button aprobar-doc" data-id="'.esc_attr($d->id ?? '').'">'.esc_html__('Aprobar','midas-rrhh').'</a>';
                echo '<a href="#" class="button rechazar-doc" data-id="'.esc_attr($d->id ?? '').'">'.esc_html__('Rechazar','midas-rrhh').'</a>';
            }
            echo '</div></td>';

            echo $estado_td;
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="'.($estado==='historial' ? 8 : 7).'"><em>'.esc_html__('Sin datos','midas-rrhh').'</em></td></tr>';
    }
    $tbody_html = (string) ob_get_clean();

    wp_send_json_success([
        'tbody'       => $tbody_html,
        'page'        => (int) $page,
        'per_page'    => (int) $per_page,
        'total'       => (int) $total,
        'total_pages' => (int) $total_pages,
        'estado'      => (string) $estado,
    ]);
}

// --- TICKETS ---
public static function crear_ticket() {
    // Nonce
    $nonce_ok = false;
    if (isset($_POST['nonce_ticket']) && wp_verify_nonce($_POST['nonce_ticket'], 'midas_tickets_nonce')) $nonce_ok = true;
    elseif (isset($_POST['nonce']) && wp_verify_nonce($_POST['nonce'], 'midas_tickets_nonce')) $nonce_ok = true;

    if (!$nonce_ok)           wp_send_json_error(['message' => __('Nonce inválido. Intenta refrescar la página.', 'midas-rrhh')], 403);
    if (!is_user_logged_in()) wp_send_json_error(['message' => __('Debes iniciar sesión para crear un ticket.', 'midas-rrhh')], 401);

    $asunto  = (string)($_POST['asunto']  ?? '');
    $mensaje = (string)($_POST['mensaje'] ?? '');
    if ($asunto === '' || $mensaje === '') {
        wp_send_json_error(['message' => __('Faltan datos requeridos', 'midas-rrhh')], 400);
    }

    $controller = new \MidasRRHH\Controllers\Ticket_Controller();
    $user_id    = get_current_user_id();

    // Si es admin: debe venir destinatario y se fuerza 'enviado'.
    $es_admin = current_user_can('manage_options') || current_user_can('administrator') || current_user_can('rrhh_admin');
    if ($es_admin) {
        $destinatario_id = absint($_POST['destinatario_id'] ?? 0);
        if ($destinatario_id <= 0) {
            wp_send_json_error(['message' => __('Selecciona un destinatario.', 'midas-rrhh')], 400);
        }
        $res = $controller->crear_ticket($user_id, $asunto, $mensaje, 'enviado', $destinatario_id);
    } else {
        // No admin: el controller resuelve RRHH por defecto y deja 'pendiente'
        $res = $controller->crear_ticket($user_id, $asunto, $mensaje);
    }

    if (is_wp_error($res)) {
        wp_send_json_error(['message' => $res->get_error_message()], 400);
    }

    // *** NUEVO: chequear que realmente se insertó (ID > 0) ***
    if (!$res || !is_numeric($res) || intval($res) <= 0) {
        wp_send_json_error(['message' => __('No se pudo crear el ticket.', 'midas-rrhh')], 400);
    }

    if (function_exists(__NAMESPACE__.'\\midas_clear_tickets_cache')) {
        midas_clear_tickets_cache();
    }

    wp_send_json_success(['message' => __('Ticket creado con éxito', 'midas-rrhh')]);
}

public static function responder_ticket() {
    $nonce_ok = false;
    if (isset($_POST['nonce_ticket']) && wp_verify_nonce($_POST['nonce_ticket'], 'midas_tickets_nonce')) $nonce_ok = true;
    if (isset($_POST['nonce']) && wp_verify_nonce($_POST['nonce'], 'midas_tickets_nonce')) $nonce_ok = true;
    if (!$nonce_ok) wp_send_json_error(['message' => __('Nonce inválido. Intenta refrescar la página.', 'midas-rrhh')], 403);
    if (!is_user_logged_in()) wp_send_json_error(['message' => __('Debes iniciar sesión para responder.', 'midas-rrhh')], 401);

    if (!current_user_can('manage_options') && !current_user_can('administrator') && !current_user_can('rrhh_admin') && !current_user_can('rrhh_gestor')) {
        wp_send_json_error(['message' => __('No tienes permiso para responder instancias.', 'midas-rrhh')], 403);
    }

    $ticket_id = absint($_POST['ticket_id'] ?? 0);
    $valor_raw = (string)($_POST['valor'] ?? '');
    $valor     = self::normalize_observaciones($valor_raw, 2000);

    if ($ticket_id <= 0 || $valor === '') {
        wp_send_json_error(['message' => __('Datos inválidos.', 'midas-rrhh')], 400);
    }

    try {
        $controller = new \MidasRRHH\Controllers\Ticket_Controller();

        // Firma tolerante
        try {
            $res = $controller->responder_ticket($ticket_id, $valor, get_current_user_id());
        } catch (\ArgumentCountError $e) {
            $res = $controller->responder_ticket($ticket_id, $valor);
        }

        if (is_wp_error($res)) {
            wp_send_json_error(['message' => $res->get_error_message()], 400);
        }

        // *** NUEVO: exigir éxito real (true) ***
        if ($res !== true) {
            wp_send_json_error(['message' => __('No se pudo guardar la respuesta.', 'midas-rrhh')], 400);
        }

        if (function_exists(__NAMESPACE__.'\\midas_clear_tickets_cache')) {
            midas_clear_tickets_cache();
        }

        // Info para pintar sin recargar (opcional)
        $current = wp_get_current_user();
        wp_send_json_success([
            'message'      => __('Respuesta enviada correctamente.', 'midas-rrhh'),
            'respuesta'    => $valor,
            'admin_nombre' => $current ? $current->display_name : ''
        ]);
    } catch (\Throwable $e) {
        error_log('[MidasRRHH][responder_ticket] ERROR: ' . $e->getMessage());
        wp_send_json_error(['message' => __('Error interno al responder.', 'midas-rrhh')], 500);
    }
}

public static function rechazar_ticket() {
    $nonce_ok = false;
    if (isset($_POST['nonce_ticket']) && wp_verify_nonce($_POST['nonce_ticket'], 'midas_tickets_nonce')) $nonce_ok = true;
    if (isset($_POST['nonce']) && wp_verify_nonce($_POST['nonce'], 'midas_tickets_nonce')) $nonce_ok = true;
    if (!$nonce_ok) wp_send_json_error(['message' => __('Nonce inválido. Intenta refrescar la página.', 'midas-rrhh')], 403);
    if (!is_user_logged_in()) wp_send_json_error(['message' => __('Debes iniciar sesión para rechazar.', 'midas-rrhh')], 401);

    if (!current_user_can('manage_options') && !current_user_can('administrator') && !current_user_can('rrhh_admin') && !current_user_can('rrhh_gestor')) {
        wp_send_json_error(['message' => __('No tienes permiso para rechazar instancias.', 'midas-rrhh')], 403);
    }

    $ticket_id = absint($_POST['ticket_id'] ?? 0);
    $valor_raw = (string)($_POST['valor'] ?? '');
    $motivo    = self::normalize_observaciones($valor_raw, 2000);

    if ($ticket_id <= 0 || $motivo === '') {
        wp_send_json_error(['message' => __('Datos inválidos.', 'midas-rrhh')], 400);
    }

    try {
        $controller = new \MidasRRHH\Controllers\Ticket_Controller();

        // Firma tolerante
        try {
            $res = $controller->rechazar_ticket($ticket_id, $motivo, get_current_user_id());
        } catch (\ArgumentCountError $e) {
            $res = $controller->rechazar_ticket($ticket_id, $motivo);
        }

        if (is_wp_error($res)) {
            wp_send_json_error(['message' => $res->get_error_message()], 400);
        }

        // *** NUEVO: exigir éxito real (true) ***
        if ($res !== true) {
            wp_send_json_error(['message' => __('No se pudo guardar el rechazo.', 'midas-rrhh')], 400);
        }

        if (function_exists(__NAMESPACE__.'\\midas_clear_tickets_cache')) {
            midas_clear_tickets_cache();
        }

        $current = wp_get_current_user();
        wp_send_json_success([
            'message'      => __('Instancia rechazada correctamente.', 'midas-rrhh'),
            'motivo'       => $motivo,
            'admin_nombre' => $current ? $current->display_name : ''
        ]);
    } catch (\Throwable $e) {
        error_log('[MidasRRHH][rechazar_ticket] ERROR: ' . $e->getMessage());
        wp_send_json_error(['message' => __('Error interno al rechazar.', 'midas-rrhh')], 500);
    }
}

        /* =========================
     *   CONFIGURACIÓN (CRUD)
     * ========================= */

    /* nonce = 'midas_cfg_nonce' (enviado como 'nonce'); requiere login y rol gestor/admin */
    private static function verify_cfg() {
        if (defined('DOING_AJAX') && DOING_AJAX) { @ini_set('display_errors', 0); }
        $t = $_POST['nonce'] ?? $_GET['nonce'] ?? '';
        if (!$t || !wp_verify_nonce($t, 'midas_cfg_nonce')) {
            wp_send_json_error(['message'=>'Nonce inválido.'], 403);
        }
        if (!is_user_logged_in()) {
            wp_send_json_error(['message'=>'Debes iniciar sesión.'], 401);
        }
        if (!current_user_can('rrhh_admin') && !current_user_can('manage_options')) {
            // si querés permitir también rrhh_gestor, destapá la línea de abajo:
            // if (!current_user_can('rrhh_gestor')) wp_send_json_error(['message'=>'Permiso denegado.'], 403);
        }
    }

    /* Mapea el ID de tabla del front a tabla SQL y a sus columnas */
    private static function cfg_map(string $tablaId) : array {
        global $wpdb;
        switch ($tablaId) {
            case 'tabla-tareas':
                return ['table'=>$wpdb->prefix.'midas_tareas', 'kind'=>'tareas',
                        'cols'=>['id','nombre','descripcion','activo']];
            case 'tabla-areas':
                return ['table'=>$wpdb->prefix.'midas_areas', 'kind'=>'areas',
                        'cols'=>['id','nombre','rol','activo']];
            case 'tabla-enfermedades':
                return ['table'=>$wpdb->prefix.'midas_enfermedades', 'kind'=>'enfermedades',
                        'cols'=>['id','tipo','descripcion']];
            case 'tabla-medicos':
                return ['table'=>$wpdb->prefix.'midas_medicos', 'kind'=>'medicos',
                        'cols'=>['id','nombre','apellido','especialidad','matricula']];
            case 'tabla-licencias':
                return ['table'=>$wpdb->prefix.'midas_licencia_tipos', 'kind'=>'licencias',
                        'cols'=>['id','tipo','descripcion']];
            default:
                return ['table'=>'', 'kind'=>'', 'cols'=>[]];
        }
    }

    /* Render de una fila <tr> según la tabla (min/sin adornos) */
    private static function cfg_render_row(array $row, string $kind, string $tablaId) : string {
        $id = (int)($row['id'] ?? 0);
        $btns = '<a href="#" class="button midas-btn-editar" data-tabla="'.esc_attr($tablaId).'" data-id="'.$id.'">'.esc_html__('Editar','midas-rrhh').'</a> '.
                '<a href="#" class="button midas-btn-eliminar" data-tabla="'.esc_attr($tablaId).'" data-id="'.$id.'">'.esc_html__('Eliminar','midas-rrhh').'</a>';

        if ($kind==='tareas') {
            $estado = !empty($row['activo']) ? 'Activo' : 'Inactivo';
            return '<tr><td>'.$id.'</td><td>'.esc_html($row['nombre']??'').'</td><td>'.esc_html($row['descripcion']??'').'</td><td>'.esc_html($estado).'</td><td>'.$btns.'</td></tr>';
        }
        if ($kind==='areas') {
            $estado = !empty($row['activo']) ? 'Activo' : 'Inactivo';
            return '<tr><td>'.$id.'</td><td>'.esc_html($row['nombre']??'').'</td><td>'.esc_html($row['rol']??'').'</td><td>'.esc_html($estado).'</td><td>'.$btns.'</td></tr>';
        }
        if ($kind==='enfermedades') {
            return '<tr><td>'.$id.'</td><td>'.esc_html($row['tipo']??'').'</td><td>'.esc_html($row['descripcion']??'').'</td><td>'.$btns.'</td></tr>';
        }
        if ($kind==='medicos') {
            return '<tr><td>'.$id.'</td><td>'.esc_html($row['nombre']??'').'</td><td>'.esc_html($row['apellido']??'').'</td><td>'.esc_html($row['especialidad']??'').'</td><td>'.esc_html($row['matricula']??'').'</td><td>'.$btns.'</td></tr>';
        }
        if ($kind==='licencias') {
            return '<tr><td>'.$id.'</td><td>'.esc_html($row['tipo']??'').'</td><td>'.esc_html($row['descripcion']??'').'</td><td>'.$btns.'</td></tr>';
        }
        return '';
    }

    /* LISTAR (server-side): devuelve d.data.html + page/total_pages */
    public static function cfg_list() {
        self::verify_cfg();
        global $wpdb;

        $tablaId  = sanitize_text_field($_POST['tabla'] ?? '');
        $page     = max(1, (int)($_POST['page'] ?? 1));
        $per_page = min(50, max(5, (int)($_POST['per_page'] ?? 15)));
        $q_raw    = (string)($_POST['q'] ?? '');
        $q        = function_exists('mb_strtoupper') ? mb_strtoupper(trim(wp_unslash($q_raw)), 'UTF-8') : strtoupper(trim(wp_unslash($q_raw)));

        $map = self::cfg_map($tablaId);
        if (!$map['table']) wp_send_json_error(['message'=>'Tabla desconocida.']);

        $table = $map['table']; $kind = $map['kind']; $cols = $map['cols'];
        $fields = implode(',', array_map(function($c){ return 't.'.$c; }, $cols));
        $where = ' WHERE 1=1 '; $params = [];

        if ($q !== '') {
            if ($kind==='tareas') {
                $where .= ' AND (UPPER(COALESCE(t.nombre,"")) LIKE %s OR UPPER(COALESCE(t.descripcion,"")) LIKE %s) ';
                $like = '%'.$wpdb->esc_like($q).'%'; $params = [$like,$like];
            } elseif ($kind==='areas') {
                $where .= ' AND (UPPER(COALESCE(t.nombre,"")) LIKE %s OR UPPER(COALESCE(t.rol,"")) LIKE %s) ';
                $like = '%'.$wpdb->esc_like($q).'%'; $params = [$like,$like];
            } elseif ($kind==='enfermedades' || $kind==='licencias') {
                $where .= ' AND (UPPER(COALESCE(t.tipo,"")) LIKE %s OR UPPER(COALESCE(t.descripcion,"")) LIKE %s) ';
                $like = '%'.$wpdb->esc_like($q).'%'; $params = [$like,$like];
            } elseif ($kind==='medicos') {
                $where .= ' AND (UPPER(COALESCE(t.nombre,"")) LIKE %s OR UPPER(COALESCE(t.apellido,"")) LIKE %s OR UPPER(COALESCE(t.especialidad,"")) LIKE %s OR UPPER(COALESCE(t.matricula,"")) LIKE %s) ';
                $like = '%'.$wpdb->esc_like($q).'%'; $params = [$like,$like,$like,$like];
            }
        }

        $total = (int) ($params ? $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table t $where", ...$params))
                                 : $wpdb->get_var("SELECT COUNT(*) FROM $table t $where"));

        $offset = ($page-1)*$per_page;
        $sql = "SELECT $fields FROM $table t $where ORDER BY t.id DESC LIMIT %d OFFSET %d";
        $rows = $params ? $wpdb->get_results($wpdb->prepare($sql, ...array_merge($params, [$per_page,$offset])), ARRAY_A)
                        : $wpdb->get_results($wpdb->prepare($sql, $per_page,$offset), ARRAY_A);

        ob_start();
        if ($rows) {
            foreach ($rows as $r) echo self::cfg_render_row($r, $kind, $tablaId);
        } else {
            echo '<tr><td colspan="8"><em>'.esc_html__('Sin datos','midas-rrhh').'</em></td></tr>';
        }
        $html = ob_get_clean();

        wp_send_json_success([
            'html'        => $html,
            'page'        => (int)$page,
            'total_pages' => max(1, (int)ceil($total/$per_page)),
        ]);
    }

    /* AGREGAR / EDITAR (usa el mismo handler) */
    public static function cfg_guardar() {
        self::verify_cfg();
        global $wpdb;

        $tablaId = sanitize_text_field($_POST['tabla'] ?? '');
        $map = self::cfg_map($tablaId);
        if (!$map['table']) wp_send_json_error(['message'=>'Tabla desconocida.']);

        $id  = intval($_POST['registro_id'] ?? 0);
        $t   = $map['table'];
        $k   = $map['kind'];
        $d   = []; $fmt = [];

        if ($k==='tareas') {
            $d = [
                'nombre'      => sanitize_text_field($_POST['nombre'] ?? ''),
                'descripcion' => sanitize_textarea_field($_POST['descripcion'] ?? ''),
                'activo'      => isset($_POST['activo']) ? (int)$_POST['activo'] : 1
            ]; $fmt = ['%s','%s','%d'];
        } elseif ($k==='areas') {
            $d = [
                'nombre' => sanitize_text_field($_POST['nombre'] ?? ''),
                'rol'    => sanitize_text_field($_POST['rol'] ?? ''),
                'activo' => isset($_POST['activo']) ? (int)$_POST['activo'] : 1
            ]; $fmt = ['%s','%s','%d'];
        } elseif ($k==='enfermedades') {
            $d = [
                'tipo'        => sanitize_text_field($_POST['tipo'] ?? ''),
                'descripcion' => sanitize_textarea_field($_POST['descripcion'] ?? '')
            ]; $fmt = ['%s','%s'];
        } elseif ($k==='medicos') {
            $d = [
                'nombre'       => sanitize_text_field($_POST['nombre'] ?? ''),
                'apellido'     => sanitize_text_field($_POST['apellido'] ?? ''),
                'especialidad' => sanitize_text_field($_POST['especialidad'] ?? ''),
                'matricula'    => sanitize_text_field($_POST['matricula'] ?? '')
            ]; $fmt = ['%s','%s','%s','%s'];
        } elseif ($k==='licencias') {
            $d = [
                'tipo'        => sanitize_text_field($_POST['tipo'] ?? ''),
                'descripcion' => sanitize_textarea_field($_POST['descripcion'] ?? '')
            ]; $fmt = ['%s','%s'];
        } else {
            wp_send_json_error(['message'=>'Tipo no soportado.']);
        }

        foreach ($d as $key=>$val) { if ($val==='' && $key!=='descripcion' && $key!=='especialidad' && $key!=='matricula') {
            wp_send_json_error(['message'=>'Campos obligatorios incompletos.']);
        }}

        if ($id>0) {
            $ok = $wpdb->update($t, $d, ['id'=>$id], $fmt, ['%d']);
            if ($ok===false) wp_send_json_error(['message'=>'No se pudo actualizar.']);
            wp_send_json_success(['message'=>'Actualizado']);
        } else {
            $ok = $wpdb->insert($t, $d, $fmt);
            if (!$ok) wp_send_json_error(['message'=>'No se pudo crear.']);
            wp_send_json_success(['message'=>'Creado','id'=>(int)$wpdb->insert_id]);
        }
    }

    /* ELIMINAR */
    public static function cfg_eliminar() {
        self::verify_cfg();
        global $wpdb;
        $tablaId = sanitize_text_field($_POST['tabla'] ?? '');
        $map = self::cfg_map($tablaId);
        if (!$map['table']) wp_send_json_error(['message'=>'Tabla desconocida.']);
        $id = intval($_POST['registro_id'] ?? 0);
        if ($id<=0) wp_send_json_error(['message'=>'ID inválido.']);
        $ok = $wpdb->delete($map['table'], ['id'=>$id], ['%d']);
        if (!$ok) wp_send_json_error(['message'=>'No se pudo eliminar.']);
        wp_send_json_success(['message'=>'Eliminado']);
    }
/* =========================
 *  DOCUMENTACIÓN VENCIMIENTO – LISTAS
 * ========================= */
public static function docv_listar() {
    self::verify_read_only(); // solo exige login

    global $wpdb;
    $t_docs = $wpdb->prefix.'midas_documentaciones';
    $t_emp  = $wpdb->prefix.'midas_empleados';

    // detectar tabla de tipos disponible
    $t_tipos = '';
    foreach ([$wpdb->prefix.'midas_documento_tipos', $wpdb->prefix.'midas_documentos_tipos', $wpdb->prefix.'midas_doc_tipos'] as $c) {
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $c))) { $t_tipos = $c; break; }
    }

    // filtros básicos
    $q        = trim((string)($_POST['q'] ?? ''));
    $estado   = sanitize_text_field($_POST['estado'] ?? 'todos'); // todos|vigentes|vencidos|por-vencer
    $tipo_id  = intval($_POST['tipo_id'] ?? 0);
    $page     = max(1, (int)($_POST['page'] ?? 1));
    $per_page = min(50, max(5, (int)($_POST['per_page'] ?? 10)));
    $offset   = ($page - 1) * $per_page;

    // columnas variables según la tabla de documentos
    $cols = (array) $wpdb->get_col("SHOW COLUMNS FROM `$t_docs`", 0);
    $c_desc   = in_array('descripcion',   $cols, true) ? 'descripcion'   : (in_array('detalles', $cols, true) ? 'detalles' : 'descripcion');
    $c_inicio = in_array('fecha_inicio',  $cols, true) ? 'fecha_inicio'  : (in_array('inicio', $cols, true) ? 'inicio' : 'fecha_emision');
    $c_fin    = in_array('fecha_fin',     $cols, true) ? 'fecha_fin'     : (in_array('fin', $cols, true) ? 'fin' : 'vencimiento');
    $c_estado = in_array('estado',        $cols, true) ? 'estado'        : null;
    $c_tipo   = in_array('tipo_id',       $cols, true) ? 'tipo_id'       : (in_array('documento_tipo_id', $cols, true) ? 'documento_tipo_id' : null);
    $c_file   = in_array('documento_id',  $cols, true) ? 'documento_id'  : (in_array('archivo_id', $cols, true) ? 'archivo_id' : null);
    $c_borr   = in_array('borrado',       $cols, true) ? 'borrado'       : null;

    // columnas disponibles en la tabla de tipos -> construir expresión segura para tipo_nombre
    $tipo_name_expr = "NULL";
    if ($t_tipos) {
        $cols_tipos = (array) $wpdb->get_col("SHOW COLUMNS FROM `$t_tipos`", 0);
        $cand = [];
        foreach (['descripcion','tipo','nombre'] as $f) {
            if (in_array($f, $cols_tipos, true)) { $cand[] = "t.$f"; }
        }
        if ($cand) { $tipo_name_expr = 'COALESCE('.implode(', ', $cand).')'; }
    }

    // base query
    $where  = " WHERE 1=1 ";
    $params = [];

    if ($c_borr) { $where .= " AND COALESCE(d.$c_borr,0)=0"; }

    if ($q !== '') {
        $like = '%'.$wpdb->esc_like($q).'%';
        $where .= " AND (UPPER(COALESCE(d.$c_desc,'')) LIKE %s
                      OR UPPER(COALESCE(e.nombre,'')) LIKE %s
                      OR UPPER(COALESCE(e.apellido,'')) LIKE %s
                      OR UPPER(COALESCE(e.dni,'')) LIKE %s)";
        $params = array_merge($params, array_fill(0, 4, strtoupper($like)));
    }
    if ($tipo_id > 0 && $c_tipo) {
        $where   .= " AND d.$c_tipo = %d";
        $params[] = $tipo_id;
    }
    if (in_array($estado, ['vigentes','vencidos','por-vencer'], true)) {
        $hoy = current_time('Y-m-d');
        if ($estado === 'vigentes') {
            $where   .= " AND (d.$c_fin IS NULL OR d.$c_fin >= %s)";
            $params[] = $hoy;
        } elseif ($estado === 'vencidos') {
            $where   .= " AND d.$c_fin < %s";
            $params[] = $hoy;
        } else {
            $where   .= " AND d.$c_fin BETWEEN %s AND DATE_ADD(%s, INTERVAL 30 DAY)";
            $params[] = $hoy; $params[] = $hoy;
        }
    }

    // total
    $sql_count = "
        SELECT COUNT(*)
        FROM $t_docs d
        LEFT JOIN $t_emp e ON e.id = d.empleado_id
        ".($t_tipos ? "LEFT JOIN $t_tipos t ON t.id = ".($c_tipo ? "d.$c_tipo" : "0") : "")."
        $where
    ";
    $total = (int) ($params ? $wpdb->get_var($wpdb->prepare($sql_count, ...$params)) : $wpdb->get_var($sql_count));

    // rows
    $sql_rows = "
        SELECT d.id, d.empleado_id, ".($c_tipo ? "d.$c_tipo AS tipo_id," : "NULL AS tipo_id,")."
               d.$c_desc AS descripcion, d.$c_inicio AS fecha_inicio, d.$c_fin AS fecha_fin,
               ".($c_estado ? "d.$c_estado AS estado," : "NULL AS estado,")."
               ".($c_file ? "d.$c_file AS archivo_id," : "NULL AS archivo_id,")."
               CONCAT(COALESCE(e.nombre,''),' ',COALESCE(e.apellido,''),' - ',COALESCE(e.dni,'')) AS empleado_nombre,
               ".($t_tipos ? $tipo_name_expr : "NULL")." AS tipo_nombre
        FROM $t_docs d
        LEFT JOIN $t_emp e ON e.id = d.empleado_id
        ".($t_tipos ? "LEFT JOIN $t_tipos t ON t.id = ".($c_tipo ? "d.$c_tipo" : "0") : "")."
        $where
        ORDER BY COALESCE(d.$c_fin, d.$c_inicio, d.id) DESC, d.id DESC
        LIMIT %d OFFSET %d
    ";
    $rows = $params
        ? $wpdb->get_results($wpdb->prepare($sql_rows, ...array_merge($params, [$per_page, $offset])))
        : $wpdb->get_results($wpdb->prepare($sql_rows, $per_page, $offset));

    // fallback de estado
    $calc_estado = function($fecha_fin) {
        if (empty($fecha_fin)) return __('Sin vencimiento','midas-rrhh');
        $today = new \DateTime(current_time('Y-m-d'));
        $fin   = \DateTime::createFromFormat('Y-m-d', date('Y-m-d', strtotime($fecha_fin)));
        if (!$fin) return '-';
        $diff = (int)$today->diff($fin)->format('%r%a');
        if ($diff < 0)   return __('Vencido','midas-rrhh');
        if ($diff <= 30) return __('Por vencer','midas-rrhh');
        return __('Vigente','midas-rrhh');
    };

    // render
    ob_start();
    if ($rows) {
        foreach ($rows as $r) {
            $fi  = $r->fecha_inicio ? date_i18n('d/m/Y', strtotime($r->fecha_inicio)) : '-';
            $ff  = $r->fecha_fin    ? date_i18n('d/m/Y', strtotime($r->fecha_fin))    : '-';
            $est = ($r->estado !== null && $r->estado !== '') ? ucfirst(strtolower((string)$r->estado))
                                                              : $calc_estado($r->fecha_fin);
            $url     = ($r->archivo_id ? wp_get_attachment_url((int)$r->archivo_id) : '');
            $archivo = $url ? '<a class="button button-small" target="_blank" rel="noopener" href="'.esc_url($url).'">'.esc_html__('Ver archivo','midas-rrhh').'</a>' : '<em>-</em>';

            echo '<tr data-id="'.(int)$r->id.'">
                    <td>'.esc_html($r->empleado_nombre ?? '-').'</td>
                    <td>'.esc_html($r->tipo_nombre ?? '-').'</td>
                    <td title="'.esc_attr($r->descripcion ?? '').'">'.esc_html($r->descripcion ?? '-').'</td>
                    <td>'.esc_html($fi).'</td>
                    <td>'.esc_html($ff).'</td>
                    <td>'.esc_html($est).'</td>
                    <td>'.$archivo.'</td>
                    <td class="col-acciones">
                        <div class="acciones-licencia-grid">
                            <a href="#" class="button button-small doc-edit" data-id="'.(int)$r->id.'">'.esc_html__('Editar','midas-rrhh').'</a>
                            <a href="#" class="button button-small doc-del"  data-id="'.(int)$r->id.'">'.esc_html__('Eliminar','midas-rrhh').'</a>
                        </div>
                    </td>
                  </tr>';
        }
    } else {
        echo '<tr><td colspan="8"><em>'.esc_html__('Sin datos','midas-rrhh').'</em></td></tr>';
    }
    $tbody = ob_get_clean();

    wp_send_json_success([
        'tbody'       => $tbody,
        'page'        => (int)$page,
        'per_page'    => (int)$per_page,
        'total'       => (int)$total,
        'total_pages' => max(1, (int)ceil($total / $per_page)),
    ]);
}


public static function docv_tipos_listar() {
    self::verify_read_only(); // solo exige login

    global $wpdb;
    // detectar tabla de tipos disponible
    $t_tipos = '';
    foreach ([$wpdb->prefix.'midas_documento_tipos', $wpdb->prefix.'midas_documentos_tipos', $wpdb->prefix.'midas_doc_tipos'] as $c) {
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $c))) { $t_tipos = $c; break; }
    }
    if (!$t_tipos) {
        wp_send_json_success([
            'tbody'       => '<tr><td colspan="3"><em>'.esc_html__('Sin datos','midas-rrhh').'</em></td></tr>',
            'page'        => 1,
            'per_page'    => 10,
            'total'       => 0,
            'total_pages' => 1,
        ]);
    }

    $q        = trim((string)($_POST['q'] ?? ''));
    $page     = max(1, (int)($_POST['page'] ?? 1));
    $per_page = min(50, max(5, (int)($_POST['per_page'] ?? 10)));
    $offset   = ($page - 1) * $per_page;

    // columnas variables (soporta par plazo_numero/plazo_unidad o única columna)
    $cols      = (array) $wpdb->get_col("SHOW COLUMNS FROM `$t_tipos`", 0);
    $c_desc    = in_array('descripcion', $cols, true) ? 'descripcion' : (in_array('nombre', $cols, true) ? 'nombre' : 'descripcion');
    $has_pair  = in_array('plazo_numero', $cols, true) && in_array('plazo_unidad', $cols, true);
    $c_plazo_1 = null;
    if (!$has_pair) {
        foreach (['plazo','dias','validez_dias'] as $cand) {
            if (in_array($cand, $cols, true)) { $c_plazo_1 = $cand; break; }
        }
    }

    $where  = " WHERE 1=1 ";
    $params = [];
    if ($q !== '') {
        $like = '%'.$wpdb->esc_like($q).'%';
        $where .= " AND UPPER(COALESCE($c_desc,'')) LIKE %s";
        $params[] = strtoupper($like);
    }

    $sql_count = "SELECT COUNT(*) FROM $t_tipos $where";
    $total = (int) ($params ? $wpdb->get_var($wpdb->prepare($sql_count, ...$params)) : $wpdb->get_var($sql_count));

    if ($has_pair) {
        $sql_rows = "SELECT id, $c_desc AS descripcion, plazo_numero, plazo_unidad
                     FROM $t_tipos $where
                     ORDER BY id DESC LIMIT %d OFFSET %d";
    } else {
        $sql_rows = "SELECT id, $c_desc AS descripcion".($c_plazo_1 ? ", $c_plazo_1 AS plazo" : ", NULL AS plazo")."
                     FROM $t_tipos $where
                     ORDER BY id DESC LIMIT %d OFFSET %d";
    }
    $rows = $params
        ? $wpdb->get_results($wpdb->prepare($sql_rows, ...array_merge($params, [$per_page, $offset])))
        : $wpdb->get_results($wpdb->prepare($sql_rows, $per_page, $offset));

    // helper de etiqueta de unidad
    $unit_label = function($u) {
        $u = strtolower((string)$u);
        if ($u === 'dias' || $u === 'días')   return __('días','midas-rrhh');
        if ($u === 'meses')                   return __('meses','midas-rrhh');
        if ($u === 'anios' || $u === 'años')  return __('años','midas-rrhh');
        return $u ?: '';
    };

    ob_start();
    if ($rows) {
        foreach ($rows as $r) {
            if ($has_pair) {
                $num = isset($r->plazo_numero) ? (int)$r->plazo_numero : 0;
                $uni = isset($r->plazo_unidad) ? $unit_label($r->plazo_unidad) : '';
                $plazo_txt = ($num > 0 && $uni) ? ($num.' '.$uni) : '—';
                $data_n = $num ?: '';
                $data_u = isset($r->plazo_unidad) ? esc_attr(strtolower($r->plazo_unidad)) : '';
            } else {
                $d = (isset($r->plazo) && $r->plazo !== null && $r->plazo !== '') ? (int)$r->plazo : 0;
                $plazo_txt = $d > 0 ? ($d.' '.__('días','midas-rrhh')) : '—';
                $data_n = $d ?: '';
                $data_u = 'dias';
            }

            echo '<tr data-id="'.(int)$r->id.'">
                    <td>'.esc_html($r->descripcion ?? '-').'</td>
                    <td>'.esc_html($plazo_txt).'</td>
                    <td>
                        <button class="button button-small tipo-edit"
                                data-id="'.(int)$r->id.'"
                                data-des="'.esc_attr($r->descripcion ?? '').'"
                                data-n="'.esc_attr($data_n).'"
                                data-u="'.esc_attr($data_u).'">'.esc_html__('Editar','midas-rrhh').'</button>
                        <button class="button button-small tipo-del" data-id="'.(int)$r->id.'">'.esc_html__('Eliminar','midas-rrhh').'</button>
                    </td>
                  </tr>';
        }
    } else {
        echo '<tr><td colspan="3"><em>'.esc_html__('Sin datos','midas-rrhh').'</em></td></tr>';
    }
    $tbody = ob_get_clean();

    wp_send_json_success([
        'tbody'       => $tbody,
        'page'        => (int)$page,
        'per_page'    => (int)$per_page,
        'total'       => (int)$total,
        'total_pages' => max(1, (int)ceil($total / $per_page)),
    ]);
}

/* =========================
 *  DOCUMENTACIÓN VENCIMIENTO – TIPOS (CRUD)
 * ========================= */
public static function docv_tipo_guardar() {
    self::verify_read_only(); // solo login
    if (!check_ajax_referer('midas_doc_tipos_nonce', 'midas_doc_tipos_nonce', false)) {
        wp_send_json_error(['message' => __('Nonce inválido', 'midas-rrhh')], 400);
    }

    global $wpdb;

    // detectar tabla
    $t_tipos = '';
    foreach ([$wpdb->prefix.'midas_documento_tipos', $wpdb->prefix.'midas_documentos_tipos', $wpdb->prefix.'midas_doc_tipos'] as $c) {
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $c))) { $t_tipos = $c; break; }
    }
    if (!$t_tipos) {
        wp_send_json_error(['message' => __('No se encontró la tabla de tipos', 'midas-rrhh')], 400);
    }

    // columnas variables
    $cols       = (array) $wpdb->get_col("SHOW COLUMNS FROM `$t_tipos`", 0);
    $c_desc     = in_array('descripcion', $cols, true) ? 'descripcion' : (in_array('nombre', $cols, true) ? 'nombre' : null);
    $has_pair   = in_array('plazo_numero', $cols, true) && in_array('plazo_unidad', $cols, true);
    $c_plazo_1  = null;
    if (!$has_pair) {
        foreach (['plazo','dias','validez_dias'] as $cand) {
            if (in_array($cand, $cols, true)) { $c_plazo_1 = $cand; break; }
        }
    }
    if (!$c_desc) {
        wp_send_json_error(['message' => __('La tabla de tipos no tiene columna de descripción/nombre', 'midas-rrhh')], 400);
    }

    // datos
    $id           = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $descripcion  = isset($_POST['descripcion']) ? sanitize_text_field(wp_unslash($_POST['descripcion'])) : '';
    $plazo_numero = isset($_POST['plazo_numero']) ? intval($_POST['plazo_numero']) : 0;
    $plazo_unidad = isset($_POST['plazo_unidad']) ? sanitize_text_field(wp_unslash($_POST['plazo_unidad'])) : '';

    if ($descripcion === '') {
        wp_send_json_error(['message' => __('La descripción es obligatoria', 'midas-rrhh')], 400);
    }

    // normalizador de unidad
    $norm_unit = function($u) {
        $u = strtolower((string)$u);
        if (in_array($u, ['dias','días'], true)) return 'dias';
        if ($u === 'meses') return 'meses';
        if (in_array($u, ['anios','años'], true)) return 'anios';
        return '';
    };
    $plazo_unidad_n = $norm_unit($plazo_unidad);

    // si tenemos una única columna, convertimos a días (aproximado)
    $plazo_en_dias = null;
    if (!$has_pair && $c_plazo_1) {
        if ($plazo_numero > 0) {
            if ($plazo_unidad_n === 'dias')      $plazo_en_dias = $plazo_numero;
            elseif ($plazo_unidad_n === 'meses') $plazo_en_dias = $plazo_numero * 30;
            elseif ($plazo_unidad_n === 'anios') $plazo_en_dias = $plazo_numero * 365;
            else                                 $plazo_en_dias = $plazo_numero;
        } else {
            $plazo_en_dias = null;
        }
    }

    if ($id > 0) {
        // UPDATE
        $sets   = ["$c_desc = %s"];
        $params = [$descripcion];

        if ($has_pair) {
            if ($plazo_numero > 0 && $plazo_unidad_n) {
                $sets[]  = "plazo_numero = %d";
                $sets[]  = "plazo_unidad = %s";
                $params[] = $plazo_numero;
                $params[] = $plazo_unidad_n;
            } else {
                $sets[] = "plazo_numero = NULL";
                $sets[] = "plazo_unidad = NULL";
            }
        } elseif ($c_plazo_1) {
            if ($plazo_en_dias === null) {
                $sets[] = "$c_plazo_1 = NULL";
            } else {
                $sets[]   = "$c_plazo_1 = %d";
                $params[] = (int)$plazo_en_dias;
            }
        }

        $params[] = $id;
        $sql = "UPDATE $t_tipos SET ".implode(', ', $sets)." WHERE id = %d";
        $ok  = $wpdb->query($wpdb->prepare($sql, ...$params));
        if ($ok === false) {
            wp_send_json_error(['message' => __('No se pudo actualizar el tipo', 'midas-rrhh')], 500);
        }
        wp_send_json_success(['message' => __('Tipo actualizado', 'midas-rrhh'), 'id' => (int)$id]);

    } else {
        // INSERT
        $cols_sql = [$c_desc];
        $vals_sql = ['%s'];
        $params   = [$descripcion];

        if ($has_pair) {
            if ($plazo_numero > 0 && $plazo_unidad_n) {
                $cols_sql[] = 'plazo_numero'; $vals_sql[] = '%d'; $params[] = $plazo_numero;
                $cols_sql[] = 'plazo_unidad'; $vals_sql[] = '%s'; $params[] = $plazo_unidad_n;
            }
        } elseif ($c_plazo_1) {
            if ($plazo_en_dias !== null) {
                $cols_sql[] = $c_plazo_1; $vals_sql[] = '%d'; $params[] = (int)$plazo_en_dias;
            }
        }

        $sql = "INSERT INTO $t_tipos (".implode(',', $cols_sql).") VALUES (".implode(',', $vals_sql).")";
        $ok  = $wpdb->query($wpdb->prepare($sql, ...$params));
        if ($ok === false) {
            wp_send_json_error(['message' => __('No se pudo crear el tipo', 'midas-rrhh')], 500);
        }
        $new_id = (int)$wpdb->insert_id;
        wp_send_json_success(['message' => __('Tipo creado', 'midas-rrhh'), 'id' => $new_id]);
    }
}

public static function docv_tipo_eliminar() {
    self::verify_read_only();
    if (!check_ajax_referer('midas_doc_tipos_nonce', 'midas_doc_tipos_nonce', false)) {
        wp_send_json_error(['message' => __('Nonce inválido', 'midas-rrhh')], 400);
    }

    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    if ($id <= 0) {
        wp_send_json_error(['message' => __('ID inválido', 'midas-rrhh')], 400);
    }

    global $wpdb;
    $t_tipos = '';
    foreach ([$wpdb->prefix.'midas_documento_tipos', $wpdb->prefix.'midas_documentos_tipos', $wpdb->prefix.'midas_doc_tipos'] as $c) {
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $c))) { $t_tipos = $c; break; }
    }
    if (!$t_tipos) {
        wp_send_json_error(['message' => __('No se encontró la tabla de tipos', 'midas-rrhh')], 400);
    }

    $ok = $wpdb->delete($t_tipos, ['id' => $id], ['%d']);
    if ($ok === false) {
        wp_send_json_error(['message' => __('No se pudo eliminar el tipo', 'midas-rrhh')], 500);
    }
    wp_send_json_success(['message' => __('Tipo eliminado', 'midas-rrhh')]);
}

/* =========================
 *  DOCUMENTACIÓN VENCIMIENTO – DOCUMENTOS (CRUD)
 *  Requiere: acciones wp_ajax_midas_doc_crear|editar|eliminar apuntando a estos métodos.
 * ========================= */

/**
 * Crea documento. Calcula fecha_fin a partir del tipo (si tiene plazo).
 * Ignora cualquier fecha_fin enviada por el cliente.
 */
public static function doc_crear() {
    self::verify_read_only();
    if (!check_ajax_referer('midas_documentaciones_nonce', 'midas_documentaciones_nonce', false)) {
        wp_send_json_error(['message' => __('Nonce inválido', 'midas-rrhh')], 400);
    }

    global $wpdb;
    $t_docs = $wpdb->prefix.'midas_documentaciones';

    // Columnas variables
    $cols = (array) $wpdb->get_col("SHOW COLUMNS FROM `$t_docs`", 0);
    if (!$cols) {
        wp_send_json_error(['message' => __('No se encontró la tabla de documentos', 'midas-rrhh')], 400);
    }
    $c_desc   = in_array('descripcion',   $cols, true) ? 'descripcion'   : (in_array('detalles', $cols, true) ? 'detalles' : 'descripcion');
    $c_inicio = in_array('fecha_inicio',  $cols, true) ? 'fecha_inicio'  : (in_array('inicio', $cols, true) ? 'inicio' : 'fecha_emision');
    $c_fin    = in_array('fecha_fin',     $cols, true) ? 'fecha_fin'     : (in_array('fin', $cols, true) ? 'fin' : 'vencimiento');
    $c_tipo   = in_array('tipo_id',       $cols, true) ? 'tipo_id'       : (in_array('documento_tipo_id', $cols, true) ? 'documento_tipo_id' : null);
    $c_file   = in_array('documento_id',  $cols, true) ? 'documento_id'  : (in_array('archivo_id', $cols, true) ? 'archivo_id' : null);

    $empleado_id  = isset($_POST['empleado_id']) ? (int) $_POST['empleado_id'] : 0;
    $descripcion  = isset($_POST['descripcion']) ? sanitize_text_field(wp_unslash($_POST['descripcion'])) : '';
    $fecha_inicio = isset($_POST['fecha_inicio']) ? sanitize_text_field(wp_unslash($_POST['fecha_inicio'])) : '';
    $tipo_id      = isset($_POST['tipo_id']) ? (int) $_POST['tipo_id'] : 0;

    if ($empleado_id <= 0) {
        wp_send_json_error(['message' => __('Empleado requerido', 'midas-rrhh')], 400);
    }
    if (!$fecha_inicio || !self::is_valid_ymd($fecha_inicio)) {
        wp_send_json_error(['message' => __('Fecha de inicio inválida (YYYY-MM-DD)', 'midas-rrhh')], 400);
    }

    // calcular fecha_fin según tipo (si viene y existe en tabla de tipos)
    $fecha_fin_calc = self::docv_calcular_fin_desde_tipo($fecha_inicio, $tipo_id);

    // manejar archivo (opcional)
    $archivo_id = null;
    if (!empty($_FILES['archivo']) && !empty($_FILES['archivo']['name'])) {
        if (!function_exists('media_handle_upload')) {
            require_once(ABSPATH.'wp-admin/includes/file.php');
            require_once(ABSPATH.'wp-admin/includes/media.php');
            require_once(ABSPATH.'wp-admin/includes/image.php');
        }
        $attach_id = media_handle_upload('archivo', 0);
        if (is_wp_error($attach_id)) {
            wp_send_json_error(['message' => __('Error subiendo archivo: ', 'midas-rrhh').$attach_id->get_error_message()], 500);
        }
        $archivo_id = (int)$attach_id;
    }

    // construir data evitando NULL explícitos (omitimos columnas que irían NULL)
    $data = [
        'empleado_id' => $empleado_id,
        $c_desc       => $descripcion,
        $c_inicio     => $fecha_inicio,
    ];
    $format = ['%d', '%s', '%s'];

    if ($c_tipo && $tipo_id > 0) {
        $data[$c_tipo] = $tipo_id;
        $format[] = '%d';
    }
    if ($c_fin && $fecha_fin_calc) {
        $data[$c_fin] = $fecha_fin_calc;
        $format[] = '%s';
    }
    if ($c_file && $archivo_id) {
        $data[$c_file] = $archivo_id;
        $format[] = '%d';
    }

    $ok = $wpdb->insert($t_docs, $data, $format);
    if ($ok === false) {
        wp_send_json_error(['message' => __('No se pudo crear el documento', 'midas-rrhh')], 500);
    }
    $new_id = (int)$wpdb->insert_id;
    wp_send_json_success(['message' => __('Documento creado', 'midas-rrhh'), 'id' => $new_id]);
}

/**
 * Edita documento. Recalcula fecha_fin si hay tipo_id y el tipo tiene plazo.
 * Si suben un archivo nuevo, reemplaza el id de archivo.
 */
public static function doc_editar() {
    self::verify_read_only();
    if (!check_ajax_referer('midas_documentaciones_nonce', 'midas_documentaciones_nonce', false)) {
        wp_send_json_error(['message' => __('Nonce inválido', 'midas-rrhh')], 400);
    }

    global $wpdb;
    $t_docs = $wpdb->prefix.'midas_documentaciones';

    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    if ($id <= 0) {
        wp_send_json_error(['message' => __('ID inválido', 'midas-rrhh')], 400);
    }

    // Columnas variables
    $cols = (array) $wpdb->get_col("SHOW COLUMNS FROM `$t_docs`", 0);
    if (!$cols) {
        wp_send_json_error(['message' => __('No se encontró la tabla de documentos', 'midas-rrhh')], 400);
    }
    $c_desc   = in_array('descripcion',   $cols, true) ? 'descripcion'   : (in_array('detalles', $cols, true) ? 'detalles' : 'descripcion');
    $c_inicio = in_array('fecha_inicio',  $cols, true) ? 'fecha_inicio'  : (in_array('inicio', $cols, true) ? 'inicio' : 'fecha_emision');
    $c_fin    = in_array('fecha_fin',     $cols, true) ? 'fecha_fin'     : (in_array('fin', $cols, true) ? 'fin' : 'vencimiento');
    $c_tipo   = in_array('tipo_id',       $cols, true) ? 'tipo_id'       : (in_array('documento_tipo_id', $cols, true) ? 'documento_tipo_id' : null);
    $c_file   = in_array('documento_id',  $cols, true) ? 'documento_id'  : (in_array('archivo_id', $cols, true) ? 'archivo_id' : null);

    // leer actuales (p/ defaults)
    $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $t_docs WHERE id=%d", $id));
    if (!$row) {
        wp_send_json_error(['message' => __('Documento no encontrado', 'midas-rrhh')], 404);
    }

    // inputs
    $empleado_id  = isset($_POST['empleado_id']) ? (int) $_POST['empleado_id'] : (int)($row->empleado_id ?? 0);
    $descripcion  = isset($_POST['descripcion']) ? sanitize_text_field(wp_unslash($_POST['descripcion'])) : (string)($row->$c_desc ?? '');
    $fecha_inicio = isset($_POST['fecha_inicio']) ? sanitize_text_field(wp_unslash($_POST['fecha_inicio'])) : (string)($row->$c_inicio ?? '');
    $tipo_id      = isset($_POST['tipo_id']) ? (int) $_POST['tipo_id'] : ($c_tipo ? (int)($row->$c_tipo ?? 0) : 0);

    if ($empleado_id <= 0) {
        wp_send_json_error(['message' => __('Empleado requerido', 'midas-rrhh')], 400);
    }
    if (!$fecha_inicio || !self::is_valid_ymd($fecha_inicio)) {
        wp_send_json_error(['message' => __('Fecha de inicio inválida (YYYY-MM-DD)', 'midas-rrhh')], 400);
    }

    // calcular fecha_fin desde tipo (si aplica)
    $fecha_fin_calc = self::docv_calcular_fin_desde_tipo($fecha_inicio, $tipo_id);

    // archivo nuevo (opcional)
    $archivo_id = null;
    if (!empty($_FILES['archivo']) && !empty($_FILES['archivo']['name'])) {
        if (!function_exists('media_handle_upload')) {
            require_once(ABSPATH.'wp-admin/includes/file.php');
            require_once(ABSPATH.'wp-admin/includes/media.php');
            require_once(ABSPATH.'wp-admin/includes/image.php');
        }
        $attach_id = media_handle_upload('archivo', 0);
        if (is_wp_error($attach_id)) {
            wp_send_json_error(['message' => __('Error subiendo archivo: ', 'midas-rrhh').$attach_id->get_error_message()], 500);
        }
        $archivo_id = (int)$attach_id;
    }

    // construir UPDATE dinámico
    $sets   = ['empleado_id = %d', "$c_desc = %s", "$c_inicio = %s"];
    $params = [$empleado_id, $descripcion, $fecha_inicio];

    if ($c_tipo) { $sets[] = "$c_tipo = %d"; $params[] = $tipo_id > 0 ? $tipo_id : null; }
    if ($c_fin)  {
        if ($fecha_fin_calc) { $sets[] = "$c_fin = %s"; $params[] = $fecha_fin_calc; }
        else { $sets[] = "$c_fin = NULL"; }
    }
    if ($c_file && $archivo_id) { $sets[] = "$c_file = %d"; $params[] = $archivo_id; }

    // quitar =%d con NULL no funciona; si $tipo_id<=0, ponemos "col=NULL"
    if ($c_tipo && ($tipo_id <= 0)) {
        foreach ($sets as $i => $s) {
            if ($s === "$c_tipo = %d") { $sets[$i] = "$c_tipo = NULL"; array_pop($params); break; }
        }
    }

    $params[] = $id;
    $sql = "UPDATE $t_docs SET ".implode(', ', $sets)." WHERE id = %d";
    $ok  = $wpdb->query($wpdb->prepare($sql, ...$params));
    if ($ok === false) {
        wp_send_json_error(['message' => __('No se pudo actualizar el documento', 'midas-rrhh')], 500);
    }
    wp_send_json_success(['message' => __('Documento actualizado', 'midas-rrhh'), 'id' => (int)$id]);
}

/**
 * Elimina documento (no borra el adjunto físico).
 */
public static function doc_eliminar() {
    self::verify_read_only();
    if (!check_ajax_referer('midas_documentaciones_nonce', 'midas_documentaciones_nonce', false)) {
        wp_send_json_error(['message' => __('Nonce inválido', 'midas-rrhh')], 400);
    }

    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    if ($id <= 0) {
        wp_send_json_error(['message' => __('ID inválido', 'midas-rrhh')], 400);
    }

    global $wpdb;
    $t_docs = $wpdb->prefix.'midas_documentaciones';
    $ok = $wpdb->delete($t_docs, ['id' => $id], ['%d']);
    if ($ok === false) {
        wp_send_json_error(['message' => __('No se pudo eliminar el documento', 'midas-rrhh')], 500);
    }
    wp_send_json_success(['message' => __('Documento eliminado', 'midas-rrhh')]);
}

/* =========================
 *  Helpers privados
 * ========================= */

/**
 * Valida formato YYYY-MM-DD simple.
 */
private static function is_valid_ymd($s) {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$s)) return false;
    [$y,$m,$d] = array_map('intval', explode('-', $s));
    return checkdate($m,$d,$y);
}

/**
 * Calcula la fecha de fin desde fecha_inicio y tipo_id según la tabla de tipos disponible.
 * Retorna string YYYY-MM-DD o null si no hay plazo.
 */
private static function docv_calcular_fin_desde_tipo($fecha_inicio, $tipo_id) {
    if ($tipo_id <= 0 || !$fecha_inicio) return null;

    global $wpdb;
    $t_tipos = '';
    foreach ([$wpdb->prefix.'midas_documento_tipos', $wpdb->prefix.'midas_documentos_tipos', $wpdb->prefix.'midas_doc_tipos'] as $c) {
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $c))) { $t_tipos = $c; break; }
    }
    if (!$t_tipos) return null;

    $cols = (array) $wpdb->get_col("SHOW COLUMNS FROM `$t_tipos`", 0);
    $has_pair  = in_array('plazo_numero', $cols, true) && in_array('plazo_unidad', $cols, true);
    $c_plazo_1 = null;
    if (!$has_pair) {
        foreach (['plazo','dias','validez_dias'] as $cand) {
            if (in_array($cand, $cols, true)) { $c_plazo_1 = $cand; break; }
        }
    }

    if ($has_pair) {
        $tipo = $wpdb->get_row($wpdb->prepare("SELECT plazo_numero, plazo_unidad FROM $t_tipos WHERE id=%d", $tipo_id));
        if (!$tipo) return null;
        $n = (int)($tipo->plazo_numero ?? 0);
        $u = strtolower((string)($tipo->plazo_unidad ?? ''));
        if ($n <= 0 || !$u) return null;

        $dt = \DateTime::createFromFormat('Y-m-d', $fecha_inicio);
        if (!$dt) return null;
        if ($u === 'dias' || $u === 'días')       { $dt->modify("+{$n} days"); }
        elseif ($u === 'meses')                   { $dt->modify("+{$n} months"); }
        elseif ($u === 'anios' || $u === 'años')  { $dt->modify("+{$n} years"); }
        else                                      { $dt->modify("+{$n} days"); } // fallback
        return $dt->format('Y-m-d');

    } elseif ($c_plazo_1) {
        $dias = (int)$wpdb->get_var($wpdb->prepare("SELECT $c_plazo_1 FROM $t_tipos WHERE id=%d", $tipo_id));
        if ($dias <= 0) return null;
        $dt = \DateTime::createFromFormat('Y-m-d', $fecha_inicio);
        if (!$dt) return null;
        $dt->modify("+{$dias} days");
        return $dt->format('Y-m-d');
    }

    return null;
}

/* ========= PALETA (scoped a Midas RRHH) ========= */
public static function palette_get() {
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => __('Debes iniciar sesión.', 'midas-rrhh')], 401);
    }
    $opt = get_option('midas_rrhh_palette_scoped', []);
    if (!is_array($opt)) $opt = [];
    wp_send_json_success(['palette' => $opt]);
}

public static function palette_save() {
    // Acepta varios nombres de nonce para compat.
    $nonce = $_POST['nonce']
        ?? $_POST['midas_palette_scoped_nonce']
        ?? $_POST['_wpnonce']
        ?? '';

    if (!$nonce || !wp_verify_nonce($nonce, 'midas_palette_scoped_nonce')) {
        wp_send_json_error(['message' => __('Nonce inválido.', 'midas-rrhh')], 403);
    }
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => __('Debes iniciar sesión.', 'midas-rrhh')], 401);
    }
    if (!current_user_can('rrhh_admin') && !current_user_can('manage_options') && !current_user_can('administrator')) {
        wp_send_json_error(['message' => __('Permiso denegado.', 'midas-rrhh')], 403);
    }

    $raw  = isset($_POST['palette']) ? wp_unslash((string)$_POST['palette']) : '';
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        wp_send_json_error(['message' => __('Payload inválido.', 'midas-rrhh')], 400);
    }

    // Normalizador HEX -> #RRGGBB
    $norm_hex = function ($v) {
        if (!is_string($v)) return null;
        $v = trim($v);
        if (preg_match('/^#([0-9a-fA-F]{3})$/', $v, $m)) {
            $h = strtoupper($m[1]);
            return '#'.$h[0].$h[0].$h[1].$h[1].$h[2].$h[2];
        }
        if (preg_match('/^#([0-9a-fA-F]{6})$/', $v, $m)) {
            return '#'.strtoupper($m[1]);
        }
        return null;
    };

    $cards = $data['cards'] ?? [];
    $text  = $data['text']  ?? [];
    $clean = [
        'cards' => [
            'bg'        => $norm_hex($cards['bg']        ?? '') ?: '#FFFFFF',
            'border'    => $norm_hex($cards['border']    ?? '') ?: '#CCD0D4',
            'headerBg'  => $norm_hex($cards['headerBg']  ?? '') ?: '#F7F7F7',
            'headerTxt' => $norm_hex($cards['headerTxt'] ?? '') ?: '#1F2937',
            'stripe'    => $norm_hex($cards['stripe']    ?? '') ?: '#F9FAFB',
        ],
        'text' => [
            'txt'   => $norm_hex($text['txt']   ?? '') ?: '#1E293B',
            'muted' => $norm_hex($text['muted'] ?? '') ?: '#475569',
        ],
    ];

    update_option('midas_rrhh_palette_scoped', $clean, false);
    wp_send_json_success(['saved' => $clean]);
}

/* ========= DASHBOARD: Conectados dentro de Midas RRHH ========= */

/**
 * Marca al usuario como activo específicamente en páginas de Midas (guardamos timestamp).
 * Llamar este endpoint desde el JS del admin del plugin cada 60–120s.
 *
 * Acepta (opcionalmente) cualquiera de estos nonces:
 *  - midas_dash_nonce
 *  - midas_empleados_nonce
 *  - midas_cm_nonce
 * Si no llega nonce, igual requiere que el usuario esté logueado.
 */
public static function dash_ping() {
    if ( ! is_user_logged_in() ) {
        wp_send_json_error(['message' => __('Debes iniciar sesión.', 'midas-rrhh')], 401);
    }

    // Verificación flexible de nonce (si vino alguno)
    $token = $_POST['nonce']
        ?? $_POST['midas_dash_nonce']
        ?? $_POST['midas_empleados_nonce']
        ?? $_POST['midas_cm_nonce']
        ?? $_POST['_wpnonce']
        ?? null;

    if ( $token ) {
        $ok = (
            wp_verify_nonce( $token, 'midas_dash_nonce' ) ||
            wp_verify_nonce( $token, 'midas_empleados_nonce' ) ||
            wp_verify_nonce( $token, 'midas_cm_nonce' )
        );
        if ( ! $ok ) {
            wp_send_json_error(['message' => __('Nonce inválido.', 'midas-rrhh')], 403);
        }
    }

    $user_id = get_current_user_id();
    $now     = time();

    // Guarda último ping
    update_user_meta( $user_id, 'midas_rrhh_last_ping', $now );

    // (Opcional) guarda el scope/pestaña desde donde se hizo ping
    $scope = isset($_POST['scope']) ? sanitize_text_field( wp_unslash($_POST['scope']) ) : '';
    if ($scope !== '') {
        update_user_meta( $user_id, 'midas_rrhh_last_scope', $scope );
    }

    wp_send_json_success([
        'ts'    => $now,
        'scope' => $scope,
    ]);
}

/**
 * Devuelve conectados (usuarios con ping < window segundos).
 * Por defecto, ventana de 5 minutos. Restringido a quienes pueden ver/gestionar el dashboard.
 *
 * POST:
 *  - window (int, opcional): ventana en segundos (60–1800). Default 300.
 *  - nonce/midas_dash_nonce/midas_empleados_nonce/midas_cm_nonce (opcional)
 */
public static function dash_conectados() {
    // Verificación flexible de nonce (si vino alguno)
    $token = $_POST['nonce']
        ?? $_POST['midas_dash_nonce']
        ?? $_POST['midas_empleados_nonce']
        ?? $_POST['midas_cm_nonce']
        ?? $_POST['_wpnonce']
        ?? null;

    if ( $token ) {
        $ok = (
            wp_verify_nonce( $token, 'midas_dash_nonce' ) ||
            wp_verify_nonce( $token, 'midas_empleados_nonce' ) ||
            wp_verify_nonce( $token, 'midas_cm_nonce' )
        );
        if ( ! $ok ) {
            wp_send_json_error(['message' => __('Nonce inválido.', 'midas-rrhh')], 403);
        }
    }

    if ( ! is_user_logged_in() ) {
        wp_send_json_error(['message' => __('Debes iniciar sesión.', 'midas-rrhh')], 401);
    }

    // Permisos: cualquiera que ya tiene acceso de gestión/visualización al dashboard de Midas
    if (
        ! current_user_can('edit_midas_empleados') &&
        ! current_user_can('rrhh_gestor') &&
        ! current_user_can('rrhh_admin') &&
        ! current_user_can('manage_options') &&
        ! current_user_can('administrator')
    ) {
        wp_send_json_error(['message' => __('Permiso denegado.', 'midas-rrhh')], 403);
    }

    // Ventana segura (min 60s, max 1800s)
    $window = isset($_POST['window']) ? intval($_POST['window']) : 300;
    if ($window < 60)   $window = 60;
    if ($window > 1800) $window = 1800;

    $cutoff = time() - $window;

    // Usuarios con meta "midas_rrhh_last_ping" dentro de ventana
    $q = new \WP_User_Query([
        'number'       => -1,
        'meta_key'     => 'midas_rrhh_last_ping',
        'meta_value'   => $cutoff,
        'meta_compare' => '>=',
        'meta_type'    => 'NUMERIC',
        'fields'       => ['ID', 'display_name', 'user_email'],
    ]);
    $users = $q->get_results();

    $list = [];
    if ( ! empty($users) && is_array($users) ) {
        $now = time();
        foreach ( $users as $u ) {
            $last  = (int) get_user_meta($u->ID, 'midas_rrhh_last_ping', true);
            $scope = (string) get_user_meta($u->ID, 'midas_rrhh_last_scope', true);
            $list[] = [
                'id'    => (int) $u->ID,
                'name'  => (string) $u->display_name,
                'email' => (string) $u->user_email,
                'ago'   => max(0, $now - $last),
                'last'  => $last,
                'scope' => $scope, // última pestaña/página reportada por el ping
            ];
        }

        // Ordenar por el más reciente primero (menor "ago")
        usort($list, static function($a, $b) {
            if ($a['ago'] === $b['ago']) {
                // desempate por nombre para tener orden estable
                return strcmp($a['name'], $b['name']);
            }
            return $a['ago'] <=> $b['ago'];
        });
    }

    wp_send_json_success([
        'count'  => count($list),
        'items'  => $list,
        'window' => $window,
        'now'    => time(),
    ]);
}

/*──────────────────────────────────────────────────────────────────────────────
  MIDAS RRHH — ORGANIGRAMA: 
──────────────────────────────────────────────────────────────────────────────*/

/** @var \MidasRRHH\Controllers\Organigrama_Controller|null */
private static $orgchart_controller = null;

/** Carga perezosa del Organigrama_Controller (si existe) */
private static function get_orgchart_controller() {
    if (self::$orgchart_controller instanceof \MidasRRHH\Controllers\Organigrama_Controller) {
        return self::$orgchart_controller;
    }
    // Cargar clase si no está ya cargada (ajusta la ruta si es distinta)
    if (!class_exists('\MidasRRHH\Controllers\Organigrama_Controller')) {
        if (defined('MIDAS_RRHH_PLUGIN_DIR')) {
            $path = rtrim(MIDAS_RRHH_PLUGIN_DIR, '/').'/controllers/Organigrama_Controller.php';
            if (file_exists($path)) {
                require_once $path;
            }
        }
    }
    if (class_exists('\MidasRRHH\Controllers\Organigrama_Controller')) {
        self::$orgchart_controller = new \MidasRRHH\Controllers\Organigrama_Controller();
        return self::$orgchart_controller;
    }
    return null;
}

/** GET: devuelve el árbol del organigrama */
public static function orgchart_get() {
    // Nonce y permisos (mismo esquema que el controller original)
    if (!check_ajax_referer('midas_orgchart_nonce', 'nonce', false)) {
        wp_send_json_error(['message' => __('Nonce inválido.', 'midas-rrhh')], 403);
    }
    if (!current_user_can('edit_midas_empleados') && !current_user_can('manage_options')) {
        wp_send_json_error(['message' => __('Sin permisos.', 'midas-rrhh')], 403);
    }

    // Delegamos al controller si está disponible
    if ($ctl = self::get_orgchart_controller()) {
        // El controller ya hace wp_send_json_* internamente
        return $ctl->ajax_get();
    }

    // Fallback: sin controller, devolvemos un árbol vacío (evita "0")
    wp_send_json_success(['tree' => [], 'source' => 'fallback']);
}

/** SAVE: persiste el árbol del organigrama */
public static function orgchart_save() {
    if (!check_ajax_referer('midas_orgchart_nonce', 'nonce', false)) {
        wp_send_json_error(['message' => __('Nonce inválido.', 'midas-rrhh')], 403);
    }
    if (!current_user_can('edit_midas_empleados') && !current_user_can('manage_options')) {
        wp_send_json_error(['message' => __('Sin permisos.', 'midas-rrhh')], 403);
    }

    // Normalizamos el payload (acepta JSON string o array)
    $payload = isset($_POST['data']) ? wp_unslash($_POST['data']) : null;
    if (is_string($payload)) {
        $decoded = json_decode($payload, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            $payload = $decoded;
        }
    }
    if (empty($payload) || !is_array($payload)) {
        wp_send_json_error(['message' => __('Payload vacío o inválido.', 'midas-rrhh')], 400);
    }

    // Delegamos al controller si está disponible
    if ($ctl = self::get_orgchart_controller()) {
        // Muchos controllers esperan $_POST['data'] como string JSON;
        // si el tuyo lo necesita así, vuelve a codificar:
        $_POST['data'] = wp_json_encode($payload);
        return $ctl->ajax_save();
    }

    // Fallback: guardamos directo como opción (no recomendado, pero útil de emergencia)
    update_option('midas_orgchart_tree', $payload, false);
    wp_send_json_success(['saved' => true, 'source' => 'fallback']);
}




}

// Instanciar para registrar los hooks
add_action('init', ['MidasRRHH\Ajax\Ajax_Handler', 'init']);

// =========================
// AJAX: MARCAR LICENCIA COMO VISTA (fuera de la clase)
// =========================
add_action('wp_ajax_midas_marcar_licencia_vista', function() {
    // ✅ Nonce flexible: acepta 'nonce' o 'midas_empleados_nonce' con acción 'midas_empleados_nonce'
    $token = $_POST['nonce'] ?? $_GET['nonce'] ?? $_POST['midas_empleados_nonce'] ?? $_GET['midas_empleados_nonce'] ?? '';
    if (!$token || !wp_verify_nonce($token, 'midas_empleados_nonce')) {
        wp_send_json_error(['message' => 'Nonce inválido.'], 403);
    }
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Debes iniciar sesión.'], 401);
    }
    if (!current_user_can('rrhh_gestor') && !current_user_can('rrhh_admin') && !current_user_can('administrator')) {
        wp_send_json_error(['message' => 'No autorizado para marcar licencias como vistas.'], 403);
    }

    $licencia_id = intval($_POST['licencia_id'] ?? 0);
    if ($licencia_id <= 0) {
        wp_send_json_error(['message' => 'ID de licencia inválido.'], 400);
    }

    global $wpdb;
    $table   = $wpdb->prefix . 'midas_licencias';
    $updated = $wpdb->update($table, ['visto' => 1], ['id' => $licencia_id]);

    if ($updated === false) {
        wp_send_json_error(['message' => 'Error al marcar como visto.'], 400);
    }

    if (function_exists(__NAMESPACE__.'\\midas_clear_licencias_cache')) midas_clear_licencias_cache();

    wp_send_json_success(['message' => 'Licencia marcada como vista']);
});

// =========================
// AJAX: GUARDAR OPCIONES BLOQUEADAS POR ROL (FRONTEND)
// =========================
add_action('wp_ajax_midas_guardar_opciones_bloqueadas', function() {
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'midas_roles_nonce')) {
        wp_send_json_error(['message' => 'Nonce inválido. Intenta refrescar la página.'], 403);
    }
    if (!current_user_can('rrhh_admin') && !current_user_can('administrator')) {
        wp_send_json_error(['message' => 'No tienes permiso para hacer esto.'], 403);
    }

    $rol      = sanitize_text_field($_POST['rol'] ?? '');
    $opciones = isset($_POST['opciones']) ? json_decode(stripslashes($_POST['opciones']), true) : [];
    if (!$rol) wp_send_json_error(['message' => 'Rol no especificado.'], 400);
    if (!is_array($opciones)) $opciones = [];

    $opciones = array_values(array_unique(array_filter(array_map('sanitize_key', $opciones))));

    $all_bloqueadas = get_option('midas_rrhh_opciones_bloqueadas', []);
    if (!is_array($all_bloqueadas)) $all_bloqueadas = [];
    $prev = $all_bloqueadas[$rol] ?? [];
    if (!is_array($prev)) $prev = [];
    $prev = array_values(array_unique(array_filter(array_map('sanitize_key', $prev))));

    if ($prev === $opciones) {
        wp_send_json_success(['message' => 'Opciones bloqueadas actualizadas']);
    }

    $all_bloqueadas[$rol] = $opciones;
    $ok = update_option('midas_rrhh_opciones_bloqueadas', $all_bloqueadas);

    if ($ok === false) {
        $check = get_option('midas_rrhh_opciones_bloqueadas', []);
        $check = is_array($check) ? $check : [];
        $final = $check[$rol] ?? [];
        $final = array_values(array_unique(array_filter(array_map('sanitize_key', (array)$final))));
        if ($final === $opciones) {
            wp_send_json_success(['message' => 'Opciones bloqueadas actualizadas']);
        }
        wp_send_json_error(['message' => 'No se pudo guardar.'], 500);
    }

    wp_send_json_success(['message' => 'Opciones bloqueadas actualizadas']);
});

// =========================
// AJAX: GUARDAR TABS OCULTAS POR USUARIO (BACKEND)
// =========================

// Helper para normalizar aliases hacia claves canónicas
if (!function_exists('midas_rrhh_normalize_tab_key')) {
    function midas_rrhh_normalize_tab_key($key) {
        $k = sanitize_key($key);
        $aliases = [
            'instancia'     => 'tickets',
            'instancias'    => 'tickets',
            'ticket'        => 'tickets',
            'informe'       => 'reportes',
            'informes'      => 'reportes',
            'configuracion' => 'ajustes',
        ];
        return isset($aliases[$k]) ? $aliases[$k] : $k;
    }
}

add_action('wp_ajax_midas_guardar_tabs', function () {
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'midas_roles_nonce')) {
        wp_send_json_error(['message' => 'Nonce inválido. Intenta refrescar la página.', 'code' => 'bad_nonce'], 403);
    }
    if (!is_user_logged_in() || (!current_user_can('rrhh_admin') && !current_user_can('administrator'))) {
        wp_send_json_error(['message' => 'No tienes permiso para hacer esto.'], 403);
    }

    $user_id = absint($_POST['user_id'] ?? 0);
    $tabs_in = $_POST['tabs'] ?? '[]';
    $tabs    = json_decode(stripslashes($tabs_in), true);
    if (!is_array($tabs)) $tabs = [];

    if ($user_id <= 0 || !get_user_by('id', $user_id)) {
        wp_send_json_error(['message' => 'Usuario inválido.'], 400);
    }

    // ====== CLAVES VÁLIDAS: usar SIEMPRE el mapa canónico del enforcer ======
    $tab_map = function_exists('midas_rrhh_tab_map') ? midas_rrhh_tab_map() : [
        'dashboard'      => 'midas-rrhh',
        'empleados'      => 'midas-empleados',
        'recibos'        => 'midas-recibos',
        'licencias'      => 'midas-licencias',
        'carpeta_medica' => 'midas-carpeta-medica',
        'tickets'        => 'midas-tickets',   // UI: “Instancias”
        'reportes'       => 'midas-reportes',
        'ajustes'        => 'midas-configuracion',
        'roles'          => 'midas-roles',
    ];
    $valid_keys = array_map('sanitize_key', array_keys($tab_map));

    // ❗ Normalizar -> sanitizar -> limitar a válidas
    $tabs = array_map('midas_rrhh_normalize_tab_key', $tabs);
    $tabs = array_values(array_unique(array_filter(array_map('sanitize_key', $tabs))));
    $tabs = array_values(array_intersect($tabs, $valid_keys));

    $ok = false;

    try {
        // Intentar guardar vía controlador si existe
        $saved_via_controller = false;
        try {
            if (class_exists('\MidasRRHH\Controllers\Rol_Controller')) {
                $rc = new \MidasRRHH\Controllers\Rol_Controller();
                if (method_exists($rc, 'guardar_tabs_usuario')) {
                    $tmp = $rc->guardar_tabs_usuario($user_id, $tabs);
                    if (is_wp_error($tmp)) {
                        wp_send_json_error(['message' => $tmp->get_error_message()], 500);
                    }
                    $ok = (bool) $tmp;
                    $saved_via_controller = true;

                    // Tratar "sin cambios" como éxito, comparando NORMALIZADO
                    if ($ok === false) {
                        $actual = method_exists($rc, 'obtener_tabs_usuario')
                            ? (array) $rc->obtener_tabs_usuario($user_id)
                            : (array) get_user_meta($user_id, 'midas_rrhh_tabs_ocultas', true);
                        $actual = array_map('midas_rrhh_normalize_tab_key', $actual);
                        $actual = array_values(array_unique(array_filter(array_map('sanitize_key', $actual))));
                        $actual = array_values(array_intersect($actual, $valid_keys));
                        if ($actual === $tabs) $ok = true;
                    }
                }
            }
        } catch (\Throwable $e) {
            // fall back a user_meta
        }

        if (!$saved_via_controller) {
            // Guardar en user_meta
            $prev = (array) get_user_meta($user_id, 'midas_rrhh_tabs_ocultas', true);
            $prev = array_map('midas_rrhh_normalize_tab_key', $prev);
            $prev = array_values(array_unique(array_filter(array_map('sanitize_key', $prev))));
            $prev = array_values(array_intersect($prev, $valid_keys));

            if ($prev === $tabs) {
                $ok = true; // sin cambios
            } else {
                $ok = (bool) update_user_meta($user_id, 'midas_rrhh_tabs_ocultas', $tabs);
                if ($ok === false) {
                    // Confirmar si igualmente quedó igual
                    $check = (array) get_user_meta($user_id, 'midas_rrhh_tabs_ocultas', true);
                    $check = array_map('midas_rrhh_normalize_tab_key', $check);
                    $check = array_values(array_unique(array_filter(array_map('sanitize_key', $check))));
                    $check = array_values(array_intersect($check, $valid_keys));
                    if ($check === $tabs) $ok = true;
                }
            }
        }
    } catch (\Throwable $e) {
        error_log('[MidasRRHH][midas_guardar_tabs] ERROR: ' . $e->getMessage());
        wp_send_json_error(['message' => 'Error interno al guardar.'], 500);
    }

    if (!$ok) {
        wp_send_json_error(['message' => 'No se pudo guardar.'], 500);
    }

    wp_send_json_success(['message' => 'Guardado correcto.']);
});


// =========================
// AJAX: MARCAR DOCUMENTO MÉDICO COMO VISTO
// =========================
add_action('wp_ajax_midas_marcar_documento_visto', function () {
    // Acepta cualquiera de estos campos: midas_cm_nonce, midas_empleados_nonce o nonce (alias)
    $ok = false;

    if (!empty($_POST['midas_cm_nonce']) && wp_verify_nonce($_POST['midas_cm_nonce'], 'midas_cm_nonce')) {
        $ok = true;
    } elseif (!empty($_POST['midas_empleados_nonce']) && wp_verify_nonce($_POST['midas_empleados_nonce'], 'midas_empleados_nonce')) {
        $ok = true;
    } elseif (!empty($_POST['nonce']) && (
        wp_verify_nonce($_POST['nonce'], 'midas_cm_nonce') ||
        wp_verify_nonce($_POST['nonce'], 'midas_empleados_nonce')
    )) {
        $ok = true;
    }

    if (!$ok) {
        // Opcional para depurar:
        // error_log('[midas_marcar_documento_visto] POST: '.print_r($_POST,true));
        wp_send_json_error(['message' => 'Nonce inválido.'], 403);
    }
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Debes iniciar sesión.'], 401);
    }
    if (!current_user_can('rrhh_gestor') && !current_user_can('rrhh_admin') && !current_user_can('administrator')) {
        wp_send_json_error(['message' => 'No autorizado.'], 403);
    }

    $documento_id = intval($_POST['documento_id'] ?? 0);
    if ($documento_id <= 0) wp_send_json_error(['message' => 'ID de documento inválido.'], 400);

    global $wpdb;
    $candidatas = [
        $wpdb->prefix.'midas_documentos_medicos',
        $wpdb->prefix.'midas_carpeta_medica',
        $wpdb->prefix.'midas_documentos',
    ];

    $ok2 = false; $err = '';
    foreach ($candidatas as $tabla) {
        $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tabla));
        if (!$exists) continue;

        $col = null;
        foreach (['visto','leido','visto_rrhh','leido_rrhh'] as $c) {
            $has = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$tabla` LIKE %s", $c));
            if ($has) { $col = $c; break; }
        }
        if (!$col) continue;

        $u = $wpdb->update($tabla, [$col => 1], ['id' => $documento_id], ['%d'], ['%d']);
        if ($u !== false) { $ok2 = true; break; } else { $err = 'No se pudo actualizar.'; }
    }

    if (!$ok2) {
        wp_send_json_error(['message' => $err ?: 'No se encontró tabla/columna para marcar visto.'], 400);
    }

    if (function_exists(__NAMESPACE__.'\\midas_clear_carpeta_medica_cache')) midas_clear_carpeta_medica_cache();
    wp_send_json_success(['message' => 'Documento marcado como visto']);
});

// =========================
// AJAX: MARCAR RECIBO COMO VISTO
// =========================
add_action('wp_ajax_midas_marcar_recibo_visto', function () {
    // Acepta midas_empleados_nonce o nonce (alias)
    $ok = false;

    if (!empty($_POST['midas_empleados_nonce']) && wp_verify_nonce($_POST['midas_empleados_nonce'], 'midas_empleados_nonce')) {
        $ok = true;
    } elseif (!empty($_POST['nonce']) && wp_verify_nonce($_POST['nonce'], 'midas_empleados_nonce')) {
        $ok = true;
    }

    if (!$ok) {
        // error_log('[midas_marcar_recibo_visto] POST: '.print_r($_POST,true));
        wp_send_json_error(['message' => 'Nonce inválido.'], 403);
    }
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Debes iniciar sesión.'], 401);
    }
    if (!current_user_can('rrhh_gestor') && !current_user_can('rrhh_admin') && !current_user_can('administrator')) {
        wp_send_json_error(['message' => 'No autorizado.'], 403);
    }

    $recibo_id = intval($_POST['recibo_id'] ?? 0);
    if ($recibo_id <= 0) wp_send_json_error(['message' => 'ID de recibo inválido.'], 400);

    global $wpdb;
    $tabla = $wpdb->prefix.'midas_recibos';

    $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tabla));
    if (!$exists) wp_send_json_error(['message' => 'Tabla de recibos no encontrada.'], 500);

    $col = null;
    foreach (['visto','leido','visto_rrhh','leido_rrhh'] as $c) {
        $has = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$tabla` LIKE %s", $c));
        if ($has) { $col = $c; break; }
    }
    if (!$col) {
        wp_send_json_error(['message' => 'La tabla de recibos no tiene columna de “visto/leído”.'], 500);
    }

    $u = $wpdb->update($tabla, [$col => 1], ['id' => $recibo_id], ['%d'], ['%d']);
    if ($u === false) wp_send_json_error(['message' => 'No se pudo marcar como visto.'], 400);

    if (function_exists(__NAMESPACE__.'\\midas_clear_recibos_cache')) midas_clear_recibos_cache();
    wp_send_json_success(['message' => 'Recibo marcado como visto']);
});
