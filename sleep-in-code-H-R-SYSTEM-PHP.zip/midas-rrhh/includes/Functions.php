<?php
// Funciones útiles para el plugin

function midas_rrhh_get_empleado_by_user_id($user_id) {
    $empleado_model = new MidasRRHH\Models\Empleado_Model();
    return $empleado_model->get_by_user_id($user_id);
}

function midas_rrhh_get_empleado_data($empleado_id) {
    $empleado_controller = new MidasRRHH\Controllers\Empleado_Controller();
    return $empleado_controller->obtener_empleado($empleado_id);
}

function midas_rrhh_get_recibos_empleado($empleado_id) {
    $recibo_controller = new MidasRRHH\Controllers\Recibo_Controller();
    return $recibo_controller->obtener_recibos_empleado($empleado_id);
}

function midas_rrhh_get_licencias_empleado($empleado_id) {
    $licencia_controller = new MidasRRHH\Controllers\Licencia_Controller();
    return $licencia_controller->obtener_licencias_empleado($empleado_id);
}

function midas_rrhh_get_documentos_medicos_empleado($empleado_id) {
    $carpeta_controller = new MidasRRHH\Controllers\Carpeta_Medica_Controller();
    return $carpeta_controller->obtener_documentos_empleado($empleado_id);
}

function midas_rrhh_calcular_edad($fecha_nacimiento) {
    $nacimiento = new DateTime($fecha_nacimiento);
    $hoy = new DateTime();
    $edad = $hoy->diff($nacimiento);
    return $edad->y;
}

function midas_rrhh_calcular_antiguedad($fecha_inicio) {
    $inicio = new DateTime($fecha_inicio);
    $hoy = new DateTime();
    $antiguedad = $hoy->diff($inicio);
    
    $years = $antiguedad->y;
    $months = $antiguedad->m;
    
    $parts = [];
    if ($years > 0) {
        $parts[] = sprintf(_n('%d año', '%d años', $years, 'midas-rrhh'), $years);
    }
    if ($months > 0) {
        $parts[] = sprintf(_n('%d mes', '%d meses', $months, 'midas-rrhh'), $months);
    }
    
    return implode(' ', $parts);
}

function midas_rrhh_format_date($date, $format = 'd/m/Y') {
    if (empty($date)) {
        return '';
    }
    return date_i18n($format, strtotime($date));
}