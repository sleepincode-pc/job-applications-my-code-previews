<?php
namespace MidasRRHH\Controllers;

if (!defined('ABSPATH')) exit;

/**
 * Controlador de configuración global para tablas auxiliares
 * Áreas, Tareas, Enfermedades, Médicos, Tipos de Licencia
 * ¡Listo para WordPress en Linux!
 */
class Configuracion_Controller
{
    // Registra los hooks para AJAX (invoca esto una vez desde el loader principal)
    public static function hooks()
    {
        add_action('wp_ajax_midas_agregar_configuracion', [self::class, 'agregar_configuracion']);
        add_action('wp_ajax_midas_editar_configuracion', [self::class, 'editar_configuracion']);
        add_action('wp_ajax_midas_eliminar_configuracion', [self::class, 'eliminar_configuracion']);
    }

    // ============= AGREGAR =============
    public static function agregar_configuracion()
    {
        global $wpdb;
        if (!current_user_can('manage_options')) {
            wp_send_json_error('No autorizado.');
        }
        $tabla = sanitize_text_field($_POST['tabla'] ?? '');

        $botones = function($tabla, $id) {
            return "<button type='button' class='button button-small midas-btn-editar' data-tabla='{$tabla}' data-id='{$id}'>Editar</button>
                <button type='button' class='button button-small midas-btn-eliminar' data-tabla='{$tabla}' data-id='{$id}'>Eliminar</button>";
        };

        // --- TAREAS ---
        if ($tabla === 'tabla-tareas') {
            $nombre = sanitize_text_field($_POST['nombre'] ?? '');
            $descripcion = sanitize_textarea_field($_POST['descripcion'] ?? '');
            $activo = isset($_POST['activo']) ? intval($_POST['activo']) : 1;
            if (!$nombre || !$descripcion) {
                wp_send_json_error('Completa todos los campos.');
            }
            $wpdb->insert($wpdb->prefix . 'midas_tareas', [
                'nombre' => $nombre,
                'descripcion' => $descripcion,
                'activo' => $activo
            ], ['%s', '%s', '%d']);
            $id = $wpdb->insert_id;
            $row_html = "<tr data-id='{$id}'>
                <td>{$id}</td>
                <td>" . esc_html($nombre) . "</td>
                <td>" . esc_html($descripcion) . "</td>
                <td>" . ($activo ? 'Activo' : 'Inactivo') . "</td>
                <td>{$botones('tabla-tareas', $id)}</td>
            </tr>";
            wp_send_json_success(['tabla_id' => 'tabla-tareas', 'row_html' => $row_html, 'id' => $id]);
        }

        // --- AREAS ---
        elseif ($tabla === 'tabla-areas') {
            $nombre = sanitize_text_field($_POST['nombre'] ?? '');
            $rol = sanitize_text_field($_POST['rol'] ?? '');
            $activo = isset($_POST['activo']) ? intval($_POST['activo']) : 1;
            if (!$nombre || !$rol) {
                wp_send_json_error('Completa todos los campos.');
            }
            $wpdb->insert($wpdb->prefix . 'midas_areas', [
                'nombre' => $nombre,
                'rol' => $rol,
                'activo' => $activo
            ], ['%s', '%s', '%d']);
            $id = $wpdb->insert_id;
            $row_html = "<tr data-id='{$id}'>
                <td>{$id}</td>
                <td>" . esc_html($nombre) . "</td>
                <td>" . esc_html($rol) . "</td>
                <td>" . ($activo ? 'Activo' : 'Inactivo') . "</td>
                <td>{$botones('tabla-areas', $id)}</td>
            </tr>";
            wp_send_json_success(['tabla_id' => 'tabla-areas', 'row_html' => $row_html, 'id' => $id]);
        }

        // --- ENFERMEDADES ---
        elseif ($tabla === 'tabla-enfermedades') {
            $tipo = sanitize_text_field($_POST['tipo'] ?? '');
            $descripcion = sanitize_textarea_field($_POST['descripcion'] ?? '');
            if (!$tipo || !$descripcion) {
                wp_send_json_error('Completa todos los campos.');
            }
            $wpdb->insert($wpdb->prefix . 'midas_enfermedades', [
                'tipo' => $tipo,
                'descripcion' => $descripcion
            ], ['%s', '%s']);
            $id = $wpdb->insert_id;
            $row_html = "<tr data-id='{$id}'>
                <td>{$id}</td>
                <td>" . esc_html($tipo) . "</td>
                <td>" . esc_html($descripcion) . "</td>
                <td>{$botones('tabla-enfermedades', $id)}</td>
            </tr>";
            wp_send_json_success(['tabla_id' => 'tabla-enfermedades', 'row_html' => $row_html, 'id' => $id]);
        }

        // --- MÉDICOS ---
        elseif ($tabla === 'tabla-medicos') {
            $nombre = sanitize_text_field($_POST['nombre'] ?? '');
            $apellido = sanitize_text_field($_POST['apellido'] ?? '');
            $especialidad = sanitize_text_field($_POST['especialidad'] ?? '');
            $matricula = sanitize_text_field($_POST['matricula'] ?? '');
            if (!$nombre || !$apellido) {
                wp_send_json_error('Completa nombre y apellido.');
            }
            $wpdb->insert($wpdb->prefix . 'midas_medicos', [
                'nombre' => $nombre,
                'apellido' => $apellido,
                'especialidad' => $especialidad,
                'matricula' => $matricula
            ], ['%s', '%s', '%s', '%s']);
            $id = $wpdb->insert_id;
            $row_html = "<tr data-id='{$id}'>
                <td>{$id}</td>
                <td>" . esc_html($nombre) . "</td>
                <td>" . esc_html($apellido) . "</td>
                <td>" . esc_html($especialidad) . "</td>
                <td>" . esc_html($matricula) . "</td>
                <td>{$botones('tabla-medicos', $id)}</td>
            </tr>";
            wp_send_json_success(['tabla_id' => 'tabla-medicos', 'row_html' => $row_html, 'id' => $id]);
        }

        // --- LICENCIAS ---
        elseif ($tabla === 'tabla-licencias') {
            $tipo = sanitize_text_field($_POST['tipo'] ?? '');
            $descripcion = sanitize_textarea_field($_POST['descripcion'] ?? '');
            if (!$tipo || !$descripcion) {
                wp_send_json_error('Completa todos los campos.');
            }
            $wpdb->insert($wpdb->prefix . 'midas_licencia_tipos', [
                'tipo' => $tipo,
                'descripcion' => $descripcion
            ], ['%s', '%s']);
            $id = $wpdb->insert_id;
            $row_html = "<tr data-id='{$id}'>
                <td>{$id}</td>
                <td>" . esc_html($tipo) . "</td>
                <td>" . esc_html($descripcion) . "</td>
                <td>{$botones('tabla-licencias', $id)}</td>
            </tr>";
            wp_send_json_success(['tabla_id' => 'tabla-licencias', 'row_html' => $row_html, 'id' => $id]);
        }

        wp_send_json_error('Tabla desconocida.');
    }

    // ============= EDITAR =============
    public static function editar_configuracion()
    {
        global $wpdb;
        if (!current_user_can('manage_options')) {
            wp_send_json_error('No autorizado.');
        }
        $tabla = sanitize_text_field($_POST['tabla'] ?? '');
        $id = intval($_POST['registro_id'] ?? 0);
        if (!$id) wp_send_json_error('ID inválido');

        $botones = function($tabla, $id) {
            return "<button type='button' class='button button-small midas-btn-editar' data-tabla='{$tabla}' data-id='{$id}'>Editar</button>
                <button type='button' class='button button-small midas-btn-eliminar' data-tabla='{$tabla}' data-id='{$id}'>Eliminar</button>";
        };

        // --- TAREAS ---
        if ($tabla === 'tabla-tareas') {
            $nombre = sanitize_text_field($_POST['nombre'] ?? '');
            $descripcion = sanitize_textarea_field($_POST['descripcion'] ?? '');
            $activo = isset($_POST['activo']) ? intval($_POST['activo']) : 1;
            if (!$nombre || !$descripcion) {
                wp_send_json_error('Completa todos los campos.');
            }
            $wpdb->update($wpdb->prefix . 'midas_tareas', [
                'nombre' => $nombre,
                'descripcion' => $descripcion,
                'activo' => $activo
            ], ['id' => $id], ['%s', '%s', '%d'], ['%d']);
            $row_html = "<tr data-id='{$id}'>
                <td>{$id}</td>
                <td>" . esc_html($nombre) . "</td>
                <td>" . esc_html($descripcion) . "</td>
                <td>" . ($activo ? 'Activo' : 'Inactivo') . "</td>
                <td>{$botones('tabla-tareas', $id)}</td>
            </tr>";
            wp_send_json_success(['tabla_id' => 'tabla-tareas', 'row_html' => $row_html, 'id' => $id]);
        }

        // --- AREAS ---
        elseif ($tabla === 'tabla-areas') {
            $nombre = sanitize_text_field($_POST['nombre'] ?? '');
            $rol = sanitize_text_field($_POST['rol'] ?? '');
            $activo = isset($_POST['activo']) ? intval($_POST['activo']) : 1;
            if (!$nombre || !$rol) {
                wp_send_json_error('Completa todos los campos.');
            }
            $wpdb->update($wpdb->prefix . 'midas_areas', [
                'nombre' => $nombre,
                'rol' => $rol,
                'activo' => $activo
            ], ['id' => $id], ['%s', '%s', '%d'], ['%d']);
            $row_html = "<tr data-id='{$id}'>
                <td>{$id}</td>
                <td>" . esc_html($nombre) . "</td>
                <td>" . esc_html($rol) . "</td>
                <td>" . ($activo ? 'Activo' : 'Inactivo') . "</td>
                <td>{$botones('tabla-areas', $id)}</td>
            </tr>";
            wp_send_json_success(['tabla_id' => 'tabla-areas', 'row_html' => $row_html, 'id' => $id]);
        }

        // --- ENFERMEDADES ---
        elseif ($tabla === 'tabla-enfermedades') {
            $tipo = sanitize_text_field($_POST['tipo'] ?? '');
            $descripcion = sanitize_textarea_field($_POST['descripcion'] ?? '');
            if (!$tipo || !$descripcion) {
                wp_send_json_error('Completa todos los campos.');
            }
            $wpdb->update($wpdb->prefix . 'midas_enfermedades', [
                'tipo' => $tipo,
                'descripcion' => $descripcion
            ], ['id' => $id], ['%s', '%s'], ['%d']);
            $row_html = "<tr data-id='{$id}'>
                <td>{$id}</td>
                <td>" . esc_html($tipo) . "</td>
                <td>" . esc_html($descripcion) . "</td>
                <td>{$botones('tabla-enfermedades', $id)}</td>
            </tr>";
            wp_send_json_success(['tabla_id' => 'tabla-enfermedades', 'row_html' => $row_html, 'id' => $id]);
        }

        // --- MÉDICOS ---
        elseif ($tabla === 'tabla-medicos') {
            $nombre = sanitize_text_field($_POST['nombre'] ?? '');
            $apellido = sanitize_text_field($_POST['apellido'] ?? '');
            $especialidad = sanitize_text_field($_POST['especialidad'] ?? '');
            $matricula = sanitize_text_field($_POST['matricula'] ?? '');
            if (!$nombre || !$apellido) {
                wp_send_json_error('Completa nombre y apellido.');
            }
            $wpdb->update($wpdb->prefix . 'midas_medicos', [
                'nombre' => $nombre,
                'apellido' => $apellido,
                'especialidad' => $especialidad,
                'matricula' => $matricula
            ], ['id' => $id], ['%s', '%s', '%s', '%s'], ['%d']);
            $row_html = "<tr data-id='{$id}'>
                <td>{$id}</td>
                <td>" . esc_html($nombre) . "</td>
                <td>" . esc_html($apellido) . "</td>
                <td>" . esc_html($especialidad) . "</td>
                <td>" . esc_html($matricula) . "</td>
                <td>{$botones('tabla-medicos', $id)}</td>
            </tr>";
            wp_send_json_success(['tabla_id' => 'tabla-medicos', 'row_html' => $row_html, 'id' => $id]);
        }

        // --- LICENCIAS ---
        elseif ($tabla === 'tabla-licencias') {
            $tipo = sanitize_text_field($_POST['tipo'] ?? '');
            $descripcion = sanitize_textarea_field($_POST['descripcion'] ?? '');
            if (!$tipo || !$descripcion) {
                wp_send_json_error('Completa todos los campos.');
            }
            $wpdb->update($wpdb->prefix . 'midas_licencia_tipos', [
                'tipo' => $tipo,
                'descripcion' => $descripcion
            ], ['id' => $id], ['%s', '%s'], ['%d']);
            $row_html = "<tr data-id='{$id}'>
                <td>{$id}</td>
                <td>" . esc_html($tipo) . "</td>
                <td>" . esc_html($descripcion) . "</td>
                <td>{$botones('tabla-licencias', $id)}</td>
            </tr>";
            wp_send_json_success(['tabla_id' => 'tabla-licencias', 'row_html' => $row_html, 'id' => $id]);
        }

        wp_send_json_error('Tabla desconocida.');
    }

    // ============= ELIMINAR =============
    public static function eliminar_configuracion()
    {
        global $wpdb;
        if (!current_user_can('manage_options')) {
            wp_send_json_error('No autorizado.');
        }
        $tabla = sanitize_text_field($_POST['tabla'] ?? '');
        $id = intval($_POST['registro_id'] ?? 0);
        if (!$id) wp_send_json_error('ID inválido');

        if ($tabla === 'tabla-tareas') {
            $wpdb->delete($wpdb->prefix . 'midas_tareas', ['id' => $id], ['%d']);
            wp_send_json_success(['tabla_id' => 'tabla-tareas', 'id' => $id]);
        }
        elseif ($tabla === 'tabla-areas') {
            $wpdb->delete($wpdb->prefix . 'midas_areas', ['id' => $id], ['%d']);
            wp_send_json_success(['tabla_id' => 'tabla-areas', 'id' => $id]);
        }
        elseif ($tabla === 'tabla-enfermedades') {
            $wpdb->delete($wpdb->prefix . 'midas_enfermedades', ['id' => $id], ['%d']);
            wp_send_json_success(['tabla_id' => 'tabla-enfermedades', 'id' => $id]);
        }
        elseif ($tabla === 'tabla-medicos') {
            $wpdb->delete($wpdb->prefix . 'midas_medicos', ['id' => $id], ['%d']);
            wp_send_json_success(['tabla_id' => 'tabla-medicos', 'id' => $id]);
        }
        elseif ($tabla === 'tabla-licencias') {
            $wpdb->delete($wpdb->prefix . 'midas_licencia_tipos', ['id' => $id], ['%d']);
            wp_send_json_success(['tabla_id' => 'tabla-licencias', 'id' => $id]);
        }
        wp_send_json_error('Tabla desconocida.');
    }
}

// En tu loader o index del plugin, solo esto:
// \MidasRRHH\Controllers\Configuracion_Controller::hooks();
