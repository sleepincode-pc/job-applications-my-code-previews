<?php
namespace MidasRRHH\Controllers;

use MidasRRHH\Models\Roles_Model;

class Rol_Controller {

    protected $roles_model;

    public function __construct() {
        $this->roles_model = new Roles_Model();
    }

    /**
     * Obtiene usuarios con roles actuales
     */
    public function obtener_usuarios_por_rol() {
        return get_users([
            'fields' => ['ID', 'display_name', 'roles']
        ]);
    }

    /**
     * Obtiene todos los roles disponibles en WP
     */
    public function obtener_todos_los_roles() {
        return $this->roles_model->get_todos_los_roles();
    }

    /**
     * Obtiene todas las pestañas posibles del plugin
     */
    public function obtener_tabs_disponibles() {
        return $this->roles_model->get_todos_los_tabs();
    }

    /**
     * Guarda las pestañas NO visibles para el usuario
     */
    public function guardar_tabs_usuario($user_id, $tabs) {
        return $this->roles_model->guardar_tabs_no_visibles($user_id, $tabs);
    }

    /**
     * Devuelve las pestañas NO visibles para el usuario
     */
    public function obtener_tabs_usuario($user_id) {
        return $this->roles_model->get_tabs_no_visibles_usuario($user_id);
    }

    /**
     * Devuelve las pestañas VISIBLES para el usuario
     */
    public function obtener_tabs_visibles_usuario($user_id) {
        return $this->roles_model->get_tabs_visibles_usuario($user_id);
    }

    /**
     * Devuelve las opciones bloqueadas para un rol
     * Opciones posibles: recibo, licencia, documento, ticket
     * Puedes modificar los arrays según las reglas de tu sistema.
     */
    public function obtener_opciones_bloqueadas($rol) {
        // Ejemplo: solo estos roles tienen restricciones.
        // Puedes editar estos arrays según la lógica real de tu sistema.
        $mapa_bloqueos = [
            'subscriber'  => ['licencia', 'documento'],    // No pueden licencias ni documentos médicos
            'contributor' => ['ticket'],                   // No pueden tickets
            'author'      => [],                           // Sin bloqueos
            'editor'      => [],                           // Sin bloqueos
            'administrator' => []                          // Sin bloqueos
            // Agrega más roles personalizados si lo necesitas
        ];
        return isset($mapa_bloqueos[$rol]) ? $mapa_bloqueos[$rol] : [];
    }
}

// ==============================
// ✅ HOOK AJAX: Guardar pestañas NO visibles para usuario
// ==============================

add_action('wp_ajax_midas_guardar_tabs', function () {
    check_ajax_referer('midas_roles_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(__('No tienes permisos para modificar pestañas.', 'midas-rrhh'));
    }

    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $tabs_raw = isset($_POST['tabs']) ? json_decode(stripslashes($_POST['tabs']), true) : [];

    if (!$user_id || !is_array($tabs_raw)) {
        wp_send_json_error(__('Datos inválidos.', 'midas-rrhh'));
    }

    $controller = new \MidasRRHH\Controllers\Rol_Controller();
    $resultado = $controller->guardar_tabs_usuario($user_id, $tabs_raw);

    if (is_wp_error($resultado)) {
        wp_send_json_error($resultado->get_error_message());
    }

    wp_send_json_success(true);
});
