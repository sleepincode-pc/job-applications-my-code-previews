<?php
namespace MidasRRHH\Controllers;

use WP_REST_Request;
use WP_REST_Response;

if (!defined('ABSPATH')) exit;

class API_Controller {

    public static function init() {
        add_action('rest_api_init', [__CLASS__,'register_routes']);

        // Handlers de las forms del panel (crear / revocar keys)
        add_action('admin_post_midas_api_new_key', [__CLASS__, 'handle_new_key']);
        add_action('admin_post_midas_api_del_key', [__CLASS__, 'handle_del_key']);
    }

    /* ------------------------- API KEYS ------------------------- */

    /** Lee y normaliza el storage de keys */
    private static function get_keys(): array {
        $keys = get_option('midas_rrhh_api_keys', []);
        return is_array($keys) ? $keys : [];
    }

    /** Guarda el storage de keys */
    private static function save_keys(array $keys): void {
        update_option('midas_rrhh_api_keys', $keys, false);
    }

    /** Valida la X-Midas-Key y devuelve [ok,bool, kid,str, keyRec,array] */
    private static function verify_api_key(?string $raw_key) {
        if (!$raw_key) return [false, null, null];

        $keys = self::get_keys();
        $hash = hash_hmac('sha256', $raw_key, AUTH_SALT);

        foreach ($keys as $kid => $rec) {
            if (!empty($rec['revoked'])) continue;
            if (($rec['hash'] ?? '') === $hash) {
                // Tocar "last_used"
                $keys[$kid]['last_used'] = current_time('mysql');
                self::save_keys($keys);
                return [true, $kid, $rec];
            }
        }
        return [false, null, null];
    }

    /** Permission callback común a todas las rutas */
    public static function require_key(WP_REST_Request $req) {
        $key = $req->get_header('X-Midas-Key') ?: $req->get_param('x_key');
        [$ok, , $rec] = self::verify_api_key($key);
        if (!$ok) return new \WP_Error('midas_key_invalid', 'API Key inválida o revocada', ['status'=>401]);

        // ¿solo lectura?
        if (!empty($rec['readonly']) && in_array($req->get_method(), ['POST','PUT','PATCH','DELETE'], true)) {
            return new \WP_Error('midas_key_readonly', 'Esta API Key es de solo lectura', ['status'=>403]);
        }
        return true;
    }

    /* ------------------------- RUTAS ------------------------- */

    public static function register_routes() {
        $ns = 'midas-rrhh/v1';

        // === Empleados: lista ===
        register_rest_route($ns, '/employees', [
            [
                'methods'  => 'GET',
                'callback' => [__CLASS__, 'employees_index'],
                'permission_callback' => [__CLASS__, 'require_key'],
                'args' => [
                    'per_page' => ['default'=>20, 'sanitize_callback'=>'absint'],
                    'page'     => ['default'=>1,  'sanitize_callback'=>'absint'],
                    'search'   => ['default'=>'', 'sanitize_callback'=>'sanitize_text_field'],
                ],
            ],
            [
                'methods'  => 'POST', // crear
                'callback' => [__CLASS__, 'employees_create'],
                'permission_callback' => [__CLASS__, 'require_key'],
            ],
        ]);

        // === Empleado: detalle / update ===
        register_rest_route($ns, '/employees/(?P<id>\d+)', [
            [
                'methods'  => 'GET',
                'callback' => [__CLASS__, 'employees_show'],
                'permission_callback' => [__CLASS__, 'require_key'],
            ],
            [
                // aceptamos PUT y PATCH (también POST con _method=PUT)
                'methods'  => ['PUT','PATCH','POST'],
                'callback' => [__CLASS__, 'employees_update'],
                'permission_callback' => [__CLASS__, 'require_key'],
            ],
        ]);

        // === Recibos: lista / crear ===
        register_rest_route($ns, '/recibos', [
            [
                'methods'  => 'GET',
                'callback' => [__CLASS__, 'recibos_index'],
                'permission_callback' => [__CLASS__, 'require_key'],
                'args' => [
                    'empleado_id' => ['sanitize_callback'=>'absint'],
                    'per_page'    => ['default'=>20, 'sanitize_callback'=>'absint'],
                    'page'        => ['default'=>1,  'sanitize_callback'=>'absint'],
                ],
            ],
            [
                'methods'  => 'POST',
                'callback' => [__CLASS__, 'recibos_create'],
                'permission_callback' => [__CLASS__, 'require_key'],
            ],
        ]);

        // (Opcional) CORS relajado solo para este namespace
        add_filter('rest_pre_serve_request', function($served, $result, $request, $server) use ($ns) {
            if (strpos($request->get_route(), '/'.$ns.'/') !== false) {
                header('Access-Control-Allow-Origin: *');
                header('Access-Control-Allow-Headers: Content-Type, X-Midas-Key');
                header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, OPTIONS');
            }
            return $served;
        }, 10, 4);
    }

    /* ------------------------- EMPLEADOS ------------------------- */

    public static function employees_index(WP_REST_Request $req) {
        global $wpdb;
        $per_page = max(1, min(100, (int)$req['per_page']));
        $page     = max(1, (int)$req['page']);
        $offset   = ($page - 1) * $per_page;
        $search   = $req['search'];

        $where = '';
        $params = [];
        if ($search !== '') {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $where = " WHERE nombre LIKE %s OR apellido LIKE %s OR dni LIKE %s OR cuil LIKE %s ";
            $params = [$like,$like,$like,$like];
        }

        $tbl = $wpdb->prefix.'midas_empleados';
        $total = $params
           ? (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tbl $where", ...$params))
           : (int)$wpdb->get_var("SELECT COUNT(*) FROM $tbl");

        $sql = "SELECT id,nombre,apellido,email,dni,cuil,legajo,telefono,direccion,fecha_ingreso,area,cargo,activo,created_at,updated_at
                FROM $tbl $where ORDER BY id DESC LIMIT %d OFFSET %d";
        $params_list = array_merge($params, [$per_page, $offset]);
        $items = $wpdb->get_results($wpdb->prepare($sql, ...$params_list));

        return new WP_REST_Response([
            'data' => $items,
            'meta' => ['total'=>$total, 'per_page'=>$per_page, 'page'=>$page]
        ]);
    }

    public static function employees_show(WP_REST_Request $req) {
        global $wpdb;
        $id = (int)$req['id'];
        $tbl = $wpdb->prefix.'midas_empleados';
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tbl WHERE id=%d", $id));
        if (!$row) return new \WP_Error('not_found','Empleado no encontrado', ['status'=>404]);
        return new WP_REST_Response($row);
    }

    public static function employees_create(WP_REST_Request $req) {
        // Si tenés modelo, lo usamos; si no, insert directo
        if (class_exists('\MidasRRHH\Models\Empleado_Model')) {
            $model = new \MidasRRHH\Models\Empleado_Model();
            foreach (['insert','create','add','save','store','upsert'] as $m) {
                if (method_exists($model, $m)) {
                    $data = self::clean_employee_payload($req->get_json_params() ?: $req->get_body_params());
                    $res  = $model->{$m}($data);
                    if (is_wp_error($res) || $res === false) return new \WP_Error('save_failed','No se pudo crear el empleado', ['status'=>500]);
                    return new WP_REST_Response(['ok'=>true,'id'=>$res], 201);
                }
            }
        }
        // Insert directo
        global $wpdb;
        $tbl = $wpdb->prefix.'midas_empleados';
        $d   = self::clean_employee_payload($req->get_json_params() ?: $req->get_body_params());
        $ok  = $wpdb->insert($tbl, $d);
        if (!$ok) return new \WP_Error('db_insert_error','Error al insertar', ['status'=>500]);
        return new WP_REST_Response(['ok'=>true,'id'=>$wpdb->insert_id], 201);
    }

    public static function employees_update(WP_REST_Request $req) {
        $method = strtoupper($req->get_method());
        if ($method === 'POST' && strtoupper($req->get_param('_method')) === 'PUT') $method = 'PUT';
        if (!in_array($method, ['PUT','PATCH'], true))
            return new \WP_Error('bad_method','Usa PUT o PATCH (o POST con _method=PUT)', ['status'=>405]);

        $id = (int)$req['id'];
        $payload = $req->get_json_params() ?: $req->get_body_params();

        if (class_exists('\MidasRRHH\Models\Empleado_Model')) {
            $model = new \MidasRRHH\Models\Empleado_Model();
            foreach (['update','save','upsert','edit'] as $m) {
                if (method_exists($model, $m)) {
                    $data = self::clean_employee_payload($payload, true);
                    $data['id'] = $id;
                    $res = $model->{$m}($data);
                    if (is_wp_error($res) || $res === false) return new \WP_Error('save_failed','No se pudo actualizar', ['status'=>500]);
                    return new WP_REST_Response(['ok'=>true]);
                }
            }
        }
        global $wpdb;
        $tbl = $wpdb->prefix.'midas_empleados';
        $d   = self::clean_employee_payload($payload, true);
        if (!$d) return new \WP_Error('no_fields','Sin campos para actualizar', ['status'=>400]);
        $ok  = $wpdb->update($tbl, $d, ['id'=>$id]);
        if ($ok === false) return new \WP_Error('db_update_error','Error al actualizar', ['status'=>500]);
        return new WP_REST_Response(['ok'=>true]);
    }

    private static function clean_employee_payload(array $in, bool $partial=false): array {
        $map = [
            'nombre'        => 'sanitize_text_field',
            'apellido'      => 'sanitize_text_field',
            'email'         => 'sanitize_email',
            'dni'           => 'sanitize_text_field',
            'cuil'          => 'sanitize_text_field',
            'legajo'        => 'sanitize_text_field',
            'telefono'      => 'sanitize_text_field',
            'direccion'     => 'sanitize_text_field',
            'fecha_ingreso' => 'sanitize_text_field',
            'area'          => 'sanitize_text_field',
            'cargo'         => 'sanitize_text_field',
            'activo'        => 'absint',
        ];
        $out = [];
        foreach ($map as $k=>$cb) {
            if ($partial && !array_key_exists($k, $in)) continue;
            if (array_key_exists($k, $in)) $out[$k] = call_user_func($cb, $in[$k]);
        }
        return $out;
    }

    /* ------------------------- RECIBOS ------------------------- */

    public static function recibos_index(WP_REST_Request $req) {
        global $wpdb;
        $per_page = max(1, min(100, (int)$req['per_page']));
        $page     = max(1, (int)$req['page']);
        $offset   = ($page - 1) * $per_page;

        $tbl = $wpdb->prefix.'midas_recibos';
        $where = '';
        $params = [];
        if ($req['empleado_id']) {
            $where  = ' WHERE empleado_id = %d ';
            $params = [(int)$req['empleado_id']];
        }

        $total = $params
           ? (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tbl $where", ...$params))
           : (int)$wpdb->get_var("SELECT COUNT(*) FROM $tbl");

        $sql = "SELECT id,empleado_id,periodo,monto,concepto,observaciones,created_at,updated_at
                FROM $tbl $where ORDER BY id DESC LIMIT %d OFFSET %d";
        $params_list = array_merge($params, [$per_page, $offset]);
        $items = $wpdb->get_results($wpdb->prepare($sql, ...$params_list));

        return new WP_REST_Response([
            'data' => $items,
            'meta' => ['total'=>$total, 'per_page'=>$per_page, 'page'=>$page]
        ]);
    }

    public static function recibos_create(WP_REST_Request $req) {
        if (class_exists('\MidasRRHH\Models\Recibo_Model')) {
            $model = new \MidasRRHH\Models\Recibo_Model();
            foreach (['insert','create','add','save','store','upsert'] as $m) {
                if (method_exists($model, $m)) {
                    $data = self::clean_recibo_payload($req->get_json_params() ?: $req->get_body_params());
                    $res  = $model->{$m}($data);
                    if (is_wp_error($res) || $res === false) return new \WP_Error('save_failed','No se pudo crear el recibo', ['status'=>500]);
                    return new WP_REST_Response(['ok'=>true,'id'=>$res], 201);
                }
            }
        }
        global $wpdb;
        $tbl = $wpdb->prefix.'midas_recibos';
        $d   = self::clean_recibo_payload($req->get_json_params() ?: $req->get_body_params());
        $ok  = $wpdb->insert($tbl, $d);
        if (!$ok) return new \WP_Error('db_insert_error','Error al insertar', ['status'=>500]);
        return new WP_REST_Response(['ok'=>true,'id'=>$wpdb->insert_id], 201);
    }

    private static function clean_recibo_payload(array $in): array {
        $map = [
            'empleado_id'   => 'absint',
            'periodo'       => 'sanitize_text_field',
            'monto'         => 'floatval',
            'concepto'      => 'sanitize_text_field',
            'observaciones' => 'sanitize_textarea_field',
        ];
        $out = [];
        foreach ($map as $k=>$cb) if (array_key_exists($k, $in)) $out[$k]=call_user_func($cb,$in[$k]);
        return $out;
    }

    /* ----------------- HANDLERS UI (crear/revocar key) ----------------- */

    public static function handle_new_key() {
        if (!current_user_can('manage_options')) wp_die('Permisos insuficientes');
        check_admin_referer('midas_api_new_key');

        $label = isset($_POST['label']) ? sanitize_text_field($_POST['label']) : '';
        $plain = rtrim(strtr(base64_encode(random_bytes(24)), '+/', '-_'), '=');
        $hash  = hash_hmac('sha256', $plain, AUTH_SALT);

        $keys = self::get_keys();
        $kid  = uniqid('k', true);
        $keys[$kid] = [
            'label'    => $label ?: 'API Key',
            'hash'     => $hash,
            'created'  => current_time('mysql'),
            'last_used'=> null,
            'revoked'  => 0,
            'readonly' => 0, // poné 1 si querés generar “solo lectura”
        ];
        self::save_keys($keys);

        // volvemos a la pantalla con la key en query (solo se muestra una vez)
        $url = add_query_arg(['new_key'=>$plain], menu_page_url('midas-rrhh-import-export', false));
        wp_safe_redirect($url ?: admin_url('admin.php?page=midas-rrhh-import-export'));
        exit;
    }

    public static function handle_del_key() {
        if (!current_user_can('manage_options')) wp_die('Permisos insuficientes');
        check_admin_referer('midas_api_del_key');

        $kid  = isset($_POST['kid']) ? sanitize_text_field($_POST['kid']) : '';
        $keys = self::get_keys();
        if (isset($keys[$kid])) {
            $keys[$kid]['revoked'] = 1;
            self::save_keys($keys);
        }
        wp_safe_redirect(menu_page_url('midas-rrhh-import-export', false) ?: admin_url('admin.php?page=midas-rrhh-import-export'));
        exit;
    }
}
