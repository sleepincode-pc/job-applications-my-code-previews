<?php
namespace MidasRRHH\Controllers;

if (!defined('ABSPATH')) exit;

class WelcomeController {

    /** Registra hooks necesarios y prepara el primer acceso */
    public static function maybe_show_welcome() {
        // Asegura opciones por defecto sin aplastar valores existentes
        add_option('midas_rrhh_welcome_done', 0);
        add_option('midas_rrhh_show_welcome', 1);
        add_option('midas_rrhh_terms_accepted', 0);

        // Página de onboarding (solo cuando corresponde)
        add_action('admin_menu', [self::class, 'register_onboarding_page']);

        // Redirigir automáticamente la primera vez
        add_action('admin_init', [self::class, 'redirect_first_run']);

        // Endpoints de formularios
        add_action('admin_post_midas_rrhh_finish_onboarding', [self::class, 'finish_onboarding']);
        add_action('admin_post_midas_rrhh_upload_logo',      [self::class, 'handle_logo_upload']);

        // Si quieres seguir soportando el logo en login:
        add_action('login_enqueue_scripts', [self::class, 'set_login_logo']);
    }

    /** Si corresponde, registramos una página "oculta" para el asistente */
    public static function register_onboarding_page() {
        if (!current_user_can('manage_options')) return;

        $should_show = !get_option('midas_rrhh_welcome_done') && get_option('midas_rrhh_show_welcome');
        if (!$should_show) return;

        // Submenú “oculto”: solo aparece mientras no se haya completado
        add_submenu_page(
            'midas-rrhh',
            __('Bienvenido a Midas RRHH', 'midas-rrhh'),
            __('Bienvenida', 'midas-rrhh'),
            'manage_options',
            'midas-rrhh-onboarding',
            [self::class, 'render_onboarding'],
            1
        );
    }

    /** Redirige al wizard si aún no se completó */
    public static function redirect_first_run() {
        if (!current_user_can('manage_options')) return;

        $should_show = !get_option('midas_rrhh_welcome_done') && get_option('midas_rrhh_show_welcome');
        if (!$should_show) return;

        // Evita redirecciones en AJAX, network admin, etc.
        if (wp_doing_ajax() || is_network_admin()) return;

        $current = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
        if ($current !== 'midas-rrhh-onboarding') {
            wp_safe_redirect( admin_url('admin.php?page=midas-rrhh-onboarding') );
            exit;
        }
    }

    /** Guardar resultado final (aceptar o denegar) */
    public static function finish_onboarding() {
        if (!current_user_can('manage_options')) wp_die('Permisos insuficientes');

        check_admin_referer('midas_rrhh_onboarding');
        $accept = isset($_POST['accept']) ? intval($_POST['accept']) : 0;

        update_option('midas_rrhh_terms_accepted', $accept ? 1 : 0);
        update_option('midas_rrhh_welcome_done',   1);
        update_option('midas_rrhh_show_welcome',   0);

        wp_safe_redirect( admin_url('admin.php?page=midas-rrhh') );
        exit;
    }

    /** Subida de logo (paso 1) */
    public static function handle_logo_upload() {
        if (!current_user_can('manage_options')) wp_die('Permisos insuficientes');

        check_admin_referer('midas_rrhh_upload_logo');

        if (!isset($_FILES['login_logo']) || $_FILES['login_logo']['error'] !== UPLOAD_ERR_OK) {
            wp_safe_redirect( self::onboarding_url(['logo_error' => 1]) );
            exit;
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $uploaded = media_handle_upload('login_logo', 0);
        if (!is_wp_error($uploaded)) {
            $url = wp_get_attachment_url($uploaded);
            update_option('midas_rrhh_login_logo', $url);
            wp_safe_redirect( self::onboarding_url(['logo_ok' => 1]) );
        } else {
            wp_safe_redirect( self::onboarding_url(['logo_error' => 1]) );
        }
        exit;
    }

    /** URL del wizard con query opcional */
    private static function onboarding_url(array $args = []) {
        $url = admin_url('admin.php?page=midas-rrhh-onboarding');
        if (!empty($args)) $url = add_query_arg(array_map('sanitize_text_field', $args), $url);
        return $url;
    }

    /** Pinta el logo en la pantalla de login si existe */
    public static function set_login_logo() {
        $logo_url = get_option('midas_rrhh_login_logo');
        if (!$logo_url) return;
        echo "<style>
            body.login div#login h1 a {
                background-image: url('".esc_url($logo_url)."');
                background-size: contain;
                background-position: center;
                background-repeat: no-repeat;
                width: 100%; height: 80px;
                display: block; text-indent: -9999px; overflow: hidden;
            }
        </style>";
    }

    /** Render del asistente a pantalla completa (3 pasos) */
    public static function render_onboarding() {
        if (!current_user_can('manage_options')) wp_die('Permisos insuficientes');

        $logo_url   = get_option('midas_rrhh_login_logo');
        $logo_ok    = isset($_GET['logo_ok']);
        $logo_error = isset($_GET['logo_error']);

        $ajax_url      = admin_url('admin-ajax.php');
        $palette_nonce = wp_create_nonce('midas_palette_scoped_nonce');
        $finish_nonce  = wp_create_nonce('midas_rrhh_onboarding');

        $uid          = get_current_user_id();
        $saved_palette = $uid ? get_user_meta($uid, 'midas_palette_scoped', true) : null;
        if (!is_array($saved_palette)) $saved_palette = null;

        ?>
        <div class="midas-onboarding-wrap">
            <div class="midas-onboarding">
                <div class="midas-ob-header">
                    <div class="midas-ob-brand">
                        <span class="midas-ob-logo">⚙️</span>
                        <h1>Midas RRHH</h1>
                    </div>
                    <div class="midas-ob-steps">
                        <span class="step-dot" data-step="1">1</span>
                        <span class="step-dot" data-step="2">2</span>
                        <span class="step-dot" data-step="3">3</span>
                    </div>
                </div>

                <div class="midas-ob-body">
                    <!-- PASO 1 -->
                    <section class="ob-step active" id="ob-step-1" data-step="1" aria-hidden="false">
                        <h2>¿Quieres cambiar el logo de tu web?</h2>
                        <p class="ob-sub">Podés subirlo ahora o más tarde desde este mismo asistente.</p>

                        <?php if ($logo_ok): ?>
                            <div class="ob-alert ok">¡Logo subido correctamente!</div>
                        <?php elseif ($logo_error): ?>
                            <div class="ob-alert error">No se pudo subir el logo. Probá nuevamente.</div>
                        <?php endif; ?>

                        <div class="ob-grid">
                            <div class="ob-card">
                                <h3>Subir nuevo logo</h3>
                                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data" class="ob-form">
                                    <input type="hidden" name="action" value="midas_rrhh_upload_logo">
                                    <?php wp_nonce_field('midas_rrhh_upload_logo'); ?>
                                    <input type="file" accept="image/*" name="login_logo" required>
                                    <p class="ob-help">Sugerido: fondo transparente, horizontal, máx. 400×120px.</p>
                                    <div class="ob-actions">
                                        <button type="submit" class="button button-primary">Subir logo</button>
                                    </div>
                                </form>
                            </div>

                            <div class="ob-card">
                                <h3>Vista actual</h3>
                                <div class="ob-preview">
                                    <?php if ($logo_url): ?>
                                        <img src="<?php echo esc_url($logo_url); ?>" alt="Logo actual">
                                    <?php else: ?>
                                        <div class="ob-placeholder">Sin logo configurado</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </section>

                    <!-- PASO 2 -->
                    <section class="ob-step" id="ob-step-2" data-step="2" aria-hidden="true">
                        <h2>¿Qué colores querés para tus botones y tarjetas?</h2>
                        <p class="ob-sub">Estos colores afectan tarjetas, textos y todos los <strong>botones (.button)</strong> del dashboard.</p>

                        <div class="ob-grid ob-two">
                            <div class="ob-card">
                                <h3>Tarjetas</h3>
                                <div class="color-row"><label>Fondo</label><input type="color" id="c-bg"   value="#ffffff"></div>
                                <div class="color-row"><label>Borde</label><input type="color" id="c-bor"  value="#ccd0d4"></div>
                                <div class="color-row"><label>Cabecera</label><input type="color" id="c-hbg" value="#f7f7f7"></div>
                                <div class="color-row"><label>Texto cabecera</label><input type="color" id="c-htx" value="#1f2937"></div>
                                <div class="color-row"><label>Renglón zebra</label><input type="color" id="c-str" value="#f9fafb"></div>
                            </div>
                            <div class="ob-card">
                                <h3>Textos &amp; Botones</h3>
                                <div class="color-row"><label>Texto principal</label><input type="color" id="t-main" value="#1e293b"></div>
                                <div class="color-row"><label>Texto atenuado</label><input type="color" id="t-muted" value="#475569"></div>
                                <hr>
                                <div class="color-row"><label>Fondo botón</label><input type="color" id="b-bg"   value="#2271b1"></div>
                                <div class="color-row"><label>Texto botón</label><input type="color" id="b-txt"  value="#ffffff"></div>

                                <div class="ob-actions" style="margin-top:14px;">
                                    <button type="button" class="button" id="pal-reset">Restablecer</button>
                                    <button type="button" class="button button-primary" id="pal-save">Guardar paleta</button>
                                    <span id="pal-status" class="pal-status" aria-live="polite"></span>
                                </div>
                            </div>
                        </div>

                        <!-- PREVIEW rápido -->
                        <div class="ob-live">
                            <div class="ob-card live" id="live-card">
                                <h3 id="live-card-header">Previsualización</h3>
                                <p id="live-card-text">Así se verán los componentes con tu paleta.</p>
                                <button class="button" id="live-button">Botón de ejemplo</button>
                            </div>
                        </div>

                        <!-- Datos para AJAX -->
                        <script>
                            window.midas_rrhh = window.midas_rrhh || {};
                            midas_rrhh.ajax_url      = "<?php echo esc_js($ajax_url); ?>";
                            midas_rrhh.palette_nonce = "<?php echo esc_js($palette_nonce); ?>";
                            midas_rrhh.user_palette  = <?php echo wp_json_encode($saved_palette ?: (object)[]); ?>;
                        </script>
                    </section>

                    <!-- PASO 3 -->
                    <section class="ob-step" id="ob-step-3" data-step="3" aria-hidden="true">
                        <h2>Nuestra información</h2>
                        <div class="ob-card">
                            <div class="legal">
                                <p><strong>Privacidad y uso de datos</strong></p>
                                <p>Este plugin procesa datos necesarios para la gestión de RRHH. Podés consultar nuestra política completa en el sitio de Accesswork Technology.</p>
                                <ul class="legal-list">
                                    <li>Solo administradores y roles autorizados acceden a la información.</li>
                                    <li>Podés cambiar o eliminar datos desde el panel.</li>
                                    <li>No compartimos datos con terceros sin autorización.</li>
                                </ul>
                                <p>Para continuar, elegí una opción:</p>
                            </div>
                            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="ob-form accept-form">
                                <input type="hidden" name="action" value="midas_rrhh_finish_onboarding">
                                <?php wp_nonce_field('midas_rrhh_onboarding'); ?>
                                <div class="ob-actions end">
                                    <button type="submit" name="accept" value="0" class="button">Denegar</button>
                                    <button type="submit" name="accept" value="1" class="button button-primary">Aceptar y finalizar</button>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>

                <!-- NAV inferior -->
                <div class="midas-ob-footer">
                    <div class="nav-left">
                        <button type="button" class="button" id="ob-prev">Volver atrás</button>
                    </div>
                    <div class="nav-right">
                        <button type="button" class="button button-primary" id="ob-next">Continuar</button>
                    </div>
                </div>
            </div>
        </div>

        <style>
            /* === Pantalla completa === */
            .midas-onboarding-wrap{
                position:fixed; inset:0; z-index:999999;
                background:#0b1220;
            }
            .midas-onboarding{
                position:absolute; inset:0;
                display:flex; flex-direction:column;
                max-width:1180px; margin:auto; width:100%;
                padding:24px; box-sizing:border-box;
                color:#0f172a;
            }
            .midas-ob-header{
                background:#ffffff; border-radius:14px; padding:16px 18px; margin-bottom:14px;
                display:flex; align-items:center; justify-content:space-between; gap:12px;
                box-shadow:0 6px 18px rgba(0,0,0,.12);
            }
            .midas-ob-brand{ display:flex; align-items:center; gap:12px; }
            .midas-ob-brand h1{ margin:0; font-size:20px; color:#0f172a; }
            .midas-ob-logo{
                width:36px; height:36px; border-radius:10px; background:#2271b1; color:#fff;
                display:inline-flex; align-items:center; justify-content:center; font-size:18px;
                box-shadow:0 6px 18px rgba(34,113,177,.35);
            }
            .midas-ob-steps .step-dot{
                display:inline-flex; align-items:center; justify-content:center;
                width:32px; height:32px; margin-left:6px; border-radius:50%;
                background:#e5e7eb; color:#111827; font-weight:700;
            }
            .midas-ob-steps .step-dot.active{ background:#2271b1; color:#fff; }

            .midas-ob-body{
                background:#f8fafc; border-radius:14px; flex:1 1 auto;
                padding:22px; overflow:auto; box-shadow:0 6px 24px rgba(0,0,0,.10);
            }
            .ob-step{ display:none; }
            .ob-step.active{ display:block; }
            .ob-sub{ color:#475569; margin-top:-6px; }

            .midas-ob-footer{
                margin-top:14px;
                display:flex; align-items:center; justify-content:space-between;
                background:#ffffff; border-radius:14px; padding:12px 16px;
                box-shadow:0 6px 18px rgba(0,0,0,.12);
            }
            .ob-actions{ display:flex; gap:8px; align-items:center; }
            .ob-actions.end{ justify-content:flex-end; }

            .ob-grid{ display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-top:14px; }
            .ob-two{ grid-template-columns:1fr 1fr; }
            @media (max-width: 980px){ .ob-grid, .ob-two{ grid-template-columns:1fr; } }

            .ob-card{
                background:#ffffff; border:1px solid #e5e7eb; border-radius:12px;
                padding:16px; box-shadow:0 4px 16px rgba(0,0,0,.06);
            }
            .ob-card h3{ margin-top:0; }

            .ob-form input[type="file"]{ display:block; margin:8px 0; }
            .ob-help{ color:#6b7280; margin:6px 0 2px; }
            .ob-alert{ border-radius:8px; padding:10px 12px; margin:8px 0; font-weight:600; }
            .ob-alert.ok{ background:#ecfdf5; color:#065f46; border:1px solid #10b981; }
            .ob-alert.error{ background:#fef2f2; color:#991b1b; border:1px solid #ef4444; }

            .ob-preview{ display:flex; align-items:center; justify-content:center; min-height:120px; background:#f9fafb; border:1px dashed #cbd5e1; border-radius:10px; }
            .ob-preview img{ max-height:80px; max-width:100%; }
            .ob-placeholder{ color:#64748b; }

            .color-row{ display:flex; align-items:center; justify-content:space-between; margin:8px 0; gap:10px; }
            .color-row input[type="color"]{ width:48px; height:34px; padding:0; border:1px solid #cbd5e1; border-radius:6px; }

            .ob-live{ margin-top:16px; }
            .ob-card.live{ border-style:dashed; text-align:center; }
            .ob-card.live h3{ margin:0 0 8px; }
            .pal-status{ min-width:120px; font-weight:700; }

            .legal{ color:#0f172a; }
            .legal-list{ margin:8px 0 0 18px; list-style:disc; }

            /* Forzar que toda la página admin quede tapada */
            #wpadminbar, #adminmenuwrap, #adminmenuback, #wpcontent, #wpfooter{ filter: blur(0px); }
        </style>

        <script>
        (function(){
            // ======== Navegación de pasos
            const steps = [...document.querySelectorAll('.ob-step')];
            const dots  = [...document.querySelectorAll('.step-dot')];
            const prev  = document.getElementById('ob-prev');
            const next  = document.getElementById('ob-next');

            let i = 0; // índice paso (0..2)

            function setStep(idx){
                i = Math.max(0, Math.min(steps.length-1, idx));
                steps.forEach((s, k)=>{ s.classList.toggle('active', k===i); s.setAttribute('aria-hidden', k===i?'false':'true'); });
                dots.forEach((d)=> d.classList.toggle('active', parseInt(d.dataset.step,10) === (i+1)));
                prev.disabled = (i===0);
                next.textContent = (i===steps.length-1) ? 'Continuar' : 'Continuar';
            }
            prev.addEventListener('click', ()=> setStep(i-1));
            next.addEventListener('click', ()=> {
                if (i < steps.length-1) setStep(i+1);
                else setStep(steps.length-1);
            });
            setStep(0);

            // ======== Paleta (mismo esquema que tu dashboard)
            const DEF = {
                cards:{ bg:'#ffffff', border:'#ccd0d4', headerBg:'#f7f7f7', headerTxt:'#1f2937', stripe:'#f9fafb' },
                text:{  txt:'#1e293b', muted:'#475569' },
                btn:{   bg:'#2271b1', txt:'#ffffff' }
            };
            const SAVED = (window.midas_rrhh && window.midas_rrhh.user_palette) ? window.midas_rrhh.user_palette : null;
            const base  = (SAVED && typeof SAVED==='object') ? SAVED : {};
            const pal   = {
                cards: Object.assign({}, DEF.cards, base.cards || {}),
                text:  Object.assign({}, DEF.text,  base.text  || {}),
                btn:   Object.assign({}, DEF.btn,   base.btn   || {}),
            };

            // Inputs
            const el = {
                cBg:  document.getElementById('c-bg'),
                cBor: document.getElementById('c-bor'),
                cHbg: document.getElementById('c-hbg'),
                cHtx: document.getElementById('c-htx'),
                cStr: document.getElementById('c-str'),
                tMain:document.getElementById('t-main'),
                tMuted:document.getElementById('t-muted'),
                bBg:  document.getElementById('b-bg'),
                bTxt: document.getElementById('b-txt'),
                reset:document.getElementById('pal-reset'),
                save: document.getElementById('pal-save'),
                status:document.getElementById('pal-status'),
                liveCard: document.getElementById('live-card'),
                liveHeader: document.getElementById('live-card-header'),
                liveText:   document.getElementById('live-card-text'),
                liveBtn:    document.getElementById('live-button'),
            };

            function setInputs(p){
                el.cBg.value  = p.cards.bg;    el.cBor.value = p.cards.border;
                el.cHbg.value = p.cards.headerBg;
                el.cHtx.value = p.cards.headerTxt;
                el.cStr.value = p.cards.stripe;
                el.tMain.value= p.text.txt;   el.tMuted.value= p.text.muted;
                el.bBg.value  = p.btn.bg;     el.bTxt.value  = p.btn.txt;
            }
            function getPalette(){
                return {
                    cards:{ bg:el.cBg.value, border:el.cBor.value, headerBg:el.cHbg.value, headerTxt:el.cHtx.value, stripe:el.cStr.value },
                    text:{  txt:el.tMain.value, muted:el.tMuted.value },
                    btn:{   bg:el.bBg.value,   txt:el.bTxt.value }
                };
            }
            function applyPreview(p){
                if(!el.liveCard) return;
                el.liveCard.style.setProperty('background', p.cards.bg);
                el.liveCard.style.setProperty('border', '1px solid '+p.cards.border);
                el.liveHeader.style.setProperty('background', p.cards.headerBg);
                el.liveHeader.style.setProperty('color', p.cards.headerTxt);
                el.liveText.style.setProperty('color', p.text.txt);
                el.liveBtn.style.setProperty('background', p.btn.bg);
                el.liveBtn.style.setProperty('border-color', p.btn.bg);
                el.liveBtn.style.setProperty('color', p.btn.txt);
            }
            setInputs(pal);
            applyPreview(pal);

            ['input','change'].forEach(evt=>{
                [el.cBg,el.cBor,el.cHbg,el.cHtx,el.cStr,el.tMain,el.tMuted,el.bBg,el.bTxt].forEach(inp=>{
                    inp.addEventListener(evt, ()=> applyPreview( getPalette() ));
                });
            });

            el.reset.addEventListener('click', ()=>{
                setInputs(DEF); applyPreview(DEF);
                el.status.textContent='Restablecido (no guardado)';
                setTimeout(()=>el.status.textContent='', 2000);
            });

            el.save.addEventListener('click', ()=>{
                const AJAX = (window.midas_rrhh && window.midas_rrhh.ajax_url) ? window.midas_rrhh.ajax_url : ajaxurl;
                const NP   = (window.midas_rrhh && window.midas_rrhh.palette_nonce) ? window.midas_rrhh.palette_nonce : '';
                if (!NP) { alert('Falta nonce. Recargá la página.'); return; }
                const payload = getPalette();
                el.save.disabled = true; el.status.textContent='Guardando...';
                fetch(AJAX, {
                    method:'POST', credentials:'include',
                    headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},
                    body:new URLSearchParams({
                        action:'midas_save_palette_scoped',
                        nonce: NP, _wpnonce: NP,
                        palette: JSON.stringify(payload)
                    })
                }).then(r=>r.json().catch(()=>null).then(j=>({ok:r.ok, j})))
                .then(res=>{
                    if (!res || !res.ok || !res.j?.success) throw new Error(res?.j?.data?.message || 'Error guardando');
                    el.status.textContent='Guardado ✓';
                    setTimeout(()=>el.status.textContent='', 1800);
                })
                .catch(err=>{ console.error(err); el.status.textContent='Error al guardar'; })
                .finally(()=>{ el.save.disabled=false; });
            });
        })();
        </script>
        <?php
    }
}
