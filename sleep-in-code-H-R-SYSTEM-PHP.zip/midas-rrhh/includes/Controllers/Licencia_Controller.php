<?php
namespace MidasRRHH\Controllers;

use MidasRRHH\Models\Licencia_Model;
use MidasRRHH\Models\Empleado_Model;
use MidasRRHH\Models\Recibo_Model;
use MidasRRHH\Core\Security;
use MidasRRHH\Core\Notificaciones;
use WP_Error;

class Licencia_Controller {
    private $licencia_model;
    private $empleado_model;
    private $recibo_model;
    private $security;
    private $notificaciones;

    public function __construct() {
        error_log('[Licencia_Controller] __construct');
        $this->licencia_model = new Licencia_Model();
        $this->empleado_model = new Empleado_Model();
        $this->recibo_model = new Recibo_Model();
        $this->security = new Security();
        $this->notificaciones = new Notificaciones();
    }

    public function obtener_licencias_aprobadas_para_recibos($fecha_inicio = null, $fecha_fin = null) {
        error_log("[obtener_licencias_aprobadas_para_recibos][START]");
        if (!current_user_can('read_private_midas_licencias')) {
            error_log('[obtener_licencias_aprobadas_para_recibos][ERROR] Permiso denegado');
            return new WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }
        $licencias = $this->licencia_model->get_aprobadas($fecha_inicio, $fecha_fin);
        foreach ($licencias as $licencia) {
            $empleado = $this->empleado_model->get($licencia->empleado_id);
            $licencia->empleado_nombre = $empleado ? $empleado->nombre . ' ' . $empleado->apellido : '';
            $licencia->fecha_inicio_formateada = date_i18n('d/m/Y', strtotime($licencia->fecha_inicio));
            $licencia->fecha_fin_formateada = date_i18n('d/m/Y', strtotime($licencia->fecha_fin));
            if ($licencia->gestor_id) {
                $gestor = get_user_by('id', $licencia->gestor_id);
                $licencia->gestor_nombre = $gestor ? $gestor->display_name : '';
            }
            if ($licencia->documento_id) {
                $licencia->documento_url = wp_get_attachment_url($licencia->documento_id);
            }
        }
        error_log("[obtener_licencias_aprobadas_para_recibos][FIN-OK] Total: ".count($licencias));
        return $licencias;
    }

    public function obtener_recibos_aprobados($fecha_inicio = null, $fecha_fin = null) {
        error_log("[obtener_recibos_aprobados][START]");
        if (!current_user_can('read_private_midas_recibos')) {
            error_log('[obtener_recibos_aprobados][ERROR] Permiso denegado');
            return new WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }
        $recibos = $this->recibo_model->get_aprobados($fecha_inicio, $fecha_fin);
        foreach ($recibos as $recibo) {
            $empleado = $this->empleado_model->get($recibo->empleado_id);
            $recibo->empleado_nombre = $empleado ? $empleado->nombre . ' ' . $empleado->apellido : '';
            $recibo->periodo_formateado = $recibo->periodo ? date_i18n('F Y', strtotime($recibo->periodo)) : '';
            if ($recibo->archivo_id) {
                $recibo->archivo_url = wp_get_attachment_url($recibo->archivo_id);
            }
            if ($recibo->gestor_id) {
                $gestor = get_user_by('id', $recibo->gestor_id);
                $recibo->gestor_nombre = $gestor ? $gestor->display_name : '';
            }
        }
        error_log("[obtener_recibos_aprobados][FIN-OK] Total: ".count($recibos));
        return $recibos;
    }

    private function upload_documento($file) {
        error_log('[upload_documento][START] File: ' . print_r($file, true));
        if (!function_exists('wp_handle_upload')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        $upload_overrides = [
            'test_form' => false,
            'mimes' => [
                'jpg|jpeg|jpe' => 'image/jpeg',
                'png' => 'image/png',
                'pdf' => 'application/pdf'
            ]
        ];
        $movefile = wp_handle_upload($file, $upload_overrides);
        if (isset($movefile['error'])) {
            error_log('[upload_documento][ERROR] ' . $movefile['error']);
            return new WP_Error('upload_error', $movefile['error']);
        }
        $attachment = [
            'post_mime_type' => $movefile['type'],
            'post_title' => __('Documento de licencia ', 'midas-rrhh') . date('Y-m-d'),
            'post_content' => '',
            'post_status' => 'inherit'
        ];
        $attach_id = wp_insert_attachment($attachment, $movefile['file']);
        if (is_wp_error($attach_id)) {
            error_log('[upload_documento][ERROR] wp_insert_attachment: ' . $attach_id->get_error_message());
            return $attach_id;
        }
        if (strpos($movefile['type'], 'image') !== false) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
            $attach_data = wp_generate_attachment_metadata($attach_id, $movefile['file']);
            wp_update_attachment_metadata($attach_id, $attach_data);
        }
        error_log('[upload_documento][FIN-OK] id=' . $attach_id);
        return $attach_id;
    }

    public function aprobar_licencia($licencia_id, $dias_aprobados, $observaciones = '') {
        error_log("[aprobar_licencia][START] licencia_id=$licencia_id, dias_aprobados=$dias_aprobados, observaciones=$observaciones");
        if (!current_user_can('publish_midas_licencias')) {
            error_log('[aprobar_licencia][ERROR] Permiso denegado');
            return new WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }
        $licencia = $this->licencia_model->get($licencia_id);
        if (!$licencia) {
            error_log('[aprobar_licencia][ERROR] Licencia no encontrada');
            return new WP_Error('not_found', __('Licencia no encontrada', 'midas-rrhh'));
        }
        $dias_aprobados = intval($dias_aprobados);
        if ($dias_aprobados <= 0) {
            $inicio = \DateTime::createFromFormat('Y-m-d', $licencia->fecha_inicio);
            $fin = \DateTime::createFromFormat('Y-m-d', $licencia->fecha_fin);
            if (!$inicio || !$fin || $fin < $inicio) {
                error_log('[aprobar_licencia][ERROR] Fechas inválidas en licencia original');
                return new WP_Error('invalid_date', __('Fechas inválidas en la licencia original', 'midas-rrhh'));
            }
            $dias_aprobados = $inicio->diff($fin)->days + 1;
        }
        $update_data = [
            'estado' => 'aprobado',
            'dias_aprobados' => $dias_aprobados,
            'observaciones' => sanitize_textarea_field($observaciones),
            'gestor_id' => get_current_user_id()
        ];
        error_log('[aprobar_licencia] update_data: ' . print_r($update_data, true));
        $result = $this->licencia_model->update($licencia_id, $update_data);
        if ($result === false) {
            error_log('[aprobar_licencia][ERROR] Error DB update');
            return new WP_Error('db_error', __('Error al actualizar la licencia', 'midas-rrhh'));
        }
        $this->notificaciones->enviar_notificacion_licencia_aprobada($licencia_id);
        error_log("[aprobar_licencia][FIN-OK] licencia_id=$licencia_id");

        // Devuelve el objeto completo actualizado
        return $this->obtener_licencia($licencia_id);
    }

    public function rechazar_licencia($licencia_id, $observaciones = '') {
        error_log("[rechazar_licencia][START] licencia_id=$licencia_id, observaciones=$observaciones");
        if (!current_user_can('publish_midas_licencias')) {
            error_log('[rechazar_licencia][ERROR] Permiso denegado');
            return new WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }
        $licencia = $this->licencia_model->get($licencia_id);
        if (!$licencia) {
            error_log('[rechazar_licencia][ERROR] Licencia no encontrada');
            return new WP_Error('not_found', __('Licencia no encontrada', 'midas-rrhh'));
        }
        $update_data = [
            'estado' => 'rechazado',
            'observaciones' => sanitize_textarea_field($observaciones),
            'gestor_id' => get_current_user_id()
        ];
        error_log('[rechazar_licencia] update_data: ' . print_r($update_data, true));
        $result = $this->licencia_model->update($licencia_id, $update_data);
        if ($result === false) {
            error_log('[rechazar_licencia][ERROR] Error DB update');
            return new WP_Error('db_error', __('Error al actualizar la licencia', 'midas-rrhh'));
        }
        $this->notificaciones->enviar_notificacion_licencia_rechazada($licencia_id);
        error_log("[rechazar_licencia][FIN-OK] licencia_id=$licencia_id");

        // Devuelve el objeto completo actualizado
        return $this->obtener_licencia($licencia_id);
    }

    public function editar_licencia($licencia_id, $tipo, $fecha_inicio, $fecha_fin, $documento = null, $observaciones = '') {
        error_log("[editar_licencia][START] licencia_id=$licencia_id, tipo=$tipo, fecha_inicio=$fecha_inicio, fecha_fin=$fecha_fin, documento=".print_r($documento,true).", observaciones=$observaciones");
        $licencia = $this->licencia_model->get($licencia_id);
        if (!$licencia) {
            error_log('[editar_licencia][ERROR] Licencia no encontrada');
            return new WP_Error('not_found', __('Licencia no encontrada', 'midas-rrhh'));
        }
        $current_user = wp_get_current_user();
        $empleado = $this->empleado_model->get($licencia->empleado_id);
        $puede_editar = false;
        if ($empleado && $empleado->user_id == $current_user->ID && $licencia->estado === 'pendiente') {
            $puede_editar = true;
        }
        if (current_user_can('publish_midas_licencias')) {
            $puede_editar = true;
        }
        if (!$puede_editar) {
            error_log('[editar_licencia][ERROR] Permiso denegado');
            return new WP_Error('forbidden', __('No tienes permisos para editar esta licencia', 'midas-rrhh'));
        }
        $fecha_inicio_obj = \DateTime::createFromFormat('Y-m-d', $fecha_inicio);
        $fecha_fin_obj = \DateTime::createFromFormat('Y-m-d', $fecha_fin);
        if (!$fecha_inicio_obj || !$fecha_fin_obj || $fecha_fin_obj < $fecha_inicio_obj) {
            error_log('[editar_licencia][ERROR] Fechas inválidas');
            return new WP_Error('invalid_date', __('Fechas inválidas', 'midas-rrhh'));
        }
        $dias_solicitados = $fecha_inicio_obj->diff($fecha_fin_obj)->days + 1;
        $documento_id = $licencia->documento_id;
        if ($documento && !empty($documento['tmp_name'])) {
            error_log('[editar_licencia] Subiendo documento nuevo...');
            if ($documento_id) {
                wp_delete_attachment($documento_id, true);
            }
            $documento_id = $this->upload_documento($documento);
            if (is_wp_error($documento_id)) {
                error_log('[editar_licencia][ERROR] upload_documento: ' . $documento_id->get_error_message());
                return $documento_id;
            }
        }
        $update_data = [
            'tipo' => sanitize_text_field($tipo),
            'fecha_inicio' => $fecha_inicio,
            'fecha_fin' => $fecha_fin,
            'dias_solicitados' => $dias_solicitados,
            'documento_id' => $documento_id,
            'observaciones' => sanitize_textarea_field($observaciones)
        ];
        error_log('[editar_licencia] update_data: ' . print_r($update_data, true));
        $result = $this->licencia_model->update($licencia_id, $update_data);
        if ($result === false) {
            error_log('[editar_licencia][ERROR] Error DB update');
            return new WP_Error('db_error', __('Error al actualizar la licencia', 'midas-rrhh'));
        }
        error_log("[editar_licencia][FIN-OK] licencia_id=$licencia_id");

        // Devuelve el objeto completo actualizado
        return $this->obtener_licencia($licencia_id);
    }

    public function obtener_licencias_empleado($empleado_id) {
        error_log("[obtener_licencias_empleado][START] empleado_id=$empleado_id");
        $current_user = wp_get_current_user();
        $empleado = $this->empleado_model->get($empleado_id);
        if ($empleado->user_id != $current_user->ID && !current_user_can('read_private_midas_licencias')) {
            error_log('[obtener_licencias_empleado][ERROR] Permiso denegado');
            return new WP_Error('forbidden', __('No tienes permisos para ver estas licencias', 'midas-rrhh'));
        }
        $licencias = $this->licencia_model->get_by_empleado($empleado_id);
        foreach ($licencias as $licencia) {
            if ($licencia->documento_id) {
                $licencia->documento_url = wp_get_attachment_url($licencia->documento_id);
            }
            $licencia->fecha_inicio_formateada = date_i18n('d/m/Y', strtotime($licencia->fecha_inicio));
            $licencia->fecha_fin_formateada = date_i18n('d/m/Y', strtotime($licencia->fecha_fin));
        }
        error_log("[obtener_licencias_empleado][FIN-OK] Licencias: ".count($licencias));
        return $licencias;
    }

    public function obtener_licencia($licencia_id) {
        error_log("[obtener_licencia][START] licencia_id=$licencia_id");
        $licencia = $this->licencia_model->get($licencia_id);
        if (!$licencia) {
            error_log('[obtener_licencia][ERROR] Licencia no encontrada');
            return new WP_Error('not_found', __('Licencia no encontrada', 'midas-rrhh'));
        }
        $current_user = wp_get_current_user();
        $empleado = $this->empleado_model->get($licencia->empleado_id);
        if ($empleado->user_id != $current_user->ID && !current_user_can('read_private_midas_licencias')) {
            error_log('[obtener_licencia][ERROR] Permiso denegado');
            return new WP_Error('forbidden', __('No tienes permisos para ver esta licencia', 'midas-rrhh'));
        }
        if ($licencia->documento_id) {
            $licencia->documento_url = wp_get_attachment_url($licencia->documento_id);
        }
        $licencia->fecha_inicio_formateada = date_i18n('d/m/Y', strtotime($licencia->fecha_inicio));
        $licencia->fecha_fin_formateada = date_i18n('d/m/Y', strtotime($licencia->fecha_fin));
        $licencia->empleado_nombre = $empleado ? $empleado->nombre . ' ' . $empleado->apellido : '';
        if ($licencia->gestor_id) {
            $gestor = get_user_by('id', $licencia->gestor_id);
            $licencia->gestor_nombre = $gestor ? $gestor->display_name : '';
        }
        if (!isset($licencia->observaciones)) {
            $licencia->observaciones = '';
        }
        error_log("[obtener_licencia][FIN-OK] licencia_id=$licencia_id");
        return $licencia;
    }

    public function obtener_licencias_pendientes() {
        error_log("[obtener_licencias_pendientes][START]");
        if (!current_user_can('read_private_midas_licencias')) {
            error_log('[obtener_licencias_pendientes][ERROR] Permiso denegado');
            return new WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }
        $licencias = $this->licencia_model->get_pendientes();
        foreach ($licencias as $licencia) {
            $empleado = $this->empleado_model->get($licencia->empleado_id);
            $licencia->empleado_nombre = $empleado ? $empleado->nombre . ' ' . $empleado->apellido : '';
            $licencia->fecha_inicio_formateada = date_i18n('d/m/Y', strtotime($licencia->fecha_inicio));
            $licencia->fecha_fin_formateada = date_i18n('d/m/Y', strtotime($licencia->fecha_fin));
            if ($licencia->documento_id) {
                $licencia->documento_url = wp_get_attachment_url($licencia->documento_id);
            }
        }
        error_log("[obtener_licencias_pendientes][FIN-OK] Total: ".count($licencias));
        return $licencias;
    }

    public function obtener_licencias_aprobadas($fecha_inicio = null, $fecha_fin = null) {
        error_log("[obtener_licencias_aprobadas][START]");
        if (!current_user_can('read_private_midas_licencias')) {
            error_log('[obtener_licencias_aprobadas][ERROR] Permiso denegado');
            return new WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }
        $licencias = $this->licencia_model->get_aprobadas($fecha_inicio, $fecha_fin);
        foreach ($licencias as $licencia) {
            $empleado = $this->empleado_model->get($licencia->empleado_id);
            $licencia->empleado_nombre = $empleado ? $empleado->nombre . ' ' . $empleado->apellido : '';
            $licencia->fecha_inicio_formateada = date_i18n('d/m/Y', strtotime($licencia->fecha_inicio));
            $licencia->fecha_fin_formateada = date_i18n('d/m/Y', strtotime($licencia->fecha_fin));
            if ($licencia->gestor_id) {
                $gestor = get_user_by('id', $licencia->gestor_id);
                $licencia->gestor_nombre = $gestor ? $gestor->display_name : '';
            }
            if ($licencia->documento_id) {
                $licencia->documento_url = wp_get_attachment_url($licencia->documento_id);
            }
        }
        error_log("[obtener_licencias_aprobadas][FIN-OK] Total: ".count($licencias));
        return $licencias;
    }

    public function obtener_licencias_rechazadas() {
        error_log("[obtener_licencias_rechazadas][START]");
        if (!current_user_can('read_private_midas_licencias')) {
            error_log('[obtener_licencias_rechazadas][ERROR] Permiso denegado');
            return new WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }
        $licencias = $this->licencia_model->get_rechazadas();
        foreach ($licencias as $licencia) {
            $empleado = $this->empleado_model->get($licencia->empleado_id);
            $licencia->empleado_nombre = $empleado ? $empleado->nombre . ' ' . $empleado->apellido : '';
            $licencia->fecha_inicio_formateada = date_i18n('d/m/Y', strtotime($licencia->fecha_inicio));
            $licencia->fecha_fin_formateada = date_i18n('d/m/Y', strtotime($licencia->fecha_fin));
            if ($licencia->gestor_id) {
                $gestor = get_user_by('id', $licencia->gestor_id);
                $licencia->gestor_nombre = $gestor ? $gestor->display_name : '';
            }
            if ($licencia->documento_id) {
                $licencia->documento_url = wp_get_attachment_url($licencia->documento_id);
            }
        }
        error_log("[obtener_licencias_rechazadas][FIN-OK] Total: ".count($licencias));
        return $licencias;
    }

    public function obtener_historial_licencias() {
        error_log("[obtener_historial_licencias][START]");
        if (!current_user_can('read_private_midas_licencias')) {
            error_log('[obtener_historial_licencias][ERROR] Permiso denegado');
            return [];
        }
        $licencias = $this->licencia_model->get_todas();
        foreach ($licencias as $licencia) {
            $empleado = $this->empleado_model->get($licencia->empleado_id);
            $licencia->empleado_nombre = $empleado ? $empleado->nombre . ' ' . $empleado->apellido : '';
            $licencia->fecha_inicio_formateada = date_i18n('d/m/Y', strtotime($licencia->fecha_inicio));
            $licencia->fecha_fin_formateada = date_i18n('d/m/Y', strtotime($licencia->fecha_fin));
            if ($licencia->documento_id) {
                $licencia->documento_url = wp_get_attachment_url($licencia->documento_id);
            }
        }
        error_log("[obtener_historial_licencias][FIN-OK] Total: ".count($licencias));
        return $licencias;
    }

    // --------- NOTIFICACIÓN INTEGRADA AL CREAR --------------
    public function solicitar_licencia($empleado_id, $tipo, $fecha_inicio, $fecha_fin, $documento = null, $observaciones = '') {
        error_log("[solicitar_licencia][START] empleado_id=$empleado_id, tipo=$tipo, fecha_inicio=$fecha_inicio, fecha_fin=$fecha_fin, documento=".print_r($documento,true).", observaciones=$observaciones");
        if (!current_user_can('publish_midas_licencias')) {
            return new WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }
        if (!$empleado_id || !$tipo || !$fecha_inicio || !$fecha_fin) {
            return new WP_Error('invalid_data', __('Datos incompletos', 'midas-rrhh'));
        }
        $fecha_inicio_obj = \DateTime::createFromFormat('Y-m-d', $fecha_inicio);
        $fecha_fin_obj = \DateTime::createFromFormat('Y-m-d', $fecha_fin);
        if (!$fecha_inicio_obj || !$fecha_fin_obj || $fecha_fin_obj < $fecha_inicio_obj) {
            return new WP_Error('invalid_date', __('Fechas inválidas', 'midas-rrhh'));
        }
        $dias_solicitados = $fecha_inicio_obj->diff($fecha_fin_obj)->days + 1;
        $documento_id = null;
        if ($documento && !empty($documento['tmp_name'])) {
            $documento_id = $this->upload_documento($documento);
            if (is_wp_error($documento_id)) {
                return $documento_id;
            }
        }
        $data = [
            'empleado_id'      => intval($empleado_id),
            'tipo'             => sanitize_text_field($tipo),
            'fecha_inicio'     => $fecha_inicio,
            'fecha_fin'        => $fecha_fin,
            'dias_solicitados' => $dias_solicitados,
            'estado'           => 'pendiente',
            'observaciones'    => sanitize_textarea_field($observaciones),
            'gestor_id'        => get_current_user_id(),
        ];
        if ($documento_id) {
            $data['documento_id'] = $documento_id;
        }
        $licencia_id = $this->licencia_model->insert($data);

        // --------- ENVIAR NOTIFICACIÓN AL CREAR LICENCIA -----------

        if ($licencia_id && !is_wp_error($licencia_id)) {
            $this->notificaciones->enviar_notificacion_licencia_pendiente($licencia_id);

            // Devuelve el objeto completo recién creado
            return $this->obtener_licencia($licencia_id);
        }

        error_log("[solicitar_licencia][FIN-OK] licencia_id=$licencia_id");
        return $licencia_id;
    }

    // --------- NUEVO MÉTODO PARA ELIMINAR LICENCIA ---------
    public function eliminar_licencia(int $licencia_id) {
        error_log("[eliminar_licencia][START] licencia_id=$licencia_id");

        if (!current_user_can('delete_midas_licencias') && !current_user_can('rrhh_gestor') && !current_user_can('rrhh_admin') && !current_user_can('administrator')) {
            error_log('[eliminar_licencia][ERROR] Permiso denegado');
            return new WP_Error('forbidden', __('No tienes permisos para eliminar licencias.', 'midas-rrhh'));
        }

        if ($licencia_id <= 0) {
            error_log('[eliminar_licencia][ERROR] ID inválido');
            return new WP_Error('invalid_id', __('ID de licencia no válido.', 'midas-rrhh'));
        }

        $licencia = $this->licencia_model->get($licencia_id);
        if (!$licencia) {
            error_log('[eliminar_licencia][ERROR] Licencia no encontrada');
            return new WP_Error('not_found', __('Licencia no encontrada.', 'midas-rrhh'));
        }

        // Si tiene documento asociado, eliminar attachment
        if (!empty($licencia->documento_id)) {
            wp_delete_attachment($licencia->documento_id, true);
            error_log("[eliminar_licencia] Documento eliminado: {$licencia->documento_id}");
        }

        $result = $this->licencia_model->delete($licencia_id);

        if ($result === false) {
            error_log('[eliminar_licencia][ERROR] Error al eliminar licencia en BD');
            return new WP_Error('db_error', __('Error al eliminar la licencia.', 'midas-rrhh'));
        }

        error_log("[eliminar_licencia][FIN-OK] licencia_id=$licencia_id");
        return true;
    }
}
