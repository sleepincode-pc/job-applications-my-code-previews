<?php
namespace MidasRRHH\Controllers;

use MidasRRHH\Models\Tarea_Model;
use MidasRRHH\Models\Area_Model;
use MidasRRHH\Core\Security;

class Tarea_Area_Controller {
    private $tarea_model;
    private $area_model;
    private $security;

    public function __construct() {
        $this->tarea_model = new Tarea_Model();
        $this->area_model = new Area_Model();
        $this->security = new Security();
    }

    // Métodos para Tareas
    public function crear_tarea($nombre, $descripcion = '') {
        if (!current_user_can('edit_midas_tareas')) {
            return new \WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }

        $nombre = sanitize_text_field($nombre);
        if (empty($nombre)) {
            return new \WP_Error('empty_name', __('El nombre de la tarea no puede estar vacío', 'midas-rrhh'));
        }

        $tarea_data = [
            'nombre' => $nombre,
            'descripcion' => sanitize_textarea_field($descripcion),
        ];

        $tarea_id = $this->tarea_model->insert($tarea_data);

        if (!$tarea_id) {
            return new \WP_Error('db_error', __('Error al crear la tarea', 'midas-rrhh'));
        }

        return $tarea_id;
    }

    public function actualizar_tarea($tarea_id, $nombre, $descripcion = '', $activo = null) {
        if (!current_user_can('edit_midas_tareas')) {
            return new \WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }

        $tarea = $this->tarea_model->get($tarea_id);
        if (!$tarea) {
            return new \WP_Error('not_found', __('Tarea no encontrada', 'midas-rrhh'));
        }

        $nombre = sanitize_text_field($nombre);
        if (empty($nombre)) {
            return new \WP_Error('empty_name', __('El nombre de la tarea no puede estar vacío', 'midas-rrhh'));
        }

        $update_data = [
            'nombre' => $nombre,
            'descripcion' => sanitize_textarea_field($descripcion),
        ];

        if ($activo !== null) {
            $update_data['activo'] = $activo ? 1 : 0;
        }

        $result = $this->tarea_model->update($tarea_id, $update_data);

        if ($result === false) {
            return new \WP_Error('db_error', __('Error al actualizar la tarea', 'midas-rrhh'));
        }

        return true;
    }

    public function eliminar_tarea($tarea_id) {
        if (!current_user_can('edit_midas_tareas')) {
            return new \WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }

        $empleados_con_tarea = $this->empleados_con_tarea($tarea_id);
        if (!empty($empleados_con_tarea)) {
            return new \WP_Error('in_use', __('No se puede eliminar la tarea porque está asignada a empleados', 'midas-rrhh'));
        }

        $result = $this->tarea_model->delete($tarea_id);

        if (!$result) {
            return new \WP_Error('db_error', __('Error al eliminar la tarea', 'midas-rrhh'));
        }

        return true;
    }

    public function obtener_tarea($tarea_id) {
        if (!current_user_can('edit_midas_tareas')) {
            return new \WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }

        $tarea = $this->tarea_model->get($tarea_id);
        if (!$tarea) {
            return new \WP_Error('not_found', __('Tarea no encontrada', 'midas-rrhh'));
        }

        return $tarea;
    }

    public function obtener_todas_tareas($activas_only = false) {
        if (!current_user_can('edit_midas_tareas')) {
            return new \WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }

        return $this->tarea_model->get_all(!$activas_only);
    }

    private function empleados_con_tarea($tarea_id) {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, nombre, apellido FROM {$wpdb->prefix}midas_empleados 
                WHERE tarea_id = %d AND activo = 1",
                $tarea_id
            )
        );
    }

    // Métodos para Áreas
    public function crear_area($nombre, $descripcion = '') {
        if (!current_user_can('edit_midas_areas')) {
            return new \WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }

        $nombre = sanitize_text_field($nombre);
        if (empty($nombre)) {
            return new \WP_Error('empty_name', __('El nombre del área no puede estar vacío', 'midas-rrhh'));
        }

        $area_data = [
            'nombre' => $nombre,
            'descripcion' => sanitize_textarea_field($descripcion),
        ];

        $area_id = $this->area_model->insert($area_data);

        if (!$area_id) {
            return new \WP_Error('db_error', __('Error al crear el área', 'midas-rrhh'));
        }

        return $area_id;
    }

    public function actualizar_area($area_id, $nombre, $descripcion = '', $activo = null) {
        if (!current_user_can('edit_midas_areas')) {
            return new \WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }

        $area = $this->area_model->get($area_id);
        if (!$area) {
            return new \WP_Error('not_found', __('Área no encontrada', 'midas-rrhh'));
        }

        $nombre = sanitize_text_field($nombre);
        if (empty($nombre)) {
            return new \WP_Error('empty_name', __('El nombre del área no puede estar vacío', 'midas-rrhh'));
        }

        $update_data = [
            'nombre' => $nombre,
            'descripcion' => sanitize_textarea_field($descripcion),
        ];

        if ($activo !== null) {
            $update_data['activo'] = $activo ? 1 : 0;
        }

        $result = $this->area_model->update($area_id, $update_data);

        if ($result === false) {
            return new \WP_Error('db_error', __('Error al actualizar el área', 'midas-rrhh'));
        }

        return true;
    }

    public function eliminar_area($area_id) {
        if (!current_user_can('edit_midas_areas')) {
            return new \WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }

        $empleados_con_area = $this->empleados_con_area($area_id);
        if (!empty($empleados_con_area)) {
            return new \WP_Error('in_use', __('No se puede eliminar el área porque está asignada a empleados', 'midas-rrhh'));
        }

        $result = $this->area_model->delete($area_id);

        if (!$result) {
            return new \WP_Error('db_error', __('Error al eliminar el área', 'midas-rrhh'));
        }

        return true;
    }

    public function obtener_area($area_id) {
        if (!current_user_can('edit_midas_areas')) {
            return new \WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }

        $area = $this->area_model->get($area_id);
        if (!$area) {
            return new \WP_Error('not_found', __('Área no encontrada', 'midas-rrhh'));
        }

        return $area;
    }

    public function obtener_todas_areas($activas_only = false) {
        if (!current_user_can('edit_midas_areas')) {
            return new \WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }

        return $this->area_model->get_all(!$activas_only);
    }

    private function empleados_con_area($area_id) {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, nombre, apellido FROM {$wpdb->prefix}midas_empleados 
                WHERE area_id = %d AND activo = 1",
                $area_id
            )
        );
    }
}
