<?php
namespace MidasRRHH\Controllers;

use MidasRRHH\Models\Area_Model;
use MidasRRHH\Models\Empleado_Model;
use MidasRRHH\Models\Reporte_Model;

class Reporte_Controller {

    public function render_reportes() {
        $area_model     = new Area_Model();
        $empleado_model = new Empleado_Model();
        $reporte_model  = new Reporte_Model();

        // Áreas activas
        $areas = $area_model->obtener_areas_activas();

        // Filtro por área (si se envió el form)
        $area_id = isset($_POST['filtro_area']) && $_POST['filtro_area'] !== '' ? intval($_POST['filtro_area']) : null;

        // Empleados (filtrados o todos), ordenado por actualización/creación desc
        if ($area_id) {
            $empleados = $empleado_model->obtener_empleados_por_area($area_id);
        } else {
            $empleados = $empleado_model->obtener_empleados_con_area_y_tarea_ordenados();
        }

        // NUEVO: movimientos de actividad (para la tabla “Movimientos (Actividad)”)
        // Trae creado/actualizado en Documentación y Tipos, con el nombre del usuario WP.
        $actividad = $reporte_model->obtener_movimientos_actividad(200);

        // Helpers de formato
        $calcular_antiguedad = function($fecha_inicio) {
            if (empty($fecha_inicio) || $fecha_inicio == '0000-00-00') return '';
            $inicio = new \DateTime($fecha_inicio);
            $hoy    = new \DateTime();
            $diff   = $hoy->diff($inicio);
            return $diff->y . ' años, ' . $diff->m . ' meses';
        };

        $formatear_fecha = function($fecha) {
            if (empty($fecha) || $fecha == '0000-00-00') return '';
            $date = \DateTime::createFromFormat('Y-m-d', $fecha);
            return $date ? $date->format('d/m/Y') : '';
        };

        foreach ($empleados as $empleado) {
            $empleado->fecha_inicio_laboral_formateada = $formatear_fecha($empleado->fecha_inicio_laboral ?? '');
            $empleado->antiguedad = $calcular_antiguedad($empleado->fecha_inicio_laboral ?? '');
        }

        // Cargar la vista (tendrá disponibles: $areas, $empleados, $actividad)
        require_once MIDAS_RRHH_PLUGIN_DIR . 'templates/admin/reportes.php';
    }
}
