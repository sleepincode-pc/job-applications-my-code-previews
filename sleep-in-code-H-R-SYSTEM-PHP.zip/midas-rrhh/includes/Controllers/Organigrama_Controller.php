<?php
namespace MidasRRHH\Controllers;

use MidasRRHH\Models\Organigrama_Model;

if (!defined('ABSPATH')) exit;

/*──────────────────────────────────────────────────────────────────────────────
  MIDAS RRHH — ORGANIGRAMA: Controller (AJAX)
  Ajustes:
  - Acepta 'tree' o 'data' (JSON string o array).
  - Permisos: edit_midas_empleados OR manage_options.
  - Nonce con check_ajax_referer('midas_orgchart_nonce','nonce', false).
  - Chequeo de tamaño tras wp_json_encode().
  - Respuesta GET incluye 'source' => 'controller' (útil para debug).
──────────────────────────────────────────────────────────────────────────────*/

class Organigrama_Controller {
    /** @var Organigrama_Model */
    private Organigrama_Model $model;

    public function __construct() {
        $this->model = new Organigrama_Model();

        // AJAX (solo admin)
        add_action('wp_ajax_midas_orgchart_get',  [$this, 'ajax_get']);
        add_action('wp_ajax_midas_orgchart_save', [$this, 'ajax_save']);
    }

    /** GET: devuelve el árbol del organigrama */
    public function ajax_get() {
        if (!current_user_can('edit_midas_empleados') && !current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Sin permisos.', 'midas-rrhh')], 403);
        }
        if (!check_ajax_referer('midas_orgchart_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Nonce inválido.', 'midas-rrhh')], 403);
        }

        $tree = $this->model->get_tree();
        wp_send_json_success(['tree' => $tree, 'source' => 'controller']);
    }

    /** SAVE: persiste el árbol del organigrama */
    public function ajax_save() {
        if (!current_user_can('edit_midas_empleados') && !current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Sin permisos.', 'midas-rrhh')], 403);
        }
        if (!check_ajax_referer('midas_orgchart_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Nonce inválido.', 'midas-rrhh')], 403);
        }

        // Acepta 'tree' o 'data', como JSON string o array.
        $payload = $_POST['tree'] ?? $_POST['data'] ?? null;

        if (is_string($payload)) {
            $payload = json_decode(wp_unslash($payload), true);
        } elseif (is_array($payload)) {
            // Ya es array: quitamos slashes profundos
            $payload = stripslashes_deep($payload);
        }

        if (empty($payload) || !is_array($payload)) {
            wp_send_json_error(['message' => __('Payload vacío o inválido.', 'midas-rrhh')], 400);
        }

        if (!$this->model->validate_tree($payload)) {
            wp_send_json_error(['message' => __('Estructura inválida.', 'midas-rrhh')], 422);
        }

        // Verificación de tamaño sobre lo que realmente se guardará
        $json_for_size = wp_json_encode($payload);
        if (!$json_for_size || strlen($json_for_size) > Organigrama_Model::MAX_BYTES) {
            wp_send_json_error(['message' => __('Organigrama demasiado grande.', 'midas-rrhh')], 413);
        }

        $ok = $this->model->save_tree($payload);
        if (!$ok) {
            wp_send_json_error(['message' => __('No se pudo guardar.', 'midas-rrhh')], 500);
        }

        wp_send_json_success(['saved' => true]);
    }
}
