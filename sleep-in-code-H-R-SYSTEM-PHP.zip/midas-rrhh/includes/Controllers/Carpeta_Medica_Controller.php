<?php
namespace MidasRRHH\Controllers;

use MidasRRHH\Models\Carpeta_Medica_Model;
use MidasRRHH\Core\Notificaciones;
use WP_Error;

class Carpeta_Medica_Controller
{
    private $model;

    public function __construct()
    {
        $this->model = new Carpeta_Medica_Model();
    }

    // =============================
    // Normalizador que PRESERVA ESPACIOS
    // =============================
    /**
     * - NFKC
     * - Elimina zero-width
     * - Convierte espacios “raros” (NBSP etc.) a espacio normal
     * - Quita controles (permite \r\n si $allow_newlines)
     * - Filtra a set seguro
     * - NO recorta ni colapsa espacios
     * - Opcionalmente convierte a MAYÚSCULAS
     */
    private function normalize_preservando_espacios($s, $allow_newlines = false, $to_upper = true)
    {
        $orig = (string) $s;
        $s = (string) $s;

        if (function_exists('wp_unslash')) {
            $s = wp_unslash($s);
        }
        if (class_exists('\Normalizer')) {
            $norm = \Normalizer::normalize($s, \Normalizer::FORM_KC);
            if ($norm !== false) $s = $norm;
        }

        $safe_preg = static function ($pattern, $replacement, $subject) {
            $res = @preg_replace($pattern, $replacement, $subject);
            return ($res === null) ? $subject : $res;
        };

        // Zero-width
        $s = $safe_preg('/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $s);

        // Espacios raros -> normal
        $s = $safe_preg('/[\x{00A0}\x{1680}\x{2000}-\x{200A}\x{202F}\x{205F}\x{3000}]/u', ' ', $s);

        // Control chars
        if ($allow_newlines) {
            $s = $safe_preg('/[\x00-\x09\x0B\x0C\x0E-\x1F\x7F]/u', '', $s);
        } else {
            $s = $safe_preg('/[\x00-\x1F\x7F]/u', '', $s);
        }

        // Set permitido (+ \r\n si corresponde). OJO con la "/"
        $allowed = '/[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ0-9 .,:;¡!¿?\(\)\-_\/#+%'.($allow_newlines ? "\r\n" : '').']/u';
        $s = $safe_preg($allowed, '', $s);

        if ($to_upper) {
            $s = function_exists('mb_strtoupper') ? mb_strtoupper($s, 'UTF-8') : strtoupper($s);
        }

        if ($s === null || $s === false) {
            $s = $orig;
        }

        return $s;
    }

    /**
     * Compat: tomar observaciones desde varios nombres.
     */
    private function coalesce_observaciones($observaciones_inicial, $allow_newlines = true)
    {
        $valor = (string) ($observaciones_inicial ?? '');

        if ($valor === '' && !empty($_POST)) {
            $candidatos = ['observaciones', 'respuesta', 'motivo_rechazo', 'obs_gestion', 'observaciones_estado'];
            foreach ($candidatos as $k) {
                if (isset($_POST[$k]) && $_POST[$k] !== '') {
                    $valor = (string) $_POST[$k];
                    break;
                }
            }
        }

        return $this->normalize_preservando_espacios($valor, $allow_newlines, true);
    }

    // Crear documento
    public function crear_documento_medico($empleado_id, $motivo_id, $medico_id, $fecha_emision, $archivo, $dias_solicitados = 1, $observaciones = '')
    {
        error_log("=====[Carpeta_Medica_Controller][crear_documento_medico]=====");
        error_log("Args: empleado_id=$empleado_id, motivo_id=$motivo_id, medico_id=$medico_id, fecha_emision=$fecha_emision, dias_solicitados=$dias_solicitados, observaciones=".json_encode($observaciones));
        error_log("Archivo: " . ($archivo ? json_encode([
            'name' => $archivo['name'] ?? '',
            'type' => $archivo['type'] ?? '',
            'size' => $archivo['size'] ?? '',
            'tmp_name' => $archivo['tmp_name'] ?? '',
            'error' => $archivo['error'] ?? '',
        ]) : 'NULL'));

        if (!$empleado_id || !$motivo_id || !$medico_id || !$fecha_emision) {
            return new WP_Error('parametros_invalidos', 'Faltan parámetros obligatorios.');
        }

        $dias_solicitados = max(1, (int)$dias_solicitados);
        $observaciones = $this->coalesce_observaciones($observaciones, true);

        $documento_id = null;

        if ($archivo && !empty($archivo['tmp_name'])) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';

            $overrides = ['test_form' => false];
            $uploaded_file = wp_handle_upload($archivo, $overrides);
            if (isset($uploaded_file['error'])) {
                return new WP_Error('upload_error', $uploaded_file['error']);
            }

            $attachment = [
                'post_mime_type' => $uploaded_file['type'],
                'post_title'     => sanitize_file_name(basename($uploaded_file['file'])),
                'post_content'   => '',
                'post_status'    => 'inherit',
            ];
            $attach_id = wp_insert_attachment($attachment, $uploaded_file['file']);
            if (is_wp_error($attach_id)) {
                return $attach_id;
            }

            $attach_data = wp_generate_attachment_metadata($attach_id, $uploaded_file['file']);
            wp_update_attachment_metadata($attach_id, $attach_data);

            $documento_id = $attach_id;
        }

        $data = [
            'empleado_id'       => $empleado_id,
            'motivo_id'         => $motivo_id,
            'medico_id'         => $medico_id,
            'fecha_emision'     => $fecha_emision,
            'fecha_vencimiento' => null,
            'dias_solicitados'  => $dias_solicitados,
            'observaciones'     => $observaciones,
            'documento_id'      => $documento_id,
            'estado_id'         => 1, // pendiente
            'created_at'        => current_time('mysql'),
            'updated_at'        => current_time('mysql'),
        ];

        $inserted = $this->model->insert($data);
        if (is_wp_error($inserted) || !$inserted) {
            return is_wp_error($inserted) ? $inserted : new WP_Error('db_error', 'Error al insertar documento médico.');
        }

        try {
            $notificaciones = new Notificaciones();
            $notificaciones->enviar_notificacion_documento_medico_pendiente($inserted);
        } catch (\Throwable $e) { /* noop */ }

        return $this->model->get_with_empleado($inserted);
    }

    public function editar_documento_medico(array $post_data, $archivo = null)
    {
        $documento_id = intval($post_data['documento_id'] ?? 0);
        if (!$documento_id) {
            return new WP_Error('parametros_invalidos', 'ID de documento inválido.');
        }
        $documento = $this->model->get($documento_id);
        if (!$documento) {
            return new WP_Error('not_found', 'Documento médico no encontrado.');
        }

        $data_update = [];
        if (!empty($post_data['motivo'])) {
            $data_update['motivo_id'] = intval($post_data['motivo']);
        } elseif (!empty($post_data['motivo_id'])) {
            $data_update['motivo_id'] = intval($post_data['motivo_id']);
        }
        if (!empty($post_data['medico_id'])) {
            $data_update['medico_id'] = intval($post_data['medico_id']);
        }
        if (!empty($post_data['fecha_emision'])) {
            $data_update['fecha_emision'] = sanitize_text_field($post_data['fecha_emision']);
        }
        if (!empty($post_data['fecha_vencimiento'])) {
            $data_update['fecha_vencimiento'] = sanitize_text_field($post_data['fecha_vencimiento']);
        }
        if ($post_data['dias_solicitados'] !== '' && $post_data['dias_solicitados'] !== null) {
            $data_update['dias_solicitados'] = max(1, intval($post_data['dias_solicitados']));
        }

        if (array_key_exists('observaciones', $post_data) || array_key_exists('respuesta', $post_data)) {
            $obs_src = $post_data['observaciones'] ?? $post_data['respuesta'] ?? '';
            $data_update['observaciones'] = $this->coalesce_observaciones($obs_src, true);
        }

        if ($archivo && !empty($archivo['tmp_name'])) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';

            $overrides = ['test_form' => false];
            $uploaded_file = wp_handle_upload($archivo, $overrides);
            if (isset($uploaded_file['error'])) {
                return new WP_Error('upload_error', $uploaded_file['error']);
            }

            // Borrar attachment anterior si lo hay
            if (!empty($documento->documento_id)) {
                wp_delete_attachment((int)$documento->documento_id, true);
            }

            $attachment = [
                'post_mime_type' => $uploaded_file['type'],
                'post_title'     => sanitize_file_name(basename($uploaded_file['file'])),
                'post_content'   => '',
                'post_status'    => 'inherit',
            ];
            $attach_id = wp_insert_attachment($attachment, $uploaded_file['file']);
            if (is_wp_error($attach_id)) {
                return $attach_id;
            }

            $attach_data = wp_generate_attachment_metadata($attach_id, $uploaded_file['file']);
            wp_update_attachment_metadata($attach_id, $attach_data);

            $data_update['documento_id'] = $attach_id;
        }

        $data_update['updated_at'] = current_time('mysql');

        $updated = $this->model->update($documento_id, $data_update);
        if (!$updated) {
            return new WP_Error('db_error', 'Error al actualizar documento médico.');
        }

        return $this->model->get_with_empleado($documento_id);
    }

    public function aprobar_documento_medico($documento_id, $dias_aprobados, $observaciones = '')
    {
        $documento = $this->model->get($documento_id);
        if (!$documento) {
            return new WP_Error('not_found', 'Documento médico no encontrado.');
        }

        $observaciones = $this->coalesce_observaciones($observaciones, true);

        $data_update = [
            'estado_id'      => 2,
            'dias_aprobados' => max(1, intval($dias_aprobados)),
            'observaciones'  => $observaciones,
            'updated_at'     => current_time('mysql'),
        ];

        $updated = $this->model->update($documento_id, $data_update);
        if (!$updated) {
            return new WP_Error('db_error', 'Error al aprobar documento médico.');
        }

        try {
            $notificaciones = new Notificaciones();
            $notificaciones->enviar_notificacion_documento_medico_aprobado($documento_id);
        } catch (\Throwable $e) { /* noop */ }

        return $this->model->get_with_empleado($documento_id);
    }

    public function rechazar_documento_medico($documento_id, $observaciones = '')
    {
        $documento = $this->model->get($documento_id);
        if (!$documento) {
            return new WP_Error('not_found', 'Documento médico no encontrado.');
        }

        $observaciones = $this->coalesce_observaciones($observaciones, true);

        $data_update = [
            'estado_id'     => 3,
            'observaciones' => $observaciones,
            'updated_at'    => current_time('mysql'),
        ];

        $updated = $this->model->update($documento_id, $data_update);
        if (!$updated) {
            return new WP_Error('db_error', 'Error al rechazar documento médico.');
        }

        try {
            $notificaciones = new Notificaciones();
            $notificaciones->enviar_notificacion_documento_medico_rechazado($documento_id);
        } catch (\Throwable $e) { /* noop */ }

        return $this->model->get_with_empleado($documento_id);
    }

    public function obtener_documento($documento_id)
    {
        $documento = $this->model->get_with_empleado($documento_id);
        if (!$documento) {
            return new WP_Error('not_found', 'Documento médico no encontrado.');
        }
        return $documento;
    }

    public function obtener_documentos_pendientes()
    {
        return $this->model->get_por_estado_con_empleado(1);
    }

    public function obtener_documentos_aprobados()
    {
        return $this->model->get_por_estado_con_empleado(2);
    }

    public function obtener_documentos_rechazados()
    {
        return $this->model->get_por_estado_con_empleado(3);
    }

    public function obtener_historial_documentos()
    {
        return $this->model->get_all_con_empleado();
    }

    // ===== AJAX helpers =====

    public function ajax_obtener_documentos_empleado()
    {
        if (!is_user_logged_in()) {
            return new WP_Error('no_auth', 'Debes iniciar sesión para ver los documentos.');
        }
        $current_user = wp_get_current_user();
        $empleado_id = $this->get_empleado_id_por_usuario($current_user->ID);
        if (!$empleado_id) {
            return new WP_Error('no_empleado', 'Empleado no encontrado para el usuario actual.');
        }
        $documentos = $this->model->get_by_empleado($empleado_id);
        return $documentos ?: [];
    }

    public function ajax_obtener_documento_medico()
    {
        $documento_id = intval($_POST['documento_id'] ?? 0);
        if (!$documento_id) {
            return new WP_Error('param_invalid', 'ID de documento inválido.');
        }
        return $this->obtener_documento($documento_id);
    }

    public function ajax_obtener_documentos_pendientes()   { return $this->obtener_documentos_pendientes() ?: []; }
    public function ajax_obtener_documentos_aprobados()    { return $this->obtener_documentos_aprobados() ?: []; }
    public function ajax_obtener_documentos_rechazados()   { return $this->obtener_documentos_rechazados() ?: []; }
    public function ajax_obtener_historial_documentos()    { return $this->obtener_historial_documentos() ?: []; }

    // Eliminar documento + borrar attachment si existe
    public function eliminar_documento_medico($documento_id)
    {
        $documento = $this->model->get($documento_id);
        if (!$documento) {
            return new WP_Error('not_found', 'Documento médico no encontrado.');
        }

        // si hay archivo adjunto, lo borramos del media library
        if (!empty($documento->documento_id)) {
            try {
                wp_delete_attachment((int)$documento->documento_id, true);
            } catch (\Throwable $e) {
                // no interrumpimos si falla borrar el archivo
            }
        }

        $deleted = $this->model->delete($documento_id);
        if (!$deleted) {
            return new WP_Error('db_error', 'Error al eliminar documento médico.');
        }
        return true;
    }

    private function get_empleado_id_por_usuario($user_id)
    {
        global $wpdb;
        $tabla = $wpdb->prefix . 'midas_empleados';
        $empleado_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM $tabla WHERE user_id = %d", $user_id));
        return $empleado_id ?: null;
    }

    public function obtener_documentos_empleado($empleado_id)
    {
        if (!$empleado_id) {
            return new WP_Error('parametros_invalidos', 'Falta el ID de empleado.');
        }
        return $this->model->get_by_empleado($empleado_id);
    }
}
