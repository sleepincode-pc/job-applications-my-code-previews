<?php
namespace MidasRRHH\Controllers;

use MidasRRHH\Models\Empleado_Model;
use MidasRRHH\Models\Tarea_Model;
use MidasRRHH\Models\Area_Model;
use MidasRRHH\Core\Security;

class Empleado_Controller {
    public $empleado_model;
    private $tarea_model;
    private $area_model;
    private $security;

    public function __construct() {
        $this->empleado_model = new Empleado_Model();
        $this->tarea_model = new Tarea_Model();
        $this->area_model = new Area_Model();
        $this->security = new Security();
    }

    // Helpers para obtener nombres
    public function get_area_nombre_por_id($id) {
        global $wpdb;
        if (!$id) return '';
        return (string)$wpdb->get_var($wpdb->prepare("SELECT nombre FROM {$wpdb->prefix}midas_areas WHERE id=%d", $id));
    }

    public function get_tarea_nombre_por_id($id) {
        global $wpdb;
        if (!$id) return '';
        return (string)$wpdb->get_var($wpdb->prepare("SELECT nombre FROM {$wpdb->prefix}midas_tareas WHERE id=%d", $id));
    }

    /**
     * Lógica de negocio para crear empleado
     */
    public function crear_empleado($data) {
        if (empty($data['nombre']) || empty($data['apellido'])) {
            return new \WP_Error('incomplete', __('Nombre y Apellido son obligatorios.', 'midas-rrhh'));
        }
        // Permitir fecha_fin_laboral si tu modelo lo guarda
        $id = $this->empleado_model->insert($data);
        if (!$id) {
            return new \WP_Error('db_error', __('Error al guardar empleado.', 'midas-rrhh'));
        }
        return $id;
    }

    /**
     * Lógica de negocio para actualizar empleado
     */
    public function actualizar_empleado($id, $data, $files = []) {
        if (empty($id)) {
            return new \WP_Error('invalid_id', __('ID de empleado inválido.', 'midas-rrhh'));
        }
        // Permitir fecha_fin_laboral si tu modelo lo guarda
        $updated = $this->empleado_model->update($id, $data);
        if ($updated === false) {
            return new \WP_Error('db_error', __('Error al actualizar empleado.', 'midas-rrhh'));
        }
        return true;
    }

    /**
     * ELIMINAR EMPLEADO (NUEVO)
     */
    public function eliminar_empleado($empleado_id) {
        global $wpdb;
        // Eliminar notas asociadas (si existen)
        $wpdb->delete("{$wpdb->prefix}midas_empleado_notas", ['empleado_id' => $empleado_id]);
        // Eliminar empleado
        $result = $wpdb->delete("{$wpdb->prefix}midas_empleados", ['id' => $empleado_id]);
        if ($result === false) {
            return new \WP_Error('db_error', __('Error al eliminar el empleado.', 'midas-rrhh'));
        }
        return true;
    }

    /**
     * Obtener empleado por user_id (para frontend)
     */
    public function get_by_user_id($user_id) {
        return $this->empleado_model->get_by_user_id($user_id);
    }

    /**
     * Obtener empleado por ID con nombres de área y tarea
     */
    public function get_by_id_con_area_y_tarea($id) {
        return $this->empleado_model->get_by_id_con_area_y_tarea($id);
    }

    /**
     * Obtener todos los empleados (con fecha_fin_laboral)
     */
    public function obtener_todos_empleados($limit = 100, $offset = 0) {
        global $wpdb;
        $tabla = $wpdb->prefix . 'midas_empleados';
        $sql = $wpdb->prepare("SELECT e.*, a.nombre AS area_nombre, t.nombre AS tarea_nombre, e.fecha_fin_laboral
            FROM $tabla e
            LEFT JOIN {$wpdb->prefix}midas_areas a ON e.area = a.id
            LEFT JOIN {$wpdb->prefix}midas_tareas t ON e.tarea = t.id
            ORDER BY e.id DESC
            LIMIT %d OFFSET %d", $limit, $offset);
        return $wpdb->get_results($sql);
    }

    // --------------------------
    // BUSQUEDA AJAX UNIFICADA (para Ajax_Handler)
    // --------------------------
    public function buscar_empleados_ajax($buscar = '', $paged = 1, $por_pagina = 10) {
        global $wpdb;
        $tabla = $wpdb->prefix . 'midas_empleados';
        $offset = ($paged - 1) * $por_pagina;

        $where = '';
        $params = [];
        if (!empty($buscar)) {
            $where = " WHERE e.nombre LIKE %s OR e.apellido LIKE %s OR e.dni LIKE %s OR e.cuil LIKE %s";
            $wild = '%' . $wpdb->esc_like($buscar) . '%';
            $params = [$wild, $wild, $wild, $wild];
        }

        $sql_total = "SELECT COUNT(*) FROM $tabla e" . $where;
        $total = $wpdb->get_var($params ? $wpdb->prepare($sql_total, ...$params) : $sql_total);

        // AGREGADO: fecha_fin_laboral en el SELECT
        $sql = "SELECT e.*, a.nombre AS area_nombre, t.nombre AS tarea_nombre, e.fecha_fin_laboral
                FROM $tabla e
                LEFT JOIN {$wpdb->prefix}midas_areas a ON e.area = a.id
                LEFT JOIN {$wpdb->prefix}midas_tareas t ON e.tarea = t.id
                $where ORDER BY e.id DESC LIMIT %d OFFSET %d";

        $params2 = $params;
        $params2[] = $por_pagina;
        $params2[] = $offset;

        $empleados = $wpdb->get_results($params2 ? $wpdb->prepare($sql, ...$params2) : "$sql LIMIT $por_pagina OFFSET $offset");

        // Mapas para áreas y tareas
        $areas = $wpdb->get_results("SELECT id, nombre FROM {$wpdb->prefix}midas_areas ORDER BY nombre ASC");
        $areas_map = [];
        foreach ($areas as $a) $areas_map[$a->id] = $a->nombre;
        $tareas = $wpdb->get_results("SELECT id, nombre FROM {$wpdb->prefix}midas_tareas ORDER BY nombre ASC");
        $tareas_map = [];
        foreach ($tareas as $t) $tareas_map[$t->id] = $t->nombre;

        // Notas de empleados
        $notas_empleados = [];
        $notas = $wpdb->get_results("SELECT empleado_id, nota FROM {$wpdb->prefix}midas_empleado_notas");
        foreach ($notas as $nota) $notas_empleados[$nota->empleado_id] = $nota->nota;

        // Paginación simple
        $total_paginas = ceil($total / $por_pagina);
        $pagination = '';
        if ($total_paginas > 1) {
            $pagination .= '<nav class="midas-paginacion"><ul>';
            for ($i = 1; $i <= $total_paginas; $i++) {
                $active = $i == $paged ? ' active' : '';
                $pagination .= "<li class='$active' data-paged='$i'>$i</li>";
            }
            $pagination .= '</ul></nav>';
        }

        return [
            'empleados' => $empleados,
            'areas_map' => $areas_map,
            'tareas_map' => $tareas_map,
            'notas_empleados' => $notas_empleados,
            'pagination' => $pagination,
        ];
    }
}
