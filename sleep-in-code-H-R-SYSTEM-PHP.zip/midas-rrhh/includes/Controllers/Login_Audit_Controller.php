<?php
namespace MidasRRHH\Controllers;

if (!defined('ABSPATH')) exit;

class Login_Audit_Controller {

    public static function init() {
        // Se dispara en /wp-login.php con usuario autenticado
        add_action('wp_login', [__CLASS__, 'on_login'], 10, 2);
    }

    public static function on_login($user_login, $user) {
        if (!($user instanceof \WP_User)) return;

        $ip  = self::get_ip();
        $ua  = isset($_SERVER['HTTP_USER_AGENT']) ? substr((string)$_SERVER['HTTP_USER_AGENT'], 0, 1000) : '';
        $os  = self::detect_os($ua);
        $br  = self::detect_browser($ua);
        $dev = self::detect_device($ua);

        $geo = self::geolocate_ip($ip); // city, region, country, lat, lon (o vacío)

        global $wpdb;
        $t = $wpdb->prefix . 'midas_login_audit';
        $wpdb->insert($t, [
            'user_id'  => (int) $user->ID,
            'login_at' => current_time('mysql'),
            'ip'       => $ip ?: null,
            'ua'       => $ua ?: null,
            'device'   => $dev ?: null,
            'browser'  => $br ?: null,
            'os'       => $os ?: null,
            'city'     => $geo['city'] ?? null,
            'region'   => $geo['region'] ?? null,
            'country'  => $geo['country'] ?? null,
            'lat'      => isset($geo['lat']) ? (float)$geo['lat'] : null,
            'lon'      => isset($geo['lon']) ? (float)$geo['lon'] : null,
        ]);
    }

    /* -------- helpers -------- */

    private static function get_ip(): string {
        $keys = ['HTTP_X_FORWARDED_FOR','HTTP_CLIENT_IP','HTTP_X_REAL_IP','REMOTE_ADDR'];
        foreach ($keys as $k) {
            if (!empty($_SERVER[$k])) {
                $ip = trim(explode(',', $_SERVER[$k])[0]);
                return substr($ip, 0, 45);
            }
        }
        return '';
    }

    private static function detect_device(string $ua): string {
        $u = strtolower($ua);
        if (strpos($u, 'mobile') !== false || strpos($u, 'iphone') !== false || strpos($u, 'android') !== false) return 'Mobile';
        if (strpos($u, 'ipad') !== false || strpos($u, 'tablet') !== false) return 'Tablet';
        return 'Desktop';
    }
    private static function detect_os(string $ua): string {
        $map = [
            'Windows' => 'Windows', 'Mac OS' => 'macOS', 'Macintosh' => 'macOS',
            'Android' => 'Android', 'iPhone' => 'iOS', 'iPad' => 'iPadOS',
            'Linux' => 'Linux', 'CrOS' => 'ChromeOS'
        ];
        foreach ($map as $needle => $val) if (stripos($ua, $needle)!==false) return $val;
        return 'Desconocido';
    }
    private static function detect_browser(string $ua): string {
        $pairs = ['Edg' => 'Edge', 'OPR' => 'Opera', 'Chrome' => 'Chrome', 'Firefox' => 'Firefox', 'Safari' => 'Safari', 'MSIE' => 'IE', 'Trident' => 'IE'];
        foreach ($pairs as $needle => $val) if (stripos($ua, $needle)!==false) return $val;
        return 'Desconocido';
    }

    /**
     * Geolocaliza por IP con caché (1 semana).
     * Usa ipapi.co; si IP es local, devuelve "Localhost".
     */
    private static function geolocate_ip(string $ip): array {
        if (!$ip || $ip === '127.0.0.1' || $ip === '::1') {
            return ['city' => 'Localhost', 'region' => '', 'country' => '', 'lat' => null, 'lon' => null];
        }
        $key = 'midas_geo_' . md5($ip);
        $cached = get_transient($key);
        if (is_array($cached)) return $cached;

        $resp = wp_remote_get("https://ipapi.co/" . rawurlencode($ip) . "/json/", [
            'timeout' => 3,
            'headers' => ['Accept' => 'application/json']
        ]);
        $out = [];
        if (!is_wp_error($resp) && 200 === wp_remote_retrieve_response_code($resp)) {
            $body = json_decode(wp_remote_retrieve_body($resp), true);
            if (is_array($body)) {
                $out = [
                    'city'    => sanitize_text_field($body['city'] ?? ''),
                    'region'  => sanitize_text_field($body['region'] ?? ''),
                    'country' => sanitize_text_field($body['country_name'] ?? ($body['country'] ?? '')),
                    'lat'     => isset($body['latitude']) ? (float)$body['latitude'] : null,
                    'lon'     => isset($body['longitude']) ? (float)$body['longitude'] : null,
                ];
            }
        }
        set_transient($key, $out, WEEK_IN_SECONDS);
        return $out;
    }
}
