<?php
namespace MidasRRHH\Controllers;

if (!defined('ABSPATH')) exit;

class ImportExport_Controller {

    public static function init() {
        // Import simple
        add_action('admin_post_midas_ie_import', [self::class, 'handle_import_simple']);

        // Import avanzado
        add_action('admin_post_midas_ie_import_adv', [self::class, 'handle_import_advanced']);

        // Export
        add_action('admin_post_midas_ie_export', [self::class, 'handle_export']);

        // API Keys
        add_action('admin_post_midas_api_new_key',  [self::class, 'handle_api_new_key']);
        add_action('admin_post_midas_api_del_key',  [self::class, 'handle_api_del_key']);
        add_action('admin_post_midas_api_show_key', [self::class, 'handle_api_show_key']); // <-- nuevo
    }

    /* ============================================================
     * IMPORTADOR SIMPLE
     * ============================================================ */
    public static function handle_import_simple() {
        if (!current_user_can('manage_options')) wp_die('Permisos insuficientes');
        check_admin_referer('midas_ie_import');

        $target     = sanitize_text_field($_POST['target'] ?? '');
        $has_header = !empty($_POST['has_header']);
        $dry_run    = !empty($_POST['dry_run']);

        $file = $_FILES['file'] ?? null;
        if (!$file || empty($file['tmp_name'])) {
            self::redirect_msg(__('Subí un archivo.', 'midas-rrhh'), 0, 1);
        }

        // CSV/Excel
        $rows = self::read_any_spreadsheet($file['tmp_name']);
        if ($rows === null) self::redirect_msg(__('Archivo no válido o vacío.', 'midas-rrhh'), 0, 1);

        $ok = 0; $err = 0;

        // Si hay encabezado, tomarlo
        $headers = [];
        if ($has_header && !empty($rows)) {
            $headers = array_map([self::class,'normalize_header'], array_shift($rows));
        } else {
            if (!empty($rows)) {
                $headers = [];
                $max = max(array_map('count', $rows));
                for ($i=0; $i<$max; $i++) $headers[] = 'col'.($i+1);
            }
        }

        foreach ($rows as $i => $row) {
            $assoc = self::row_to_assoc($headers, $row);
            $res = self::persist_row($target, $assoc, 'insert'); // simple = insert
            if ($res === true) $ok++; else $err++;
        }

        $msg = sprintf(__('Importación simple finalizada (%s).', 'midas-rrhh'), $target);
        if ($dry_run) $msg = __('Simulación OK (no se guardó nada).', 'midas-rrhh');

        self::redirect_msg($msg, $ok, $err);
    }

    /* ============================================================
     * IMPORTADOR AVANZADO
     * ============================================================ */
    public static function handle_import_advanced() {
        if (!current_user_can('manage_options')) wp_die('Permisos insuficientes');
        check_admin_referer('midas_ie_import_adv');

        $target      = sanitize_text_field($_POST['adv_target'] ?? '');
        $encoding    = sanitize_text_field($_POST['adv_encoding'] ?? 'UTF-8');
        $delimiter   = self::unescape($_POST['adv_delimiter'] ?? ',');
        $enclosure   = self::unescape($_POST['adv_enclosure'] ?? '"');
        $escape      = self::unescape($_POST['adv_escape'] ?? '\\');
        $decimal     = sanitize_text_field($_POST['adv_decimal'] ?? '.');
        $date_format = sanitize_text_field($_POST['adv_date_format'] ?? 'Y-m-d');
        $has_header  = intval($_POST['adv_has_header'] ?? 1);
        $skip_rows   = max(0, intval($_POST['adv_skip_rows'] ?? 0));
        $max_rows    = max(0, intval($_POST['adv_max_rows'] ?? 0));
        $mode        = sanitize_text_field($_POST['adv_mode'] ?? 'insert');
        $dry_run     = !empty($_POST['adv_dry_run']);
        $mapping     = [];
        if (!empty($_POST['adv_mapping'])) {
            $mapping = json_decode(wp_unslash($_POST['adv_mapping']), true);
            if (!is_array($mapping)) $mapping = [];
        }

        // Subida o URL
        $file = $_FILES['adv_file'] ?? null;
        $url  = esc_url_raw($_POST['adv_url'] ?? '');

        $buffer = null;

        if ($file && !empty($file['tmp_name'])) {
            $buffer = file_get_contents($file['tmp_name']);
        } elseif (!empty($url)) {
            $resp = wp_remote_get($url, ['timeout' => 30]);
            if (!is_wp_error($resp) && wp_remote_retrieve_response_code($resp) === 200) {
                $buffer = wp_remote_retrieve_body($resp);
            }
        }

        if ($buffer === null) {
            self::redirect_msg(__('No se pudo leer el archivo/URL.', 'midas-rrhh'), 0, 1);
        }

        // Convertir a UTF-8 si hace falta
        if (function_exists('mb_convert_encoding') && strtoupper($encoding) !== 'UTF-8') {
            $buffer = @mb_convert_encoding($buffer, 'UTF-8', $encoding);
        }

        // Abrir stream temporal
        $fh = fopen('php://temp', 'w+');
        fwrite($fh, $buffer);
        rewind($fh);

        $ok=0; $err=0;
        $headers = [];
        $line_no = 0;

        // Saltar N filas si corresponde
        for ($s=0; $s<$skip_rows; $s++) {
            if (feof($fh)) break;
            fgetcsv($fh, 0, $delimiter, $enclosure, $escape);
            $line_no++;
        }

        // Leer encabezados
        if ($has_header) {
            $raw = fgetcsv($fh, 0, $delimiter, $enclosure, $escape);
            $line_no++;
            if (!is_array($raw)) $raw = [];
            $headers = array_map([self::class,'normalize_header'], $raw);
        }

        $read_rows = 0;

        // Procesar filas
        while (!feof($fh)) {
            $row = fgetcsv($fh, 0, $delimiter, $enclosure, $escape);
            if ($row === false || $row === null) break;
            $line_no++;

            if ($row === [null] || $row === []) continue;

            if (!$headers) {
                $headers = [];
                for ($i=0; $i<count($row); $i++) $headers[] = 'col'.($i+1);
            }

            $assoc = self::row_to_assoc($headers, $row);

            // Mapear columnas según $mapping
            $assoc = self::apply_mapping($assoc, $mapping);

            // Limpieza/normalización
            $assoc = self::sanitize_values($assoc, $decimal, $date_format);

            if (!$dry_run) {
                $res = self::persist_row($target, $assoc, $mode);
                if ($res === true) $ok++; else $err++;
            } else {
                $ok++;
            }

            $read_rows++;
            if ($max_rows > 0 && $read_rows >= $max_rows) break;
        }

        fclose($fh);

        $msg = sprintf(__('Importación avanzada finalizada (%s).', 'midas-rrhh'), $target);
        if ($dry_run) $msg = __('Simulación OK (no se guardó nada).', 'midas-rrhh');

        self::redirect_msg($msg, $ok, $err);
    }

    /* ============================================================
     * EXPORTAR
     * ============================================================ */
    public static function handle_export() {
        if (!current_user_can('manage_options')) wp_die('Permisos insuficientes');
        check_admin_referer('midas_ie_export');

        global $wpdb;

        $target   = sanitize_text_field($_POST['target'] ?? 'empleados');
        $download = sanitize_text_field($_POST['download'] ?? 'data');

        $filename = $target . '-' . date('Ymd-His') . '.csv';

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        header('Pragma: no-cache');
        header('Expires: 0');

        $out = fopen('php://output', 'w');

        // BOM UTF-8
        fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));

        if ($target === 'empleados') {
            $headers = ['id','nombre','apellido','dni','cuil','email','telefono','fecha_nacimiento','direccion','estado_civil','cv_id','fecha_inicio_laboral','activo','created_at','updated_at','created_by','updated_by'];
            fputcsv($out, $headers);

            if ($download === 'data') {
                $rows = $wpdb->get_results("SELECT ".implode(',', array_map('esc_sql',$headers))." FROM {$wpdb->prefix}midas_empleados", ARRAY_A);
                foreach ($rows as $row) fputcsv($out, $row);
            }
        } else { // recibos
            $headers = ['id','empleado_id','periodo','monto','created_at','created_by'];
            fputcsv($out, $headers);

            if ($download === 'data') {
                $rows = $wpdb->get_results("SELECT ".implode(',', array_map('esc_sql',$headers))." FROM {$wpdb->prefix}midas_recibos", ARRAY_A);
                foreach ($rows as $row) fputcsv($out, $row);
            }
        }

        fclose($out);
        exit;
    }

    /* ============================================================
     * API KEYS
     * ============================================================ */
    public static function handle_api_new_key() {
        if (!current_user_can('manage_options')) wp_die('Permisos insuficientes');
        check_admin_referer('midas_api_new_key');

        $label = sanitize_text_field($_POST['label'] ?? '');

        $keys = get_option('midas_rrhh_api_keys', []);
        if (!is_array($keys)) $keys = [];

        // secreto visible 1 vez aquí y almacenable para "Mostrar clave"
        $raw  = wp_generate_password(40, false, false); // solo alfanumérico
        $kid  = sha1($raw); // id de la fila

        $keys[$kid] = [
            'label'     => $label ?: 'API Key',
            'created'   => date('Y-m-d H:i:s'),
            'last_used' => null,
            'revoked'   => 0,
            'secret'    => $raw, // <--- guardamos la clave para poder revelarla con el botón
        ];

        update_option('midas_rrhh_api_keys', $keys, false);

        // mostramos la clave generada una vez via query param
        $url = add_query_arg(['new_key' => rawurlencode($raw)], admin_url('admin.php?page=midas-rrhh-import-export'));
        wp_safe_redirect($url);
        exit;
    }

    public static function handle_api_del_key() {
        if (!current_user_can('manage_options')) wp_die('Permisos insuficientes');
        check_admin_referer('midas_api_del_key');

        $kid  = sanitize_text_field($_POST['kid'] ?? '');
        $keys = get_option('midas_rrhh_api_keys', []);
        if (isset($keys[$kid])) {
            $keys[$kid]['revoked'] = 1;
            update_option('midas_rrhh_api_keys', $keys, false);
        }

        wp_safe_redirect(admin_url('admin.php?page=midas-rrhh-import-export'));
        exit;
    }

    /** Botón “Mostrar clave” -> redirige con show_kid */
    public static function handle_api_show_key() {
        if (!current_user_can('manage_options')) wp_die('Permisos insuficientes');
        check_admin_referer('midas_api_show_key');

        $kid = sanitize_text_field($_POST['kid'] ?? '');
        // no exponemos la clave en la URL; solo el id y la plantila la toma del option
        $url = add_query_arg(['show_kid' => rawurlencode($kid)], admin_url('admin.php?page=midas-rrhh-import-export'));
        wp_safe_redirect($url);
        exit;
    }

    /* ============================================================
     * HELPERS
     * ============================================================ */

    /** Lee CSV/XLS/XLSX devolviendo array de filas (cada fila = array) */
    private static function read_any_spreadsheet(string $tmp_file) : ?array {
        $ext = strtolower(pathinfo($tmp_file, PATHINFO_EXTENSION));
        if (class_exists('\PhpOffice\PhpSpreadsheet\IOFactory')) {
            try {
                $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile($tmp_file);
                $reader->setReadDataOnly(true);
                $spreadsheet = $reader->load($tmp_file);
                $sheet = $spreadsheet->getActiveSheet();
                $rows = [];
                foreach ($sheet->getRowIterator() as $row) {
                    $line = [];
                    $cellIterator = $row->getCellIterator();
                    $cellIterator->setIterateOnlyExistingCells(false);
                    foreach ($cellIterator as $cell) $line[] = trim((string)$cell->getFormattedValue());
                    if (!empty(array_filter($line, fn($v)=>$v!==''))) $rows[] = $line;
                }
                return $rows;
            } catch (\Throwable $e) {
                // fallback CSV
            }
        }
        // CSV plano
        $out = [];
        $fh = fopen($tmp_file, 'r');
        if (!$fh) return null;
        while (($row = fgetcsv($fh)) !== false) {
            if (!empty(array_filter($row, fn($v)=>$v!==null && $v!==''))) $out[] = array_map('trim', $row);
        }
        fclose($fh);
        return $out ?: null;
    }

    private static function normalize_header($h) {
        $h = trim((string)$h);
        $h = strtolower($h);
        $h = preg_replace('/\s+/', '_', $h);
        $h = preg_replace('/[^a-z0-9_]/', '', $h);
        return $h ?: 'col';
    }

    private static function row_to_assoc(array $headers, array $row) : array {
        $assoc = [];
        foreach ($headers as $i => $key) {
            $assoc[$key] = isset($row[$i]) ? trim((string)$row[$i]) : '';
        }
        return $assoc;
    }

    private static function apply_mapping(array $assoc, array $mapping) : array {
        if (!$mapping) return $assoc;

        $normalized = [];
        $lower_assoc = [];
        foreach ($assoc as $k=>$v) $lower_assoc[self::normalize_header($k)] = $v;

        foreach ($mapping as $dest => $sources) {
            $val = null;
            if (is_string($sources)) $sources = [$sources];
            if (!is_array($sources)) $sources = [];
            array_unshift($sources, $dest); // fallback: el propio nombre

            foreach ($sources as $candidate) {
                $ck = self::normalize_header($candidate);
                if (array_key_exists($ck, $lower_assoc)) {
                    $val = $lower_assoc[$ck];
                    break;
                }
            }
            $normalized[$dest] = $val;
        }

        foreach ($assoc as $k=>$v) {
            if (!array_key_exists($k, $normalized)) $normalized[$k] = $v;
        }

        return $normalized;
    }

    private static function sanitize_values(array $assoc, string $decimal, string $date_format) : array {
        foreach ($assoc as $k=>$v) {
            $val = $v;

            if (is_string($val)) {
                $l = strtolower($val);
                if (in_array($l, ['true','sí','si','1','yes','activo','activa'], true)) {
                    $val = 1;
                } elseif (in_array($l, ['false','no','0','inactivo','inactiva'], true)) {
                    $val = 0;
                }
            }

            if (is_string($val) && preg_match('/^[0-9\.,]+$/', $val)) {
                if ($decimal === ',') {
                    $tmp = str_replace('.', '', $val);
                    $tmp = str_replace(',', '.', $tmp);
                    if (is_numeric($tmp)) $val = $tmp;
                } else {
                    $tmp = str_replace(',', '', $val);
                    if (is_numeric($tmp)) $val = $tmp;
                }
            }

            if (is_string($val) && preg_match('/[\/\-\:]/', $val)) {
                $dt = \DateTime::createFromFormat($date_format, $val);
                if ($dt instanceof \DateTime) {
                    $val = $dt->format('Y-m-d H:i:s');
                } else {
                    $ts = strtotime($val);
                    if ($ts) $val = date('Y-m-d H:i:s', $ts);
                }
            }

            $assoc[$k] = $val;
        }
        return $assoc;
    }

    /** Inserta/actualiza según destino */
    private static function persist_row(string $target, array $data, string $mode='insert') {
        global $wpdb;

        try {
            if ($target === 'empleados') {
                $table = $wpdb->prefix . 'midas_empleados';

                $row = [
                    'nombre'               => $data['nombre'] ?? '',
                    'apellido'             => $data['apellido'] ?? '',
                    'dni'                  => $data['dni'] ?? '',
                    'cuil'                 => $data['cuil'] ?? '',
                    'email'                => $data['email'] ?? '',
                    'telefono'             => $data['telefono'] ?? '',
                    'fecha_nacimiento'     => self::to_date($data['fecha_nacimiento'] ?? null),
                    'direccion'            => $data['direccion'] ?? '',
                    'estado_civil'         => $data['estado_civil'] ?? '',
                    'cv_id'                => $data['cv_id'] ?? '',
                    'fecha_inicio_laboral' => self::to_date($data['fecha_inicio_laboral'] ?? null, 'Y-m-d'),
                    'activo'               => isset($data['activo']) ? (int)!!$data['activo'] : 1,
                    'updated_at'           => current_time('mysql'),
                    'updated_by'           => get_current_user_id(),
                ];

                if ($mode === 'upsert' && !empty($row['dni'])) {
                    $id = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE dni=%s", $row['dni']));
                    if ($id) {
                        $wpdb->update($table, $row, ['id'=>$id]);
                        return true;
                    }
                }

                $row['created_at'] = current_time('mysql');
                $row['created_by'] = get_current_user_id();
                $res = $wpdb->insert($table, $row);
                return $res !== false;

            } else { // recibos
                $table = $wpdb->prefix . 'midas_recibos';

                $row = [
                    'empleado_id' => isset($data['empleado_id']) ? (int)$data['empleado_id'] : 0,
                    'periodo'     => $data['periodo'] ?? '',
                    'monto'       => isset($data['monto']) && is_numeric($data['monto']) ? (float)$data['monto'] : 0,
                    'updated_at'  => current_time('mysql'),
                    'updated_by'  => get_current_user_id(),
                ];

                if ($mode === 'upsert' && $row['empleado_id'] && $row['periodo']) {
                    $id = $wpdb->get_var($wpdb->prepare(
                        "SELECT id FROM $table WHERE empleado_id=%d AND periodo=%s",
                        $row['empleado_id'], $row['periodo']
                    ));
                    if ($id) {
                        $wpdb->update($table, $row, ['id'=>$id]);
                        return true;
                    }
                }

                $row['created_at'] = current_time('mysql');
                $row['created_by'] = get_current_user_id();
                $res = $wpdb->insert($table, $row);
                return $res !== false;
            }

        } catch (\Throwable $e) {
            error_log('[MidasRRHH][Import] '.$e->getMessage());
            return false;
        }
    }

    private static function to_date($val, $format='Y-m-d') {
        if (!$val) return null;
        if ($val instanceof \DateTime) return $val->format($format);
        if (preg_match('/^\d{4}-\d{2}-\d{2}/', (string)$val)) return substr((string)$val, 0, strlen($format));
        $ts = strtotime((string)$val);
        return $ts ? date($format, $ts) : null;
    }

    private static function unescape($s) {
        $s = (string)$s;
        $s = str_replace(['\\t','\\n','\\r','\\0'], ["\t","\n","\r","\0"], $s);
        return $s;
    }

    private static function redirect_msg(string $msg, int $ok=0, int $err=0) {
        $args = [
            'midas_msg' => rawurlencode($msg),
            'ok'  => $ok,
            'err' => $err,
        ];
        wp_safe_redirect( add_query_arg($args, admin_url('admin.php?page=midas-rrhh-import-export')) );
        exit;
    }
}
