<?php
namespace MidasRRHH\Controllers;

use MidasRRHH\Models\Ticket_Model;

if (!defined('ABSPATH')) exit;

class Ticket_Controller {
    private $ticket_model;

    public function __construct() {
        $this->ticket_model = new Ticket_Model();
    }

    /**
     * Crear un nuevo ticket en wp_midas_tickets.
     * - Saneo únicamente aquí (input crudo del form).
     * - Usuarios comunes: estado=pendiente y destinatario por defecto (si existe).
     */
    public function crear_ticket($user_id, $asunto, $mensaje, $estado = 'pendiente', $destinatario_id = 0) {
        // Saneo PERMISIVO (no destruye contenido válido)
        $asunto  = $this->clean_subject($asunto);
        $mensaje = $this->clean_message($mensaje);

        // Validación mínima de contenido
        if (empty($user_id) || $asunto === '' || $mensaje === '') {
            return new \WP_Error('faltan_datos', __('Todos los campos son obligatorios.', 'midas-rrhh'));
        }

        // Permisos
        $is_admin = current_user_can('manage_options')
                 || current_user_can('administrator')
                 || current_user_can('rrhh_admin');

        // Normaliza estado
        $allowed = ['pendiente','enviado','respondido','rechazado'];
        $estado  = strtolower((string)$estado);
        if (!in_array($estado, $allowed, true)) $estado = 'pendiente';

        if ($is_admin) {
            $destinatario_id = absint($destinatario_id);
        } else {
            $estado          = 'pendiente';
            $destinatario_id = $this->resolve_default_rrhh_user_id();
        }

        // Crear (proxy tolerante a la firma del modelo)
        $result = $this->model_crear_proxy($user_id, $asunto, $mensaje, $estado, $destinatario_id);

        if (!is_wp_error($result) && $result) {
            $this->maybe_notify_on_creacion($estado, $destinatario_id, $asunto, $mensaje, $user_id);
        }

        return $result;
    }

    /* ======================== LECTURAS – SOLO wp_midas_tickets ======================== */

    /** Alias usado por el Frontend (lo llama así). */
    public function obtener_tickets_empleado($empleado_user_id) {
        return $this->obtener_tickets_usuario($empleado_user_id);
    }

    public function obtener_tickets_usuario($user_id) {
        if (empty($user_id)) return [];
        global $wpdb;
        $t = $wpdb->prefix . 'midas_tickets';
        $sql = $wpdb->prepare(
            "SELECT id, user_id, destinatario_id, asunto, mensaje, estado, fecha_creacion, fecha_respuesta,
                    admin_id, admin_nombre, respuesta, motivo_rechazo, visto
             FROM $t
             WHERE user_id = %d OR destinatario_id = %d
             ORDER BY id DESC",
            absint($user_id), absint($user_id)
        );
        $rows = $wpdb->get_results($sql);
        return is_array($rows) ? $rows : [];
    }

    /** Útil si se necesita un ticket puntual. */
    public function obtener_ticket($ticket_id, $user_id = null) {
        global $wpdb;
        $t = $wpdb->prefix . 'midas_tickets';
        $ticket_id = absint($ticket_id);
        if ($user_id) {
            $user_id = absint($user_id);
            $sql = $wpdb->prepare(
                "SELECT id, user_id, destinatario_id, asunto, mensaje, estado, fecha_creacion, fecha_respuesta,
                        admin_id, admin_nombre, respuesta, motivo_rechazo, visto
                 FROM $t
                 WHERE id = %d AND (user_id = %d OR destinatario_id = %d)
                 LIMIT 1",
                $ticket_id, $user_id, $user_id
            );
        } else {
            $sql = $wpdb->prepare(
                "SELECT id, user_id, destinatario_id, asunto, mensaje, estado, fecha_creacion, fecha_respuesta,
                        admin_id, admin_nombre, respuesta, motivo_rechazo, visto
                 FROM $t
                 WHERE id = %d
                 LIMIT 1",
                $ticket_id
            );
        }
        return $wpdb->get_row($sql);
    }

    public function obtener_todos($estado = null) {
        if (!current_user_can('manage_options') && !current_user_can('administrator') && !current_user_can('rrhh_admin')) {
            return [];
        }
        global $wpdb;
        $t = $wpdb->prefix . 'midas_tickets';
        if ($estado !== null && $estado !== '') {
            $sql = $wpdb->prepare(
                "SELECT id, user_id, destinatario_id, asunto, mensaje, estado, fecha_creacion, fecha_respuesta,
                        admin_id, admin_nombre, respuesta, motivo_rechazo, visto
                 FROM $t WHERE estado = %s ORDER BY id DESC",
                (string)$estado
            );
        } else {
            $sql = "SELECT id, user_id, destinatario_id, asunto, mensaje, estado, fecha_creacion, fecha_respuesta,
                           admin_id, admin_nombre, respuesta, motivo_rechazo, visto
                    FROM $t ORDER BY id DESC";
        }
        $rows = $wpdb->get_results($sql);
        return is_array($rows) ? $rows : [];
    }

    public function obtener_todos_los_tickets($estado = null) { return $this->obtener_todos($estado); }

    /* ======================== ACCIONES ADMIN ======================== */

    public function responder_ticket($ticket_id, $respuesta) {
        if (
            !current_user_can('manage_options') &&
            !current_user_can('administrator') &&
            !current_user_can('rrhh_admin') &&
            !current_user_can('rrhh_gestor')
        ) return new \WP_Error('sin_permiso', __('Sin permisos para responder tickets.', 'midas-rrhh'));

        $admin_id        = get_current_user_id();
        $admin_user      = get_userdata($admin_id);
        $admin_nombre    = $admin_user ? $admin_user->display_name : '';
        $fecha_respuesta = current_time('mysql');

        $respuesta = $this->clean_message($respuesta);
        if ($respuesta === '') return new \WP_Error('faltan_datos', __('La respuesta es obligatoria.', 'midas-rrhh'));

        return $this->ticket_model->responder($ticket_id, $respuesta, $admin_id, $admin_nombre, $fecha_respuesta);
    }

    public function rechazar_ticket($ticket_id, $motivo) {
        if (
            !current_user_can('manage_options') &&
            !current_user_can('administrator') &&
            !current_user_can('rrhh_admin') &&
            !current_user_can('rrhh_gestor')
        ) return new \WP_Error('sin_permiso', __('Sin permisos para rechazar tickets.', 'midas-rrhh'));

        $admin_id        = get_current_user_id();
        $admin_user      = get_userdata($admin_id);
        $admin_nombre    = $admin_user ? $admin_user->display_name : '';
        $fecha_respuesta = current_time('mysql');

        $motivo = $this->clean_message($motivo);
        if ($motivo === '') return new \WP_Error('faltan_datos', __('Debes indicar un motivo de rechazo.', 'midas-rrhh'));

        return $this->ticket_model->rechazar($ticket_id, $motivo, $admin_id, $admin_nombre, $fecha_respuesta);
    }

    /* ======================== ELIMINACIÓN ======================== */

    public function eliminar_ticket($ticket_id, $user_id = null) {
        if ( current_user_can('manage_options') || current_user_can('administrator') || current_user_can('rrhh_admin') || current_user_can('rrhh_gestor') ) {
            return $this->ticket_model->eliminar($ticket_id);
        }
        return $this->ticket_model->eliminar($ticket_id, $user_id);
    }

    /* ======================== Proxy tolerante a firma ======================== */

    private function model_crear_proxy($user_id, $asunto, $mensaje, $estado = 'pendiente', $destinatario_id = 0) {
        if (!method_exists($this->ticket_model, 'crear')) return new \WP_Error('model_missing', __('No se encontró el método crear() en Ticket_Model.', 'midas-rrhh'));
        try {
            $ref  = new \ReflectionMethod($this->ticket_model, 'crear');
            $num  = $ref->getNumberOfParameters();
            $pars = $ref->getParameters();
        } catch (\ReflectionException $e) { $num = 3; $pars = []; }

        $args = [$user_id, $asunto, $mensaje];

        if ($num === 3) return $this->ticket_model->crear(...$args);

        if ($num === 4) {
            $p4 = isset($pars[3]) ? strtolower($pars[3]->getName() ?? '') : '';
            $args[] = (strpos($p4,'dest')!==false) ? $destinatario_id : $estado;
            return $this->ticket_model->crear(...$args);
        }

        $p4 = isset($pars[3]) ? strtolower($pars[3]->getName() ?? '') : '';
        $p5 = isset($pars[4]) ? strtolower($pars[4]->getName() ?? '') : '';
        if ((strpos($p4,'dest')!==false && strpos($p5,'est')!==false) || (strpos($p4,'dest')!==false && strpos($p5,'state')!==false)) {
            $args[] = $destinatario_id; $args[] = $estado;
        } else { $args[] = $estado; $args[] = $destinatario_id; }
        return $this->ticket_model->crear(...$args);
    }

    /* ======================== Notificaciones ======================== */

    private function maybe_notify_on_creacion($estado, $destinatario_id, $asunto, $mensaje, $remitente_user_id) {
        if (current_user_can('manage_options') && $estado === 'enviado' && $destinatario_id > 0) {
            $this->mail_ticket_enviado($destinatario_id, $asunto, $mensaje, $remitente_user_id); return;
        }
        if ($estado === 'pendiente') $this->mail_ticket_creado_a_gestores($asunto, $mensaje, $remitente_user_id);
    }

    private function mail_ticket_enviado($destinatario_user_id, $asunto, $mensaje, $remitente_user_id) {
        $dest_user = get_userdata(absint($destinatario_user_id));
        if (!$dest_user || empty($dest_user->user_email)) return;
        $rem = get_userdata(absint($remitente_user_id));
        $remitente_nombre = $rem ? $rem->display_name : __('RRHH', 'midas-rrhh');
        $panel_url = $this->get_panel_url();
        $site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        $subject = sprintf('[%s] Nueva instancia para vos', $site_name);
        $body  = "Hola {$dest_user->display_name},\n\nTe enviaron una nueva instancia.\n\nAsunto: {$asunto}\nMensaje:\n{$mensaje}\n\nRemitente: {$remitente_nombre}\n";
        if ($panel_url) $body .= "Podés verla acá: {$panel_url}\n\n";
        $body .= "— {$site_name}\n";
        $this->mail_send($dest_user->user_email, $subject, $body);
    }

    private function mail_ticket_creado_a_gestores($asunto, $mensaje, $remitente_user_id) {
        $settings = get_option('midas_rrhh_smtp_settings', []);
        $to = isset($settings['notify_gestores']) ? trim((string)$settings['notify_gestores']) : '';
        if (!$to) return;
        $rem = get_userdata(absint($remitente_user_id));
        $remitente_nombre = $rem ? $rem->display_name : __('Usuario', 'midas-rrhh');
        $panel_url = $this->get_panel_url();
        $site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        $subject = sprintf('[%s] Nueva instancia creada (pendiente)', $site_name);
        $body  = "Se creó una nueva instancia.\n\nRemitente: {$remitente_nombre}\nAsunto: {$asunto}\nMensaje:\n{$mensaje}\n\n";
        if ($panel_url) $body .= "Panel: {$panel_url}\n\n";
        $body .= "— {$site_name}\n";
        $this->mail_send($to, $subject, $body);
    }

    private function mail_send($to, $subject, $body) {
        if (empty($to)) return;
        $settings   = get_option('midas_rrhh_smtp_settings', []);
        $from_email = !empty($settings['from_email']) ? $settings['from_email'] : get_option('admin_email');
        $from_name  = !empty($settings['from_name'])  ? $settings['from_name']  : get_bloginfo('name');
        $headers = ['Content-Type: text/plain; charset=UTF-8'];
        if ($from_email) $headers[] = 'From: ' . $from_name . ' <' . $from_email . '>';
        try { @wp_mail($to, $subject, $body, $headers); } catch (\Throwable $e) {}
    }

    private function get_panel_url() {
        $page_id = absint(get_option('midas_rrhh_pagina_mi_perfil_id'));
        if ($page_id) { $url = get_permalink($page_id); if ($url) return $url; }
        return home_url('/mi-perfil');
    }

    private function resolve_default_rrhh_user_id() : int {
        $opt = absint(get_option('midas_rrhh_destinatario_default_user_id'));
        if ($opt > 0 && get_userdata($opt)) return $opt;
        $q = new \WP_User_Query(['number'=>1,'role__in'=>['rrhh_admin','rrhh_gestor','administrator'],'orderby'=>'ID','order'=>'ASC','fields'=>['ID']]);
        $users = $q->get_results();
        return (!empty($users) && !empty($users[0]->ID)) ? (int)$users[0]->ID : 0;
    }

    /* ======================== Saneo simple ======================== */

    private function clean_subject($s) {
        $s = (string) (function_exists('wp_unslash') ? wp_unslash($s) : $s);
        if (class_exists('\Normalizer')) $s = \Normalizer::normalize($s, \Normalizer::FORM_KC);
        $s = wp_strip_all_tags($s);
        // Quitar controles (no espacios)
        $s = preg_replace('/[\x00-\x1F\x7F]/u', '', $s);
        // Colapsar espacios internos y recortar
        $s = preg_replace('/\s+/u', ' ', $s);
        return trim($s);
    }

    private function clean_message($s) {
        $s = (string) (function_exists('wp_unslash') ? wp_unslash($s) : $s);
        if (class_exists('\Normalizer')) $s = \Normalizer::normalize($s, \Normalizer::FORM_KC);
        $s = wp_strip_all_tags($s, true); // preserva saltos de línea
        // permitir \n y \r, quitar el resto de controles
        $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $s);
        // normalizar \r\n → \n
        $s = preg_replace("/\r\n?/", "\n", $s);
        return trim($s);
    }
}
