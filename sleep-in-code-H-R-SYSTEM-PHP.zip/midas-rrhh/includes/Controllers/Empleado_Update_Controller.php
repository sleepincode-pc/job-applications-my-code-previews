<?php
if (!defined('ABSPATH')) exit;

require_once MIDAS_RRHH_PATH . 'models/Empleado_Model.php';

class Empleado_Update_Controller {
    private $model;

    public function __construct() {
        $this->model = new Empleado_Model();

        // AJAX (admin-ajax.php)
        add_action('wp_ajax_midas_editar_empleado', [$this, 'editar_empleado_ajax']);

        // Formulario tradicional (no AJAX)
        add_action('admin_post_midas_editar_empleado', [$this, 'editar_empleado_form']);
    }

    // =============== AJAX ===============
    public function editar_empleado_ajax() {
        // Validación de nonce
        if (empty($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'midas_empleados_nonce')) {
            wp_send_json_error(['message' => 'Nonce inválido.']);
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('No tienes permiso.', 'midas-rrhh')]);
        }

        $id = intval($_POST['id'] ?? $_POST['empleado_id'] ?? 0);
        if (!$id) {
            wp_send_json_error(['message' => 'ID de empleado inválido.']);
        }

        // Datos sanitizados
        $datos = [
            'nombre'           => sanitize_text_field($_POST['nombre'] ?? ''),
            'apellido'         => sanitize_text_field($_POST['apellido'] ?? ''),
            'dni'              => sanitize_text_field($_POST['dni'] ?? ''),
            'cuil'             => sanitize_text_field($_POST['cuil'] ?? ''),
            'email'            => sanitize_email($_POST['email'] ?? ''),
            'telefono'         => sanitize_text_field($_POST['telefono'] ?? ''),
            'fecha_nacimiento' => sanitize_text_field($_POST['fecha_nacimiento'] ?? ''),
            'direccion'        => sanitize_text_field($_POST['direccion'] ?? ''),
            'estado_civil'     => sanitize_text_field($_POST['estado_civil'] ?? ''),
            'fecha_inicio_laboral' => sanitize_text_field($_POST['fecha_inicio_laboral'] ?? ''),
        ];

        // Manejar la subida del archivo si existe
        if (!empty($_FILES['foto']['name']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';

            $attachment_id = media_handle_upload('foto', 0);

            if (is_wp_error($attachment_id)) {
                wp_send_json_error(['message' => 'Error al subir la imagen: ' . $attachment_id->get_error_message()]);
            }

            $datos['foto_id'] = $attachment_id;
        } elseif (!empty($_POST['foto_id_actual'])) {
            // Mantener la foto actual si no se subió una nueva
            $datos['foto_id'] = intval($_POST['foto_id_actual']);
        }

        $ok = $this->model->actualizar_empleado($id, $datos);

        if ($ok) {
            $empleado = $this->model->get($id);
            $empleado_data = [
                'id' => $empleado->id,
                'nombre' => $empleado->nombre,
                'apellido' => $empleado->apellido,
                'dni' => $empleado->dni,
                'cuil' => $empleado->cuil,
                'email' => $empleado->email,
                'telefono' => $empleado->telefono,
                'fecha_nacimiento' => $empleado->fecha_nacimiento,
                'direccion' => $empleado->direccion,
                'estado_civil' => $empleado->estado_civil,
                'fecha_inicio_laboral' => $empleado->fecha_inicio_laboral,
                'foto_id' => $empleado->foto_id,
                'foto_url' => $empleado->foto_id ? wp_get_attachment_url($empleado->foto_id) : '',
            ];
            wp_send_json_success(['empleado' => $empleado_data]);
        } else {
            wp_send_json_error(['message' => 'Error al guardar el empleado.']);
        }
    }

    // =============== FORMULARIO CLÁSICO ===============
    public function editar_empleado_form() {
        if (!current_user_can('manage_options')) {
            wp_die(__('No tienes permiso para realizar esta acción.', 'midas-rrhh'));
        }

        // Validar nonce
        check_admin_referer('midas_empleados_nonce');

        $id = intval($_POST['empleado_id']);
        if (!$id) {
            wp_die(__('ID de empleado inválido.', 'midas-rrhh'));
        }

        $datos = [
            'nombre'   => sanitize_text_field($_POST['nombre']),
            'apellido' => sanitize_text_field($_POST['apellido']),
            'dni'      => sanitize_text_field($_POST['dni']),
            'cuil'     => sanitize_text_field($_POST['cuil']),
            // Otros campos sanitizados aquí si se usan
        ];

        $this->model->actualizar_empleado($id, $datos);

        wp_redirect(admin_url('admin-ajax.php?page=midas_rrhh_empleados&edit_success=1'));
        exit;
    }
}
