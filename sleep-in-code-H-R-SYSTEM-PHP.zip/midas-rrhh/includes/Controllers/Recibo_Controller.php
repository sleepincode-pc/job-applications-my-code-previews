<?php
namespace MidasRRHH\Controllers;

use MidasRRHH\Models\Recibo_Model;
use MidasRRHH\Models\Empleado_Model;
use MidasRRHH\Core\Security;
use MidasRRHH\Core\Notificaciones;
use WP_Error;

if (!defined('ABSPATH')) exit;

class Recibo_Controller {
    private $recibo_model;
    private $empleado_model;
    private $security;
    private $notificaciones;

    public function __construct() {
        $this->recibo_model   = new Recibo_Model();
        $this->empleado_model = new Empleado_Model();
        $this->security       = new Security();
        $this->notificaciones = new Notificaciones();

        // AJAX search por nombre/dni/cuil
        add_action('wp_ajax_midas_buscar_recibos', [$this, 'ajax_buscar_recibos']);

        // IMPORTANTE:
        // Los hooks AJAX de tabla/form se registran en Ajax_Handler para evitar duplicados.
        // (midas_obtener_recibos_ajax, midas_crear_recibo_frontend, midas_eliminar_recibo)
    }

    // --- AJAX: Traer recibos (admin RRHH ve todos; empleado común ve los propios) ---
    public static function obtener_recibos_ajax() {
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'No autorizado'], 401);
        }

        $current_user     = wp_get_current_user();
        $empleado_model   = new Empleado_Model();

        $is_manager = current_user_can('read_private_midas_recibos')
            || current_user_can('rrhh_gestor')
            || current_user_can('rrhh_admin')
            || current_user_can('administrator');

        // Parámetro de búsqueda opcional (desde AJAX)
        $buscar = isset($_POST['buscar_recibo']) ? sanitize_text_field(wp_unslash($_POST['buscar_recibo'])) : '';
        $buscar_norm = function_exists('mb_strtoupper') ? mb_strtoupper($buscar, 'UTF-8') : strtoupper($buscar);

        $recibo_model = new Recibo_Model();
        $recibos      = [];

        if ($is_manager) {
            // RRHH/Admin: ve TODOS, con filtro sobre datos del empleado
            $recibos_data = $recibo_model->get_all();
            foreach ($recibos_data as $recibo) {
                $emp = $empleado_model->get_by_id_con_area_y_tarea($recibo->empleado_id);
                if (!$emp) continue;

                if ($buscar_norm !== '') {
                    $F = static function($v) {
                        $s = (string)($v ?? '');
                        return function_exists('mb_strtoupper') ? mb_strtoupper($s, 'UTF-8') : strtoupper($s);
                    };
                    $encontrado =
                        (stripos($F($emp->nombre),                $buscar_norm) !== false) ||
                        (stripos($F($emp->apellido),              $buscar_norm) !== false) ||
                        (stripos($F($emp->dni),                   $buscar_norm) !== false) ||
                        (stripos($F($emp->cuil),                  $buscar_norm) !== false) ||
                        (stripos($F($emp->tarea_nombre ?? ''),    $buscar_norm) !== false) ||
                        (stripos($F($emp->area_nombre  ?? ''),    $buscar_norm) !== false);
                    if (!$encontrado) continue;
                }

                $recibos[] = [
                    'id'              => (int)$recibo->id,
                    'empleado_id'     => (int)$recibo->empleado_id,
                    'empleado_nombre' => trim(($emp->nombre ?? '') . ' ' . ($emp->apellido ?? '')),
                    'periodo'         => (string)($recibo->periodo ?? ''),
                    'monto'           => (float)($recibo->monto ?? 0),
                    'detalles'        => (string)($recibo->detalles ?? ''),
                    'archivo_id'      => (int)($recibo->archivo_id ?? 0),
                ];
            }
        } else {
            // Empleado común: solo SUS recibos
            $current_empleado = $empleado_model->get_by_user_id($current_user->ID);
            if (!$current_empleado) {
                wp_send_json_error(['message' => 'Empleado no encontrado.'], 400);
            }

            $recibos_data = $recibo_model->get_by_empleado($current_empleado->id);
            // Para búsqueda de empleado, tiene sentido filtrar por periodo/detalles
            $F = static function($v) {
                $s = (string)($v ?? '');
                return function_exists('mb_strtoupper') ? mb_strtoupper($s, 'UTF-8') : strtoupper($s);
            };

            foreach ($recibos_data as $recibo) {
                if ($buscar_norm !== '') {
                    $match = (stripos($F($recibo->periodo ?? ''), $buscar_norm) !== false)
                          || (stripos($F($recibo->detalles ?? ''), $buscar_norm) !== false);
                    if (!$match) continue;
                }

                $recibos[] = [
                    'id'              => (int)$recibo->id,
                    'empleado_id'     => (int)$recibo->empleado_id,
                    'empleado_nombre' => trim(($current_empleado->nombre ?? '') . ' ' . ($current_empleado->apellido ?? '')),
                    'periodo'         => (string)($recibo->periodo ?? ''),
                    'monto'           => (float)($recibo->monto ?? 0),
                    'detalles'        => (string)($recibo->detalles ?? ''),
                    'archivo_id'      => (int)($recibo->archivo_id ?? 0),
                ];
            }
        }

        wp_send_json_success(['recibos' => $recibos]);
    }

    // --- AJAX: Crear nuevo recibo (frontend) ---
    public static function crear_recibo_frontend() {
        // Alinear con la vista (input hidden name="nonce" y action 'midas_recibos_nonce')
        if (empty($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'midas_recibos_nonce')) {
            wp_send_json_error(['message' => 'Nonce inválido. Intenta refrescar la página.'], 403);
        }
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'Debes iniciar sesión para realizar esta acción'], 401);
        }

        $current_user     = wp_get_current_user();
        $empleado_model   = new Empleado_Model();
        $current_empleado = $empleado_model->get_by_user_id($current_user->ID);

        if (!$current_empleado) {
            wp_send_json_error(['message' => 'Empleado no encontrado.'], 400);
        }

        $empleado_id_post = intval($_POST['empleado_id'] ?? 0);
        if (!$empleado_id_post) {
            wp_send_json_error(['message' => 'Empleado no seleccionado.'], 400);
        }
        $empleado_destino = $empleado_model->get($empleado_id_post);
        if (!$empleado_destino) {
            wp_send_json_error(['message' => 'Empleado seleccionado no existe.'], 400);
        }

        // Permisos: RRHH/admin o, si no, solo si sube para sí mismo
        $can_publish = current_user_can('publish_midas_recibos')
                    || current_user_can('rrhh_gestor')
                    || current_user_can('rrhh_admin')
                    || current_user_can('administrator');

        if (!$can_publish && $empleado_id_post !== (int)$current_empleado->id) {
            wp_send_json_error(['message' => 'No tienes permisos para cargar recibos para otros empleados.'], 403);
        }

        $periodo  = sanitize_text_field($_POST['periodo'] ?? '');
        $monto    = floatval($_POST['monto'] ?? 0);
        $detalles = sanitize_textarea_field($_POST['detalles'] ?? '');

        if ($periodo === '' || $monto <= 0 || empty($_FILES['archivo_pdf'])) {
            wp_send_json_error(['message' => 'Todos los campos son obligatorios y el monto debe ser mayor a 0.'], 400);
        }

        $archivo_pdf = $_FILES['archivo_pdf'];
        if (!isset($archivo_pdf['error']) || $archivo_pdf['error'] !== UPLOAD_ERR_OK) {
            wp_send_json_error(['message' => 'Error al subir el archivo.'], 400);
        }

        $filetype = wp_check_filetype_and_ext($archivo_pdf['tmp_name'], $archivo_pdf['name']);
        if (($filetype['ext'] ?? '') !== 'pdf' || ($filetype['type'] ?? '') !== 'application/pdf') {
            wp_send_json_error(['message' => 'El archivo debe ser un PDF válido.'], 400);
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        $uploaded = wp_handle_upload($archivo_pdf, ['test_form' => false]);
        if (isset($uploaded['error'])) {
            wp_send_json_error(['message' => 'Error al subir el archivo: ' . $uploaded['error']], 400);
        }

        // Crear attachment
        $attachment = [
            'post_mime_type' => $uploaded['type'],
            'post_title'     => basename($uploaded['file']),
            'post_content'   => '',
            'post_status'    => 'inherit',
        ];
        $archivo_id = wp_insert_attachment($attachment, $uploaded['file']);

        require_once ABSPATH . 'wp-admin/includes/image.php';
        wp_update_attachment_metadata($archivo_id, wp_generate_attachment_metadata($archivo_id, $uploaded['file']));

        // Guardar recibo
        $data = [
            'empleado_id' => $empleado_id_post,
            'periodo'     => $periodo,
            'archivo_id'  => $archivo_id,
            'monto'       => $monto,
            'detalles'    => $detalles,
        ];

        $recibo_model = new Recibo_Model();
        $inserted = $recibo_model->insert($data);

        if (!$inserted || is_wp_error($inserted)) {
            if (!is_wp_error($archivo_id) && $archivo_id) {
                wp_delete_attachment($archivo_id, true);
            }
            wp_send_json_error(['message' => is_wp_error($inserted) ? $inserted->get_error_message() : 'Error al guardar el recibo'], 400);
        }

        if (function_exists('midas_clear_recibos_cache')) {
            midas_clear_recibos_cache();
        }

        wp_send_json_success([
            'message'     => 'Recibo cargado correctamente',
            'recibo_id'   => (int)$inserted,
            'archivo_url' => wp_get_attachment_url($archivo_id),
        ]);
    }

    // --- AJAX: Eliminar recibo ---
    public static function eliminar_recibo_ajax() {
        // Alinear con la vista (nonce)
        if (empty($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'midas_recibos_nonce')) {
            wp_send_json_error(['message' => 'Nonce inválido. Intenta refrescar la página.'], 403);
        }
        if (!current_user_can('delete_midas_recibos')) {
            wp_send_json_error(['message' => 'No tienes permisos para realizar esta acción.'], 403);
        }

        $recibo_id = isset($_POST['recibo_id']) ? intval($_POST['recibo_id']) : 0;
        if (!$recibo_id) {
            wp_send_json_error(['message' => 'ID de recibo inválido'], 400);
        }
        $recibo_model = new Recibo_Model();
        $recibo = $recibo_model->get($recibo_id);
        if (!$recibo) {
            wp_send_json_error(['message' => 'Recibo no encontrado'], 404);
        }
        if ($recibo->archivo_id) {
            wp_delete_attachment($recibo->archivo_id, true);
        }
        $result = $recibo_model->delete($recibo_id);
        if (!$result) {
            wp_send_json_error(['message' => 'Error al eliminar el recibo'], 400);
        }
        if (function_exists('midas_clear_recibos_cache')) {
            midas_clear_recibos_cache();
        }
        wp_send_json_success(['message' => 'Recibo eliminado correctamente']);
    }

    // --- Instancia: buscar recibos por nombre, apellido, DNI o CUIL ---
    public function ajax_buscar_recibos() {
        if (!current_user_can('read_private_midas_recibos')) {
            wp_send_json_error(['message' => __('No tienes permisos', 'midas-rrhh')]);
        }

        $termino = isset($_GET['term']) ? sanitize_text_field($_GET['term']) : '';
        if (empty($termino)) {
            wp_send_json_success([]);
        }

        $resultados = $this->recibo_model->buscar_por_empleado_info($termino);

        foreach ($resultados as &$recibo) {
            $recibo->archivo_url        = wp_get_attachment_url($recibo->archivo_id);
            $recibo->periodo_formateado = date_i18n('F Y', strtotime($recibo->periodo));
            $recibo->empleado_nombre    = $recibo->nombre . ' ' . $recibo->apellido;
        }

        wp_send_json_success($resultados);
    }

    // --- Instancia: generar recibo nuevo (no AJAX, para usar en backend) ---
    public function generar_recibo($empleado_id, $periodo, $monto, $file, $detalles = '') {
        if (!current_user_can('publish_midas_recibos')) {
            return new WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }

        $empleado = $this->empleado_model->get($empleado_id);
        if (!$empleado) {
            return new WP_Error('not_found', __('Empleado no encontrado', 'midas-rrhh'));
        }

        $monto = floatval($monto);
        if ($monto <= 0) {
            return new WP_Error('invalid_amount', __('El monto debe ser mayor que cero', 'midas-rrhh'));
        }

        $archivo_id = $this->upload_recibo_file($file);
        if (is_wp_error($archivo_id)) {
            return $archivo_id;
        }

        $recibo_data = [
            'empleado_id' => $empleado_id,
            'periodo'     => $periodo,
            'archivo_id'  => $archivo_id,
            'monto'       => $monto,
            'detalles'    => sanitize_textarea_field($detalles)
        ];

        $recibo_id = $this->recibo_model->insert($recibo_data);

        if (!$recibo_id) {
            wp_delete_attachment($archivo_id, true);
            return new WP_Error('db_error', __('Error al guardar el recibo en la base de datos', 'midas-rrhh'));
        }

        // Notificación a empleado
        $this->notificaciones->enviar_notificacion_nuevo_recibo($empleado_id, $periodo, $archivo_id);

        return $recibo_id;
    }

    // --- Instancia: subir archivo PDF (para backend) ---
    private function upload_recibo_file($file) {
        if (!function_exists('wp_handle_upload')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        $upload_overrides = [
            'test_form' => false,
            'mimes'     => ['pdf' => 'application/pdf']
        ];

        $movefile = wp_handle_upload($file, $upload_overrides);

        if (isset($movefile['error'])) {
            return new WP_Error('upload_error', $movefile['error']);
        }

        $attachment = [
            'post_mime_type' => $movefile['type'],
            'post_title'     => __('Recibo de sueldo ', 'midas-rrhh') . date('Y-m-d'),
            'post_content'   => '',
            'post_status'    => 'private'
        ];

        $attach_id = wp_insert_attachment($attachment, $movefile['file']);

        if (is_wp_error($attach_id)) {
            return $attach_id;
        }

        return $attach_id;
    }

    // --- Instancia: obtener todos los recibos de un empleado ---
    public function obtener_recibos_empleado($empleado_id) {
        $current_user = wp_get_current_user();
        $empleado     = $this->empleado_model->get($empleado_id);

        if (!$empleado) {
            return new WP_Error('not_found', __('Empleado no encontrado', 'midas-rrhh'));
        }

        if ($empleado->user_id != $current_user->ID && !current_user_can('read_private_midas_recibos')) {
            return new WP_Error('forbidden', __('No tienes permisos para ver estos recibos', 'midas-rrhh'));
        }

        $recibos = $this->recibo_model->get_by_empleado($empleado_id);

        foreach ($recibos as $recibo) {
            $recibo->archivo_url        = wp_get_attachment_url($recibo->archivo_id);
            $recibo->periodo_formateado = date_i18n('F Y', strtotime($recibo->periodo));
        }

        return $recibos;
    }

    // --- Instancia: obtener recibo individual por ID ---
    public function obtener_recibo($recibo_id) {
        $recibo = $this->recibo_model->get($recibo_id);
        if (!$recibo) {
            return new WP_Error('not_found', __('Recibo no encontrado', 'midas-rrhh'));
        }

        $current_user = wp_get_current_user();
        $empleado     = $this->empleado_model->get($recibo->empleado_id);

        if ($empleado->user_id != $current_user->ID && !current_user_can('read_private_midas_recibos')) {
            return new WP_Error('forbidden', __('No tienes permisos para ver este recibo', 'midas-rrhh'));
        }

        $recibo->archivo_url        = wp_get_attachment_url($recibo->archivo_id);
        $recibo->periodo_formateado = date_i18n('F Y', strtotime($recibo->periodo));
        $recibo->empleado_nombre    = $empleado->nombre . ' ' . $empleado->apellido;

        return $recibo;
    }

    // --- Instancia: obtener recibos por periodo ---
    public function obtener_recibos_por_periodo($periodo) {
        if (!current_user_can('read_private_midas_recibos')) {
            return new WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }

        $recibos = $this->recibo_model->get_by_periodo($periodo);

        foreach ($recibos as $recibo) {
            $empleado = $this->empleado_model->get($recibo->empleado_id);
            $recibo->empleado_nombre    = $empleado ? $empleado->nombre . ' ' . $empleado->apellido : '';
            $recibo->archivo_url        = wp_get_attachment_url($recibo->archivo_id);
            $recibo->periodo_formateado = date_i18n('F Y', strtotime($recibo->periodo));
        }

        return $recibos;
    }

    // --- Instancia: eliminar recibo (backend, no AJAX) ---
    public function eliminar_recibo($recibo_id) {
        if (!current_user_can('delete_midas_recibos')) {
            return new WP_Error('forbidden', __('No tienes permisos para realizar esta acción', 'midas-rrhh'));
        }

        $recibo = $this->recibo_model->get($recibo_id);
        if (!$recibo) {
            return new WP_Error('not_found', __('Recibo no encontrado', 'midas-rrhh'));
        }

        if ($recibo->archivo_id) {
            wp_delete_attachment($recibo->archivo_id, true);
        }

        $result = $this->recibo_model->delete($recibo_id);
        if (!$result) {
            return new WP_Error('db_error', __('Error al eliminar el recibo', 'midas-rrhh'));
        }

        return true;
    }
}
