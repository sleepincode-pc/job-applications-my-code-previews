<?php
namespace MidasRRHH\Controllers;

if (!defined('ABSPATH')) exit;

use MidasRRHH\Models\Documentacion_Model;

/**
 * Controlador de Documentación con vencimiento
 * - Respuestas con cabeceras de seguridad y sin caché
 * - Mutaciones solo por POST + nonce
 * - Validaciones y saneos de entrada/salida
 * - Lista ordenada del último ingresado al primero
 */
final class Documentacion_Controller {
    private $model;

    public function __construct(){
        $this->model = new Documentacion_Model();
    }

    /* ===================== Registro de endpoints AJAX ===================== */
    public static function register_ajax(){
        // Quitar handlers legacy si existieran
        if (class_exists('\MidasRRHH\Ajax\Ajax_Handler')) {
            remove_action('wp_ajax_midas_docv_listar',  [\MidasRRHH\Ajax\Ajax_Handler::class, 'docv_listar']);
            remove_action('wp_ajax_midas_doc_crear',    [\MidasRRHH\Ajax\Ajax_Handler::class, 'doc_crear']);
            remove_action('wp_ajax_midas_doc_editar',   [\MidasRRHH\Ajax\Ajax_Handler::class, 'doc_editar']);
            remove_action('wp_ajax_midas_doc_eliminar', [\MidasRRHH\Ajax\Ajax_Handler::class, 'doc_eliminar']);
        }

        // Registrar actuales (prioridad 1)
        add_action('wp_ajax_midas_docv_listar',  [self::class, 'listar_docv'], 1);
        add_action('wp_ajax_midas_doc_crear',    [self::class, 'crear'],        1);
        add_action('wp_ajax_midas_doc_editar',   [self::class, 'editar'],       1);
        add_action('wp_ajax_midas_doc_eliminar', [self::class, 'eliminar'],     1);
    }

    /* ===================== Utilidades de seguridad ===================== */
    private static function can_manage(): bool {
        return is_user_logged_in() && current_user_can('edit_midas_empleados');
    }

    private static function verify_nonce_docs(): void {
        $ok = isset($_POST['midas_documentaciones_nonce'])
           && wp_verify_nonce($_POST['midas_documentaciones_nonce'], 'midas_documentaciones_nonce');
        if (!$ok) {
            self::nocache_and_headers();
            wp_send_json_error(['message'=>__('Nonce inválido.','midas-rrhh')], 403);
        }
    }

    private static function require_post(): void {
        $m = strtoupper($_SERVER['REQUEST_METHOD'] ?? '');
        if ($m !== 'POST') {
            self::nocache_and_headers();
            wp_send_json_error(['message'=>__('Método no permitido.','midas-rrhh')], 405);
        }
    }

    private static function nocache_and_headers(): void {
        if (function_exists('nocache_headers')) {
            nocache_headers();
        }
        if (!headers_sent()) {
            header('X-Content-Type-Options: nosniff');
            header('X-Frame-Options: SAMEORIGIN');
            header('Referrer-Policy: no-referrer');
            // Para JSON: política estricta
            header("Content-Security-Policy: default-src 'none'; frame-ancestors 'self'; base-uri 'self'");
        }
    }

    /* ============================ LISTAR ============================ */
    public static function listar_docv(){
        self::nocache_and_headers();
        if (!self::can_manage()) {
            wp_send_json_error(['message'=>__('Sin permiso.','midas-rrhh')],403);
        }

        $m = new Documentacion_Model();

        // Estado desde la UI → modelo (si es "todos", lo omitimos)
        $estado_ui = sanitize_text_field($_REQUEST['estado'] ?? 'todos');
        $map       = ['vigentes'=>'vigente', 'por-vencer'=>'por_vencer', 'vencidos'=>'vencido'];
        $estado    = $map[$estado_ui] ?? null; // null => no filtra

        $per_page = (int)($_REQUEST['per_page'] ?? 10);
        $per_page = min(50, max(5, $per_page));
        $page     = isset($_REQUEST['page']) ? (int)$_REQUEST['page'] : (int)($_REQUEST['paged'] ?? 1);
        $page     = max(1, $page);

        $args = [
            'q'        => sanitize_text_field($_REQUEST['q'] ?? ''),
            'tipo_id'  => isset($_REQUEST['tipo_id']) ? (int)$_REQUEST['tipo_id'] : 0,
            'paged'    => $page,
            'per_page' => $per_page,

            // Pedimos orden “más reciente primero”.
            // (Tu Documentacion_Model.php ya lo respeta con ORDER BY d.id DESC;
            // este flag permite compat futuro sin romper nada.)
            'order_by' => 'id_desc',
        ];
        if ($estado) { $args['estado'] = $estado; }

        $res = $m->listar_docs($args);

        if (is_wp_error($res)) {
            wp_send_json_error(['message'=>$res->get_error_message()], 500);
        }

        $items = $res['items'] ?? ($res['rows'] ?? []);
        $total = isset($res['total']) ? (int)$res['total'] : (int)($res['count'] ?? count($items));
        $per   = (int)($res['per_page'] ?? $per_page);
        $paged = (int)($res['paged']    ?? $page);

        // (Salvaguarda por si el modelo no aplicara el orden)
        if (is_array($items) || $items instanceof \Traversable) {
            $items = is_array($items) ? $items : iterator_to_array($items);
            usort($items, static function($a,$b){
                return (int)($b->id ?? 0) <=> (int)($a->id ?? 0);
            });
        }

        $tbody = self::render_docs_tbody($items);
        $total_pages = max(1, (int)ceil($total / max(1,$per)));

        wp_send_json_success([
            'tbody'       => $tbody,
            'total'       => $total,
            'page'        => $paged,
            'per_page'    => $per,
            'total_pages' => $total_pages,
        ]);
    }

    private static function render_docs_tbody($rows): string{
        if (empty($rows)) {
            return '<tr><td colspan="8"><em>'.esc_html__('Sin datos','midas-rrhh').'</em></td></tr>';
        }
        $out = '';
        foreach ($rows as $r) {
            $emp   = trim(($r->emp_nombre ?? '').' '.($r->emp_apellido ?? ''));
            $tipo  = $r->tipo_descripcion ?? '—';
            $desc  = $r->descripcion ?? '—';

            $ini_raw = $r->fecha_inicio ?? '';
            $fin_raw = $r->fecha_fin ?? '';
            $ini = $ini_raw ? date_i18n('d/m/Y', strtotime($ini_raw)) : '—';
            $fin = $fin_raw ? date_i18n('d/m/Y', strtotime($fin_raw)) : '—';

            $estado_txt = $r->estado ?? '';
            $badge_cls  = 'grey';
            if ($estado_txt === 'vigente' || $estado_txt === 'sin_vencimiento') $badge_cls='green';
            elseif ($estado_txt === 'por_vencer') $badge_cls='orange';
            elseif ($estado_txt === 'vencido')    $badge_cls='red';
            $estado_label = $estado_txt ? ucwords(str_replace('_',' ', $estado_txt)) : __('—','midas-rrhh');
            $estado_html  = '<span class="badge '.$badge_cls.'">'.esc_html($estado_label).'</span>';

            $archivo_html = '—';
            if (!empty($r->archivo_id)) {
                $url = wp_get_attachment_url((int)$r->archivo_id);
                if ($url) {
                    $archivo_html = '<a class="button button-small" href="'.esc_url($url).'" target="_blank" rel="noopener">'.
                                    esc_html__('Ver archivo','midas-rrhh').'</a>';
                }
            }

            $acciones =
                '<button class="button button-small doc-edit" data-id="'.(int)$r->id.'">'.
                    esc_html__('Editar','midas-rrhh').
                '</button> '.
                '<button class="button button-small doc-del"  data-id="'.(int)$r->id.'">'.
                    esc_html__('Eliminar','midas-rrhh').
                '</button>';

            $out .= '<tr data-id="'.(int)$r->id.'">'.
                '<td>'.esc_html($emp ?: '—').'</td>'.
                '<td>'.esc_html($tipo).'</td>'.
                // descripción permitiendo formato básico seguro
                '<td>'.wp_kses($desc, ['a'=>['href'=>[],'target'=>[],'rel'=>[]],'br'=>[],'em'=>[],'strong'=>[],'span'=>['class'=>[]]]) .'</td>'.
                '<td>'.esc_html($ini).'</td>'.
                '<td>'.esc_html($fin).'</td>'.
                '<td>'.$estado_html.'</td>'.
                '<td>'.$archivo_html.'</td>'.
                '<td class="col-acciones">'.$acciones.'</td>'.
            '</tr>';
        }
        return $out;
    }

    /* ================== CREAR / EDITAR / ELIMINAR ================== */

    public static function crear(){
        self::require_post();
        self::nocache_and_headers();

        if (!self::can_manage()) wp_send_json_error(['message'=>__('Sin permiso.','midas-rrhh')],403);
        self::verify_nonce_docs();

        $m = new Documentacion_Model();

        $empleado_id = isset($_POST['empleado_id']) ? (int)$_POST['empleado_id'] : 0;
        $tipo_id     = isset($_POST['tipo_id'])     ? (int)$_POST['tipo_id']     : null;
        $descripcion = wp_kses_post($_POST['descripcion'] ?? '');
        $fecha_inicio= sanitize_text_field($_POST['fecha_inicio'] ?? '');
        $archivo_id  = self::handle_upload_if_any('archivo');

        if ($empleado_id <= 0 || !$fecha_inicio) {
            wp_send_json_error(['message'=>__('Empleado y fecha de inicio son obligatorios.','midas-rrhh')],400);
        }

        $user_id = (int) get_current_user_id();
        $id = $m->crear_doc($empleado_id,$tipo_id,$descripcion,$fecha_inicio,null,$archivo_id,$user_id);
        if (!$id) wp_send_json_error(['message'=>__('No se pudo guardar.','midas-rrhh')],500);

        wp_send_json_success(['id'=>$id]);
    }

    public static function editar(){
        self::require_post();
        self::nocache_and_headers();

        if (!self::can_manage()) wp_send_json_error(['message'=>__('Sin permiso.','midas-rrhh')],403);
        self::verify_nonce_docs();

        $m  = new Documentacion_Model();
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        if ($id <= 0) wp_send_json_error(['message'=>__('ID inválido.','midas-rrhh')],400);

        $patch = [];
        if (isset($_POST['empleado_id']))  $patch['empleado_id']  = (int)$_POST['empleado_id'];
        if (isset($_POST['tipo_id']))      $patch['tipo_id']      = (int)$_POST['tipo_id'];
        if (isset($_POST['descripcion']))  $patch['descripcion']  = wp_kses_post($_POST['descripcion']);
        if (isset($_POST['fecha_inicio'])) $patch['fecha_inicio'] = sanitize_text_field($_POST['fecha_inicio']);

        $new_file = self::handle_upload_if_any('archivo');
        if ($new_file) $patch['archivo_id'] = $new_file;

        if (empty($patch)) wp_send_json_error(['message'=>__('Nada para actualizar.','midas-rrhh')],400);

        $user_id = (int) get_current_user_id();
        $ok = $m->editar_doc($id, $patch, $user_id);
        if (!$ok) wp_send_json_error(['message'=>__('No se pudo actualizar.','midas-rrhh')],500);

        wp_send_json_success(['id'=>$id]);
    }

    public static function eliminar(){
        self::require_post();
        self::nocache_and_headers();

        if (!self::can_manage()) wp_send_json_error(['message'=>__('Sin permiso.','midas-rrhh')],403);
        self::verify_nonce_docs();

        $m  = new Documentacion_Model();
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        if ($id <= 0) wp_send_json_error(['message'=>__('ID inválido.','midas-rrhh')],400);

        $user_id = (int) get_current_user_id();
        $ok = $m->soft_delete_doc($id, $user_id);
        if (!$ok) wp_send_json_error(['message'=>__('No se pudo eliminar.','midas-rrhh')],500);

        wp_send_json_success(['id'=>$id]);
    }

    /* ================== Upload helper endurecido ================== */
    private static function handle_upload_if_any(string $field){
        if (empty($_FILES[$field]) || empty($_FILES[$field]['name'])) return null;

        if (!function_exists('media_handle_upload')) {
            require_once ABSPATH.'wp-admin/includes/file.php';
            require_once ABSPATH.'wp-admin/includes/media.php';
            require_once ABSPATH.'wp-admin/includes/image.php';
        }

        $file = $_FILES[$field];

        if (!empty($file['error']) && (int)$file['error'] !== UPLOAD_ERR_OK) {
            wp_send_json_error(['message'=>__('Error en la subida.','midas-rrhh')],400);
        }

        // Extensiones/mimes permitidos
        $allowed_mimes = [
            'application/pdf',
            'image/jpeg',
            'image/png',
            'image/gif',
            'image/webp',
        ];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $bad = ['php','phtml','php3','php4','php5','phar','js','html','htm','svg','exe','sh','bat','ps1','dll'];
        if (in_array($ext, $bad, true)) {
            wp_send_json_error(['message'=>__('Extensión no permitida.','midas-rrhh')],400);
        }
        if (!in_array($file['type'], $allowed_mimes, true)) {
            wp_send_json_error(['message'=>__('Tipo de archivo no permitido.','midas-rrhh')],400);
        }
        if ((int)$file['size'] > 10*1024*1024) {
            wp_send_json_error(['message'=>__('Archivo demasiado grande (máx 10MB).','midas-rrhh')],400);
        }

        // Subida segura vía API WP
        $attach_id = media_handle_upload($field, 0);
        if (is_wp_error($attach_id)) {
            wp_send_json_error(['message'=>__('Error subiendo archivo: ','midas-rrhh').$attach_id->get_error_message()],400);
        }
        return (int)$attach_id;
    }
}

Documentacion_Controller::register_ajax();
