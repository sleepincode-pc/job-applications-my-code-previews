<?php
namespace MidasRRHH\Controllers;

use MidasRRHH\Models\Novedades_Model;

if (!defined('ABSPATH')) exit;

/**
 * Controller de Novedades / Ampliaciones
 * - Registra endpoints AJAX para admin y front
 * - Expone un método estático install() para crear tablas
 */
class Novedades_Controller {
    /** @var Novedades_Model */
    private $model;

    public function __construct() {
        $this->model = new Novedades_Model();

        // AJAX (lectura pública)
        add_action('wp_ajax_midas_nov_list_topics',       [$this, 'ajax_list_topics']);
        add_action('wp_ajax_nopriv_midas_nov_list_topics',[$this, 'ajax_list_topics']);

        add_action('wp_ajax_midas_nov_get_topic',         [$this, 'ajax_get_topic']);
        add_action('wp_ajax_nopriv_midas_nov_get_topic',  [$this, 'ajax_get_topic']);

        add_action('wp_ajax_midas_nov_list_replies',       [$this, 'ajax_list_replies']);
        add_action('wp_ajax_nopriv_midas_nov_list_replies',[$this, 'ajax_list_replies']);

        // AJAX (escritura solo admin/backoffice)
        add_action('wp_ajax_midas_nov_create_topic', [$this, 'ajax_create_topic']);
        add_action('wp_ajax_midas_nov_update_topic', [$this, 'ajax_update_topic']);
        add_action('wp_ajax_midas_nov_delete_topic', [$this, 'ajax_delete_topic']);
        add_action('wp_ajax_midas_nov_add_reply',   [$this, 'ajax_add_reply']);
        add_action('wp_ajax_midas_nov_delete_reply',[$this, 'ajax_delete_reply']);
    }

    /** Llamar en la activación del plugin */
    public static function install() {
        $model = new Novedades_Model();
        $model->create_tables();
    }

    /* ========= Helpers ========= */

    private function can_manage(): bool {
        // Usá la capability que te encaje; mantengo la que venís usando
        return current_user_can('edit_midas_empleados') || current_user_can('manage_options');
    }

    private function parse_pagination(): array {
        return [
            'page'     => isset($_REQUEST['page_num']) ? max(1, intval($_REQUEST['page_num'])) : 1,
            'per_page' => isset($_REQUEST['per_page']) ? max(1, intval($_REQUEST['per_page'])) : 20,
        ];
    }

    /* ========= AJAX (lectura) ========= */

    public function ajax_list_topics() {
        $args = $this->parse_pagination();
        if (isset($_REQUEST['estado']))          $args['estado'] = sanitize_text_field(wp_unslash($_REQUEST['estado']));
        if (isset($_REQUEST['cliente_visible'])) $args['cliente_visible'] = intval($_REQUEST['cliente_visible']);
        if (isset($_REQUEST['s']))               $args['s'] = sanitize_text_field(wp_unslash($_REQUEST['s']));

        $out = $this->model->list_topics($args);
        wp_send_json_success($out);
    }

    public function ajax_get_topic() {
        $id = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;
        if ($id <= 0) wp_send_json_error(['message'=>'ID inválido'], 400);

        $topic   = $this->model->get_topic($id);
        if (!$topic) wp_send_json_error(['message'=>'No encontrado'], 404);

        // opcional: cargar primeras respuestas
        $replies = $this->model->list_replies($id, ['page'=>1,'per_page'=>50]);
        wp_send_json_success(['topic'=>$topic, 'replies'=>$replies]);
    }

    public function ajax_list_replies() {
        $topic_id = isset($_REQUEST['topic_id']) ? intval($_REQUEST['topic_id']) : 0;
        if ($topic_id <= 0) wp_send_json_error(['message'=>'ID inválido'], 400);

        $args = $this->parse_pagination();
        if (isset($_REQUEST['estado'])) $args['estado'] = sanitize_text_field(wp_unslash($_REQUEST['estado']));
        $out = $this->model->list_replies($topic_id, $args);
        wp_send_json_success($out);
    }

    /* ========= AJAX (escritura) ========= */

    public function ajax_create_topic() {
        if (!$this->can_manage()) wp_send_json_error(['message'=>'No autorizado'], 403);
        check_ajax_referer('midas_nov_nonce','nonce');

        $payload = [
            'titulo'          => isset($_POST['titulo']) ? sanitize_text_field(wp_unslash($_POST['titulo'])) : '',
            'contenido'       => isset($_POST['contenido']) ? wp_kses_post(wp_unslash($_POST['contenido'])) : '',
            'estado'          => isset($_POST['estado']) ? sanitize_text_field(wp_unslash($_POST['estado'])) : 'publish',
            'sticky'          => !empty($_POST['sticky']) ? 1 : 0,
            'tags'            => isset($_POST['tags']) ? sanitize_text_field(wp_unslash($_POST['tags'])) : '',
            'cliente_visible' => !empty($_POST['cliente_visible']) ? 1 : 0,
            'autor_id'        => get_current_user_id(),
        ];

        if ($payload['titulo'] === '') wp_send_json_error(['message'=>'El título es obligatorio'], 400);

        $id = $this->model->create_topic($payload);
        if ($id <= 0) wp_send_json_error(['message'=>'No se pudo crear el tema'], 500);

        wp_send_json_success(['id'=>$id]);
    }

    public function ajax_update_topic() {
        if (!$this->can_manage()) wp_send_json_error(['message'=>'No autorizado'], 403);
        check_ajax_referer('midas_nov_nonce','nonce');

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        if ($id <= 0) wp_send_json_error(['message'=>'ID inválido'], 400);

        $data = [];
        foreach (['titulo','contenido','estado','tags'] as $k) {
            if (isset($_POST[$k])) $data[$k] = wp_unslash($_POST[$k]);
        }
        if (isset($_POST['sticky']))          $data['sticky'] = intval($_POST['sticky']);
        if (isset($_POST['cliente_visible'])) $data['cliente_visible'] = intval($_POST['cliente_visible']);

        $ok = $this->model->update_topic($id, $data);
        if (!$ok) wp_send_json_error(['message'=>'No se pudo actualizar'], 500);

        wp_send_json_success(['updated'=>true]);
    }

    public function ajax_delete_topic() {
        if (!$this->can_manage()) wp_send_json_error(['message'=>'No autorizado'], 403);
        check_ajax_referer('midas_nov_nonce','nonce');

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        if ($id <= 0) wp_send_json_error(['message'=>'ID inválido'], 400);

        $ok = $this->model->delete_topic($id);
        if (!$ok) wp_send_json_error(['message'=>'No se pudo eliminar'], 500);

        wp_send_json_success(['deleted'=>true]);
    }

    public function ajax_add_reply() {
        if (!$this->can_manage()) wp_send_json_error(['message'=>'No autorizado'], 403);
        check_ajax_referer('midas_nov_nonce','nonce');

        $topic_id  = isset($_POST['topic_id']) ? intval($_POST['topic_id']) : 0;
        $contenido = isset($_POST['contenido']) ? wp_kses_post(wp_unslash($_POST['contenido'])) : '';
        if ($topic_id <= 0 || $contenido === '') wp_send_json_error(['message'=>'Datos incompletos'], 400);

        $id = $this->model->add_reply($topic_id, [
            'contenido'=>$contenido,
            'estado'   =>'publish',
            'autor_id' =>get_current_user_id(),
        ]);
        if ($id <= 0) wp_send_json_error(['message'=>'No se pudo responder'], 500);

        wp_send_json_success(['id'=>$id]);
    }

    public function ajax_delete_reply() {
        if (!$this->can_manage()) wp_send_json_error(['message'=>'No autorizado'], 403);
        check_ajax_referer('midas_nov_nonce','nonce');

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        if ($id <= 0) wp_send_json_error(['message'=>'ID inválido'], 400);

        $ok = $this->model->delete_reply($id);
        if (!$ok) wp_send_json_error(['message'=>'No se pudo eliminar la respuesta'], 500);

        wp_send_json_success(['deleted'=>true]);
    }
}
