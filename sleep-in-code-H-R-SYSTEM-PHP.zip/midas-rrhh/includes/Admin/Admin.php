<?php
namespace MidasRRHH\Admin;

use MidasRRHH\Controllers\Reporte_Controller;
use MidasRRHH\Controllers\Organigrama_Controller;

if (!defined('ABSPATH')) exit;

class Admin {
    private $reporte_controller;
    private $organigrama_controller;
    private static $instance = null;

    public function __construct() {
        error_log("[Admin::__construct] Inicializando Admin");
        $this->reporte_controller     = new Reporte_Controller();
        $this->organigrama_controller = new Organigrama_Controller(); // registra AJAX, etc.

        // prioridad baja: registrar menú temprano
        add_action('admin_menu', [$this, 'add_admin_pages'], 5);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
    }

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
            error_log("[Admin::get_instance] Instancia creada");
        }
        return self::$instance;
    }

    public static function init() {
        if (!is_admin()) return null;
        if (wp_doing_ajax() || (defined('DOING_CRON') && DOING_CRON)) return null;

        $script = basename($_SERVER['PHP_SELF'] ?? '');
        if (in_array($script, ['admin-post.php','admin-ajax.php','async-upload.php','media-upload.php'], true)) {
            return null;
        }

        error_log("[Admin::init] Inicializando Admin singleton");
        return self::get_instance();
    }

    /** Proxy estático para el Dashboard (lo usa el menú padre) */
    public static function dashboard_page() {
        self::get_instance()->render_dashboard();
    }

    /** AJAX: guardar paleta por usuario */
    public static function ajax_save_palette_scoped() {
        if (!check_ajax_referer('midas_palette_scoped_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Nonce inválido o faltante.'], 403);
        }

        $uid = get_current_user_id();
        if (!$uid) {
            wp_send_json_error(['message' => 'Sin usuario'], 403);
        }

        $raw  = isset($_POST['palette']) ? wp_unslash($_POST['palette']) : '';
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            wp_send_json_error(['message' => 'Payload inválido'], 400);
        }

        $is_hex = function($v){ return is_string($v) && preg_match('/^#[0-9A-Fa-f]{6}$/', $v); };

        $clean = [
            'cards' => [
                'bg'        => $is_hex($data['cards']['bg'] ?? '')        ? $data['cards']['bg']        : '#ffffff',
                'border'    => $is_hex($data['cards']['border'] ?? '')    ? $data['cards']['border']    : '#ccd0d4',
                'headerBg'  => $is_hex($data['cards']['headerBg'] ?? '')  ? $data['cards']['headerBg']  : '#f7f7f7',
                'headerTxt' => $is_hex($data['cards']['headerTxt'] ?? '') ? $data['cards']['headerTxt'] : '#1f2937',
                'stripe'    => $is_hex($data['cards']['stripe'] ?? '')    ? $data['cards']['stripe']    : '#f9fafb',
            ],
            'text' => [
                'txt'   => $is_hex($data['text']['txt'] ?? '')   ? $data['text']['txt']   : '#1e293b',
                'muted' => $is_hex($data['text']['muted'] ?? '') ? $data['text']['muted'] : '#475569',
            ],
            'btn' => [
                'bg'  => $is_hex($data['btn']['bg']  ?? '') ? $data['btn']['bg']  : '#2271b1',
                'txt' => $is_hex($data['btn']['txt'] ?? '') ? $data['btn']['txt'] : '#ffffff',
            ],
        ];

        update_user_meta($uid, 'midas_palette_scoped', $clean);
        wp_send_json_success(['saved' => $clean]);
    }

    /** Comprueba si ya existe un submenú con ese slug bajo un padre dado */
    private function submenu_exists(string $parent_slug, string $menu_slug): bool {
        global $submenu;
        if (!isset($submenu[$parent_slug]) || !is_array($submenu[$parent_slug])) return false;
        foreach ($submenu[$parent_slug] as $item) {
            if (isset($item[2]) && $item[2] === $menu_slug) return true;
        }
        return false;
    }

    private function normalize_menu(string $parent_slug) {
        global $submenu;
        if (isset($submenu[$parent_slug][0])) {
            $submenu[$parent_slug][0][0] = __('Dashboard', 'midas-rrhh');
        }
        if (!isset($submenu[$parent_slug]) || !is_array($submenu[$parent_slug])) return;

        $order = [
            'midas-rrhh',
            'midas-empleados',
            'midas-recibos',
            'midas-licencias',
            'midas-carpeta-medica',
            'midas-documentacion-vencimiento',
            'midas-organigrama',
            'midas-novedades-ampliaciones', // único submenú del foro
            'midas-reportes',
            'midas-roles',
            'midas-tickets',
            'midas-rrhh-import-export',
            'midas-configuracion',
        ];
        usort($submenu[$parent_slug], function($a,$b) use ($order){
            $sa=$a[2]??''; $sb=$b[2]??'';
            $ia=array_search($sa,$order,true); $ib=array_search($sb,$order,true);
            $ia=($ia===false)?PHP_INT_MAX:$ia; $ib=($ib===false)?PHP_INT_MAX:$ib;
            return $ia<=>$ib;
        });
    }

    public function add_admin_pages() {
        $parent_slug = 'midas-rrhh';

        if (empty($GLOBALS['admin_page_hooks'][$parent_slug])) {
            add_menu_page(
                __('Midas RRHH','midas-rrhh'),
                __('Midas RRHH','midas-rrhh'),
                'edit_midas_empleados',
                $parent_slug,
                [self::class,'dashboard_page'],
                'dashicons-groups',
                30
            );
        }

        // Submenús existentes
        if (!$this->submenu_exists($parent_slug, 'midas-empleados')) {
            add_submenu_page($parent_slug, __('Empleados','midas-rrhh'), __('Empleados','midas-rrhh'),
                'edit_midas_empleados', 'midas-empleados', [$this,'render_empleados']);
        }
        if (!$this->submenu_exists($parent_slug, 'midas-recibos')) {
            add_submenu_page($parent_slug, __('Recibos','midas-rrhh'), __('Recibos','midas-rrhh'),
                'edit_midas_recibos', 'midas-recibos', [$this,'render_recibos']);
        }
        if (!$this->submenu_exists($parent_slug, 'midas-licencias')) {
            add_submenu_page($parent_slug, __('Licencias','midas-rrhh'), __('Licencias','midas-rrhh'),
                'edit_midas_licencias', 'midas-licencias', [$this,'render_licencias']);
        }
        if (!$this->submenu_exists($parent_slug, 'midas-carpeta-medica')) {
            add_submenu_page($parent_slug, __('Carpeta Médica','midas-rrhh'), __('Carpeta Médica','midas-rrhh'),
                'edit_midas_carpeta_medica', 'midas-carpeta-medica', [$this,'render_carpeta_medica']);
        }
        if (!$this->submenu_exists($parent_slug, 'midas-documentacion-vencimiento')) {
            add_submenu_page($parent_slug,
                __('Documentación con vencimiento','midas-rrhh'), __('Documentación con vencimiento','midas-rrhh'),
                'edit_midas_empleados', 'midas-documentacion-vencimiento', [$this,'render_documentacion_vencimiento']);
        }

        // Organigrama
        if (!$this->submenu_exists($parent_slug, 'midas-organigrama')) {
            add_submenu_page(
                $parent_slug,
                __('Organigrama','midas-rrhh'),
                __('Organigrama','midas-rrhh'),
                'edit_midas_empleados',
                'midas-organigrama',
                [$this,'render_organigrama']
            );
        }

        // ÚNICO submenú: Novedades / Ampliaciones
        if (!$this->submenu_exists($parent_slug, 'midas-novedades-ampliaciones')) {
            add_submenu_page(
                $parent_slug,
                __('Novedades / Ampliaciones','midas-rrhh'),
                __('Novedades / Ampliaciones','midas-rrhh'),
                'edit_midas_empleados', // ajustá la capability si necesitás
                'midas-novedades-ampliaciones',
                [$this,'render_novedades_ampliaciones']
            );
        }

        if (!$this->submenu_exists($parent_slug, 'midas-reportes')) {
            add_submenu_page($parent_slug, __('Reportes','midas-rrhh'), __('Reportes','midas-rrhh'),
                'export_midas_reports', 'midas-reportes', [$this->reporte_controller,'render_reportes']);
        }
        if (!$this->submenu_exists($parent_slug, 'midas-roles')) {
            add_submenu_page($parent_slug, __('Roles','midas-rrhh'), __('Roles','midas-rrhh'),
                'manage_options', 'midas-roles', [$this,'render_roles']);
        }
        if (!$this->submenu_exists($parent_slug, 'midas-tickets')) {
            add_submenu_page($parent_slug, __('Instancias','midas-rrhh'), __('Instancias','midas-rrhh'),
                'manage_options', 'midas-tickets', [$this,'render_tickets']);
        }
        if (!$this->submenu_exists($parent_slug, 'midas-rrhh-import-export')) {
            add_submenu_page($parent_slug, __('Importar/Exportar','midas-rrhh'), __('Importar/Exportar','midas-rrhh'),
                'manage_options', 'midas-rrhh-import-export', [$this,'render_import_export']);
        }

        // Configuración (opcional por pestaña)
        $user_tabs = get_user_meta(get_current_user_id(), 'midas_user_tabs', true);
        $user_tabs = is_array($user_tabs) ? $user_tabs : [];
        if (in_array('config', $user_tabs) || current_user_can('manage_options')) {
            if (!$this->submenu_exists($parent_slug, 'midas-configuracion')) {
                add_submenu_page($parent_slug, __('Configuración','midas-rrhh'), __('Configuración','midas-rrhh'),
                    'manage_options', 'midas-configuracion', [$this,'render_configuracion']);
            }
        }

        $this->normalize_menu($parent_slug);

        if (!defined('MIDAS_RRHH_MENU_ADDED')) define('MIDAS_RRHH_MENU_ADDED', true);
    }

    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'midas-') === false) return;

        wp_enqueue_style('midas-admin', MIDAS_RRHH_PLUGIN_URL.'assets/css/admin.css', [], MIDAS_RRHH_VERSION);
        wp_enqueue_script('midas-admin', MIDAS_RRHH_PLUGIN_URL.'assets/js/admin.js', ['jquery','wp-util'], MIDAS_RRHH_VERSION, true);
        wp_enqueue_script('midas-darkmode', MIDAS_RRHH_PLUGIN_URL.'assets/js/darkmode.js', [], MIDAS_RRHH_VERSION, true);

        // boot global (merge)
        $boot = [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonces'   => [
                'roles'    => wp_create_nonce('midas_roles_nonce'),
                'empleados'=> wp_create_nonce('midas_empleados_nonce'),
            ],
            'i18n'     => [
                'empleado_guardado'   => __('Empleado guardado correctamente.', 'midas-rrhh'),
                'empleado_eliminado'  => __('Empleado eliminado correctamente.', 'midas-rrhh'),
                'no_results'          => __('No se encontraron empleados.', 'midas-rrhh'),
                'confirm_delete'      => __('¿Estás seguro que querés eliminar este empleado?', 'midas-rrhh'),
                'edit'                => __('Editar', 'midas-rrhh'),
                'delete'              => __('Eliminar', 'midas-rrhh'),
            ]
        ];
        wp_add_inline_script(
            'midas-admin',
            'window.midas_rrhh = Object.assign({}, window.midas_rrhh || {}, ' . wp_json_encode($boot) . ');',
            'before'
        );

        wp_enqueue_script('jquery-ui-datepicker');
        wp_enqueue_style('jquery-ui','https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');

        if (isset($_GET['page']) && $_GET['page'] === 'midas-empleados') {
            wp_enqueue_style('midas-empleados-nota', MIDAS_RRHH_PLUGIN_URL.'assets/css/empleados-nota.css', [], MIDAS_RRHH_VERSION);
        }
    }

    // ===== Renderers =====
    public function render_dashboard()                 { include MIDAS_RRHH_PLUGIN_DIR . 'templates/admin/dashboard.php'; }
    public function render_empleados()                 { include MIDAS_RRHH_PLUGIN_DIR . 'templates/admin/empleados.php'; }
    public function render_recibos()                   { include MIDAS_RRHH_PLUGIN_DIR . 'templates/admin/recibos.php'; }
    public function render_licencias()                 { include MIDAS_RRHH_PLUGIN_DIR . 'templates/admin/licencias.php'; }
    public function render_carpeta_medica()            { include MIDAS_RRHH_PLUGIN_DIR . 'templates/admin/carpeta-medica.php'; }
    public function render_documentacion_vencimiento() { include MIDAS_RRHH_PLUGIN_DIR . 'templates/admin/documentacion-vencimiento.php'; }
    public function render_roles()                     { include MIDAS_RRHH_PLUGIN_DIR . 'templates/admin/roles.php'; }
    public function render_tickets()                   { include MIDAS_RRHH_PLUGIN_DIR . 'templates/admin/tickets.php'; }
    public function render_configuracion()             { $smtp_settings = get_option('midas_rrhh_smtp_settings', []); include MIDAS_RRHH_PLUGIN_DIR . 'templates/admin/configuracion.php'; }
    public function render_import_export()             { include MIDAS_RRHH_PLUGIN_DIR . 'templates/admin/import-export.php'; }
    public function render_organigrama()               { include MIDAS_RRHH_PLUGIN_DIR . 'templates/admin/organigrama.php'; }

    // 👉 ÚNICO renderer del foro (apunta a la vista existente novedades.php)
    public function render_novedades_ampliaciones()    { include MIDAS_RRHH_PLUGIN_DIR . 'templates/admin/novedades.php'; }
}
// ==== FIN DE LA CLASE Admin ====

// Inicialización del Admin (evita admin-post/admin-ajax/cron)
add_action('admin_init', ['MidasRRHH\Admin\Admin', 'init']);

// Registrar SIEMPRE el endpoint AJAX (también en admin-ajax.php)
add_action('wp_ajax_midas_save_palette_scoped', ['MidasRRHH\Admin\Admin', 'ajax_save_palette_scoped']);

// AJAX Configuración (otros endpoints existentes)
add_action('wp_ajax_midas_agregar_configuracion', [\MidasRRHH\Controllers\Configuracion_Controller::class, 'agregar_configuracion']);
add_action('wp_ajax_midas_editar_configuracion',  [\MidasRRHH\Controllers\Configuracion_Controller::class, 'editar_configuracion']);
add_action('wp_ajax_midas_eliminar_configuracion',[\MidasRRHH\Controllers\Configuracion_Controller::class, 'eliminar_configuracion']);
