jQuery(document).ready(function($) {
  // ======================= PALETA GLOBAL (todas las pestañas) =======================
  (function setupGlobalPalette(){
    // ---- Descubrir AJAX URL y Nonces (robusto) ----
    var AJAX_URL = (window.midas_rrhh && window.midas_rrhh.ajax_url) || $('#midas-ajax-url').val() || window.ajaxurl || '';
    var PALETTE_NONCE = (window.midas_rrhh && window.midas_rrhh.palette_nonce) || $('#midas-nonce-palette').val() || '';
    var SAVED = (window.midas_rrhh && window.midas_rrhh.user_palette) || null;

    // ---- Estilos base (si la vista no trae CSS del dashboard) ----
    if (!document.getElementById('midas-palette-base')) {
      var baseCSS = `
      <style id="midas-palette-base">
        [data-midas-scope], #midasDashboard, body.midas-scope-fallback{
          --md-card-bg:#ffffff; --md-card-border:#ccd0d4; --md-card-header-bg:#f7f7f7; --md-card-header-text:#1f2937;
          --md-table-stripe:#f9fafb; --md-text:#1e293b; --md-muted:#475569; color:var(--md-text);
        }
        [data-midas-scope] .midas-card, #midasDashboard .midas-card, body.midas-scope-fallback .midas-card{
          background:var(--md-card-bg); border:1px solid var(--md-card-border);
        }
        [data-midas-scope] .midas-card h3, #midasDashboard .midas-card h3, body.midas-scope-fallback .midas-card h3{
          background:var(--md-card-header-bg); color:var(--md-card-header-text); border-bottom:1px solid var(--md-card-border);
          margin:0; padding:15px;
        }
        [data-midas-scope] table.wp-list-table tbody tr:nth-child(odd),
        #midasDashboard table.wp-list-table tbody tr:nth-child(odd),
        body.midas-scope-fallback table.wp-list-table tbody tr:nth-child(odd){
          background:var(--md-table-stripe) !important;
        }
      </style>`;
      $('head').append(baseCSS);
    }

    // ---- Crear modal si no existe (reutilizable en todas las vistas) ----
    if (!document.getElementById('midasPaletteModal')) {
      var modalHTML = `
      <div id="midasPaletteModal" class="midas-modal-overlay" style="display:none;" aria-hidden="true" aria-modal="true" role="dialog">
        <div class="midas-modal" role="document">
          <h2 class="midas-modal-title">🎨 Paleta de colores</h2>
          <p class="midas-modal-sub">Afecta tarjetas/tablas de esta vista.</p>
          <div class="midas-modal-grid">
            <div class="mmg-col">
              <h4>Tarjetas</h4>
              <label>Fondo <input type="color" id="c-bg" value="#ffffff"></label>
              <label>Borde <input type="color" id="c-border" value="#ccd0d4"></label>
              <label>Cabecera <input type="color" id="c-hbg" value="#f7f7f7"></label>
              <label>Texto cabecera <input type="color" id="c-htxt" value="#1f2937"></label>
              <label>Renglón zebra <input type="color" id="c-stripe" value="#f9fafb"></label>
            </div>
            <div class="mmg-col">
              <h4>Textos</h4>
              <label>Texto principal <input type="color" id="t-main" value="#1e293b"></label>
              <label>Texto atenuado <input type="color" id="t-muted" value="#475569"></label>
            </div>
          </div>
          <div class="midas-modal-actions">
            <button type="button" class="button" id="pal-reset">Restablecer</button>
            <button type="button" class="button button-primary" id="pal-save">Guardar</button>
            <button type="button" class="button" id="pal-close">Cerrar</button>
            <span id="pal-status" class="pal-status" aria-live="polite"></span>
          </div>
        </div>
      </div>`;
      $('body').append(modalHTML);

      // CSS mínimo del modal y FAB
      var css = `
      <style id="midas-palette-modal-css">
        .midas-palette-inline-btn{ margin-left:8px; vertical-align:middle; }
        .midas-palette-fab{ position:fixed; right:18px; bottom:18px; z-index:9999; width:48px; height:48px; border-radius:50%;
          display:flex; align-items:center; justify-content:center; background:#2271b1; color:#fff; font-size:22px; cursor:pointer;
          box-shadow:0 8px 22px rgba(0,0,0,.2); }
        .midas-palette-fab:hover{ filter:brightness(0.95); }
        .midas-modal-overlay{ position:fixed; inset:0; background:rgba(0,0,0,.45); display:none; align-items:center; justify-content:center; z-index:10000; padding:12px; }
        .midas-modal{ width:100%; max-width:760px; background:#fff; border:1px solid #d0d7de; border-radius:12px; box-shadow:0 12px 36px rgba(0,0,0,.25); padding:16px; }
        .midas-modal-title{ margin:0 0 6px; font-size:18px; }
        .midas-modal-sub{ margin:0 0 12px; color:#4b5563; }
        .midas-modal-grid{ display:grid; grid-template-columns:1fr 1fr; gap:16px; }
        .mmg-col{ background:#fafafa; border:1px solid #e5e7eb; padding:12px; border-radius:8px; }
        .mmg-col h4{ margin:0 0 10px; }
        .mmg-col label{ display:flex; align-items:center; justify-content:space-between; gap:10px; padding:6px 0; }
        .mmg-col input[type="color"]{ width:44px; height:32px; padding:0; border:1px solid #c8d1dc; border-radius:4px; }
        .midas-modal-actions{ display:flex; gap:8px; align-items:center; justify-content:flex-end; margin-top:12px; }
        .pal-status{ min-width:120px; font-weight:600; }
        @media (max-width:560px){ .midas-modal-grid{ grid-template-columns:1fr; } }
      </style>`;
      $('head').append(css);
    }

    // ---- Botón (inline o FAB) ----
    if (!document.getElementById('midas-palette-trigger')) {
      var inlineBtn = $('<button type="button" id="midas-palette-trigger" class="button button-secondary midas-palette-inline-btn">🎨 Paleta</button>');
      var darkBtn = document.querySelector('.wp-dark-mode-switch, .wp-dark-mode-switcher, #wp-dark-mode-switch, .wp-admin-dark-mode-toggle, #wp-dark-mode-toggle');
      if (darkBtn) {
        $(darkBtn).after(inlineBtn);
      } else {
        // FAB si no hay dark toggle visible
        var fab = $('<div class="midas-palette-fab" title="Elegir paleta">🎨</div>');
        $('body').append(fab);
        fab.on('click', function(){ openModal(); });
      }
      inlineBtn.on('click', function(){ openModal(); });
    }

    // ---- Scopes a los que se aplica la paleta ----
    var $scopes = $('[data-midas-scope], #midasDashboard');
    if (!$scopes.length) { $('body').addClass('midas-scope-fallback'); $scopes = $('body'); }

    // ---- Defaults + paleta inicial ----
    var DEF = { cards:{ bg:'#ffffff', border:'#ccd0d4', headerBg:'#f7f7f7', headerTxt:'#1f2937', stripe:'#f9fafb' },
                text:{ txt:'#1e293b', muted:'#475569' } };
    var initial = (SAVED && typeof SAVED==='object')
      ? { cards: $.extend({}, DEF.cards, SAVED.cards||{}), text: $.extend({}, DEF.text, SAVED.text||{}) }
      : (function(){ try{ return JSON.parse(localStorage.getItem('midas.palette.scoped')||'null')||DEF; }catch(_){ return DEF; } })();

    function applyPaletteTo($els, p){
      $els.each(function(){
        var el = this;
        el.style.setProperty('--md-card-bg',         p.cards.bg);
        el.style.setProperty('--md-card-border',     p.cards.border);
        el.style.setProperty('--md-card-header-bg',  p.cards.headerBg);
        el.style.setProperty('--md-card-header-text',p.cards.headerTxt);
        el.style.setProperty('--md-table-stripe',    p.cards.stripe);
        el.style.setProperty('--md-text',            p.text.txt);
        el.style.setProperty('--md-muted',           p.text.muted);
      });
      try{ localStorage.setItem('midas.palette.scoped', JSON.stringify(p)); }catch(_){}
    }
    applyPaletteTo($scopes, initial);

    // ---- Modal control ----
    var $modal   = $('#midasPaletteModal');
    var $btnClose= $('#pal-close');
    function openModal(){ $modal.css('display','flex').attr('aria-hidden','false'); syncInputs(current()); }
    function closeModal(){ $modal.hide().attr('aria-hidden','true'); }
    $btnClose.on('click', closeModal);
    $modal.on('click', function(e){ if (e.target === this) closeModal(); });
    $(document).on('keydown', function(e){ if (e.key === 'Escape') closeModal(); });

    // ---- Inputs + eventos ----
    var $cBg   = $('#c-bg'), $cBor = $('#c-border'), $cHbg = $('#c-hbg'),
        $cHtxt = $('#c-htxt'), $cStr = $('#c-stripe'), $tMain = $('#t-main'),
        $tMuted = $('#t-muted'), $reset = $('#pal-reset'), $save = $('#pal-save'), $status = $('#pal-status');

    function current(){
      // Lee de los inputs si existen, sino usa localStorage/SAVED/DEF
      var ls = null; try{ ls = JSON.parse(localStorage.getItem('midas.palette.scoped')||'null'); }catch(_){}
      var base = ls || SAVED || initial || DEF;
      return { cards:{ bg: $cBg.val()||base.cards.bg, border:$cBor.val()||base.cards.border, headerBg:$cHbg.val()||base.cards.headerBg,
                       headerTxt:$cHtxt.val()||base.cards.headerTxt, stripe:$cStr.val()||base.cards.stripe },
               text:{ txt:$tMain.val()||base.text.txt, muted:$tMuted.val()||base.text.muted } };
    }
    function syncInputs(p){
      $cBg.val(p.cards.bg); $cBor.val(p.cards.border); $cHbg.val(p.cards.headerBg);
      $cHtxt.val(p.cards.headerTxt); $cStr.val(p.cards.stripe);
      $tMain.val(p.text.txt); $tMuted.val(p.text.muted);
    }
    syncInputs(initial);

    function onChange(){ var p = current(); applyPaletteTo($scopes, p); }
    $([ $cBg,$cBor,$cHbg,$cHtxt,$cStr,$tMain,$tMuted ]).each(function(){ this.on('input', onChange); this.on('change', onChange); });

    $reset.on('click', function(){
      syncInputs(DEF); applyPaletteTo($scopes, DEF);
      $status.text('Restablecido (no guardado)'); setTimeout(function(){ $status.text(''); }, 2000);
    });

    $save.on('click', function(){
      var nonce = (window.midas_rrhh && window.midas_rrhh.palette_nonce) || $('#midas-nonce-palette').val() || PALETTE_NONCE || '';
      if (!nonce) { alert('Falta nonce. Recargá la página.'); return; }
      var payload = current();
      $save.prop('disabled', true); $status.text('Guardando...');

      $.ajax({
        url: AJAX_URL, type: 'POST', dataType: 'json',
        data: { action:'midas_save_palette_scoped', nonce:nonce, _wpnonce:nonce, palette: JSON.stringify(payload) }
      }).done(function(r){
        if (!r || r.success !== true) { alert((r && r.data && (r.data.message||r.data)) || 'Error guardando'); $status.text('Error'); return; }
        $status.text('Guardado ✓');
      }).fail(function(){
        alert('No se pudo guardar tu paleta.'); $status.text('Error');
      }).always(function(){
        $save.prop('disabled', false); setTimeout(function(){ $status.text(''); }, 2200);
      });
    });
  })();
  // ======================= FIN PALETA GLOBAL =======================


  // ======================= TU LÓGICA EXISTENTE (EMPLEADOS) =======================
  var ajaxInProgress = false;
  var modalAbierto = false;

  // Logo login (no se toca)
  if (typeof midas_rrhh !== 'undefined' && midas_rrhh.logo_login_url) {
    var customStyle = `
      <style>
        body.login div#login h1 a {
          background-image: url('${midas_rrhh.logo_login_url}') !important;
          background-size: contain !important;
          width: auto !important;
          height: 100px !important;
        }
      </style>`;
    $('head').append(customStyle);
  }

  // ----------------------- EMPLEADOS: Buscar -----------------------
  $('#buscar-empleados')
    .on('input', debounce(function() {
      var termino = $(this).val().trim();
      if (termino.length >= 3 || termino.length === 0) buscarEmpleados(termino);
    }, 300))
    .on('focus', function() {
      $('html, body').animate({ scrollTop: $(this).offset().top - 100 }, 300);
    });

  // ----------------------- EMPLEADOS: Editar/Borrar ----------------
  $(document).on('click', '.editar-empleado', function(e) {
    e.preventDefault(); var empleadoId = $(this).data('id'); abrirModalEmpleado(empleadoId);
  });
  $(document).on('click', '.borrar-empleado', function(e) {
    e.preventDefault(); var empleadoId = $(this).data('id'); confirmarEliminarEmpleado(empleadoId);
  });

  // --- FORM EDITAR: Submit AJAX ---
  $('#form-editar-empleado').off('submit').on('submit', function(e) {
    e.preventDefault(); if (ajaxInProgress) return; ajaxInProgress = true;
    var formData = new FormData(this);
    formData.append('action', 'midas_editar_empleado');
    formData.append('nonce', midas_rrhh.nonces.empleados);

    $.ajax({
      url: midas_rrhh.ajax_url, type:'POST', data: formData, processData:false, contentType:false, dataType:'json',
      beforeSend: function(){ $('#form-editar-empleado button[type="submit"]').prop('disabled', true); }
    }).done(function(response){
      if (response.success && response.data && response.data.empleado) {
        var emp = response.data.empleado;
        var fila = $('tr[data-empleado-id="'+emp.id+'"]');
        if (fila.length) {
          fila.empty();
          fila.append('<td>' + emp.nombre + ' ' + emp.apellido + '</td>');
          fila.append('<td>' + emp.dni + '</td>');
          fila.append('<td>' + emp.cuil + '</td>');
          fila.append('<td>' + (emp.area_nombre || '') + '</td>');
          fila.append('<td>' + (emp.tarea_nombre || '') + '</td>');
          var actions = $('<td>');
          actions.append('<a href="#" class="button editar-empleado" data-id="'+emp.id+'">' + midas_rrhh.i18n.edit + '</a> ');
          actions.append('<a href="#" class="button button-danger borrar-empleado" data-id="'+emp.id+'">' + midas_rrhh.i18n.delete + '</a>');
          fila.append(actions);
        }
        showSuccess(midas_rrhh.i18n.empleado_guardado);
        $('#modal-editar').fadeOut(); modalAbierto = false;
      } else {
        showError(response.data && response.data.message ? response.data.message : (response.data || 'Error desconocido'));
      }
    }).fail(function(xhr, status){
      if (xhr.responseText && xhr.responseText.trim().startsWith('<!DOCTYPE html>')) return;
      showError('Error al guardar empleado');
    }).always(function(){
      ajaxInProgress = false; $('#form-editar-empleado button[type="submit"]').prop('disabled', false);
    });
  });

  function buscarEmpleados(termino) {
    if (ajaxInProgress) return; ajaxInProgress = true;
    $.ajax({
      url: midas_rrhh.ajax_url, type:'POST', data:{ action:'midas_buscar_empleados', termino:termino, nonce:midas_rrhh.nonces.empleados }, dataType:'json'
    }).done(function(response){
      if (response.success) actualizarTablaEmpleados(response.data);
      else showError(response.data || 'Error desconocido al buscar empleados');
    }).fail(function(xhr, status, error){
      if (xhr.responseText && xhr.responseText.trim().startsWith('<!DOCTYPE html>')) return;
      if (status !== 'abort') { console.error('Error AJAX:', status, error); showError('Error en la comunicación con el servidor'); }
    }).always(function(){ ajaxInProgress = false; });
  }

  function abrirModalEmpleado(empleadoId) {
    if (modalAbierto) return; modalAbierto = true;
    if (empleadoId > 0) {
      $.ajax({
        url: midas_rrhh.ajax_url, type:'POST', data:{ action:'midas_obtener_empleado', empleado_id:empleadoId, nonce:midas_rrhh.nonces.empleados }, dataType:'json'
      }).done(function(response){
        if (response.success) {
          const d = response.data;
          $('#edit-id').val(d.id); $('#edit-nombre').val(d.nombre); $('#edit-apellido').val(d.apellido);
          $('#edit-dni').val(d.dni); $('#edit-cuil').val(d.cuil); $('#edit-email').val(d.email || '');
          $('#edit-telefono').val(d.telefono || ''); $('#edit-fecha_nacimiento').val(d.fecha_nacimiento || '');
          $('#edit-direccion').val(d.direccion || ''); $('#edit-estado_civil').val(d.estado_civil || '');
          $('#edit-fecha_inicio_laboral').val(d.fecha_inicio_laboral || ''); $('#edit-foto-id').val(d.foto_id || '');
          $('#foto-preview').attr('src', d.foto_url || ''); $('#modal-editar').fadeIn();
        } else { showError(response.data); modalAbierto = false; }
      }).fail(function(xhr){
        if (xhr.responseText && xhr.responseText.trim().startsWith('<!DOCTYPE html>')) return;
        showError('Error al obtener datos del empleado'); modalAbierto = false;
      });
    } else {
      $('#form-editar-empleado')[0].reset(); $('#edit-id').val(''); $('#modal-editar').fadeIn();
    }
  }

  function confirmarEliminarEmpleado(empleadoId) {
    if (!confirm(midas_rrhh.i18n.confirm_delete)) return;
    $.ajax({
      url: midas_rrhh.ajax_url, type:'POST', data:{ action:'midas_eliminar_empleado', empleado_id:empleadoId, nonce:midas_rrhh.nonces.empleados }, dataType:'json'
    }).done(function(response){
      if (response.success) { showSuccess(midas_rrhh.i18n.empleado_eliminado); buscarEmpleados(''); }
      else showError(response.data);
    }).fail(function(xhr){
      if (xhr.responseText && xhr.responseText.trim().startsWith('<!DOCTYPE html>')) return;
      showError('Error al eliminar empleado');
    });
  }

  function actualizarTablaEmpleados(empleados) {
    var tbody = $('.empleados-table tbody'); tbody.empty();
    if (!empleados || !empleados.length) {
      tbody.append('<tr><td colspan="6" class="no-results">' + midas_rrhh.i18n.no_results + '</td></tr>'); return;
    }
    $.each(empleados, function(_, empleado) {
      var row = $('<tr data-empleado-id="' + empleado.id + '">');
      row.append('<td>' + empleado.nombre + ' ' + empleado.apellido + '</td>');
      row.append('<td>' + empleado.dni + '</td>');
      row.append('<td>' + empleado.cuil + '</td>');
      row.append('<td>' + (empleado.area_nombre || '') + '</td>');
      row.append('<td>' + (empleado.tarea_nombre || '') + '</td>');
      var actions = $('<td>');
      actions.append('<a href="#" class="button editar-empleado" data-id="' + empleado.id + '">' + midas_rrhh.i18n.edit + '</a> ');
      actions.append('<a href="#" class="button button-danger borrar-empleado" data-id="' + empleado.id + '">' + midas_rrhh.i18n.delete + '</a>');
      row.append(actions); tbody.append(row);
    });
  }

  // ======================= UTILIDADES =======================
  function debounce(func, wait) {
    var t; return function(){ var ctx=this, args=arguments; clearTimeout(t); t=setTimeout(function(){ func.apply(ctx,args); }, wait); };
  }

  // ======================= CERRAR MODAL =======================
  $(document).on('click', '#modal-editar', function(e) {
    if ($(e.target).is('#modal-editar')) { $('#modal-editar').fadeOut(); modalAbierto = false; }
  });
});
