jQuery(document).ready(function($) {
    // Manejo de tabs
    $('.midas-tab-nav a').on('click', function(e) {
        e.preventDefault();
        
        // Obtener el ID del contenido de la pestaña
        var tabId = $(this).attr('href');
        
        // Marcar la pestaña como activa
        $(this).closest('.midas-tab-nav').find('a').removeClass('active');
        $(this).addClass('active');
        
        // Mostrar el contenido correspondiente
        $(this).closest('.midas-tabs').find('.midas-tab-content').removeClass('active');
        $(tabId).addClass('active');
    });
    
    // Manejo del datepicker
    $('.midas-datepicker').datepicker({
        dateFormat: 'yy-mm-dd',
        changeMonth: true,
        changeYear: true
    });
    
    // Solicitud de licencia
    $('#form-solicitar-licencia').on('submit', function(e) {
        e.preventDefault();
        
        var formData = new FormData(this);
        
        $.ajax({
            url: midas_rrhh.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            beforeSend: function() {
                // Mostrar spinner de carga
            },
            success: function(response) {
                if (response.success) {
                    // Mostrar mensaje de éxito y recargar
                    alert('Licencia solicitada correctamente');
                    location.reload();
                } else {
                    alert(response.data);
                }
            }
        });
    });
    
    // Aprobar licencia (para gestores)
    $('.aprobar-licencia').on('click', function() {
        var licenciaId = $(this).data('id');
        
        if (confirm('¿Estás seguro de aprobar esta licencia?')) {
            $.ajax({
                url: midas_rrhh.ajax_url,
                type: 'POST',
                data: {
                    action: 'midas_aprobar_licencia',
                    licencia_id: licenciaId,
                    nonce: midas_rrhh.nonces.licencias
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert(response.data);
                    }
                }
            });
        }
    });
    
    // Similar para otras acciones (rechazar licencia, aprobar documentos, etc.)
});

// Guardar y restaurar scroll en panel_gestor / panel_empleado
jQuery(function ($) {
  // --- helpers ---
  function getParamFromHref(href) {
    if (!href) return null;
    if (href.indexOf('panel_gestor=') !== -1) return 'panel_gestor';
    if (href.indexOf('panel_empleado=') !== -1) return 'panel_empleado';
    return null;
  }
  function getActiveParamFromURL() {
    var qs = window.location.search || '';
    if (qs.indexOf('panel_gestor=') !== -1) return 'panel_gestor';
    if (qs.indexOf('panel_empleado=') !== -1) return 'panel_empleado';
    return null;
  }

  function storageKey(p) { return 'midas_scroll_' + p + '_' + location.pathname; }

  function saveScroll(p, y) {
    if (!p) return;
    var val = (typeof y === 'number') ? y : window.scrollY || $(window).scrollTop();
    try { sessionStorage.setItem(storageKey(p), String(val)); } catch (e) {}
  }

  function restoreScroll() {
    var p = getActiveParamFromURL();
    if (!p) return;
    var v = sessionStorage.getItem(storageKey(p));
    if (v == null) return;
    var y = parseInt(v, 10) || 0;

    // Forzamos control manual del navegador para que no “salte”
    if ('scrollRestoration' in history) { history.scrollRestoration = 'manual'; }

    // Usamos doble rAF para asegurarnos que el layout terminó (tablas, imgs, etc.)
    requestAnimationFrame(function(){
      requestAnimationFrame(function(){
        window.scrollTo(0, y);
        try { sessionStorage.removeItem(storageKey(p)); } catch (e) {}
      });
    });
  }

  // --- guardar al hacer click en el sidebar ---
  $(document).on('click', '.midas-sidebar .midas-menu-item a', function () {
    var p = getParamFromHref(this.href);
    if (p) saveScroll(p);
  });

  // --- fallback: guardar si recarga/retrocede/avanza ---
  $(window).on('beforeunload', function () {
    var p = getActiveParamFromURL();
    if (p) saveScroll(p);
  });

  // --- restaurar al cargar ---
  restoreScroll();

  // ⬇️ opcional: usalo en tus AJAX en vez de location.reload()
  // window.midasReloadKeepingState = function() {
  //   var p = getActiveParamFromURL();
  //   if (p) saveScroll(p, window.scrollY);
  //   location.reload();
  // };
});
