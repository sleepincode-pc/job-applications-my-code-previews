// === BOTÓN MODO OSCURO SOLO EN DASHBOARD ===
(function () {
    const body = document.body;
    // Cambia esto según el slug o la URL de tu dashboard.
    // Por ejemplo, si tu dashboard está en admin.php?page=midas-dashboard:
    const isDashboard =
        window.location.href.includes('page=midas-dashboard') ||
        // Alternativamente, si usás un class o id especial en el dashboard:
        document.querySelector('.midas-rrhh-dashboard');

    // El botón solo se agrega si estamos en el dashboard
    if (isDashboard) {
        let btn = document.getElementById('btn-toggle-darkmode');
        let icon, label;

        if (!btn) {
            const h1 = document.querySelector('.wrap > h1');
            if (h1) {
                let btnContainer = document.getElementById('darkmode-btn-container');
                if (!btnContainer) {
                    btnContainer = document.createElement('div');
                    btnContainer.id = 'darkmode-btn-container';
                    btnContainer.style.position = 'absolute';
                    btnContainer.style.right = '0';
                    btnContainer.style.top = '4px';
                    btnContainer.style.transform = 'none';
                    btnContainer.style.zIndex = '10';
                    btnContainer.style.display = 'flex';
                    btnContainer.style.alignItems = 'flex-start';
                    h1.style.position = 'relative';
                    h1.appendChild(btnContainer);
                }

                btn = document.createElement('button');
                btn.id = 'btn-toggle-darkmode';
                btn.type = 'button';
                btn.title = 'Cambiar modo oscuro/claro';
                btn.setAttribute('aria-label', 'Cambiar modo oscuro/claro');
                btn.style.marginLeft = '8px';

                // Primero el icono
                icon = document.createElement('span');
                icon.id = 'icon-darkmode';
                icon.textContent = '🌙';

                // Luego el label a la derecha
                label = document.createElement('span');
                label.id = 'darkmode-label';

                btn.appendChild(icon);
                btn.appendChild(label); // TEXTO SIEMPRE A LA DERECHA DEL ICONO

                btnContainer.appendChild(btn);
            }
        } else {
            icon = btn.querySelector('#icon-darkmode');
            label = btn.querySelector('#darkmode-label');
            if (!icon) {
                icon = document.createElement('span');
                icon.id = 'icon-darkmode';
                icon.textContent = '🌙';
                btn.insertBefore(icon, btn.firstChild);
            }
            if (!label) {
                label = document.createElement('span');
                label.id = 'darkmode-label';
                btn.appendChild(label);
            }
        }

        function updateIcon() {
            if (body.classList.contains('dark')) {
                icon.textContent = '☀️';
                label.textContent = 'Activar modo claro';
            } else {
                icon.textContent = '🌙';
                label.textContent = 'Activar modo oscuro';
            }
        }

        // Estado inicial desde localStorage
        if (localStorage.getItem('midas_darkmode') === 'true') {
            body.classList.add('dark');
        } else {
            body.classList.remove('dark');
        }
        updateIcon();

        if (btn) {
            btn.addEventListener('click', function () {
                body.classList.toggle('dark');
                const isDark = body.classList.contains('dark');
                localStorage.setItem('midas_darkmode', isDark);
                updateIcon();
            });
        }
    } else {
        // SIEMPRE aplicar dark mode si estaba guardado, aunque no esté el botón
        if (localStorage.getItem('midas_darkmode') === 'true') {
            body.classList.add('dark');
        } else {
            body.classList.remove('dark');
        }
    }
})();
