<?php
// Campos para Sesiones Psicológicas
function ac_definir_campos_sesion_psicologica() {
    return array(
        'fecha_sesion' => array(
            'type' => 'date',
            'label' => 'Fecha de Sesión',
            'required' => true
        ),
        'hora_inicio' => array(
            'type' => 'time',
            'label' => 'Hora de Inicio'
        ),
        'hora_fin' => array(
            'type' => 'time',
            'label' => 'Hora de Fin'
        ),
        'tipo_sesion' => array(
            'type' => 'select',
            'label' => 'Tipo de Sesión',
            'options' => array(
                'individual' => 'Individual',
                'grupal' => 'Grupal',
                'pareja' => 'Pareja',
                'familiar' => 'Familiar'
            )
        ),
        'modalidad' => array(
            'type' => 'select',
            'label' => 'Modalidad',
            'options' => array(
                'presencial' => 'Presencial',
                'virtual' => 'Virtual',
                'telefonica' => 'Telefónica'
            )
        ),
        'objetivos_sesion' => array(
            'type' => 'textarea',
            'label' => 'Objetivos de la Sesión'
        ),
        'temas_abordados' => array(
            'type' => 'textarea',
            'label' => 'Temas Abordados',
            'required' => true
        ),
        'tecnicas_aplicadas' => array(
            'type' => 'textarea',
            'label' => 'Técnicas Aplicadas'
        ),
        'observaciones_conducta' => array(
            'type' => 'textarea',
            'label' => 'Observaciones de Conducta'
        ),
        'afecto_humor' => array(
            'type' => 'textarea',
            'label' => 'Afecto y Estado de Ánimo'
        ),
        'cogniciones_identificadas' => array(
            'type' => 'textarea',
            'label' => 'Cogniciones Identificadas'
        ),
        'intervenciones_realizadas' => array(
            'type' => 'textarea',
            'label' => 'Intervenciones Realizadas'
        ),
        'respuesta_intervenciones' => array(
            'type' => 'textarea',
            'label' => 'Respuesta a las Intervenciones'
        ),
        'avances_cambios' => array(
            'type' => 'textarea',
            'label' => 'Avances y Cambios Observados'
        ),
        'dificultades_obstaculos' => array(
            'type' => 'textarea',
            'label' => 'Dificultades y Obstáculos'
        ),
        'tareas_entre_sesiones' => array(
            'type' => 'textarea',
            'label' => 'Tareas Entre Sesiones'
        ),
        'objetivos_proxima_sesion' => array(
            'type' => 'textarea',
            'label' => 'Objetivos para Próxima Sesión'
        ),
        'observaciones_adicionales' => array(
            'type' => 'textarea',
            'label' => 'Observaciones Adicionales'
        )
    );
}
?>