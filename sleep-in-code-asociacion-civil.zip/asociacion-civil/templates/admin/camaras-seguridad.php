<?php
if (!defined('ABSPATH')) {
    exit;
}

// Verificar que $camaras esté definida y sea un array
if (!isset($camaras) || !is_array($camaras)) {
    $camaras = array();
}

// Verificar que $registros esté definida y sea un array  
if (!isset($registros) || !is_array($registros)) {
    $registros = array();
}

// Manejar exportaciones
if (isset($_GET['export'])) {
    $export_type = $_GET['export'];
    
    if ($export_type === 'csv') {
        ac_exportar_camaras_csv($camaras);
    } elseif ($export_type === 'pdf') {
        ac_exportar_camaras_pdf($camaras);
    } elseif ($export_type === 'pdf_individual' && isset($_GET['id'])) {
        $camara_id = intval($_GET['id']);
        $camara_individual = null;
        
        foreach ($camaras as $camara) {
            if ($camara->getId() === $camara_id) {
                $camara_individual = $camara;
                break;
            }
        }
        
        if ($camara_individual) {
            ac_exportar_camara_pdf_individual($camara_individual);
        }
    }
}

// Funciones de exportación para cámaras
function ac_exportar_camaras_csv($camaras) {
    $filename = 'camaras_seguridad_' . date('Y-m-d') . '.csv';
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $output = fopen('php://output', 'w');
    fputs($output, "\xEF\xBB\xBF");
    
    // Encabezados
    fputcsv($output, array(
        'ID', 'Nombre', 'Ubicación', 'Tipo', 'Modelo', 'IP', 'Estado', 
        'Fecha Instalación', 'Último Mantenimiento', 'Próximo Mantenimiento'
    ), ';');
    
    // Datos
    foreach ($camaras as $camara) {
        if (is_object($camara) && method_exists($camara, 'getNombre')) {
            fputcsv($output, array(
                $camara->getId(),
                $camara->getNombre(),
                $camara->getUbicacion(),
                $camara->getTipo(),
                $camara->getModelo(),
                $camara->getIp(),
                $camara->getEstado(),
                $camara->getFechaInstalacion(),
                $camara->getUltimoMantenimiento(),
                $camara->getProximoMantenimiento()
            ), ';');
        }
    }
    
    fclose($output);
    exit;
}

function ac_exportar_camaras_pdf($camaras) {
    $filename = 'camaras_seguridad_' . date('Y-m-d') . '.pdf';
    
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Reporte de Cámaras de Seguridad</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { text-align: center; color: #333; }
            h2 { color: #0073aa; background-color: #f8f9fa; padding: 10px; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .section { margin-bottom: 30px; border: 1px solid #ddd; padding: 15px; }
            .camara-info { background-color: #f0f8ff; }
            .configuracion { border-color: #46b450; background-color: #f0fff0; }
            .estado-activa { color: #46b450; font-weight: bold; }
            .estado-inactiva { color: #dc3232; font-weight: bold; }
            .estado-mantenimiento { color: #ffb900; font-weight: bold; }
        </style>
    </head>
    <body>
        <h1>Reporte de Cámaras de Seguridad</h1>
        <p style="text-align: center;">Exportado el: ' . date('d/m/Y H:i:s') . '</p>
        <p style="text-align: center;">Total de cámaras: ' . count($camaras) . '</p>
        <hr>';
    
    foreach ($camaras as $index => $camara) {
        if (is_object($camara) && method_exists($camara, 'getNombre')) {
            $estado_class = 'estado-' . $camara->getEstado();
            
            $html .= '<div class="section camara-info">
                <h2>Cámara #' . ($index + 1) . ' - ' . $camara->getNombre() . '</h2>
                <table>
                    <tr><td style="width: 30%; font-weight: bold;">Ubicación:</td><td>' . $camara->getUbicacion() . '</td></tr>
                    <tr><td style="font-weight: bold;">Tipo:</td><td>' . $camara->getTipo() . '</td></tr>
                    <tr><td style="font-weight: bold;">Modelo:</td><td>' . $camara->getModelo() . '</td></tr>
                    <tr><td style="font-weight: bold;">IP/Dirección:</td><td>' . $camara->getIp() . '</td></tr>
                    <tr><td style="font-weight: bold;">Estado:</td><td class="' . $estado_class . '">' . $camara->getEstado() . '</td></tr>
                    <tr><td style="font-weight: bold;">Fecha Instalación:</td><td>' . ($camara->getFechaInstalacion() ? date('d/m/Y', strtotime($camara->getFechaInstalacion())) : 'No especificada') . '</td></tr>
                </table>';
            
            if ($camara->getUltimoMantenimiento() || $camara->getProximoMantenimiento()) {
                $html .= '<h4>Mantenimiento:</h4>
                <table>
                    <tr><td style="width: 30%; font-weight: bold;">Último Mantenimiento:</td><td>' . ($camara->getUltimoMantenimiento() ? date('d/m/Y', strtotime($camara->getUltimoMantenimiento())) : 'No registrado') . '</td></tr>
                    <tr><td style="font-weight: bold;">Próximo Mantenimiento:</td><td>' . ($camara->getProximoMantenimiento() ? date('d/m/Y', strtotime($camara->getProximoMantenimiento())) : 'No programado') . '</td></tr>
                </table>';
            }
            
            if ($camara->getObservaciones()) {
                $html .= '<h4>Observaciones:</h4>
                <div style="border: 1px solid #46b450; padding: 10px; background-color: #f0fff0;">
                    ' . nl2br($camara->getObservaciones()) . '
                </div>';
            }
            
            if ($camara->getUrlStream()) {
                $html .= '<h4>Enlace de Stream:</h4>
                <div style="border: 1px solid #ffb900; padding: 10px; background-color: #fff8e7;">
                    <a href="' . $camara->getUrlStream() . '" target="_blank">' . $camara->getUrlStream() . '</a>
                </div>';
            }
            
            $html .= '</div><hr style="margin: 20px 0;">';
        }
    }
    
    $html .= '</body></html>';
    
    echo $html;
    exit;
}

function ac_exportar_camara_pdf_individual($camara) {
    $filename = 'camara_' . sanitize_title($camara->getNombre()) . '_' . date('Y-m-d') . '.pdf';
    
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $estado_class = 'estado-' . $camara->getEstado();
    
    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Cámara de Seguridad - ' . $camara->getNombre() . '</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 30px; line-height: 1.6; }
            h1 { text-align: center; color: #333; margin-bottom: 10px; }
            h2 { text-align: center; color: #0073aa; margin-bottom: 30px; }
            .header-info { margin-bottom: 30px; }
            .info-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            .info-table td { padding: 8px; border-bottom: 1px solid #eee; }
            .info-table td:first-child { font-weight: bold; width: 35%; }
            .section { margin-bottom: 25px; }
            .section-title { color: #555; border-bottom: 2px solid #0073aa; padding-bottom: 5px; margin-bottom: 10px; }
            .content-box { border: 1px solid #ddd; padding: 15px; background-color: #f9f9f9; margin-bottom: 15px; }
            .configuracion-box { border-color: #46b450; background-color: #f0fff0; }
            .mantenimiento-box { border-color: #ffb900; background-color: #fff8e7; }
            .estado-activa { color: #46b450; font-weight: bold; }
            .estado-inactiva { color: #dc3232; font-weight: bold; }
            .estado-mantenimiento { color: #ffb900; font-weight: bold; }
            .footer { text-align: center; margin-top: 40px; color: #666; font-size: 12px; }
        </style>
    </head>
    <body>
        <h1>INFORME DE CÁMARA DE SEGURIDAD</h1>
        <h2>' . $camara->getNombre() . '</h2>
        
        <div class="header-info">
            <table class="info-table">
                <tr>
                    <td>Ubicación:</td>
                    <td>' . $camara->getUbicacion() . '</td>
                </tr>
                <tr>
                    <td>Tipo:</td>
                    <td>' . $camara->getTipo() . '</td>
                </tr>
                <tr>
                    <td>Modelo:</td>
                    <td>' . $camara->getModelo() . '</td>
                </tr>
                <tr>
                    <td>Estado:</td>
                    <td class="' . $estado_class . '">' . $camara->getEstado() . '</td>
                </tr>
                <tr>
                    <td>Fecha de Instalación:</td>
                    <td>' . ($camara->getFechaInstalacion() ? date('d/m/Y', strtotime($camara->getFechaInstalacion())) : 'No especificada') . '</td>
                </tr>
            </table>
        </div>';
    
    if ($camara->getIp() || $camara->getPuerto()) {
        $html .= '<div class="section">
            <h3 class="section-title">CONFIGURACIÓN DE RED</h3>
            <div class="content-box configuracion-box">
                <table class="info-table">
                    <tr><td style="width: 40%;">Dirección IP:</td><td>' . ($camara->getIp() ? $camara->getIp() : 'No configurada') . '</td></tr>
                    <tr><td>Puerto:</td><td>' . ($camara->getPuerto() ? $camara->getPuerto() : 'No configurado') . '</td></tr>
                    <tr><td>Usuario:</td><td>' . ($camara->getUsuario() ? $camara->getUsuario() : 'No configurado') . '</td></tr>
                </table>
            </div>
        </div>';
    }
    
    if ($camara->getUltimoMantenimiento() || $camara->getProximoMantenimiento()) {
        $html .= '<div class="section">
            <h3 class="section-title">HISTORIAL DE MANTENIMIENTO</h3>
            <div class="content-box mantenimiento-box">
                <table class="info-table">
                    <tr><td style="width: 40%;">Último Mantenimiento:</td><td>' . ($camara->getUltimoMantenimiento() ? date('d/m/Y', strtotime($camara->getUltimoMantenimiento())) : 'No registrado') . '</td></tr>
                    <tr><td>Próximo Mantenimiento:</td><td>' . ($camara->getProximoMantenimiento() ? date('d/m/Y', strtotime($camara->getProximoMantenimiento())) : 'No programado') . '</td></tr>
                </table>
            </div>
        </div>';
    }
    
    if ($camara->getObservaciones()) {
        $html .= '<div class="section">
            <h3 class="section-title">OBSERVACIONES</h3>
            <div class="content-box">' . nl2br($camara->getObservaciones()) . '</div>
        </div>';
    }
    
    if ($camara->getUrlStream()) {
        $html .= '<div class="section">
            <h3 class="section-title">ENLACES DE ACCESO</h3>
            <div class="content-box">
                <p><strong>Stream en Vivo:</strong></p>
                <p><a href="' . $camara->getUrlStream() . '" target="_blank">' . $camara->getUrlStream() . '</a></p>';
        
        if ($camara->getUrlSnapshot()) {
            $html .= '<p><strong>Captura Instantánea:</strong></p>
                <p><a href="' . $camara->getUrlSnapshot() . '" target="_blank">' . $camara->getUrlSnapshot() . '</a></p>';
        }
        
        $html .= '</div>
        </div>';
    }
    
    $html .= '<div class="footer">
            Documento generado el ' . date('d/m/Y H:i:s') . '<br>
            ' . get_bloginfo('name') . ' - Sistema de Seguridad
        </div>
    </body>
    </html>';
    
    echo $html;
    exit;
}

// Manejar guardado de cámara desde formulario
if (isset($_POST['guardar_camara'])) {
    ac_guardar_camara_seguridad();
}

function ac_guardar_camara_seguridad() {
    // Verificar nonce para seguridad
    if (!wp_verify_nonce($_POST['_wpnonce'], 'guardar_camara_seguridad')) {
        wp_die('Error de seguridad');
    }
    
    $nombre = sanitize_text_field($_POST['nombre']);
    $ubicacion = sanitize_text_field($_POST['ubicacion']);
    $tipo = sanitize_text_field($_POST['tipo']);
    $modelo = sanitize_text_field($_POST['modelo']);
    $ip = sanitize_text_field($_POST['ip']);
    $puerto = intval($_POST['puerto']);
    $usuario = sanitize_text_field($_POST['usuario']);
    $password = sanitize_text_field($_POST['password']);
    $url_stream = sanitize_text_field($_POST['url_stream']);
    $url_snapshot = sanitize_text_field($_POST['url_snapshot']);
    $estado = sanitize_text_field($_POST['estado']);
    $observaciones = sanitize_textarea_field($_POST['observaciones']);
    $fecha_instalacion = sanitize_text_field($_POST['fecha_instalacion']);
    $ultimo_mantenimiento = sanitize_text_field($_POST['ultimo_mantenimiento']);
    $proximo_mantenimiento = sanitize_text_field($_POST['proximo_mantenimiento']);
    
    // Aquí deberías llamar a tu función para guardar la cámara en la base de datos
    // Por ejemplo:
    // $camara_id = guardar_camara($nombre, $ubicacion, $tipo, $modelo, $ip, $puerto, $usuario, $password, $url_stream, $url_snapshot, $estado, $observaciones, $fecha_instalacion, $ultimo_mantenimiento, $proximo_mantenimiento);
    
    // Simulación de guardado exitoso
    $guardado_exitoso = true;
    
    if ($guardado_exitoso) {
        echo '<div class="notice notice-success is-dismissible">';
        echo '<p>✅ Cámara de seguridad guardada correctamente.</p>';
        echo '</div>';
        
        // Redirigir para evitar reenvío del formulario
        echo '<script>setTimeout(function() { window.location.href = "' . admin_url('admin.php?page=ac-camaras-seguridad') . '"; }, 2000);</script>';
    } else {
        echo '<div class="notice notice-error is-dismissible">';
        echo '<p>❌ Error al guardar la cámara. Por favor, inténtalo de nuevo.</p>';
        echo '</div>';
    }
}

// Manejar importación CSV
if (isset($_POST['importar_csv'])) {
    ac_importar_csv_camaras();
}

function ac_importar_csv_camaras() {
    if (!empty($_FILES['csv_file']['tmp_name'])) {
        $file = $_FILES['csv_file']['tmp_name'];
        $handle = fopen($file, 'r');
        
        if ($handle !== FALSE) {
            $importados = 0;
            $errores = 0;
            $primera_linea = true;
            
            while (($data = fgetcsv($handle, 1000, ';')) !== FALSE) {
                if ($primera_linea) {
                    $primera_linea = false;
                    continue;
                }
                
                if (count($data) >= 5) {
                    $nombre = sanitize_text_field($data[1]);
                    $ubicacion = sanitize_text_field($data[2]);
                    $tipo = sanitize_text_field($data[3]);
                    $modelo = sanitize_text_field($data[4]);
                    $ip = isset($data[5]) ? sanitize_text_field($data[5]) : '';
                    $estado = isset($data[6]) ? sanitize_text_field($data[6]) : 'activa';
                    $fecha_instalacion = isset($data[7]) ? sanitize_text_field($data[7]) : '';
                    $ultimo_mantenimiento = isset($data[8]) ? sanitize_text_field($data[8]) : '';
                    $proximo_mantenimiento = isset($data[9]) ? sanitize_text_field($data[9]) : '';
                    
                    $importados++;
                } else {
                    $errores++;
                }
            }
            
            fclose($handle);
            
            echo '<div class="notice notice-success is-dismissible">';
            echo '<p>Importación completada: ' . $importados . ' cámaras importadas correctamente. ' . $errores . ' errores.</p>';
            echo '</div>';
        }
    }
}

// Manejar guardado de cámara desde OCR
if (isset($_POST['guardar_camara_ocr'])) {
    ac_guardar_camara_ocr();
}

function ac_guardar_camara_ocr() {
    // Verificar nonce para seguridad
    if (!wp_verify_nonce($_POST['_wpnonce'], 'guardar_camara_ocr')) {
        wp_die('Error de seguridad');
    }
    
    $nombre = sanitize_text_field($_POST['nombre']);
    $ubicacion = sanitize_text_field($_POST['ubicacion']);
    $tipo = sanitize_text_field($_POST['tipo']);
    $modelo = sanitize_text_field($_POST['modelo']);
    $ip = sanitize_text_field($_POST['ip']);
    $puerto = intval($_POST['puerto']);
    $usuario = sanitize_text_field($_POST['usuario']);
    $password = sanitize_text_field($_POST['password']);
    $url_stream = sanitize_text_field($_POST['url_stream']);
    $url_snapshot = sanitize_text_field($_POST['url_snapshot']);
    $estado = sanitize_text_field($_POST['estado']);
    $observaciones = sanitize_textarea_field($_POST['observaciones']);
    $fecha_instalacion = sanitize_text_field($_POST['fecha_instalacion']);
    $ultimo_mantenimiento = sanitize_text_field($_POST['ultimo_mantenimiento']);
    $proximo_mantenimiento = sanitize_text_field($_POST['proximo_mantenimiento']);
    
    // Simulación de guardado exitoso
    $guardado_exitoso = true;
    
    if ($guardado_exitoso) {
        echo '<div class="notice notice-success is-dismissible">';
        echo '<p>✅ Cámara guardada correctamente a partir del texto extraído.</p>';
        echo '</div>';
        
        // Redirigir para evitar reenvío del formulario
        echo '<script>setTimeout(function() { window.location.href = "' . admin_url('admin.php?page=ac-camaras-seguridad') . '"; }, 2000);</script>';
    } else {
        echo '<div class="notice notice-error is-dismissible">';
        echo '<p>❌ Error al guardar la cámara. Por favor, inténtalo de nuevo.</p>';
        echo '</div>';
    }
}

// Si estamos en el proceso de OCR, mostrar el formulario de edición
if (isset($_GET['ocr_edit'])) {
    ac_mostrar_formulario_edicion_ocr_camaras();
    return;
}

function ac_mostrar_formulario_edicion_ocr_camaras() {
    $texto_extraido = isset($_GET['texto']) ? base64_decode($_GET['texto']) : '';
    ?>
    <div class="wrap">
        <h1>📷 Revisar Texto Extraído de Documento de Cámara</h1>
        
        <div class="notice notice-info">
            <p>Revisa y edita el texto extraído del documento antes de guardar la cámara. Corrige cualquier error en el reconocimiento de texto.</p>
        </div>
        
        <form method="post" action="<?php echo admin_url('admin.php?page=ac-camaras-seguridad'); ?>">
            <?php wp_nonce_field('guardar_camara_ocr'); ?>
            <input type="hidden" name="guardar_camara_ocr" value="1">
            
            <div class="ac-ocr-form-container" style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                <!-- Columna izquierda: Campos de la cámara -->
                <div class="ac-ocr-campos">
                    <h3>Información de la Cámara</h3>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="nombre">Nombre de la Cámara *</label>
                            </th>
                            <td>
                                <input type="text" id="nombre" name="nombre" class="regular-text" 
                                       value="Cámara Extraída - <?php echo date('d/m/Y'); ?>" required>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ubicacion">Ubicación *</label>
                            </th>
                            <td>
                                <input type="text" id="ubicacion" name="ubicacion" class="regular-text" 
                                       placeholder="Ej: Recepción, Estacionamiento, Sala de Servidores..." required>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="tipo">Tipo de Cámara *</label>
                            </th>
                            <td>
                                <select id="tipo" name="tipo" class="regular-text" required>
                                    <option value="IP">Cámara IP</option>
                                    <option value="Analogica">Cámara Analógica</option>
                                    <option value="WiFi">Cámara WiFi</option>
                                    <option value="PTZ">Cámara PTZ</option>
                                    <option value="Domo">Cámara Domo</option>
                                    <option value="Bullet">Cámara Bullet</option>
                                    <option value="Otro">Otro</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="modelo">Modelo</label>
                            </th>
                            <td>
                                <input type="text" id="modelo" name="modelo" class="regular-text" 
                                       placeholder="Ej: DS-2CD2143G0-I, Hikvision DS-2DE...">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ip">Dirección IP</label>
                            </th>
                            <td>
                                <input type="text" id="ip" name="ip" class="regular-text" 
                                       placeholder="192.168.1.100">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="estado">Estado</label>
                            </th>
                            <td>
                                <select id="estado" name="estado" class="regular-text">
                                    <option value="activa">Activa</option>
                                    <option value="inactiva">Inactiva</option>
                                    <option value="mantenimiento">En Mantenimiento</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                    
                    <h3 style="margin-top: 30px;">Configuración y Mantenimiento</h3>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="url_stream">URL de Stream</label>
                            </th>
                            <td>
                                <input type="url" id="url_stream" name="url_stream" class="regular-text" 
                                       placeholder="rtsp://... o http://...">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="fecha_instalacion">Fecha de Instalación</label>
                            </th>
                            <td>
                                <input type="date" id="fecha_instalacion" name="fecha_instalacion" class="regular-text" 
                                       value="<?php echo date('Y-m-d'); ?>">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="proximo_mantenimiento">Próximo Mantenimiento</label>
                            </th>
                            <td>
                                <input type="date" id="proximo_mantenimiento" name="proximo_mantenimiento" class="regular-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="observaciones">Observaciones</label>
                            </th>
                            <td>
                                <textarea id="observaciones" name="observaciones" rows="4" class="large-text" 
                                          placeholder="Notas adicionales sobre la cámara..."></textarea>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Columna derecha: Texto extraído para referencia -->
                <div class="ac-ocr-texto-original">
                    <h3>Texto Extraído (Solo referencia)</h3>
                    <div style="background: #f6f6f6; border: 1px solid #ddd; border-radius: 4px; padding: 15px; max-height: 600px; overflow-y: auto;">
                        <pre style="white-space: pre-wrap; font-family: 'Courier New', monospace; font-size: 12px; line-height: 1.4; margin: 0; color: #333;"><?php echo esc_html($texto_extraido); ?></pre>
                    </div>
                    <p class="description" style="margin-top: 10px;">
                        <strong>Nota:</strong> Este es el texto crudo extraído por el OCR. Úsalo como referencia para completar los campos del formulario.
                    </p>
                    
                    <div style="margin-top: 20px; padding: 15px; background: #fff8e7; border-radius: 4px; border-left: 4px solid #ffb900;">
                        <h4 style="margin-top: 0; color: #cc8500;">💡 Sugerencias para Cámaras</h4>
                        <ul style="margin: 10px 0; padding-left: 20px; font-size: 13px;">
                            <li>Verifica direcciones IP y puertos</li>
                            <li>Revisa modelos y especificaciones técnicas</li>
                            <li>Corrige URLs de stream y acceso</li>
                            <li>Verifica fechas de instalación y mantenimiento</li>
                            <li>Revisa la ortografía de ubicaciones</li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <p class="submit">
                <button type="submit" class="button button-primary button-large">
                    <span class="dashicons dashicons-yes" style="margin-top: 4px;"></span>
                    Guardar Cámara
                </button>
                <a href="<?php echo admin_url('admin.php?page=ac-camaras-seguridad'); ?>" class="button button-large">
                    <span class="dashicons dashicons-no" style="margin-top: 4px;"></span>
                    Cancelar
                </a>
            </p>
        </form>
        
        <style>
        .ac-ocr-form-container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .ac-ocr-campos {
            border-right: 1px solid #eee;
            padding-right: 20px;
        }
        .ac-ocr-texto-original {
            padding-left: 20px;
        }
        .large-text {
            width: 100%;
            max-width: 100%;
        }
        @media (max-width: 1200px) {
            .ac-ocr-form-container {
                grid-template-columns: 1fr !important;
            }
            .ac-ocr-campos {
                border-right: none;
                border-bottom: 1px solid #eee;
                padding-right: 0;
                padding-bottom: 20px;
                margin-bottom: 20px;
            }
            .ac-ocr-texto-original {
                padding-left: 0;
            }
        }
        </style>
    </div>
    <?php
    exit;
}

// Mensajes de éxito
$mensajes = array();
if (isset($_GET['updated'])) {
    $mensajes[] = 'Cámara guardada correctamente.';
}
if (isset($_GET['deleted'])) {
    $mensajes[] = 'Cámara eliminada correctamente.';
}
if (isset($_GET['created'])) {
    $mensajes[] = 'Cámara creada correctamente.';
}

// =============================================
// ESTADÍSTICAS AVANZADAS PARA CÁMARAS (IGUAL QUE ACTAS)
// =============================================

$total_camaras = count($camaras);
$tipos_camara = array();
$camaras_por_mes = array();
$camaras_por_año = array();
$camaras_por_quincena = array();
$camara_mas_reciente = null;
$camara_mas_antigua = null;
$camaras_con_mantenimiento = 0;
$total_ubicaciones = 0;

foreach ($camaras as $camara) {
    if (is_object($camara) && method_exists($camara, 'getTipo')) {
        // Por tipo
        $tipo = $camara->getTipo();
        if (!isset($tipos_camara[$tipo])) {
            $tipos_camara[$tipo] = 0;
        }
        $tipos_camara[$tipo]++;
        
        // Por mes
        $fecha = $camara->getFechaInstalacion();
        if ($fecha) {
            $mes = date('Y-m', strtotime($fecha));
            if (!isset($camaras_por_mes[$mes])) {
                $camaras_por_mes[$mes] = 0;
            }
            $camaras_por_mes[$mes]++;
            
            // Por año
            $año = date('Y', strtotime($fecha));
            if (!isset($camaras_por_año[$año])) {
                $camaras_por_año[$año] = 0;
            }
            $camaras_por_año[$año]++;
            
            // Por quincena
            $dia = date('j', strtotime($fecha));
            $quincena = ($dia <= 15) ? '1' : '2';
            $quincena_key = date('Y-m', strtotime($fecha)) . '-Q' . $quincena;
            if (!isset($camaras_por_quincena[$quincena_key])) {
                $camaras_por_quincena[$quincena_key] = 0;
            }
            $camaras_por_quincena[$quincena_key]++;
            
            // Fechas extremas
            if (!$camara_mas_reciente || strtotime($fecha) > strtotime($camara_mas_reciente->getFechaInstalacion())) {
                $camara_mas_reciente = $camara;
            }
            if (!$camara_mas_antigua || strtotime($fecha) < strtotime($camara_mas_antigua->getFechaInstalacion())) {
                $camara_mas_antigua = $camara;
            }
        }
        
        // Cámaras con mantenimiento programado
        if ($camara->getProximoMantenimiento()) {
            $camaras_con_mantenimiento++;
        }
        
        // Ubicaciones únicas
        if ($camara->getUbicacion()) {
            $total_ubicaciones++;
        }
    }
}

// Ordenar estadísticas
arsort($tipos_camara);
krsort($camaras_por_mes);
krsort($camaras_por_año);
krsort($camaras_por_quincena);

// Calcular porcentajes
$porcentaje_con_mantenimiento = $total_camaras > 0 ? round(($camaras_con_mantenimiento / $total_camaras) * 100) : 0;

// Quincena actual y anterior para comparación
$fecha_actual = date('Y-m-d');
$dia_actual = date('j');
$quincena_actual = ($dia_actual <= 15) ? '1' : '2';
$quincena_actual_key = date('Y-m') . '-Q' . $quincena_actual;

// Calcular quincena anterior
if ($quincena_actual == '1') {
    $mes_anterior = date('Y-m', strtotime('-1 month'));
    $quincena_anterior_key = $mes_anterior . '-Q2';
} else {
    $quincena_anterior_key = date('Y-m') . '-Q1';
}

$camaras_quincena_actual = $camaras_por_quincena[$quincena_actual_key] ?? 0;
$camaras_quincena_anterior = $camaras_por_quincena[$quincena_anterior_key] ?? 0;

// Calcular tendencia por quincena
if ($camaras_quincena_anterior > 0) {
    $tendencia = (($camaras_quincena_actual - $camaras_quincena_anterior) / $camaras_quincena_anterior) * 100;
    $tendencia_texto = $tendencia >= 0 ? '↗ Aumentando' : '↘ Disminuyendo';
    $tendencia_color = $tendencia >= 0 ? '#46b450' : '#dc3232';
} else {
    $tendencia_texto = '→ Estable';
    $tendencia_color = '#ffb900';
}

// Función para formatear nombre de quincena
function formatear_quincena($quincena_key) {
    $partes = explode('-', $quincena_key);
    $año = $partes[0];
    $mes = $partes[1];
    $quincena_num = substr($partes[2], 1);
    
    $meses = array(
        '01' => 'Ene', '02' => 'Feb', '03' => 'Mar', '04' => 'Abr',
        '05' => 'May', '06' => 'Jun', '07' => 'Jul', '08' => 'Ago',
        '09' => 'Sep', '10' => 'Oct', '11' => 'Nov', '12' => 'Dic'
    );
    
    return $quincena_num . '°Q ' . $meses[$mes] . ' ' . $año;
}

// Manejar selección de métricas y gráficos
$metricas_seleccionadas = isset($_GET['metricas']) ? $_GET['metricas'] : 'mes';
$tipo_grafico_seleccionado = isset($_GET['tipo_grafico']) ? $_GET['tipo_grafico'] : 'barras';

// Función para obtener los últimos 6 meses
function obtener_ultimos_6_meses() {
    $meses = [];
    for ($i = 5; $i >= 0; $i--) {
        $meses[] = date('Y-m', strtotime("-$i months"));
    }
    return $meses;
}

// Preparar datos para el gráfico de los últimos 6 meses
function preparar_datos_ultimos_6_meses($camaras_por_mes) {
    $ultimos_6_meses = obtener_ultimos_6_meses();
    $datos_completos = [];
    
    foreach ($ultimos_6_meses as $mes) {
        $meses_es = [
            '01' => 'Ene', '02' => 'Feb', '03' => 'Mar', '04' => 'Abr',
            '05' => 'May', '06' => 'Jun', '07' => 'Jul', '08' => 'Ago',
            '09' => 'Sep', '10' => 'Oct', '11' => 'Nov', '12' => 'Dic'
        ];
        
        $partes = explode('-', $mes);
        $año = $partes[0];
        $mes_num = $partes[1];
        $etiqueta = $meses_es[$mes_num] . ' ' . $año;
        
        $datos_completos[$etiqueta] = $camaras_por_mes[$mes] ?? 0;
    }
    
    return $datos_completos;
}

// Preparar datos para AJAX
$datos_grafico_json = array();
$datos_grafico_json['quincena'] = array();
$datos_grafico_json['mes'] = preparar_datos_ultimos_6_meses($camaras_por_mes);
$datos_grafico_json['año'] = $camaras_por_año;
$datos_grafico_json['tipo'] = $tipos_camara;

// Preparar datos de quincena
$datos_quincena = array_slice($camaras_por_quincena, 0, 6, true);
foreach ($datos_quincena as $key => $valor) {
    $datos_grafico_json['quincena'][formatear_quincena($key)] = $valor;
}

?>

<div class="wrap">
    <h1 class="wp-heading-inline">📹 Cámaras de Seguridad</h1>
    
    <?php if (!empty($mensajes)): ?>
        <?php foreach ($mensajes as $mensaje): ?>
            <div class="notice notice-success is-dismissible">
                <p><?php echo esc_html($mensaje); ?></p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <!-- ============================================= -->
    <!-- PANEL DE MÉTRICAS AVANZADAS (IGUAL QUE ACTAS) -->
    <!-- ============================================= -->
    
    <div class="ac-metrics-panel" style="margin: 20px 0;">
        <h2 style="margin-bottom: 15px; color: #23282d;">📊 Métricas del Sistema de Cámaras</h2>
        
        <div class="ac-stats-container" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; margin-bottom: 20px;">
            <!-- Métrica Principal -->
            <div class="ac-stat-card" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="display: flex; justify-content: between; align-items: center;">
                    <div>
                        <h3 style="margin: 0 0 5px 0; font-size: 14px; opacity: 0.9;">TOTAL DE CÁMARAS</h3>
                        <p style="font-size: 32px; font-weight: bold; margin: 0;">📹 <?php echo $total_camaras; ?></p>
                    </div>
                    <div style="font-size: 24px;">📹</div>
                </div>
                <div style="margin-top: 10px; font-size: 12px; opacity: 0.8;">
                    <?php echo $camaras_quincena_actual; ?> esta quincena • 
                    <span style="color: <?php echo $tendencia_color; ?>"><?php echo $tendencia_texto; ?></span>
                </div>
            </div>

            <!-- Distribución por Tipo -->
            <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #46b450; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #46b450; font-size: 14px;">DISTRIBUCIÓN POR TIPO</h3>
                <div style="max-height: 120px; overflow-y: auto;">
                    <?php foreach ($tipos_camara as $tipo => $cantidad): 
                        $porcentaje = $total_camaras > 0 ? round(($cantidad / $total_camaras) * 100) : 0;
                    ?>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                        <span><?php echo esc_html($tipo); ?></span>
                        <span style="font-weight: bold;"><?php echo $cantidad; ?> (<?php echo $porcentaje; ?>%)</span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Estadísticas de Mantenimiento -->
            <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #ffb900; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #ffb900; font-size: 14px;">MANTENIMIENTO</h3>
                <div style="display: grid; gap: 8px;">
                    <div style="display: flex; justify-content: space-between;">
                        <span>Con mantenimiento:</span>
                        <strong><?php echo $camaras_con_mantenimiento; ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Porcentaje:</span>
                        <strong><?php echo $porcentaje_con_mantenimiento; ?>%</strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Ubicaciones:</span>
                        <strong><?php echo $total_ubicaciones; ?></strong>
                    </div>
                </div>
            </div>

            <!-- Rango de Fechas -->
            <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #dc3232; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #dc3232; font-size: 14px;">RANGO TEMPORAL</h3>
                <div style="display: grid; gap: 8px; font-size: 12px;">
                    <?php if ($camara_mas_reciente): ?>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Más reciente:</span>
                        <strong><?php echo date('d/m/Y', strtotime($camara_mas_reciente->getFechaInstalacion())); ?></strong>
                    </div>
                    <?php endif; ?>
                    <?php if ($camara_mas_antigua): ?>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Más antigua:</span>
                        <strong><?php echo date('d/m/Y', strtotime($camara_mas_antigua->getFechaInstalacion())); ?></strong>
                    </div>
                    <?php endif; ?>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Cámaras este año:</span>
                        <strong><?php echo $camaras_por_año[date('Y')] ?? 0; ?></strong>
                    </div>
                </div>
            </div>
        </div>

        <!-- Selector de Métricas y Gráficos -->
        <div style="background: white; padding: 15px; border-radius: 8px; margin-bottom: 15px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h4 style="margin: 0 0 10px 0; color: #23282d; font-size: 14px;">📈 Seleccionar Métricas de Visualización</h4>
            
            <!-- Selector de Métricas -->
            <div style="display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 15px;">
                <button type="button" class="button ac-metrica-btn <?php echo $metricas_seleccionadas == 'quincena' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-metrica="quincena"
                        style="font-size: 12px; padding: 6px 12px;">
                    📈 Por Quincena
                </button>
                <button type="button" class="button ac-metrica-btn <?php echo $metricas_seleccionadas == 'mes' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-metrica="mes"
                        style="font-size: 12px; padding: 6px 12px;">
                    📅 Por Mes
                </button>
                <button type="button" class="button ac-metrica-btn <?php echo $metricas_seleccionadas == 'año' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-metrica="año"
                        style="font-size: 12px; padding: 6px 12px;">
                    📊 Por Año
                </button>
                <button type="button" class="button ac-metrica-btn <?php echo $metricas_seleccionadas == 'tipo' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-metrica="tipo"
                        style="font-size: 12px; padding: 6px 12px;">
                    🏷️ Por Tipo
                </button>
            </div>

            <!-- Selector de Tipo de Gráfico -->
            <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
                <span style="font-size: 12px; color: #666; margin-right: 10px;">Tipo de gráfico:</span>
                <button type="button" class="button ac-grafico-btn <?php echo $tipo_grafico_seleccionado == 'barras' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-grafico="barras"
                        style="font-size: 11px; padding: 4px 8px;">
                    📊 Barras
                </button>
                <button type="button" class="button ac-grafico-btn <?php echo $tipo_grafico_seleccionado == 'lineas' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-grafico="lineas"
                        style="font-size: 11px; padding: 4px 8px;">
                    📈 Líneas
                </button>
                <button type="button" class="button ac-grafico-btn <?php echo $tipo_grafico_seleccionado == 'pastel' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-grafico="pastel"
                        style="font-size: 11px; padding: 4px 8px;">
                    🥧 Pastel
                </button>
                <button type="button" class="button ac-grafico-btn <?php echo $tipo_grafico_seleccionado == 'areas' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-grafico="areas"
                        style="font-size: 11px; padding: 4px 8px;">
                    🔲 Áreas
                </button>
            </div>

            <!-- Controles de personalización -->
            <div style="display: flex; gap: 15px; flex-wrap: wrap; align-items: center; margin-top: 10px; padding-top: 10px; border-top: 1px solid #eee;">
                <span style="font-size: 12px; color: #666; margin-right: 5px;">Personalizar:</span>
                
                <div style="display: flex; gap: 8px; align-items: center;">
                    <label style="font-size: 11px; color: #666;">Tamaño:</label>
                    <button type="button" class="button ac-size-btn" data-size="pequeno" style="font-size: 10px; padding: 2px 6px;">S</button>
                    <button type="button" class="button ac-size-btn button-primary" data-size="medio" style="font-size: 10px; padding: 2px 6px;">M</button>
                    <button type="button" class="button ac-size-btn" data-size="grande" style="font-size: 10px; padding: 2px 6px;">L</button>
                </div>

                <div style="display: flex; gap: 8px; align-items: center;">
                    <label style="font-size: 11px; color: #666;">Animación:</label>
                    <button type="button" class="button ac-animacion-btn button-primary" data-animacion="si" style="font-size: 10px; padding: 2px 6px;">ON</button>
                    <button type="button" class="button ac-animacion-btn" data-animacion="no" style="font-size: 10px; padding: 2px 6px;">OFF</button>
                </div>

                <div style="display: flex; gap: 8px; align-items: center;">
                    <label style="font-size: 11px; color: #666;">Mostrar valores:</label>
                    <button type="button" class="button ac-valores-btn button-primary" data-valores="si" style="font-size: 10px; padding: 2px 6px;">SI</button>
                    <button type="button" class="button ac-valores-btn" data-valores="no" style="font-size: 10px; padding: 2px 6px;">NO</button>
                </div>
            </div>
        </div>

        <!-- Gráficos según métrica seleccionada -->
        <div class="ac-charts-container" id="graficos-container">
            <div class="ac-chart-card" style="background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="display: flex; justify-content: between; align-items: center; margin-bottom: 15px;">
                    <h4 style="margin: 0; color: #23282d; font-size: 14px;" id="titulo-grafico">
                        📈 <?php 
                        switch($metricas_seleccionadas) {
                            case 'quincena': echo 'Cámaras por Quincena (Últimas 6 quincenas)'; break;
                            case 'mes': echo 'Cámaras por Mes (Últimos 6 meses)'; break;
                            case 'año': echo 'Cámaras por Año'; break;
                            case 'tipo': echo 'Cámaras por Tipo'; break;
                        }
                        ?>
                    </h4>
                    <div class="ac-chart-info" style="font-size: 12px; color: #666;">
                        <span id="total-camaras-grafico">Total: <?php echo array_sum($datos_grafico_json[$metricas_seleccionadas]); ?> cámaras</span>
                    </div>
                </div>
                
                <!-- CONTENEDOR MEJORADO PARA GRAFICO RESPONSIVO -->
                <div id="contenedor-grafico" 
                     style="min-height: 300px; display: flex; align-items: center; justify-content: center; 
                            width: 100%; overflow: hidden; position: relative; cursor: zoom-in;"
                     class="ac-grafico-zoomable">
                    <div class="ac-loading" style="text-align: center; color: #666;">
                        <p>Cargando gráfico interactivo...</p>
                    </div>
                </div>

                <!-- Leyenda interactiva -->
                <div id="leyenda-grafico" style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #eee; display: none;">
                    <div style="display: flex; flex-wrap: wrap; gap: 10px; justify-content: center;" id="contenedor-leyenda"></div>
                </div>

                <!-- Controles de zoom -->
                <div style="margin-top: 10px; display: flex; justify-content: center; gap: 10px; align-items: center;">
                    <button type="button" class="button ac-zoom-btn" data-zoom="out" style="font-size: 10px; padding: 2px 6px;" title="Alejar">
                        <span class="dashicons dashicons-minus"></span>
                    </button>
                    <span style="font-size: 11px; color: #666;" id="zoom-level">100%</span>
                    <button type="button" class="button ac-zoom-btn" data-zoom="in" style="font-size: 10px; padding: 2px 6px;" title="Acercar">
                        <span class="dashicons dashicons-plus"></span>
                    </button>
                    <button type="button" class="button ac-zoom-btn" data-zoom="reset" style="font-size: 10px; padding: 2px 6px; margin-left: 10px;" title="Restablecer">
                        <span class="dashicons dashicons-image-rotate"></span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Acciones Principales -->
    <div class="ac-header-actions" style="display: flex; justify-content: space-between; align-items: center; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px;">
        <div>
            <a href="<?php echo admin_url('admin.php?page=ac-camaras-seguridad&action=nuevo'); ?>" class="button button-primary" style="font-size: 14px; padding: 8px 16px;">
                <span class="dashicons dashicons-plus" style="margin-top: 4px;"></span>
                Nueva Cámara
            </a>
            <?php if (!empty($camaras)): ?>
            <div class="ac-export-buttons" style="display: inline-block; margin-left: 10px;">
                <a href="<?php echo admin_url('admin.php?page=ac-camaras-seguridad&export=csv'); ?>" class="button" style="font-size: 14px; padding: 8px 16px;">
                    <span class="dashicons dashicons-media-spreadsheet" style="margin-top: 4px;"></span>
                    Exportar CSV
                </a>
                <a href="<?php echo admin_url('admin.php?page=ac-camaras-seguridad&export=pdf'); ?>" class="button" style="font-size: 14px; padding: 8px 16px; margin-left: 5px;">
                    <span class="dashicons dashicons-media-document" style="margin-top: 4px;"></span>
                    Exportar PDF
                </a>
            </div>
            <?php endif; ?>
        </div>
        
        <?php if (!empty($camaras)): ?>
        <div class="ac-search-export" style="display: flex; gap: 10px; align-items: center;">
            <input type="text" id="buscar-camaras" placeholder="Buscar en cámaras..." style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; width: 250px;">
            <span class="description" style="color: #666; font-size: 13px;">
                <?php echo $total_camaras; ?> cámara(s) registrada(s)
                <?php if ($camaras_quincena_actual > 0): ?>
                • <?php echo $camaras_quincena_actual; ?> esta quincena
                <?php endif; ?>
            </span>
        </div>
        <?php endif; ?>
    </div>

    <!-- Sección de Importación Mejorada -->
    <div class="ac-import-section" style="background: #f0f8ff; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #667eea;">
        <h3 style="margin-top: 0; color: #667eea;">
            <span class="dashicons dashicons-upload" style="margin-right: 5px;"></span>
            Importar Cámaras
        </h3>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
            <!-- Importar desde CSV -->
            <div style="border: 1px solid #667eea; padding: 15px; border-radius: 5px; background: white;">
                <h4 style="margin-top: 0; color: #667eea;">
                    <span class="dashicons dashicons-media-spreadsheet" style="margin-right: 5px;"></span>
                    Desde Archivo CSV
                </h4>
                <form method="post" enctype="multipart/form-data">
                    <input type="file" name="csv_file" accept=".csv" required style="margin-bottom: 10px; width: 100%;">
                    <button type="submit" name="importar_csv" class="button" style="width: 100%; background: #667eea; color: white; border-color: #667eea;">
                        <span class="dashicons dashicons-upload" style="margin-top: 4px;"></span>
                        Importar CSV
                    </button>
                </form>
                <p style="margin: 10px 0 0 0; font-size: 12px; color: #666;">
                    <strong>Formato:</strong> CSV con encabezados<br>
                    <strong>Separador:</strong> Punto y coma (;)
                </p>
            </div>

            <!-- Importar desde Foto/Imagen con OCR -->
            <div style="border: 1px solid #46b450; padding: 15px; border-radius: 5px; background: white;">
                <h4 style="margin-top: 0; color: #46b450;">
                    <span class="dashicons dashicons-camera" style="margin-right: 5px;"></span>
                    Desde Foto/Imagen (OCR)
                </h4>
                <div id="ocr-container">
                    <input type="file" id="foto_camara_ocr" accept="image/*" style="margin-bottom: 10px; width: 100%;">
                    <button type="button" id="procesar_ocr" class="button" style="width: 100%; background: #46b450; color: white; border-color: #46b450;">
                        <span class="dashicons dashicons-camera" style="margin-top: 4px;"></span>
                        Extraer Texto con OCR
                    </button>
                </div>
                <div id="ocr-progress" style="display: none; margin-top: 10px;">
                    <div style="background: #f0f0f0; border-radius: 4px; height: 20px; overflow: hidden;">
                        <div id="ocr-progress-bar" style="background: #46b450; height: 100%; width: 0%; transition: width 0.3s ease;"></div>
                    </div>
                    <p id="ocr-status" style="margin: 5px 0 0 0; font-size: 12px; text-align: center;">Procesando...</p>
                </div>
                <p style="margin: 10px 0 0 0; font-size: 12px; color: #666;">
                    <strong>Formatos:</strong> JPG, PNG, WebP<br>
                    <strong>Recomendación:</strong> Imágenes claras y bien iluminadas
                </p>
            </div>

            <!-- Importar desde Documento -->
            <div style="border: 1px solid #ffb900; padding: 15px; border-radius: 5px; background: white;">
                <h4 style="margin-top: 0; color: #ffb900;">
                    <span class="dashicons dashicons-media-document" style="margin-right: 5px;"></span>
                    Desde Documento PDF/Word
                </h4>
                <form method="post" enctype="multipart/form-data">
                    <input type="file" name="documento_camara" accept=".pdf,.doc,.docx,.txt" style="margin-bottom: 10px; width: 100%;">
                    <button type="submit" name="importar_documento" class="button" style="width: 100%; background: #ffb900; color: white; border-color: #ffb900;">
                        <span class="dashicons dashicons-media-document" style="margin-top: 4px;"></span>
                        Procesar Documento
                    </button>
                </form>
                <p style="margin: 10px 0 0 0; font-size: 12px; color: #666;">
                    <strong>Formatos:</strong> PDF, Word, TXT<br>
                    <strong>Límite:</strong> Archivos hasta 10MB
                </p>
            </div>
        </div>
        
        <div style="margin-top: 15px; padding: 15px; background: #fff8e7; border-radius: 5px; border-left: 4px solid #ffb900;">
            <h4 style="margin-top: 0; color: #cc8500;">
                <span class="dashicons dashicons-info" style="margin-right: 5px;"></span>
                Información sobre Importación
            </h4>
            <p style="margin: 5px 0; font-size: 13px;">
                <strong>CSV:</strong> Formato estructurado ideal para migraciones masivas.<br>
                <strong>OCR:</strong> Extrae texto de imágenes usando inteligencia artificial en el navegador.<br>
                <strong>Documentos:</strong> Procesa archivos PDF, Word y texto plano.
            </p>
        </div>
    </div>
    
    <?php if (empty($camaras)): ?>
        <div class="notice notice-info" style="padding: 20px; text-align: center;">
            <h3 style="margin-top: 0;">📹 Configura el Sistema de Seguridad</h3>
            <p>No hay cámaras de seguridad registradas en el sistema. Configura la primera cámara para comenzar el monitoreo.</p>
            <p style="margin-top: 15px;">
                <a href="<?php echo admin_url('admin.php?page=ac-camaras-seguridad&action=nuevo'); ?>" class="button button-primary button-large">
                    <span class="dashicons dashicons-plus"></span>
                    Configurar primera cámara
                </a>
            </p>
        </div>
    <?php else: ?>
        <div class="ac-table-container">
            <table class="wp-list-table widefat fixed striped" id="tabla-camaras">
                <thead>
                    <tr>
                        <th width="20%">Nombre</th>
                        <th width="15%">Ubicación</th>
                        <th width="12%">Tipo</th>
                        <th width="15%">IP/Modelo</th>
                        <th width="30%">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($camaras as $camara_item): ?>
                        <?php if (is_object($camara_item) && method_exists($camara_item, 'getNombre')): ?>
                        <tr class="ac-camara-row" data-nombre="<?php echo esc_attr(strtolower($camara_item->getNombre())); ?>" data-tipo="<?php echo esc_attr(strtolower($camara_item->getTipo())); ?>" data-ubicacion="<?php echo esc_attr(strtolower($camara_item->getUbicacion())); ?>">
                            <td>
                                <div style="display: flex; align-items: center; gap: 8px;">
                                    <div style="width: 32px; height: 32px; border-radius: 50%; background: #667eea; display: flex; align-items: center; justify-content: center; color: white; font-size: 16px;">
                                        📹
                                    </div>
                                    <div>
                                        <strong><?php echo esc_html($camara_item->getNombre()); ?></strong>
                                        <br>
                                        <small style="color: #666;">ID: <?php echo esc_html($camara_item->getId()); ?></small>
                                        <?php if ($camara_item->getEstado() === 'activa'): ?>
                                            <br>
                                            <small style="color: #46b450;">
                                                <span class="dashicons dashicons-yes-alt" style="font-size: 12px; margin-right: 2px;"></span>
                                                Cámara activa
                                            </small>
                                        <?php elseif ($camara_item->getEstado() === 'mantenimiento'): ?>
                                            <br>
                                            <small style="color: #ffb900;">
                                                <span class="dashicons dashicons-hammer" style="font-size: 12px; margin-right: 2px;"></span>
                                                En mantenimiento
                                            </small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <strong><?php echo esc_html($camara_item->getUbicacion()); ?></strong>
                            </td>
                            <td>
                                <span class="ac-badge ac-badge-<?php echo esc_attr($camara_item->getTipo()); ?>" style="background: #f0f8ff; color: #667eea; padding: 4px 8px; border-radius: 3px; font-size: 12px; font-weight: 500;">
                                    <?php echo esc_html($camara_item->getTipo()); ?>
                                </span>
                            </td>
                            <td>
                                <div>
                                    <small style="color: #666;">IP: <?php echo esc_html($camara_item->getIp() ?: 'No configurada'); ?></small>
                                    <br>
                                    <small style="color: #999;">Modelo: <?php echo esc_html($camara_item->getModelo() ?: 'No especificado'); ?></small>
                                </div>
                            </td>
                            <td>
                                <div class="ac-action-buttons" style="display: flex; gap: 5px; flex-wrap: wrap;">
                                    <a href="<?php echo admin_url('admin.php?page=ac-camaras-seguridad&action=ver&id=' . $camara_item->getId()); ?>" class="button" title="Ver detalles" style="padding: 4px 8px; font-size: 12px;">
                                        <span class="dashicons dashicons-visibility" style="font-size: 14px; margin-top: 2px;"></span>
                                        Ver
                                    </a>
                                    <a href="<?php echo admin_url('admin.php?page=ac-camaras-seguridad&action=editar&id=' . $camara_item->getId()); ?>" class="button" title="Editar cámara" style="padding: 4px 8px; font-size: 12px;">
                                        <span class="dashicons dashicons-edit" style="font-size: 14px; margin-top: 2px;"></span>
                                        Editar
                                    </a>
                                    <a href="<?php echo admin_url('admin.php?page=ac-camaras-seguridad&export=csv&id=' . $camara_item->getId()); ?>" class="button" title="Exportar a CSV" style="padding: 4px 8px; font-size: 12px; background: #0073aa; color: white; border-color: #0073aa;">
                                        <span class="dashicons dashicons-media-spreadsheet" style="font-size: 14px; margin-top: 2px;"></span>
                                        CSV
                                    </a>
                                    <a href="<?php echo admin_url('admin.php?page=ac-camaras-seguridad&export=pdf_individual&id=' . $camara_item->getId()); ?>" class="button" title="Exportar a PDF" style="padding: 4px 8px; font-size: 12px; background: #dc3232; color: white; border-color: #dc3232;">
                                        <span class="dashicons dashicons-media-document" style="font-size: 14px; margin-top: 2px;"></span>
                                        PDF
                                    </a>
                                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ac-camaras-seguridad&action=eliminar&id=' . $camara_item->getId()), 'eliminar_camara_' . $camara_item->getId()); ?>" 
                                       class="button button-link-delete" 
                                       title="Eliminar cámara" 
                                       style="padding: 4px 8px; font-size: 12px; color: #dc3232; border-color: #dc3232;"
                                       onclick="return confirm('¿Está seguro de que desea eliminar esta cámara?\n\nNombre: <?php echo esc_js($camara_item->getNombre()); ?>\nUbicación: <?php echo esc_js($camara_item->getUbicacion()); ?>');">
                                        <span class="dashicons dashicons-trash" style="font-size: 14px; margin-top: 2px;"></span>
                                        Eliminar
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Nombre</th>
                        <th>Ubicación</th>
                        <th>Tipo</th>
                        <th>IP/Modelo</th>
                        <th>Acciones</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Incluir Tesseract.js desde CDN -->
<script src="https://cdn.jsdelivr.net/npm/tesseract.js@4/dist/tesseract.min.js"></script>

<script>
jQuery(document).ready(function($) {
    // Variables para el zoom
    let zoomLevel = 1;
    let isDragging = false;
    let startX, startY, scrollLeft, scrollTop;
    
    // Función para aplicar zoom
    function aplicarZoom(nivel) {
        const contenedor = $('#contenedor-grafico');
        const contenido = contenedor.find('.ac-grafico-contenido');
        
        zoomLevel = Math.max(0.5, Math.min(3, nivel)); // Limitar entre 0.5x y 3x
        
        if (contenido.length > 0) {
            contenido.css({
                'transform': `scale(${zoomLevel})`,
                'transform-origin': 'center center'
            });
        } else {
            // Si no hay contenido específico, escalar todo el contenedor
            contenedor.css({
                'transform': `scale(${zoomLevel})`,
                'transform-origin': 'center center'
            });
        }
        
        $('#zoom-level').text(Math.round(zoomLevel * 100) + '%');
        
        // Ajustar el cursor según el nivel de zoom
        if (zoomLevel > 1) {
            contenedor.css('cursor', 'grab');
        } else {
            contenedor.css('cursor', 'zoom-in');
        }
    }
    
    // Función para resetear zoom
    function resetearZoom() {
        zoomLevel = 1;
        aplicarZoom(zoomLevel);
        $('#contenedor-grafico').scrollLeft(0).scrollTop(0);
    }
    
    // Event listeners para botones de zoom
    $('.ac-zoom-btn').on('click', function() {
        const accion = $(this).data('zoom');
        
        switch(accion) {
            case 'in':
                aplicarZoom(zoomLevel + 0.25);
                break;
            case 'out':
                aplicarZoom(zoomLevel - 0.25);
                break;
            case 'reset':
                resetearZoom();
                break;
        }
    });
    
    // Zoom con rueda del mouse
    $('#contenedor-grafico').on('wheel', function(e) {
        if (e.ctrlKey) {
            e.preventDefault();
            const delta = e.originalEvent.deltaY > 0 ? -0.1 : 0.1;
            aplicarZoom(zoomLevel + delta);
        }
    });
    
    // Arrastrar para mover cuando hay zoom
    $('#contenedor-grafico').on('mousedown', function(e) {
        if (zoomLevel > 1) {
            isDragging = true;
            startX = e.pageX - $(this).offset().left;
            startY = e.pageY - $(this).offset().top;
            scrollLeft = $(this).scrollLeft();
            scrollTop = $(this).scrollTop();
            $(this).css('cursor', 'grabbing');
        }
    });
    
    $(document).on('mousemove', function(e) {
        if (!isDragging) return;
        
        const contenedor = $('#contenedor-grafico');
        const x = e.pageX - contenedor.offset().left;
        const y = e.pageY - contenedor.offset().top;
        const walkX = (x - startX) * 2;
        const walkY = (y - startY) * 2;
        
        contenedor.scrollLeft(scrollLeft - walkX);
        contenedor.scrollTop(scrollTop - walkY);
    });
    
    $(document).on('mouseup', function() {
        isDragging = false;
        if (zoomLevel > 1) {
            $('#contenedor-grafico').css('cursor', 'grab');
        }
    });
    
    // Doble click para resetear zoom
    $('#contenedor-grafico').on('dblclick', function() {
        resetearZoom();
    });

    // OCR Functionality para cámaras
    const ocrButton = document.getElementById('procesar_ocr');
    const fileInput = document.getElementById('foto_camara_ocr');
    const progressDiv = document.getElementById('ocr-progress');
    const progressBar = document.getElementById('ocr-progress-bar');
    const statusText = document.getElementById('ocr-status');
    
    if (ocrButton && fileInput) {
        ocrButton.addEventListener('click', async () => {
            const file = fileInput.files[0];
            
            if (!file) {
                alert('Por favor, selecciona una imagen primero.');
                return;
            }
            
            // Validar tipo de archivo
            const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
            if (!validTypes.includes(file.type)) {
                alert('Por favor, selecciona una imagen válida (JPG, PNG o WebP).');
                return;
            }
            
            // Validar tamaño (max 10MB)
            if (file.size > 10 * 1024 * 1024) {
                alert('La imagen es demasiado grande. El tamaño máximo es 10MB.');
                return;
            }
            
            // Mostrar progreso
            progressDiv.style.display = 'block';
            progressBar.style.width = '0%';
            statusText.textContent = 'Inicializando OCR...';
            ocrButton.disabled = true;
            
            try {
                // Inicializar Tesseract
                statusText.textContent = 'Cargando motor OCR...';
                progressBar.style.width = '10%';
                
                const worker = await Tesseract.createWorker('spa+eng'); // Español e Inglés
                
                statusText.textContent = 'Reconociendo texto...';
                progressBar.style.width = '30%';
                
                // Procesar la imagen
                const { data: { text, confidence } } = await worker.recognize(file, {
                    logger: m => {
                        if (m.status === 'recognizing text') {
                            const progress = Math.round(m.progress * 50) + 30; // 30-80%
                            progressBar.style.width = progress + '%';
                            statusText.textContent = `Procesando: ${Math.round(m.progress * 100)}%`;
                        }
                    }
                });
                
                progressBar.style.width = '90%';
                statusText.textContent = 'Finalizando...';
                
                // Terminar el worker
                await worker.terminate();
                
                progressBar.style.width = '100%';
                statusText.textContent = '¡Completado!';
                
                // Mostrar resultados
                setTimeout(() => {
                    if (text.trim().length === 0) {
                        alert('No se pudo extraer texto de la imagen. Intenta con una imagen más clara o con mejor iluminación.');
                        progressDiv.style.display = 'none';
                        ocrButton.disabled = false;
                        return;
                    }
                    
                    // Calcular confianza
                    const confianzaPorcentaje = Math.round(confidence * 100);
                    
                    // Mostrar confirmación antes de proceder
                    const confirmar = confirm(
                        `OCR completado con ${confianzaPorcentaje}% de confianza.\n\n` +
                        `¿Deseas proceder a editar el texto extraído?`
                    );
                    
                    if (confirmar) {
                        // Codificar el texto para URL y redirigir
                        const textoCodificado = btoa(unescape(encodeURIComponent(text)));
                        window.location.href = `<?php echo admin_url('admin.php?page=ac-camaras-seguridad&ocr_edit=1&text='); ?>${textoCodificado}`;
                    } else {
                        progressDiv.style.display = 'none';
                        ocrButton.disabled = false;
                    }
                    
                }, 1000);
                
            } catch (error) {
                console.error('Error en OCR:', error);
                statusText.textContent = 'Error: ' + error.message;
                progressBar.style.backgroundColor = '#dc3232';
                
                setTimeout(() => {
                    progressDiv.style.display = 'none';
                    ocrButton.disabled = false;
                    alert('Error al procesar la imagen: ' + error.message);
                }, 2000);
            }
        });
    }
    
    // Resto del código para gráficos interactivos...
    const datosGraficos = <?php echo json_encode($datos_grafico_json); ?>;
    let metricaActual = '<?php echo $metricas_seleccionadas; ?>';
    let tipoGraficoActual = '<?php echo $tipo_grafico_seleccionado; ?>';
    let configuracion = {
        tamaño: 'medio',
        animacion: 'si',
        mostrarValores: 'si'
    };
    
    // Inicializar el gráfico
    function inicializarGrafico() {
        cargarGrafico(metricaActual, tipoGraficoActual);
    }
    
    // Cargar gráfico con AJAX
    function cargarGrafico(metrica, tipoGrafico) {
        const contenedor = $('#contenedor-grafico');
        const titulo = $('#titulo-grafico');
        const totalCamaras = $('#total-camaras-grafico');
        const leyenda = $('#leyenda-grafico');
        
        // Mostrar loading
        contenedor.html('<div class="ac-loading" style="text-align: center; color: #666;"><p>Cargando gráfico interactivo...</p></div>');
        
        // Resetear zoom
        resetearZoom();
        
        // Simular AJAX (en realidad usamos datos locales)
        setTimeout(function() {
            const datos = datosGraficos[metrica];
            const tituloTexto = obtenerTituloGrafico(metrica);
            const total = Object.values(datos).reduce((sum, val) => sum + val, 0);
            
            titulo.text('📈 ' + tituloTexto);
            totalCamaras.text('Total: ' + total + ' cámaras');
            
            // Generar gráfico dentro de un contenedor escalable
            const graficoHTML = `
                <div class="ac-grafico-contenido" style="width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; transform-origin: center center;">
                    ${generarGrafico(datos, tipoGrafico, tituloTexto)}
                </div>
            `;
            contenedor.html(graficoHTML);
            
            // Actualizar leyenda
            actualizarLeyenda(datos, tipoGrafico);
            leyenda.show();
            
            // Actualizar estado de botones
            actualizarBotonesActivos();
            
            // Actualizar URL sin recargar
            actualizarURL(metrica, tipoGrafico);
            
            // Aplicar animaciones si están activadas
            if (configuracion.animacion === 'si') {
                aplicarAnimaciones();
            }
            
        }, 500);
    }
    
    // Obtener título del gráfico
    function obtenerTituloGrafico(metrica) {
        const titulos = {
            'quincena': 'Cámaras por Quincena (Últimas 6 quincenas)',
            'mes': 'Cámaras por Mes (Últimos 6 meses)',
            'año': 'Cámaras por Año',
            'tipo': 'Cámaras por Tipo'
        };
        return titulos[metrica] || 'Gráfico de Cámaras';
    }
    
    // Generar gráfico
    function generarGrafico(datos, tipo, titulo) {
        if (!datos || Object.keys(datos).length === 0) {
            return '<div style="text-align: center; padding: 40px; color: #666;">No hay datos para mostrar</div>';
        }
        
        const tamaño = obtenerTamañoGrafico();
        
        switch(tipo) {
            case 'barras':
                return generarGraficoBarras(datos, titulo, tamaño);
            case 'lineas':
                return generarGraficoLineas(datos, titulo, tamaño);
            case 'pastel':
                return generarGraficoPastel(datos, titulo, tamaño);
            case 'areas':
                return generarGraficoAreas(datos, titulo, tamaño);
            default:
                return generarGraficoBarras(datos, titulo, tamaño);
        }
    }
    
    // Obtener dimensiones según tamaño
    function obtenerTamañoGrafico() {
        const tamaños = {
            'pequeno': { altura: 250, anchoBarras: '70%', radioPastel: 150 },
            'medio': { altura: 300, anchoBarras: '80%', radioPastel: 200 },
            'grande': { altura: 350, anchoBarras: '90%', radioPastel: 250 }
        };
        return tamaños[configuracion.tamaño] || tamaños.medio;
    }
    
    // Generar gráfico de barras
    function generarGraficoBarras(datos, titulo, tamaño) {
        const maxValor = Math.max(...Object.values(datos));
        const etiquetas = Object.keys(datos);
        const valores = Object.values(datos);
        
        let html = `<div class="ac-grafico-barras" style="width: 100%; height: ${tamaño.altura}px; display: flex; align-items: end; gap: 8px; padding: 20px 0; border-bottom: 1px solid #eee; position: relative;">`;
        
        etiquetas.forEach((etiqueta, index) => {
            const valor = valores[index];
            const altura = maxValor > 0 ? (valor / maxValor) * (tamaño.altura - 50) : 0;
            const porcentaje = maxValor > 0 ? Math.round((valor / maxValor) * 100) : 0;
            
            html += `
                <div style="display: flex; flex-direction: column; align-items: center; flex: 1; position: relative;">
                    <div class="ac-barra" 
                         style="background: linear-gradient(to top, #667eea, #764ba2); 
                                width: ${tamaño.anchoBarras}; 
                                height: ${altura}px; 
                                border-radius: 4px 4px 0 0; 
                                position: relative;
                                cursor: pointer;
                                transition: all 0.3s ease;
                                opacity: 0;
                                transform: translateY(20px);"
                         onmouseover="this.style.background='linear-gradient(to top, #5a6fd8, #667eea)'; this.style.transform='translateY(15px)';"
                         onmouseout="this.style.background='linear-gradient(to top, #667eea, #764ba2)'; this.style.transform='translateY(0)';"
                         title="${etiqueta}: ${valor} cámaras">
                        ${configuracion.mostrarValores === 'si' ? 
                            `<span style="position: absolute; top: -25px; left: 50%; transform: translateX(-50%); font-size: 11px; font-weight: bold; color: #667eea;">${valor}</span>` : 
                            ''
                        }
                    </div>
                    <div style="margin-top: 10px; font-size: 11px; text-align: center; color: #666; height: 40px; display: flex; align-items: center; justify-content: center;">
                        <span style="writing-mode: vertical-rl; transform: rotate(180deg); white-space: nowrap;">${etiqueta}</span>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        return html;
    }
    
    // Generar gráfico de líneas
    function generarGraficoLineas(datos, titulo, tamaño) {
        const maxValor = Math.max(...Object.values(datos));
        const valores = Object.values(datos);
        const etiquetas = Object.keys(datos);
        
        let html = `<div class="ac-grafico-lineas" style="width: 100%; height: ${tamaño.altura}px; position: relative; padding: 20px 0;">`;
        html += '<svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">';
        
        // Línea de fondo
        let pathData = '';
        const xIncremento = 100 / (valores.length - 1);
        
        valores.forEach((valor, index) => {
            const x = index * xIncremento;
            const y = 100 - ((valor / maxValor) * 95); // Reducir altura máxima al 95% para mejor visualización
            if (index === 0) {
                pathData += `M ${x} ${y} `;
            } else {
                pathData += `L ${x} ${y} `;
            }
        });
        
        html += `<path d="${pathData}" stroke="#667eea" stroke-width="1.5" fill="none" class="ac-linea" style="opacity: 0; stroke-dasharray: 1000; stroke-dashoffset: 1000;" />`;
        
        // Puntos interactivos
        valores.forEach((valor, index) => {
            const x = index * xIncremento;
            const y = 100 - ((valor / maxValor) * 95);
            const mostrarValor = configuracion.mostrarValores === 'si';
            
            html += `
                <g class="ac-punto-grupo" style="opacity: 0; transform: scale(0);">
                    <circle cx="${x}" cy="${y}" r="1.5" fill="#667eea" class="ac-punto" />
                    <circle cx="${x}" cy="${y}" r="4" fill="rgba(102, 126, 234, 0.2)" class="ac-punto-hover" 
                            style="cursor: pointer; transition: all 0.3s ease;"
                            onmouseover="this.style.r='6'; this.previousElementSibling.style.r='2';"
                            onmouseout="this.style.r='4'; this.previousElementSibling.style.r='1.5';" />
                    ${mostrarValor ? 
                        `<text x="${x}" y="${y - 8}" text-anchor="middle" font-size="3" fill="#667eea" font-weight="bold">${valor}</text>` : 
                        ''
                    }
                </g>
            `;
        });
        
        html += '</svg>';
        
        // Etiquetas del eje X
        html += '<div style="display: flex; justify-content: space-between; margin-top: 10px; padding: 0 10px;">';
        etiquetas.forEach(etiqueta => {
            html += `<span style="font-size: 10px; color: #666; transform: rotate(-45deg); display: inline-block; transform-origin: left bottom;">${etiqueta.substring(0, 8)}</span>`;
        });
        html += '</div>';
        
        html += '</div>';
        return html;
    }
    
    // Generar gráfico de pastel
    function generarGraficoPastel(datos, titulo, tamaño) {
        const total = Object.values(datos).reduce((sum, val) => sum + val, 0);
        const colores = ['#667eea', '#764ba2', '#46b450', '#ffb900', '#dc3232', '#826eb4'];
        
        let html = '<div class="ac-grafico-pastel" style="display: flex; align-items: center; justify-content: center; height: ' + tamaño.altura + 'px;">';
        html += '<div style="width: ' + tamaño.radioPastel + 'px; height: ' + tamaño.radioPastel + 'px; border-radius: 50%; position: relative; background: conic-gradient(';
        
        const porcentajes = [];
        let inicio = 0;
        let indexColor = 0;
        
        Object.entries(datos).forEach(([etiqueta, valor]) => {
            const porcentaje = (valor / total) * 100;
            const color = colores[indexColor % colores.length];
            porcentajes.push({ etiqueta, valor, porcentaje, color, inicio, fin: inicio + porcentaje });
            
            html += `${color} ${inicio}% ${inicio + porcentaje}%`;
            if (indexColor < Object.keys(datos).length - 1) {
                html += ', ';
            }
            
            inicio += porcentaje;
            indexColor++;
        });
        
        html += ');"></div>';
        
        html += '</div>';
        return html;
    }
    
    // Generar gráfico de áreas
    function generarGraficoAreas(datos, titulo, tamaño) {
        const maxValor = Math.max(...Object.values(datos));
        const valores = Object.values(datos);
        const etiquetas = Object.keys(datos);
        
        let html = `<div class="ac-grafico-areas" style="width: 100%; height: ${tamaño.altura}px; position: relative; padding: 20px 0;">`;
        html += '<svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">';
        
        // Área
        let pathData = 'M 0 100 ';
        const xIncremento = 100 / (valores.length - 1);
        
        valores.forEach((valor, index) => {
            const x = index * xIncremento;
            const y = 100 - ((valor / maxValor) * 95); // Reducir altura máxima al 95%
            pathData += `L ${x} ${y} `;
        });
        
        pathData += 'L 100 100 Z';
        
        html += `<path d="${pathData}" fill="url(#areaGradient)" stroke="#667eea" stroke-width="1" class="ac-area" style="opacity: 0;" />`;
        
        // Gradiente para el área
        html += `
            <defs>
                <linearGradient id="areaGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stop-color="rgba(102, 126, 234, 0.3)" />
                    <stop offset="100%" stop-color="rgba(102, 126, 234, 0.1)" />
                </linearGradient>
            </defs>
        `;
        
        // Puntos interactivos
        valores.forEach((valor, index) => {
            const x = index * xIncremento;
            const y = 100 - ((valor / maxValor) * 95);
            const mostrarValor = configuracion.mostrarValores === 'si';
            
            html += `
                <g class="ac-punto-grupo" style="opacity: 0; transform: scale(0);">
                    <circle cx="${x}" cy="${y}" r="1.5" fill="#667eea" class="ac-punto" />
                    <circle cx="${x}" cy="${y}" r="4" fill="rgba(102, 126, 234, 0.2)" class="ac-punto-hover" 
                            style="cursor: pointer; transition: all 0.3s ease;"
                            onmouseover="this.style.r='6'; this.previousElementSibling.style.r='2';"
                            onmouseout="this.style.r='4'; this.previousElementSibling.style.r='1.5';" />
                    ${mostrarValor ? 
                        `<text x="${x}" y="${y - 8}" text-anchor="middle" font-size="3" fill="#667eea" font-weight="bold">${valor}</text>` : 
                        ''
                    }
                </g>
            `;
        });
        
        html += '</svg>';
        
        // Etiquetas del eje X
        html += '<div style="display: flex; justify-content: space-between; margin-top: 10px; padding: 0 10px;">';
        etiquetas.forEach(etiqueta => {
            html += `<span style="font-size: 10px; color: #666;">${etiqueta.substring(0, 8)}</span>`;
        });
        html += '</div>';
        
        html += '</div>';
        return html;
    }
    
    // Actualizar leyenda
    function actualizarLeyenda(datos, tipoGrafico) {
        const contenedor = $('#contenedor-leyenda');
        const colores = ['#667eea', '#764ba2', '#46b450', '#ffb900', '#dc3232', '#826eb4'];
        
        contenedor.empty();
        
        Object.entries(datos).forEach(([etiqueta, valor], index) => {
            const color = colores[index % colores.length];
            const porcentaje = tipoGrafico === 'pastel' ? Math.round((valor / Object.values(datos).reduce((sum, val) => sum + val, 0)) * 100) : null;
            
            const elementoLeyenda = `
                <div class="ac-leyenda-item" 
                     style="display: flex; align-items: center; padding: 4px 8px; background: #f8f9fa; border-radius: 4px; cursor: pointer; transition: all 0.3s ease;"
                     onmouseover="this.style.background='#e9ecef'; this.style.transform='translateY(-2px)';"
                     onmouseout="this.style.background='#f8f9fa'; this.style.transform='translateY(0)';"
                     onclick="acResaltarElemento('${tipoGrafico}', ${index})">
                    <span style="display: inline-block; width: 12px; height: 12px; background: ${color}; margin-right: 6px; border-radius: 2px;"></span>
                    <span style="font-size: 11px; color: #495057;">
                        ${etiqueta}: ${valor}${porcentaje ? ` (${porcentaje}%)` : ''}
                    </span>
                </div>
            `;
            
            contenedor.append(elementoLeyenda);
        });
    }
    
    // Aplicar animaciones
    function aplicarAnimaciones() {
        // Animación para barras
        $('.ac-barra').each(function(index) {
            $(this).delay(index * 100).animate({
                opacity: 1,
                translateY: 0
            }, 500);
        });
        
        // Animación para líneas
        $('.ac-linea').animate({
            opacity: 1,
            strokeDashoffset: 0
        }, 1000);
        
        // Animación para puntos
        $('.ac-punto-grupo').each(function(index) {
            $(this).delay(800 + (index * 100)).animate({
                opacity: 1,
                scale: 1
            }, 400);
        });
        
        // Animación para áreas
        $('.ac-area').animate({
            opacity: 1
        }, 800);
    }
    
    // Actualizar botones activos
    function actualizarBotonesActivos() {
        $('.ac-metrica-btn').removeClass('button-primary').addClass('button-secondary');
        $('.ac-grafico-btn').removeClass('button-primary').addClass('button-secondary');
        $('.ac-size-btn').removeClass('button-primary').addClass('button-secondary');
        $('.ac-animacion-btn').removeClass('button-primary').addClass('button-secondary');
        $('.ac-valores-btn').removeClass('button-primary').addClass('button-secondary');
        
        $(`.ac-metrica-btn[data-metrica="${metricaActual}"]`).removeClass('button-secondary').addClass('button-primary');
        $(`.ac-grafico-btn[data-grafico="${tipoGraficoActual}"]`).removeClass('button-secondary').addClass('button-primary');
        $(`.ac-size-btn[data-size="${configuracion.tamaño}"]`).removeClass('button-secondary').addClass('button-primary');
        $(`.ac-animacion-btn[data-animacion="${configuracion.animacion}"]`).removeClass('button-secondary').addClass('button-primary');
        $(`.ac-valores-btn[data-valores="${configuracion.mostrarValores}"]`).removeClass('button-secondary').addClass('button-primary');
    }
    
    // Actualizar URL sin recargar
    function actualizarURL(metrica, tipoGrafico) {
        const url = new URL(window.location);
        url.searchParams.set('metricas', metrica);
        url.searchParams.set('tipo_grafico', tipoGrafico);
        window.history.replaceState({}, '', url);
    }
    
    // Event listeners para botones
    $('.ac-metrica-btn').on('click', function() {
        metricaActual = $(this).data('metrica');
        cargarGrafico(metricaActual, tipoGraficoActual);
    });
    
    $('.ac-grafico-btn').on('click', function() {
        tipoGraficoActual = $(this).data('grafico');
        cargarGrafico(metricaActual, tipoGraficoActual);
    });
    
    $('.ac-size-btn').on('click', function() {
        configuracion.tamaño = $(this).data('size');
        cargarGrafico(metricaActual, tipoGraficoActual);
    });
    
    $('.ac-animacion-btn').on('click', function() {
        configuracion.animacion = $(this).data('animacion');
        cargarGrafico(metricaActual, tipoGraficoActual);
    });
    
    $('.ac-valores-btn').on('click', function() {
        configuracion.mostrarValores = $(this).data('valores');
        cargarGrafico(metricaActual, tipoGraficoActual);
    });
    
    // Búsqueda en tiempo real
    $('#buscar-camaras').on('keyup', function() {
        var searchText = $(this).val().toLowerCase();
        var resultados = 0;
        
        $('.ac-camara-row').each(function() {
            var nombre = $(this).data('nombre');
            var tipo = $(this).data('tipo');
            var ubicacion = $(this).data('ubicacion');
            
            if (nombre.indexOf(searchText) > -1 || 
                tipo.indexOf(searchText) > -1 || 
                ubicacion.indexOf(searchText) > -1) {
                $(this).show();
                resultados++;
            } else {
                $(this).hide();
            }
        });
        
        $('.description').text(resultados + ' cámara(s) encontrada(s)');
    });
    
    // Ordenar por fecha (más reciente primero)
    var rows = $('.ac-camara-row').get();
    rows.sort(function(a, b) {
        var fechaA = $(a).find('td:nth-child(2)').text();
        var fechaB = $(b).find('td:nth-child(2)').text();
        // Asumiendo que la fecha está en el formato dd/mm/yyyy
        var dateA = new Date(fechaA.split('/').reverse().join('-'));
        var dateB = new Date(fechaB.split('/').reverse().join('-'));
        return dateB - dateA;
    });
    
    $.each(rows, function(index, row) {
        $('#tabla-camaras tbody').append(row);
    });
    
    // Inicializar el gráfico al cargar la página
    inicializarGrafico();
});

// Función global para resaltar elementos
function acResaltarElemento(tipo, index) {
    if (tipo === 'barras') {
        // Resaltar barra específica
        const barras = document.querySelectorAll('.ac-barra');
        barras.forEach((barra, i) => {
            if (i === index) {
                barra.style.background = 'linear-gradient(to top, #5a6fd8, #667eea)';
                barra.style.transform = 'translateY(-5px)';
                barra.style.boxShadow = '0 4px 8px rgba(0,0,0,0.2)';
            } else {
                barra.style.background = 'linear-gradient(to top, #667eea, #764ba2)';
                barra.style.opacity = '0.5';
                barra.style.transform = 'translateY(0)';
            }
        });
        
        // Restaurar después de 2 segundos
        setTimeout(() => {
            barras.forEach(barra => {
                barra.style.background = 'linear-gradient(to top, #667eea, #764ba2)';
                barra.style.opacity = '1';
                barra.style.transform = 'translateY(0)';
                barra.style.boxShadow = 'none';
            });
        }, 2000);
    }
}
</script>

<style>
.ac-table-container {
    margin-top: 20px;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

/* Estilos para tipos de cámaras */
.ac-badge-ip {
    background: #f0f8ff !important;
    color: #667eea !important;
}

.ac-badge-analogica {
    background: #fff0f6 !important;
    color: #eb2f96 !important;
}

.ac-badge-wifi {
    background: #f6ffed !important;
    color: #52c41a !important;
}

.ac-badge-ptz {
    background: #fff7e6 !important;
    color: #fa8c16 !important;
}

.ac-badge-domo {
    background: #f9f0ff !important;
    color: #722ed1 !important;
}

.ac-badge-bullet {
    background: #fff0f0 !important;
    color: #e74c3c !important;
}

.ac-badge-otro {
    background: #f8f8f8 !important;
    color: #666 !important;
}

/* Estilos para interactividad */
.ac-barra {
    transition: all 0.3s ease !important;
}

.ac-barra:hover {
    transform: translateY(-5px) !important;
    box-shadow: 0 4px 8px rgba(0,0,0,0.2) !important;
}

.ac-linea {
    transition: all 0.3s ease;
}

.ac-linea:hover {
    stroke-width: 2.5;
}

.ac-punto-hover:hover + .ac-punto {
    r: 2.5 !important;
}

.ac-area {
    transition: all 0.3s ease;
}

.ac-area:hover {
    opacity: 0.9 !important;
}

.ac-leyenda-item {
    transition: all 0.3s ease;
}

/* Estilos para zoom y arrastre */
.ac-grafico-zoomable {
    transition: transform 0.3s ease;
    overflow: auto !important;
}

.ac-grafico-zoomable.zoomed {
    cursor: grab;
}

.ac-grafico-zoomable.zoomed:active {
    cursor: grabbing;
}

.ac-grafico-contenido {
    transition: transform 0.3s ease;
}

/* Animaciones */
@keyframes aparecerBarras {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes dibujarLinea {
    from {
        stroke-dashoffset: 1000;
    }
    to {
        stroke-dashoffset: 0;
    }
}

@keyframes aparecerPuntos {
    from {
        opacity: 0;
        transform: scale(0);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}

@media (max-width: 768px) {
    .ac-stats-container {
        grid-template-columns: 1fr !important;
    }
    
    .ac-header-actions {
        flex-direction: column;
        gap: 15px;
        align-items: flex-start !important;
    }
    
    .ac-action-buttons {
        flex-direction: column;
    }
    
    #buscar-camaras {
        width: 100% !important;
    }
    
    .ac-import-section > div {
        grid-template-columns: 1fr !important;
    }
    
    .ac-grafico-pastel {
        flex-direction: column;
    }
    
    .ac-grafico-barras {
        gap: 4px !important;
    }
    
    /* Ajustes de zoom para móviles */
    .ac-zoom-btn {
        padding: 8px 12px !important;
        font-size: 14px !important;
    }
    
    #zoom-level {
        font-size: 14px !important;
    }
}
</style>