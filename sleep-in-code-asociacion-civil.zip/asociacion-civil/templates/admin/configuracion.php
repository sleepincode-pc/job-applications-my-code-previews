<?php
$configuracion = get_option('asociacion_civil_settings', array());
?>

<div class="wrap">
    <h1>Configuración de la Asociación Civil</h1>
    
    <?php if (isset($_GET['updated'])): ?>
        <div class="notice notice-success is-dismissible">
            <p>Configuración actualizada correctamente.</p>
        </div>
    <?php endif; ?>
    
    <div class="ac-configuracion-container">
        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
            <input type="hidden" name="action" value="guardar_configuracion_asociacion">
            <?php wp_nonce_field('guardar_configuracion', 'configuracion_nonce'); ?>
            
            <div class="ac-config-section">
                <h2>Información Básica</h2>
                
                <div class="ac-form-grid">
                    <div class="ac-form-group">
                        <label for="nombre_asociacion">Nombre de la Asociación *</label>
                        <input type="text" id="nombre_asociacion" name="nombre_asociacion" required 
                               value="<?php echo isset($configuracion['nombre_asociacion']) ? esc_attr($configuracion['nombre_asociacion']) : ''; ?>"
                               placeholder="Ej: Asociación Civil Pro Desarrollo Comunitario">
                    </div>
                    
                    <div class="ac-form-group">
                        <label for="rif">RIF</label>
                        <input type="text" id="rif" name="rif" 
                               value="<?php echo isset($configuracion['rif']) ? esc_attr($configuracion['rif']) : ''; ?>"
                               placeholder="Ej: J-12345678-9">
                    </div>
                </div>
                
                <div class="ac-form-grid">
                    <div class="ac-form-group">
                        <label for="numero_registro">Número de Registro</label>
                        <input type="text" id="numero_registro" name="numero_registro" 
                               value="<?php echo isset($configuracion['numero_registro']) ? esc_attr($configuracion['numero_registro']) : ''; ?>"
                               placeholder="Número de registro oficial">
                    </div>
                    
                    <div class="ac-form-group">
                        <label for="fecha_constitucion">Fecha de Constitución</label>
                        <input type="date" id="fecha_constitucion" name="fecha_constitucion" 
                               value="<?php echo isset($configuracion['fecha_constitucion']) ? esc_attr($configuracion['fecha_constitucion']) : ''; ?>">
                    </div>
                </div>
            </div>
            
            <div class="ac-config-section">
                <h2>Información de Contacto</h2>
                
                <div class="ac-form-group">
                    <label for="direccion">Dirección</label>
                    <textarea id="direccion" name="direccion" rows="3" 
                              placeholder="Dirección completa de la asociación"><?php 
                        echo isset($configuracion['direccion']) ? esc_textarea($configuracion['direccion']) : ''; 
                    ?></textarea>
                </div>
                
                <div class="ac-form-grid">
                    <div class="ac-form-group">
                        <label for="telefono">Teléfono</label>
                        <input type="text" id="telefono" name="telefono" 
                               value="<?php echo isset($configuracion['telefono']) ? esc_attr($configuracion['telefono']) : ''; ?>"
                               placeholder="Ej: +58 212-123-4567">
                    </div>
                    
                    <div class="ac-form-group">
                        <label for="email">Email de Contacto</label>
                        <input type="email" id="email" name="email" 
                               value="<?php echo isset($configuracion['email']) ? esc_attr($configuracion['email']) : ''; ?>"
                               placeholder="Ej: info@asociacion.org">
                    </div>
                </div>
            </div>
            
            <div class="ac-config-section">
                <h2>Configuración del Sistema</h2>
                
                <div class="ac-form-grid">
                    <div class="ac-form-group">
                        <label for="miembros_por_pagina">Miembros por página</label>
                        <input type="number" id="miembros_por_pagina" name="miembros_por_pagina" 
                               value="<?php echo esc_attr(get_option('ac_miembros_por_pagina', 20)); ?>"
                               min="5" max="100">
                    </div>
                    
                    <div class="ac-form-group">
                        <label for="dias_recordatorio">Días de recordatorio para eventos</label>
                        <input type="number" id="dias_recordatorio" name="dias_recordatorio" 
                               value="<?php echo esc_attr(get_option('ac_dias_recordatorio', 7)); ?>"
                               min="1" max="30">
                        <p class="description">Días de anticipación para recordatorios de eventos</p>
                    </div>
                </div>
                
                <div class="ac-form-group">
                    <label>
                        <input type="checkbox" name="notificaciones_email" value="1" 
                               <?php checked(get_option('ac_notificaciones_email', 1), 1); ?>>
                        Enviar notificaciones por email
                    </label>
                </div>
                
                <div class="ac-form-group">
                    <label>
                        <input type="checkbox" name="backup_automatico" value="1" 
                               <?php checked(get_option('ac_backup_automatico', 0), 1); ?>>
                        Realizar backup automático mensual
                    </label>
                </div>
            </div>
            
            <div class="ac-config-section">
                <h2>Mantenimiento</h2>
                
                <div class="ac-mantenimiento-actions">
                    <div class="ac-action-card">
                        <h3>Exportar Datos</h3>
                        <p>Exportar todos los datos de la asociación en formato CSV</p>
                        <button type="button" id="exportar-datos" class="button">Exportar Datos Completos</button>
                    </div>
                    
                    <div class="ac-action-card">
                        <h3>Limpiar Cache</h3>
                        <p>Limpiar cache temporal del sistema</p>
                        <button type="button" id="limpiar-cache" class="button">Limpiar Cache</button>
                    </div>
                    
                    <div class="ac-action-card">
                        <h3>Verificar Base de Datos</h3>
                        <p>Verificar integridad de las tablas de la base de datos</p>
                        <button type="button" id="verificar-bd" class="button">Verificar BD</button>
                    </div>
                </div>
            </div>
            
            <div class="ac-form-submit">
                <button type="submit" class="button button-primary button-large">Guardar Configuración</button>
                <button type="reset" class="button button-large">Restablecer</button>
            </div>
        </form>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Validación de email
    $('#email').on('blur', function() {
        var email = $(this).val();
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (email.length > 0 && !emailRegex.test(email)) {
            alert('Por favor ingrese un email válido');
            $(this).focus();
        }
    });
    
    // Acciones de mantenimiento
    $('#exportar-datos').on('click', function() {
        if (confirm('¿Exportar todos los datos de la asociación?')) {
            window.location.href = '<?php echo admin_url('admin-post.php?action=exportar_datos_completos'); ?>';
        }
    });
    
    $('#limpiar-cache').on('click', function() {
        if (confirm('¿Limpiar cache del sistema?')) {
            $.post(ajaxurl, {
                action: 'limpiar_cache_asociacion',
                nonce: '<?php echo wp_create_nonce("limpiar_cache"); ?>'
            }, function(response) {
                alert(response.data);
            });
        }
    });
    
    $('#verificar-bd').on('click', function() {
        $.post(ajaxurl, {
            action: 'verificar_bd_asociacion',
            nonce: '<?php echo wp_create_nonce("verificar_bd"); ?>'
        }, function(response) {
            alert(response.data);
        });
    });
});
</script>