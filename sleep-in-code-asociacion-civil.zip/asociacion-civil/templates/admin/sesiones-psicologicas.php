<?php
if (!defined('ABSPATH')) {
    exit;
}

// Verificar que $sesiones esté definida y sea un array
if (!isset($sesiones) || !is_array($sesiones)) {
    $sesiones = array();
}

// Verificar que $pacientes esté definida y sea un array  
if (!isset($pacientes) || !is_array($pacientes)) {
    $pacientes = array();
}

// Manejar exportaciones
if (isset($_GET['export'])) {
    $export_type = $_GET['export'];
    
    if ($export_type === 'csv') {
        ac_exportar_sesiones_csv($sesiones);
    } elseif ($export_type === 'pdf') {
        ac_exportar_sesiones_pdf($sesiones);
    } elseif ($export_type === 'pdf_individual' && isset($_GET['id'])) {
        $sesion_id = intval($_GET['id']);
        $sesion_individual = null;
        
        foreach ($sesiones as $sesion) {
            if ($sesion->getId() === $sesion_id) {
                $sesion_individual = $sesion;
                break;
            }
        }
        
        if ($sesion_individual) {
            ac_exportar_sesion_pdf_individual($sesion_individual);
        }
    }
}

// Funciones de exportación para sesiones
function ac_exportar_sesiones_csv($sesiones) {
    $filename = 'sesiones_psicologicas_' . date('Y-m-d') . '.csv';
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $output = fopen('php://output', 'w');
    fputs($output, "\xEF\xBB\xBF");
    
    // Encabezados
    fputcsv($output, array(
        'ID', 'Paciente', 'Psicólogo', 'Fecha Sesión', 'Duración (min)', 
        'Tipo Sesión', 'Motivo Consulta', 'Estado', 'Próxima Sesión'
    ), ';');
    
    // Datos
    foreach ($sesiones as $sesion) {
        if (is_object($sesion) && method_exists($sesion, 'getPacienteNombre')) {
            fputcsv($output, array(
                $sesion->getId(),
                $sesion->getPacienteNombre(),
                $sesion->getPsicologoNombre(),
                $sesion->getFechaSesion(),
                $sesion->getDuracion(),
                $sesion->getTipoSesion(),
                $sesion->getMotivoConsulta(),
                $sesion->getEstado(),
                $sesion->getProximaSesion()
            ), ';');
        }
    }
    
    fclose($output);
    exit;
}

function ac_exportar_sesiones_pdf($sesiones) {
    $filename = 'sesiones_psicologicas_' . date('Y-m-d') . '.pdf';
    
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Reporte de Sesiones Psicológicas</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { text-align: center; color: #333; }
            h2 { color: #0073aa; background-color: #f8f9fa; padding: 10px; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .section { margin-bottom: 30px; border: 1px solid #ddd; padding: 15px; }
            .paciente-info { background-color: #f0f8ff; }
            .observaciones { border-color: #46b450; background-color: #f0fff0; }
        </style>
    </head>
    <body>
        <h1>Reporte de Sesiones Psicológicas</h1>
        <p style="text-align: center;">Exportado el: ' . date('d/m/Y H:i:s') . '</p>
        <p style="text-align: center;">Total de sesiones: ' . count($sesiones) . '</p>
        <hr>';
    
    foreach ($sesiones as $index => $sesion) {
        if (is_object($sesion) && method_exists($sesion, 'getPacienteNombre')) {
            $html .= '<div class="section">
                <h2>Sesión #' . ($index + 1) . ' - ' . $sesion->getPacienteNombre() . '</h2>
                <table>
                    <tr><td style="width: 30%; font-weight: bold;">Fecha Sesión:</td><td>' . date('d/m/Y H:i', strtotime($sesion->getFechaSesion())) . '</td></tr>
                    <tr><td style="font-weight: bold;">Psicólogo:</td><td>' . $sesion->getPsicologoNombre() . '</td></tr>
                    <tr><td style="font-weight: bold;">Duración:</td><td>' . $sesion->getDuracion() . ' minutos</td></tr>
                    <tr><td style="font-weight: bold;">Tipo Sesión:</td><td>' . $sesion->getTipoSesion() . '</td></tr>
                    <tr><td style="font-weight: bold;">Estado:</td><td>' . $sesion->getEstado() . '</td></tr>
                </table>';
            
            if ($sesion->getMotivoConsulta()) {
                $html .= '<h4>Motivo de Consulta:</h4>
                <div style="border: 1px solid #ddd; padding: 10px; background-color: #f9f9f9;">
                    ' . nl2br($sesion->getMotivoConsulta()) . '
                </div>';
            }
            
            if ($sesion->getContenidoSesion()) {
                $html .= '<h4>Contenido de la Sesión:</h4>
                <div style="border: 1px solid #ddd; padding: 10px; background-color: #f9f9f9;">
                    ' . strip_tags($sesion->getContenidoSesion()) . '
                </div>';
            }
            
            if ($sesion->getObservaciones()) {
                $html .= '<h4>Observaciones:</h4>
                <div style="border: 1px solid #46b450; padding: 10px; background-color: #f0fff0;">
                    ' . strip_tags($sesion->getObservaciones()) . '
                </div>';
            }
            
            if ($sesion->getProximaSesion()) {
                $html .= '<h4>Próxima Sesión:</h4>
                <div style="border: 1px solid #ffb900; padding: 10px; background-color: #fff8e7;">
                    ' . date('d/m/Y H:i', strtotime($sesion->getProximaSesion())) . '
                </div>';
            }
            
            $html .= '</div><hr style="margin: 20px 0;">';
        }
    }
    
    $html .= '</body></html>';
    
    echo $html;
    exit;
}

function ac_exportar_sesion_pdf_individual($sesion) {
    $filename = 'sesion_' . sanitize_title($sesion->getPacienteNombre()) . '_' . date('Y-m-d') . '.pdf';
    
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Sesión Psicológica - ' . $sesion->getPacienteNombre() . '</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 30px; line-height: 1.6; }
            h1 { text-align: center; color: #333; margin-bottom: 10px; }
            h2 { text-align: center; color: #0073aa; margin-bottom: 30px; }
            .header-info { margin-bottom: 30px; }
            .info-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            .info-table td { padding: 8px; border-bottom: 1px solid #eee; }
            .info-table td:first-child { font-weight: bold; width: 25%; }
            .section { margin-bottom: 25px; }
            .section-title { color: #555; border-bottom: 2px solid #0073aa; padding-bottom: 5px; margin-bottom: 10px; }
            .content-box { border: 1px solid #ddd; padding: 15px; background-color: #f9f9f9; margin-bottom: 15px; }
            .observaciones-box { border-color: #46b450; background-color: #f0fff0; }
            .proxima-sesion-box { border-color: #ffb900; background-color: #fff8e7; }
            .footer { text-align: center; margin-top: 40px; color: #666; font-size: 12px; }
        </style>
    </head>
    <body>
        <h1>INFORME DE SESIÓN PSICOLÓGICA</h1>
        <h2>' . $sesion->getPacienteNombre() . '</h2>
        
        <div class="header-info">
            <table class="info-table">
                <tr>
                    <td>Fecha de Sesión:</td>
                    <td>' . date('d/m/Y H:i', strtotime($sesion->getFechaSesion())) . '</td>
                </tr>
                <tr>
                    <td>Psicólogo:</td>
                    <td>' . $sesion->getPsicologoNombre() . '</td>
                </tr>
                <tr>
                    <td>Duración:</td>
                    <td>' . $sesion->getDuracion() . ' minutos</td>
                </tr>
                <tr>
                    <td>Tipo de Sesión:</td>
                    <td>' . $sesion->getTipoSesion() . '</td>
                </tr>
                <tr>
                    <td>Estado:</td>
                    <td>' . $sesion->getEstado() . '</td>
                </tr>
            </table>
        </div>';
    
    if ($sesion->getMotivoConsulta()) {
        $html .= '<div class="section">
            <h3 class="section-title">MOTIVO DE CONSULTA</h3>
            <div class="content-box">' . nl2br($sesion->getMotivoConsulta()) . '</div>
        </div>';
    }
    
    if ($sesion->getContenidoSesion()) {
        $html .= '<div class="section">
            <h3 class="section-title">DESARROLLO DE LA SESIÓN</h3>
            <div class="content-box">' . strip_tags($sesion->getContenidoSesion()) . '</div>
        </div>';
    }
    
    if ($sesion->getObservaciones()) {
        $html .= '<div class="section">
            <h3 class="section-title">OBSERVACIONES DEL TERAPEUTA</h3>
            <div class="content-box observaciones-box">' . strip_tags($sesion->getObservaciones()) . '</div>
        </div>';
    }
    
    if ($sesion->getProximaSesion()) {
        $html .= '<div class="section">
            <h3 class="section-title">PRÓXIMA SESIÓN PROGRAMADA</h3>
            <div class="content-box proxima-sesion-box">
                ' . date('d/m/Y H:i', strtotime($sesion->getProximaSesion())) . '
            </div>
        </div>';
    }
    
    $html .= '<div class="footer">
            Documento generado el ' . date('d/m/Y H:i:s') . '<br>
            ' . get_bloginfo('name') . ' - Área de Psicología
        </div>
    </body>
    </html>';
    
    echo $html;
    exit;
}

// Manejar guardado de sesión desde formulario
if (isset($_POST['guardar_sesion'])) {
    ac_guardar_sesion_psicologica();
}

function ac_guardar_sesion_psicologica() {
    // Verificar nonce para seguridad
    if (!wp_verify_nonce($_POST['_wpnonce'], 'guardar_sesion_psicologica')) {
        wp_die('Error de seguridad');
    }
    
    $paciente_id = intval($_POST['paciente_id']);
    $psicologo_id = intval($_POST['psicologo_id']);
    $fecha_sesion = sanitize_text_field($_POST['fecha_sesion']);
    $duracion = intval($_POST['duracion']);
    $tipo_sesion = sanitize_text_field($_POST['tipo_sesion']);
    $motivo_consulta = sanitize_textarea_field($_POST['motivo_consulta']);
    $contenido_sesion = sanitize_textarea_field($_POST['contenido_sesion']);
    $observaciones = sanitize_textarea_field($_POST['observaciones']);
    $estado = sanitize_text_field($_POST['estado']);
    $proxima_sesion = sanitize_text_field($_POST['proxima_sesion']);
    
    // Aquí deberías llamar a tu función para guardar la sesión en la base de datos
    // Por ejemplo:
    // $sesion_id = guardar_sesion($paciente_id, $psicologo_id, $fecha_sesion, $duracion, $tipo_sesion, $motivo_consulta, $contenido_sesion, $observaciones, $estado, $proxima_sesion);
    
    // Simulación de guardado exitoso
    $guardado_exitoso = true;
    
    if ($guardado_exitoso) {
        echo '<div class="notice notice-success is-dismissible">';
        echo '<p>✅ Sesión psicológica guardada correctamente.</p>';
        echo '</div>';
        
        // Redirigir para evitar reenvío del formulario
        echo '<script>setTimeout(function() { window.location.href = "' . admin_url('admin.php?page=ac-sesiones') . '"; }, 2000);</script>';
    } else {
        echo '<div class="notice notice-error is-dismissible">';
        echo '<p>❌ Error al guardar la sesión. Por favor, inténtalo de nuevo.</p>';
        echo '</div>';
    }
}

// Estadísticas para sesiones psicológicas
$total_sesiones = count($sesiones);
$sesiones_por_mes = array();
$sesiones_por_psicologo = array();
$sesiones_por_tipo = array();
$pacientes_activos = array();
$sesion_mas_reciente = null;

foreach ($sesiones as $sesion) {
    if (is_object($sesion) && method_exists($sesion, 'getFechaSesion')) {
        // Por mes
        $fecha = $sesion->getFechaSesion();
        if ($fecha) {
            $mes = date('Y-m', strtotime($fecha));
            if (!isset($sesiones_por_mes[$mes])) {
                $sesiones_por_mes[$mes] = 0;
            }
            $sesiones_por_mes[$mes]++;
        }
        
        // Por psicólogo
        $psicologo = $sesion->getPsicologoNombre();
        if (!isset($sesiones_por_psicologo[$psicologo])) {
            $sesiones_por_psicologo[$psicologo] = 0;
        }
        $sesiones_por_psicologo[$psicologo]++;
        
        // Por tipo
        $tipo = $sesion->getTipoSesion();
        if (!isset($sesiones_por_tipo[$tipo])) {
            $sesiones_por_tipo[$tipo] = 0;
        }
        $sesiones_por_tipo[$tipo]++;
        
        // Pacientes activos
        $paciente_id = $sesion->getPacienteId();
        if (!in_array($paciente_id, $pacientes_activos)) {
            $pacientes_activos[] = $paciente_id;
        }
        
        // Sesión más reciente
        if (!$sesion_mas_reciente || strtotime($fecha) > strtotime($sesion_mas_reciente->getFechaSesion())) {
            $sesion_mas_reciente = $sesion;
        }
    }
}

// Ordenar estadísticas
krsort($sesiones_por_mes);
arsort($sesiones_por_psicologo);
arsort($sesiones_por_tipo);

// Calcular promedios
$total_pacientes_activos = count($pacientes_activos);
$promedio_sesiones_por_paciente = $total_pacientes_activos > 0 ? round($total_sesiones / $total_pacientes_activos, 1) : 0;

// Preparar datos para gráficos
$datos_grafico_json = array();
$datos_grafico_json['mes'] = array_slice($sesiones_por_mes, 0, 6, true);
$datos_grafico_json['psicologo'] = $sesiones_por_psicologo;
$datos_grafico_json['tipo'] = $sesiones_por_tipo;

?>

<div class="wrap">
    <h1 class="wp-heading-inline">👥 Sesiones Psicológicas</h1>
    
    <!-- Panel de Métricas para Sesiones -->
    <div class="ac-metrics-panel" style="margin: 20px 0;">
        <h2 style="margin-bottom: 15px; color: #23282d;">📊 Métricas de Sesiones Psicológicas</h2>
        
        <div class="ac-stats-container" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; margin-bottom: 20px;">
            <!-- Métrica Principal -->
            <div class="ac-stat-card" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="display: flex; justify-content: between; align-items: center;">
                    <div>
                        <h3 style="margin: 0 0 5px 0; font-size: 14px; opacity: 0.9;">TOTAL DE SESIONES</h3>
                        <p style="font-size: 32px; font-weight: bold; margin: 0;">🛋️ <?php echo $total_sesiones; ?></p>
                    </div>
                    <div style="font-size: 24px;">🛋️</div>
                </div>
                <div style="margin-top: 10px; font-size: 12px; opacity: 0.8;">
                    <?php echo $total_pacientes_activos; ?> pacientes activos • 
                    <?php echo $promedio_sesiones_por_paciente; ?> sesiones/paciente
                </div>
            </div>

            <!-- Distribución por Tipo -->
            <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #667eea; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #667eea; font-size: 14px;">DISTRIBUCIÓN POR TIPO</h3>
                <div style="max-height: 120px; overflow-y: auto;">
                    <?php foreach ($sesiones_por_tipo as $tipo => $cantidad): 
                        $porcentaje = $total_sesiones > 0 ? round(($cantidad / $total_sesiones) * 100) : 0;
                    ?>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                        <span><?php echo esc_html($tipo); ?></span>
                        <span style="font-weight: bold;"><?php echo $cantidad; ?> (<?php echo $porcentaje; ?>%)</span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Psicólogos -->
            <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #f093fb; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #f093fb; font-size: 14px;">SESIONES POR PSICÓLOGO</h3>
                <div style="max-height: 120px; overflow-y: auto;">
                    <?php foreach ($sesiones_por_psicologo as $psicologo => $cantidad): 
                        $porcentaje = $total_sesiones > 0 ? round(($cantidad / $total_sesiones) * 100) : 0;
                    ?>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                        <span><?php echo esc_html($psicologo); ?></span>
                        <span style="font-weight: bold;"><?php echo $cantidad; ?> (<?php echo $porcentaje; ?>%)</span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Información General -->
            <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #4facfe; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #4facfe; font-size: 14px;">INFORMACIÓN GENERAL</h3>
                <div style="display: grid; gap: 8px; font-size: 12px;">
                    <div style="display: flex; justify-content: space-between;">
                        <span>Pacientes activos:</span>
                        <strong><?php echo $total_pacientes_activos; ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Promedio sesiones/paciente:</span>
                        <strong><?php echo $promedio_sesiones_por_paciente; ?></strong>
                    </div>
                    <?php if ($sesion_mas_reciente): ?>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Última sesión:</span>
                        <strong><?php echo date('d/m/Y', strtotime($sesion_mas_reciente->getFechaSesion())); ?></strong>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Acciones Principales -->
    <div class="ac-header-actions" style="display: flex; justify-content: space-between; align-items: center; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px;">
        <div>
            <a href="<?php echo admin_url('admin.php?page=ac-sesiones&action=nueva'); ?>" class="button button-primary" style="font-size: 14px; padding: 8px 16px;">
                <span class="dashicons dashicons-plus" style="margin-top: 4px;"></span>
                Nueva Sesión
            </a>
            <?php if (!empty($sesiones)): ?>
            <div class="ac-export-buttons" style="display: inline-block; margin-left: 10px;">
                <a href="<?php echo admin_url('admin.php?page=ac-sesiones&export=csv'); ?>" class="button" style="font-size: 14px; padding: 8px 16px;">
                    <span class="dashicons dashicons-media-spreadsheet" style="margin-top: 4px;"></span>
                    Exportar CSV
                </a>
                <a href="<?php echo admin_url('admin.php?page=ac-sesiones&export=pdf'); ?>" class="button" style="font-size: 14px; padding: 8px 16px; margin-left: 5px;">
                    <span class="dashicons dashicons-media-document" style="margin-top: 4px;"></span>
                    Exportar PDF
                </a>
            </div>
            <?php endif; ?>
        </div>
        
        <?php if (!empty($sesiones)): ?>
        <div class="ac-search-export" style="display: flex; gap: 10px; align-items: center;">
            <input type="text" id="buscar-sesiones" placeholder="Buscar en sesiones..." style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; width: 250px;">
            <span class="description" style="color: #666; font-size: 13px;">
                <?php echo $total_sesiones; ?> sesión(es) registrada(s)
            </span>
        </div>
        <?php endif; ?>
    </div>

    <!-- Sección de Seguimiento de Pacientes -->
    <div class="ac-pacientes-section" style="background: #f0f8ff; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #667eea;">
        <h3 style="margin-top: 0; color: #667eea;">
            <span class="dashicons dashicons-groups" style="margin-right: 5px;"></span>
            Seguimiento de Pacientes
        </h3>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 15px;">
            <?php foreach ($pacientes as $paciente): ?>
                <?php 
                // Obtener sesiones del paciente
                $sesiones_paciente = array_filter($sesiones, function($sesion) use ($paciente) {
                    return $sesion->getPacienteId() === $paciente->getId();
                });
                $total_sesiones_paciente = count($sesiones_paciente);
                $ultima_sesion = !empty($sesiones_paciente) ? end($sesiones_paciente) : null;
                ?>
                
                <div class="ac-paciente-card" style="background: white; border: 1px solid #e1e5e9; border-radius: 8px; padding: 15px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px;">
                        <?php if ($paciente->getFoto()): ?>
                            <img src="<?php echo esc_url($paciente->getFoto()); ?>" alt="<?php echo esc_attr($paciente->getNombreCompleto()); ?>" style="width: 60px; height: 60px; border-radius: 50%; object-fit: cover;">
                        <?php else: ?>
                            <div style="width: 60px; height: 60px; border-radius: 50%; background: #667eea; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                                <?php echo substr($paciente->getNombre(), 0, 1) . substr($paciente->getApellido(), 0, 1); ?>
                            </div>
                        <?php endif; ?>
                        
                        <div style="flex: 1;">
                            <h4 style="margin: 0 0 5px 0; color: #333;"><?php echo esc_html($paciente->getNombreCompleto()); ?></h4>
                            <p style="margin: 0; color: #666; font-size: 12px;">
                                <?php echo $paciente->getCedula(); ?> • 
                                <?php echo $paciente->getEdad(); ?> años
                            </p>
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 15px;">
                        <div style="text-align: center;">
                            <div style="font-size: 18px; font-weight: bold; color: #667eea;"><?php echo $total_sesiones_paciente; ?></div>
                            <div style="font-size: 11px; color: #666;">Sesiones</div>
                        </div>
                        <div style="text-align: center;">
                            <div style="font-size: 18px; font-weight: bold; color: #4facfe;">
                                <?php echo $ultima_sesion ? date('d/m', strtotime($ultima_sesion->getFechaSesion())) : '--'; ?>
                            </div>
                            <div style="font-size: 11px; color: #666;">Última</div>
                        </div>
                    </div>
                    
                    <div style="display: flex; gap: 5px;">
                        <a href="<?php echo admin_url('admin.php?page=ac-sesiones&action=ver-paciente&id=' . $paciente->getId()); ?>" class="button" style="flex: 1; text-align: center; padding: 6px; font-size: 11px;">
                            Ver Historial
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=ac-sesiones&action=nueva&paciente_id=' . $paciente->getId()); ?>" class="button button-primary" style="flex: 1; text-align: center; padding: 6px; font-size: 11px;">
                            Nueva Sesión
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <?php if (empty($sesiones)): ?>
        <div class="notice notice-info" style="padding: 20px; text-align: center;">
            <h3 style="margin-top: 0;">🛋️ Comienza el Registro de Sesiones</h3>
            <p>No hay sesiones psicológicas registradas en el sistema. Crea la primera sesión para comenzar el seguimiento de pacientes.</p>
            <p style="margin-top: 15px;">
                <a href="<?php echo admin_url('admin.php?page=ac-sesiones&action=nueva'); ?>" class="button button-primary button-large">
                    <span class="dashicons dashicons-plus"></span>
                    Crear la primera sesión
                </a>
            </p>
        </div>
    <?php else: ?>
        <div class="ac-table-container">
            <table class="wp-list-table widefat fixed striped" id="tabla-sesiones">
                <thead>
                    <tr>
                        <th width="15%">Paciente</th>
                        <th width="15%">Psicólogo</th>
                        <th width="12%">Fecha</th>
                        <th width="8%">Duración</th>
                        <th width="10%">Tipo</th>
                        <th width="20%">Motivo</th>
                        <th width="10%">Estado</th>
                        <th width="10%">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($sesiones as $sesion_item): ?>
                        <?php if (is_object($sesion_item) && method_exists($sesion_item, 'getPacienteNombre')): ?>
                        <tr class="ac-sesion-row" data-paciente="<?php echo esc_attr(strtolower($sesion_item->getPacienteNombre())); ?>" data-psicologo="<?php echo esc_attr(strtolower($sesion_item->getPsicologoNombre())); ?>" data-tipo="<?php echo esc_attr(strtolower($sesion_item->getTipoSesion())); ?>">
                            <td>
                                <div style="display: flex; align-items: center; gap: 8px;">
                                    <?php 
                                    $paciente_foto = $sesion_item->getPacienteFoto();
                                    if ($paciente_foto): 
                                    ?>
                                        <img src="<?php echo esc_url($paciente_foto); ?>" alt="<?php echo esc_attr($sesion_item->getPacienteNombre()); ?>" style="width: 32px; height: 32px; border-radius: 50%; object-fit: cover;">
                                    <?php else: ?>
                                        <div style="width: 32px; height: 32px; border-radius: 50%; background: #667eea; display: flex; align-items: center; justify-content: center; color: white; font-size: 12px; font-weight: bold;">
                                            <?php 
                                            $nombre = $sesion_item->getPacienteNombre();
                                            $apellido = $sesion_item->getPacienteApellido();
                                            echo substr($nombre, 0, 1) . substr($apellido, 0, 1); 
                                            ?>
                                        </div>
                                    <?php endif; ?>
                                    <div>
                                        <strong><?php echo esc_html($sesion_item->getPacienteNombre()); ?></strong>
                                        <br>
                                        <small style="color: #666;"><?php echo esc_html($sesion_item->getPacienteCedula()); ?></small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <strong><?php echo esc_html($sesion_item->getPsicologoNombre()); ?></strong>
                            </td>
                            <td>
                                <?php 
                                $fecha = $sesion_item->getFechaSesion();
                                echo esc_html(date('d/m/Y H:i', strtotime($fecha)));
                                ?>
                            </td>
                            <td>
                                <span class="ac-badge" style="background: #e7f3ff; color: #0073aa; padding: 4px 8px; border-radius: 3px; font-size: 12px; font-weight: 500;">
                                    <?php echo esc_html($sesion_item->getDuracion()); ?> min
                                </span>
                            </td>
                            <td>
                                <span class="ac-badge ac-badge-<?php echo esc_attr($sesion_item->getTipoSesion()); ?>" style="background: #f0f8ff; color: #667eea; padding: 4px 8px; border-radius: 3px; font-size: 12px; font-weight: 500;">
                                    <?php echo esc_html($sesion_item->getTipoSesion()); ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($sesion_item->getMotivoConsulta()): ?>
                                    <?php 
                                    $resumen = strip_tags($sesion_item->getMotivoConsulta());
                                    if (strlen($resumen) > 100) {
                                        echo esc_html(substr($resumen, 0, 100) . '...');
                                    } else {
                                        echo esc_html($resumen);
                                    }
                                    ?>
                                <?php else: ?>
                                    <span style="color: #999;">Sin motivo especificado</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="ac-badge ac-badge-<?php echo esc_attr($sesion_item->getEstado()); ?>" 
                                      style="background: <?php echo $sesion_item->getEstado() === 'completada' ? '#f0fff0' : '#fff8e7'; ?>; 
                                             color: <?php echo $sesion_item->getEstado() === 'completada' ? '#46b450' : '#cc8500'; ?>; 
                                             padding: 4px 8px; border-radius: 3px; font-size: 12px; font-weight: 500;">
                                    <?php echo esc_html($sesion_item->getEstado()); ?>
                                </span>
                            </td>
                            <td>
                                <div class="ac-action-buttons" style="display: flex; gap: 5px; flex-wrap: wrap;">
                                    <a href="<?php echo admin_url('admin.php?page=ac-sesiones&action=ver&id=' . $sesion_item->getId()); ?>" class="button" title="Ver sesión completa" style="padding: 4px 8px; font-size: 12px;">
                                        <span class="dashicons dashicons-visibility" style="font-size: 14px; margin-top: 2px;"></span>
                                        Ver
                                    </a>
                                    <a href="<?php echo admin_url('admin.php?page=ac-sesiones&action=editar&id=' . $sesion_item->getId()); ?>" class="button" title="Editar sesión" style="padding: 4px 8px; font-size: 12px;">
                                        <span class="dashicons dashicons-edit" style="font-size: 14px; margin-top: 2px;"></span>
                                        Editar
                                    </a>
                                    <a href="<?php echo admin_url('admin.php?page=ac-sesiones&export=pdf_individual&id=' . $sesion_item->getId()); ?>" class="button" title="Exportar a PDF" style="padding: 4px 8px; font-size: 12px; background: #dc3232; color: white; border-color: #dc3232;">
                                        <span class="dashicons dashicons-media-document" style="font-size: 14px; margin-top: 2px;"></span>
                                        PDF
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Paciente</th>
                        <th>Psicólogo</th>
                        <th>Fecha</th>
                        <th>Duración</th>
                        <th>Tipo</th>
                        <th>Motivo</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    <?php endif; ?>
</div>

<script>
jQuery(document).ready(function($) {
    // Búsqueda en tiempo real
    $('#buscar-sesiones').on('keyup', function() {
        var searchText = $(this).val().toLowerCase();
        var resultados = 0;
        
        $('.ac-sesion-row').each(function() {
            var paciente = $(this).data('paciente');
            var psicologo = $(this).data('psicologo');
            var tipo = $(this).data('tipo');
            
            if (paciente.indexOf(searchText) > -1 || 
                psicologo.indexOf(searchText) > -1 || 
                tipo.indexOf(searchText) > -1) {
                $(this).show();
                resultados++;
            } else {
                $(this).hide();
            }
        });
        
        $('.description').text(resultados + ' sesión(es) encontrada(s)');
    });
    
    // Ordenar por fecha (más reciente primero)
    var rows = $('.ac-sesion-row').get();
    rows.sort(function(a, b) {
        var dateA = new Date($(a).find('td:nth-child(3)').text().split(' ')[0].split('/').reverse().join('-'));
        var dateB = new Date($(b).find('td:nth-child(3)').text().split(' ')[0].split('/').reverse().join('-'));
        return dateB - dateA;
    });
    
    $.each(rows, function(index, row) {
        $('#tabla-sesiones tbody').append(row);
    });
});
</script>

<style>
.ac-table-container {
    margin-top: 20px;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

/* Estilos para tipos de sesión */
.ac-badge-individual {
    background: #f0f8ff !important;
    color: #667eea !important;
}

.ac-badge-grupal {
    background: #fff0f6 !important;
    color: #eb2f96 !important;
}

.ac-badge-familiar {
    background: #f6ffed !important;
    color: #52c41a !important;
}

.ac-badge-evaluacion {
    background: #fff7e6 !important;
    color: #fa8c16 !important;
}

.ac-badge-seguimiento {
    background: #f9f0ff !important;
    color: #722ed1 !important;
}

/* Estilos para estados */
.ac-badge-completada {
    background: #f6ffed !important;
    color: #52c41a !important;
}

.ac-badge-pendiente {
    background: #fff7e6 !important;
    color: #fa8c16 !important;
}

.ac-badge-cancelada {
    background: #fff2f0 !important;
    color: #ff4d4f !important;
}

.ac-badge-reprogramada {
    background: #f0f8ff !important;
    color: #1890ff !important;
}

/* Responsive */
@media (max-width: 768px) {
    .ac-stats-container {
        grid-template-columns: 1fr !important;
    }
    
    .ac-header-actions {
        flex-direction: column;
        gap: 15px;
        align-items: flex-start !important;
    }
    
    .ac-action-buttons {
        flex-direction: column;
    }
    
    #buscar-sesiones {
        width: 100% !important;
    }
    
    .ac-pacientes-section > div {
        grid-template-columns: 1fr !important;
    }
    
    .ac-paciente-card {
        text-align: center;
    }
}
</style>