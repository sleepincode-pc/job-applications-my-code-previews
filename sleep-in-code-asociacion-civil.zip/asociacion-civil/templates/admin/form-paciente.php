<?php
if (!defined('ABSPATH')) {
    exit;
}

// Cargar FileManager para gestionar fotos
if (!class_exists('AsociacionCivil\FileManager')) {
    require_once plugin_dir_path(dirname(__FILE__, 2)) . 'includes/classes/FileManager.php';
}
$file_manager = new AsociacionCivil\FileManager();

$es_nuevo = !$paciente->getId();
$titulo = $es_nuevo ? 'Agregar Nuevo Paciente' : 'Editar Paciente: ' . $paciente->getNombreCompleto();

// Obtener foto de perfil actual si existe
$foto_perfil_actual = null;
if (!$es_nuevo) {
    $fotos = $file_manager->get_paciente_fotos($paciente->getId());
    foreach ($fotos as $foto) {
        if ($foto['tipo'] === 'perfil') {
            $foto_perfil_actual = $foto;
            break;
        }
    }
}
?>

<div class="wrap" style="background: white; color: black; padding: 20px;">
    <h1 style="color: black;"><?php echo $titulo; ?></h1>

    <form method="post" enctype="multipart/form-data">
        <?php wp_nonce_field('guardar_paciente', 'paciente_nonce'); ?>
        
        <div class="ac-card" style="background: white; border: 1px solid #ccc; margin-bottom: 20px; border-radius: 8px;">
            <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                <h2 style="color: black; margin: 0;">📷 Foto de Perfil</h2>
            </div>
            <div class="ac-card-body" style="padding: 20px;">
                <table class="form-table" style="color: black; width: 100%;">
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0; width: 200px;"><label for="foto_perfil">Foto de Perfil</label></th>
                        <td style="padding: 10px 0;">
                            <?php if ($foto_perfil_actual): ?>
                                <div style="margin-bottom: 15px;">
                                    <img src="<?php echo esc_url($foto_perfil_actual['url']); ?>" 
                                         alt="Foto de perfil actual" 
                                         style="width: 100px; height: 100px; object-fit: cover; border-radius: 50%; border: 3px solid #ddd; display: block;">
                                    <p style="color: #666; margin: 5px 0 0 0; font-size: 12px;">Foto actual</p>
                                </div>
                            <?php else: ?>
                                <div style="margin-bottom: 15px;">
                                    <div style="width: 100px; height: 100px; background: #f0f0f0; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 3px solid #ddd;">
                                        <span style="font-size: 24px; color: #666;">👤</span>
                                    </div>
                                    <p style="color: #666; margin: 5px 0 0 0; font-size: 12px;">Sin foto de perfil</p>
                                </div>
                            <?php endif; ?>
                            
                            <input type="file" id="foto_perfil" name="foto_perfil" accept="image/jpeg,image/png,image/gif" style="color: black;">
                            <p class="description" style="color: #666; margin: 5px 0 0 0;">
                                Formatos permitidos: JPG, PNG, GIF. Tamaño máximo: 5MB
                            </p>
                            <?php if ($foto_perfil_actual): ?>
                                <p class="description" style="color: #666; margin: 5px 0 0 0;">
                                    <input type="checkbox" id="eliminar_foto_perfil" name="eliminar_foto_perfil" value="1">
                                    <label for="eliminar_foto_perfil" style="color: #666;">Eliminar foto de perfil actual</label>
                                </p>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="ac-card" style="background: white; border: 1px solid #ccc; margin-bottom: 20px; border-radius: 8px;">
            <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                <h2 style="color: black; margin: 0;">📝 Información Personal</h2>
            </div>
            <div class="ac-card-body" style="padding: 20px;">
                <table class="form-table" style="color: black; width: 100%;">
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0; width: 200px;"><label for="cedula">Cédula *</label></th>
                        <td style="padding: 10px 0;">
                            <input type="text" id="cedula" name="cedula" value="<?php echo esc_attr($paciente->getCedula() ?? ''); ?>" class="regular-text" required style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 300px;">
                            <p class="description" style="color: #666; margin: 5px 0 0 0;">Número de cédula de identidad</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="nombre">Nombre *</label></th>
                        <td style="padding: 10px 0;">
                            <input type="text" id="nombre" name="nombre" value="<?php echo esc_attr($paciente->getNombre() ?? ''); ?>" class="regular-text" required style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 300px;">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="apellido">Apellido *</label></th>
                        <td style="padding: 10px 0;">
                            <input type="text" id="apellido" name="apellido" value="<?php echo esc_attr($paciente->getApellido() ?? ''); ?>" class="regular-text" required style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 300px;">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="fecha_nacimiento">Fecha de Nacimiento</label></th>
                        <td style="padding: 10px 0;">
                            <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" value="<?php echo esc_attr($paciente->getFechaNacimiento() ?? ''); ?>" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 200px;">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="genero">Género</label></th>
                        <td style="padding: 10px 0;">
                            <select id="genero" name="genero" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 300px;">
                                <option value="">Seleccionar...</option>
                                <option value="masculino" <?php selected($paciente->getGenero() ?? '', 'masculino'); ?>>Masculino</option>
                                <option value="femenino" <?php selected($paciente->getGenero() ?? '', 'femenino'); ?>>Femenino</option>
                                <option value="otro" <?php selected($paciente->getGenero() ?? '', 'otro'); ?>>Otro</option>
                            </select>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="ac-card" style="background: white; border: 1px solid #ccc; margin-bottom: 20px; border-radius: 8px;">
            <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                <h2 style="color: black; margin: 0;">📞 Información de Contacto</h2>
            </div>
            <div class="ac-card-body" style="padding: 20px;">
                <table class="form-table" style="color: black; width: 100%;">
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0; width: 200px;"><label for="telefono">Teléfono</label></th>
                        <td style="padding: 10px 0;">
                            <input type="tel" id="telefono" name="telefono" value="<?php echo esc_attr($paciente->getTelefono() ?? ''); ?>" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 300px;">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="email">Email</label></th>
                        <td style="padding: 10px 0;">
                            <input type="email" id="email" name="email" value="<?php echo esc_attr($paciente->getEmail() ?? ''); ?>" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 300px;">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="direccion">Dirección</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="direccion" name="direccion" rows="3" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($paciente->getDireccion() ?? ''); ?></textarea>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="ac-card" style="background: white; border: 1px solid #ccc; margin-bottom: 20px; border-radius: 8px;">
            <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                <h2 style="color: black; margin: 0;">🆘 Contacto de Emergencia</h2>
            </div>
            <div class="ac-card-body" style="padding: 20px;">
                <table class="form-table" style="color: black; width: 100%;">
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0; width: 200px;"><label for="contacto_emergencia_nombre">Nombre</label></th>
                        <td style="padding: 10px 0;">
                            <input type="text" id="contacto_emergencia_nombre" name="contacto_emergencia_nombre" value="<?php echo esc_attr($paciente->getContactoEmergenciaNombre() ?? ''); ?>" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 300px;">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="contacto_emergencia_telefono">Teléfono</label></th>
                        <td style="padding: 10px 0;">
                            <input type="tel" id="contacto_emergencia_telefono" name="contacto_emergencia_telefono" value="<?php echo esc_attr($paciente->getContactoEmergenciaTelefono() ?? ''); ?>" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 300px;">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="contacto_emergencia_parentesco">Parentesco</label></th>
                        <td style="padding: 10px 0;">
                            <input type="text" id="contacto_emergencia_parentesco" name="contacto_emergencia_parentesco" value="<?php echo esc_attr($paciente->getContactoEmergenciaParentesco() ?? ''); ?>" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 300px;">
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="ac-card" style="background: white; border: 1px solid #ccc; margin-bottom: 20px; border-radius: 8px;">
            <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                <h2 style="color: black; margin: 0;">🏥 Información Médica</h2>
            </div>
            <div class="ac-card-body" style="padding: 20px;">
                <table class="form-table" style="color: black; width: 100%;">
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0; width: 200px;"><label for="historial_medico">Historial Médico</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="historial_medico" name="historial_medico" rows="5" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($paciente->getHistorialMedico() ?? ''); ?></textarea>
                            <p class="description" style="color: #666; margin: 5px 0 0 0;">Enfermedades previas, condiciones crónicas, cirugías, etc.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="alergias">Alergias</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="alergias" name="alergias" rows="3" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($paciente->getAlergias() ?? ''); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="medicamentos_actuales">Medicamentos Actuales</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="medicamentos_actuales" name="medicamentos_actuales" rows="3" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($paciente->getMedicamentosActuales() ?? ''); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="seguro_medico">Seguro Médico</label></th>
                        <td style="padding: 10px 0;">
                            <input type="text" id="seguro_medico" name="seguro_medico" value="<?php echo esc_attr($paciente->getSeguroMedico() ?? ''); ?>" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 300px;">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="numero_seguro_medico">Número de Seguro</label></th>
                        <td style="padding: 10px 0;">
                            <input type="text" id="numero_seguro_medico" name="numero_seguro_medico" value="<?php echo esc_attr($paciente->getNumeroSeguroMedico() ?? ''); ?>" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 300px;">
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="ac-card" style="background: white; border: 1px solid #ccc; margin-bottom: 20px; border-radius: 8px;">
            <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                <h2 style="color: black; margin: 0;">📋 Información Adicional</h2>
            </div>
            <div class="ac-card-body" style="padding: 20px;">
                <table class="form-table" style="color: black; width: 100%;">
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0; width: 200px;"><label for="estado_civil">Estado Civil</label></th>
                        <td style="padding: 10px 0;">
                            <select id="estado_civil" name="estado_civil" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 300px;">
                                <option value="">Seleccionar...</option>
                                <option value="soltero" <?php selected($paciente->getEstadoCivil() ?? '', 'soltero'); ?>>Soltero/a</option>
                                <option value="casado" <?php selected($paciente->getEstadoCivil() ?? '', 'casado'); ?>>Casado/a</option>
                                <option value="divorciado" <?php selected($paciente->getEstadoCivil() ?? '', 'divorciado'); ?>>Divorciado/a</option>
                                <option value="viudo" <?php selected($paciente->getEstadoCivil() ?? '', 'viudo'); ?>>Viudo/a</option>
                                <option value="union_libre" <?php selected($paciente->getEstadoCivil() ?? '', 'union_libre'); ?>>Unión Libre</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="ocupacion">Ocupación</label></th>
                        <td style="padding: 10px 0;">
                            <input type="text" id="ocupacion" name="ocupacion" value="<?php echo esc_attr($paciente->getOcupacion() ?? ''); ?>" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 300px;">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="nivel_educativo">Nivel Educativo</label></th>
                        <td style="padding: 10px 0;">
                            <select id="nivel_educativo" name="nivel_educativo" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 300px;">
                                <option value="">Seleccionar...</option>
                                <option value="primaria" <?php selected($paciente->getNivelEducativo() ?? '', 'primaria'); ?>>Primaria</option>
                                <option value="secundaria" <?php selected($paciente->getNivelEducativo() ?? '', 'secundaria'); ?>>Secundaria</option>
                                <option value="tecnico" <?php selected($paciente->getNivelEducativo() ?? '', 'tecnico'); ?>>Técnico</option>
                                <option value="universitario" <?php selected($paciente->getNivelEducativo() ?? '', 'universitario'); ?>>Universitario</option>
                                <option value="postgrado" <?php selected($paciente->getNivelEducativo() ?? '', 'postgrado'); ?>>Postgrado</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="referencia_por">Referido por</label></th>
                        <td style="padding: 10px 0;">
                            <input type="text" id="referencia_por" name="referencia_por" value="<?php echo esc_attr($paciente->getReferenciaPor() ?? ''); ?>" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 300px;">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="motivo_consulta_principal">Motivo de Consulta Principal</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="motivo_consulta_principal" name="motivo_consulta_principal" rows="3" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($paciente->getMotivoConsultaPrincipal() ?? ''); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="expectativas_tratamiento">Expectativas del Tratamiento</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="expectativas_tratamiento" name="expectativas_tratamiento" rows="3" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($paciente->getExpectativasTratamiento() ?? ''); ?></textarea>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="ac-card" style="background: white; border: 1px solid #ccc; margin-bottom: 20px; border-radius: 8px;">
            <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                <h2 style="color: black; margin: 0;">📊 Información de Registro</h2>
            </div>
            <div class="ac-card-body" style="padding: 20px;">
                <table class="form-table" style="color: black; width: 100%;">
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0; width: 200px;"><label for="fecha_ingreso">Fecha de Ingreso *</label></th>
                        <td style="padding: 10px 0;">
                            <input type="date" id="fecha_ingreso" name="fecha_ingreso" value="<?php echo esc_attr($paciente->getFechaIngreso() ?? ''); ?>" class="regular-text" required style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 200px;">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="estado">Estado</label></th>
                        <td style="padding: 10px 0;">
                            <select id="estado" name="estado" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 300px;">
                                <option value="activo" <?php selected($paciente->getEstado() ?? '', 'activo'); ?>>Activo</option>
                                <option value="inactivo" <?php selected($paciente->getEstado() ?? '', 'inactivo'); ?>>Inactivo</option>
                                <option value="alta" <?php selected($paciente->getEstado() ?? '', 'alta'); ?>>Alta</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="observaciones_generales">Observaciones Generales</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="observaciones_generales" name="observaciones_generales" rows="3" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($paciente->getObservacionesGenerales() ?? ''); ?></textarea>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <p class="submit">
            <input type="submit" name="guardar_paciente" class="button button-primary" value="💾 Guardar Paciente" style="color: white; background: #0073aa; border: 1px solid #0073aa; padding: 10px 20px; border-radius: 4px; font-size: 14px; cursor: pointer;">
            <a href="<?php echo admin_url('admin.php?page=ac-pacientes'); ?>" class="button" style="color: #555; background: #f7f7f7; border: 1px solid #ccc; text-decoration: none; padding: 10px 20px; border-radius: 4px; font-size: 14px; margin-left: 10px;">❌ Cancelar</a>
        </p>
    </form>
</div>

<style>
.form-table th {
    color: black;
    font-weight: 600;
}

.form-table td {
    color: black;
}

.large-text {
    color: black;
    border: 1px solid #ccc;
    padding: 8px;
    width: 100%;
}

.regular-text {
    color: black;
    border: 1px solid #ccc;
    padding: 5px;
}

select.regular-text {
    color: black;
    border: 1px solid #ccc;
    padding: 5px;
}

input[type="date"] {
    color: black;
    border: 1px solid #ccc;
    padding: 5px;
}

input[type="file"] {
    color: black;
    border: 1px solid #ccc;
    padding: 5px;
    background: white;
}

.button-primary:hover {
    background: #005a87 !important;
    border-color: #005a87 !important;
}

.button:hover {
    background: #e5e5e5 !important;
    border-color: #bbb !important;
}

.description {
    color: #666;
    font-style: italic;
    margin: 5px 0 0 0;
}

input[type="checkbox"] {
    margin-right: 5px;
}
</style>