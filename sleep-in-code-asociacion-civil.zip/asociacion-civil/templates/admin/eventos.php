<?php
$tipo_filtro = isset($_GET['tipo']) ? sanitize_text_field($_GET['tipo']) : '';
$estado_filtro = isset($_GET['estado']) ? sanitize_text_field($_GET['estado']) : '';
?>

<div class="wrap">
    <h1>Gestión de Eventos y Asambleas
        <a href="<?php echo admin_url('admin.php?page=ac-eventos&action=nuevo'); ?>" class="page-title-action">
            Agregar Nuevo Evento
        </a>
    </h1>
    
    <div class="ac-filtros-section">
        <form method="get">
            <input type="hidden" name="page" value="ac-eventos">
            <div class="ac-filtros-grid">
                <div class="ac-form-group">
                    <label for="tipo">Tipo de Evento:</label>
                    <select id="tipo" name="tipo">
                        <option value="">Todos los tipos</option>
                        <option value="reunion" <?php selected($tipo_filtro, 'reunion'); ?>>Reunión</option>
                        <option value="asamblea" <?php selected($tipo_filtro, 'asamblea'); ?>>Asamblea</option>
                        <option value="evento" <?php selected($tipo_filtro, 'evento'); ?>>Evento</option>
                        <option value="otros" <?php selected($tipo_filtro, 'otros'); ?>>Otros</option>
                    </select>
                </div>
                
                <div class="ac-form-group">
                    <label for="estado">Estado:</label>
                    <select id="estado" name="estado">
                        <option value="">Todos los estados</option>
                        <option value="planificado" <?php selected($estado_filtro, 'planificado'); ?>>Planificado</option>
                        <option value="realizado" <?php selected($estado_filtro, 'realizado'); ?>>Realizado</option>
                        <option value="cancelado" <?php selected($estado_filtro, 'cancelado'); ?>>Cancelado</option>
                    </select>
                </div>
                
                <div class="ac-form-group">
                    <label>&nbsp;</label>
                    <button type="submit" class="button">Filtrar</button>
                    <?php if ($tipo_filtro || $estado_filtro): ?>
                        <a href="<?php echo admin_url('admin.php?page=ac-eventos'); ?>" class="button">Limpiar</a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
    
    <h2>Próximos Eventos</h2>
    <div class="ac-table-container">
        <?php if ($proximos): ?>
            <table class="wp-list-table widefat fixed striped ac-table">
                <thead>
                    <tr>
                        <th>Título</th>
                        <th>Fecha y Hora</th>
                        <th>Lugar</th>
                        <th>Tipo</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($proximos as $evento): ?>
                        <tr>
                            <td>
                                <strong><?php echo esc_html($evento->titulo); ?></strong>
                                <?php if ($evento->descripcion): ?>
                                    <br><small><?php echo esc_html(wp_trim_words($evento->descripcion, 10)); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo date('d/m/Y H:i', strtotime($evento->fecha)); ?>
                                <br><small><?php echo $this->tiempo_relativo($evento->fecha); ?></small>
                            </td>
                            <td><?php echo esc_html($evento->lugar); ?></td>
                            <td>
                                <span class="ac-tipo ac-tipo-<?php echo esc_attr($evento->tipo); ?>">
                                    <?php echo esc_html(ucfirst($evento->tipo)); ?>
                                </span>
                            </td>
                            <td>
                                <span class="ac-estado ac-estado-<?php echo esc_attr($evento->estado); ?>">
                                    <?php echo esc_html(ucfirst($evento->estado)); ?>
                                </span>
                            </td>
                            <td class="ac-actions">
                                <a href="<?php echo admin_url('admin.php?page=ac-eventos&action=editar&id=' . $evento->id); ?>" 
                                   class="button button-small">Editar</a>
                                <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ac-eventos&action=eliminar&id=' . $evento->id), 'eliminar_evento_' . $evento->id); ?>" 
                                   class="button button-small button-link-delete" 
                                   onclick="return confirm('¿Está seguro de que desea eliminar este evento?')">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="ac-empty-state">
                <p>No hay eventos próximos programados.</p>
                <a href="<?php echo admin_url('admin.php?page=ac-eventos&action=nuevo'); ?>" class="button button-primary">Programar el primer evento</a>
            </div>
        <?php endif; ?>
    </div>
    
    <h2>Eventos Pasados</h2>
    <div class="ac-table-container">
        <?php if ($pasados): ?>
            <table class="wp-list-table widefat fixed striped ac-table">
                <thead>
                    <tr>
                        <th>Título</th>
                        <th>Fecha</th>
                        <th>Lugar</th>
                        <th>Tipo</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pasados as $evento): ?>
                        <tr>
                            <td>
                                <strong><?php echo esc_html($evento->titulo); ?></strong>
                                <?php if ($evento->descripcion): ?>
                                    <br><small><?php echo esc_html(wp_trim_words($evento->descripcion, 10)); ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?php echo date('d/m/Y H:i', strtotime($evento->fecha)); ?></td>
                            <td><?php echo esc_html($evento->lugar); ?></td>
                            <td>
                                <span class="ac-tipo ac-tipo-<?php echo esc_attr($evento->tipo); ?>">
                                    <?php echo esc_html(ucfirst($evento->tipo)); ?>
                                </span>
                            </td>
                            <td>
                                <span class="ac-estado ac-estado-<?php echo esc_attr($evento->estado); ?>">
                                    <?php echo esc_html(ucfirst($evento->estado)); ?>
                                </span>
                            </td>
                            <td class="ac-actions">
                                <a href="<?php echo admin_url('admin.php?page=ac-eventos&action=editar&id=' . $evento->id); ?>" 
                                   class="button button-small">Editar</a>
                                <?php if ($evento->tipo === 'asamblea'): ?>
                                    <a href="<?php echo admin_url('admin.php?page=ac-documentos&action=nuevo&tipo=acta&evento_id=' . $evento->id); ?>" 
                                       class="button button-small">Subir Acta</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="ac-empty-state">
                <p>No hay eventos pasados registrados.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
// Función helper para mostrar tiempo relativo
function tiempo_relativo($fecha) {
    $ahora = current_time('timestamp');
    $fecha_ts = strtotime($fecha);
    $diferencia = $fecha_ts - $ahora;
    
    if ($diferencia < 0) {
        return 'Pasado';
    }
    
    $dias = floor($diferencia / (60 * 60 * 24));
    $horas = floor(($diferencia % (60 * 60 * 24)) / (60 * 60));
    
    if ($dias > 0) {
        return "En $dias días";
    } elseif ($horas > 0) {
        return "En $horas horas";
    } else {
        return "Muy pronto";
    }
}
?>