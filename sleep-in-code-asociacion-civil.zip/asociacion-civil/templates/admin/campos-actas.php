<?php
if (!defined('ABSPATH')) {
    exit;
}

// Iniciar buffer de salida para evitar errores de headers
ob_start();

// =============================================
// SISTEMA DE GESTIÓN UNIFICADO
// =============================================

// Verificar qué sistema mostrar basado en parámetros o configuración
$modo_actual = isset($_GET['modo']) ? sanitize_text_field($_GET['modo']) : 'planificador';

// =============================================
// INCLUIR AMBOS SISTEMAS DE FORMA SEGURA
// =============================================

// Función para cargar el sistema de actas de forma segura
function cargar_sistema_actas() {
    // Definir variables globales necesarias para campo-actas.php
    global $actas;
    
    // Inicializar $actas si no existe
    if (!isset($actas) || !is_array($actas)) {
        $actas = array();
    }
    
    // Incluir funciones de campo-actas.php de forma segura
    if (!function_exists('get_acta_property')) {
        // Aquí irían todas las funciones de campo-actas.php
        // pero las definiremos condicionalmente para evitar conflictos
        
        function get_acta_property($acta, $property) {
            if (!is_object($acta) && !is_array($acta)) {
                return '';
            }
            
            // Implementación simplificada - expandir según necesidades
            if (is_array($acta)) {
                return isset($acta[$property]) ? $acta[$property] : '';
            }
            
            // Para objetos, intentar métodos getter o propiedades directas
            $getters = [
                'id' => 'getId',
                'titulo' => 'getTitulo',
                'fecha' => 'getFecha',
                // ... otros mapeos
            ];
            
            if (isset($getters[$property]) && method_exists($acta, $getters[$property])) {
                return $acta->{$getters[$property]}();
            }
            
            if (property_exists($acta, $property)) {
                try {
                    return $acta->$property;
                } catch (Error $e) {
                    return '';
                }
            }
            
            return '';
        }
    }
    
    // Aquí puedes agregar más funciones de campo-actas.php de forma condicional
}

// =============================================
// INTERFAZ DE NAVEGACIÓN UNIFICADA
// =============================================

function mostrar_navegacion_unificada() {
    $modo_actual = isset($_GET['modo']) ? sanitize_text_field($_GET['modo']) : 'planificador';
    ?>
    <div class="ac-navigation" style="margin: 20px 0; background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
        <h2 style="margin-top: 0;">Sistema Integral de Gestión</h2>
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador'); ?>" 
               class="button <?php echo $modo_actual === 'planificador' ? 'button-primary' : ''; ?>" 
               style="text-decoration: none;">
                📅 Planificador Diario
            </a>
            <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas'); ?>" 
               class="button <?php echo $modo_actual === 'actas' ? 'button-primary' : ''; ?>" 
               style="text-decoration: none;">
                📋 Libro de Actas
            </a>
            <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=estadisticas'); ?>" 
               class="button <?php echo $modo_actual === 'estadisticas' ? 'button-primary' : ''; ?>" 
               style="text-decoration: none;">
                📊 Estadísticas Integradas
            </a>
        </div>
    </div>
    <?php
}

// =============================================
// SISTEMA UNIFICADO PRINCIPAL
// =============================================

function ac_sistema_integrado() {
    $modo_actual = isset($_GET['modo']) ? sanitize_text_field($_GET['modo']) : 'planificador';
    
    // Mostrar navegación unificada
    mostrar_navegacion_unificada();
    
    // Cargar el sistema correspondiente
    switch ($modo_actual) {
        case 'planificador':
            ac_mostrar_planificador_completo();
            break;
            
        case 'actas':
            cargar_sistema_actas();
            ac_mostrar_sistema_actas();
            break;
            
        case 'estadisticas':
            ac_mostrar_estadisticas_integradas();
            break;
            
        default:
            ac_mostrar_planificador_completo();
    }
}

// =============================================
// SISTEMA DE ACTAS INTEGRADO
// =============================================

function ac_mostrar_sistema_actas() {
    // Cargar datos de actas (simulado - en realidad vendría de tu base de datos)
    global $actas;
    
    // Simular algunas actas para demostración
    $actas = array(
        (object) array(
            'id' => 1,
            'titulo' => 'Reunión de Planificación Semanal',
            'fecha' => date('Y-m-d', strtotime('-2 days')),
            'tipo' => 'planificación',
            'lugar' => 'Sala de Conferencias',
            'convocante' => 'Director General',
            'asistentes' => "Juan Pérez\nMaría García\nCarlos López",
            'contenido' => 'Se discutió la planificación de actividades para la próxima semana.',
            'acuerdos' => 'Asignar tareas específicas a cada departamento.'
        ),
        (object) array(
            'id' => 2,
            'titulo' => 'Evaluación de Proyectos',
            'fecha' => date('Y-m-d', strtotime('-5 days')),
            'tipo' => 'evaluación',
            'lugar' => 'Oficina Principal',
            'convocante' => 'Gerente de Proyectos',
            'asistentes' => "Ana Martínez\nPedro Sánchez\nLaura Rodríguez",
            'contenido' => 'Revisión del estado actual de los proyectos en curso.',
            'acuerdos' => 'Ajustar cronogramas y asignar recursos adicionales.'
        )
    );
    ?>
    
    <div class="wrap">
        <h1 class="wp-heading-inline">📋 Sistema de Gestión de Actas</h1>
        
        <div class="ac-actas-header" style="display: flex; justify-content: space-between; align-items: center; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px;">
            <div>
                <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas&action=nuevo'); ?>" class="button button-primary">
                    <span class="dashicons dashicons-plus" style="margin-top: 4px;"></span>
                    Nueva Acta
                </a>
                <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas&export=csv'); ?>" class="button" style="margin-left: 10px;">
                    <span class="dashicons dashicons-media-spreadsheet" style="margin-top: 4px;"></span>
                    Exportar CSV
                </a>
            </div>
            
            <div class="ac-search-box">
                <input type="text" placeholder="Buscar actas..." style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; width: 250px;">
            </div>
        </div>

        <!-- Panel de Métricas Rápidas -->
        <div class="ac-actas-metrics" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px;">
            <div style="background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="font-size: 32px; color: #667eea;">📄</div>
                <h3 style="margin: 10px 0 5px 0; color: #333;">Total Actas</h3>
                <p style="font-size: 24px; font-weight: bold; color: #667eea; margin: 0;"><?php echo count($actas); ?></p>
            </div>
            
            <div style="background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="font-size: 32px; color: #46b450;">📅</div>
                <h3 style="margin: 10px 0 5px 0; color: #333;">Este Mes</h3>
                <p style="font-size: 24px; font-weight: bold; color: #46b450; margin: 0;">2</p>
            </div>
            
            <div style="background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="font-size: 32px; color: #ffb900;">👥</div>
                <h3 style="margin: 10px 0 5px 0; color: #333;">Participantes</h3>
                <p style="font-size: 24px; font-weight: bold; color: #ffb900; margin: 0;">8</p>
            </div>
            
            <div style="background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="font-size: 32px; color: #dc3232;">✅</div>
                <h3 style="margin: 10px 0 5px 0; color: #333;">Acuerdos</h3>
                <p style="font-size: 24px; font-weight: bold; color: #dc3232; margin: 0;">5</p>
            </div>
        </div>

        <!-- Lista de Actas -->
        <div class="ac-actas-list" style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h2 style="margin-top: 0; border-bottom: 2px solid #0073aa; padding-bottom: 10px;">Actas Recientes</h2>
            
            <?php if (!empty($actas)): ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th style="width: 40%;">Título</th>
                            <th style="width: 15%;">Fecha</th>
                            <th style="width: 15%;">Tipo</th>
                            <th style="width: 20%;">Convocante</th>
                            <th style="width: 10%;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($actas as $acta): ?>
                        <tr>
                            <td>
                                <strong><?php echo esc_html(get_acta_property($acta, 'titulo')); ?></strong>
                                <div style="font-size: 12px; color: #666; margin-top: 5px;">
                                    <?php echo esc_html(get_acta_property($acta, 'lugar') ?: 'Sin lugar especificado'); ?>
                                </div>
                            </td>
                            <td>
                                <?php echo date('d/m/Y', strtotime(get_acta_property($acta, 'fecha'))); ?>
                            </td>
                            <td>
                                <span style="background: #e7f3ff; color: #0073aa; padding: 4px 8px; border-radius: 12px; font-size: 12px;">
                                    <?php echo esc_html(get_acta_property($acta, 'tipo')); ?>
                                </span>
                            </td>
                            <td>
                                <?php echo esc_html(get_acta_property($acta, 'convocante')); ?>
                            </td>
                            <td>
                                <div style="display: flex; gap: 5px;">
                                    <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas&action=ver&id=' . get_acta_property($acta, 'id')); ?>" 
                                       class="button button-small" title="Ver">
                                        <span class="dashicons dashicons-visibility" style="font-size: 16px;"></span>
                                    </a>
                                    <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas&action=editar&id=' . get_acta_property($acta, 'id')); ?>" 
                                       class="button button-small" title="Editar">
                                        <span class="dashicons dashicons-edit" style="font-size: 16px;"></span>
                                    </a>
                                    <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas&export=pdf_individual&id=' . get_acta_property($acta, 'id')); ?>" 
                                       class="button button-small" title="Exportar PDF">
                                        <span class="dashicons dashicons-pdf" style="font-size: 16px;"></span>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align: center; padding: 40px 20px; color: #666;">
                    <div style="font-size: 64px; margin-bottom: 15px;">📝</div>
                    <h3 style="color: #333;">No hay actas registradas</h3>
                    <p>Comienza creando tu primera acta para llevar un registro de tus reuniones.</p>
                    <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas&action=nuevo'); ?>" class="button button-primary">
                        Crear Primera Acta
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <!-- Panel de Acciones Rápidas -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 20px;">
            <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin-top: 0; color: #0073aa;">🚀 Importación Rápida</h3>
                <p>Importa actas desde archivos CSV o procesa documentos con OCR.</p>
                <div style="display: flex; gap: 10px; margin-top: 15px;">
                    <button type="button" class="button">
                        <span class="dashicons dashicons-upload" style="margin-top: 4px;"></span>
                        Importar CSV
                    </button>
                    <button type="button" class="button">
                        <span class="dashicons dashicons-scanner" style="margin-top: 4px;"></span>
                        Procesar con OCR
                    </button>
                </div>
            </div>
            
            <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin-top: 0; color: #46b450;">📊 Plantillas</h3>
                <p>Utiliza plantillas predefinidas para crear actas rápidamente.</p>
                <div style="display: flex; gap: 10px; margin-top: 15px;">
                    <button type="button" class="button">
                        <span class="dashicons dashicons-admin-page" style="margin-top: 4px;"></span>
                        Acta Ordinaria
                    </button>
                    <button type="button" class="button">
                        <span class="dashicons dashicons-groups" style="margin-top: 4px;"></span>
                        Asamblea
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <style>
    .ac-actas-list table {
        border: 1px solid #ccd0d4;
        border-radius: 4px;
        overflow: hidden;
    }
    
    .ac-actas-list th {
        background: #f8f9fa;
        font-weight: 600;
    }
    
    .button-small {
        padding: 4px 8px;
        height: auto;
        line-height: 1;
    }
    
    .button-small .dashicons {
        margin-top: 2px;
    }
    </style>
    <?php
}

// =============================================
// ESTADÍSTICAS INTEGRADAS
// =============================================

function ac_mostrar_estadisticas_integradas() {
    // Aquí integrarías las estadísticas de ambos sistemas
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline">📊 Estadísticas Integradas</h1>
        
        <div style="background: white; padding: 30px; border-radius: 8px; margin-top: 20px;">
            <h2 style="margin-top: 0; color: #333;">Sistema en Desarrollo</h2>
            <p>Esta sección integrará las estadísticas del planificador diario y el sistema de actas en un solo dashboard.</p>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 30px;">
                <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 8px;">
                    <div style="font-size: 48px; margin-bottom: 15px;">📅</div>
                    <h3>Planificador Diario</h3>
                    <p>Métricas de cumplimiento y seguimiento de actividades programadas.</p>
                </div>
                
                <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 8px;">
                    <div style="font-size: 48px; margin-bottom: 15px;">📋</div>
                    <h3>Sistema de Actas</h3>
                    <p>Estadísticas de reuniones, participantes y acuerdos registrados.</p>
                </div>
            </div>
            
            <div style="text-align: center; margin-top: 40px; padding: 40px; background: linear-gradient(135deg, #667eea, #764ba2); color: white; border-radius: 12px;">
                <h2 style="color: white;">🚀 Próximamente</h2>
                <p>Estamos trabajando en la integración completa de estadísticas entre ambos sistemas.</p>
                <p>Podrás ver correlaciones entre tu productividad diaria y la efectividad de tus reuniones.</p>
            </div>
        </div>
    </div>
    <?php
}

// =============================================
// EJECUTAR EL SISTEMA INTEGRADO
// =============================================

// Determinar qué mostrar basado en el modo
$modo_actual = isset($_GET['modo']) ? sanitize_text_field($_GET['modo']) : 'planificador';

switch ($modo_actual) {
    case 'planificador':
        // Mostrar planificador (ya está definido en libro-actas.php)
        if (function_exists('ac_mostrar_planificador_completo')) {
            ac_mostrar_planificador_completo();
        } else {
            echo '<div class="notice notice-error"><p>Error: No se pudo cargar el planificador.</p></div>';
        }
        break;
        
    case 'actas':
        // Mostrar sistema de actas
        ac_mostrar_sistema_actas();
        break;
        
    case 'estadisticas':
        // Mostrar estadísticas integradas
        ac_mostrar_estadisticas_integradas();
        break;
        
    default:
        // Por defecto, mostrar planificador
        if (function_exists('ac_mostrar_planificador_completo')) {
            ac_mostrar_planificador_completo();
        }
}

// Limpiar buffer de salida
ob_end_flush();
?>