<?php
$tipo_filtro = isset($_GET['tipo']) ? sanitize_text_field($_GET['tipo']) : '';
$categoria_filtro = isset($_GET['categoria']) ? sanitize_text_field($_GET['categoria']) : '';
?>

<div class="wrap">
    <h1>Gestión de Documentos
        <a href="<?php echo admin_url('admin.php?page=ac-documentos&action=nuevo'); ?>" class="page-title-action">
            Subir Nuevo Documento
        </a>
    </h1>
    
    <div class="ac-filtros-section">
        <form method="get">
            <input type="hidden" name="page" value="ac-documentos">
            <div class="ac-filtros-grid">
                <div class="ac-form-group">
                    <label for="tipo">Tipo de Documento:</label>
                    <select id="tipo" name="tipo">
                        <option value="">Todos los tipos</option>
                        <option value="acta" <?php selected($tipo_filtro, 'acta'); ?>>Actas</option>
                        <option value="convocatoria" <?php selected($tipo_filtro, 'convocatoria'); ?>>Convocatorias</option>
                        <option value="estatuto" <?php selected($tipo_filtro, 'estatuto'); ?>>Estatutos</option>
                        <option value="reglamento" <?php selected($tipo_filtro, 'reglamento'); ?>>Reglamentos</option>
                        <option value="informe" <?php selected($tipo_filtro, 'informe'); ?>>Informes</option>
                        <option value="otros" <?php selected($tipo_filtro, 'otros'); ?>>Otros</option>
                    </select>
                </div>
                
                <div class="ac-form-group">
                    <label for="categoria">Categoría:</label>
                    <input type="text" id="categoria" name="categoria" 
                           value="<?php echo esc_attr($categoria_filtro); ?>"
                           placeholder="Filtrar por categoría">
                </div>
                
                <div class="ac-form-group">
                    <label>&nbsp;</label>
                    <button type="submit" class="button">Filtrar</button>
                    <?php if ($tipo_filtro || $categoria_filtro): ?>
                        <a href="<?php echo admin_url('admin.php?page=ac-documentos'); ?>" class="button">Limpiar</a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
    
    <div class="ac-table-container">
        <?php if ($documentos): ?>
            <table class="wp-list-table widefat fixed striped ac-table">
                <thead>
                    <tr>
                        <th>Documento</th>
                        <th>Tipo</th>
                        <th>Categoría</th>
                        <th>Fecha Documento</th>
                        <th>Archivo</th>
                        <th>Visible para</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($documentos as $doc): ?>
                        <?php
                        $documento_obj = new AsociacionCivil\Documento($doc->id);
                        $tamano = $documento_obj->getTamanoArchivo();
                        $extension = $documento_obj->getExtension();
                        ?>
                        <tr>
                            <td>
                                <strong><?php echo esc_html($doc->titulo); ?></strong>
                                <?php if ($doc->descripcion): ?>
                                    <br><small><?php echo esc_html(wp_trim_words($doc->descripcion, 15)); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="ac-tipo-doc ac-tipo-<?php echo esc_attr($doc->tipo); ?>">
                                    <?php echo esc_html(ucfirst($doc->tipo)); ?>
                                </span>
                            </td>
                            <td><?php echo esc_html($doc->categoria ?: 'General'); ?></td>
                            <td><?php echo date('d/m/Y', strtotime($doc->fecha_documento)); ?></td>
                            <td>
                                <?php if ($doc->archivo): ?>
                                    <span class="ac-archivo-info">
                                        <span class="dashicons dashicons-media-document"></span>
                                        <?php echo strtoupper($extension); ?> • <?php echo $tamano; ?>
                                    </span>
                                <?php else: ?>
                                    <span class="ac-sin-archivo">Sin archivo</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="ac-visibilidad ac-visibilidad-<?php echo esc_attr($doc->visible_para); ?>">
                                    <?php
                                    $visibilidad = array(
                                        'junta' => 'Junta Directiva',
                                        'miembros' => 'Miembros',
                                        'publico' => 'Público'
                                    );
                                    echo esc_html($visibilidad[$doc->visible_para] ?? $doc->visible_para);
                                    ?>
                                </span>
                            </td>
                            <td class="ac-actions">
                                <?php if ($doc->archivo): ?>
                                    <a href="<?php echo esc_url($documento_obj->getArchivoUrl()); ?>" 
                                       target="_blank" class="button button-small">Descargar</a>
                                <?php endif; ?>
                                <a href="<?php echo admin_url('admin.php?page=ac-documentos&action=editar&id=' . $doc->id); ?>" 
                                   class="button button-small">Editar</a>
                                <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ac-documentos&action=eliminar&id=' . $doc->id), 'eliminar_documento_' . $doc->id); ?>" 
                                   class="button button-small button-link-delete" 
                                   onclick="return confirm('¿Está seguro de que desea eliminar este documento?')">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="ac-empty-state">
                <p>No hay documentos registrados.</p>
                <a href="<?php echo admin_url('admin.php?page=ac-documentos&action=nuevo'); ?>" class="button button-primary">Subir el primer documento</a>
            </div>
        <?php endif; ?>
    </div>
</div>