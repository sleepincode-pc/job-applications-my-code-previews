<?php
if (!defined('ABSPATH')) {
    exit;
}

// Cargar FileManager para mostrar foto de perfil
if (!class_exists('AsociacionCivil\FileManager')) {
    require_once plugin_dir_path(dirname(__FILE__, 2)) . 'includes/classes/FileManager.php';
}
$file_manager = new AsociacionCivil\FileManager();
$foto_perfil = $file_manager->get_foto_perfil_principal($paciente->getId());
?>

<div class="wrap" style="background: white; color: black; padding: 20px;">
    <h1 style="color: black;">👥 Información del Paciente</h1>
    
    <div class="ac-patient-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; padding: 20px; background: #f8f9fa; border-radius: 8px;">
        <div class="ac-patient-info">
            <h2 style="color: black; margin: 0 0 10px 0;"><?php echo esc_html($paciente->getNombreCompleto()); ?></h2>
            <p class="ac-patient-meta" style="color: #666; margin: 0;">
                <strong style="color: black;">Cédula:</strong> <?php echo esc_html($paciente->getCedula()); ?> |
                <strong style="color: black;">Estado:</strong> 
                <span class="ac-badge ac-badge-<?php echo $paciente->getEstado() === 'activo' ? 'success' : 'warning'; ?>" 
                      style="padding: 4px 8px; border-radius: 12px; font-size: 12px; font-weight: bold; background: <?php echo $paciente->getEstado() === 'activo' ? '#d4edda' : '#fff3cd'; ?>; color: <?php echo $paciente->getEstado() === 'activo' ? '#155724' : '#856404'; ?>;">
                    <?php echo ucfirst($paciente->getEstado()); ?>
                </span>
            </p>
        </div>
        <div class="ac-patient-actions">
            <a href="<?php echo admin_url('admin.php?page=ac-pacientes&action=editar&id=' . $paciente->getId()); ?>" class="button button-primary" style="color: white; background: #0073aa; text-decoration: none; padding: 8px 12px; border-radius: 4px;">✏️ Editar</a>
            <a href="<?php echo admin_url('admin.php?page=ac-pacientes&action=fotos&id=' . $paciente->getId()); ?>" class="button" style="color: #555; background: #f7f7f7; text-decoration: none; padding: 8px 12px; border-radius: 4px; margin-left: 8px;">🖼️ Fotos</a>
            <a href="<?php echo admin_url('admin.php?page=ac-pacientes'); ?>" class="button" style="color: #555; background: #f7f7f7; text-decoration: none; padding: 8px 12px; border-radius: 4px; margin-left: 8px;">← Volver</a>
        </div>
    </div>

    <div class="ac-patient-details">
        <div class="ac-row" style="display: flex; gap: 20px; margin-bottom: 20px;">
            <div class="ac-col" style="flex: 1;">
                <div class="ac-card" style="background: white; border: 1px solid #ccc; border-radius: 8px;">
                    <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                        <h3 style="color: black; margin: 0;">📝 Información Personal</h3>
                    </div>
                    <div class="ac-card-body" style="padding: 20px;">
                        <?php if ($foto_perfil): ?>
                            <div style="text-align: center; margin-bottom: 15px;">
                                <img src="<?php echo esc_url($foto_perfil['url']); ?>" 
                                     alt="Foto de perfil" 
                                     style="width: 100px; height: 100px; object-fit: cover; border-radius: 50%; border: 3px solid #ddd;">
                                <p style="margin: 5px 0 0 0; color: #666; font-size: 12px;">Foto de perfil</p>
                            </div>
                        <?php endif; ?>
                        <table class="ac-details-table" style="width: 100%; color: black; border-collapse: collapse;">
                            <tr><th style="text-align: left; padding: 8px; border-bottom: 1px solid #eee; color: black;">Cédula:</th><td style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo esc_html($paciente->getCedula()); ?></td></tr>
                            <tr><th style="text-align: left; padding: 8px; border-bottom: 1px solid #eee; color: black;">Nombre:</th><td style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo esc_html($paciente->getNombreCompleto()); ?></td></tr>
                            <tr><th style="text-align: left; padding: 8px; border-bottom: 1px solid #eee; color: black;">Fecha Nacimiento:</th><td style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo $paciente->getFechaNacimiento() ? date('d/m/Y', strtotime($paciente->getFechaNacimiento())) : 'No especificada'; ?></td></tr>
                            <tr><th style="text-align: left; padding: 8px; border-bottom: 1px solid #eee; color: black;">Edad:</th><td style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo $paciente->getFechaNacimiento() ? $paciente->calcularEdad() . ' años' : 'No especificada'; ?></td></tr>
                            <tr><th style="text-align: left; padding: 8px; border-bottom: 1px solid #eee; color: black;">Género:</th><td style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo esc_html(ucfirst($paciente->getGenero() ?: 'No especificado')); ?></td></tr>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="ac-col" style="flex: 1;">
                <div class="ac-card" style="background: white; border: 1px solid #ccc; border-radius: 8px;">
                    <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                        <h3 style="color: black; margin: 0;">📞 Información de Contacto</h3>
                    </div>
                    <div class="ac-card-body" style="padding: 20px;">
                        <table class="ac-details-table" style="width: 100%; color: black; border-collapse: collapse;">
                            <tr><th style="text-align: left; padding: 8px; border-bottom: 1px solid #eee; color: black;">Teléfono:</th><td style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo esc_html($paciente->getTelefono() ?: 'No especificado'); ?></td></tr>
                            <tr><th style="text-align: left; padding: 8px; border-bottom: 1px solid #eee; color: black;">Email:</th><td style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo esc_html($paciente->getEmail() ?: 'No especificado'); ?></td></tr>
                            <tr><th style="text-align: left; padding: 8px; border-bottom: 1px solid #eee; color: black;">Dirección:</th><td style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo esc_html($paciente->getDireccion() ?: 'No especificada'); ?></td></tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="ac-row" style="display: flex; gap: 20px; margin-bottom: 20px;">
            <div class="ac-col" style="flex: 1;">
                <div class="ac-card" style="background: white; border: 1px solid #ccc; border-radius: 8px;">
                    <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                        <h3 style="color: black; margin: 0;">🆘 Contacto de Emergencia</h3>
                    </div>
                    <div class="ac-card-body" style="padding: 20px;">
                        <table class="ac-details-table" style="width: 100%; color: black; border-collapse: collapse;">
                            <tr><th style="text-align: left; padding: 8px; border-bottom: 1px solid #eee; color: black;">Nombre:</th><td style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo esc_html($paciente->getContactoEmergenciaNombre() ?: 'No especificado'); ?></td></tr>
                            <tr><th style="text-align: left; padding: 8px; border-bottom: 1px solid #eee; color: black;">Teléfono:</th><td style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo esc_html($paciente->getContactoEmergenciaTelefono() ?: 'No especificado'); ?></td></tr>
                            <tr><th style="text-align: left; padding: 8px; border-bottom: 1px solid #eee; color: black;">Parentesco:</th><td style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo esc_html($paciente->getContactoEmergenciaParentesco() ?: 'No especificado'); ?></td></tr>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="ac-col" style="flex: 1;">
                <div class="ac-card" style="background: white; border: 1px solid #ccc; border-radius: 8px;">
                    <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                        <h3 style="color: black; margin: 0;">📊 Información de Registro</h3>
                    </div>
                    <div class="ac-card-body" style="padding: 20px;">
                        <table class="ac-details-table" style="width: 100%; color: black; border-collapse: collapse;">
                            <tr><th style="text-align: left; padding: 8px; border-bottom: 1px solid #eee; color: black;">Fecha Ingreso:</th><td style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo date('d/m/Y', strtotime($paciente->getFechaIngreso())); ?></td></tr>
                            <tr><th style="text-align: left; padding: 8px; border-bottom: 1px solid #eee; color: black;">Estado Civil:</th><td style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo esc_html(ucfirst($paciente->getEstadoCivil() ?: 'No especificado')); ?></td></tr>
                            <tr><th style="text-align: left; padding: 8px; border-bottom: 1px solid #eee; color: black;">Ocupación:</th><td style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo esc_html($paciente->getOcupacion() ?: 'No especificada'); ?></td></tr>
                            <tr><th style="text-align: left; padding: 8px; border-bottom: 1px solid #eee; color: black;">Nivel Educativo:</th><td style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo esc_html(ucfirst($paciente->getNivelEducativo() ?: 'No especificado')); ?></td></tr>
                            <tr><th style="text-align: left; padding: 8px; border-bottom: 1px solid #eee; color: black;">Referido por:</th><td style="padding: 8px; border-bottom: 1px solid #eee;"><?php echo esc_html($paciente->getReferenciaPor() ?: 'No especificado'); ?></td></tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="ac-card" style="background: white; border: 1px solid #ccc; border-radius: 8px; margin-bottom: 20px;">
            <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                <h3 style="color: black; margin: 0;">🏥 Información Médica</h3>
            </div>
            <div class="ac-card-body" style="padding: 20px;">
                <div class="ac-medical-info">
                    <div class="ac-medical-section" style="margin-bottom: 20px;">
                        <h4 style="color: black; margin: 0 0 10px 0;">Historial Médico</h4>
                        <p style="color: black; background: #f8f9fa; padding: 15px; border-radius: 4px; margin: 0;"><?php echo $paciente->getHistorialMedico() ? nl2br(esc_html($paciente->getHistorialMedico())) : 'No especificado'; ?></p>
                    </div>
                    
                    <div class="ac-medical-section" style="margin-bottom: 20px;">
                        <h4 style="color: black; margin: 0 0 10px 0;">Alergias</h4>
                        <p style="color: black; background: #f8f9fa; padding: 15px; border-radius: 4px; margin: 0;"><?php echo $paciente->getAlergias() ? nl2br(esc_html($paciente->getAlergias())) : 'No especificadas'; ?></p>
                    </div>
                    
                    <div class="ac-medical-section" style="margin-bottom: 20px;">
                        <h4 style="color: black; margin: 0 0 10px 0;">Medicamentos Actuales</h4>
                        <p style="color: black; background: #f8f9fa; padding: 15px; border-radius: 4px; margin: 0;"><?php echo $paciente->getMedicamentosActuales() ? nl2br(esc_html($paciente->getMedicamentosActuales())) : 'No especificados'; ?></p>
                    </div>
                    
                    <div class="ac-medical-section">
                        <h4 style="color: black; margin: 0 0 10px 0;">Seguro Médico</h4>
                        <p style="color: black; background: #f8f9fa; padding: 15px; border-radius: 4px; margin: 0;"><?php echo $paciente->getSeguroMedico() ? esc_html($paciente->getSeguroMedico()) . ' (' . esc_html($paciente->getNumeroSeguroMedico()) . ')' : 'No especificado'; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="ac-card" style="background: white; border: 1px solid #ccc; border-radius: 8px;">
            <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                <h3 style="color: black; margin: 0;">🎯 Información de Consulta</h3>
            </div>
            <div class="ac-card-body" style="padding: 20px;">
                <div class="ac-consultation-info">
                    <div class="ac-consultation-section" style="margin-bottom: 20px;">
                        <h4 style="color: black; margin: 0 0 10px 0;">Motivo de Consulta Principal</h4>
                        <p style="color: black; background: #f8f9fa; padding: 15px; border-radius: 4px; margin: 0;"><?php echo $paciente->getMotivoConsultaPrincipal() ? nl2br(esc_html($paciente->getMotivoConsultaPrincipal())) : 'No especificado'; ?></p>
                    </div>
                    
                    <div class="ac-consultation-section" style="margin-bottom: 20px;">
                        <h4 style="color: black; margin: 0 0 10px 0;">Expectativas del Tratamiento</h4>
                        <p style="color: black; background: #f8f9fa; padding: 15px; border-radius: 4px; margin: 0;"><?php echo $paciente->getExpectativasTratamiento() ? nl2br(esc_html($paciente->getExpectativasTratamiento())) : 'No especificadas'; ?></p>
                    </div>
                    
                    <div class="ac-consultation-section">
                        <h4 style="color: black; margin: 0 0 10px 0;">Observaciones Generales</h4>
                        <p style="color: black; background: #f8f9fa; padding: 15px; border-radius: 4px; margin: 0;"><?php echo $paciente->getObservacionesGenerales() ? nl2br(esc_html($paciente->getObservacionesGenerales())) : 'No especificadas'; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>