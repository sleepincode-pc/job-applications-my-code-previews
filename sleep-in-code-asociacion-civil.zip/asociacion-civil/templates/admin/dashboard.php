<div class="wrap asociacion-civil-dashboard">
    <h1>Gestión de Asociación Civil</h1>
    
    <?php if (isset($_GET['updated'])): ?>
        <div class="notice notice-success is-dismissible">
            <p>Configuración actualizada correctamente.</p>
        </div>
    <?php endif; ?>
    
    <div class="ac-stats-container">
        <div class="ac-stat-card">
            <div class="ac-stat-icon">👥</div>
            <h3>Miembros Activos</h3>
            <div class="ac-stat-number"><?php echo esc_html($estadisticas['total_miembros']); ?></div>
            <a href="<?php echo admin_url('admin.php?page=ac-miembros'); ?>" class="ac-stat-link">Ver todos</a>
        </div>
        
        <div class="ac-stat-card">
            <div class="ac-stat-icon">📅</div>
            <h3>Próximos Eventos</h3>
            <div class="ac-stat-number"><?php echo esc_html(count($estadisticas['proximos_eventos'])); ?></div>
            <a href="<?php echo admin_url('admin.php?page=ac-eventos'); ?>" class="ac-stat-link">Ver eventos</a>
        </div>
        
        <div class="ac-stat-card">
            <div class="ac-stat-icon">📋</div>
            <h3>Total Documentos</h3>
            <div class="ac-stat-number"><?php echo esc_html($estadisticas['total_documentos']); ?></div>
            <a href="<?php echo admin_url('admin.php?page=ac-documentos'); ?>" class="ac-stat-link">Ver documentos</a>
        </div>
        
        <div class="ac-stat-card">
            <div class="ac-stat-icon">🏛️</div>
            <h3>Últimas Asambleas</h3>
            <div class="ac-stat-number"><?php echo esc_html(count($estadisticas['ultimas_asambleas'])); ?></div>
            <a href="<?php echo admin_url('admin.php?page=ac-eventos&tipo=asamblea'); ?>" class="ac-stat-link">Ver asambleas</a>
        </div>
    </div>
    
    <div class="ac-dashboard-sections">
        <div class="ac-section">
            <h2>Próximos Eventos</h2>
            <?php if (!empty($estadisticas['proximos_eventos'])): ?>
                <div class="ac-event-list">
                    <?php foreach ($estadisticas['proximos_eventos'] as $evento): ?>
                        <div class="ac-event-item">
                            <div class="ac-event-fecha">
                                <?php echo date('d M', strtotime($evento->fecha)); ?>
                            </div>
                            <div class="ac-event-info">
                                <strong><?php echo esc_html($evento->titulo); ?></strong>
                                <div class="ac-event-details">
                                    <?php echo date('H:i', strtotime($evento->fecha)); ?>
                                    <?php if ($evento->lugar): ?> • <?php echo esc_html($evento->lugar); ?><?php endif; ?>
                                </div>
                            </div>
                            <div class="ac-event-actions">
                                <a href="<?php echo admin_url('admin.php?page=ac-eventos&action=editar&id=' . $evento->id); ?>" class="button button-small">Editar</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>No hay eventos próximos programados.</p>
            <?php endif; ?>
            <div class="ac-section-footer">
                <a href="<?php echo admin_url('admin.php?page=ac-eventos&action=nuevo'); ?>" class="button">Agregar Nuevo Evento</a>
            </div>
        </div>
        
        <div class="ac-section">
            <h2>Acciones Rápidas</h2>
            <div class="ac-quick-actions">
                <a href="<?php echo admin_url('admin.php?page=ac-miembros&action=nuevo'); ?>" class="ac-quick-action">
                    <span class="dashicons dashicons-admin-users"></span>
                    <span>Agregar Miembro</span>
                </a>
                
                <a href="<?php echo admin_url('admin.php?page=ac-eventos&action=nuevo'); ?>" class="ac-quick-action">
                    <span class="dashicons dashicons-calendar-alt"></span>
                    <span>Programar Evento</span>
                </a>
                
                <a href="<?php echo admin_url('admin.php?page=ac-documentos&action=nuevo'); ?>" class="ac-quick-action">
                    <span class="dashicons dashicons-media-document"></span>
                    <span>Subir Documento</span>
                </a>
                
                <a href="<?php echo admin_url('admin.php?page=ac-configuracion'); ?>" class="ac-quick-action">
                    <span class="dashicons dashicons-admin-settings"></span>
                    <span>Configuración</span>
                </a>
            </div>
            
            <h2 style="margin-top: 30px;">Información de la Asociación</h2>
            <?php
            $configuracion = get_option('asociacion_civil_settings');
            if (!empty($configuracion['nombre_asociacion'])):
            ?>
            <div class="ac-info-asociacion">
                <p><strong>Nombre:</strong> <?php echo esc_html($configuracion['nombre_asociacion']); ?></p>
                <?php if ($configuracion['rif']): ?>
                    <p><strong>RIF:</strong> <?php echo esc_html($configuracion['rif']); ?></p>
                <?php endif; ?>
                <?php if ($configuracion['telefono']): ?>
                    <p><strong>Teléfono:</strong> <?php echo esc_html($configuracion['telefono']); ?></p>
                <?php endif; ?>
                <?php if ($configuracion['email']): ?>
                    <p><strong>Email:</strong> <?php echo esc_html($configuracion['email']); ?></p>
                <?php endif; ?>
            </div>
            <?php else: ?>
                <p>Configura la información de tu asociación en la página de <a href="<?php echo admin_url('admin.php?page=ac-configuracion'); ?>">configuración</a>.</p>
            <?php endif; ?>
        </div>
    </div>
</div>