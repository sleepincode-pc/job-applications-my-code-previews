<?php
// Campos para Notas Judiciales
function ac_definir_campos_nota_judicial() {
    return array(
        'numero_expediente' => array(
            'type' => 'text',
            'label' => 'Número de Expediente',
            'required' => true
        ),
        'juzgado' => array(
            'type' => 'text',
            'label' => 'Juzgado o Tribunal'
        ),
        'juez' => array(
            'type' => 'text',
            'label' => 'Juez a Cargo'
        ),
        'fiscal' => array(
            'type' => 'text',
            'label' => 'Fiscal'
        ),
        'abogado_defensor' => array(
            'type' => 'text',
            'label' => 'Abogado Defensor'
        ),
        'tipo_proceso' => array(
            'type' => 'select',
            'label' => 'Tipo de Proceso',
            'options' => array(
                'penal' => 'Penal',
                'civil' => 'Civil',
                'familia' => 'Familia',
                'laboral' => 'Laboral',
                'administrativo' => 'Administrativo'
            )
        ),
        'fecha_audiencia' => array(
            'type' => 'date',
            'label' => 'Fecha de Audiencia'
        ),
        'hora_audiencia' => array(
            'type' => 'time',
            'label' => 'Hora de Audiencia'
        ),
        'resumen_hechos' => array(
            'type' => 'textarea',
            'label' => 'Resumen de Hechos'
        ),
        'dictamen_psicologico' => array(
            'type' => 'textarea',
            'label' => 'Dictamen Psicológico'
        ),
        'recomendaciones' => array(
            'type' => 'textarea',
            'label' => 'Recomendaciones'
        ),
        'medidas_cautelares' => array(
            'type' => 'textarea',
            'label' => 'Medidas Cautelares'
        ),
        'proximas_actuaciones' => array(
            'type' => 'textarea',
            'label' => 'Próximas Actuaciones'
        ),
        'observaciones_judiciales' => array(
            'type' => 'textarea',
            'label' => 'Observaciones Judiciales'
        )
    );
}
?>