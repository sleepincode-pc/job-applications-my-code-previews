<?php
/*
Plugin Name: Sistema Integral de Gestión
Description: Sistema completo para gestión de actas, planificador diario, registro de actividades y control de medicación
Version: 2.0
Author: Asociación Civil
Text Domain: sistema-integral
*/

// =============================================
// SEGURIDAD Y CONFIGURACIÓN INICIAL
// =============================================

// Prevenir acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Configurar zona horaria de Buenos Aires
date_default_timezone_set('America/Argentina/Buenos_Aires');

// Definir constantes del plugin
define('AC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AC_PLUGIN_VERSION', '2.0');

// =============================================
// FUNCIONES CORE DEL SISTEMA
// =============================================

// Verificar si WordPress está cargado
if (!function_exists('add_action')) {
    die('Este plugin requiere WordPress.');
}

// VERIFICACIÓN DE PERMISOS MEJORADA
function ac_verificar_permisos() {
    // Permitir a administradores y editores
    if (!current_user_can('manage_options') && !current_user_can('edit_pages')) {
        wp_die('No tienes permisos para acceder a esta página.');
    }
}

// FUNCIONES DE BASE DE DATOS Y TABLAS
function ac_conectar_bd() {
    global $wpdb;
    return $wpdb;
}

function ac_crear_tablas_si_no_existen() {
    global $wpdb;
    
    $charset_collate = $wpdb->get_charset_collate();
    
    // Tabla de actas
    $tabla_actas = $wpdb->prefix . 'ac_actas';
    
    // Verificar si la tabla ya existe
    if ($wpdb->get_var("SHOW TABLES LIKE '$tabla_actas'") != $tabla_actas) {
        $sql_actas = "CREATE TABLE $tabla_actas (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            titulo varchar(255) NOT NULL,
            fecha date NOT NULL,
            lugar varchar(255),
            tipo varchar(100),
            contenido longtext,
            asistentes longtext,
            acuerdos longtext,
            fecha_creacion datetime DEFAULT CURRENT_TIMESTAMP,
            fecha_actualizacion datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            convocante varchar(255),
            estado varchar(50) DEFAULT 'activo',
            usuario_id mediumint(9) DEFAULT 0,
            PRIMARY KEY (id),
            KEY idx_fecha (fecha),
            KEY idx_tipo (tipo),
            KEY idx_estado (estado),
            KEY idx_usuario (usuario_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_actas);
        
        // Registrar en el log que se creó la tabla
        error_log("Asociacion Civil: Tabla de actas creada - $tabla_actas");
    }
    
    // Tabla de registros diarios
    $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
    
    if ($wpdb->get_var("SHOW TABLES LIKE '$tabla_registros'") != $tabla_registros) {
        $sql_registros = "CREATE TABLE $tabla_registros (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            fecha date NOT NULL,
            actividad_id varchar(255) NOT NULL,
            actividad_nombre varchar(255) NOT NULL,
            estado varchar(50) NOT NULL,
            duracion_real int(11),
            valoracion int(11),
            observaciones text,
            tipo_actividad varchar(100),
            fecha_creacion datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_fecha (fecha),
            KEY idx_actividad (actividad_id),
            KEY idx_estado (estado)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_registros);
    }

    // Tabla de pacientes
    $tabla_pacientes = $wpdb->prefix . 'ac_pacientes';
    
    if ($wpdb->get_var("SHOW TABLES LIKE '$tabla_pacientes'") != $tabla_pacientes) {
        $sql_pacientes = "CREATE TABLE $tabla_pacientes (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            cedula varchar(50) NOT NULL,
            nombre varchar(255) NOT NULL,
            apellido varchar(255) NOT NULL,
            fecha_nacimiento date,
            genero varchar(20),
            telefono varchar(50),
            email varchar(255),
            direccion text,
            estado varchar(50) DEFAULT 'activo',
            fecha_creacion datetime DEFAULT CURRENT_TIMESTAMP,
            fecha_actualizacion datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY cedula (cedula),
            KEY idx_estado (estado),
            KEY idx_nombre (nombre),
            KEY idx_apellido (apellido)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_pacientes);
    }
}

function ac_crear_tabla_medicacion() {
    global $wpdb;
    
    $charset_collate = $wpdb->get_charset_collate();
    $tabla_medicacion = $wpdb->prefix . 'ac_medicacion';
    
    if ($wpdb->get_var("SHOW TABLES LIKE '$tabla_medicacion'") != $tabla_medicacion) {
        $sql_medicacion = "CREATE TABLE $tabla_medicacion (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            paciente_id mediumint(9) NOT NULL,
            medicamento varchar(255) NOT NULL,
            dosis varchar(100) NOT NULL,
            frecuencia varchar(100) NOT NULL,
            via_administracion varchar(50),
            fecha_inicio date NOT NULL,
            fecha_fin date,
            horario_administracion text,
            indicaciones_especiales text,
            estado varchar(20) DEFAULT 'activo',
            prescrito_por varchar(255),
            observaciones text,
            fecha_creacion datetime DEFAULT CURRENT_TIMESTAMP,
            fecha_actualizacion datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY paciente_id (paciente_id),
            KEY estado (estado),
            KEY fecha_inicio (fecha_inicio)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_medicacion);
    }
}

// =============================================
// SISTEMA DE REGISTRO AUTOMÁTICO MEJORADO
// =============================================

function ac_registro_automatico_actividad() {
    global $wpdb;
    
    $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
    $fecha_actual = date('Y-m-d');
    $hora_actual = date('H:i');
    
    // Obtener datos del horario
    $datos_horario = ac_obtener_estado_horario();
    $actividad_actual = ac_obtener_actividad_actual($datos_horario);
    
    if (!$actividad_actual) {
        return;
    }
    
    // Verificar si ya existe un registro para esta actividad hoy
    $actividad_id = $actividad_actual['hora'] . '_' . sanitize_title($actividad_actual['detalles']['actividad']);
    
    $existe_registro = $wpdb->get_var($wpdb->prepare("
        SELECT COUNT(*) FROM $tabla_registros 
        WHERE fecha = %s AND actividad_id = %s
    ", $fecha_actual, $actividad_id));
    
    if ($existe_registro > 0) {
        return; // Ya existe registro, no hacer nada
    }
    
    // Determinar estado automático basado en la hora
    $estado_auto = 'en_progreso';
    $hora_actividad = strtotime($actividad_actual['hora']);
    $hora_actual_ts = strtotime($hora_actual);
    $duracion = $actividad_actual['detalles']['duracion'];
    $hora_fin = strtotime($actividad_actual['hora'] . ' + ' . $duracion . ' minutes');
    
    // Si ya pasó más de 15 minutos del final, marcar como completada
    if ($hora_actual_ts > ($hora_fin + 900)) { // 900 segundos = 15 minutos
        $estado_auto = 'completada';
    }
    
    // Crear registro automático
    $resultado = $wpdb->insert(
        $tabla_registros,
        [
            'fecha' => $fecha_actual,
            'actividad_id' => $actividad_id,
            'actividad_nombre' => $actividad_actual['detalles']['actividad'],
            'estado' => $estado_auto,
            'duracion_real' => $actividad_actual['detalles']['duracion'],
            'valoracion' => 3, // Valoración neutral por defecto
            'observaciones' => 'Registro automático del sistema',
            'tipo_actividad' => $actividad_actual['detalles']['tipo']
        ],
        ['%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s']
    );
    
    if ($resultado) {
        error_log("Asociacion Civil: Registro automático creado para " . $actividad_actual['detalles']['actividad'] . " - Estado: " . $estado_auto);
    }
}

function ac_actualizar_registros_automaticos() {
    global $wpdb;
    
    $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
    $fecha_actual = date('Y-m-d');
    $hora_actual = date('H:i');
    
    // Obtener actividades en progreso
    $actividades_en_progreso = $wpdb->get_results($wpdb->prepare("
        SELECT * FROM $tabla_registros 
        WHERE fecha = %s AND estado = 'en_progreso'
    ", $fecha_actual), ARRAY_A);
    
    foreach ($actividades_en_progreso as $registro) {
        // Extraer hora de la actividad del ID
        $partes = explode('_', $registro['actividad_id']);
        $hora_actividad = $partes[0];
        
        // Calcular si la actividad ya debería haber terminado
        $duracion = $registro['duracion_real'] ?: 60;
        $hora_fin = date('H:i', strtotime($hora_actividad . ' + ' . $duracion . ' minutes'));
        
        // Si ya pasó el tiempo de la actividad + 15 minutos, marcarla como completada
        if (strtotime($hora_actual) > (strtotime($hora_fin) + 900)) {
            $wpdb->update(
                $tabla_registros,
                ['estado' => 'completada'],
                ['id' => $registro['id']],
                ['%s'],
                ['%d']
            );
            error_log("Asociacion Civil: Registro actualizado automáticamente a completado - " . $registro['actividad_nombre']);
        }
    }
}

function ac_verificar_actividades_faltantes() {
    global $wpdb;
    
    $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
    $fecha_actual = date('Y-m-d');
    $hora_actual = date('H:i');
    
    // Obtener actividades del día ya registradas
    $actividades_registradas = $wpdb->get_col($wpdb->prepare("
        SELECT actividad_id FROM $tabla_registros 
        WHERE fecha = %s
    ", $fecha_actual));
    
    $datos_horario = ac_obtener_estado_horario();
    $actividades_faltantes = [];
    
    foreach ($datos_horario['actividades'] as $hora => $detalles) {
        $actividad_id = $hora . '_' . sanitize_title($detalles['actividad']);
        
        // Solo considerar actividades que ya deberían haber comenzado
        if (strtotime($hora) <= strtotime($hora_actual)) {
            // Si no está registrada y ya pasó su hora de inicio
            if (!in_array($actividad_id, $actividades_registradas)) {
                $actividades_faltantes[] = [
                    'hora' => $hora,
                    'actividad' => $detalles['actividad'],
                    'icono' => $detalles['icono'],
                    'tipo' => $detalles['tipo'],
                    'duracion' => $detalles['duracion']
                ];
            }
        }
    }
    
    return $actividades_faltantes;
}

// =============================================
// FUNCIONES PARA MÉTRICAS Y ESTADÍSTICAS CORREGIDAS
// =============================================

function ac_obtener_registros_por_rango($rango = 'semana') {
    global $wpdb;
    
    $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
    
    // Verificar si la tabla existe
    if ($wpdb->get_var("SHOW TABLES LIKE '$tabla_registros'") != $tabla_registros) {
        return [];
    }
    
    // Calcular fechas según el rango CORREGIDO
    $fecha_fin = date('Y-m-d');
    switch ($rango) {
        case 'hoy':
            $fecha_inicio = $fecha_fin;
            break;
        case 'semana':
            $fecha_inicio = date('Y-m-d', strtotime('-6 days')); // 7 días incluyendo hoy
            break;
        case 'mes':
            $fecha_inicio = date('Y-m-d', strtotime('-29 days')); // 30 días incluyendo hoy
            break;
        default:
            $fecha_inicio = date('Y-m-d', strtotime('-6 days'));
    }
    
    $query = $wpdb->prepare("
        SELECT * FROM $tabla_registros 
        WHERE fecha BETWEEN %s AND %s 
        ORDER BY fecha DESC, id DESC
    ", $fecha_inicio, $fecha_fin);
    
    return $wpdb->get_results($query, ARRAY_A);
}

function ac_obtener_estadisticas_cumplimiento_mejorado($rango = 'semana') {
    global $wpdb;
    
    $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
    
    // Verificar si la tabla existe
    if ($wpdb->get_var("SHOW TABLES LIKE '$tabla_registros'") != $tabla_registros) {
        return ac_estadisticas_por_defecto($rango);
    }
    
    // Calcular fechas según el rango CORREGIDO
    $fecha_fin = date('Y-m-d');
    switch ($rango) {
        case 'hoy':
            $fecha_inicio = $fecha_fin;
            break;
        case 'semana':
            $fecha_inicio = date('Y-m-d', strtotime('-6 days')); // 7 días incluyendo hoy
            break;
        case 'mes':
            $fecha_inicio = date('Y-m-d', strtotime('-29 days')); // 30 días incluyendo hoy
            break;
        default:
            $fecha_inicio = date('Y-m-d', strtotime('-6 days'));
    }
    
    // Obtener estadísticas REALES desde la base de datos
    $query = $wpdb->prepare("
        SELECT 
            COUNT(*) as total_actividades,
            SUM(CASE WHEN estado = 'completada' THEN 1 ELSE 0 END) as completadas,
            SUM(CASE WHEN estado = 'pendiente' THEN 1 ELSE 0 END) as pendientes,
            SUM(CASE WHEN estado = 'cancelada' THEN 1 ELSE 0 END) as canceladas,
            SUM(CASE WHEN estado = 'no_cumplida' THEN 1 ELSE 0 END) as no_cumplidas,
            SUM(CASE WHEN estado = 'en_progreso' THEN 1 ELSE 0 END) as en_progreso,
            AVG(CASE WHEN valoracion > 0 THEN valoracion ELSE NULL END) as valoracion_promedio,
            AVG(CASE WHEN duracion_real > 0 THEN duracion_real ELSE NULL END) as duracion_promedio
        FROM $tabla_registros 
        WHERE fecha BETWEEN %s AND %s
    ", $fecha_inicio, $fecha_fin);
    
    $estadisticas = $wpdb->get_row($query, ARRAY_A);
    
    if (!$estadisticas || $estadisticas['total_actividades'] == 0) {
        return ac_estadisticas_por_defecto($rango, $fecha_inicio, $fecha_fin);
    }
    
    // Calcular porcentajes
    $total = $estadisticas['total_actividades'];
    $completadas = $estadisticas['completadas'];
    $pendientes = $estadisticas['pendientes'];
    $canceladas = $estadisticas['canceladas'];
    $no_cumplidas = $estadisticas['no_cumplidas'];
    $en_progreso = $estadisticas['en_progreso'];
    
    $porcentaje_completadas = $total > 0 ? round(($completadas / $total) * 100) : 0;
    $porcentaje_pendientes = $total > 0 ? round(($pendientes / $total) * 100) : 0;
    $porcentaje_canceladas = $total > 0 ? round(($canceladas / $total) * 100) : 0;
    $porcentaje_no_cumplidas = $total > 0 ? round(($no_cumplidas / $total) * 100) : 0;
    $porcentaje_en_progreso = $total > 0 ? round(($en_progreso / $total) * 100) : 0;
    
    return [
        'total_actividades' => $total,
        'completadas' => $completadas,
        'pendientes' => $pendientes,
        'canceladas' => $canceladas,
        'no_cumplidas' => $no_cumplidas,
        'en_progreso' => $en_progreso,
        'porcentaje_completadas' => $porcentaje_completadas,
        'porcentaje_pendientes' => $porcentaje_pendientes,
        'porcentaje_canceladas' => $porcentaje_canceladas,
        'porcentaje_no_cumplidas' => $porcentaje_no_cumplidas,
        'porcentaje_en_progreso' => $porcentaje_en_progreso,
        'valoracion_promedio' => floatval($estadisticas['valoracion_promedio'] ?? 0),
        'duracion_promedio' => floatval($estadisticas['duracion_promedio'] ?? 0),
        'rango' => $rango,
        'fecha_inicio' => $fecha_inicio,
        'fecha_fin' => $fecha_fin,
        'con_datos' => true
    ];
}

function ac_estadisticas_por_defecto($rango, $fecha_inicio = null, $fecha_fin = null) {
    if ($fecha_inicio === null) {
        $fecha_fin = date('Y-m-d');
        switch ($rango) {
            case 'hoy':
                $fecha_inicio = $fecha_fin;
                break;
            case 'semana':
                $fecha_inicio = date('Y-m-d', strtotime('-6 days'));
                break;
            case 'mes':
                $fecha_inicio = date('Y-m-d', strtotime('-29 days'));
                break;
            default:
                $fecha_inicio = date('Y-m-d', strtotime('-6 days'));
        }
    }
    
    return [
        'total_actividades' => 0,
        'completadas' => 0,
        'pendientes' => 0,
        'canceladas' => 0,
        'no_cumplidas' => 0,
        'en_progreso' => 0,
        'porcentaje_completadas' => 0,
        'porcentaje_pendientes' => 0,
        'porcentaje_canceladas' => 0,
        'porcentaje_no_cumplidas' => 0,
        'porcentaje_en_progreso' => 0,
        'valoracion_promedio' => 0,
        'duracion_promedio' => 0,
        'rango' => $rango,
        'fecha_inicio' => $fecha_inicio,
        'fecha_fin' => $fecha_fin,
        'con_datos' => false
    ];
}

// =============================================
// PLANIFICADOR DIARIO - FUNCIONES PRINCIPALES
// =============================================

function ac_obtener_estado_horario() {
    $hora_actual = date('H:i');
    $dia_actual = date('N');
    
    // Estructura horaria
    $actividades = [
        '08:00' => ['actividad' => 'Buen día / Despertar', 'icono' => '☀️', 'duracion' => 30, 'tipo' => 'rutina'],
        '08:30' => ['actividad' => 'Desayuno', 'icono' => '🍽️', 'duracion' => 30, 'tipo' => 'alimentacion'],
        '09:00' => ['actividad' => 'Lectura: "Solo por Hoy" + Libro Azul + Reflexión', 'icono' => '📖', 'duracion' => 30, 'tipo' => 'desarrollo_personal'],
        '09:30' => ['actividad' => 'Objetivos del día', 'icono' => '🎯', 'duracion' => 30, 'tipo' => 'planificacion'],
        '10:00' => ['actividad' => 'Reorden (organización y limpieza)', 'icono' => '🧹', 'duracion' => 90, 'tipo' => 'organizacion'],
        '11:30' => ['actividad' => 'Grupo de Sentimiento Libre', 'icono' => '👥', 'duracion' => 60, 'tipo' => 'terapia_grupal'],
        '12:30' => ['actividad' => 'Almuerzo', 'icono' => '🥗', 'duracion' => 30, 'tipo' => 'alimentacion'],
        '13:00' => ['actividad' => 'Hora Libre', 'icono' => '🆓', 'duracion' => 130, 'tipo' => 'descanso'],
        '15:10' => ['actividad' => 'Grupo de R.E.S. escrita del día anterior', 'icono' => '✍️', 'duracion' => 170, 'tipo' => 'terapia_escrita'],
        '18:10' => ['actividad' => 'Merienda', 'icono' => '☕', 'duracion' => 50, 'tipo' => 'alimentacion'],
        '19:00' => ['actividad' => 'Grupo de Escritura de R.E.S. para leer al día siguiente', 'icono' => '📝', 'duracion' => 120, 'tipo' => 'terapia_escrita'],
        '21:00' => ['actividad' => 'Cena', 'icono' => '🍲', 'duracion' => 60, 'tipo' => 'alimentacion'],
        '22:00' => ['actividad' => 'Medicación', 'icono' => '💊', 'duracion' => 60, 'tipo' => 'salud'],
        '23:00' => ['actividad' => 'Todos a la cama', 'icono' => '🛌', 'duracion' => 480, 'tipo' => 'descanso']
    ];
    
    return [
        'hora_actual' => $hora_actual,
        'dia_actual' => $dia_actual,
        'actividades' => $actividades
    ];
}

function ac_obtener_actividad_actual($datos_horario) {
    $hora_actual = $datos_horario['hora_actual'];
    $actividades = $datos_horario['actividades'];
    
    $actividad_actual = null;
    $hora_actual_ts = strtotime($hora_actual);
    
    foreach ($actividades as $hora => $detalles) {
        $hora_inicio_ts = strtotime($hora);
        $hora_fin_ts = strtotime($hora . ' + ' . $detalles['duracion'] . ' minutes');
        
        // Si la hora actual está entre el inicio y el fin de la actividad
        if ($hora_actual_ts >= $hora_inicio_ts && $hora_actual_ts < $hora_fin_ts) {
            $actividad_actual = [
                'hora' => $hora,
                'detalles' => $detalles,
                'hora_fin' => date('H:i', $hora_fin_ts)
            ];
            break;
        }
    }
    
    return $actividad_actual;
}

function ac_obtener_proximas_actividades($datos_horario, $limite = 3) {
    $hora_actual = $datos_horario['hora_actual'];
    $actividades = $datos_horario['actividades'];
    
    $proximas = [];
    $hora_actual_ts = strtotime($hora_actual);
    
    foreach ($actividades as $hora => $detalles) {
        $hora_actividad_ts = strtotime($hora);
        
        // Solo incluir actividades futuras
        if ($hora_actividad_ts > $hora_actual_ts) {
            $minutos_restantes = round(($hora_actividad_ts - $hora_actual_ts) / 60);
            
            $proximas[] = [
                'hora' => $hora, 
                'detalles' => $detalles,
                'minutos_restantes' => $minutos_restantes,
                'timestamp' => $hora_actividad_ts
            ];
            
            if (count($proximas) >= $limite) break;
        }
    }
    
    return $proximas;
}

function ac_calcular_minutos_restantes($hora_actual, $hora_objetivo) {
    $actual = strtotime($hora_actual);
    $objetivo = strtotime($hora_objetivo);
    $diferencia = $objetivo - $actual;
    return round($diferencia / 60);
}

function ac_calcular_progreso_dia($datos_horario) {
    $hora_actual = strtotime($datos_horario['hora_actual']);
    $inicio_dia = strtotime('08:00');
    $fin_dia = strtotime('23:00');
    $total_minutos = ($fin_dia - $inicio_dia) / 60;
    $minutos_transcurridos = ($hora_actual - $inicio_dia) / 60;
    
    if ($minutos_transcurridos < 0) return 0;
    if ($minutos_transcurridos > $total_minutos) return 100;
    
    return round(($minutos_transcurridos / $total_minutos) * 100);
}

// =============================================
// SISTEMA DE GUARDADO Y ESTADÍSTICAS
// =============================================

function ac_guardar_registro_diario() {
    // Verificar permisos primero
    if (!current_user_can('manage_options') && !current_user_can('edit_pages')) {
        return [
            'success' => false,
            'message' => 'No tienes permisos para realizar esta acción.'
        ];
    }
    
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'guardar_registro_diario')) {
        return [
            'success' => false,
            'message' => 'Error de seguridad. Por favor, recarga la página.'
        ];
    }
    
    global $wpdb;
    
    $fecha = sanitize_text_field($_POST['fecha'] ?? '');
    $actividad_id = sanitize_text_field($_POST['actividad_id'] ?? '');
    $actividad_nombre = sanitize_text_field($_POST['actividad_nombre'] ?? '');
    $estado = sanitize_text_field($_POST['estado'] ?? 'completada');
    $observaciones = sanitize_textarea_field($_POST['observaciones'] ?? '');
    $duracion_real = intval($_POST['duracion_real'] ?? 0);
    $valoracion = intval($_POST['valoracion'] ?? 5);
    $tipo_actividad = sanitize_text_field($_POST['tipo_actividad'] ?? '');
    
    // Validaciones básicas
    if (empty($fecha) || empty($actividad_id) || empty($actividad_nombre)) {
        return [
            'success' => false,
            'message' => 'Faltan campos obligatorios.'
        ];
    }
    
    $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
    
    // Verificar si ya existe un registro para esta actividad en esta fecha
    $existe = $wpdb->get_var($wpdb->prepare("
        SELECT COUNT(*) FROM $tabla_registros 
        WHERE fecha = %s AND actividad_id = %s
    ", $fecha, $actividad_id));
    
    if ($existe > 0) {
        // Actualizar registro existente
        $resultado = $wpdb->update(
            $tabla_registros,
            [
                'estado' => $estado,
                'duracion_real' => $duracion_real,
                'valoracion' => $valoracion,
                'observaciones' => $observaciones,
                'tipo_actividad' => $tipo_actividad
            ],
            [
                'fecha' => $fecha,
                'actividad_id' => $actividad_id
            ],
            ['%s', '%d', '%d', '%s', '%s'],
            ['%s', '%s']
        );
    } else {
        // Insertar nuevo registro
        $resultado = $wpdb->insert(
            $tabla_registros,
            [
                'fecha' => $fecha,
                'actividad_id' => $actividad_id,
                'actividad_nombre' => $actividad_nombre,
                'estado' => $estado,
                'duracion_real' => $duracion_real,
                'valoracion' => $valoracion,
                'observaciones' => $observaciones,
                'tipo_actividad' => $tipo_actividad
            ],
            ['%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s']
        );
    }
    
    if ($resultado === false) {
        return [
            'success' => false,
            'message' => 'Error al guardar en la base de datos: ' . $wpdb->last_error
        ];
    }
    
    return [
        'success' => true,
        'message' => 'Registro guardado correctamente'
    ];
}

// =============================================
// SISTEMA DE ACTAS - FUNCIONES DE BASE DE DATOS
// =============================================

function get_acta_property($acta, $property) {
    if (!is_object($acta) && !is_array($acta)) {
        return '';
    }
    
    // Si es array, acceso directo
    if (is_array($acta)) {
        return isset($acta[$property]) ? $acta[$property] : '';
    }
    
    return '';
}

function ac_obtener_actas_existentes($limit = 50, $offset = 0) {
    global $wpdb;
    
    $tabla_actas = $wpdb->prefix . 'ac_actas';
    
    // Verificar si la tabla existe
    if ($wpdb->get_var("SHOW TABLES LIKE '$tabla_actas'") != $tabla_actas) {
        // Si la tabla no existe, crearla
        ac_crear_tablas_si_no_existen();
        return [];
    }
    
    $query = $wpdb->prepare("
        SELECT * FROM $tabla_actas 
        WHERE estado = 'activo' 
        ORDER BY fecha DESC, id DESC 
        LIMIT %d OFFSET %d
    ", $limit, $offset);
    
    $actas = $wpdb->get_results($query, ARRAY_A);
    
    return $actas ?: [];
}

function ac_obtener_acta_por_id($id) {
    global $wpdb;
    
    $tabla_actas = $wpdb->prefix . 'ac_actas';
    
    $query = $wpdb->prepare("
        SELECT * FROM $tabla_actas 
        WHERE id = %d AND estado = 'activo'
    ", $id);
    
    $acta = $wpdb->get_row($query, ARRAY_A);
    
    return $acta;
}

function ac_guardar_acta($datos_acta) {
    // Verificar permisos
    if (!current_user_can('manage_options') && !current_user_can('edit_pages')) {
        return ['success' => false, 'message' => 'No tienes permisos para realizar esta acción.'];
    }
    
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'guardar_acta')) {
        return ['success' => false, 'message' => 'Error de seguridad'];
    }
    
    global $wpdb;
    
    $tabla_actas = $wpdb->prefix . 'ac_actas';
    
    // Sanitizar datos
    $id = intval($datos_acta['id'] ?? 0);
    $titulo = sanitize_text_field($datos_acta['titulo'] ?? '');
    $fecha = sanitize_text_field($datos_acta['fecha'] ?? '');
    $lugar = sanitize_text_field($datos_acta['lugar'] ?? '');
    $tipo = sanitize_text_field($datos_acta['tipo'] ?? '');
    $convocante = sanitize_text_field($datos_acta['convocante'] ?? '');
    $contenido = wp_kses_post($datos_acta['contenido'] ?? '');
    $asistentes = sanitize_textarea_field($datos_acta['asistentes'] ?? '');
    $acuerdos = sanitize_textarea_field($datos_acta['acuerdos'] ?? '');
    $estado = sanitize_text_field($datos_acta['estado'] ?? 'activo');
    $usuario_id = get_current_user_id();
    
    if (empty($titulo) || empty($fecha)) {
        return ['success' => false, 'message' => 'El título y la fecha son obligatorios'];
    }
    
    $datos = [
        'titulo' => $titulo,
        'fecha' => $fecha,
        'lugar' => $lugar,
        'tipo' => $tipo,
        'convocante' => $convocante,
        'contenido' => $contenido,
        'asistentes' => $asistentes,
        'acuerdos' => $acuerdos,
        'estado' => $estado,
        'usuario_id' => $usuario_id
    ];
    
    if ($id > 0) {
        // Actualizar acta existente
        $resultado = $wpdb->update(
            $tabla_actas,
            $datos,
            ['id' => $id],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d'],
            ['%d']
        );
    } else {
        // Insertar nueva acta
        $resultado = $wpdb->insert(
            $tabla_actas,
            $datos,
            ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d']
        );
        $id = $wpdb->insert_id;
    }
    
    if ($resultado === false) {
        return [
            'success' => false,
            'message' => 'Error al guardar en la base de datos: ' . $wpdb->last_error
        ];
    }
    
    return [
        'success' => true,
        'message' => $id > 0 ? 'Acta actualizada correctamente' : 'Acta creada correctamente',
        'id' => $id
    ];
}

function ac_eliminar_acta($id) {
    // Verificar permisos
    if (!current_user_can('manage_options') && !current_user_can('edit_pages')) {
        return ['success' => false, 'message' => 'No tienes permisos para realizar esta acción.'];
    }
    
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'eliminar_acta_' . $id)) {
        return ['success' => false, 'message' => 'Error de seguridad'];
    }
    
    global $wpdb;
    
    $tabla_actas = $wpdb->prefix . 'ac_actas';
    
    $resultado = $wpdb->update(
        $tabla_actas,
        ['estado' => 'eliminado'],
        ['id' => $id],
        ['%s'],
        ['%d']
    );
    
    if ($resultado === false) {
        return [
            'success' => false,
            'message' => 'Error al eliminar el acta: ' . $wpdb->last_error
        ];
    }
    
    return [
        'success' => true,
        'message' => 'Acta eliminada correctamente'
    ];
}

// =============================================
// SISTEMA DE MEDICACIÓN - FUNCIONES PRINCIPALES
// =============================================

function ac_obtener_pacientes_activos() {
    global $wpdb;
    
    $tabla_pacientes = $wpdb->prefix . 'ac_pacientes';
    
    // Verificar si la tabla existe
    if ($wpdb->get_var("SHOW TABLES LIKE '$tabla_pacientes'") != $tabla_pacientes) {
        return [];
    }
    
    $query = "SELECT * FROM $tabla_pacientes WHERE estado = 'activo' ORDER BY nombre, apellido ASC";
    
    $resultados = $wpdb->get_results($query, ARRAY_A);
    
    // Convertir a objetos Paciente (simplificado)
    $pacientes = [];
    foreach ($resultados as $resultado) {
        $pacientes[] = (object) $resultado;
    }
    
    return $pacientes;
}

function ac_guardar_medicacion() {
    // Verificar permisos
    if (!current_user_can('manage_options') && !current_user_can('edit_pages')) {
        return ['success' => false, 'message' => 'No tienes permisos para realizar esta acción.'];
    }
    
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'guardar_medicacion')) {
        return ['success' => false, 'message' => 'Error de seguridad'];
    }
    
    global $wpdb;
    
    $tabla_medicacion = $wpdb->prefix . 'ac_medicacion';
    
    // Sanitizar datos
    $id = intval($_POST['id'] ?? 0);
    $paciente_id = intval($_POST['paciente_id'] ?? 0);
    $medicamento = sanitize_text_field($_POST['medicamento'] ?? '');
    $dosis = sanitize_text_field($_POST['dosis'] ?? '');
    $frecuencia = sanitize_text_field($_POST['frecuencia'] ?? '');
    $via_administracion = sanitize_text_field($_POST['via_administracion'] ?? '');
    $fecha_inicio = sanitize_text_field($_POST['fecha_inicio'] ?? '');
    $fecha_fin = sanitize_text_field($_POST['fecha_fin'] ?? '');
    $horario_administracion = sanitize_textarea_field($_POST['horario_administracion'] ?? '');
    $prescrito_por = sanitize_text_field($_POST['prescrito_por'] ?? '');
    $indicaciones_especiales = sanitize_textarea_field($_POST['indicaciones_especiales'] ?? '');
    $observaciones = sanitize_textarea_field($_POST['observaciones'] ?? '');
    $estado = sanitize_text_field($_POST['estado'] ?? 'activo');
    
    if (empty($paciente_id) || empty($medicamento) || empty($dosis) || empty($frecuencia) || empty($fecha_inicio)) {
        return ['success' => false, 'message' => 'Los campos obligatorios están vacíos'];
    }
    
    $datos = [
        'paciente_id' => $paciente_id,
        'medicamento' => $medicamento,
        'dosis' => $dosis,
        'frecuencia' => $frecuencia,
        'via_administracion' => $via_administracion,
        'fecha_inicio' => $fecha_inicio,
        'fecha_fin' => $fecha_fin,
        'horario_administracion' => $horario_administracion,
        'prescrito_por' => $prescrito_por,
        'indicaciones_especiales' => $indicaciones_especiales,
        'observaciones' => $observaciones,
        'estado' => $estado
    ];
    
    if ($id > 0) {
        // Actualizar medicación existente
        $resultado = $wpdb->update(
            $tabla_medicacion,
            $datos,
            ['id' => $id],
            ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'],
            ['%d']
        );
    } else {
        // Insertar nueva medicación
        $resultado = $wpdb->insert(
            $tabla_medicacion,
            $datos,
            ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
        );
        $id = $wpdb->insert_id;
    }
    
    if ($resultado === false) {
        return [
            'success' => false,
            'message' => 'Error al guardar en la base de datos: ' . $wpdb->last_error
        ];
    }
    
    return [
        'success' => true,
        'message' => $id > 0 ? 'Medicación actualizada correctamente' : 'Medicación registrada correctamente',
        'id' => $id
    ];
}

// =============================================
// SISTEMA DE ACTIVIDADES GUARDADAS - CRUD COMPLETO
// =============================================

function ac_obtener_todas_actividades($limit = 100, $offset = 0, $filtros = []) {
    global $wpdb;
    
    $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
    
    // Verificar si la tabla existe
    if ($wpdb->get_var("SHOW TABLES LIKE '$tabla_registros'") != $tabla_registros) {
        return [];
    }
    
    $where_conditions = ["1=1"];
    $params = [];
    
    // Aplicar filtros
    if (!empty($filtros['fecha_desde'])) {
        $where_conditions[] = "fecha >= %s";
        $params[] = $filtros['fecha_desde'];
    }
    
    if (!empty($filtros['fecha_hasta'])) {
        $where_conditions[] = "fecha <= %s";
        $params[] = $filtros['fecha_hasta'];
    }
    
    if (!empty($filtros['estado'])) {
        $where_conditions[] = "estado = %s";
        $params[] = $filtros['estado'];
    }
    
    if (!empty($filtros['tipo_actividad'])) {
        $where_conditions[] = "tipo_actividad = %s";
        $params[] = $filtros['tipo_actividad'];
    }
    
    if (!empty($filtros['actividad_nombre'])) {
        $where_conditions[] = "actividad_nombre LIKE %s";
        $params[] = '%' . $wpdb->esc_like($filtros['actividad_nombre']) . '%';
    }
    
    $where_clause = implode(" AND ", $where_conditions);
    
    // Agregar parámetros de límite y offset
    $params[] = $limit;
    $params[] = $offset;
    
    $query = $wpdb->prepare("
        SELECT * FROM $tabla_registros 
        WHERE $where_clause 
        ORDER BY fecha DESC, id DESC 
        LIMIT %d OFFSET %d
    ", $params);
    
    $actividades = $wpdb->get_results($query, ARRAY_A);
    
    return $actividades ?: [];
}

function ac_contar_actividades($filtros = []) {
    global $wpdb;
    
    $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
    
    // Verificar si la tabla existe
    if ($wpdb->get_var("SHOW TABLES LIKE '$tabla_registros'") != $tabla_registros) {
        return 0;
    }
    
    $where_conditions = ["1=1"];
    $params = [];
    
    // Aplicar filtros
    if (!empty($filtros['fecha_desde'])) {
        $where_conditions[] = "fecha >= %s";
        $params[] = $filtros['fecha_desde'];
    }
    
    if (!empty($filtros['fecha_hasta'])) {
        $where_conditions[] = "fecha <= %s";
        $params[] = $filtros['fecha_hasta'];
    }
    
    if (!empty($filtros['estado'])) {
        $where_conditions[] = "estado = %s";
        $params[] = $filtros['estado'];
    }
    
    if (!empty($filtros['tipo_actividad'])) {
        $where_conditions[] = "tipo_actividad = %s";
        $params[] = $filtros['tipo_actividad'];
    }
    
    if (!empty($filtros['actividad_nombre'])) {
        $where_conditions[] = "actividad_nombre LIKE %s";
        $params[] = '%' . $wpdb->esc_like($filtros['actividad_nombre']) . '%';
    }
    
    $where_clause = implode(" AND ", $where_conditions);
    
    if (!empty($params)) {
        $query = $wpdb->prepare("
            SELECT COUNT(*) FROM $tabla_registros 
            WHERE $where_clause
        ", $params);
    } else {
        $query = "SELECT COUNT(*) FROM $tabla_registros WHERE $where_clause";
    }
    
    return $wpdb->get_var($query);
}

function ac_obtener_actividad_por_id($id) {
    global $wpdb;
    
    $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
    
    $query = $wpdb->prepare("
        SELECT * FROM $tabla_registros 
        WHERE id = %d
    ", $id);
    
    $actividad = $wpdb->get_row($query, ARRAY_A);
    
    return $actividad;
}

function ac_actualizar_actividad($id, $datos) {
    // Verificar permisos
    if (!current_user_can('manage_options') && !current_user_can('edit_pages')) {
        return ['success' => false, 'message' => 'No tienes permisos para realizar esta acción.'];
    }
    
    global $wpdb;
    
    $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
    
    // Sanitizar datos
    $estado = sanitize_text_field($datos['estado'] ?? '');
    $duracion_real = intval($datos['duracion_real'] ?? 0);
    $valoracion = intval($datos['valoracion'] ?? 0);
    $observaciones = sanitize_textarea_field($datos['observaciones'] ?? '');
    $tipo_actividad = sanitize_text_field($datos['tipo_actividad'] ?? '');
    
    $resultado = $wpdb->update(
        $tabla_registros,
        [
            'estado' => $estado,
            'duracion_real' => $duracion_real,
            'valoracion' => $valoracion,
            'observaciones' => $observaciones,
            'tipo_actividad' => $tipo_actividad
        ],
        ['id' => $id],
        ['%s', '%d', '%d', '%s', '%s'],
        ['%d']
    );
    
    if ($resultado === false) {
        return [
            'success' => false,
            'message' => 'Error al actualizar la actividad: ' . $wpdb->last_error
        ];
    }
    
    return [
        'success' => true,
        'message' => 'Actividad actualizada correctamente'
    ];
}

function ac_eliminar_actividad($id) {
    // Verificar permisos
    if (!current_user_can('manage_options') && !current_user_can('edit_pages')) {
        return ['success' => false, 'message' => 'No tienes permisos para realizar esta acción.'];
    }
    
    global $wpdb;
    
    $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
    
    $resultado = $wpdb->delete(
        $tabla_registros,
        ['id' => $id],
        ['%d']
    );
    
    if ($resultado === false) {
        return [
            'success' => false,
            'message' => 'Error al eliminar la actividad: ' . $wpdb->last_error
        ];
    }
    
    return [
        'success' => true,
        'message' => 'Actividad eliminada correctamente'
    ];
}

// =============================================
// INTERFAZ DE NAVEGACIÓN UNIFICADA MEJORADA
// =============================================

function mostrar_navegacion_unificada() {
    $modo_actual = isset($_GET['modo']) ? sanitize_text_field($_GET['modo']) : 'planificador';
    $submodo_actual = isset($_GET['submodo']) ? sanitize_text_field($_GET['submodo']) : '';
    ?>
    <div class="ac-navigation" style="margin: 20px 0; background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
        <h2 style="margin-top: 0;">Sistema Integral de Gestión</h2>
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador'); ?>" 
               class="button <?php echo $modo_actual === 'planificador' && $submodo_actual !== 'actividades' ? 'button-primary' : ''; ?>" 
               style="text-decoration: none;">
                📅 Planificador Diario
            </a>
            <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador&submodo=actividades'); ?>" 
               class="button <?php echo $submodo_actual === 'actividades' ? 'button-primary' : ''; ?>" 
               style="text-decoration: none;">
                📊 Actividades Guardadas
            </a>
            <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas'); ?>" 
               class="button <?php echo $modo_actual === 'actas' ? 'button-primary' : ''; ?>" 
               style="text-decoration: none;">
                📋 Libro de Actas
            </a>
            <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=medicacion'); ?>" 
               class="button <?php echo $modo_actual === 'medicacion' ? 'button-primary' : ''; ?>" 
               style="text-decoration: none;">
                💊 Medicación
            </a>
        </div>
    </div>
    <?php
}

// =============================================
// INTERFAZ PRINCIPAL - SISTEMA INTEGRAL
// =============================================

function ac_sistema_integrado() {
    // Verificar permisos MEJORADO - más permisivo
    if (!current_user_can('manage_options') && !current_user_can('edit_pages')) {
        wp_die(
            '<div style="text-align: center; padding: 50px; font-family: Arial, sans-serif;">
                <h1 style="color: #dc3232;">❌ Acceso Denegado</h1>
                <p>No tienes permisos para acceder al Sistema Integral de Gestión.</p>
                <p>Contacta al administrador del sitio para solicitar acceso.</p>
                <p><a href="' . admin_url() . '" class="button">Volver al Inicio</a></p>
            </div>'
        );
    }
    
    $modo_actual = isset($_GET['modo']) ? sanitize_text_field($_GET['modo']) : 'planificador';
    
    // Asegurar que las tablas existan
    ac_crear_tablas_si_no_existen();
    ac_crear_tabla_medicacion();
    
    // Mostrar navegación unificada
    mostrar_navegacion_unificada();
    
    // Cargar el sistema correspondiente
    switch ($modo_actual) {
        case 'planificador':
            ac_mostrar_planificador_completo();
            break;
            
        case 'actas':
            ac_mostrar_sistema_actas();
            break;
            
        case 'medicacion':
            ac_mostrar_sistema_medicacion();
            break;
            
        default:
            ac_mostrar_planificador_completo();
    }
}

// =============================================
// PLANIFICADOR DIARIO - INTERFAZ COMPLETA
// =============================================

function ac_mostrar_planificador_completo() {
    $submodo_actual = isset($_GET['submodo']) ? sanitize_text_field($_GET['submodo']) : '';
    
    if ($submodo_actual === 'actividades') {
        ac_mostrar_lista_actividades();
        return;
    }
    
    $rango_actual = isset($_GET['rango']) ? sanitize_text_field($_GET['rango']) : 'semana';
    $datos_horario = ac_obtener_estado_horario();
    $actividad_actual = ac_obtener_actividad_actual($datos_horario);
    $proximas_actividades = ac_obtener_proximas_actividades($datos_horario, 3);
    $progreso_dia = ac_calcular_progreso_dia($datos_horario);
    
    // OBTENER ESTADÍSTICAS REALES DE LA BASE DE DATOS
    $estadisticas = ac_obtener_estadisticas_cumplimiento_mejorado($rango_actual);
    
    // VERIFICAR ACTIVIDADES FALTANTES
    $actividades_faltantes = ac_verificar_actividades_faltantes();
    
    $dias_semana = [1 => 'Lunes', 2 => 'Martes', 3 => 'Miércoles', 4 => 'Jueves', 5 => 'Viernes', 6 => 'Sábado', 7 => 'Domingo'];
    
    // Manejar formularios
    ob_start();
    ?>
    
    <div class="wrap">
        <h1 class="wp-heading-inline">🗓️ Planificador Diario - Sistema Integral</h1>
        
        <!-- Acciones Principales -->
        <div class="ac-header-actions" style="display: flex; justify-content: space-between; align-items: center; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px;">
            <div>
                <button type="button" id="registrar-actividad-actual" class="button button-primary" style="font-size: 14px; padding: 8px 16px;">
                    <span class="dashicons dashicons-plus" style="margin-top: 4px;"></span>
                    Registrar Actividad Actual
                </button>
                <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador&export=registros'); ?>" class="button" style="font-size: 14px; padding: 8px 16px; margin-left: 10px;">
                    <span class="dashicons dashicons-media-spreadsheet" style="margin-top: 4px;"></span>
                    Exportar Registros
                </a>
                <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador&submodo=actividades'); ?>" class="button" style="font-size: 14px; padding: 8px 16px; margin-left: 10px;">
                    <span class="dashicons dashicons-list-view" style="margin-top: 4px;"></span>
                    Ver Todas las Actividades
                </a>
                
                <!-- Botón para registro automático de actividades faltantes -->
                <?php if (!empty($actividades_faltantes)): ?>
                <button type="button" id="registrar-automatico" class="button" style="font-size: 14px; padding: 8px 16px; margin-left: 10px; background: #ffb900; border-color: #ffb900;">
                    <span class="dashicons dashicons-update" style="margin-top: 4px;"></span>
                    Registrar Actividades Faltantes (<?php echo count($actividades_faltantes); ?>)
                </button>
                <?php endif; ?>
            </div>
            
            <div class="ac-search-export" style="display: flex; gap: 10px; align-items: center;">
                <span class="description" style="color: #666; font-size: 13px;">
                    <?php echo date('d/m/Y'); ?> • 
                    <?php echo $dias_semana[$datos_horario['dia_actual']]; ?>
                </span>
            </div>
        </div>
        
        <!-- Panel de Recordatorios de Actividades Faltantes -->
        <?php if (!empty($actividades_faltantes)): ?>
        <div class="ac-recordatorios-panel" style="margin: 20px 0;">
            <div style="background: #fff3cd; border: 1px solid #ffeaa7; border-left: 4px solid #fdcb6e; padding: 15px 20px; border-radius: 8px;">
                <h3 style="margin: 0 0 10px 0; color: #856404; display: flex; align-items: center; gap: 10px;">
                    <span class="dashicons dashicons-warning" style="color: #f39c12;"></span>
                    Actividades Pendientes de Registro
                </h3>
                <p style="margin: 0 0 15px 0; color: #856404;">
                    El sistema detectó <strong><?php echo count($actividades_faltantes); ?> actividades</strong> que ya pasaron pero no están registradas.
                </p>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 10px; margin-bottom: 15px;">
                    <?php foreach ($actividades_faltantes as $index => $actividad): ?>
                    <div style="background: rgba(255,255,255,0.7); padding: 10px; border-radius: 4px; display: flex; align-items: center; gap: 10px;">
                        <div style="font-size: 20px;"><?php echo $actividad['icono']; ?></div>
                        <div style="flex: 1;">
                            <div style="font-weight: bold; font-size: 13px;"><?php echo $actividad['actividad']; ?></div>
                            <div style="font-size: 11px; color: #666;">Hora: <?php echo $actividad['hora']; ?> • Duración: <?php echo $actividad['duracion']; ?>min</div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <div style="display: flex; gap: 10px;">
                    <button type="button" id="registrar-todas-faltantes" class="button" style="background: #f39c12; border-color: #f39c12; color: white;">
                        <span class="dashicons dashicons-yes" style="margin-top: 4px;"></span>
                        Registrar Todas como Completadas
                    </button>
                    <button type="button" id="ignorar-recordatorios" class="button">
                        <span class="dashicons dashicons-no" style="margin-top: 4px;"></span>
                        Omitir por Hoy
                    </button>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Panel de Métricas y Estadísticas CON DATOS REALES -->
        <div class="ac-metrics-panel" style="margin: 20px 0;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <h2 style="margin: 0; color: #23282d;">📊 Métricas de Cumplimiento</h2>
                <div>
                    <select id="filtro-rango" style="padding: 5px 10px; border-radius: 4px;">
                        <option value="hoy" <?php echo $rango_actual === 'hoy' ? 'selected' : ''; ?>>Hoy</option>
                        <option value="semana" <?php echo $rango_actual === 'semana' ? 'selected' : ''; ?>>Última semana</option>
                        <option value="mes" <?php echo $rango_actual === 'mes' ? 'selected' : ''; ?>>Último mes</option>
                    </select>
                </div>
            </div>
            
            <?php if (!$estadisticas['con_datos']): ?>
                <div style="background: #fff3cd; color: #856404; padding: 20px; border-radius: 8px; text-align: center; margin-bottom: 20px;">
                    <p style="margin: 0;">📝 No hay registros de actividades en el período seleccionado. 
                    <strong>Comienza registrando tus primeras actividades para ver las métricas aquí.</strong></p>
                </div>
            <?php else: ?>
                <div class="ac-stats-container" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; margin-bottom: 20px;">
                    <!-- Métrica Principal -->
                    <div class="ac-stat-card" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <h3 style="margin: 0 0 5px 0; font-size: 14px; opacity: 0.9;">CUMPLIMIENTO <?php echo strtoupper($rango_actual); ?></h3>
                                <p style="font-size: 32px; font-weight: bold; margin: 0;">📊 <?php echo esc_html($estadisticas['porcentaje_completadas']); ?>%</p>
                            </div>
                            <div style="font-size: 24px;">🎯</div>
                        </div>
                        <div style="margin-top: 10px; font-size: 12px; opacity: 0.8;">
                            <?php echo esc_html($estadisticas['completadas']); ?> de <?php echo esc_html($estadisticas['total_actividades']); ?> actividades
                        </div>
                    </div>

                    <!-- Distribución por Estado -->
                    <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #46b450; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                        <h3 style="margin: 0 0 10px 0; color: #46b450; font-size: 14px;">DISTRIBUCIÓN POR ESTADO</h3>
                        <div style="max-height: 120px; overflow-y: auto;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                                <span>✅ Completadas</span>
                                <span style="font-weight: bold;"><?php echo esc_html($estadisticas['completadas']); ?> (<?php echo esc_html($estadisticas['porcentaje_completadas']); ?>%)</span>
                            </div>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                                <span>🔄 En progreso</span>
                                <span style="font-weight: bold;"><?php echo esc_html($estadisticas['en_progreso']); ?> (<?php echo esc_html($estadisticas['porcentaje_en_progreso']); ?>%)</span>
                            </div>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                                <span>⏳ Pendientes</span>
                                <span style="font-weight: bold;"><?php echo esc_html($estadisticas['pendientes']); ?> (<?php echo esc_html($estadisticas['porcentaje_pendientes']); ?>%)</span>
                            </div>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                                <span>❌ Canceladas</span>
                                <span style="font-weight: bold;"><?php echo esc_html($estadisticas['canceladas']); ?> (<?php echo esc_html($estadisticas['porcentaje_canceladas']); ?>%)</span>
                            </div>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                                <span>⚠️ No Cumplidas</span>
                                <span style="font-weight: bold;"><?php echo esc_html($estadisticas['no_cumplidas']); ?> (<?php echo esc_html($estadisticas['porcentaje_no_cumplidas']); ?>%)</span>
                            </div>
                        </div>
                    </div>

                    <!-- Estadísticas de Calidad -->
                    <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #ffb900; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                        <h3 style="margin: 0 0 10px 0; color: #ffb900; font-size: 14px;">CALIDAD Y TIEMPO</h3>
                        <div style="display: grid; gap: 8px;">
                            <div style="display: flex; justify-content: space-between;">
                                <span>Valoración promedio:</span>
                                <strong>
                                    <?php 
                                    $valoracion = $estadisticas['valoracion_promedio'];
                                    if ($valoracion > 0) {
                                        $estrellas_llenas = floor($valoracion);
                                        $media_estrella = $valoracion - $estrellas_llenas >= 0.5;
                                        
                                        echo str_repeat('⭐', $estrellas_llenas);
                                        if ($media_estrella) echo '½';
                                        echo ' (' . number_format($valoracion, 1) . '/5)';
                                    } else {
                                        echo 'Sin datos';
                                    }
                                    ?>
                                </strong>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <span>Duración promedio:</span>
                                <strong>
                                    <?php 
                                    echo $estadisticas['duracion_promedio'] > 0 
                                        ? number_format($estadisticas['duracion_promedio'], 0) . ' min' 
                                        : 'Sin datos'; 
                                    ?>
                                </strong>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <span>Actividades totales:</span>
                                <strong><?php echo esc_html($estadisticas['total_actividades']); ?></strong>
                            </div>
                        </div>
                    </div>

                    <!-- Rango Temporal -->
                    <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #dc3232; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                        <h3 style="margin: 0 0 10px 0; color: #dc3232; font-size: 14px;">PERIODO ANALIZADO</h3>
                        <div style="display: grid; gap: 8px; font-size: 12px;">
                            <div style="display: flex; justify-content: space-between;">
                                <span>Desde:</span>
                                <strong><?php echo date('d/m/Y', strtotime($estadisticas['fecha_inicio'])); ?></strong>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <span>Hasta:</span>
                                <strong><?php echo date('d/m/Y', strtotime($estadisticas['fecha_fin'])); ?></strong>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <span>Rango:</span>
                                <strong><?php echo ucfirst($estadisticas['rango']); ?></strong>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Panel Principal de Estado -->
        <div class="ac-planificador-panel" style="margin: 20px 0;">
            <!-- Header con Información General -->
            <div class="ac-planificador-header" style="background: linear-gradient(135deg, #0073aa, #005a87); color: white; padding: 25px; border-radius: 12px; margin-bottom: 20px;">
                <div style="display: grid; grid-template-columns: auto 1fr auto; gap: 20px; align-items: center;">
                    <div style="font-size: 48px;">🗓️</div>
                    <div>
                        <h2 style="margin: 0 0 5px 0; font-size: 24px;">Plan del Día - <?php echo $dias_semana[$datos_horario['dia_actual']]; ?></h2>
                        <p style="margin: 0; opacity: 0.9; font-size: 16px;"><?php echo date('d/m/Y'); ?></p>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-size: 32px; font-weight: bold;" class="ac-hora-actual">🕐 <?php echo $datos_horario['hora_actual']; ?></div>
                        <div style="font-size: 14px; opacity: 0.8;">Hora actual (Buenos Aires)</div>
                    </div>
                </div>
                
                <!-- Barra de Progreso del Día -->
                <div style="margin-top: 20px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 14px;">
                        <span>Progreso del día</span>
                        <span><?php echo $progreso_dia; ?>%</span>
                    </div>
                    <div style="background: rgba(255,255,255,0.2); height: 8px; border-radius: 4px; overflow: hidden;">
                        <div style="background: white; height: 100%; width: <?php echo $progreso_dia; ?>%; border-radius: 4px; transition: width 0.5s ease;"></div>
                    </div>
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                <!-- Columna Izquierda: Actividad Actual -->
                <div class="ac-actividad-actual" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
                    <h3 style="margin-top: 0; color: #667eea; border-bottom: 2px solid #667eea; padding-bottom: 10px;">
                        <span class="dashicons dashicons-clock" style="margin-right: 8px;"></span>
                        Estado Actual
                    </h3>
                    
                    <?php if ($actividad_actual): ?>
                        <div style="text-align: center; padding: 20px 0;">
                            <div style="font-size: 64px; margin-bottom: 15px;"><?php echo $actividad_actual['detalles']['icono']; ?></div>
                            <h4 style="margin: 0 0 10px 0; font-size: 20px; color: #333;"><?php echo $actividad_actual['detalles']['actividad']; ?></h4>
                            <div style="display: inline-block; background: #667eea; color: white; padding: 8px 16px; border-radius: 20px; font-size: 14px; font-weight: bold;">
                                🕐 <?php echo $actividad_actual['hora']; ?>
                            </div>
                        </div>
                        
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-top: 15px;">
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 13px;">
                                <div>
                                    <strong>Tipo:</strong><br>
                                    <span style="color: #666;"><?php echo ucfirst(str_replace('_', ' ', $actividad_actual['detalles']['tipo'])); ?></span>
                                </div>
                                <div>
                                    <strong>Duración:</strong><br>
                                    <span style="color: #666;"><?php echo $actividad_actual['detalles']['duracion']; ?> minutos</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Formulario de Registro -->
                        <div style="margin-top: 20px; padding: 20px; background: #f8f9fa; border-radius: 8px;">
                            <h4 style="margin-top: 0; color: #495057;">📝 Registrar esta actividad</h4>
                            <form method="post" id="form-registro-actual">
                                <?php wp_nonce_field('guardar_registro_diario'); ?>
                                <input type="hidden" name="guardar_registro_diario" value="1">
                                <input type="hidden" name="fecha" value="<?php echo date('Y-m-d'); ?>">
                                <input type="hidden" name="actividad_id" value="<?php echo $actividad_actual['hora'] . '_' . sanitize_title($actividad_actual['detalles']['actividad']); ?>">
                                <input type="hidden" name="actividad_nombre" value="<?php echo esc_attr($actividad_actual['detalles']['actividad']); ?>">
                                <input type="hidden" name="tipo_actividad" value="<?php echo esc_attr($actividad_actual['detalles']['tipo']); ?>">
                                
                                <table class="form-table">
                                    <tr>
                                        <th scope="row"><label for="estado">Estado</label></th>
                                        <td>
                                            <select name="estado" id="estado" class="regular-text" required>
                                                <option value="completada">✅ Completada</option>
                                                <option value="en_progreso" selected>🔄 En progreso</option>
                                                <option value="pendiente">⏳ Pendiente</option>
                                                <option value="cancelada">❌ Cancelada</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><label for="duracion_real">Duración real (min)</label></th>
                                        <td>
                                            <input type="number" name="duracion_real" id="duracion_real" class="small-text" value="<?php echo $actividad_actual['detalles']['duracion']; ?>" min="1" max="480">
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><label for="valoracion">Valoración</label></th>
                                        <td>
                                            <select name="valoracion" id="valoracion" class="regular-text" required>
                                                <option value="5">⭐⭐⭐⭐⭐ Excelente</option>
                                                <option value="4">⭐⭐⭐⭐ Muy buena</option>
                                                <option value="3" selected>⭐⭐⭐ Buena</option>
                                                <option value="2">⭐⭐ Regular</option>
                                                <option value="1">⭐ Mala</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><label for="observaciones">Observaciones</label></th>
                                        <td>
                                            <textarea name="observaciones" id="observaciones" rows="3" class="large-text" placeholder="Notas, comentarios, dificultades..."></textarea>
                                        </td>
                                    </tr>
                                </table>
                                
                                <p class="submit">
                                    <button type="submit" class="button button-primary">
                                        <span class="dashicons dashicons-yes" style="margin-top: 4px;"></span>
                                        Guardar Registro
                                    </button>
                                </p>
                            </form>
                        </div>
                    <?php else: ?>
                        <div style="text-align: center; padding: 40px 20px; color: #666;">
                            <div style="font-size: 64px; margin-bottom: 15px;">🌙</div>
                            <h4 style="margin: 0 0 10px 0; color: #333;">Fuera del horario activo</h4>
                            <p>El horario activo es de 8:00 a 23:00 horas.</p>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Columna Derecha: Próximas Actividades -->
                <div class="ac-proximas-actividades" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
                    <h3 style="margin-top: 0; color: #764ba2; border-bottom: 2px solid #764ba2; padding-bottom: 10px;">
                        <span class="dashicons dashicons-arrow-right" style="margin-right: 8px;"></span>
                        Próximas Actividades
                    </h3>
                    
                    <?php if (!empty($proximas_actividades)): ?>
                        <div style="display: flex; flex-direction: column; gap: 15px;">
                            <?php foreach ($proximas_actividades as $index => $proxima): ?>
                                <div class="ac-proxima-actividad" 
                                     data-timestamp="<?php echo $proxima['timestamp']; ?>"
                                     style="display: grid; grid-template-columns: auto 1fr auto; gap: 15px; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #764ba2; transition: all 0.3s ease;">
                                    <div style="font-size: 24px;"><?php echo $proxima['detalles']['icono']; ?></div>
                                    <div>
                                        <div style="font-weight: bold; margin-bottom: 4px;"><?php echo $proxima['detalles']['actividad']; ?></div>
                                        <div style="font-size: 12px; color: #666;">
                                            <?php echo ucfirst(str_replace('_', ' ', $proxima['detalles']['tipo'])); ?> • 
                                            <?php echo $proxima['detalles']['duracion']; ?> min
                                        </div>
                                    </div>
                                    <div style="text-align: right;">
                                        <div style="font-weight: bold; color: #764ba2;"><?php echo $proxima['hora']; ?></div>
                                        <div class="ac-contador" style="font-size: 11px; color: #666; font-weight: bold;">
                                            en <?php echo $proxima['minutos_restantes']; ?> min
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <!-- Contador General -->
                        <div style="margin-top: 20px; padding: 15px; background: linear-gradient(135deg, #764ba2, #667eea); color: white; border-radius: 8px; text-align: center;">
                            <div style="font-size: 14px; margin-bottom: 5px;">Próxima actividad en:</div>
                            <div id="contador-general" style="font-size: 24px; font-weight: bold;">
                                <?php echo $proximas_actividades[0]['minutos_restantes']; ?> minutos
                            </div>
                        </div>
                    <?php else: ?>
                        <div style="text-align: center; padding: 40px 20px; color: #666;">
                            <div style="font-size: 48px; margin-bottom: 15px;">🌜</div>
                            <p>No hay más actividades programadas para hoy.</p>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Botón de registro rápido -->
                    <div style="margin-top: 20px; padding: 15px; background: #e8f5e8; border-radius: 8px; border-left: 4px solid #46b450;">
                        <h4 style="margin-top: 0; color: #2e7d32;">⚡ Registro Rápido</h4>
                        <p style="margin: 10px 0; font-size: 13px;">¿Quieres registrar una actividad no programada?</p>
                        <button type="button" id="registro-rapido" class="button" style="background: #46b450; color: white; border-color: #46b450;">
                            <span class="dashicons dashicons-plus" style="margin-top: 4px;"></span>
                            Nueva Actividad
                        </button>
                    </div>

                    <!-- Botón de No Cumplimiento -->
                    <div style="margin-top: 15px; padding: 15px; background: #ffeaea; border-radius: 8px; border-left: 4px solid #dc3232;">
                        <h4 style="margin-top: 0; color: #dc3232;">⚠️ No Cumplimiento</h4>
                        <p style="margin: 10px 0; font-size: 13px;">¿No se pudo realizar alguna actividad programada?</p>
                        <button type="button" id="btn-no-cumplio" class="button" style="background: #dc3232; color: white; border-color: #dc3232;">
                            <span class="dashicons dashicons-warning" style="margin-top: 4px;"></span>
                            Registrar No Cumplimiento
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Horario Completo del Día -->
            <div class="ac-horario-completo" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
                <h3 style="margin-top: 0; color: #495057; border-bottom: 2px solid #495057; padding-bottom: 10px;">
                    <span class="dashicons dashicons-list-view" style="margin-right: 8px;"></span>
                    Horario Completo del Día
                </h3>
                
                <div class="ac-linea-tiempo" style="position: relative;">
                    <?php
                    $actividades = $datos_horario['actividades'];
                    $hora_actual = $datos_horario['hora_actual'];
                    
                    // Colores por tipo de actividad
                    $colores_tipo = [
                        'rutina' => '#667eea',
                        'alimentacion' => '#f093fb',
                        'desarrollo_personal' => '#4facfe',
                        'planificacion' => '#43e97b',
                        'organizacion' => '#fa709a',
                        'terapia_grupal' => '#a8edea',
                        'descanso' => '#ffecd2',
                        'terapia_escrita' => '#84fab0',
                        'salud' => '#ff9a9e'
                    ];
                    
                    foreach ($actividades as $hora => $detalles):
                        $hora_inicio_ts = strtotime($hora);
                        $hora_fin_ts = strtotime($hora . ' + ' . $detalles['duracion'] . ' minutes');
                        $hora_actual_ts = strtotime($hora_actual);
                        
                        $es_actual = ($hora_actual_ts >= $hora_inicio_ts && $hora_actual_ts < $hora_fin_ts);
                        $es_pasado = ($hora_fin_ts <= $hora_actual_ts);
                        $es_futuro = ($hora_inicio_ts > $hora_actual_ts);
                    ?>
                    <div class="ac-item-tiempo" style="display: grid; grid-template-columns: 80px 1fr; gap: 20px; padding: 15px 0; position: relative; align-items: start;">
                        <!-- Línea vertical y hora -->
                        <div style="position: relative;">
                            <div style="font-weight: bold; color: <?php echo $es_pasado ? '#999' : ($es_actual ? '#667eea' : '#333'); ?>;">
                                <?php echo $hora; ?>
                            </div>
                            <?php if (!$es_pasado): ?>
                                <div style="position: absolute; left: 35px; top: 0; bottom: 0; width: 2px; background: #667eea; opacity: 0.3;"></div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Tarjeta de actividad -->
                        <div class="ac-tarjeta-actividad" 
                             style="background: <?php echo $es_pasado ? '#f8f9fa' : ($es_actual ? $colores_tipo[$detalles['tipo']] . '20' : '#ffffff'); ?>; 
                                    border: 2px solid <?php echo $es_actual ? $colores_tipo[$detalles['tipo']] : 'transparent'; ?>;
                                    padding: 15px; 
                                    border-radius: 8px; 
                                    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
                                    position: relative;">
                            
                            <?php if ($es_actual): ?>
                                <div style="position: absolute; top: -8px; right: -8px; background: #667eea; color: white; padding: 4px 8px; border-radius: 12px; font-size: 10px; font-weight: bold;">
                                    AHORA
                                </div>
                            <?php endif; ?>
                            
                            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 8px;">
                                <div style="font-size: 24px;"><?php echo $detalles['icono']; ?></div>
                                <div style="flex: 1;">
                                    <div style="font-weight: bold; color: <?php echo $es_pasado ? '#999' : '#333'; ?>;">
                                        <?php echo $detalles['actividad']; ?>
                                    </div>
                                    <div style="display: flex; gap: 15px; font-size: 12px; color: #666; margin-top: 4px;">
                                        <span>⏱️ <?php echo $detalles['duracion']; ?> min</span>
                                        <span>🏷️ <?php echo ucfirst(str_replace('_', ' ', $detalles['tipo'])); ?></span>
                                    </div>
                                </div>
                                <div>
                                    <button type="button" class="button ac-registrar-btn" data-actividad='<?php echo json_encode($detalles); ?>' data-hora="<?php echo $hora; ?>" style="font-size: 11px; padding: 4px 8px;">
                                        <span class="dashicons dashicons-edit" style="font-size: 12px; margin-top: 2px;"></span>
                                        Registrar
                                    </button>
                                </div>
                            </div>
                            
                            <?php if ($es_actual): ?>
                                <div style="background: rgba(255,255,255,0.7); padding: 8px; border-radius: 4px; font-size: 12px; text-align: center;">
                                    <strong>En progreso</strong> • Termina a las <?php echo date('H:i', $hora_fin_ts); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Acciones Finales -->
                <div style="margin-top: 30px; padding: 20px; background: linear-gradient(135deg, #f093fb, #f5576c); color: white; border-radius: 8px; text-align: center;">
                    <h3 style="margin-top: 0; color: white;">📊 Resumen del Día</h3>
                    <p>Genera un reporte completo de todas las actividades realizadas hoy.</p>
                    <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador&export=resumen_diario'); ?>" class="button button-primary" style="background: white; color: #f5576c; border-color: white; font-weight: bold;">
                        <span class="dashicons dashicons-pdf" style="margin-top: 4px;"></span>
                        Generar Resumen Diario PDF
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal para Registro Rápido -->
    <div id="modal-registro-rapido" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; align-items: center; justify-content: center;">
        <div style="background: white; padding: 30px; border-radius: 12px; width: 90%; max-width: 500px; max-height: 90vh; overflow-y: auto;">
            <h3 style="margin-top: 0; color: #0073aa;">➕ Registrar Actividad Personalizada</h3>
            
            <form method="post" id="form-registro-rapido">
                <?php wp_nonce_field('guardar_registro_diario'); ?>
                <input type="hidden" name="guardar_registro_diario" value="1">
                <input type="hidden" name="fecha" value="<?php echo date('Y-m-d'); ?>">
                <input type="hidden" name="tipo_actividad" value="personalizada">
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="actividad_personalizada">Actividad *</label></th>
                        <td>
                            <input type="text" name="actividad_nombre" id="actividad_personalizada" class="regular-text" placeholder="Describe la actividad..." required>
                            <input type="hidden" name="actividad_id" value="personalizada_<?php echo time(); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="estado_personalizado">Estado</label></th>
                        <td>
                            <select name="estado" id="estado_personalizado" class="regular-text" required>
                                <option value="completada">✅ Completada</option>
                                <option value="en_progreso">🔄 En progreso</option>
                                <option value="pendiente">⏳ Pendiente</option>
                                <option value="cancelada">❌ Cancelada</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="duracion_personalizada">Duración real (min)</label></th>
                        <td>
                            <input type="number" name="duracion_real" id="duracion_personalizada" class="small-text" value="30" min="1" max="480">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="valoracion_personalizada">Valoración</label></th>
                        <td>
                            <select name="valoracion" id="valoracion_personalizada" class="regular-text" required>
                                <option value="5">⭐⭐⭐⭐⭐ Excelente</option>
                                <option value="4">⭐⭐⭐⭐ Muy buena</option>
                                <option value="3" selected>⭐⭐⭐ Buena</option>
                                <option value="2">⭐⭐ Regular</option>
                                <option value="1">⭐ Mala</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="observaciones_personalizadas">Observaciones</label></th>
                        <td>
                            <textarea name="observaciones" id="observaciones_personalizadas" rows="3" class="large-text" placeholder="Notas, comentarios, dificultades..."></textarea>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary">
                        <span class="dashicons dashicons-yes" style="margin-top: 4px;"></span>
                        Guardar Registro
                    </button>
                    <button type="button" id="cancelar-registro" class="button" style="margin-left: 10px;">
                        <span class="dashicons dashicons-no" style="margin-top: 4px;"></span>
                        Cancelar
                    </button>
                </p>
            </form>
        </div>
    </div>

    <!-- Modal para No Cumplimiento -->
    <div id="modal-no-cumplio" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; align-items: center; justify-content: center;">
        <div style="background: white; padding: 30px; border-radius: 12px; width: 90%; max-width: 500px; max-height: 90vh; overflow-y: auto;">
            <h3 style="margin-top: 0; color: #dc3232;">⚠️ Registrar No Cumplimiento</h3>
            
            <form method="post" id="form-no-cumplio">
                <?php wp_nonce_field('guardar_registro_diario'); ?>
                <input type="hidden" name="guardar_registro_diario" value="1">
                <input type="hidden" name="fecha" value="<?php echo date('Y-m-d'); ?>">
                <input type="hidden" name="estado" value="no_cumplida">
                <input type="hidden" name="tipo_actividad" value="no_cumplida">
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="actividad_no_cumplida">Actividad No Cumplida *</label></th>
                        <td>
                            <input type="text" name="actividad_nombre" id="actividad_no_cumplida" class="regular-text" required placeholder="¿Qué actividad no se cumplió?">
                            <input type="hidden" name="actividad_id" value="no_cumplida_<?php echo time(); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="razon_no_cumplio">Razón del No Cumplimiento</label></th>
                        <td>
                            <select name="razon_no_cumplio" id="razon_no_cumplio" class="regular-text">
                                <option value="">-- Seleccionar --</option>
                                <option value="imprevisto">Imprevisto</option>
                                <option value="salud">Problema de salud</option>
                                <option value="clima">Condiciones climáticas</option>
                                <option value="personal">Razón personal</option>
                                <option value="otro">Otro</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="observaciones_no_cumplio">Observaciones</label></th>
                        <td>
                            <textarea name="observaciones" id="observaciones_no_cumplio" rows="4" class="large-text" placeholder="Explicar por qué no se cumplió la actividad..." required></textarea>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary" style="background: #dc3232; border-color: #dc3232;">
                        <span class="dashicons dashicons-warning" style="margin-top: 4px;"></span>
                        Registrar No Cumplimiento
                    </button>
                    <button type="button" id="cancelar-no-cumplio" class="button" style="margin-left: 10px;">
                        Cancelar
                    </button>
                </p>
            </form>
        </div>
    </div>

    <!-- Modal para Registro Masivo -->
    <div id="modal-registro-masivo" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; align-items: center; justify-content: center;">
        <div style="background: white; padding: 30px; border-radius: 12px; width: 90%; max-width: 500px; max-height: 90vh; overflow-y: auto;">
            <h3 style="margin-top: 0; color: #0073aa;">📝 Registrar Actividades Faltantes</h3>
            
            <div id="lista-actividades-faltantes" style="max-height: 300px; overflow-y: auto; margin: 15px 0; padding: 10px; background: #f8f9fa; border-radius: 4px;">
                <!-- Las actividades se cargarán aquí via JavaScript -->
            </div>
            
            <p style="color: #666; font-size: 14px;">
                Se crearán registros automáticos para todas las actividades listadas arriba con estado "Completada" y valoración neutral.
            </p>
            
            <p class="submit">
                <button type="button" id="confirmar-registro-masivo" class="button button-primary">
                    <span class="dashicons dashicons-yes" style="margin-top: 4px;"></span>
                    Confirmar Registro
                </button>
                <button type="button" id="cancelar-registro-masivo" class="button" style="margin-left: 10px;">
                    <span class="dashicons dashicons-no" style="margin-top: 4px;"></span>
                    Cancelar
                </button>
            </p>
        </div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        // Filtro de rango para métricas
        $('#filtro-rango').on('change', function() {
            var rango = $(this).val();
            window.location.href = '<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador'); ?>&rango=' + rango;
        });

        // Estado actual en tiempo real
        function actualizarEstadoTiempoReal() {
            const ahora = new Date();
            const horas = ahora.getHours().toString().padStart(2, '0');
            const minutos = ahora.getMinutes().toString().padStart(2, '0');
            const segundos = ahora.getSeconds().toString().padStart(2, '0');
            
            // Actualizar hora actual
            $('.ac-hora-actual').text('🕐 ' + horas + ':' + minutos + ':' + segundos);
            
            // Actualizar contadores de próximas actividades
            $('.ac-proxima-actividad').each(function() {
                const $elemento = $(this);
                const timestamp = $elemento.data('timestamp');
                const ahoraTimestamp = Math.floor(Date.now() / 1000);
                const diferencia = timestamp - ahoraTimestamp;
                const minutosRestantes = Math.floor(diferencia / 60);
                
                if (minutosRestantes > 0) {
                    // Actualizar texto del contador
                    $elemento.find('.ac-contador').text('en ' + minutosRestantes + ' min');
                    
                    // Aplicar efectos visuales según la proximidad
                    $elemento.removeClass('actividad-proxima actividad-muy-proxima');
                    $elemento.find('.ac-contador').removeClass('contador-urgente');
                    
                    if (minutosRestantes <= 5) {
                        $elemento.addClass('actividad-muy-proxima');
                        $elemento.find('.ac-contador').addClass('contador-urgente');
                    } else if (minutosRestantes <= 15) {
                        $elemento.addClass('actividad-proxima');
                    }
                } else {
                    $elemento.find('.ac-contador').text('¡Ahora!');
                    $elemento.addClass('actividad-muy-proxima');
                    $elemento.find('.ac-contador').addClass('contador-urgente');
                }
            });
            
            // Actualizar contador general
            const $primerElemento = $('.ac-proxima-actividad').first();
            if ($primerElemento.length) {
                const timestamp = $primerElemento.data('timestamp');
                const ahoraTimestamp = Math.floor(Date.now() / 1000);
                const diferencia = timestamp - ahoraTimestamp;
                const minutosRestantes = Math.floor(diferencia / 60);
                
                if (minutosRestantes > 0) {
                    $('#contador-general').text(minutosRestantes + ' minutos');
                } else {
                    $('#contador-general').html('<span style="color: #ffeb3b;">¡AHORA!</span>');
                }
            }
        }
        
        // Actualizar cada segundo para tiempo real
        setInterval(actualizarEstadoTiempoReal, 1000);
        actualizarEstadoTiempoReal(); // Ejecutar inmediatamente
        
        // Modal para registro rápido
        $('#registro-rapido').on('click', function() {
            $('#modal-registro-rapido').fadeIn();
        });
        
        $('#cancelar-registro').on('click', function() {
            $('#modal-registro-rapido').fadeOut();
        });
        
        // Modal No Cumplimiento
        $('#btn-no-cumplio').on('click', function() {
            $('#modal-no-cumplio').fadeIn();
        });
        
        $('#cancelar-no-cumplio').on('click', function() {
            $('#modal-no-cumplio').fadeOut();
        });
        
        // Registro automático de actividades faltantes
        $('#registrar-automatico, #registrar-todas-faltantes').on('click', function() {
            $('#modal-registro-masivo').fadeIn();
            
            // Cargar lista de actividades faltantes
            var actividades = <?php echo json_encode($actividades_faltantes); ?>;
            var listaHtml = '';
            
            actividades.forEach(function(actividad, index) {
                listaHtml += '<div style="display: flex; align-items: center; gap: 10px; padding: 8px; border-bottom: 1px solid #ddd; background: white; margin-bottom: 5px; border-radius: 4px;">';
                listaHtml += '<div style="font-size: 20px;">' + actividad.icono + '</div>';
                listaHtml += '<div style="flex: 1;">';
                listaHtml += '<strong>' + actividad.actividad + '</strong>';
                listaHtml += '<div style="font-size: 12px; color: #666;">Hora: ' + actividad.hora + ' • Duración: ' + actividad.duracion + 'min</div>';
                listaHtml += '</div>';
                listaHtml += '</div>';
            });
            
            $('#lista-actividades-faltantes').html(listaHtml);
        });
        
        $('#cancelar-registro-masivo, #ignorar-recordatorios').on('click', function() {
            $('#modal-registro-masivo').fadeOut();
        });
        
        $('#confirmar-registro-masivo').on('click', function() {
            var $boton = $(this);
            $boton.prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation: spin 1s linear infinite; margin-top: 4px;"></span> Registrando...');
            
            // Enviar petición AJAX para registrar todas las actividades
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'ac_registro_masivo_faltantes',
                    actividades: <?php echo json_encode($actividades_faltantes); ?>,
                    _wpnonce: '<?php echo wp_create_nonce('ac_registro_masivo_faltantes'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        alert('✅ ' + response.data.message);
                        location.reload();
                    } else {
                        alert('❌ ' + response.data.message);
                        $boton.prop('disabled', false).html('<span class="dashicons dashicons-yes" style="margin-top: 4px;"></span> Confirmar Registro');
                    }
                },
                error: function(xhr, status, error) {
                    console.log(xhr.responseText);
                    alert('❌ Error al registrar las actividades: ' + xhr.responseText);
                    $boton.prop('disabled', false).html('<span class="dashicons dashicons-yes" style="margin-top: 4px;"></span> Confirmar Registro');
                }
            });
        });
        
        // Botones de registro en actividades
        $('.ac-registrar-btn').on('click', function() {
            const actividad = $(this).data('actividad');
            const hora = $(this).data('hora');
            
            $('#actividad_personalizada').val(actividad.actividad);
            $('#modal-registro-rapido').fadeIn();
        });
        
        // Cerrar modales al hacer click fuera
        $('#modal-registro-rapido, #modal-no-cumplio, #modal-registro-masivo').on('click', function(e) {
            if (e.target === this) {
                $(this).fadeOut();
            }
        });
    });
    </script>
    
    <style>
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    .actividad-proxima {
        background: #fff3cd !important;
        border-left-color: #ffc107 !important;
    }
    
    .actividad-muy-proxima {
        background: #f8d7da !important;
        border-left-color: #dc3545 !important;
        animation: pulse 1s infinite;
    }
    
    .contador-urgente {
        color: #dc3545 !important;
        font-weight: bold;
    }
    
    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.7; }
        100% { opacity: 1; }
    }
    </style>
    <?php
    echo ob_get_clean();
}

// =============================================
// LISTA DE ACTIVIDADES GUARDADAS - CRUD COMPLETO
// =============================================

function ac_mostrar_lista_actividades() {
    $pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;
    $por_pagina = 20;
    $offset = ($pagina_actual - 1) * $por_pagina;
    
    // Filtros
    $filtros = [
        'fecha_desde' => isset($_GET['fecha_desde']) ? sanitize_text_field($_GET['fecha_desde']) : '',
        'fecha_hasta' => isset($_GET['fecha_hasta']) ? sanitize_text_field($_GET['fecha_hasta']) : '',
        'estado' => isset($_GET['estado']) ? sanitize_text_field($_GET['estado']) : '',
        'tipo_actividad' => isset($_GET['tipo_actividad']) ? sanitize_text_field($_GET['tipo_actividad']) : '',
        'actividad_nombre' => isset($_GET['actividad_nombre']) ? sanitize_text_field($_GET['actividad_nombre']) : ''
    ];
    
    // Obtener actividades
    $actividades = ac_obtener_todas_actividades($por_pagina, $offset, $filtros);
    $total_actividades = ac_contar_actividades($filtros);
    $total_paginas = ceil($total_actividades / $por_pagina);
    
    // Tipos de actividad únicos para el filtro
    global $wpdb;
    $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
    $tipos_actividad = $wpdb->get_col("SELECT DISTINCT tipo_actividad FROM $tabla_registros WHERE tipo_actividad IS NOT NULL AND tipo_actividad != ''");
    
    ob_start();
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline">📊 Actividades Guardadas</h1>
        
        <div class="ac-actividades-header" style="display: flex; justify-content: space-between; align-items: center; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px;">
            <div>
                <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador'); ?>" class="button">
                    <span class="dashicons dashicons-arrow-left" style="margin-top: 4px;"></span>
                    Volver al Planificador
                </a>
                <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador&export=actividades_completas'); ?>" class="button" style="margin-left: 10px;">
                    <span class="dashicons dashicons-media-spreadsheet" style="margin-top: 4px;"></span>
                    Exportar CSV
                </a>
            </div>
            
            <div class="ac-search-export" style="display: flex; gap: 10px; align-items: center;">
                <span class="description" style="color: #666; font-size: 13px;">
                    Total: <?php echo $total_actividades; ?> actividades
                </span>
            </div>
        </div>

        <!-- Filtros -->
        <div class="ac-filtros-actividades" style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-bottom: 20px;">
            <h3 style="margin-top: 0;">🔍 Filtros de Búsqueda</h3>
            <form method="get">
                <input type="hidden" name="page" value="ac-sistema-integral">
                <input type="hidden" name="modo" value="planificador">
                <input type="hidden" name="submodo" value="actividades">
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 15px;">
                    <div>
                        <label for="fecha_desde" style="display: block; margin-bottom: 5px; font-weight: bold;">Fecha desde:</label>
                        <input type="date" name="fecha_desde" id="fecha_desde" value="<?php echo esc_attr($filtros['fecha_desde']); ?>" class="regular-text">
                    </div>
                    
                    <div>
                        <label for="fecha_hasta" style="display: block; margin-bottom: 5px; font-weight: bold;">Fecha hasta:</label>
                        <input type="date" name="fecha_hasta" id="fecha_hasta" value="<?php echo esc_attr($filtros['fecha_hasta']); ?>" class="regular-text">
                    </div>
                    
                    <div>
                        <label for="estado" style="display: block; margin-bottom: 5px; font-weight: bold;">Estado:</label>
                        <select name="estado" id="estado" class="regular-text">
                            <option value="">Todos los estados</option>
                            <option value="completada" <?php echo $filtros['estado'] === 'completada' ? 'selected' : ''; ?>>Completada</option>
                            <option value="en_progreso" <?php echo $filtros['estado'] === 'en_progreso' ? 'selected' : ''; ?>>En progreso</option>
                            <option value="pendiente" <?php echo $filtros['estado'] === 'pendiente' ? 'selected' : ''; ?>>Pendiente</option>
                            <option value="cancelada" <?php echo $filtros['estado'] === 'cancelada' ? 'selected' : ''; ?>>Cancelada</option>
                            <option value="no_cumplida" <?php echo $filtros['estado'] === 'no_cumplida' ? 'selected' : ''; ?>>No cumplida</option>
                        </select>
                    </div>
                    
                    <div>
                        <label for="tipo_actividad" style="display: block; margin-bottom: 5px; font-weight: bold;">Tipo:</label>
                        <select name="tipo_actividad" id="tipo_actividad" class="regular-text">
                            <option value="">Todos los tipos</option>
                            <?php foreach ($tipos_actividad as $tipo): ?>
                                <option value="<?php echo esc_attr($tipo); ?>" <?php echo $filtros['tipo_actividad'] === $tipo ? 'selected' : ''; ?>>
                                    <?php echo ucfirst(str_replace('_', ' ', $tipo)); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label for="actividad_nombre" style="display: block; margin-bottom: 5px; font-weight: bold;">Buscar actividad:</label>
                    <input type="text" name="actividad_nombre" id="actividad_nombre" value="<?php echo esc_attr($filtros['actividad_nombre']); ?>" class="regular-text" placeholder="Nombre de la actividad...">
                </div>
                
                <div>
                    <button type="submit" class="button button-primary">
                        <span class="dashicons dashicons-search" style="margin-top: 4px;"></span>
                        Aplicar Filtros
                    </button>
                    <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador&submodo=actividades'); ?>" class="button" style="margin-left: 10px;">
                        Limpiar Filtros
                    </a>
                </div>
            </form>
        </div>

        <!-- Lista de Actividades -->
        <div class="ac-lista-actividades" style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h2 style="margin-top: 0; border-bottom: 2px solid #0073aa; padding-bottom: 10px;">
                Lista de Actividades Registradas
            </h2>
            
            <?php if (!empty($actividades)): ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Actividad</th>
                            <th>Estado</th>
                            <th>Duración</th>
                            <th>Valoración</th>
                            <th>Tipo</th>
                            <th>Observaciones</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($actividades as $actividad): ?>
                        <tr>
                            <td>
                                <strong><?php echo date('d/m/Y', strtotime($actividad['fecha'])); ?></strong>
                            </td>
                            <td>
                                <?php echo esc_html($actividad['actividad_nombre']); ?>
                            </td>
                            <td>
                                <?php
                                $estados = [
                                    'completada' => '✅ Completada',
                                    'en_progreso' => '🔄 En progreso',
                                    'pendiente' => '⏳ Pendiente',
                                    'cancelada' => '❌ Cancelada',
                                    'no_cumplida' => '⚠️ No cumplida'
                                ];
                                echo $estados[$actividad['estado']] ?? $actividad['estado'];
                                ?>
                            </td>
                            <td>
                                <?php echo $actividad['duracion_real'] ? $actividad['duracion_real'] . ' min' : 'N/A'; ?>
                            </td>
                            <td>
                                <?php
                                if ($actividad['valoracion'] > 0) {
                                    echo str_repeat('⭐', $actividad['valoracion']);
                                } else {
                                    echo 'N/A';
                                }
                                ?>
                            </td>
                            <td>
                                <?php 
                                echo $actividad['tipo_actividad'] 
                                    ? ucfirst(str_replace('_', ' ', $actividad['tipo_actividad']))
                                    : 'No especificado';
                                ?>
                            </td>
                            <td>
                                <?php echo esc_html($actividad['observaciones'] ?: '—'); ?>
                            </td>
                            <td>
                                <div style="display: flex; gap: 5px;">
                                    <button type="button" class="button button-small editar-actividad" 
                                            data-id="<?php echo $actividad['id']; ?>"
                                            data-actividad='<?php echo json_encode($actividad); ?>'
                                            title="Editar">
                                        <span class="dashicons dashicons-edit" style="font-size: 16px;"></span>
                                    </button>
                                    <form method="post" style="display: inline;">
                                        <?php wp_nonce_field('eliminar_actividad_' . $actividad['id']); ?>
                                        <input type="hidden" name="eliminar_actividad" value="1">
                                        <input type="hidden" name="actividad_id" value="<?php echo $actividad['id']; ?>">
                                        <button type="submit" class="button button-small" title="Eliminar" onclick="return confirm('¿Está seguro de que desea eliminar esta actividad?');">
                                            <span class="dashicons dashicons-trash" style="font-size: 16px;"></span>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <!-- Paginación -->
                <?php if ($total_paginas > 1): ?>
                <div class="ac-paginacion" style="margin-top: 20px; text-align: center;">
                    <?php
                    $base_url = admin_url('admin.php?page=ac-sistema-integral&modo=planificador&submodo=actividades');
                    $base_url .= '&fecha_desde=' . urlencode($filtros['fecha_desde']);
                    $base_url .= '&fecha_hasta=' . urlencode($filtros['fecha_hasta']);
                    $base_url .= '&estado=' . urlencode($filtros['estado']);
                    $base_url .= '&tipo_actividad=' . urlencode($filtros['tipo_actividad']);
                    $base_url .= '&actividad_nombre=' . urlencode($filtros['actividad_nombre']);
                    $base_url .= '&pagina=';
                    
                    if ($pagina_actual > 1) {
                        echo '<a href="' . $base_url . ($pagina_actual - 1) . '" class="button">« Anterior</a> ';
                    }
                    
                    for ($i = 1; $i <= $total_paginas; $i++) {
                        if ($i == $pagina_actual) {
                            echo '<span class="button button-primary" style="margin: 0 5px;">' . $i . '</span> ';
                        } else {
                            echo '<a href="' . $base_url . $i . '" class="button" style="margin: 0 5px;">' . $i . '</a> ';
                        }
                    }
                    
                    if ($pagina_actual < $total_paginas) {
                        echo '<a href="' . $base_url . ($pagina_actual + 1) . '" class="button">Siguiente »</a>';
                    }
                    ?>
                </div>
                <?php endif; ?>
            <?php else: ?>
                <div style="text-align: center; padding: 40px 20px; color: #666;">
                    <div style="font-size: 64px; margin-bottom: 15px;">📝</div>
                    <h3 style="color: #333;">No hay actividades registradas</h3>
                    <p>No se encontraron actividades con los filtros aplicados.</p>
                    <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador'); ?>" class="button button-primary">
                        Ir al Planificador
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal para Editar Actividad -->
    <div id="modal-editar-actividad" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; align-items: center; justify-content: center;">
        <div style="background: white; padding: 30px; border-radius: 12px; width: 90%; max-width: 600px; max-height: 90vh; overflow-y: auto;">
            <h3 style="margin-top: 0; color: #0073aa;">✏️ Editar Actividad</h3>
            
            <form method="post" id="form-editar-actividad">
                <?php wp_nonce_field('actualizar_actividad'); ?>
                <input type="hidden" name="actualizar_actividad" value="1">
                <input type="hidden" name="actividad_id" id="editar_actividad_id" value="">
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="editar_fecha">Fecha</label></th>
                        <td>
                            <input type="date" name="fecha" id="editar_fecha" class="regular-text" readonly>
                            <p class="description">La fecha no se puede modificar</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="editar_actividad_nombre">Actividad</label></th>
                        <td>
                            <input type="text" name="actividad_nombre" id="editar_actividad_nombre" class="regular-text" readonly>
                            <p class="description">El nombre de la actividad no se puede modificar</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="editar_estado">Estado *</label></th>
                        <td>
                            <select name="estado" id="editar_estado" class="regular-text" required>
                                <option value="completada">✅ Completada</option>
                                <option value="en_progreso">🔄 En progreso</option>
                                <option value="pendiente">⏳ Pendiente</option>
                                <option value="cancelada">❌ Cancelada</option>
                                <option value="no_cumplida">⚠️ No cumplida</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="editar_duracion_real">Duración real (min)</label></th>
                        <td>
                            <input type="number" name="duracion_real" id="editar_duracion_real" class="small-text" min="1" max="480">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="editar_valoracion">Valoración</label></th>
                        <td>
                            <select name="valoracion" id="editar_valoracion" class="regular-text" required>
                                <option value="5">⭐⭐⭐⭐⭐ Excelente</option>
                                <option value="4">⭐⭐⭐⭐ Muy buena</option>
                                <option value="3">⭐⭐⭐ Buena</option>
                                <option value="2">⭐⭐ Regular</option>
                                <option value="1">⭐ Mala</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="editar_tipo_actividad">Tipo de Actividad</label></th>
                        <td>
                            <select name="tipo_actividad" id="editar_tipo_actividad" class="regular-text">
                                <option value="">-- Seleccionar --</option>
                                <option value="rutina">Rutina</option>
                                <option value="alimentacion">Alimentación</option>
                                <option value="desarrollo_personal">Desarrollo Personal</option>
                                <option value="planificacion">Planificación</option>
                                <option value="organizacion">Organización</option>
                                <option value="terapia_grupal">Terapia Grupal</option>
                                <option value="descanso">Descanso</option>
                                <option value="terapia_escrita">Terapia Escrita</option>
                                <option value="salud">Salud</option>
                                <option value="personalizada">Personalizada</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="editar_observaciones">Observaciones</label></th>
                        <td>
                            <textarea name="observaciones" id="editar_observaciones" rows="4" class="large-text" placeholder="Notas, comentarios, dificultades..."></textarea>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary">
                        <span class="dashicons dashicons-yes" style="margin-top: 4px;"></span>
                        Actualizar Actividad
                    </button>
                    <button type="button" id="cancelar-edicion" class="button" style="margin-left: 10px;">
                        <span class="dashicons dashicons-no" style="margin-top: 4px;"></span>
                        Cancelar
                    </button>
                </p>
            </form>
        </div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        // Abrir modal de edición
        $('.editar-actividad').on('click', function() {
            var actividad = $(this).data('actividad');
            
            // Llenar el formulario con los datos de la actividad
            $('#editar_actividad_id').val(actividad.id);
            $('#editar_fecha').val(actividad.fecha);
            $('#editar_actividad_nombre').val(actividad.actividad_nombre);
            $('#editar_estado').val(actividad.estado);
            $('#editar_duracion_real').val(actividad.duracion_real);
            $('#editar_valoracion').val(actividad.valoracion);
            $('#editar_tipo_actividad').val(actividad.tipo_actividad);
            $('#editar_observaciones').val(actividad.observaciones);
            
            // Mostrar modal
            $('#modal-editar-actividad').fadeIn();
        });
        
        // Cerrar modal de edición
        $('#cancelar-edicion').on('click', function() {
            $('#modal-editar-actividad').fadeOut();
        });
        
        // Cerrar modal al hacer click fuera
        $('#modal-editar-actividad').on('click', function(e) {
            if (e.target === this) {
                $(this).fadeOut();
            }
        });
        
        // Auto-submit de filtros cuando cambian las fechas
        $('#fecha_desde, #fecha_hasta').on('change', function() {
            if ($('#fecha_desde').val() && $('#fecha_hasta').val()) {
                $(this).closest('form').submit();
            }
        });
    });
    </script>
    <?php
    echo ob_get_clean();
}

// =============================================
// SISTEMA DE ACTAS MEJORADO
// =============================================

function ac_mostrar_sistema_actas() {
    $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    
    switch ($action) {
        case 'nuevo':
        case 'editar':
            ac_mostrar_formulario_acta($id);
            break;
        case 'ver':
            ac_mostrar_acta_individual($id);
            break;
        default:
            ac_mostrar_lista_actas();
    }
}

function ac_mostrar_lista_actas() {
    $actas = ac_obtener_actas_existentes();
    ob_start();
    ?>
    
    <div class="wrap">
        <h1 class="wp-heading-inline">📋 Sistema de Gestión de Actas</h1>
        
        <div class="ac-actas-header" style="display: flex; justify-content: space-between; align-items: center; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px;">
            <div>
                <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas&action=nuevo'); ?>" class="button button-primary">
                    <span class="dashicons dashicons-plus" style="margin-top: 4px;"></span>
                    Nueva Acta
                </a>
                <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas&export=csv'); ?>" class="button" style="margin-left: 10px;">
                    <span class="dashicons dashicons-media-spreadsheet" style="margin-top: 4px;"></span>
                    Exportar CSV
                </a>
            </div>
            
            <div class="ac-search-box">
                <input type="text" placeholder="Buscar actas..." style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; width: 250px;">
            </div>
        </div>

        <!-- Panel de Métricas Rápidas -->
        <div class="ac-actas-metrics" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px;">
            <div style="background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="font-size: 32px; color: #667eea;">📄</div>
                <h3 style="margin: 10px 0 5px 0; color: #333;">Total Actas</h3>
                <p style="font-size: 24px; font-weight: bold; color: #667eea; margin: 0;"><?php echo count($actas); ?></p>
            </div>
            
            <div style="background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="font-size: 32px; color: #46b450;">📅</div>
                <h3 style="margin: 10px 0 5px 0; color: #333;">Este Mes</h3>
                <p style="font-size: 24px; font-weight: bold; color: #46b450; margin: 0;">
                    <?php 
                    $mes_actual = date('Y-m');
                    $actas_mes = array_filter($actas, function($acta) use ($mes_actual) {
                        return substr($acta['fecha'], 0, 7) === $mes_actual;
                    });
                    echo count($actas_mes);
                    ?>
                </p>
            </div>
            
            <div style="background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="font-size: 32px; color: #ffb900;">👥</div>
                <h3 style="margin: 10px 0 5px 0; color: #333;">Participantes</h3>
                <p style="font-size: 24px; font-weight: bold; color: #ffb900; margin: 0;">
                    <?php
                    $total_participantes = 0;
                    foreach ($actas as $acta) {
                        if (!empty($acta['asistentes'])) {
                            $asistentes = explode("\n", $acta['asistentes']);
                            $total_participantes += count(array_filter($asistentes));
                        }
                    }
                    echo $total_participantes;
                    ?>
                </p>
            </div>
            
            <div style="background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="font-size: 32px; color: #dc3232;">✅</div>
                <h3 style="margin: 10px 0 5px 0; color: #333;">Acuerdos</h3>
                <p style="font-size: 24px; font-weight: bold; color: #dc3232; margin: 0;">
                    <?php
                    $total_acuerdos = 0;
                    foreach ($actas as $acta) {
                        if (!empty($acta['acuerdos'])) {
                            $acuerdos = explode("\n", $acta['acuerdos']);
                            $total_acuerdos += count(array_filter($acuerdos));
                        }
                    }
                    echo $total_acuerdos;
                    ?>
                </p>
            </div>
        </div>

        <!-- Lista de Actas -->
        <div class="ac-actas-list" style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h2 style="margin-top: 0; border-bottom: 2px solid #0073aa; padding-bottom: 10px;">Actas Recientes</h2>
            
            <?php if (!empty($actas)): ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th style="width: 40%;">Título</th>
                            <th style="width: 15%;">Fecha</th>
                            <th style="width: 15%;">Tipo</th>
                            <th style="width: 20%;">Convocante</th>
                            <th style="width: 10%;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($actas as $acta): ?>
                        <tr>
                            <td>
                                <strong><?php echo esc_html($acta['titulo']); ?></strong>
                                <div style="font-size: 12px; color: #666; margin-top: 5px;">
                                    <?php echo esc_html($acta['lugar'] ?: 'Sin lugar especificado'); ?>
                                </div>
                            </td>
                            <td>
                                <?php echo date('d/m/Y', strtotime($acta['fecha'])); ?>
                            </td>
                            <td>
                                <span style="background: #e7f3ff; color: #0073aa; padding: 4px 8px; border-radius: 12px; font-size: 12px;">
                                    <?php echo esc_html($acta['tipo']); ?>
                                </span>
                            </td>
                            <td>
                                <?php echo esc_html($acta['convocante']); ?>
                            </td>
                            <td>
                                <div style="display: flex; gap: 5px;">
                                    <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas&action=ver&id=' . $acta['id']); ?>" 
                                       class="button button-small" title="Ver">
                                        <span class="dashicons dashicons-visibility" style="font-size: 16px;"></span>
                                    </a>
                                    <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas&action=editar&id=' . $acta['id']); ?>" 
                                       class="button button-small" title="Editar">
                                        <span class="dashicons dashicons-edit" style="font-size: 16px;"></span>
                                    </a>
                                    <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas&export=pdf_individual&id=' . $acta['id']); ?>" 
                                       class="button button-small" title="Exportar PDF">
                                        <span class="dashicons dashicons-pdf" style="font-size: 16px;"></span>
                                    </a>
                                    <form method="post" style="display: inline;">
                                        <?php wp_nonce_field('eliminar_acta_' . $acta['id']); ?>
                                        <input type="hidden" name="eliminar_acta" value="1">
                                        <input type="hidden" name="acta_id" value="<?php echo $acta['id']; ?>">
                                        <button type="submit" class="button button-small" title="Eliminar" onclick="return confirm('¿Está seguro de que desea eliminar esta acta?');">
                                            <span class="dashicons dashicons-trash" style="font-size: 16px;"></span>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align: center; padding: 40px 20px; color: #666;">
                    <div style="font-size: 64px; margin-bottom: 15px;">📝</div>
                    <h3 style="color: #333;">No hay actas registradas</h3>
                    <p>Comienza creando tu primera acta para llevar un registro de tus reuniones.</p>
                    <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas&action=nuevo'); ?>" class="button button-primary">
                        Crear Primera Acta
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
    echo ob_get_clean();
}

function ac_mostrar_formulario_acta($id = 0) {
    $acta = $id > 0 ? ac_obtener_acta_por_id($id) : null;
    ob_start();
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline"><?php echo $id > 0 ? '✏️ Editar Acta' : '📝 Nueva Acta'; ?></h1>
        
        <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <form method="post">
                <?php wp_nonce_field('guardar_acta'); ?>
                <input type="hidden" name="guardar_acta" value="1">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="titulo">Título *</label></th>
                        <td>
                            <input type="text" name="titulo" id="titulo" class="regular-text" value="<?php echo $acta ? esc_attr($acta['titulo']) : ''; ?>" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="fecha">Fecha *</label></th>
                        <td>
                            <input type="date" name="fecha" id="fecha" class="regular-text" value="<?php echo $acta ? $acta['fecha'] : date('Y-m-d'); ?>" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="lugar">Lugar</label></th>
                        <td>
                            <input type="text" name="lugar" id="lugar" class="regular-text" value="<?php echo $acta ? esc_attr($acta['lugar']) : ''; ?>">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="tipo">Tipo de Reunión</label></th>
                        <td>
                            <select name="tipo" id="tipo" class="regular-text">
                                <option value="ordinaria" <?php echo $acta && $acta['tipo'] === 'ordinaria' ? 'selected' : ''; ?>>Ordinaria</option>
                                <option value="extraordinaria" <?php echo $acta && $acta['tipo'] === 'extraordinaria' ? 'selected' : ''; ?>>Extraordinaria</option>
                                <option value="comision" <?php echo $acta && $acta['tipo'] === 'comision' ? 'selected' : ''; ?>>Comisión</option>
                                <option value="otra" <?php echo $acta && $acta['tipo'] === 'otra' ? 'selected' : ''; ?>>Otra</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="convocante">Convocante</label></th>
                        <td>
                            <input type="text" name="convocante" id="convocante" class="regular-text" value="<?php echo $acta ? esc_attr($acta['convocante']) : ''; ?>">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="asistentes">Asistentes</label></th>
                        <td>
                            <textarea name="asistentes" id="asistentes" rows="5" class="large-text" placeholder="Lista de asistentes (uno por línea)"><?php echo $acta ? esc_textarea($acta['asistentes']) : ''; ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="contenido">Contenido de la Reunión</label></th>
                        <td>
                            <textarea name="contenido" id="contenido" rows="10" class="large-text" placeholder="Describa los temas tratados en la reunión..."><?php echo $acta ? esc_textarea($acta['contenido']) : ''; ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="acuerdos">Acuerdos</label></th>
                        <td>
                            <textarea name="acuerdos" id="acuerdos" rows="5" class="large-text" placeholder="Lista de acuerdos (uno por línea)"><?php echo $acta ? esc_textarea($acta['acuerdos']) : ''; ?></textarea>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary">
                        <span class="dashicons dashicons-yes" style="margin-top: 4px;"></span>
                        <?php echo $id > 0 ? 'Actualizar Acta' : 'Guardar Acta'; ?>
                    </button>
                    <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas'); ?>" class="button" style="margin-left: 10px;">
                        Cancelar
                    </a>
                </p>
            </form>
        </div>
    </div>
    <?php
    echo ob_get_clean();
}

function ac_mostrar_acta_individual($id) {
    $acta = ac_obtener_acta_por_id($id);
    if (!$acta) {
        echo '<div class="notice notice-error"><p>Acta no encontrada.</p></div>';
        return;
    }
    ob_start();
    ?>
    <div class="wrap">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h1 class="wp-heading-inline">📄 Acta: <?php echo esc_html($acta['titulo']); ?></h1>
            <div>
                <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas&action=editar&id=' . $id); ?>" class="button">
                    <span class="dashicons dashicons-edit" style="margin-top: 4px;"></span>
                    Editar
                </a>
                <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas&export=pdf_individual&id=' . $id); ?>" class="button" style="margin-left: 10px;">
                    <span class="dashicons dashicons-pdf" style="margin-top: 4px;"></span>
                    Exportar PDF
                </a>
                <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas'); ?>" class="button" style="margin-left: 10px;">
                    Volver a la lista
                </a>
            </div>
        </div>
        
        <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <div style="border-bottom: 2px solid #0073aa; padding-bottom: 15px; margin-bottom: 20px;">
                <h2 style="margin-top: 0; color: #0073aa;"><?php echo esc_html($acta['titulo']); ?></h2>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px;">
                    <div>
                        <strong>Fecha:</strong><br>
                        <?php echo date('d/m/Y', strtotime($acta['fecha'])); ?>
                    </div>
                    <div>
                        <strong>Lugar:</strong><br>
                        <?php echo esc_html($acta['lugar'] ?: 'No especificado'); ?>
                    </div>
                    <div>
                        <strong>Tipo:</strong><br>
                        <?php echo esc_html($acta['tipo']); ?>
                    </div>
                    <div>
                        <strong>Convocante:</strong><br>
                        <?php echo esc_html($acta['convocante'] ?: 'No especificado'); ?>
                    </div>
                </div>
            </div>
            
            <?php if (!empty($acta['asistentes'])): ?>
            <div style="margin-bottom: 25px;">
                <h3 style="color: #333; border-bottom: 1px solid #eee; padding-bottom: 8px;">Asistentes</h3>
                <div style="background: #f8f9fa; padding: 15px; border-radius: 4px;">
                    <?php echo nl2br(esc_html($acta['asistentes'])); ?>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($acta['contenido'])): ?>
            <div style="margin-bottom: 25px;">
                <h3 style="color: #333; border-bottom: 1px solid #eee; padding-bottom: 8px;">Contenido de la Reunión</h3>
                <div style="background: #f8f9fa; padding: 20px; border-radius: 4px; line-height: 1.6;">
                    <?php echo nl2br(esc_html($acta['contenido'])); ?>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($acta['acuerdos'])): ?>
            <div style="margin-bottom: 25px;">
                <h3 style="color: #333; border-bottom: 1px solid #eee; padding-bottom: 8px;">Acuerdos</h3>
                <div style="background: #e8f5e8; padding: 20px; border-radius: 4px; border-left: 4px solid #46b450;">
                    <?php echo nl2br(esc_html($acta['acuerdos'])); ?>
                </div>
            </div>
            <?php endif; ?>
            
            <div style="border-top: 1px solid #eee; padding-top: 15px; margin-top: 20px; font-size: 12px; color: #666;">
                <strong>Información del sistema:</strong><br>
                Creado: <?php echo date('d/m/Y H:i', strtotime($acta['fecha_creacion'])); ?> | 
                Última actualización: <?php echo date('d/m/Y H:i', strtotime($acta['fecha_actualizacion'])); ?>
            </div>
        </div>
    </div>
    <?php
    echo ob_get_clean();
}

// =============================================
// SISTEMA DE MEDICACIÓN MEJORADO
// =============================================

function ac_mostrar_sistema_medicacion() {
    $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    
    switch ($action) {
        case 'nuevo':
        case 'editar':
            ac_mostrar_formulario_medicacion($id);
            break;
        default:
            ac_mostrar_lista_medicacion();
    }
}

function ac_mostrar_lista_medicacion() {
    global $wpdb;
    
    $tabla_medicacion = $wpdb->prefix . 'ac_medicacion';
    $tabla_pacientes = $wpdb->prefix . 'ac_pacientes';
    
    $medicaciones = $wpdb->get_results("
        SELECT m.*, p.nombre, p.apellido 
        FROM $tabla_medicacion m 
        LEFT JOIN $tabla_pacientes p ON m.paciente_id = p.id 
        WHERE m.estado = 'activo' 
        ORDER BY m.fecha_inicio DESC
    ", ARRAY_A);
    
    $pacientes = ac_obtener_pacientes_activos();
    
    ob_start();
    ?>
    
    <div class="wrap">
        <h1 class="wp-heading-inline">💊 Sistema de Gestión de Medicación</h1>
        
        <div class="ac-medicacion-header" style="display: flex; justify-content: space-between; align-items: center; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px;">
            <div>
                <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=medicacion&action=nuevo'); ?>" class="button button-primary">
                    <span class="dashicons dashicons-plus" style="margin-top: 4px;"></span>
                    Nueva Medicación
                </a>
            </div>
            
            <div class="ac-search-box">
                <input type="text" placeholder="Buscar medicación..." style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; width: 250px;">
            </div>
        </div>

        <!-- Panel de Métricas Rápidas -->
        <div class="ac-medicacion-metrics" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px;">
            <div style="background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="font-size: 32px; color: #667eea;">💊</div>
                <h3 style="margin: 10px 0 5px 0; color: #333;">Total Medicaciones</h3>
                <p style="font-size: 24px; font-weight: bold; color: #667eea; margin: 0;"><?php echo count($medicaciones); ?></p>
            </div>
            
            <div style="background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="font-size: 32px; color: #46b450;">👥</div>
                <h3 style="margin: 10px 0 5px 0; color: #333;">Pacientes Activos</h3>
                <p style="font-size: 24px; font-weight: bold; color: #46b450; margin: 0;"><?php echo count($pacientes); ?></p>
            </div>
            
            <div style="background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="font-size: 32px; color: #ffb900;">📅</div>
                <h3 style="margin: 10px 0 5px 0; color: #333;">Este Mes</h3>
                <p style="font-size: 24px; font-weight: bold; color: #ffb900; margin: 0;">
                    <?php 
                    $mes_actual = date('Y-m');
                    $medicaciones_mes = array_filter($medicaciones, function($med) use ($mes_actual) {
                        return substr($med['fecha_inicio'], 0, 7) === $mes_actual;
                    });
                    echo count($medicaciones_mes);
                    ?>
                </p>
            </div>
            
            <div style="background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="font-size: 32px; color: #dc3232;">⚠️</div>
                <h3 style="margin: 10px 0 5px 0; color: #333;">Por Vencer</h3>
                <p style="font-size: 24px; font-weight: bold; color: #dc3232; margin: 0;">
                    <?php
                    $hoy = date('Y-m-d');
                    $por_vencer = array_filter($medicaciones, function($med) use ($hoy) {
                        return $med['fecha_fin'] && $med['fecha_fin'] >= $hoy && $med['fecha_fin'] <= date('Y-m-d', strtotime('+7 days'));
                    });
                    echo count($por_vencer);
                    ?>
                </p>
            </div>
        </div>

        <!-- Lista de Medicación -->
        <div class="ac-medicacion-list" style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h2 style="margin-top: 0; border-bottom: 2px solid #0073aa; padding-bottom: 10px;">Registros de Medicación</h2>
            
            <?php if (!empty($medicaciones)): ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th style="width: 20%;">Paciente</th>
                            <th style="width: 15%;">Medicamento</th>
                            <th style="width: 10%;">Dosis</th>
                            <th style="width: 10%;">Frecuencia</th>
                            <th style="width: 15%;">Período</th>
                            <th style="width: 15%;">Prescrito por</th>
                            <th style="width: 15%;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($medicaciones as $med): ?>
                        <tr>
                            <td>
                                <strong><?php echo esc_html($med['nombre'] . ' ' . $med['apellido']); ?></strong>
                            </td>
                            <td>
                                <?php echo esc_html($med['medicamento']); ?>
                            </td>
                            <td>
                                <?php echo esc_html($med['dosis']); ?>
                            </td>
                            <td>
                                <?php echo esc_html($med['frecuencia']); ?>
                            </td>
                            <td>
                                <?php echo date('d/m/Y', strtotime($med['fecha_inicio'])); ?>
                                <?php if ($med['fecha_fin']): ?>
                                    <br>al <?php echo date('d/m/Y', strtotime($med['fecha_fin'])); ?>
                                <?php else: ?>
                                    <br><em>Indefinido</em>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo esc_html($med['prescrito_por'] ?: 'No especificado'); ?>
                            </td>
                            <td>
                                <div style="display: flex; gap: 5px;">
                                    <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=medicacion&action=editar&id=' . $med['id']); ?>" 
                                       class="button button-small" title="Editar">
                                        <span class="dashicons dashicons-edit" style="font-size: 16px;"></span>
                                    </a>
                                    <form method="post" style="display: inline;">
                                        <?php wp_nonce_field('eliminar_medicacion_' . $med['id']); ?>
                                        <input type="hidden" name="eliminar_medicacion" value="1">
                                        <input type="hidden" name="medicacion_id" value="<?php echo $med['id']; ?>">
                                        <button type="submit" class="button button-small" title="Eliminar" onclick="return confirm('¿Está seguro de que desea eliminar este registro?');">
                                            <span class="dashicons dashicons-trash" style="font-size: 16px;"></span>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align: center; padding: 40px 20px; color: #666;">
                    <div style="font-size: 64px; margin-bottom: 15px;">💊</div>
                    <h3 style="color: #333;">No hay registros de medicación</h3>
                    <p>Comienza registrando la primera medicación para llevar un control de los tratamientos.</p>
                    <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=medicacion&action=nuevo'); ?>" class="button button-primary">
                        Registrar Primera Medicación
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
    echo ob_get_clean();
}

function ac_mostrar_formulario_medicacion($id = 0) {
    global $wpdb;
    
    $tabla_medicacion = $wpdb->prefix . 'ac_medicacion';
    $medicacion = $id > 0 ? $wpdb->get_row($wpdb->prepare("SELECT * FROM $tabla_medicacion WHERE id = %d", $id), ARRAY_A) : null;
    
    $pacientes = ac_obtener_pacientes_activos();
    
    ob_start();
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline"><?php echo $id > 0 ? '✏️ Editar Medicación' : '💊 Nueva Medicación'; ?></h1>
        
        <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <form method="post">
                <?php wp_nonce_field('guardar_medicacion'); ?>
                <input type="hidden" name="guardar_medicacion" value="1">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="paciente_id">Paciente *</label></th>
                        <td>
                            <select name="paciente_id" id="paciente_id" class="regular-text" required>
                                <option value="">-- Seleccionar Paciente --</option>
                                <?php foreach ($pacientes as $paciente): ?>
                                <option value="<?php echo $paciente->id; ?>" <?php echo $medicacion && $medicacion['paciente_id'] == $paciente->id ? 'selected' : ''; ?>>
                                    <?php echo esc_html($paciente->nombre . ' ' . $paciente->apellido); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="medicamento">Medicamento *</label></th>
                        <td>
                            <input type="text" name="medicamento" id="medicamento" class="regular-text" value="<?php echo $medicacion ? esc_attr($medicacion['medicamento']) : ''; ?>" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="dosis">Dosis *</label></th>
                        <td>
                            <input type="text" name="dosis" id="dosis" class="regular-text" value="<?php echo $medicacion ? esc_attr($medicacion['dosis']) : ''; ?>" placeholder="Ej: 500mg, 10ml">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="frecuencia">Frecuencia *</label></th>
                        <td>
                            <input type="text" name="frecuencia" id="frecuencia" class="regular-text" value="<?php echo $medicacion ? esc_attr($medicacion['frecuencia']) : ''; ?>" placeholder="Ej: Cada 8 horas, 1 vez al día">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="via_administracion">Vía de Administración</label></th>
                        <td>
                            <select name="via_administracion" id="via_administracion" class="regular-text">
                                <option value="">-- Seleccionar --</option>
                                <option value="oral" <?php echo $medicacion && $medicacion['via_administracion'] === 'oral' ? 'selected' : ''; ?>>Oral</option>
                                <option value="intravenosa" <?php echo $medicacion && $medicacion['via_administracion'] === 'intravenosa' ? 'selected' : ''; ?>>Intravenosa</option>
                                <option value="intramuscular" <?php echo $medicacion && $medicacion['via_administracion'] === 'intramuscular' ? 'selected' : ''; ?>>Intramuscular</option>
                                <option value="subcutanea" <?php echo $medicacion && $medicacion['via_administracion'] === 'subcutanea' ? 'selected' : ''; ?>>Subcutánea</option>
                                <option value="topica" <?php echo $medicacion && $medicacion['via_administracion'] === 'topica' ? 'selected' : ''; ?>>Tópica</option>
                                <option value="inhalatoria" <?php echo $medicacion && $medicacion['via_administracion'] === 'inhalatoria' ? 'selected' : ''; ?>>Inhalatoria</option>
                                <option value="otra" <?php echo $medicacion && $medicacion['via_administracion'] === 'otra' ? 'selected' : ''; ?>>Otra</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="fecha_inicio">Fecha de Inicio *</label></th>
                        <td>
                            <input type="date" name="fecha_inicio" id="fecha_inicio" class="regular-text" value="<?php echo $medicacion ? $medicacion['fecha_inicio'] : date('Y-m-d'); ?>" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="fecha_fin">Fecha de Fin</label></th>
                        <td>
                            <input type="date" name="fecha_fin" id="fecha_fin" class="regular-text" value="<?php echo $medicacion ? $medicacion['fecha_fin'] : ''; ?>">
                            <p class="description">Dejar en blanco si es de uso continuo</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="horario_administracion">Horario de Administración</label></th>
                        <td>
                            <textarea name="horario_administracion" id="horario_administracion" rows="3" class="large-text" placeholder="Horarios específicos de administración"><?php echo $medicacion ? esc_textarea($medicacion['horario_administracion']) : ''; ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="prescrito_por">Prescrito por</label></th>
                        <td>
                            <input type="text" name="prescrito_por" id="prescrito_por" class="regular-text" value="<?php echo $medicacion ? esc_attr($medicacion['prescrito_por']) : ''; ?>" placeholder="Nombre del médico">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="indicaciones_especiales">Indicaciones Especiales</label></th>
                        <td>
                            <textarea name="indicaciones_especiales" id="indicaciones_especiales" rows="3" class="large-text" placeholder="Indicaciones especiales, precauciones..."><?php echo $medicacion ? esc_textarea($medicacion['indicaciones_especiales']) : ''; ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="observaciones">Observaciones</label></th>
                        <td>
                            <textarea name="observaciones" id="observaciones" rows="3" class="large-text" placeholder="Observaciones adicionales..."><?php echo $medicacion ? esc_textarea($medicacion['observaciones']) : ''; ?></textarea>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary">
                        <span class="dashicons dashicons-yes" style="margin-top: 4px;"></span>
                        <?php echo $id > 0 ? 'Actualizar Medicación' : 'Guardar Medicación'; ?>
                    </button>
                    <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=medicacion'); ?>" class="button" style="margin-left: 10px;">
                        Cancelar
                    </a>
                </p>
            </form>
        </div>
    </div>
    <?php
    echo ob_get_clean();
}

// =============================================
// HOOKS DE ACTIVACIÓN Y DESACTIVACIÓN
// =============================================

register_activation_hook(__FILE__, 'ac_activar_plugin');
register_deactivation_hook(__FILE__, 'ac_desactivar_plugin');
register_uninstall_hook(__FILE__, 'ac_desinstalar_plugin');

/**
 * Función ejecutada al activar el plugin
 */
function ac_activar_plugin() {
    // Verificar permisos
    if (!current_user_can('activate_plugins')) {
        return;
    }
    
    // Crear tablas necesarias
    ac_crear_tablas_si_no_existen();
    ac_crear_tabla_medicacion();
    
    // Registrar opciones por defecto
    add_option('ac_sistema_version', AC_PLUGIN_VERSION);
    add_option('ac_zona_horaria', 'America/Argentina/Buenos_Aires');
    
    // Log de activación
    error_log('Sistema Integral de Gestión: Plugin activado correctamente');
}

/**
 * Función ejecutada al desactivar el plugin
 */
function ac_desactivar_plugin() {
    // Verificar permisos
    if (!current_user_can('activate_plugins')) {
        return;
    }
    
    // Limpiar cron jobs si existen
    wp_clear_scheduled_hook('ac_registro_automatico_diario');
    
    // Log de desactivación
    error_log('Sistema Integral de Gestión: Plugin desactivado');
}

/**
 * Función ejecutada al desinstalar el plugin
 */
function ac_desinstalar_plugin() {
    // Verificar permisos
    if (!current_user_can('activate_plugins')) {
        return;
    }
    
    // Opción para eliminar datos al desinstalar
    $eliminar_datos = get_option('ac_eliminar_datos_desinstalar', 'no');
    
    if ($eliminar_datos === 'si') {
        global $wpdb;
        
        // Eliminar tablas
        $tablas = [
            $wpdb->prefix . 'ac_actas',
            $wpdb->prefix . 'ac_registros_diarios',
            $wpdb->prefix . 'ac_pacientes',
            $wpdb->prefix . 'ac_medicacion'
        ];
        
        foreach ($tablas as $tabla) {
            $wpdb->query("DROP TABLE IF EXISTS $tabla");
        }
        
        // Eliminar opciones
        delete_option('ac_sistema_version');
        delete_option('ac_zona_horaria');
        delete_option('ac_eliminar_datos_desinstalar');
        
        error_log('Sistema Integral de Gestión: Todos los datos eliminados');
    } else {
        error_log('Sistema Integral de Gestión: Plugin desinstalado (datos conservados)');
    }
}

// =============================================
// CONFIGURACIÓN DEL MENÚ ADMINISTRATIVO
// =============================================

add_action('admin_menu', 'ac_agregar_menu_administrativo');

function ac_agregar_menu_administrativo() {
    // Menú principal
    add_menu_page(
        'Sistema Integral de Gestión',
        'Sistema Integral', 
        'manage_options',
        'ac-sistema-integral',
        'ac_sistema_integrado',
        'dashicons-calendar-alt',
        25
    );
    
    // Subpáginas (opcionales - para organización adicional)
    add_submenu_page(
        'ac-sistema-integral',
        'Planificador Diario',
        'Planificador',
        'manage_options',
        'admin.php?page=ac-sistema-integral&modo=planificador'
    );
    
    add_submenu_page(
        'ac-sistema-integral',
        'Libro de Actas',
        'Actas',
        'manage_options',
        'admin.php?page=ac-sistema-integral&modo=actas'
    );
    
    add_submenu_page(
        'ac-sistema-integral',
        'Control de Medicación',
        'Medicación',
        'manage_options',
        'admin.php?page=ac-sistema-integral&modo=medicacion'
    );
    
    // Página de configuración
    add_submenu_page(
        'ac-sistema-integral',
        'Configuración del Sistema',
        'Configuración',
        'manage_options',
        'ac-configuracion',
        'ac_mostrar_pagina_configuracion'
    );
}

// =============================================
// PÁGINA DE CONFIGURACIÓN
// =============================================

function ac_mostrar_pagina_configuracion() {
    // Verificar permisos usando función del core si existe
    ac_verificar_permisos();
    
    // Guardar configuración si se envió el formulario
    if (isset($_POST['guardar_configuracion'])) {
        ac_guardar_configuracion();
    }
    
    $zona_horaria = get_option('ac_zona_horaria', 'America/Argentina/Buenos_Aires');
    $eliminar_datos = get_option('ac_eliminar_datos_desinstalar', 'no');
    
    ob_start();
    ?>
    
    <div class="wrap">
        <h1>⚙️ Configuración del Sistema Integral</h1>
        
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin-top: 20px;">
            <!-- Configuración Principal -->
            <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h2 style="margin-top: 0; border-bottom: 2px solid #0073aa; padding-bottom: 10px;">
                    Configuración General
                </h2>
                
                <form method="post">
                    <?php wp_nonce_field('guardar_configuracion'); ?>
                    <input type="hidden" name="guardar_configuracion" value="1">
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="zona_horaria">Zona Horaria</label></th>
                            <td>
                                <select name="zona_horaria" id="zona_horaria" class="regular-text">
                                    <option value="America/Argentina/Buenos_Aires" <?php selected($zona_horaria, 'America/Argentina/Buenos_Aires'); ?>>Buenos Aires, Argentina</option>
                                    <option value="America/Argentina/Cordoba" <?php selected($zona_horaria, 'America/Argentina/Cordoba'); ?>>Córdoba, Argentina</option>
                                    <option value="America/Mexico_City" <?php selected($zona_horaria, 'America/Mexico_City'); ?>>Ciudad de México</option>
                                    <option value="America/Bogota" <?php selected($zona_horaria, 'America/Bogota'); ?>>Bogotá, Colombia</option>
                                    <option value="America/Lima" <?php selected($zona_horaria, 'America/Lima'); ?>>Lima, Perú</option>
                                    <option value="America/Santiago" <?php selected($zona_horaria, 'America/Santiago'); ?>>Santiago, Chile</option>
                                    <option value="America/Caracas" <?php selected($zona_horaria, 'America/Caracas'); ?>>Caracas, Venezuela</option>
                                </select>
                                <p class="description">Selecciona la zona horaria para los registros del sistema</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="eliminar_datos">Eliminar Datos al Desinstalar</label></th>
                            <td>
                                <select name="eliminar_datos" id="eliminar_datos" class="regular-text">
                                    <option value="no" <?php selected($eliminar_datos, 'no'); ?>>No, conservar los datos</option>
                                    <option value="si" <?php selected($eliminar_datos, 'si'); ?>>Sí, eliminar todos los datos</option>
                                </select>
                                <p class="description">⚠️ ¡Atención! Esta opción eliminará todas las actas, registros y datos del plugin al desinstalarlo</p>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <button type="submit" class="button button-primary">
                            <span class="dashicons dashicons-yes" style="margin-top: 4px;"></span>
                            Guardar Configuración
                        </button>
                    </p>
                </form>
            </div>
            
            <!-- Panel de Información -->
            <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); height: fit-content;">
                <h3 style="margin-top: 0; color: #0073aa;">📊 Estado del Sistema</h3>
                
                <?php
                global $wpdb;
                $tabla_actas = $wpdb->prefix . 'ac_actas';
                $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
                $tabla_pacientes = $wpdb->prefix . 'ac_pacientes';
                $tabla_medicacion = $wpdb->prefix . 'ac_medicacion';
                ?>
                
                <div style="display: grid; gap: 10px; margin-top: 15px;">
                    <div style="display: flex; justify-content: space-between; padding: 8px; background: #f8f9fa; border-radius: 4px;">
                        <span>Actas registradas:</span>
                        <strong><?php echo $wpdb->get_var("SELECT COUNT(*) FROM $tabla_actas WHERE estado = 'activo'"); ?></strong>
                    </div>
                    
                    <div style="display: flex; justify-content: space-between; padding: 8px; background: #f8f9fa; border-radius: 4px;">
                        <span>Registros de actividades:</span>
                        <strong><?php echo $wpdb->get_var("SELECT COUNT(*) FROM $tabla_registros"); ?></strong>
                    </div>
                    
                    <div style="display: flex; justify-content: space-between; padding: 8px; background: #f8f9fa; border-radius: 4px;">
                        <span>Pacientes registrados:</span>
                        <strong><?php echo $wpdb->get_var("SELECT COUNT(*) FROM $tabla_pacientes WHERE estado = 'activo'"); ?></strong>
                    </div>
                    
                    <div style="display: flex; justify-content: space-between; padding: 8px; background: #f8f9fa; border-radius: 4px;">
                        <span>Medicaciones activas:</span>
                        <strong><?php echo $wpdb->get_var("SELECT COUNT(*) FROM $tabla_medicacion WHERE estado = 'activo'"); ?></strong>
                    </div>
                </div>
                
                <div style="margin-top: 20px; padding: 15px; background: #e7f3ff; border-radius: 4px;">
                    <h4 style="margin-top: 0; color: #0073aa;">ℹ️ Información del Sistema</h4>
                    <ul style="margin: 10px 0; padding-left: 20px;">
                        <li>Versión: <?php echo AC_PLUGIN_VERSION; ?></li>
                        <li>Zona horaria: <?php echo $zona_horaria; ?></li>
                        <li>WordPress: <?php echo get_bloginfo('version'); ?></li>
                        <li>PHP: <?php echo phpversion(); ?></li>
                    </ul>
                </div>
                
                <!-- Acciones Rápidas -->
                <div style="margin-top: 20px;">
                    <h4 style="margin-bottom: 10px; color: #0073aa;">🔧 Acciones Rápidas</h4>
                    <div style="display: flex; flex-direction: column; gap: 8px;">
                        <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador'); ?>" class="button">
                            <span class="dashicons dashicons-calendar" style="margin-top: 4px;"></span>
                            Ir al Planificador
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas&action=nuevo'); ?>" class="button">
                            <span class="dashicons dashicons-plus" style="margin-top: 4px;"></span>
                            Crear Nueva Acta
                        </a>
                        <button type="button" id="revisar-tablas" class="button">
                            <span class="dashicons dashicons-admin-tools" style="margin-top: 4px;"></span>
                            Revisar Tablas
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Panel de Mantenimiento -->
        <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-top: 20px;">
            <h2 style="margin-top: 0; border-bottom: 2px solid #dc3232; padding-bottom: 10px; color: #dc3232;">
                🛠️ Herramientas de Mantenimiento
            </h2>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div>
                    <h3>Exportar Datos</h3>
                    <p>Exporta todos los datos del sistema en formato CSV para respaldo o análisis externo.</p>
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas&export=csv'); ?>" class="button">
                            Exportar Actas
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador&export=actividades_completas'); ?>" class="button">
                            Exportar Actividades
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador&export=registros'); ?>" class="button">
                            Exportar Registros
                        </a>
                    </div>
                </div>
                
                <div>
                    <h3>Limpieza de Datos</h3>
                    <p>Elimina registros antiguos o datos de prueba. ⚠️ Estas acciones no se pueden deshacer.</p>
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <button type="button" id="limpiar-registros-antiguos" class="button">
                            Limpiar Registros Antiguos
                        </button>
                        <button type="button" id="reparar-tablas" class="button">
                            Reparar Tablas
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        // Revisar tablas
        $('#revisar-tablas').on('click', function() {
            var $boton = $(this);
            $boton.prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation: spin 1s linear infinite; margin-top: 4px;"></span> Revisando...');
            
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'ac_revisar_tablas',
                    _wpnonce: '<?php echo wp_create_nonce('ac_revisar_tablas'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        alert('✅ ' + response.data.message);
                    } else {
                        alert('❌ ' + response.data.message);
                    }
                    $boton.prop('disabled', false).html('<span class="dashicons dashicons-admin-tools" style="margin-top: 4px;"></span> Revisar Tablas');
                },
                error: function() {
                    alert('❌ Error al revisar las tablas');
                    $boton.prop('disabled', false).html('<span class="dashicons dashicons-admin-tools" style="margin-top: 4px;"></span> Revisar Tablas');
                }
            });
        });
        
        // Limpiar registros antiguos
        $('#limpiar-registros-antiguos').on('click', function() {
            if (confirm('¿Está seguro de que desea eliminar los registros de actividades con más de 1 año de antigüedad? Esta acción no se puede deshacer.')) {
                var $boton = $(this);
                $boton.prop('disabled', true).html('Limpiando...');
                
                $.ajax({
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    type: 'POST',
                    data: {
                        action: 'ac_limpiar_registros_antiguos',
                        _wpnonce: '<?php echo wp_create_nonce('ac_limpiar_registros_antiguos'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            alert('✅ ' + response.data.message);
                        } else {
                            alert('❌ ' + response.data.message);
                        }
                        $boton.prop('disabled', false).html('Limpiar Registros Antiguos');
                    },
                    error: function() {
                        alert('❌ Error al limpiar registros');
                        $boton.prop('disabled', false).html('Limpiar Registros Antiguos');
                    }
                });
            }
        });
        
        // Reparar tablas
        $('#reparar-tablas').on('click', function() {
            if (confirm('¿Está seguro de que desea reparar las tablas de la base de datos?')) {
                var $boton = $(this);
                $boton.prop('disabled', true).html('Reparando...');
                
                $.ajax({
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    type: 'POST',
                    data: {
                        action: 'ac_reparar_tablas',
                        _wpnonce: '<?php echo wp_create_nonce('ac_reparar_tablas'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            alert('✅ ' + response.data.message);
                        } else {
                            alert('❌ ' + response.data.message);
                        }
                        $boton.prop('disabled', false).html('Reparar Tablas');
                    },
                    error: function() {
                        alert('❌ Error al reparar tablas');
                        $boton.prop('disabled', false).html('Reparar Tablas');
                    }
                });
            }
        });
    });
    </script>
    <?php
    echo ob_get_clean();
}

// =============================================
// GUARDAR CONFIGURACIÓN
// =============================================

function ac_guardar_configuracion() {
    // Verificar permisos y nonce
    if (!current_user_can('manage_options') || 
        !isset($_POST['_wpnonce']) || 
        !wp_verify_nonce($_POST['_wpnonce'], 'guardar_configuracion')) {
        echo '<div class="notice notice-error"><p>Error de seguridad al guardar la configuración.</p></div>';
        return;
    }
    
    // Sanitizar y guardar opciones
    $zona_horaria = sanitize_text_field($_POST['zona_horaria']);
    $eliminar_datos = sanitize_text_field($_POST['eliminar_datos']);
    
    update_option('ac_zona_horaria', $zona_horaria);
    update_option('ac_eliminar_datos_desinstalar', $eliminar_datos);
    
    // Actualizar zona horaria
    date_default_timezone_set($zona_horaria);
    
    echo '<div class="notice notice-success is-dismissible"><p>✅ Configuración guardada correctamente.</p></div>';
}

// =============================================
// FUNCIONES AJAX PARA MANTENIMIENTO
// =============================================

add_action('wp_ajax_ac_revisar_tablas', 'ac_ajax_revisar_tablas');
add_action('wp_ajax_ac_limpiar_registros_antiguos', 'ac_ajax_limpiar_registros_antiguos');
add_action('wp_ajax_ac_reparar_tablas', 'ac_ajax_reparar_tablas');

function ac_ajax_revisar_tablas() {
    // Verificar permisos
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'No tienes permisos para realizar esta acción.']);
    }
    
    if (!wp_verify_nonce($_POST['_wpnonce'], 'ac_revisar_tablas')) {
        wp_send_json_error(['message' => 'Error de seguridad.']);
    }
    
    global $wpdb;
    
    $tablas = [
        $wpdb->prefix . 'ac_actas',
        $wpdb->prefix . 'ac_registros_diarios',
        $wpdb->prefix . 'ac_pacientes',
        $wpdb->prefix . 'ac_medicacion'
    ];
    
    $resultados = [];
    $errores = [];
    
    foreach ($tablas as $tabla) {
        if ($wpdb->get_var("SHOW TABLES LIKE '$tabla'") != $tabla) {
            $errores[] = "La tabla $tabla no existe";
        } else {
            $resultados[] = "✅ $tabla - OK";
        }
    }
    
    if (empty($errores)) {
        wp_send_json_success([
            'message' => 'Todas las tablas existen y están correctamente configuradas.',
            'detalles' => $resultados
        ]);
    } else {
        wp_send_json_error([
            'message' => 'Se encontraron problemas con algunas tablas.',
            'detalles' => $errores
        ]);
    }
}

function ac_ajax_limpiar_registros_antiguos() {
    // Verificar permisos
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'No tienes permisos para realizar esta acción.']);
    }
    
    if (!wp_verify_nonce($_POST['_wpnonce'], 'ac_limpiar_registros_antiguos')) {
        wp_send_json_error(['message' => 'Error de seguridad.']);
    }
    
    global $wpdb;
    $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
    
    $fecha_limite = date('Y-m-d', strtotime('-1 year'));
    $eliminados = $wpdb->query(
        $wpdb->prepare("DELETE FROM $tabla_registros WHERE fecha < %s", $fecha_limite)
    );
    
    if ($eliminados === false) {
        wp_send_json_error(['message' => 'Error al eliminar registros antiguos: ' . $wpdb->last_error]);
    } else {
        wp_send_json_success(['message' => "Se eliminaron $eliminados registros antiguos (anteriores a $fecha_limite)."]);
    }
}

function ac_ajax_reparar_tablas() {
    // Verificar permisos
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'No tienes permisos para realizar esta acción.']);
    }
    
    if (!wp_verify_nonce($_POST['_wpnonce'], 'ac_reparar_tablas')) {
        wp_send_json_error(['message' => 'Error de seguridad.']);
    }
    
    global $wpdb;
    
    // Recrear las tablas usando funciones del core si existen
    ac_crear_tablas_si_no_existen();
    ac_crear_tabla_medicacion();
    
    wp_send_json_success(['message' => 'Tablas reparadas correctamente.']);
}

// =============================================
// HOOKS ADICIONALES Y CONFIGURACIÓN
// =============================================

// Inicializar el sistema cuando WordPress cargue
add_action('init', 'ac_inicializar_sistema');

function ac_inicializar_sistema() {
    // Aplicar zona horaria configurada
    $zona_horaria = get_option('ac_zona_horaria', 'America/Argentina/Buenos_Aires');
    date_default_timezone_set($zona_horaria);
    
    // Verificar y crear tablas si es necesario usando funciones del core
    if (is_admin()) {
        ac_crear_tablas_si_no_existen();
        ac_crear_tabla_medicacion();
    }
}

// Agregar estilos CSS adicionales
add_action('admin_enqueue_scripts', 'ac_agregar_estilos_admin');

function ac_agregar_estilos_admin($hook) {
    // Solo cargar en las páginas del plugin
    if (strpos($hook, 'ac-sistema-integral') !== false || strpos($hook, 'ac-configuracion') !== false) {
        wp_enqueue_style('ac-estilos-admin', AC_PLUGIN_URL . 'assets/admin.css', [], AC_PLUGIN_VERSION);
        
        // Animación para spinner
        wp_add_inline_style('ac-estilos-admin', '
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        ');
    }
}

// =============================================
// MANEJAR ENVÍOS DE FORMULARIOS
// =============================================

// Manejar guardado de registro diario
if (isset($_POST['guardar_registro_diario'])) {
    // Verificar permisos antes de procesar
    if (current_user_can('manage_options') || current_user_can('edit_pages')) {
        $resultado = ac_guardar_registro_diario();
        
        if ($resultado['success']) {
            echo '<div class="notice notice-success is-dismissible"><p>✅ ' . $resultado['message'] . '</p></div>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>❌ ' . $resultado['message'] . '</p></div>';
        }
    }
}

// Manejar guardado de acta
if (isset($_POST['guardar_acta'])) {
    // Verificar permisos antes de procesar
    if (current_user_can('manage_options') || current_user_can('edit_pages')) {
        $resultado = ac_guardar_acta($_POST);
        
        if ($resultado['success']) {
            echo '<div class="notice notice-success is-dismissible"><p>✅ ' . $resultado['message'] . '</p></div>';
            
            // Redirigir para evitar reenvío del formulario
            if (isset($resultado['id'])) {
                echo '<script>setTimeout(function() { window.location.href = "?page=ac-sistema-integral&modo=actas&action=ver&id=' . $resultado['id'] . '"; }, 1000);</script>';
            }
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>❌ ' . $resultado['message'] . '</p></div>';
        }
    }
}

// Manejar eliminación de acta
if (isset($_POST['eliminar_acta'])) {
    // Verificar permisos antes de procesar
    if (current_user_can('manage_options') || current_user_can('edit_pages')) {
        $resultado = ac_eliminar_acta(intval($_POST['acta_id']));
        
        if ($resultado['success']) {
            echo '<div class="notice notice-success is-dismissible"><p>✅ ' . $resultado['message'] . '</p></div>';
            echo '<script>setTimeout(function() { window.location.href = "?page=ac-sistema-integral&modo=actas"; }, 1000);</script>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>❌ ' . $resultado['message'] . '</p></div>';
        }
    }
}

// Manejar guardado de medicación
if (isset($_POST['guardar_medicacion'])) {
    // Verificar permisos antes de procesar
    if (current_user_can('manage_options') || current_user_can('edit_pages')) {
        $resultado = ac_guardar_medicacion();
        
        if ($resultado['success']) {
            echo '<div class="notice notice-success is-dismissible"><p>✅ ' . $resultado['message'] . '</p></div>';
            
            // Redirigir para evitar reenvío del formulario
            if (isset($resultado['id'])) {
                echo '<script>setTimeout(function() { window.location.href = "?page=ac-sistema-integral&modo=medicacion"; }, 1000);</script>';
            }
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>❌ ' . $resultado['message'] . '</p></div>';
        }
    }
}

// Manejar actualización de actividad
if (isset($_POST['actualizar_actividad'])) {
    // Verificar permisos antes de procesar
    if (current_user_can('manage_options') || current_user_can('edit_pages')) {
        $id = intval($_POST['actividad_id']);
        $resultado = ac_actualizar_actividad($id, $_POST);
        
        if ($resultado['success']) {
            echo '<div class="notice notice-success is-dismissible"><p>✅ ' . $resultado['message'] . '</p></div>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>❌ ' . $resultado['message'] . '</p></div>';
        }
    }
}

// Manejar eliminación de actividad
if (isset($_POST['eliminar_actividad'])) {
    // Verificar permisos antes de procesar
    if (current_user_can('manage_options') || current_user_can('edit_pages')) {
        $id = intval($_POST['actividad_id']);
        $resultado = ac_eliminar_actividad($id);
        
        if ($resultado['success']) {
            echo '<div class="notice notice-success is-dismissible"><p>✅ ' . $resultado['message'] . '</p></div>';
            echo '<script>setTimeout(function() { window.location.href = "?page=ac-sistema-integral&modo=planificador&submodo=actividades"; }, 1000);</script>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>❌ ' . $resultado['message'] . '</p></div>';
        }
    }
}

// =============================================
// MANEJAR EXPORTACIONES
// =============================================
if (isset($_GET['export'])) {
    // Verificar permisos
    if (!current_user_can('manage_options') && !current_user_can('edit_pages')) {
        wp_die('No tienes permisos para realizar esta acción.');
    }
    
    $export_type = $_GET['export'];
    
    if ($export_type === 'csv') {
        // Exportar actas a CSV
        $actas = ac_obtener_actas_existentes(1000);
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="actas_' . date('Y-m-d') . '.csv"');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['ID', 'Título', 'Fecha', 'Tipo', 'Lugar', 'Convocante', 'Asistentes', 'Acuerdos']);
        
        foreach ($actas as $acta) {
            fputcsv($output, [
                $acta['id'],
                $acta['titulo'],
                $acta['fecha'],
                $acta['tipo'],
                $acta['lugar'],
                $acta['convocante'],
                str_replace("\n", "; ", $acta['asistentes']),
                str_replace("\n", "; ", $acta['acuerdos'])
            ]);
        }
        
        fclose($output);
        exit;
        
    } elseif ($export_type === 'pdf_individual' && isset($_GET['id'])) {
        // Exportar acta individual a PDF (simplificado)
        $acta = ac_obtener_acta_por_id(intval($_GET['id']));
        
        if (!$acta) {
            wp_die('Acta no encontrada');
        }
        
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="acta_' . $acta['id'] . '_' . $acta['fecha'] . '.pdf"');
        
        // En una implementación real, usarías una librería PDF como TCPDF o Dompdf
        echo "=== ACTA ===\n\n";
        echo "Título: " . $acta['titulo'] . "\n";
        echo "Fecha: " . $acta['fecha'] . "\n";
        echo "Lugar: " . $acta['lugar'] . "\n";
        echo "Tipo: " . $acta['tipo'] . "\n";
        echo "Convocante: " . $acta['convocante'] . "\n\n";
        echo "ASISTENTES:\n" . $acta['asistentes'] . "\n\n";
        echo "CONTENIDO:\n" . $acta['contenido'] . "\n\n";
        echo "ACUERDOS:\n" . $acta['acuerdos'] . "\n";
        
        exit;
        
    } elseif ($export_type === 'resumen_diario') {
        // Resumen diario en PDF
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="resumen_diario_' . date('Y-m-d') . '.pdf"');
        
        // Contenido simplificado del PDF
        echo "RESUMEN DIARIO - " . date('d/m/Y') . "\n\n";
        echo "Este es un resumen de las actividades del día.\n";
        echo "En una implementación completa, aquí irían todos los registros del día.\n";
        
        exit;
        
    } elseif ($export_type === 'registros') {
        // Exportar registros a CSV
        global $wpdb;
        $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
        
        $registros = $wpdb->get_results("
            SELECT fecha, actividad_nombre, estado, valoracion, duracion_real, observaciones 
            FROM $tabla_registros 
            ORDER BY fecha DESC, id DESC
        ", ARRAY_A);
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="registros_' . date('Y-m-d') . '.csv"');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['Fecha', 'Actividad', 'Estado', 'Valoración', 'Duración (min)', 'Observaciones']);
        
        foreach ($registros as $registro) {
            fputcsv($output, [
                $registro['fecha'],
                $registro['actividad_nombre'],
                $registro['estado'],
                $registro['valoracion'],
                $registro['duracion_real'],
                $registro['observaciones']
            ]);
        }
        
        fclose($output);
        exit;
        
    } elseif ($export_type === 'actividades_completas') {
        // Exportar actividades completas a CSV
        $actividades = ac_obtener_todas_actividades(1000);
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="actividades_completas_' . date('Y-m-d') . '.csv"');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['ID', 'Fecha', 'Actividad', 'Estado', 'Duración', 'Valoración', 'Tipo', 'Observaciones']);
        
        foreach ($actividades as $actividad) {
            fputcsv($output, [
                $actividad['id'],
                $actividad['fecha'],
                $actividad['actividad_nombre'],
                $actividad['estado'],
                $actividad['duracion_real'],
                $actividad['valoracion'],
                $actividad['tipo_actividad'],
                $actividad['observaciones']
            ]);
        }
        
        fclose($output);
        exit;
    }
}

// =============================================
// FUNCIÓN AJAX PARA REGISTRO MASIVO
// =============================================

// Registrar la función AJAX para usuarios logueados
add_action('wp_ajax_ac_registro_masivo_faltantes', 'ac_ajax_registro_masivo_faltantes_callback');

function ac_ajax_registro_masivo_faltantes_callback() {
    // Verificar nonce
    if (!wp_verify_nonce($_POST['_wpnonce'], 'ac_registro_masivo_faltantes')) {
        wp_send_json_error(['message' => 'Error de seguridad.']);
        return;
    }
    
    // Verificar permisos
    if (!current_user_can('manage_options') && !current_user_can('edit_pages')) {
        wp_send_json_error(['message' => 'No tienes permisos para realizar esta acción.']);
        return;
    }
    
    global $wpdb;
    $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
    $fecha_actual = date('Y-m-d');
    
    $actividades = isset($_POST['actividades']) ? $_POST['actividades'] : [];
    $registros_creados = 0;
    
    if (empty($actividades)) {
        wp_send_json_error(['message' => 'No hay actividades para registrar.']);
        return;
    }
    
    foreach ($actividades as $actividad) {
        $actividad_id = $actividad['hora'] . '_' . sanitize_title($actividad['actividad']);
        
        $existe = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*) FROM $tabla_registros 
            WHERE fecha = %s AND actividad_id = %s
        ", $fecha_actual, $actividad_id));
        
        if ($existe == 0) {
            $resultado = $wpdb->insert(
                $tabla_registros,
                [
                    'fecha' => $fecha_actual,
                    'actividad_id' => $actividad_id,
                    'actividad_nombre' => sanitize_text_field($actividad['actividad']),
                    'estado' => 'completada',
                    'duracion_real' => intval($actividad['duracion']),
                    'valoracion' => 3,
                    'observaciones' => 'Registro automático masivo',
                    'tipo_actividad' => sanitize_text_field($actividad['tipo'])
                ],
                ['%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s']
            );
            
            if ($resultado) {
                $registros_creados++;
            }
        }
    }
    
    wp_send_json_success([
        'message' => 'Se crearon ' . $registros_creados . ' registros automáticamente.',
        'registros_creados' => $registros_creados
    ]);
}

// =============================================
// WIDGETS Y FUNCIONALIDADES EXTRAS
// =============================================

// Agregar widget de dashboard
add_action('wp_dashboard_setup', 'ac_agregar_widget_dashboard');

function ac_agregar_widget_dashboard() {
    if (current_user_can('manage_options') || current_user_can('edit_pages')) {
        wp_add_dashboard_widget(
            'ac_resumen_diario',
            '📊 Resumen del Sistema Integral',
            'ac_mostrar_widget_dashboard'
        );
    }
}

function ac_mostrar_widget_dashboard() {
    global $wpdb;
    
    $hoy = date('Y-m-d');
    $tabla_registros = $wpdb->prefix . 'ac_registros_diarios';
    $tabla_actas = $wpdb->prefix . 'ac_actas';
    
    // Verificar si las tablas existen
    if ($wpdb->get_var("SHOW TABLES LIKE '$tabla_registros'") != $tabla_registros) {
        echo '<p>El sistema no está configurado correctamente. Por favor, active el plugin.</p>';
        return;
    }
    
    // Actividades de hoy
    $actividades_hoy = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $tabla_registros WHERE fecha = %s", 
        $hoy
    ));
    
    // Actas del mes
    $mes_actual = date('Y-m');
    $actas_mes = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $tabla_actas WHERE fecha LIKE %s AND estado = 'activo'",
        $mes_actual . '%'
    ));
    ?>
    
    <div style="display: grid; gap: 10px;">
        <div style="display: flex; justify-content: space-between; padding: 8px; background: #f8f9fa; border-radius: 4px;">
            <span>Actividades hoy:</span>
            <strong><?php echo $actividades_hoy; ?></strong>
        </div>
        
        <div style="display: flex; justify-content: space-between; padding: 8px; background: #f8f9fa; border-radius: 4px;">
            <span>Actas este mes:</span>
            <strong><?php echo $actas_mes; ?></strong>
        </div>
        
        <div style="margin-top: 10px; display: flex; gap: 5px; flex-wrap: wrap;">
            <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador'); ?>" class="button button-small">
                Ir al Planificador
            </a>
            <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas&action=nuevo'); ?>" class="button button-small">
                Nueva Acta
            </a>
        </div>
        
        <?php if ($actividades_hoy == 0): ?>
            <div style="margin-top: 10px; padding: 10px; background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 4px;">
                <p style="margin: 0; font-size: 12px;">📝 No hay actividades registradas hoy.</p>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

// =============================================
// SHORTCODES (OPCIONAL)
// =============================================

add_shortcode('mostrar_estadisticas', 'ac_shortcode_estadisticas');

function ac_shortcode_estadisticas($atts) {
    // Solo para usuarios con permisos
    if (!current_user_can('manage_options') && !current_user_can('edit_pages')) {
        return '';
    }
    
    $atts = shortcode_atts([
        'tipo' => 'general',
        'rango' => 'semana'
    ], $atts);
    
    ob_start();
    
    if ($atts['tipo'] === 'general') {
        $estadisticas = ac_obtener_estadisticas_cumplimiento_mejorado($atts['rango']);
        ?>
        <div style="background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h4>📊 Estadísticas del Sistema</h4>
            <div style="display: grid; gap: 8px; margin-top: 10px;">
                <div style="display: flex; justify-content: space-between;">
                    <span>Cumplimiento:</span>
                    <strong><?php echo $estadisticas['porcentaje_completadas']; ?>%</strong>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span>Actividades totales:</span>
                    <strong><?php echo $estadisticas['total_actividades']; ?></strong>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span>Valoración promedio:</span>
                    <strong><?php echo number_format($estadisticas['valoracion_promedio'], 1); ?>/5</strong>
                </div>
            </div>
        </div>
        <?php
    }
    
    return ob_get_clean();
}

// =============================================
// MENSAJE DE BIENVENIDA Y COMPROBACIONES
// =============================================

// Mostrar notice de bienvenida después de la activación
add_action('admin_notices', 'ac_notice_bienvenida');

function ac_notice_bienvenida() {
    if (get_transient('ac_plugin_activado')) {
        ?>
        <div class="notice notice-success is-dismissible">
            <p>✅ <strong>Sistema Integral de Gestión</strong> ha sido activado correctamente. 
            <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral'); ?>">Acceder al sistema</a> o 
            <a href="<?php echo admin_url('admin.php?page=ac-configuracion'); ?>">configurar opciones</a>.</p>
        </div>
        <?php
        delete_transient('ac_plugin_activado');
    }
}

// Establecer transient al activar
register_activation_hook(__FILE__, function() {
    set_transient('ac_plugin_activado', 1, 30);
});
?>