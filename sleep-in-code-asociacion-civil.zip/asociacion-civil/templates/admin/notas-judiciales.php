<?php
if (!defined('ABSPATH')) {
    exit;
}

// Verificar que $notas esté definida y sea un array
if (!isset($notas) || !is_array($notas)) {
    $notas = array();
}

// Manejar exportaciones
if (isset($_GET['export'])) {
    $export_type = $_GET['export'];
    
    if ($export_type === 'csv') {
        nj_exportar_csv($notas);
    } elseif ($export_type === 'pdf') {
        nj_exportar_pdf($notas);
    } elseif ($export_type === 'pdf_individual' && isset($_GET['id'])) {
        $nota_id = intval($_GET['id']);
        $nota_individual = null;
        
        foreach ($notas as $nota) {
            if ($nota->getId() === $nota_id) {
                $nota_individual = $nota;
                break;
            }
        }
        
        if ($nota_individual) {
            nj_exportar_pdf_individual($nota_individual);
        }
    }
}

// Funciones de exportación
function nj_exportar_csv($notas) {
    $filename = 'notas_judiciales_' . date('Y-m-d') . '.csv';
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $output = fopen('php://output', 'w');
    fputs($output, "\xEF\xBB\xBF");
    
    // Encabezados
    fputcsv($output, array(
        'ID', 'Número de Expediente', 'Fecha', 'Juzgado', 'Juez', 'Tipo de Proceso', 
        'Partes Involucradas', 'Descripción', 'Resolución', 'Estado'
    ), ';');
    
    // Datos
    foreach ($notas as $nota) {
        if (is_object($nota) && method_exists($nota, 'getExpediente')) {
            fputcsv($output, array(
                $nota->getId(),
                $nota->getExpediente(),
                $nota->getFecha(),
                $nota->getJuzgado(),
                $nota->getJuez(),
                $nota->getTipoProceso(),
                $nota->getPartes(),
                strip_tags($nota->getDescripcion()),
                strip_tags($nota->getResolucion()),
                $nota->getEstado()
            ), ';');
        }
    }
    
    fclose($output);
    exit;
}

function nj_exportar_pdf($notas) {
    $filename = 'notas_judiciales_completas_' . date('Y-m-d') . '.pdf';
    
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Registro de Notas Judiciales</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { text-align: center; color: #2c3e50; border-bottom: 2px solid #2c3e50; padding-bottom: 10px; }
            h2 { color: #34495e; background-color: #ecf0f1; padding: 10px; border-left: 4px solid #3498db; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            th, td { border: 1px solid #bdc3c7; padding: 8px; text-align: left; }
            th { background-color: #34495e; color: white; }
            .section { margin-bottom: 30px; border: 1px solid #bdc3c7; padding: 15px; border-radius: 5px; }
            .resolucion { border-color: #27ae60; background-color: #d5f4e6; }
            .estado-pendiente { background-color: #f39c12; color: white; padding: 4px 8px; border-radius: 3px; }
            .estado-resuelto { background-color: #27ae60; color: white; padding: 4px 8px; border-radius: 3px; }
            .estado-apelacion { background-color: #e74c3c; color: white; padding: 4px 8px; border-radius: 3px; }
        </style>
    </head>
    <body>
        <h1>Registro de Notas Judiciales</h1>
        <p style="text-align: center;">Exportado el: ' . date('d/m/Y H:i:s') . '</p>
        <p style="text-align: center;">Total de notas: ' . count($notas) . '</p>
        <hr>';
    
    foreach ($notas as $index => $nota) {
        if (is_object($nota) && method_exists($nota, 'getExpediente')) {
            $estado_class = 'estado-' . strtolower($nota->getEstado());
            $html .= '<div class="section">
                <h2>Nota Judicial #' . ($index + 1) . ': ' . $nota->getExpediente() . '</h2>
                <table>
                    <tr><td style="width: 25%; font-weight: bold;">Número de Expediente:</td><td>' . $nota->getExpediente() . '</td></tr>
                    <tr><td style="font-weight: bold;">Fecha:</td><td>' . date('d/m/Y', strtotime($nota->getFecha())) . '</td></tr>
                    <tr><td style="font-weight: bold;">Juzgado:</td><td>' . $nota->getJuzgado() . '</td></tr>
                    <tr><td style="font-weight: bold;">Juez:</td><td>' . ($nota->getJuez() ?: 'No especificado') . '</td></tr>
                    <tr><td style="font-weight: bold;">Tipo de Proceso:</td><td>' . $nota->getTipoProceso() . '</td></tr>
                    <tr><td style="font-weight: bold;">Estado:</td><td><span class="' . $estado_class . '">' . $nota->getEstado() . '</span></td></tr>
                </table>';
            
            if ($nota->getPartes()) {
                $html .= '<h4>Partes Involucradas:</h4>
                <div style="border: 1px solid #bdc3c7; padding: 10px; background-color: #f8f9fa;">
                    ' . nl2br($nota->getPartes()) . '
                </div>';
            }
            
            if ($nota->getDescripcion()) {
                $html .= '<h4>Descripción del Caso:</h4>
                <div style="border: 1px solid #bdc3c7; padding: 10px; background-color: #f8f9fa;">
                    ' . strip_tags($nota->getDescripcion()) . '
                </div>';
            }
            
            if ($nota->getResolucion()) {
                $html .= '<h4>Resolución:</h4>
                <div style="border: 1px solid #27ae60; padding: 10px; background-color: #d5f4e6;">
                    ' . strip_tags($nota->getResolucion()) . '
                </div>';
            }
            
            $html .= '</div><hr style="margin: 20px 0;">';
        }
    }
    
    $html .= '</body></html>';
    
    echo $html;
    exit;
}

function nj_exportar_pdf_individual($nota) {
    $filename = 'nota_judicial_' . sanitize_title($nota->getExpediente()) . '_' . date('Y-m-d') . '.pdf';
    
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $estado_class = 'estado-' . strtolower($nota->getEstado());
    
    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Nota Judicial - ' . $nota->getExpediente() . '</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 30px; line-height: 1.6; }
            h1 { text-align: center; color: #2c3e50; margin-bottom: 10px; border-bottom: 2px solid #2c3e50; padding-bottom: 10px; }
            h2 { text-align: center; color: #34495e; margin-bottom: 30px; }
            .header-info { margin-bottom: 30px; }
            .info-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            .info-table td { padding: 8px; border-bottom: 1px solid #ecf0f1; }
            .info-table td:first-child { font-weight: bold; width: 30%; background-color: #f8f9fa; }
            .section { margin-bottom: 25px; }
            .section-title { color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 5px; margin-bottom: 10px; }
            .content-box { border: 1px solid #bdc3c7; padding: 15px; background-color: #f8f9fa; margin-bottom: 15px; border-radius: 5px; }
            .resolucion-box { border-color: #27ae60; background-color: #d5f4e6; }
            .estado-pendiente { background-color: #f39c12; color: white; padding: 4px 8px; border-radius: 3px; }
            .estado-resuelto { background-color: #27ae60; color: white; padding: 4px 8px; border-radius: 3px; }
            .estado-apelacion { background-color: #e74c3c; color: white; padding: 4px 8px; border-radius: 3px; }
            .footer { text-align: center; margin-top: 40px; color: #7f8c8d; font-size: 12px; border-top: 1px solid #bdc3c7; padding-top: 20px; }
        </style>
    </head>
    <body>
        <h1>NOTA JUDICIAL</h1>
        <h2>Expediente: ' . $nota->getExpediente() . '</h2>
        
        <div class="header-info">
            <table class="info-table">
                <tr>
                    <td>Número de Expediente:</td>
                    <td>' . $nota->getExpediente() . '</td>
                </tr>
                <tr>
                    <td>Fecha:</td>
                    <td>' . date('d/m/Y', strtotime($nota->getFecha())) . '</td>
                </tr>
                <tr>
                    <td>Juzgado:</td>
                    <td>' . $nota->getJuzgado() . '</td>
                </tr>
                <tr>
                    <td>Juez:</td>
                    <td>' . ($nota->getJuez() ?: 'No especificado') . '</td>
                </tr>
                <tr>
                    <td>Tipo de Proceso:</td>
                    <td>' . $nota->getTipoProceso() . '</td>
                </tr>
                <tr>
                    <td>Estado:</td>
                    <td><span class="' . $estado_class . '">' . $nota->getEstado() . '</span></td>
                </tr>
            </table>
        </div>';
    
    if ($nota->getPartes()) {
        $html .= '<div class="section">
            <h3 class="section-title">PARTES INVOLUCRADAS</h3>
            <div class="content-box">' . nl2br($nota->getPartes()) . '</div>
        </div>';
    }
    
    if ($nota->getDescripcion()) {
        $html .= '<div class="section">
            <h3 class="section-title">DESCRIPCIÓN DEL CASO</h3>
            <div class="content-box">' . strip_tags($nota->getDescripcion()) . '</div>
        </div>';
    }
    
    if ($nota->getResolucion()) {
        $html .= '<div class="section">
            <h3 class="section-title">RESOLUCIÓN</h3>
            <div class="content-box resolucion-box">' . strip_tags($nota->getResolucion()) . '</div>
        </div>';
    }
    
    $html .= '<div class="footer">
            Documento generado el ' . date('d/m/Y H:i:s') . '<br>
            ' . get_bloginfo('name') . ' - Sistema Judicial
        </div>
    </body>
    </html>';
    
    echo $html;
    exit;
}

// Manejar importación CSV
if (isset($_POST['importar_csv'])) {
    nj_importar_csv();
}

function nj_importar_csv() {
    if (!empty($_FILES['csv_file']['tmp_name'])) {
        $file = $_FILES['csv_file']['tmp_name'];
        $handle = fopen($file, 'r');
        
        if ($handle !== FALSE) {
            $importados = 0;
            $errores = 0;
            $primera_linea = true;
            
            while (($data = fgetcsv($handle, 1000, ';')) !== FALSE) {
                if ($primera_linea) {
                    $primera_linea = false;
                    continue;
                }
                
                if (count($data) >= 8) {
                    $expediente = sanitize_text_field($data[1]);
                    $fecha = sanitize_text_field($data[2]);
                    $juzgado = sanitize_text_field($data[3]);
                    $juez = sanitize_text_field($data[4]);
                    $tipo_proceso = sanitize_text_field($data[5]);
                    $partes = isset($data[6]) ? sanitize_textarea_field($data[6]) : '';
                    $descripcion = isset($data[7]) ? sanitize_textarea_field($data[7]) : '';
                    $resolucion = isset($data[8]) ? sanitize_textarea_field($data[8]) : '';
                    $estado = isset($data[9]) ? sanitize_text_field($data[9]) : 'Pendiente';
                    
                    $importados++;
                } else {
                    $errores++;
                }
            }
            
            fclose($handle);
            
            echo '<div class="notice notice-success is-dismissible">';
            echo '<p>Importación completada: ' . $importados . ' notas judiciales importadas correctamente. ' . $errores . ' errores.</p>';
            echo '</div>';
        }
    }
}

// Manejar guardado de nota desde OCR
if (isset($_POST['guardar_nota_ocr'])) {
    nj_guardar_nota_ocr();
}

function nj_guardar_nota_ocr() {
    // Verificar nonce para seguridad
    if (!wp_verify_nonce($_POST['_wpnonce'], 'guardar_nota_ocr')) {
        wp_die('Error de seguridad');
    }
    
    $expediente = sanitize_text_field($_POST['expediente']);
    $fecha = sanitize_text_field($_POST['fecha']);
    $juzgado = sanitize_text_field($_POST['juzgado']);
    $juez = sanitize_text_field($_POST['juez']);
    $tipo_proceso = sanitize_text_field($_POST['tipo_proceso']);
    $partes = sanitize_textarea_field($_POST['partes']);
    $descripcion = sanitize_textarea_field($_POST['descripcion']);
    $resolucion = sanitize_textarea_field($_POST['resolucion']);
    $estado = sanitize_text_field($_POST['estado']);
    
    // Aquí deberías llamar a tu función para guardar la nota judicial en la base de datos
    // Por ejemplo:
    // $nota_id = guardar_nota($expediente, $fecha, $juzgado, $juez, $tipo_proceso, $partes, $descripcion, $resolucion, $estado);
    
    // Simulación de guardado exitoso
    $guardado_exitoso = true;
    
    if ($guardado_exitoso) {
        echo '<div class="notice notice-success is-dismissible">';
        echo '<p>✅ Nota judicial guardada correctamente a partir del texto extraído.</p>';
        echo '</div>';
        
        // Redirigir para evitar reenvío del formulario
        echo '<script>setTimeout(function() { window.location.href = "' . admin_url('admin.php?page=nj-registro-notas') . '"; }, 2000);</script>';
    } else {
        echo '<div class="notice notice-error is-dismissible">';
        echo '<p>❌ Error al guardar la nota judicial. Por favor, inténtalo de nuevo.</p>';
        echo '</div>';
    }
}

// Si estamos en el proceso de OCR, mostrar el formulario de edición
if (isset($_GET['ocr_edit'])) {
    nj_mostrar_formulario_edicion_ocr();
    return;
}

function nj_mostrar_formulario_edicion_ocr() {
    $texto_extraido = isset($_GET['texto']) ? base64_decode($_GET['texto']) : '';
    ?>
    <div class="wrap">
        <h1>⚖️ Revisar Texto Extraído de Documento Judicial</h1>
        
        <div class="notice notice-info">
            <p>Revisa y edita el texto extraído del documento judicial antes de guardar la nota. Corrige cualquier error en el reconocimiento de texto.</p>
        </div>
        
        <form method="post" action="<?php echo admin_url('admin.php?page=nj-registro-notas'); ?>">
            <?php wp_nonce_field('guardar_nota_ocr'); ?>
            <input type="hidden" name="guardar_nota_ocr" value="1">
            
            <div class="nj-ocr-form-container" style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                <!-- Columna izquierda: Campos de la nota judicial -->
                <div class="nj-ocr-campos">
                    <h3>Información de la Nota Judicial</h3>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="expediente">Número de Expediente *</label>
                            </th>
                            <td>
                                <input type="text" id="expediente" name="expediente" class="regular-text" 
                                       placeholder="EJ: EXP-2024-001" required>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="fecha">Fecha *</label>
                            </th>
                            <td>
                                <input type="date" id="fecha" name="fecha" class="regular-text" 
                                       value="<?php echo date('Y-m-d'); ?>" required>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="juzgado">Juzgado *</label>
                            </th>
                            <td>
                                <input type="text" id="juzgado" name="juzgado" class="regular-text" 
                                       placeholder="Juzgado de Primera Instancia..." required>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="juez">Juez/Magistrado</label>
                            </th>
                            <td>
                                <input type="text" id="juez" name="juez" class="regular-text" 
                                       placeholder="Nombre del juez...">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="tipo_proceso">Tipo de Proceso *</label>
                            </th>
                            <td>
                                <select id="tipo_proceso" name="tipo_proceso" class="regular-text" required>
                                    <option value="">Seleccionar tipo...</option>
                                    <option value="Civil">Civil</option>
                                    <option value="Penal">Penal</option>
                                    <option value="Laboral">Laboral</option>
                                    <option value="Mercantil">Mercantil</option>
                                    <option value="Administrativo">Administrativo</option>
                                    <option value="Constitucional">Constitucional</option>
                                    <option value="Familia">Familia</option>
                                    <option value="Otro">Otro</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="estado">Estado del Caso</label>
                            </th>
                            <td>
                                <select id="estado" name="estado" class="regular-text">
                                    <option value="Pendiente">Pendiente</option>
                                    <option value="En Proceso">En Proceso</option>
                                    <option value="Resuelto">Resuelto</option>
                                    <option value="Apelación">En Apelación</option>
                                    <option value="Archivado">Archivado</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                    
                    <h3 style="margin-top: 30px;">Contenido del Caso</h3>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="partes">Partes Involucradas</label>
                            </th>
                            <td>
                                <textarea id="partes" name="partes" rows="5" class="large-text" 
                                          placeholder="Demandante: Nombre Apellido&#10;Demandado: Nombre Apellido&#10;..."></textarea>
                                <p class="description">Ingresa las partes del proceso, una por línea</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="descripcion">Descripción del Caso</label>
                            </th>
                            <td>
                                <textarea id="descripcion" name="descripcion" rows="8" class="large-text" 
                                          placeholder="Descripción de los hechos, alegatos, pruebas..."></textarea>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="resolucion">Resolución/Sentencia</label>
                            </th>
                            <td>
                                <textarea id="resolucion" name="resolucion" rows="5" class="large-text" 
                                          placeholder="Texto de la resolución o sentencia..."></textarea>
                                <p class="description">Ingresa el texto completo de la resolución o sentencia</p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Columna derecha: Texto extraído para referencia -->
                <div class="nj-ocr-texto-original">
                    <h3>Texto Extraído (Solo referencia)</h3>
                    <div style="background: #f6f6f6; border: 1px solid #ddd; border-radius: 4px; padding: 15px; max-height: 600px; overflow-y: auto;">
                        <pre style="white-space: pre-wrap; font-family: 'Courier New', monospace; font-size: 12px; line-height: 1.4; margin: 0; color: #333;"><?php echo esc_html($texto_extraido); ?></pre>
                    </div>
                    <p class="description" style="margin-top: 10px;">
                        <strong>Nota:</strong> Este es el texto crudo extraído por el OCR. Úsalo como referencia para completar los campos del formulario.
                    </p>
                    
                    <div style="margin-top: 20px; padding: 15px; background: #fff8e7; border-radius: 4px; border-left: 4px solid #ffb900;">
                        <h4 style="margin-top: 0; color: #cc8500;">💡 Sugerencias para Notas Judiciales</h4>
                        <ul style="margin: 10px 0; padding-left: 20px; font-size: 13px;">
                            <li>Verifica cuidadosamente los números de expediente</li>
                            <li>Corrige nombres de jueces, partes y testigos</li>
                            <li>Revisa fechas y plazos procesales</li>
                            <li>Estructura correctamente las partes involucradas</li>
                            <li>Verifica la ortografía de términos legales</li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <p class="submit">
                <button type="submit" class="button button-primary button-large">
                    <span class="dashicons dashicons-yes" style="margin-top: 4px;"></span>
                    Guardar Nota Judicial
                </button>
                <a href="<?php echo admin_url('admin.php?page=nj-registro-notas'); ?>" class="button button-large">
                    <span class="dashicons dashicons-no" style="margin-top: 4px;"></span>
                    Cancelar
                </a>
            </p>
        </form>
        
        <style>
        .nj-ocr-form-container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .nj-ocr-campos {
            border-right: 1px solid #eee;
            padding-right: 20px;
        }
        .nj-ocr-texto-original {
            padding-left: 20px;
        }
        .large-text {
            width: 100%;
            max-width: 100%;
        }
        @media (max-width: 1200px) {
            .nj-ocr-form-container {
                grid-template-columns: 1fr !important;
            }
            .nj-ocr-campos {
                border-right: none;
                border-bottom: 1px solid #eee;
                padding-right: 0;
                padding-bottom: 20px;
                margin-bottom: 20px;
            }
            .nj-ocr-texto-original {
                padding-left: 0;
            }
        }
        </style>
    </div>
    <?php
    exit;
}

// Resto del código de estadísticas y mensajes...
// Mensajes de éxito
$mensajes = array();
if (isset($_GET['updated'])) {
    $mensajes[] = 'Nota judicial guardada correctamente.';
}
if (isset($_GET['deleted'])) {
    $mensajes[] = 'Nota judicial eliminada correctamente.';
}
if (isset($_GET['created'])) {
    $mensajes[] = 'Nota judicial creada correctamente.';
}

// Estadísticas avanzadas
$total_notas = count($notas);
$tipos_proceso = array();
$notas_por_mes = array();
$notas_por_año = array();
$notas_por_juzgado = array();
$notas_por_estado = array();
$nota_mas_reciente = null;
$nota_mas_antigua = null;
$total_partes_estimado = 0;
$notas_con_resolucion = 0;

foreach ($notas as $nota) {
    if (is_object($nota) && method_exists($nota, 'getTipoProceso')) {
        // Por tipo de proceso
        $tipo = $nota->getTipoProceso();
        if (!isset($tipos_proceso[$tipo])) {
            $tipos_proceso[$tipo] = 0;
        }
        $tipos_proceso[$tipo]++;
        
        // Por juzgado
        $juzgado = $nota->getJuzgado();
        if (!isset($notas_por_juzgado[$juzgado])) {
            $notas_por_juzgado[$juzgado] = 0;
        }
        $notas_por_juzgado[$juzgado]++;
        
        // Por estado
        $estado = $nota->getEstado();
        if (!isset($notas_por_estado[$estado])) {
            $notas_por_estado[$estado] = 0;
        }
        $notas_por_estado[$estado]++;
        
        // Por mes
        $fecha = $nota->getFecha();
        if ($fecha) {
            $mes = date('Y-m', strtotime($fecha));
            if (!isset($notas_por_mes[$mes])) {
                $notas_por_mes[$mes] = 0;
            }
            $notas_por_mes[$mes]++;
            
            // Por año
            $año = date('Y', strtotime($fecha));
            if (!isset($notas_por_año[$año])) {
                $notas_por_año[$año] = 0;
            }
            $notas_por_año[$año]++;
            
            // Fechas extremas
            if (!$nota_mas_reciente || strtotime($fecha) > strtotime($nota_mas_reciente->getFecha())) {
                $nota_mas_reciente = $nota;
            }
            if (!$nota_mas_antigua || strtotime($fecha) < strtotime($nota_mas_antigua->getFecha())) {
                $nota_mas_antigua = $nota;
            }
        }
        
        // Partes estimadas
        $partes = $nota->getPartes();
        if ($partes) {
            $lineas = array_filter(array_map('trim', explode("\n", $partes)));
            $total_partes_estimado += count($lineas);
        }
        
        // Notas con resolución
        if ($nota->getResolucion()) {
            $notas_con_resolucion++;
        }
    }
}

// Ordenar estadísticas
arsort($tipos_proceso);
arsort($notas_por_juzgado);
krsort($notas_por_mes);
krsort($notas_por_año);

// Calcular porcentajes
$porcentaje_con_resolucion = $total_notas > 0 ? round(($notas_con_resolucion / $total_notas) * 100) : 0;
$promedio_partes = $total_notas > 0 ? round($total_partes_estimado / $total_notas, 1) : 0;

// Manejar selección de métricas y gráficos
$metricas_seleccionadas = isset($_GET['metricas']) ? $_GET['metricas'] : 'mes';
$tipo_grafico_seleccionado = isset($_GET['tipo_grafico']) ? $_GET['tipo_grafico'] : 'barras';

// Función para obtener los últimos 6 meses
function nj_obtener_ultimos_6_meses() {
    $meses = [];
    for ($i = 5; $i >= 0; $i--) {
        $meses[] = date('Y-m', strtotime("-$i months"));
    }
    return $meses;
}

// Preparar datos para el gráfico de los últimos 6 meses
function nj_preparar_datos_ultimos_6_meses($notas_por_mes) {
    $ultimos_6_meses = nj_obtener_ultimos_6_meses();
    $datos_completos = [];
    
    foreach ($ultimos_6_meses as $mes) {
        $meses_es = [
            '01' => 'Ene', '02' => 'Feb', '03' => 'Mar', '04' => 'Abr',
            '05' => 'May', '06' => 'Jun', '07' => 'Jul', '08' => 'Ago',
            '09' => 'Sep', '10' => 'Oct', '11' => 'Nov', '12' => 'Dic'
        ];
        
        $partes = explode('-', $mes);
        $año = $partes[0];
        $mes_num = $partes[1];
        $etiqueta = $meses_es[$mes_num] . ' ' . $año;
        
        $datos_completos[$etiqueta] = $notas_por_mes[$mes] ?? 0;
    }
    
    return $datos_completos;
}

// Preparar datos para AJAX
$datos_grafico_json = array();
$datos_grafico_json['mes'] = nj_preparar_datos_ultimos_6_meses($notas_por_mes);
$datos_grafico_json['año'] = $notas_por_año;
$datos_grafico_json['tipo'] = $tipos_proceso;
$datos_grafico_json['juzgado'] = array_slice($notas_por_juzgado, 0, 6, true);
$datos_grafico_json['estado'] = $notas_por_estado;
?>

<div class="wrap">
    <h1 class="wp-heading-inline">⚖️ Registro de Notas Judiciales</h1>
    
    <?php if (!empty($mensajes)): ?>
        <?php foreach ($mensajes as $mensaje): ?>
            <div class="notice notice-success is-dismissible">
                <p><?php echo esc_html($mensaje); ?></p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <!-- Panel de Métricas Avanzadas -->
    <div class="nj-metrics-panel" style="margin: 20px 0;">
        <h2 style="margin-bottom: 15px; color: #2c3e50;">📊 Métricas del Registro Judicial</h2>
        
        <div class="nj-stats-container" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; margin-bottom: 20px;">
            <!-- Métrica Principal -->
            <div class="nj-stat-card" style="background: linear-gradient(135deg, #2c3e50, #34495e); color: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="display: flex; justify-content: between; align-items: center;">
                    <div>
                        <h3 style="margin: 0 0 5px 0; font-size: 14px; opacity: 0.9;">TOTAL DE NOTAS JUDICIALES</h3>
                        <p style="font-size: 32px; font-weight: bold; margin: 0;">⚖️ <?php echo $total_notas; ?></p>
                    </div>
                    <div style="font-size: 24px;">⚖️</div>
                </div>
                <div style="margin-top: 10px; font-size: 12px; opacity: 0.8;">
                    <?php echo $notas_con_resolucion; ?> con resolución • 
                    <?php echo $notas_por_estado['Pendiente'] ?? 0; ?> pendientes
                </div>
            </div>

            <!-- Distribución por Tipo de Proceso -->
            <div class="nj-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #3498db; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #3498db; font-size: 14px;">DISTRIBUCIÓN POR TIPO</h3>
                <div style="max-height: 120px; overflow-y: auto;">
                    <?php foreach ($tipos_proceso as $tipo => $cantidad): 
                        $porcentaje = $total_notas > 0 ? round(($cantidad / $total_notas) * 100) : 0;
                    ?>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                        <span><?php echo esc_html($tipo); ?></span>
                        <span style="font-weight: bold;"><?php echo $cantidad; ?> (<?php echo $porcentaje; ?>%)</span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Estadísticas de Casos -->
            <div class="nj-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #e74c3c; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #e74c3c; font-size: 14px;">ESTADÍSTICAS DE CASOS</h3>
                <div style="display: grid; gap: 8px;">
                    <div style="display: flex; justify-content: space-between;">
                        <span>Partes involucradas:</span>
                        <strong><?php echo $total_partes_estimado; ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Promedio por caso:</span>
                        <strong><?php echo $promedio_partes; ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Notas con resolución:</span>
                        <strong><?php echo $notas_con_resolucion; ?> (<?php echo $porcentaje_con_resolucion; ?>%)</strong>
                    </div>
                </div>
            </div>

            <!-- Estados de los Casos -->
            <div class="nj-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #f39c12; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #f39c12; font-size: 14px;">ESTADOS DE LOS CASOS</h3>
                <div style="display: grid; gap: 8px; font-size: 12px;">
                    <?php foreach ($notas_por_estado as $estado => $cantidad): 
                        $color = '';
                        switch($estado) {
                            case 'Pendiente': $color = '#f39c12'; break;
                            case 'Resuelto': $color = '#27ae60'; break;
                            case 'Apelación': $color = '#e74c3c'; break;
                            case 'En Proceso': $color = '#3498db'; break;
                            default: $color = '#95a5a6';
                        }
                    ?>
                    <div style="display: flex; justify-content: space-between;">
                        <span><span style="display: inline-block; width: 8px; height: 8px; background: <?php echo $color; ?>; border-radius: 50%; margin-right: 5px;"></span><?php echo $estado; ?></span>
                        <strong><?php echo $cantidad; ?></strong>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Selector de Métricas y Gráficos -->
        <div style="background: white; padding: 15px; border-radius: 8px; margin-bottom: 15px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h4 style="margin: 0 0 10px 0; color: #2c3e50; font-size: 14px;">📈 Seleccionar Métricas de Visualización</h4>
            
            <!-- Selector de Métricas -->
            <div style="display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 15px;">
                <button type="button" class="button nj-metrica-btn <?php echo $metricas_seleccionadas == 'mes' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-metrica="mes"
                        style="font-size: 12px; padding: 6px 12px;">
                    📅 Por Mes
                </button>
                <button type="button" class="button nj-metrica-btn <?php echo $metricas_seleccionadas == 'año' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-metrica="año"
                        style="font-size: 12px; padding: 6px 12px;">
                    📊 Por Año
                </button>
                <button type="button" class="button nj-metrica-btn <?php echo $metricas_seleccionadas == 'tipo' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-metrica="tipo"
                        style="font-size: 12px; padding: 6px 12px;">
                    🏷️ Por Tipo
                </button>
                <button type="button" class="button nj-metrica-btn <?php echo $metricas_seleccionadas == 'juzgado' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-metrica="juzgado"
                        style="font-size: 12px; padding: 6px 12px;">
                    ⚖️ Por Juzgado
                </button>
                <button type="button" class="button nj-metrica-btn <?php echo $metricas_seleccionadas == 'estado' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-metrica="estado"
                        style="font-size: 12px; padding: 6px 12px;">
                    📋 Por Estado
                </button>
            </div>

            <!-- Selector de Tipo de Gráfico -->
            <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
                <span style="font-size: 12px; color: #666; margin-right: 10px;">Tipo de gráfico:</span>
                <button type="button" class="button nj-grafico-btn <?php echo $tipo_grafico_seleccionado == 'barras' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-grafico="barras"
                        style="font-size: 11px; padding: 4px 8px;">
                    📊 Barras
                </button>
                <button type="button" class="button nj-grafico-btn <?php echo $tipo_grafico_seleccionado == 'lineas' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-grafico="lineas"
                        style="font-size: 11px; padding: 4px 8px;">
                    📈 Líneas
                </button>
                <button type="button" class="button nj-grafico-btn <?php echo $tipo_grafico_seleccionado == 'pastel' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-grafico="pastel"
                        style="font-size: 11px; padding: 4px 8px;">
                    🥧 Pastel
                </button>
            </div>
        </div>

        <!-- Gráficos según métrica seleccionada -->
        <div class="nj-charts-container" id="graficos-container">
            <div class="nj-chart-card" style="background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="display: flex; justify-content: between; align-items: center; margin-bottom: 15px;">
                    <h4 style="margin: 0; color: #2c3e50; font-size: 14px;" id="titulo-grafico">
                        📈 <?php 
                        switch($metricas_seleccionadas) {
                            case 'mes': echo 'Notas por Mes (Últimos 6 meses)'; break;
                            case 'año': echo 'Notas por Año'; break;
                            case 'tipo': echo 'Notas por Tipo de Proceso'; break;
                            case 'juzgado': echo 'Notas por Juzgado (Top 6)'; break;
                            case 'estado': echo 'Notas por Estado'; break;
                        }
                        ?>
                    </h4>
                    <div class="nj-chart-info" style="font-size: 12px; color: #666;">
                        <span id="total-notas-grafico">Total: <?php echo array_sum($datos_grafico_json[$metricas_seleccionadas]); ?> notas</span>
                    </div>
                </div>
                
                <div id="contenedor-grafico" 
                     style="min-height: 300px; display: flex; align-items: center; justify-content: center; 
                            width: 100%; overflow: hidden; position: relative;">
                    <div class="nj-loading" style="text-align: center; color: #666;">
                        <p>Cargando gráfico interactivo...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Acciones Principales -->
    <div class="nj-header-actions" style="display: flex; justify-content: space-between; align-items: center; margin: 20px 0; padding: 15px; background: #ecf0f1; border-radius: 8px;">
        <div>
            <a href="<?php echo admin_url('admin.php?page=nj-registro-notas&action=nuevo'); ?>" class="button button-primary" style="font-size: 14px; padding: 8px 16px;">
                <span class="dashicons dashicons-plus" style="margin-top: 4px;"></span>
                Nueva Nota Judicial
            </a>
            <?php if (!empty($notas)): ?>
            <div class="nj-export-buttons" style="display: inline-block; margin-left: 10px;">
                <a href="<?php echo admin_url('admin.php?page=nj-registro-notas&export=csv'); ?>" class="button" style="font-size: 14px; padding: 8px 16px;">
                    <span class="dashicons dashicons-media-spreadsheet" style="margin-top: 4px;"></span>
                    Exportar CSV
                </a>
                <a href="<?php echo admin_url('admin.php?page=nj-registro-notas&export=pdf'); ?>" class="button" style="font-size: 14px; padding: 8px 16px; margin-left: 5px;">
                    <span class="dashicons dashicons-media-document" style="margin-top: 4px;"></span>
                    Exportar PDF
                </a>
            </div>
            <?php endif; ?>
        </div>
        
        <?php if (!empty($notas)): ?>
        <div class="nj-search-export" style="display: flex; gap: 10px; align-items: center;">
            <input type="text" id="buscar-notas" placeholder="Buscar en notas judiciales..." style="padding: 8px 12px; border: 1px solid #bdc3c7; border-radius: 4px; width: 250px;">
            <span class="description" style="color: #7f8c8d; font-size: 13px;">
                <?php echo $total_notas; ?> nota(s) registrada(s)
            </span>
        </div>
        <?php endif; ?>
    </div>

    <!-- Sección de Importación Mejorada -->
    <div class="nj-import-section" style="background: #ecf0f1; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #3498db;">
        <h3 style="margin-top: 0; color: #3498db;">
            <span class="dashicons dashicons-upload" style="margin-right: 5px;"></span>
            Importar Notas Judiciales
        </h3>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <!-- Importar desde CSV -->
            <div style="border: 1px solid #bdc3c7; padding: 15px; border-radius: 5px; background: white;">
                <h4 style="margin-top: 0; color: #3498db;">
                    <span class="dashicons dashicons-media-spreadsheet" style="margin-right: 5px;"></span>
                    Desde Archivo CSV
                </h4>
                <form method="post" enctype="multipart/form-data">
                    <input type="file" name="csv_file" accept=".csv" required style="margin-bottom: 10px; width: 100%;">
                    <button type="submit" name="importar_csv" class="button button-secondary" style="width: 100%;">
                        <span class="dashicons dashicons-upload" style="margin-top: 4px;"></span>
                        Importar CSV
                    </button>
                </form>
                <p style="margin: 10px 0 0 0; font-size: 12px; color: #7f8c8d;">
                    <strong>Formato:</strong> CSV con encabezados judiciales<br>
                    <strong>Separador:</strong> Punto y coma (;)
                </p>
            </div>

            <!-- Importar desde Foto/Imagen con OCR -->
            <div style="border: 1px solid #e74c3c; padding: 15px; border-radius: 5px; background: white;">
                <h4 style="margin-top: 0; color: #e74c3c;">
                    <span class="dashicons dashicons-camera" style="margin-right: 5px;"></span>
                    Desde Documento Escaneado (OCR)
                </h4>
                <div id="ocr-container">
                    <input type="file" id="documento_nota_ocr" accept="image/*" style="margin-bottom: 10px; width: 100%;">
                    <button type="button" id="procesar_ocr" class="button" style="width: 100%; background: #e74c3c; color: white; border-color: #e74c3c;">
                        <span class="dashicons dashicons-camera" style="margin-top: 4px;"></span>
                        Extraer Texto con OCR
                    </button>
                </div>
                <div id="ocr-progress" style="display: none; margin-top: 10px;">
                    <div style="background: #f0f0f0; border-radius: 4px; height: 20px; overflow: hidden;">
                        <div id="ocr-progress-bar" style="background: #e74c3c; height: 100%; width: 0%; transition: width 0.3s ease;"></div>
                    </div>
                    <p id="ocr-status" style="margin: 5px 0 0 0; font-size: 12px; text-align: center;">Procesando documento judicial...</p>
                </div>
                <p style="margin: 10px 0 0 0; font-size: 12px; color: #7f8c8d;">
                    <strong>Formatos:</strong> JPG, PNG, PDF<br>
                    <strong>Recomendación:</strong> Documentos claros y legibles
                </p>
            </div>
        </div>
        
        <div style="margin-top: 15px; padding: 15px; background: #fff8e7; border-radius: 5px; border-left: 4px solid #f39c12;">
            <h4 style="margin-top: 0; color: #cc8500;">
                <span class="dashicons dashicons-info" style="margin-right: 5px;"></span>
                Información sobre Importación Judicial
            </h4>
            <p style="margin: 5px 0; font-size: 13px;">
                <strong>CSV:</strong> Formato estructurado ideal para migraciones masivas de expedientes.<br>
                <strong>OCR:</strong> Extrae texto de documentos judiciales escaneados usando inteligencia artificial.
            </p>
        </div>
    </div>
    
    <?php if (empty($notas)): ?>
        <div class="notice notice-info" style="padding: 20px; text-align: center;">
            <h3 style="margin-top: 0;">⚖️ Comienza tu Registro Judicial</h3>
            <p>No hay notas judiciales registradas en el sistema. Crea la primera nota para comenzar a llevar el registro de tus casos judiciales.</p>
            <p style="margin-top: 15px;">
                <a href="<?php echo admin_url('admin.php?page=nj-registro-notas&action=nuevo'); ?>" class="button button-primary button-large">
                    <span class="dashicons dashicons-plus"></span>
                    Crear la primera nota judicial
                </a>
            </p>
        </div>
    <?php else: ?>
        <div class="nj-table-container">
            <table class="wp-list-table widefat fixed striped" id="tabla-notas">
                <thead>
                    <tr>
                        <th width="15%">Expediente</th>
                        <th width="10%">Fecha</th>
                        <th width="15%">Juzgado</th>
                        <th width="12%">Tipo</th>
                        <th width="10%">Estado</th>
                        <th width="28%">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($notas as $nota_item): ?>
                        <?php if (is_object($nota_item) && method_exists($nota_item, 'getExpediente')): ?>
                        <tr class="nj-nota-row" data-expediente="<?php echo esc_attr(strtolower($nota_item->getExpediente())); ?>" data-juzgado="<?php echo esc_attr(strtolower($nota_item->getJuzgado())); ?>" data-tipo="<?php echo esc_attr(strtolower($nota_item->getTipoProceso())); ?>">
                            <td>
                                <strong><?php echo esc_html($nota_item->getExpediente()); ?></strong>
                                <?php if ($nota_item->getJuez()): ?>
                                    <br>
                                    <small style="color: #666;">
                                        Juez: <?php echo esc_html($nota_item->getJuez()); ?>
                                    </small>
                                <?php endif; ?>
                                <?php if ($nota_item->getDescripcion()): ?>
                                    <br>
                                    <small style="color: #666;">
                                        <?php 
                                        $resumen = strip_tags($nota_item->getDescripcion());
                                        if (strlen($resumen) > 80) {
                                            echo esc_html(substr($resumen, 0, 80) . '...');
                                        } else {
                                            echo esc_html($resumen);
                                        }
                                        ?>
                                    </small>
                                <?php endif; ?>
                                <?php if ($nota_item->getResolucion()): ?>
                                    <br>
                                    <small style="color: #27ae60;">
                                        <span class="dashicons dashicons-yes-alt" style="font-size: 12px; margin-right: 2px;"></span>
                                        Con resolución
                                    </small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php 
                                $fecha = $nota_item->getFecha();
                                echo esc_html(date('d/m/Y', strtotime($fecha)));
                                ?>
                            </td>
                            <td>
                                <?php echo esc_html($nota_item->getJuzgado()); ?>
                            </td>
                            <td>
                                <span class="nj-badge nj-badge-<?php echo esc_attr($nota_item->getTipoProceso()); ?>" style="background: #e7f3ff; color: #3498db; padding: 4px 8px; border-radius: 3px; font-size: 12px; font-weight: 500;">
                                    <?php echo esc_html($nota_item->getTipoProceso()); ?>
                                </span>
                            </td>
                            <td>
                                <?php 
                                $estado = $nota_item->getEstado();
                                $color_estado = '';
                                switch($estado) {
                                    case 'Pendiente': $color_estado = '#f39c12'; break;
                                    case 'Resuelto': $color_estado = '#27ae60'; break;
                                    case 'Apelación': $color_estado = '#e74c3c'; break;
                                    case 'En Proceso': $color_estado = '#3498db'; break;
                                    default: $color_estado = '#95a5a6';
                                }
                                ?>
                                <span class="nj-estado-badge" style="background: <?php echo $color_estado; ?>; color: white; padding: 4px 8px; border-radius: 3px; font-size: 11px; font-weight: 500;">
                                    <?php echo esc_html($estado); ?>
                                </span>
                            </td>
                            <td>
                                <div class="nj-action-buttons" style="display: flex; gap: 5px; flex-wrap: wrap;">
                                    <a href="<?php echo admin_url('admin.php?page=nj-registro-notas&action=ver&id=' . $nota_item->getId()); ?>" class="button" title="Ver nota completa" style="padding: 4px 8px; font-size: 12px;">
                                        <span class="dashicons dashicons-visibility" style="font-size: 14px; margin-top: 2px;"></span>
                                        Ver
                                    </a>
                                    <a href="<?php echo admin_url('admin.php?page=nj-registro-notas&action=editar&id=' . $nota_item->getId()); ?>" class="button" title="Editar nota" style="padding: 4px 8px; font-size: 12px;">
                                        <span class="dashicons dashicons-edit" style="font-size: 14px; margin-top: 2px;"></span>
                                        Editar
                                    </a>
                                    <a href="<?php echo admin_url('admin.php?page=nj-registro-notas&export=csv&id=' . $nota_item->getId()); ?>" class="button" title="Exportar a CSV" style="padding: 4px 8px; font-size: 12px; background: #3498db; color: white; border-color: #3498db;">
                                        <span class="dashicons dashicons-media-spreadsheet" style="font-size: 14px; margin-top: 2px;"></span>
                                        CSV
                                    </a>
                                    <a href="<?php echo admin_url('admin.php?page=nj-registro-notas&export=pdf_individual&id=' . $nota_item->getId()); ?>" class="button" title="Exportar a PDF" style="padding: 4px 8px; font-size: 12px; background: #e74c3c; color: white; border-color: #e74c3c;">
                                        <span class="dashicons dashicons-media-document" style="font-size: 14px; margin-top: 2px;"></span>
                                        PDF
                                    </a>
                                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=nj-registro-notas&action=eliminar&id=' . $nota_item->getId()), 'eliminar_nota_' . $nota_item->getId()); ?>" 
                                       class="button button-link-delete" 
                                       title="Eliminar nota" 
                                       style="padding: 4px 8px; font-size: 12px; color: #e74c3c; border-color: #e74c3c;"
                                       onclick="return confirm('¿Está seguro de que desea eliminar esta nota judicial?\n\nExpediente: <?php echo esc_js($nota_item->getExpediente()); ?>\nFecha: <?php echo esc_js(date('d/m/Y', strtotime($nota_item->getFecha()))); ?>');">
                                        <span class="dashicons dashicons-trash" style="font-size: 14px; margin-top: 2px;"></span>
                                        Eliminar
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Expediente</th>
                        <th>Fecha</th>
                        <th>Juzgado</th>
                        <th>Tipo</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Incluir Tesseract.js desde CDN -->
<script src="https://cdn.jsdelivr.net/npm/tesseract.js@4/dist/tesseract.min.js"></script>

<script>
jQuery(document).ready(function($) {
    // OCR Functionality para notas judiciales
    const ocrButton = document.getElementById('procesar_ocr');
    const fileInput = document.getElementById('documento_nota_ocr');
    const progressDiv = document.getElementById('ocr-progress');
    const progressBar = document.getElementById('ocr-progress-bar');
    const statusText = document.getElementById('ocr-status');
    
    if (ocrButton && fileInput) {
        ocrButton.addEventListener('click', async () => {
            const file = fileInput.files[0];
            
            if (!file) {
                alert('Por favor, selecciona un documento judicial primero.');
                return;
            }
            
            // Validar tipo de archivo
            const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
            if (!validTypes.includes(file.type)) {
                alert('Por favor, selecciona un documento válido (JPG, PNG, WebP o PDF).');
                return;
            }
            
            // Validar tamaño (max 10MB)
            if (file.size > 10 * 1024 * 1024) {
                alert('El documento es demasiado grande. El tamaño máximo es 10MB.');
                return;
            }
            
            // Mostrar progreso
            progressDiv.style.display = 'block';
            progressBar.style.width = '0%';
            statusText.textContent = 'Inicializando OCR para documento judicial...';
            ocrButton.disabled = true;
            
            try {
                // Inicializar Tesseract
                statusText.textContent = 'Cargando motor OCR...';
                progressBar.style.width = '10%';
                
                const worker = await Tesseract.createWorker('spa+eng'); // Español e Inglés
                
                statusText.textContent = 'Reconociendo texto del documento...';
                progressBar.style.width = '30%';
                
                // Procesar la imagen
                const { data: { text, confidence } } = await worker.recognize(file, {
                    logger: m => {
                        if (m.status === 'recognizing text') {
                            const progress = Math.round(m.progress * 50) + 30; // 30-80%
                            progressBar.style.width = progress + '%';
                            statusText.textContent = `Procesando documento: ${Math.round(m.progress * 100)}%`;
                        }
                    }
                });
                
                progressBar.style.width = '90%';
                statusText.textContent = 'Finalizando...';
                
                // Terminar el worker
                await worker.terminate();
                
                progressBar.style.width = '100%';
                statusText.textContent = '¡Completado!';
                
                // Mostrar resultados
                setTimeout(() => {
                    if (text.trim().length === 0) {
                        alert('No se pudo extraer texto del documento judicial. Intenta con un documento más claro o mejor escaneado.');
                        progressDiv.style.display = 'none';
                        ocrButton.disabled = false;
                        return;
                    }
                    
                    // Calcular confianza
                    const confianzaPorcentaje = Math.round(confidence * 100);
                    
                    // Mostrar confirmación antes de proceder
                    const confirmar = confirm(
                        `OCR completado con ${confianzaPorcentaje}% de confianza.\n\n` +
                        `¿Deseas proceder a editar el texto extraído del documento judicial?`
                    );
                    
                    if (confirmar) {
                        // Codificar el texto para URL y redirigir
                        const textoCodificado = btoa(unescape(encodeURIComponent(text)));
                        window.location.href = `<?php echo admin_url('admin.php?page=nj-registro-notas&ocr_edit=1&text='); ?>${textoCodificado}`;
                    } else {
                        progressDiv.style.display = 'none';
                        ocrButton.disabled = false;
                    }
                    
                }, 1000);
                
            } catch (error) {
                console.error('Error en OCR:', error);
                statusText.textContent = 'Error: ' + error.message;
                progressBar.style.backgroundColor = '#e74c3c';
                
                setTimeout(() => {
                    progressDiv.style.display = 'none';
                    ocrButton.disabled = false;
                    alert('Error al procesar el documento judicial: ' + error.message);
                }, 2000);
            }
        });
    }
    
    // Resto del código para gráficos interactivos...
    const datosGraficos = <?php echo json_encode($datos_grafico_json); ?>;
    let metricaActual = '<?php echo $metricas_seleccionadas; ?>';
    let tipoGraficoActual = '<?php echo $tipo_grafico_seleccionado; ?>';
    
    // Inicializar el gráfico
    function inicializarGrafico() {
        cargarGrafico(metricaActual, tipoGraficoActual);
    }
    
    // Cargar gráfico
    function cargarGrafico(metrica, tipoGrafico) {
        const contenedor = $('#contenedor-grafico');
        const titulo = $('#titulo-grafico');
        const totalNotas = $('#total-notas-grafico');
        
        // Mostrar loading
        contenedor.html('<div class="nj-loading" style="text-align: center; color: #666;"><p>Cargando gráfico interactivo...</p></div>');
        
        // Simular carga
        setTimeout(function() {
            const datos = datosGraficos[metrica];
            const tituloTexto = obtenerTituloGrafico(metrica);
            const total = Object.values(datos).reduce((sum, val) => sum + val, 0);
            
            titulo.text('📈 ' + tituloTexto);
            totalNotas.text('Total: ' + total + ' notas');
            
            // Generar gráfico simple (en una implementación real, usarías una librería como Chart.js)
            const graficoHTML = generarGraficoSimple(datos, tipoGrafico, tituloTexto);
            contenedor.html(graficoHTML);
            
            // Actualizar estado de botones
            actualizarBotonesActivos();
            
        }, 500);
    }
    
    // Obtener título del gráfico
    function obtenerTituloGrafico(metrica) {
        const titulos = {
            'mes': 'Notas por Mes (Últimos 6 meses)',
            'año': 'Notas por Año',
            'tipo': 'Notas por Tipo de Proceso',
            'juzgado': 'Notas por Juzgado (Top 6)',
            'estado': 'Notas por Estado'
        };
        return titulos[metrica] || 'Gráfico de Notas Judiciales';
    }
    
    // Generar gráfico simple (placeholder)
    function generarGraficoSimple(datos, tipo, titulo) {
        if (!datos || Object.keys(datos).length === 0) {
            return '<div style="text-align: center; padding: 40px; color: #666;">No hay datos para mostrar</div>';
        }
        
        let html = '<div style="text-align: center; padding: 20px; color: #7f8c8d;">';
        html += '<p>Gráfico de ' + titulo + '</p>';
        html += '<div style="display: inline-block; text-align: left; margin-top: 20px;">';
        
        Object.entries(datos).forEach(([etiqueta, valor]) => {
            html += '<div style="margin: 10px 0; display: flex; align-items: center;">';
            html += '<span style="width: 150px; display: inline-block;">' + etiqueta + '</span>';
            html += '<span style="width: 40px; text-align: right; margin-right: 10px;">' + valor + '</span>';
            html += '<div style="width: 200px; height: 20px; background: #ecf0f1; border-radius: 3px; overflow: hidden;">';
            html += '<div style="height: 100%; background: #3498db; width: ' + (valor / Math.max(...Object.values(datos)) * 100) + '%;"></div>';
            html += '</div>';
            html += '</div>';
        });
        
        html += '</div></div>';
        return html;
    }
    
    // Actualizar botones activos
    function actualizarBotonesActivos() {
        $('.nj-metrica-btn').removeClass('button-primary').addClass('button-secondary');
        $('.nj-grafico-btn').removeClass('button-primary').addClass('button-secondary');
        
        $(`.nj-metrica-btn[data-metrica="${metricaActual}"]`).removeClass('button-secondary').addClass('button-primary');
        $(`.nj-grafico-btn[data-grafico="${tipoGraficoActual}"]`).removeClass('button-secondary').addClass('button-primary');
    }
    
    // Event listeners para botones
    $('.nj-metrica-btn').on('click', function() {
        metricaActual = $(this).data('metrica');
        cargarGrafico(metricaActual, tipoGraficoActual);
    });
    
    $('.nj-grafico-btn').on('click', function() {
        tipoGraficoActual = $(this).data('grafico');
        cargarGrafico(metricaActual, tipoGraficoActual);
    });
    
    // Búsqueda en tiempo real
    $('#buscar-notas').on('keyup', function() {
        var searchText = $(this).val().toLowerCase();
        var resultados = 0;
        
        $('.nj-nota-row').each(function() {
            var expediente = $(this).data('expediente');
            var juzgado = $(this).data('juzgado');
            var tipo = $(this).data('tipo');
            
            if (expediente.indexOf(searchText) > -1 || 
                juzgado.indexOf(searchText) > -1 || 
                tipo.indexOf(searchText) > -1) {
                $(this).show();
                resultados++;
            } else {
                $(this).hide();
            }
        });
        
        $('.description').text(resultados + ' nota(s) encontrada(s)');
    });
    
    // Ordenar por fecha (más reciente primero)
    var rows = $('.nj-nota-row').get();
    rows.sort(function(a, b) {
        var dateA = new Date($(a).find('td:nth-child(2)').text().split('/').reverse().join('-'));
        var dateB = new Date($(b).find('td:nth-child(2)').text().split('/').reverse().join('-'));
        return dateB - dateA;
    });
    
    $.each(rows, function(index, row) {
        $('#tabla-notas tbody').append(row);
    });
    
    // Inicializar el gráfico al cargar la página
    inicializarGrafico();
});
</script>

<style>
.nj-table-container {
    margin-top: 20px;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

.nj-badge-civil {
    background: #e7f3ff !important;
    color: #3498db !important;
}

.nj-badge-penal {
    background: #ffe7e7 !important;
    color: #e74c3c !important;
}

.nj-badge-laboral {
    background: #fff7e7 !important;
    color: #f39c12 !important;
}

.nj-badge-mercantil {
    background: #f0e7ff !important;
    color: #9b59b6 !important;
}

.nj-badge-administrativo {
    background: #e7fff0 !important;
    color: #27ae60 !important;
}

.nj-badge-constitucional {
    background: #fff0f7 !important;
    color: #e84393 !important;
}

.nj-badge-familia {
    background: #f0f7ff !important;
    color: #0984e3 !important;
}

.nj-badge-otro {
    background: #f8f8f8 !important;
    color: #7f8c8d !important;
}

@media (max-width: 768px) {
    .nj-stats-container {
        grid-template-columns: 1fr !important;
    }
    
    .nj-header-actions {
        flex-direction: column;
        gap: 15px;
        align-items: flex-start !important;
    }
    
    .nj-action-buttons {
        flex-direction: column;
    }
    
    #buscar-notas {
        width: 100% !important;
    }
    
    .nj-import-section > div {
        grid-template-columns: 1fr !important;
    }
}
</style>