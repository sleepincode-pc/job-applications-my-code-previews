<?php
if (!defined('ABSPATH')) {
    exit;
}

// Verificar que $acta esté definida y sea un objeto válido
if (!isset($acta) || !is_object($acta) || !method_exists($acta, 'getTitulo')) {
    echo '<div class="notice notice-error"><p>Error: No se pudo cargar la información del acta.</p></div>';
    echo '<p><a href="' . admin_url('admin.php?page=ac-libro-actas') . '" class="button">Volver al listado</a></p>';
    return;
}
?>

<div class="wrap asociacion-civil">
    <h1 class="wp-heading-inline">Acta: <?php echo esc_html($acta->getTitulo()); ?></h1>
    
    <div class="ac-action-buttons">
        <a href="<?php echo admin_url('admin.php?page=ac-libro-actas&action=editar&id=' . $acta->getId()); ?>" class="button button-primary">
            Editar Acta
        </a>
        <a href="<?php echo admin_url('admin.php?page=ac-libro-actas'); ?>" class="button">
            Volver al listado
        </a>
        <a href="<?php echo admin_url('admin.php?page=ac-libro-actas&action=editar&id=' . $acta->getId() . '&print=1'); ?>" class="button" target="_blank">
            Imprimir
        </a>
    </div>
    
    <hr class="wp-header-end">
    
    <div class="ac-admin-container">
        <div class="ac-acta-view">
            <!-- Encabezado del acta -->
            <div class="ac-acta-header">
                <div class="ac-acta-title">
                    <h2><?php echo esc_html($acta->getTitulo()); ?></h2>
                </div>
                <div class="ac-acta-meta">
                    <div class="ac-meta-item">
                        <strong>Fecha:</strong> <?php echo esc_html($acta->getFecha()); ?>
                    </div>
                    <div class="ac-meta-item">
                        <strong>Lugar:</strong> <?php echo esc_html($acta->getLugar()); ?>
                    </div>
                    <div class="ac-meta-item">
                        <strong>Tipo:</strong> 
                        <span class="ac-badge ac-badge-<?php echo esc_attr($acta->getTipo()); ?>">
                            <?php echo esc_html($acta->getTipo()); ?>
                        </span>
                    </div>
                </div>
            </div>
            
            <!-- Contenido del acta -->
            <div class="ac-acta-content">
                <?php if ($acta->getContenido()): ?>
                    <div class="ac-acta-section">
                        <h3>Desarrollo de la Reunión</h3>
                        <div class="ac-acta-text">
                            <?php echo wpautop(wp_kses_post($acta->getContenido())); ?>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if ($acta->getAsistentes()): ?>
                    <div class="ac-acta-section">
                        <h3>Lista de Asistentes</h3>
                        <div class="ac-acta-text">
                            <?php echo wpautop(wp_kses_post($acta->getAsistentes())); ?>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if ($acta->getAcuerdos()): ?>
                    <div class="ac-acta-section">
                        <h3>Acuerdos y Resoluciones</h3>
                        <div class="ac-acta-text">
                            <?php echo wpautop(wp_kses_post($acta->getAcuerdos())); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Pie del acta -->
            <div class="ac-acta-footer">
                <div class="ac-acta-dates">
                    <p><strong>Fecha de creación:</strong> <?php echo esc_html($acta->getFechaCreacion()); ?></p>
                    <?php if ($acta->getFechaActualizacion() && $acta->getFechaActualizacion() !== $acta->getFechaCreacion()): ?>
                        <p><strong>Última actualización:</strong> <?php echo esc_html($acta->getFechaActualizacion()); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>