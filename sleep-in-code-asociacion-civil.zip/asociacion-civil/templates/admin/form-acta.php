<?php
if (!defined('ABSPATH')) {
    exit;
}

// Determinar si es nuevo o edición
$es_nuevo = !isset($acta) || !$acta->getId();
$titulo_pagina = $es_nuevo ? 'Nueva Acta' : 'Editar Acta: ' . esc_html($acta->getTitulo());
$accion = $es_nuevo ? 'nuevo' : 'editar';
$id_acta = $es_nuevo ? 0 : $acta->getId();

// Valores por defecto para nuevo acta
$titulo = $es_nuevo ? '' : $acta->getTitulo();
$fecha = $es_nuevo ? date('Y-m-d') : $acta->getFecha();
$lugar = $es_nuevo ? '' : $acta->getLugar();
$tipo = $es_nuevo ? 'reunion' : $acta->getTipo();
$contenido = $es_nuevo ? '' : $acta->getContenido();
$asistentes = $es_nuevo ? '' : $acta->getAsistentes();
$acuerdos = $es_nuevo ? '' : $acta->getAcuerdos();
?>

<div class="wrap asociacion-civil">
    <h1 class="wp-heading-inline"><?php echo $titulo_pagina; ?></h1>
    
    <div class="ac-action-buttons">
        <a href="<?php echo admin_url('admin.php?page=ac-libro-actas'); ?>" class="button">
            ← Volver al listado
        </a>
    </div>
    
    <hr class="wp-header-end">
    
    <div class="ac-admin-container">
        <form method="post" action="" class="ac-form">
            <?php wp_nonce_field('guardar_acta', 'acta_nonce'); ?>
            
            <?php if (!$es_nuevo): ?>
                <input type="hidden" name="id" value="<?php echo $id_acta; ?>">
            <?php endif; ?>
            
            <div class="ac-form-section">
                <h2>Información Básica</h2>
                
                <div class="ac-form-row">
                    <div class="ac-form-column">
                        <label for="titulo">Título del Acta *</label>
                        <input type="text" id="titulo" name="titulo" value="<?php echo esc_attr($titulo); ?>" required class="regular-text">
                    </div>
                </div>
                
                <div class="ac-form-row">
                    <div class="ac-form-column">
                        <label for="fecha">Fecha *</label>
                        <input type="date" id="fecha" name="fecha" value="<?php echo esc_attr($fecha); ?>" required class="regular-text">
                    </div>
                    
                    <div class="ac-form-column">
                        <label for="lugar">Lugar</label>
                        <input type="text" id="lugar" name="lugar" value="<?php echo esc_attr($lugar); ?>" class="regular-text" placeholder="Ej: Sala de reuniones principal">
                    </div>
                    
                    <div class="ac-form-column">
                        <label for="tipo">Tipo de Reunión *</label>
                        <select id="tipo" name="tipo" required class="regular-text">
                            <option value="reunion" <?php selected($tipo, 'reunion'); ?>>Reunión Ordinaria</option>
                            <option value="asamblea" <?php selected($tipo, 'asamblea'); ?>>Asamblea</option>
                            <option value="extraordinaria" <?php selected($tipo, 'extraordinaria'); ?>>Reunión Extraordinaria</option>
                            <option value="junta" <?php selected($tipo, 'junta'); ?>>Junta Directiva</option>
                            <option value="comision" <?php selected($tipo, 'comision'); ?>>Comisión</option>
                            <option value="otro" <?php selected($tipo, 'otro'); ?>>Otro</option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="ac-form-section">
                <h2>Contenido del Acta</h2>
                
                <div class="ac-form-row">
                    <div class="ac-form-full">
                        <label for="contenido">Desarrollo de la Reunión</label>
                        <textarea id="contenido" name="contenido" rows="10" class="large-text" placeholder="Describa los puntos tratados, discusiones y desarrollo general de la reunión..."><?php echo esc_textarea($contenido); ?></textarea>
                        <p class="description">Describa detalladamente el desarrollo de la reunión, puntos tratados y discusiones.</p>
                    </div>
                </div>
            </div>
            
            <div class="ac-form-section">
                <h2>Asistentes</h2>
                
                <div class="ac-form-row">
                    <div class="ac-form-full">
                        <label for="asistentes">Lista de Asistentes</label>
                        <textarea id="asistentes" name="asistentes" rows="6" class="large-text" placeholder="Liste los nombres de las personas que asistieron a la reunión, uno por línea..."><?php echo esc_textarea($asistentes); ?></textarea>
                        <p class="description">Ingrese los nombres de los asistentes, uno por línea. Puede incluir cargos si es necesario.</p>
                    </div>
                </div>
            </div>
            
            <div class="ac-form-section">
                <h2>Acuerdos y Resoluciones</h2>
                
                <div class="ac-form-row">
                    <div class="ac-form-full">
                        <label for="acuerdos">Acuerdos Tomados</label>
                        <textarea id="acuerdos" name="acuerdos" rows="8" class="large-text" placeholder="Describa los acuerdos, resoluciones y decisiones tomadas durante la reunión..."><?php echo esc_textarea($acuerdos); ?></textarea>
                        <p class="description">Describa detalladamente los acuerdos, resoluciones y decisiones tomadas durante la reunión.</p>
                    </div>
                </div>
            </div>
            
            <div class="ac-form-actions">
                <button type="submit" name="guardar_acta" class="button button-primary button-large">
                    <?php echo $es_nuevo ? 'Crear Acta' : 'Actualizar Acta'; ?>
                </button>
                
                <a href="<?php echo admin_url('admin.php?page=ac-libro-actas'); ?>" class="button button-large">
                    Cancelar
                </a>
            </div>
        </form>
    </div>
</div>

<style>
.ac-admin-container {
    max-width: 1200px;
    margin: 20px 0;
}

.ac-form-section {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 4px;
    padding: 20px;
    margin-bottom: 20px;
}

.ac-form-section h2 {
    margin-top: 0;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
    color: #23282d;
}

.ac-form-row {
    display: flex;
    gap: 20px;
    margin-bottom: 15px;
}

.ac-form-column {
    flex: 1;
}

.ac-form-full {
    flex: 1;
}

.ac-form-actions {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 4px;
    padding: 20px;
    text-align: right;
}

.ac-form-actions .button {
    margin-left: 10px;
}

label {
    display: block;
    margin-bottom: 5px;
    font-weight: 600;
}

input[type="text"],
input[type="date"],
input[type="email"],
input[type="tel"],
select,
textarea {
    width: 100%;
}

.regular-text {
    width: 100%;
}

.large-text {
    width: 100%;
    min-height: 120px;
}

.description {
    color: #666;
    font-style: italic;
    margin-top: 5px;
}

@media (max-width: 768px) {
    .ac-form-row {
        flex-direction: column;
        gap: 15px;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Validación básica del formulario
    $('.ac-form').on('submit', function(e) {
        var titulo = $('#titulo').val().trim();
        var fecha = $('#fecha').val();
        var tipo = $('#tipo').val();
        
        if (!titulo) {
            alert('Por favor, ingrese un título para el acta.');
            $('#titulo').focus();
            e.preventDefault();
            return false;
        }
        
        if (!fecha) {
            alert('Por favor, seleccione una fecha.');
            $('#fecha').focus();
            e.preventDefault();
            return false;
        }
        
        if (!tipo) {
            alert('Por favor, seleccione un tipo de reunión.');
            $('#tipo').focus();
            e.preventDefault();
            return false;
        }
    });
    
    // Inicializar datepicker si es necesario
    if ($.fn.datepicker) {
        $('#fecha').datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true,
            yearRange: '-10:+1'
        });
    }
});
</script>