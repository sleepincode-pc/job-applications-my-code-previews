<?php
if (!defined('ABSPATH')) {
    exit;
}

// Verificar que $psicodramas esté definida y sea un array
if (!isset($psicodramas) || !is_array($psicodramas)) {
    $psicodramas = array();
}

// Verificar que $facilitadores esté definida y sea un array  
if (!isset($facilitadores) || !is_array($facilitadores)) {
    $facilitadores = array();
}

// Manejar exportaciones
if (isset($_GET['export'])) {
    $export_type = $_GET['export'];
    
    if ($export_type === 'csv') {
        ac_exportar_psicodramas_csv($psicodramas);
    } elseif ($export_type === 'pdf') {
        ac_exportar_psicodramas_pdf($psicodramas);
    } elseif ($export_type === 'pdf_individual' && isset($_GET['id'])) {
        $psicodrama_id = intval($_GET['id']);
        $psicodrama_individual = null;
        
        foreach ($psicodramas as $psicodrama) {
            if ($psicodrama->getId() === $psicodrama_id) {
                $psicodrama_individual = $psicodrama;
                break;
            }
        }
        
        if ($psicodrama_individual) {
            ac_exportar_psicodrama_pdf_individual($psicodrama_individual);
        }
    }
}

// Funciones de exportación para psicodramas
function ac_exportar_psicodramas_csv($psicodramas) {
    $filename = 'psicodramas_' . date('Y-m-d') . '.csv';
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $output = fopen('php://output', 'w');
    fputs($output, "\xEF\xBB\xBF");
    
    // Encabezados
    fputcsv($output, array(
        'ID', 'Título', 'Fecha Sesión', 'Duración (min)', 'Facilitador', 
        'Cofacilitador', 'Participantes', 'Tema Central', 'Técnica', 'Estado'
    ), ';');
    
    // Datos
    foreach ($psicodramas as $psicodrama) {
        if (is_object($psicodrama) && method_exists($psicodrama, 'getTitulo')) {
            fputcsv($output, array(
                $psicodrama->getId(),
                $psicodrama->getTitulo(),
                $psicodrama->getFechaSesion(),
                $psicodrama->getDuracion(),
                $psicodrama->getFacilitadorNombre(),
                $psicodrama->getCofacilitadorNombre(),
                $psicodrama->getNumeroParticipantes(),
                $psicodrama->getTemaCentral(),
                $psicodrama->getTecnicaNombre(),
                $psicodrama->getEstadoNombre()
            ), ';');
        }
    }
    
    fclose($output);
    exit;
}

function ac_exportar_psicodramas_pdf($psicodramas) {
    $filename = 'psicodramas_' . date('Y-m-d') . '.pdf';
    
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Reporte de Psicodramas</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { text-align: center; color: #333; }
            h2 { color: #0073aa; background-color: #f8f9fa; padding: 10px; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .section { margin-bottom: 30px; border: 1px solid #ddd; padding: 15px; }
            .psicodrama-info { background-color: #f0f8ff; }
            .escenas { border-color: #46b450; background-color: #f0fff0; }
            .insights { border-color: #ffb900; background-color: #fff8e7; }
        </style>
    </head>
    <body>
        <h1>Reporte de Psicodramas</h1>
        <p style="text-align: center;">Exportado el: ' . date('d/m/Y H:i:s') . '</p>
        <p style="text-align: center;">Total de psicodramas: ' . count($psicodramas) . '</p>
        <hr>';
    
    foreach ($psicodramas as $index => $psicodrama) {
        if (is_object($psicodrama) && method_exists($psicodrama, 'getTitulo')) {
            $html .= '<div class="section psicodrama-info">
                <h2>Psicodrama #' . ($index + 1) . ' - ' . $psicodrama->getTitulo() . '</h2>
                <table>
                    <tr><td style="width: 30%; font-weight: bold;">Fecha Sesión:</td><td>' . date('d/m/Y H:i', strtotime($psicodrama->getFechaSesion())) . '</td></tr>
                    <tr><td style="font-weight: bold;">Facilitador:</td><td>' . $psicodrama->getFacilitadorNombre() . '</td></tr>
                    <tr><td style="font-weight: bold;">Cofacilitador:</td><td>' . $psicodrama->getCofacilitadorNombre() . '</td></tr>
                    <tr><td style="font-weight: bold;">Duración:</td><td>' . $psicodrama->getDuracion() . ' minutos</td></tr>
                    <tr><td style="font-weight: bold;">Técnica:</td><td>' . $psicodrama->getTecnicaNombre() . '</td></tr>
                    <tr><td style="font-weight: bold;">Estado:</td><td>' . $psicodrama->getEstadoNombre() . '</td></tr>
                    <tr><td style="font-weight: bold;">Participantes:</td><td>' . $psicodrama->getNumeroParticipantes() . '</td></tr>
                </table>';
            
            if ($psicodrama->getTemaCentral()) {
                $html .= '<h4>Tema Central:</h4>
                <div style="border: 1px solid #ddd; padding: 10px; background-color: #f9f9f9;">
                    ' . nl2br($psicodrama->getTemaCentral()) . '
                </div>';
            }
            
            if ($psicodrama->getDescripcion()) {
                $html .= '<h4>Descripción:</h4>
                <div style="border: 1px solid #ddd; padding: 10px; background-color: #f9f9f9;">
                    ' . nl2br($psicodrama->getDescripcion()) . '
                </div>';
            }
            
            $escenas = $psicodrama->getEscenasDesarrolladas();
            if (!empty($escenas) && is_array($escenas)) {
                $html .= '<h4>Escenas Desarrolladas:</h4>
                <div class="escenas">';
                foreach ($escenas as $escena) {
                    $html .= '<div style="margin-bottom: 15px; padding: 10px; border-bottom: 1px solid #46b450;">
                        <strong>' . esc_html($escena['titulo']) . '</strong><br>
                        ' . nl2br(strip_tags($escena['descripcion'])) . '
                    </div>';
                }
                $html .= '</div>';
            }
            
            $insights = $psicodrama->getInsightsPrincipales();
            if (!empty($insights) && is_array($insights)) {
                $html .= '<h4>Insights Principales:</h4>
                <div class="insights">';
                foreach ($insights as $insight) {
                    $html .= '<div style="margin-bottom: 10px; padding: 8px; border-left: 3px solid #ffb900;">
                        ' . nl2br(strip_tags($insight['texto'])) . '
                    </div>';
                }
                $html .= '</div>';
            }
            
            if ($psicodrama->getObservaciones()) {
                $html .= '<h4>Observaciones:</h4>
                <div style="border: 1px solid #dc3232; padding: 10px; background-color: #fff0f0;">
                    ' . nl2br($psicodrama->getObservaciones()) . '
                </div>';
            }
            
            $html .= '</div><hr style="margin: 20px 0;">';
        }
    }
    
    $html .= '</body></html>';
    
    echo $html;
    exit;
}

function ac_exportar_psicodrama_pdf_individual($psicodrama) {
    $filename = 'psicodrama_' . sanitize_title($psicodrama->getTitulo()) . '_' . date('Y-m-d') . '.pdf';
    
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Psicodrama - ' . $psicodrama->getTitulo() . '</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 30px; line-height: 1.6; }
            h1 { text-align: center; color: #333; margin-bottom: 10px; }
            h2 { text-align: center; color: #0073aa; margin-bottom: 30px; }
            .header-info { margin-bottom: 30px; }
            .info-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            .info-table td { padding: 8px; border-bottom: 1px solid #eee; }
            .info-table td:first-child { font-weight: bold; width: 25%; }
            .section { margin-bottom: 25px; }
            .section-title { color: #555; border-bottom: 2px solid #0073aa; padding-bottom: 5px; margin-bottom: 10px; }
            .content-box { border: 1px solid #ddd; padding: 15px; background-color: #f9f9f9; margin-bottom: 15px; }
            .escenas-box { border-color: #46b450; background-color: #f0fff0; }
            .insights-box { border-color: #ffb900; background-color: #fff8e7; }
            .participantes-box { border-color: #667eea; background-color: #f0f8ff; }
            .footer { text-align: center; margin-top: 40px; color: #666; font-size: 12px; }
        </style>
    </head>
    <body>
        <h1>INFORME DE PSICODRAMA</h1>
        <h2>' . $psicodrama->getTitulo() . '</h2>
        
        <div class="header-info">
            <table class="info-table">
                <tr>
                    <td>Fecha de Sesión:</td>
                    <td>' . date('d/m/Y H:i', strtotime($psicodrama->getFechaSesion())) . '</td>
                </tr>
                <tr>
                    <td>Facilitador:</td>
                    <td>' . $psicodrama->getFacilitadorNombre() . '</td>
                </tr>
                <tr>
                    <td>Cofacilitador:</td>
                    <td>' . $psicodrama->getCofacilitadorNombre() . '</td>
                </tr>
                <tr>
                    <td>Duración:</td>
                    <td>' . $psicodrama->getDuracion() . ' minutos</td>
                </tr>
                <tr>
                    <td>Técnica Utilizada:</td>
                    <td>' . $psicodrama->getTecnicaNombre() . '</td>
                </tr>
                <tr>
                    <td>Estado:</td>
                    <td>' . $psicodrama->getEstadoNombre() . '</td>
                </tr>
                <tr>
                    <td>Número de Participantes:</td>
                    <td>' . $psicodrama->getNumeroParticipantes() . '</td>
                </tr>
            </table>
        </div>';
    
    if ($psicodrama->getTemaCentral()) {
        $html .= '<div class="section">
            <h3 class="section-title">TEMA CENTRAL</h3>
            <div class="content-box">' . nl2br($psicodrama->getTemaCentral()) . '</div>
        </div>';
    }
    
    if ($psicodrama->getDescripcion()) {
        $html .= '<div class="section">
            <h3 class="section-title">DESCRIPCIÓN DE LA SESIÓN</h3>
            <div class="content-box">' . nl2br($psicodrama->getDescripcion()) . '</div>
        </div>';
    }
    
    $participantes = $psicodrama->getParticipantesNombres();
    if (!empty($participantes)) {
        $html .= '<div class="section">
            <h3 class="section-title">PARTICIPANTES</h3>
            <div class="content-box participantes-box">
                <ul>';
        foreach ($participantes as $participante) {
            $html .= '<li>' . esc_html($participante) . '</li>';
        }
        $html .= '</ul>
            </div>
        </div>';
    }
    
    $escenas = $psicodrama->getEscenasDesarrolladas();
    if (!empty($escenas) && is_array($escenas)) {
        $html .= '<div class="section">
            <h3 class="section-title">ESCENAS DESARROLLADAS</h3>
            <div class="content-box escenas-box">';
        foreach ($escenas as $index => $escena) {
            $html .= '<div style="margin-bottom: 20px;">
                <h4 style="color: #46b450; margin-bottom: 5px;">Escena ' . ($index + 1) . ': ' . esc_html($escena['titulo']) . '</h4>
                <div style="padding-left: 15px;">' . nl2br(strip_tags($escena['descripcion'])) . '</div>
            </div>';
        }
        $html .= '</div>
        </div>';
    }
    
    $insights = $psicodrama->getInsightsPrincipales();
    if (!empty($insights) && is_array($insights)) {
        $html .= '<div class="section">
            <h3 class="section-title">INSIGHTS PRINCIPALES</h3>
            <div class="content-box insights-box">';
        foreach ($insights as $index => $insight) {
            $html .= '<div style="margin-bottom: 15px; padding: 10px; border-left: 3px solid #ffb900;">
                <strong>Insight ' . ($index + 1) . ':</strong><br>
                ' . nl2br(strip_tags($insight['texto'])) . '
            </div>';
        }
        $html .= '</div>
        </div>';
    }
    
    if ($psicodrama->getObservaciones()) {
        $html .= '<div class="section">
            <h3 class="section-title">OBSERVACIONES DEL FACILITADOR</h3>
            <div class="content-box">' . nl2br($psicodrama->getObservaciones()) . '</div>
        </div>';
    }
    
    if ($psicodrama->getProximaSesion()) {
        $html .= '<div class="section">
            <h3 class="section-title">PRÓXIMA SESIÓN PROGRAMADA</h3>
            <div class="content-box" style="border-color: #667eea; background-color: #f0f8ff;">
                ' . date('d/m/Y H:i', strtotime($psicodrama->getProximaSesion())) . '
            </div>
        </div>';
    }
    
    $html .= '<div class="footer">
            Documento generado el ' . date('d/m/Y H:i:s') . '<br>
            ' . get_bloginfo('name') . ' - Área de Psicodrama
        </div>
    </body>
    </html>';
    
    echo $html;
    exit;
}

// Manejar guardado de psicodrama desde formulario
if (isset($_POST['guardar_psicodrama'])) {
    ac_guardar_psicodrama();
}

function ac_guardar_psicodrama() {
    // Verificar nonce para seguridad
    if (!wp_verify_nonce($_POST['_wpnonce'], 'guardar_psicodrama')) {
        wp_die('Error de seguridad');
    }
    
    $titulo = sanitize_text_field($_POST['titulo']);
    $descripcion = sanitize_textarea_field($_POST['descripcion']);
    $fecha_sesion = sanitize_text_field($_POST['fecha_sesion']);
    $duracion = intval($_POST['duracion']);
    $facilitador_id = intval($_POST['facilitador_id']);
    $cofacilitador_id = !empty($_POST['cofacilitador_id']) ? intval($_POST['cofacilitador_id']) : null;
    $participantes = isset($_POST['participantes']) ? array_map('intval', $_POST['participantes']) : array();
    $tema_central = sanitize_text_field($_POST['tema_central']);
    $tecnica_utilizada = sanitize_text_field($_POST['tecnica_utilizada']);
    $observaciones = sanitize_textarea_field($_POST['observaciones']);
    $estado = sanitize_text_field($_POST['estado']);
    $proxima_sesion = !empty($_POST['proxima_sesion']) ? sanitize_text_field($_POST['proxima_sesion']) : null;
    
    // Aquí deberías llamar a tu función para guardar el psicodrama en la base de datos
    // Por ejemplo:
    // $psicodrama_id = guardar_psicodrama($titulo, $descripcion, $fecha_sesion, $duracion, $facilitador_id, $cofacilitador_id, $participantes, $tema_central, $tecnica_utilizada, $observaciones, $estado, $proxima_sesion);
    
    // Simulación de guardado exitoso
    $guardado_exitoso = true;
    
    if ($guardado_exitoso) {
        echo '<div class="notice notice-success is-dismissible">';
        echo '<p>✅ Psicodrama guardado correctamente.</p>';
        echo '</div>';
        
        // Redirigir para evitar reenvío del formulario
        echo '<script>setTimeout(function() { window.location.href = "' . admin_url('admin.php?page=ac-psicodramas') . '"; }, 2000);</script>';
    } else {
        echo '<div class="notice notice-error is-dismissible">';
        echo '<p>❌ Error al guardar el psicodrama. Por favor, inténtalo de nuevo.</p>';
        echo '</div>';
    }
}

// Estadísticas para psicodramas
$total_psicodramas = count($psicodramas);
$psicodramas_por_mes = array();
$psicodramas_por_facilitador = array();
$psicodramas_por_tecnica = array();
$psicodramas_por_estado = array();
$total_participantes = 0;
$psicodrama_mas_reciente = null;

foreach ($psicodramas as $psicodrama) {
    if (is_object($psicodrama) && method_exists($psicodrama, 'getFechaSesion')) {
        // Por mes
        $fecha = $psicodrama->getFechaSesion();
        if ($fecha) {
            $mes = date('Y-m', strtotime($fecha));
            if (!isset($psicodramas_por_mes[$mes])) {
                $psicodramas_por_mes[$mes] = 0;
            }
            $psicodramas_por_mes[$mes]++;
        }
        
        // Por facilitador
        $facilitador = $psicodrama->getFacilitadorNombre();
        if (!isset($psicodramas_por_facilitador[$facilitador])) {
            $psicodramas_por_facilitador[$facilitador] = 0;
        }
        $psicodramas_por_facilitador[$facilitador]++;
        
        // Por técnica
        $tecnica = $psicodrama->getTecnicaNombre();
        if (!isset($psicodramas_por_tecnica[$tecnica])) {
            $psicodramas_por_tecnica[$tecnica] = 0;
        }
        $psicodramas_por_tecnica[$tecnica]++;
        
        // Por estado
        $estado = $psicodrama->getEstadoNombre();
        if (!isset($psicodramas_por_estado[$estado])) {
            $psicodramas_por_estado[$estado] = 0;
        }
        $psicodramas_por_estado[$estado]++;
        
        // Total participantes
        $total_participantes += $psicodrama->getNumeroParticipantes();
        
        // Psicodrama más reciente
        if (!$psicodrama_mas_reciente || strtotime($fecha) > strtotime($psicodrama_mas_reciente->getFechaSesion())) {
            $psicodrama_mas_reciente = $psicodrama;
        }
    }
}

// Ordenar estadísticas
krsort($psicodramas_por_mes);
arsort($psicodramas_por_facilitador);
arsort($psicodramas_por_tecnica);
arsort($psicodramas_por_estado);

// Calcular promedios
$promedio_participantes = $total_psicodramas > 0 ? round($total_participantes / $total_psicodramas, 1) : 0;

// Preparar datos para gráficos
$datos_grafico_json = array();
$datos_grafico_json['mes'] = array_slice($psicodramas_por_mes, 0, 6, true);
$datos_grafico_json['facilitador'] = $psicodramas_por_facilitador;
$datos_grafico_json['tecnica'] = $psicodramas_por_tecnica;
$datos_grafico_json['estado'] = $psicodramas_por_estado;

?>

<div class="wrap">
    <h1 class="wp-heading-inline">🎭 Psicodramas</h1>
    
    <!-- Panel de Métricas para Psicodramas -->
    <div class="ac-metrics-panel" style="margin: 20px 0;">
        <h2 style="margin-bottom: 15px; color: #23282d;">📊 Métricas de Psicodramas</h2>
        
        <div class="ac-stats-container" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; margin-bottom: 20px;">
            <!-- Métrica Principal -->
            <div class="ac-stat-card" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="display: flex; justify-content: between; align-items: center;">
                    <div>
                        <h3 style="margin: 0 0 5px 0; font-size: 14px; opacity: 0.9;">TOTAL DE PSICODRAMAS</h3>
                        <p style="font-size: 32px; font-weight: bold; margin: 0;">🎭 <?php echo $total_psicodramas; ?></p>
                    </div>
                    <div style="font-size: 24px;">🎭</div>
                </div>
                <div style="margin-top: 10px; font-size: 12px; opacity: 0.8;">
                    <?php echo $total_participantes; ?> participantes • 
                    <?php echo $promedio_participantes; ?> promedio/sesión
                </div>
            </div>

            <!-- Distribución por Técnica -->
            <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #667eea; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #667eea; font-size: 14px;">DISTRIBUCIÓN POR TÉCNICA</h3>
                <div style="max-height: 120px; overflow-y: auto;">
                    <?php foreach ($psicodramas_por_tecnica as $tecnica => $cantidad): 
                        $porcentaje = $total_psicodramas > 0 ? round(($cantidad / $total_psicodramas) * 100) : 0;
                    ?>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                        <span><?php echo esc_html($tecnica); ?></span>
                        <span style="font-weight: bold;"><?php echo $cantidad; ?> (<?php echo $porcentaje; ?>%)</span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Facilitadores -->
            <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #f093fb; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #f093fb; font-size: 14px;">PSICODRAMAS POR FACILITADOR</h3>
                <div style="max-height: 120px; overflow-y: auto;">
                    <?php foreach ($psicodramas_por_facilitador as $facilitador => $cantidad): 
                        $porcentaje = $total_psicodramas > 0 ? round(($cantidad / $total_psicodramas) * 100) : 0;
                    ?>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                        <span><?php echo esc_html($facilitador); ?></span>
                        <span style="font-weight: bold;"><?php echo $cantidad; ?> (<?php echo $porcentaje; ?>%)</span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Información General -->
            <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #4facfe; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #4facfe; font-size: 14px;">INFORMACIÓN GENERAL</h3>
                <div style="display: grid; gap: 8px; font-size: 12px;">
                    <div style="display: flex; justify-content: space-between;">
                        <span>Total participantes:</span>
                        <strong><?php echo $total_participantes; ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Promedio participantes:</span>
                        <strong><?php echo $promedio_participantes; ?></strong>
                    </div>
                    <?php if ($psicodrama_mas_reciente): ?>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Último psicodrama:</span>
                        <strong><?php echo date('d/m/Y', strtotime($psicodrama_mas_reciente->getFechaSesion())); ?></strong>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Acciones Principales -->
    <div class="ac-header-actions" style="display: flex; justify-content: space-between; align-items: center; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px;">
        <div>
            <a href="<?php echo admin_url('admin.php?page=ac-psicodramas&action=nuevo'); ?>" class="button button-primary" style="font-size: 14px; padding: 8px 16px;">
                <span class="dashicons dashicons-plus" style="margin-top: 4px;"></span>
                Nuevo Psicodrama
            </a>
            <?php if (!empty($psicodramas)): ?>
            <div class="ac-export-buttons" style="display: inline-block; margin-left: 10px;">
                <a href="<?php echo admin_url('admin.php?page=ac-psicodramas&export=csv'); ?>" class="button" style="font-size: 14px; padding: 8px 16px;">
                    <span class="dashicons dashicons-media-spreadsheet" style="margin-top: 4px;"></span>
                    Exportar CSV
                </a>
                <a href="<?php echo admin_url('admin.php?page=ac-psicodramas&export=pdf'); ?>" class="button" style="font-size: 14px; padding: 8px 16px; margin-left: 5px;">
                    <span class="dashicons dashicons-media-document" style="margin-top: 4px;"></span>
                    Exportar PDF
                </a>
            </div>
            <?php endif; ?>
        </div>
        
        <?php if (!empty($psicodramas)): ?>
        <div class="ac-search-export" style="display: flex; gap: 10px; align-items: center;">
            <input type="text" id="buscar-psicodramas" placeholder="Buscar en psicodramas..." style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; width: 250px;">
            <span class="description" style="color: #666; font-size: 13px;">
                <?php echo $total_psicodramas; ?> psicodrama(s) registrado(s)
            </span>
        </div>
        <?php endif; ?>
    </div>

    <!-- Sección de Próximos Psicodramas -->
    <?php 
    $proximos_psicodramas = array_filter($psicodramas, function($psicodrama) {
        return in_array($psicodrama->getEstado(), array('planificada', 'en_curso')) && 
               strtotime($psicodrama->getFechaSesion()) >= strtotime('today');
    });
    ?>
    
    <?php if (!empty($proximos_psicodramas)): ?>
    <div class="ac-proximos-section" style="background: #f0fff0; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #46b450;">
        <h3 style="margin-top: 0; color: #46b450;">
            <span class="dashicons dashicons-calendar-alt" style="margin-right: 5px;"></span>
            Próximos Psicodramas
        </h3>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 15px;">
            <?php foreach ($proximos_psicodramas as $psicodrama): ?>
                <div class="ac-proximo-card" style="background: white; border: 1px solid #e1e5e9; border-radius: 8px; padding: 15px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px;">
                        <h4 style="margin: 0; color: #333; flex: 1;"><?php echo esc_html($psicodrama->getTitulo()); ?></h4>
                        <span class="ac-badge ac-badge-<?php echo esc_attr($psicodrama->getEstado()); ?>" 
                              style="background: <?php echo $psicodrama->getEstado() === 'planificada' ? '#fff7e6' : '#f0f8ff'; ?>; 
                                     color: <?php echo $psicodrama->getEstado() === 'planificada' ? '#fa8c16' : '#1890ff'; ?>; 
                                     padding: 4px 8px; border-radius: 3px; font-size: 11px; font-weight: 500;">
                            <?php echo esc_html($psicodrama->getEstadoNombre()); ?>
                        </span>
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <div style="font-size: 13px; color: #666; margin-bottom: 5px;">
                            <strong>📅 <?php echo date('d/m/Y H:i', strtotime($psicodrama->getFechaSesion())); ?></strong>
                        </div>
                        <div style="font-size: 12px; color: #999;">
                            👤 <?php echo esc_html($psicodrama->getFacilitadorNombre()); ?> • 
                            🎯 <?php echo esc_html($psicodrama->getTecnicaNombre()); ?>
                        </div>
                    </div>
                    
                    <div style="display: flex; gap: 5px;">
                        <a href="<?php echo admin_url('admin.php?page=ac-psicodramas&action=ver&id=' . $psicodrama->getId()); ?>" class="button" style="flex: 1; text-align: center; padding: 6px; font-size: 11px;">
                            Ver Detalles
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=ac-psicodramas&action=editar&id=' . $psicodrama->getId()); ?>" class="button button-primary" style="flex: 1; text-align: center; padding: 6px; font-size: 11px;">
                            Editar
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
    
    <?php if (empty($psicodramas)): ?>
        <div class="notice notice-info" style="padding: 20px; text-align: center;">
            <h3 style="margin-top: 0;">🎭 Comienza el Registro de Psicodramas</h3>
            <p>No hay psicodramas registrados en el sistema. Crea el primer psicodrama para comenzar el trabajo terapéutico grupal.</p>
            <p style="margin-top: 15px;">
                <a href="<?php echo admin_url('admin.php?page=ac-psicodramas&action=nuevo'); ?>" class="button button-primary button-large">
                    <span class="dashicons dashicons-plus"></span>
                    Crear el primer psicodrama
                </a>
            </p>
        </div>
    <?php else: ?>
        <div class="ac-table-container">
            <table class="wp-list-table widefat fixed striped" id="tabla-psicodramas">
                <thead>
                    <tr>
                        <th width="20%">Título</th>
                        <th width="12%">Fecha</th>
                        <th width="15%">Facilitador</th>
                        <th width="10%">Técnica</th>
                        <th width="8%">Participantes</th>
                        <th width="15%">Tema Central</th>
                        <th width="10%">Estado</th>
                        <th width="10%">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($psicodramas as $psicodrama_item): ?>
                        <?php if (is_object($psicodrama_item) && method_exists($psicodrama_item, 'getTitulo')): ?>
                        <tr class="ac-psicodrama-row" data-titulo="<?php echo esc_attr(strtolower($psicodrama_item->getTitulo())); ?>" data-facilitador="<?php echo esc_attr(strtolower($psicodrama_item->getFacilitadorNombre())); ?>" data-tecnica="<?php echo esc_attr(strtolower($psicodrama_item->getTecnicaNombre())); ?>">
                            <td>
                                <div style="display: flex; align-items: center; gap: 8px;">
                                    <div style="width: 32px; height: 32px; border-radius: 50%; background: #667eea; display: flex; align-items: center; justify-content: center; color: white; font-size: 16px;">
                                        🎭
                                    </div>
                                    <div>
                                        <strong><?php echo esc_html($psicodrama_item->getTitulo()); ?></strong>
                                        <br>
                                        <small style="color: #666;">ID: <?php echo esc_html($psicodrama_item->getId()); ?></small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <?php 
                                $fecha = $psicodrama_item->getFechaSesion();
                                echo esc_html(date('d/m/Y H:i', strtotime($fecha)));
                                ?>
                            </td>
                            <td>
                                <strong><?php echo esc_html($psicodrama_item->getFacilitadorNombre()); ?></strong>
                                <?php if ($psicodrama_item->getCofacilitadorNombre() !== 'No asignado'): ?>
                                    <br>
                                    <small style="color: #666;">Co: <?php echo esc_html($psicodrama_item->getCofacilitadorNombre()); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="ac-badge ac-badge-<?php echo esc_attr($psicodrama_item->getTecnicaUtilizada()); ?>" style="background: #f0f8ff; color: #667eea; padding: 4px 8px; border-radius: 3px; font-size: 12px; font-weight: 500;">
                                    <?php echo esc_html($psicodrama_item->getTecnicaNombre()); ?>
                                </span>
                            </td>
                            <td>
                                <span class="ac-badge" style="background: #e7f3ff; color: #0073aa; padding: 4px 8px; border-radius: 3px; font-size: 12px; font-weight: 500;">
                                    <?php echo esc_html($psicodrama_item->getNumeroParticipantes()); ?> 👥
                                </span>
                            </td>
                            <td>
                                <?php if ($psicodrama_item->getTemaCentral()): ?>
                                    <?php 
                                    $resumen = strip_tags($psicodrama_item->getTemaCentral());
                                    if (strlen($resumen) > 100) {
                                        echo esc_html(substr($resumen, 0, 100) . '...');
                                    } else {
                                        echo esc_html($resumen);
                                    }
                                    ?>
                                <?php else: ?>
                                    <span style="color: #999;">Sin tema especificado</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="ac-badge ac-badge-<?php echo esc_attr($psicodrama_item->getEstado()); ?>" 
                                      style="background: <?php echo $psicodrama_item->getEstado() === 'completada' ? '#f0fff0' : 
                                                           ($psicodrama_item->getEstado() === 'planificada' ? '#fff7e6' : 
                                                           ($psicodrama_item->getEstado() === 'en_curso' ? '#f0f8ff' : '#fff2f0')); ?>; 
                                             color: <?php echo $psicodrama_item->getEstado() === 'completada' ? '#46b450' : 
                                                     ($psicodrama_item->getEstado() === 'planificada' ? '#fa8c16' : 
                                                     ($psicodrama_item->getEstado() === 'en_curso' ? '#1890ff' : '#ff4d4f')); ?>; 
                                             padding: 4px 8px; border-radius: 3px; font-size: 12px; font-weight: 500;">
                                    <?php echo esc_html($psicodrama_item->getEstadoNombre()); ?>
                                </span>
                            </td>
                            <td>
                                <div class="ac-action-buttons" style="display: flex; gap: 5px; flex-wrap: wrap;">
                                    <a href="<?php echo admin_url('admin.php?page=ac-psicodramas&action=ver&id=' . $psicodrama_item->getId()); ?>" class="button" title="Ver psicodrama completo" style="padding: 4px 8px; font-size: 12px;">
                                        <span class="dashicons dashicons-visibility" style="font-size: 14px; margin-top: 2px;"></span>
                                        Ver
                                    </a>
                                    <a href="<?php echo admin_url('admin.php?page=ac-psicodramas&action=editar&id=' . $psicodrama_item->getId()); ?>" class="button" title="Editar psicodrama" style="padding: 4px 8px; font-size: 12px;">
                                        <span class="dashicons dashicons-edit" style="font-size: 14px; margin-top: 2px;"></span>
                                        Editar
                                    </a>
                                    <a href="<?php echo admin_url('admin.php?page=ac-psicodramas&export=pdf_individual&id=' . $psicodrama_item->getId()); ?>" class="button" title="Exportar a PDF" style="padding: 4px 8px; font-size: 12px; background: #dc3232; color: white; border-color: #dc3232;">
                                        <span class="dashicons dashicons-media-document" style="font-size: 14px; margin-top: 2px;"></span>
                                        PDF
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Título</th>
                        <th>Fecha</th>
                        <th>Facilitador</th>
                        <th>Técnica</th>
                        <th>Participantes</th>
                        <th>Tema Central</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    <?php endif; ?>
</div>

<script>
jQuery(document).ready(function($) {
    // Búsqueda en tiempo real
    $('#buscar-psicodramas').on('keyup', function() {
        var searchText = $(this).val().toLowerCase();
        var resultados = 0;
        
        $('.ac-psicodrama-row').each(function() {
            var titulo = $(this).data('titulo');
            var facilitador = $(this).data('facilitador');
            var tecnica = $(this).data('tecnica');
            
            if (titulo.indexOf(searchText) > -1 || 
                facilitador.indexOf(searchText) > -1 || 
                tecnica.indexOf(searchText) > -1) {
                $(this).show();
                resultados++;
            } else {
                $(this).hide();
            }
        });
        
        $('.description').text(resultados + ' psicodrama(s) encontrado(s)');
    });
    
    // Ordenar por fecha (más reciente primero)
    var rows = $('.ac-psicodrama-row').get();
    rows.sort(function(a, b) {
        var dateA = new Date($(a).find('td:nth-child(2)').text().split(' ')[0].split('/').reverse().join('-'));
        var dateB = new Date($(b).find('td:nth-child(2)').text().split(' ')[0].split('/').reverse().join('-'));
        return dateB - dateA;
    });
    
    $.each(rows, function(index, row) {
        $('#tabla-psicodramas tbody').append(row);
    });
});
</script>

<style>
.ac-table-container {
    margin-top: 20px;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

/* Estilos para técnicas de psicodrama */
.ac-badge-cambio_rol {
    background: #f0f8ff !important;
    color: #667eea !important;
}

.ac-badge-doble {
    background: #fff0f6 !important;
    color: #eb2f96 !important;
}

.ac-badge-espejo {
    background: #f6ffed !important;
    color: #52c41a !important;
}

.ac-badge-silla_vacia {
    background: #fff7e6 !important;
    color: #fa8c16 !important;
}

.ac-badge-soliloquio {
    background: #f9f0ff !important;
    color: #722ed1 !important;
}

.ac-badge-proyeccion {
    background: #fff2f0 !important;
    color: #ff4d4f !important;
}

.ac-badge-escultura {
    background: #f0fff0 !important;
    color: #46b450 !important;
}

.ac-badge-rol_playing {
    background: #fff8e7 !important;
    color: #cc8500 !important;
}

/* Estilos para estados */
.ac-badge-completada {
    background: #f6ffed !important;
    color: #52c41a !important;
}

.ac-badge-planificada {
    background: #fff7e6 !important;
    color: #fa8c16 !important;
}

.ac-badge-en_curso {
    background: #f0f8ff !important;
    color: #1890ff !important;
}

.ac-badge-cancelada {
    background: #fff2f0 !important;
    color: #ff4d4f !important;
}

.ac-badge-reprogramada {
    background: #f9f0ff !important;
    color: #722ed1 !important;
}

/* Responsive */
@media (max-width: 768px) {
    .ac-stats-container {
        grid-template-columns: 1fr !important;
    }
    
    .ac-header-actions {
        flex-direction: column;
        gap: 15px;
        align-items: flex-start !important;
    }
    
    .ac-action-buttons {
        flex-direction: column;
    }
    
    #buscar-psicodramas {
        width: 100% !important;
    }
    
    .ac-proximos-section > div {
        grid-template-columns: 1fr !important;
    }
    
    .ac-proximo-card {
        text-align: center;
    }
}
</style>