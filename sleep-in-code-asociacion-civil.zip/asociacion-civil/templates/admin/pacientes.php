<?php
if (!defined('ABSPATH')) {
    exit;
}

// Inicializar FileManager si no existe
if (!class_exists('AsociacionCivil\FileManager')) {
    require_once plugin_dir_path(__FILE__) . '../includes/classes/FileManager.php';
}
$file_manager = new AsociacionCivil\FileManager();
?>

<div class="wrap" style="background: white; color: black; padding: 20px;">
    <h1 class="wp-heading-inline" style="color: black;">👥 Gestión de Pacientes</h1>
    <a href="<?php echo admin_url('admin.php?page=ac-pacientes&action=nuevo'); ?>" class="page-title-action" style="color: white; background: #0073aa; text-decoration: none; padding: 8px 12px; border-radius: 4px; margin-left: 10px;">Agregar Nuevo Paciente</a>
    
    <?php if (isset($_GET['updated'])): ?>
        <div class="notice notice-success is-dismissible" style="background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 10px; margin: 15px 0;">
            <p style="margin: 0; color: #155724;">✅ Paciente guardado correctamente.</p>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['foto_uploaded'])): ?>
        <div class="notice notice-success is-dismissible" style="background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 10px; margin: 15px 0;">
            <p style="margin: 0; color: #155724;">✅ Foto subida correctamente.</p>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['deleted'])): ?>
        <div class="notice notice-success is-dismissible" style="background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 10px; margin: 15px 0;">
            <p style="margin: 0; color: #155724;">✅ Paciente eliminado correctamente.</p>
        </div>
    <?php endif; ?>

    <hr class="wp-header-end" style="border-color: #ccc; margin: 20px 0;">

    <div class="ac-card" style="background: white; border: 1px solid #ccc; border-radius: 8px;">
        <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
            <h2 style="color: black; margin: 0;">Lista de Pacientes</h2>
            <p style="color: #666; margin: 5px 0 0 0; font-size: 14px;">
                Total: <?php echo count($pacientes); ?> paciente(s)
            </p>
        </div>
        <div class="ac-card-body" style="padding: 20px;">
            <form method="get" class="ac-search-form">
                <input type="hidden" name="page" value="ac-pacientes">
                <div class="tablenav top">
                    <div class="alignleft actions">
                        <input type="search" name="busqueda" value="<?php echo esc_attr($busqueda ?? ''); ?>" placeholder="Buscar por cédula, nombre, apellido..." class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 300px;">
                        <input type="submit" class="button" value="🔍 Buscar" style="color: white; background: #0073aa; border: 1px solid #0073aa; padding: 5px 15px; border-radius: 4px; margin-left: 10px;">
                        <?php if (!empty($busqueda)): ?>
                            <a href="<?php echo admin_url('admin.php?page=ac-pacientes'); ?>" class="button" style="color: #555; background: #f7f7f7; border: 1px solid #ccc; text-decoration: none; padding: 5px 15px; border-radius: 4px; margin-left: 10px;">🔄 Limpiar</a>
                        <?php endif; ?>
                    </div>
                    <br class="clear">
                </div>
            </form>

            <table class="wp-list-table widefat fixed striped" style="background: white; color: black; border: 1px solid #ccc; width: 100%; border-collapse: collapse; margin-top: 20px;">
                <thead style="background: #f8f9fa;">
                    <tr>
                        <th style="width: 80px; color: black; border-bottom: 1px solid #ccc; padding: 12px 8px; text-align: left;">Foto</th>
                        <th style="color: black; border-bottom: 1px solid #ccc; padding: 12px 8px; text-align: left;">Cédula</th>
                        <th style="color: black; border-bottom: 1px solid #ccc; padding: 12px 8px; text-align: left;">Nombre Completo</th>
                        <th style="color: black; border-bottom: 1px solid #ccc; padding: 12px 8px; text-align: left;">Teléfono</th>
                        <th style="color: black; border-bottom: 1px solid #ccc; padding: 12px 8px; text-align: left;">Email</th>
                        <th style="color: black; border-bottom: 1px solid #ccc; padding: 12px 8px; text-align: left;">Fecha Ingreso</th>
                        <th style="color: black; border-bottom: 1px solid #ccc; padding: 12px 8px; text-align: left;">Estado</th>
                        <th style="color: black; border-bottom: 1px solid #ccc; padding: 12px 8px; text-align: left;">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($pacientes)): ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 40px; color: black;">
                                <p style="color: black; margin-bottom: 20px; font-size: 16px;">No se encontraron pacientes.</p>
                                <a href="<?php echo admin_url('admin.php?page=ac-pacientes&action=nuevo'); ?>" class="button button-primary" style="color: white; background: #0073aa; text-decoration: none; padding: 10px 20px; border-radius: 4px; font-size: 14px;">➕ Agregar primer paciente</a>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($pacientes as $paciente): ?>
                            <?php 
                            // Obtener foto de perfil del paciente usando el método optimizado
                            $foto_perfil = $file_manager->get_foto_perfil_principal($paciente->getId());
                            ?>
                            <tr style="border-bottom: 1px solid #eee;">
                                <td style="padding: 12px 8px; border-bottom: 1px solid #eee; vertical-align: middle;">
                                    <?php if ($foto_perfil): ?>
                                        <img src="<?php echo esc_url($foto_perfil['url']); ?>" 
                                             alt="Foto de perfil de <?php echo esc_attr($paciente->getNombreCompleto()); ?>" 
                                             style="width: 50px; height: 50px; object-fit: cover; border-radius: 50%; border: 2px solid #ddd; display: block; margin: 0 auto;">
                                    <?php else: ?>
                                        <div style="width: 50px; height: 50px; background: #f0f0f0; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid #ddd; margin: 0 auto;">
                                            <span style="font-size: 20px; color: #666;">👤</span>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 12px 8px; border-bottom: 1px solid #eee; color: black; vertical-align: middle;">
                                    <strong style="color: #0073aa;"><?php echo esc_html($paciente->getCedula()); ?></strong>
                                </td>
                                <td style="padding: 12px 8px; border-bottom: 1px solid #eee; color: black; vertical-align: middle;">
                                    <strong style="color: black; display: block;"><?php echo esc_html($paciente->getNombreCompleto()); ?></strong>
                                    <?php if ($paciente->getFechaNacimiento()): ?>
                                        <small style="color: #666; font-size: 12px;">
                                            📅 Edad: <?php echo $paciente->calcularEdad(); ?> años
                                        </small>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 12px 8px; border-bottom: 1px solid #eee; color: black; vertical-align: middle;">
                                    <?php if ($paciente->getTelefono()): ?>
                                        📞 <?php echo esc_html($paciente->getTelefono()); ?>
                                    <?php else: ?>
                                        <span style="color: #999;">No especificado</span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 12px 8px; border-bottom: 1px solid #eee; color: black; vertical-align: middle;">
                                    <?php if ($paciente->getEmail()): ?>
                                        ✉️ <?php echo esc_html($paciente->getEmail()); ?>
                                    <?php else: ?>
                                        <span style="color: #999;">No especificado</span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 12px 8px; border-bottom: 1px solid #eee; color: black; vertical-align: middle;">
                                    📅 <?php echo date('d/m/Y', strtotime($paciente->getFechaIngreso())); ?>
                                </td>
                                <td style="padding: 12px 8px; border-bottom: 1px solid #eee; vertical-align: middle;">
                                    <?php
                                    $estado = $paciente->getEstado();
                                    $badge_style = '';
                                    switch ($estado) {
                                        case 'activo':
                                            $badge_style = 'background: #d4edda; color: #155724;';
                                            break;
                                        case 'inactivo':
                                            $badge_style = 'background: #fff3cd; color: #856404;';
                                            break;
                                        case 'alta':
                                            $badge_style = 'background: #cce7ff; color: #004085;';
                                            break;
                                        default:
                                            $badge_style = 'background: #e2e3e5; color: #383d41;';
                                    }
                                    ?>
                                    <span class="ac-badge" style="padding: 6px 12px; border-radius: 12px; font-size: 12px; font-weight: bold; <?php echo $badge_style; ?>">
                                        <?php echo ucfirst($estado); ?>
                                    </span>
                                </td>
                                <td style="padding: 12px 8px; border-bottom: 1px solid #eee; vertical-align: middle;">
                                    <div class="row-actions" style="font-size: 12px; line-height: 1.6;">
                                        <a href="<?php echo admin_url('admin.php?page=ac-pacientes&action=ver&id=' . $paciente->getId()); ?>" style="color: #0073aa; text-decoration: none; display: block; margin: 2px 0;">👁️ Ver</a>
                                        <a href="<?php echo admin_url('admin.php?page=ac-pacientes&action=editar&id=' . $paciente->getId()); ?>" style="color: #0073aa; text-decoration: none; display: block; margin: 2px 0;">✏️ Editar</a>
                                        <a href="<?php echo admin_url('admin.php?page=ac-pacientes&action=fotos&id=' . $paciente->getId()); ?>" style="color: #0073aa; text-decoration: none; display: block; margin: 2px 0;">🖼️ Fotos</a>
                                        <a href="<?php echo admin_url('admin.php?page=ac-historial-medico&paciente_id=' . $paciente->getId()); ?>" style="color: #0073aa; text-decoration: none; display: block; margin: 2px 0;">📋 Historial</a>
                                        <a href="<?php echo admin_url('admin.php?page=ac-seguimiento-terapeutico&paciente_id=' . $paciente->getId()); ?>" style="color: #0073aa; text-decoration: none; display: block; margin: 2px 0;">📊 Seguimiento</a>
                                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ac-pacientes&action=eliminar&id=' . $paciente->getId()), 'eliminar_paciente_' . $paciente->getId()); ?>" 
                                           class="delete" 
                                           style="color: #dc3232; text-decoration: none; display: block; margin: 2px 0;"
                                           onclick="return confirm('¿Está seguro de que desea eliminar este paciente? Esta acción no se puede deshacer.');">🗑️ Eliminar</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.ac-badge {
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: bold;
    display: inline-block;
}

.row-actions a {
    text-decoration: none;
}

.row-actions a:hover {
    text-decoration: underline;
}

/* Estilos adicionales para mantener la consistencia */
.wp-list-table th {
    background: #f8f9fa !important;
    color: black !important;
    border-bottom: 1px solid #ccc !important;
    font-weight: 600;
}

.wp-list-table td {
    background: white !important;
    color: black !important;
    border-bottom: 1px solid #eee !important;
}

.wp-list-table tr:nth-child(even) td {
    background: #f9f9f9 !important;
}

.wp-list-table tr:hover td {
    background: #f0f7ff !important;
}

.button {
    color: white;
    background: #0073aa;
    border: 1px solid #0073aa;
    padding: 5px 10px;
    border-radius: 4px;
    text-decoration: none;
    display: inline-block;
    cursor: pointer;
}

.button:hover {
    background: #005a87;
    border-color: #005a87;
    color: white;
}

.regular-text {
    border: 1px solid #ccc;
    padding: 5px;
    border-radius: 4px;
}
</style>