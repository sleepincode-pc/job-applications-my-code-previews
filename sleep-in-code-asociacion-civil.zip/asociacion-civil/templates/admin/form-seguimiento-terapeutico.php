<?php
if (!defined('ABSPATH')) {
    exit;
}

$es_nuevo = !$seguimiento->getId();
$titulo = $es_nuevo ? 'Agregar Nuevo Seguimiento Terapéutico' : 'Editar Seguimiento Terapéutico';
?>

<div class="wrap" style="background: white; color: black; padding: 20px;">
    <h1 style="color: black;"><?php echo $titulo; ?></h1>

    <form method="post">
        <?php wp_nonce_field('guardar_seguimiento_terapeutico', 'seguimiento_terapeutico_nonce'); ?>
        
        <div class="ac-card" style="background: white; border: 1px solid #ccc; border-radius: 8px; margin-bottom: 20px;">
            <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                <h2 style="color: black; margin: 0;">📝 Información del Seguimiento</h2>
            </div>
            <div class="ac-card-body" style="padding: 20px;">
                <table class="form-table" style="color: black; width: 100%;">
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0; width: 200px;"><label for="paciente_id">Paciente *</label></th>
                        <td style="padding: 10px 0;">
                            <select id="paciente_id" name="paciente_id" class="regular-text" required <?php echo !$es_nuevo ? 'disabled' : ''; ?> style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 400px;">
                                <option value="">Seleccionar paciente...</option>
                                <?php foreach ($pacientes as $p): ?>
                                    <option value="<?php echo $p->getId(); ?>" <?php selected($seguimiento->getPacienteId(), $p->getId()); ?>>
                                        <?php echo esc_html($p->getNombreCompleto() . ' (' . $p->getCedula() . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (!$es_nuevo): ?>
                                <input type="hidden" name="paciente_id" value="<?php echo $seguimiento->getPacienteId(); ?>">
                                <p class="description" style="color: #666; margin: 5px 0 0 0;">No se puede cambiar el paciente una vez creado el registro.</p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="terapeuta_id">Terapeuta *</label></th>
                        <td style="padding: 10px 0;">
                            <select id="terapeuta_id" name="terapeuta_id" class="regular-text" required style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 400px;">
                                <option value="">Seleccionar terapeuta...</option>
                                <?php foreach ($terapeutas as $t): ?>
                                    <option value="<?php echo $t->getId(); ?>" <?php selected($seguimiento->getTerapeutaId(), $t->getId()); ?>>
                                        <?php echo esc_html($t->getNombreCompleto()); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="fecha_seguimiento">Fecha de Seguimiento *</label></th>
                        <td style="padding: 10px 0;">
                            <input type="date" id="fecha_seguimiento" name="fecha_seguimiento" value="<?php echo esc_attr($seguimiento->getFechaSeguimiento()); ?>" class="regular-text" required style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 200px;">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="tipo_seguimiento">Tipo de Seguimiento *</label></th>
                        <td style="padding: 10px 0;">
                            <select id="tipo_seguimiento" name="tipo_seguimiento" class="regular-text" required style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 400px;">
                                <option value="">Seleccionar...</option>
                                <option value="evaluacion" <?php selected($seguimiento->getTipoSeguimiento(), 'evaluacion'); ?>>Evaluación</option>
                                <option value="sesion" <?php selected($seguimiento->getTipoSeguimiento(), 'sesion'); ?>>Sesión</option>
                                <option value="seguimiento" <?php selected($seguimiento->getTipoSeguimiento(), 'seguimiento'); ?>>Seguimiento</option>
                                <option value="control" <?php selected($seguimiento->getTipoSeguimiento(), 'control'); ?>>Control</option>
                            </select>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="ac-card" style="background: white; border: 1px solid #ccc; border-radius: 8px; margin-bottom: 20px;">
            <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                <h2 style="color: black; margin: 0;">🎯 Progreso del Tratamiento</h2>
            </div>
            <div class="ac-card-body" style="padding: 20px;">
                <table class="form-table" style="color: black; width: 100%;">
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0; width: 200px;"><label for="objetivo_tratamiento">Objetivo del Tratamiento</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="objetivo_tratamiento" name="objetivo_tratamiento" rows="3" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($seguimiento->getObjetivoTratamiento()); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="progreso_observado">Progreso Observado</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="progreso_observado" name="progreso_observado" rows="5" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($seguimiento->getProgresoObservado()); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="dificultades_identificadas">Dificultades Identificadas</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="dificultades_identificadas" name="dificultades_identificadas" rows="3" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($seguimiento->getDificultadesIdentificadas()); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="intervenciones_realizadas">Intervenciones Realizadas</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="intervenciones_realizadas" name="intervenciones_realizadas" rows="3" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($seguimiento->getIntervencionesRealizadas()); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="tareas_asignadas">Tareas Asignadas</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="tareas_asignadas" name="tareas_asignadas" rows="3" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($seguimiento->getTareasAsignadas()); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="nivel_progreso">Nivel de Progreso</label></th>
                        <td style="padding: 10px 0;">
                            <select id="nivel_progreso" name="nivel_progreso" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 400px;">
                                <option value="bajo" <?php selected($seguimiento->getNivelProgreso(), 'bajo'); ?>>Bajo</option>
                                <option value="regular" <?php selected($seguimiento->getNivelProgreso(), 'regular'); ?>>Regular</option>
                                <option value="bueno" <?php selected($seguimiento->getNivelProgreso(), 'bueno'); ?>>Bueno</option>
                                <option value="excelente" <?php selected($seguimiento->getNivelProgreso(), 'excelente'); ?>>Excelente</option>
                            </select>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="ac-card" style="background: white; border: 1px solid #ccc; border-radius: 8px; margin-bottom: 20px;">
            <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                <h2 style="color: black; margin: 0;">📝 Observaciones y Próximos Pasos</h2>
            </div>
            <div class="ac-card-body" style="padding: 20px;">
                <table class="form-table" style="color: black; width: 100%;">
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0; width: 200px;"><label for="observaciones_terapeuta">Observaciones del Terapeuta</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="observaciones_terapeuta" name="observaciones_terapeuta" rows="5" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($seguimiento->getObservacionesTerapeuta()); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="proxima_sesion">Próxima Sesión</label></th>
                        <td style="padding: 10px 0;">
                            <input type="date" id="proxima_sesion" name="proxima_sesion" value="<?php echo esc_attr($seguimiento->getProximaSesion()); ?>" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 200px;">
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <p class="submit">
            <input type="submit" name="guardar_seguimiento_terapeutico" class="button button-primary" value="💾 Guardar Seguimiento" style="color: white; background: #0073aa; border: 1px solid #0073aa; padding: 10px 20px; border-radius: 4px; font-size: 14px; cursor: pointer;">
            <a href="<?php echo admin_url('admin.php?page=ac-seguimiento-terapeutico' . ($seguimiento->getPacienteId() ? '&paciente_id=' . $seguimiento->getPacienteId() : '')); ?>" class="button" style="color: #555; background: #f7f7f7; border: 1px solid #ccc; text-decoration: none; padding: 10px 20px; border-radius: 4px; font-size: 14px; margin-left: 10px;">❌ Cancelar</a>
        </p>
    </form>
</div>

<style>
.form-table th {
    color: black;
    font-weight: 600;
}

.form-table td {
    color: black;
}

.large-text {
    color: black;
    border: 1px solid #ccc;
    padding: 8px;
    width: 100%;
}

.regular-text {
    color: black;
    border: 1px solid #ccc;
    padding: 5px;
}

select.regular-text {
    color: black;
    border: 1px solid #ccc;
    padding: 5px;
}

input[type="date"] {
    color: black;
    border: 1px solid #ccc;
    padding: 5px;
}

.button-primary:hover {
    background: #005a87 !important;
    border-color: #005a87 !important;
}

.button:hover {
    background: #e5e5e5 !important;
    border-color: #bbb !important;
}

.description {
    color: #666;
    font-style: italic;
    margin: 5px 0 0 0;
}

/* Estilos específicos para selects deshabilitados */
select:disabled {
    background-color: #f8f9fa;
    color: #666;
    cursor: not-allowed;
}
</style>