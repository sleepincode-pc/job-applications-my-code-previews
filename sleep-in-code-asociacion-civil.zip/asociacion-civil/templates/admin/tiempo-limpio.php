<?php
if (!defined('ABSPATH')) {
    exit;
}

// DEBUG: Verificar si estamos en el contexto correcto
error_log("Tiempo Limpio: Iniciando carga...");

// Usar la ruta absoluta para incluir Database
try {
    $database_path = plugin_dir_path(dirname(__FILE__, 2)) . 'includes/classes/Database.php';
    error_log("Tiempo Limpio: Ruta Database - " . $database_path);
    
    if (file_exists($database_path)) {
        require_once $database_path;
        error_log("Tiempo Limpio: Database.php incluido exitosamente");
        
        // Verificar que la clase existe
        if (class_exists('AsociacionCivil\Database')) {
            error_log("Tiempo Limpio: Clase Database encontrada");
            $database = new AsociacionCivil\Database();
            error_log("Tiempo Limpio: Instancia de Database creada");
        } else {
            error_log("Tiempo Limpio: ERROR - Clase Database NO existe después de incluir");
            wp_die('Error: La clase Database no existe después de incluir el archivo.');
        }
    } else {
        error_log("Tiempo Limpio: ERROR - Archivo Database.php no encontrado en: " . $database_path);
        wp_die('Error: No se pudo encontrar el archivo Database.php.');
    }
} catch (Exception $e) {
    error_log("Tiempo Limpio: EXCEPCIÓN - " . $e->getMessage());
    wp_die('Error crítico: ' . $e->getMessage());
}

// Iniciar buffer de salida
ob_start();

// Obtener registros de tiempo limpio
error_log("Tiempo Limpio: Obteniendo registros...");
try {
    $registros = $database->get_tiempo_limpio(['number' => 100]);
    error_log("Tiempo Limpio: " . count($registros) . " registros obtenidos");
} catch (Exception $e) {
    error_log("Tiempo Limpio: ERROR obteniendo registros - " . $e->getMessage());
    $registros = [];
}

// =============================================
// MANEJAR EXPORTACIONES - PRIMERO
// =============================================
if (isset($_GET['export'])) {
    $export_type = $_GET['export'];
    
    if ($export_type === 'csv') {
        ac_exportar_csv_tiempo_limpio($registros);
    } elseif ($export_type === 'pdf') {
        ac_exportar_pdf_tiempo_limpio($registros);
    } elseif ($export_type === 'pdf_individual' && isset($_GET['id'])) {
        $registro_id = intval($_GET['id']);
        $registro_individual = null;
        
        foreach ($registros as $registro) {
            if (get_tiempo_limpio_property($registro, 'id') === $registro_id) {
                $registro_individual = $registro;
                break;
            }
        }
        
        if ($registro_individual) {
            ac_exportar_pdf_individual_tiempo_limpio($registro_individual);
        }
    }
}

// =============================================
// FUNCIÓN HELPER PARA ACCEDER A PROPIEDADES
// =============================================
if (!function_exists('get_tiempo_limpio_property')) {
    function get_tiempo_limpio_property($registro, $property) {
        if (!is_object($registro)) {
            return '';
        }
        
        // Mapeo de propiedades a getters
        $getters = [
            'id' => 'getId',
            'paciente_id' => 'getPacienteId',
            'fecha_inicio_abstinencia' => 'getFechaInicioAbstinencia',
            'fecha_registro' => 'getFechaRegistro',
            'tipo_sustancia' => 'getTipoSustancia',
            'estado_actual' => 'getEstadoActual',
            'terapeuta_id' => 'getTerapeutaId',
            'avances' => 'getAvances',
            'dificultades' => 'getDificultades',
            'metas_cumplidas' => 'getMetasCumplidas',
            'observaciones' => 'getObservaciones',
            'fecha_creacion' => 'getFechaCreacion',
            'fecha_actualizacion' => 'getFechaActualizacion'
        ];
        
        if (isset($getters[$property]) && method_exists($registro, $getters[$property])) {
            return $registro->{$getters[$property]}();
        }
        
        // Fallback: intentar acceder directamente (solo si es público)
        if (property_exists($registro, $property)) {
            try {
                return $registro->$property;
            } catch (Error $e) {
                error_log("Error accediendo a propiedad $property: " . $e->getMessage());
                return '';
            }
        }
        
        return '';
    }
}

// Verificar que $registros esté definida y sea un array
if (!isset($registros) || !is_array($registros)) {
    $registros = array();
}

// Funciones de exportación
if (!function_exists('ac_exportar_csv_tiempo_limpio')) {
    function ac_exportar_csv_tiempo_limpio($registros) {
        global $database;
        $filename = 'tiempo_limpio_' . date('Y-m-d') . '.csv';
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        fputs($output, "\xEF\xBB\xBF");
        
        // Encabezados
        fputcsv($output, array(
            'ID', 'Paciente', 'Fecha Inicio Abstinencia', 'Días Limpios', 'Tipo Sustancia', 
            'Estado Actual', 'Terapeuta', 'Avances', 'Dificultades', 'Metas Cumplidas', 'Observaciones'
        ), ';');
        
        // Datos
        foreach ($registros as $registro) {
            if (is_object($registro)) {
                // Obtener datos relacionados
                $paciente = $database->get_paciente_by_id(get_tiempo_limpio_property($registro, 'paciente_id'));
                $terapeuta = get_tiempo_limpio_property($registro, 'terapeuta_id') ? 
                    $database->get_miembro_by_id(get_tiempo_limpio_property($registro, 'terapeuta_id')) : null;
                
                // Calcular días limpios
                $fecha_inicio = get_tiempo_limpio_property($registro, 'fecha_inicio_abstinencia');
                $dias_limpios = $fecha_inicio ? 
                    floor((time() - strtotime($fecha_inicio)) / (60 * 60 * 24)) : 0;
                
                fputcsv($output, array(
                    get_tiempo_limpio_property($registro, 'id'),
                    $paciente ? $paciente->getNombre() . ' ' . $paciente->getApellido() : 'N/A',
                    $fecha_inicio ? date('d/m/Y', strtotime($fecha_inicio)) : 'N/A',
                    $dias_limpios,
                    get_tiempo_limpio_property($registro, 'tipo_sustancia') ?? 'No especificado',
                    get_tiempo_limpio_property($registro, 'estado_actual') ?? 'No especificado',
                    $terapeuta ? $terapeuta->getNombre() . ' ' . $terapeuta->getApellido() : 'No asignado',
                    strip_tags(get_tiempo_limpio_property($registro, 'avances') ?? ''),
                    strip_tags(get_tiempo_limpio_property($registro, 'dificultades') ?? ''),
                    strip_tags(get_tiempo_limpio_property($registro, 'metas_cumplidas') ?? ''),
                    strip_tags(get_tiempo_limpio_property($registro, 'observaciones') ?? '')
                ), ';');
            }
        }
        
        fclose($output);
        exit;
    }
}

if (!function_exists('ac_exportar_pdf_tiempo_limpio')) {
    function ac_exportar_pdf_tiempo_limpio($registros) {
        global $database;
        $filename = 'reporte_tiempo_limpio_' . date('Y-m-d') . '.html';
        
        header('Content-Type: text/html');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $html = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Reporte Tiempo Limpio</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                h1 { text-align: center; color: #333; }
                h2 { color: #0073aa; background-color: #f8f9fa; padding: 10px; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f2f2f2; }
                .section { margin-bottom: 30px; border: 1px solid #ddd; padding: 15px; }
                .success { border-color: #46b450; background-color: #f0fff0; }
                .warning { border-color: #ffb900; background-color: #fff8e7; }
                .dias-limpios { font-size: 18px; font-weight: bold; color: #0073aa; }
            </style>
        </head>
        <body>
            <h1>Reporte de Tiempo Limpio</h1>
            <p style="text-align: center;">Exportado el: ' . date('d/m/Y H:i:s') . '</p>
            <p style="text-align: center;">Total de registros: ' . count($registros) . '</p>
            <hr>';
        
        foreach ($registros as $index => $registro) {
            if (is_object($registro)) {
                $paciente = $database->get_paciente_by_id(get_tiempo_limpio_property($registro, 'paciente_id'));
                $terapeuta = get_tiempo_limpio_property($registro, 'terapeuta_id') ? 
                    $database->get_miembro_by_id(get_tiempo_limpio_property($registro, 'terapeuta_id')) : null;
                
                $fecha_inicio = get_tiempo_limpio_property($registro, 'fecha_inicio_abstinencia');
                $dias_limpios = $fecha_inicio ? floor((time() - strtotime($fecha_inicio)) / (60 * 60 * 24)) : 0;
                
                $html .= '<div class="section">
                    <h2>Registro #' . ($index + 1) . ': ' . ($paciente ? esc_html($paciente->getNombre() . ' ' . $paciente->getApellido()) : 'Paciente no encontrado') . '</h2>
                    <table>
                        <tr><td style="width: 30%; font-weight: bold;">Paciente:</td><td>' . ($paciente ? esc_html($paciente->getNombre() . ' ' . $paciente->getApellido()) : 'N/A') . '</td></tr>
                        <tr><td style="font-weight: bold;">Fecha Inicio Abstinencia:</td><td>' . ($fecha_inicio ? date('d/m/Y', strtotime($fecha_inicio)) : 'No especificada') . '</td></tr>
                        <tr><td style="font-weight: bold;">Días Limpios:</td><td class="dias-limpios">' . $dias_limpios . ' días</td></tr>
                        <tr><td style="font-weight: bold;">Tipo Sustancia:</td><td>' . (get_tiempo_limpio_property($registro, 'tipo_sustancia') ?? 'No especificado') . '</td></tr>
                        <tr><td style="font-weight: bold;">Estado Actual:</td><td>' . (get_tiempo_limpio_property($registro, 'estado_actual') ?? 'No especificado') . '</td></tr>
                        <tr><td style="font-weight: bold;">Terapeuta:</td><td>' . ($terapeuta ? esc_html($terapeuta->getNombre() . ' ' . $terapeuta->getApellido()) : 'No asignado') . '</td></tr>
                    </table>';
                
                if (!empty(get_tiempo_limpio_property($registro, 'avances'))) {
                    $html .= '<h4>Avances y Logros:</h4>
                    <div style="border: 1px solid #46b450; padding: 10px; background-color: #f0fff0;">
                        ' . strip_tags(get_tiempo_limpio_property($registro, 'avances')) . '
                    </div>';
                }
                
                if (!empty(get_tiempo_limpio_property($registro, 'dificultades'))) {
                    $html .= '<h4>Dificultades Enfrentadas:</h4>
                    <div style="border: 1px solid #ffb900; padding: 10px; background-color: #fff8e7;">
                        ' . strip_tags(get_tiempo_limpio_property($registro, 'dificultades')) . '
                    </div>';
                }
                
                if (!empty(get_tiempo_limpio_property($registro, 'metas_cumplidas'))) {
                    $html .= '<h4>Metas Cumplidas:</h4>
                    <div style="border: 1px solid #0073aa; padding: 10px; background-color: #e7f3ff;">
                        ' . strip_tags(get_tiempo_limpio_property($registro, 'metas_cumplidas')) . '
                    </div>';
                }
                
                if (!empty(get_tiempo_limpio_property($registro, 'observaciones'))) {
                    $html .= '<h4>Observaciones:</h4>
                    <div style="border: 1px solid #ddd; padding: 10px; background-color: #f9f9f9;">
                        ' . strip_tags(get_tiempo_limpio_property($registro, 'observaciones')) . '
                    </div>';
                }
                
                $html .= '</div><hr style="margin: 20px 0;">';
            }
        }
        
        $html .= '</body></html>';
        
        echo $html;
        exit;
    }
}

if (!function_exists('ac_exportar_pdf_individual_tiempo_limpio')) {
    function ac_exportar_pdf_individual_tiempo_limpio($registro) {
        global $database;
        $paciente = $database->get_paciente_by_id(get_tiempo_limpio_property($registro, 'paciente_id'));
        $filename = 'tiempo_limpio_' . ($paciente ? sanitize_title($paciente->getNombre() . '_' . $paciente->getApellido()) : 'registro') . '_' . date('Y-m-d') . '.html';
        
        header('Content-Type: text/html');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $fecha_inicio = get_tiempo_limpio_property($registro, 'fecha_inicio_abstinencia');
        $dias_limpios = $fecha_inicio ? floor((time() - strtotime($fecha_inicio)) / (60 * 60 * 24)) : 0;
        $terapeuta = get_tiempo_limpio_property($registro, 'terapeuta_id') ? 
            $database->get_miembro_by_id(get_tiempo_limpio_property($registro, 'terapeuta_id')) : null;
        
        $html = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Tiempo Limpio - ' . ($paciente ? esc_html($paciente->getNombre() . ' ' . $paciente->getApellido()) : 'Registro') . '</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 30px; line-height: 1.6; }
                h1 { text-align: center; color: #333; margin-bottom: 10px; }
                h2 { text-align: center; color: #0073aa; margin-bottom: 30px; }
                .header-info { margin-bottom: 30px; }
                .info-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                .info-table td { padding: 8px; border-bottom: 1px solid #eee; }
                .info-table td:first-child { font-weight: bold; width: 25%; }
                .section { margin-bottom: 25px; }
                .section-title { color: #555; border-bottom: 2px solid #0073aa; padding-bottom: 5px; margin-bottom: 10px; }
                .content-box { border: 1px solid #ddd; padding: 15px; background-color: #f9f9f9; margin-bottom: 15px; }
                .success-box { border-color: #46b450; background-color: #f0fff0; }
                .warning-box { border-color: #ffb900; background-color: #fff8e7; }
                .info-box { border-color: #0073aa; background-color: #e7f3ff; }
                .dias-limpios-badge { font-size: 24px; font-weight: bold; color: #0073aa; text-align: center; padding: 10px; background: #e7f3ff; border-radius: 8px; margin: 10px 0; }
                .footer { text-align: center; margin-top: 40px; color: #666; font-size: 12px; }
            </style>
        </head>
        <body>
            <h1>REPORTE DE TIEMPO LIMPIO</h1>
            <h2>' . ($paciente ? esc_html($paciente->getNombre() . ' ' . $paciente->getApellido()) : 'Registro') . '</h2>
            
            <div class="dias-limpios-badge">
                ' . $dias_limpios . ' DÍAS LIMPIOS
            </div>
            
            <div class="header-info">
                <table class="info-table">
                    <tr>
                        <td>Paciente:</td>
                        <td>' . ($paciente ? esc_html($paciente->getNombre() . ' ' . $paciente->getApellido() . ' (C.I.: ' . $paciente->getCedula() . ')') : 'N/A') . '</td>
                    </tr>
                    <tr>
                        <td>Fecha Inicio Abstinencia:</td>
                        <td>' . ($fecha_inicio ? date('d/m/Y', strtotime($fecha_inicio)) : 'No especificada') . '</td>
                    </tr>
                    <tr>
                        <td>Tipo de Sustancia:</td>
                        <td>' . (get_tiempo_limpio_property($registro, 'tipo_sustancia') ?? 'No especificado') . '</td>
                    </tr>
                    <tr>
                        <td>Estado Actual:</td>
                        <td>' . (get_tiempo_limpio_property($registro, 'estado_actual') ?? 'No especificado') . '</td>
                    </tr>
                    <tr>
                        <td>Terapeuta:</td>
                        <td>' . ($terapeuta ? esc_html($terapeuta->getNombre() . ' ' . $terapeuta->getApellido()) : 'No asignado') . '</td>
                    </tr>
                    <tr>
                        <td>Fecha de Registro:</td>
                        <td>' . date('d/m/Y', strtotime(get_tiempo_limpio_property($registro, 'fecha_registro'))) . '</td>
                    </tr>
                </table>
            </div>';
        
        if (!empty(get_tiempo_limpio_property($registro, 'avances'))) {
            $html .= '<div class="section">
                <h3 class="section-title">AVANCES Y LOGROS</h3>
                <div class="content-box success-box">' . strip_tags(get_tiempo_limpio_property($registro, 'avances')) . '</div>
            </div>';
        }
        
        if (!empty(get_tiempo_limpio_property($registro, 'dificultades'))) {
            $html .= '<div class="section">
                <h3 class="section-title">DIFICULTADES ENFRENTADAS</h3>
                <div class="content-box warning-box">' . strip_tags(get_tiempo_limpio_property($registro, 'dificultades')) . '</div>
            </div>';
        }
        
        if (!empty(get_tiempo_limpio_property($registro, 'metas_cumplidas'))) {
            $html .= '<div class="section">
                <h3 class="section-title">METAS CUMPLIDAS</h3>
                <div class="content-box info-box">' . strip_tags(get_tiempo_limpio_property($registro, 'metas_cumplidas')) . '</div>
            </div>';
        }
        
        if (!empty(get_tiempo_limpio_property($registro, 'observaciones'))) {
            $html .= '<div class="section">
                <h3 class="section-title">OBSERVACIONES</h3>
                <div class="content-box">' . strip_tags(get_tiempo_limpio_property($registro, 'observaciones')) . '</div>
            </div>';
        }
        
        $html .= '<div class="footer">
                Documento generado el ' . date('d/m/Y H:i:s') . '<br>
                ' . get_bloginfo('name') . '
            </div>
        </body>
        </html>';
        
        echo $html;
        exit;
    }
}

// =============================================
// MANEJAR IMPORTACIÓN CSV
// =============================================
if (isset($_POST['importar_csv_tiempo_limpio'])) {
    ac_importar_csv_tiempo_limpio();
}

if (!function_exists('ac_importar_csv_tiempo_limpio')) {
    function ac_importar_csv_tiempo_limpio() {
        if (!empty($_FILES['csv_file']['tmp_name'])) {
            $file = $_FILES['csv_file']['tmp_name'];
            $handle = fopen($file, 'r');
            
            if ($handle !== FALSE) {
                $importados = 0;
                $errores = 0;
                $primera_linea = true;
                
                while (($data = fgetcsv($handle, 1000, ';')) !== FALSE) {
                    if ($primera_linea) {
                        $primera_linea = false;
                        continue;
                    }
                    
                    if (count($data) >= 5) {
                        // Aquí procesarías los datos del CSV
                        // Esto es un ejemplo básico
                        $importados++;
                    } else {
                        $errores++;
                    }
                }
                
                fclose($handle);
                
                echo '<div class="notice notice-success is-dismissible">';
                echo '<p>Importación completada: ' . $importados . ' registros importados correctamente. ' . $errores . ' errores.</p>';
                echo '</div>';
            }
        }
    }
}

// =============================================
// CÓDIGO DE ESTADÍSTICAS Y MENSAJES
// =============================================

// Mensajes de éxito
$mensajes = array();
if (isset($_GET['updated'])) {
    $mensajes[] = 'Registro de tiempo limpio actualizado correctamente.';
}
if (isset($_GET['deleted'])) {
    $mensajes[] = 'Registro de tiempo limpio eliminado correctamente.';
}
if (isset($_GET['created'])) {
    $mensajes[] = 'Registro de tiempo limpio creado correctamente.';
}

// Obtener datos para estadísticas
$total_registros = count($registros);
// NOTA: Estas funciones pueden no existir en tu Database class
// $pacientes_6_meses = $database->get_pacientes_6_meses_limpios();
// $pacientes_30_dias = $database->get_pacientes_30_dias_limpios();
// $promedio_dias = $database->get_promedio_dias_limpios();
$pacientes_6_meses = 0; // Temporal - reemplazar con función real
$pacientes_30_dias = 0; // Temporal - reemplazar con función real
$promedio_dias = 0; // Temporal - reemplazar con función real

// Estadísticas avanzadas
$estados_actuales = array();
$tipos_sustancia = array();
$registros_por_mes = array();
$registros_por_año = array();

foreach ($registros as $registro) {
    if (is_object($registro)) {
        // Por estado
        $estado = get_tiempo_limpio_property($registro, 'estado_actual') ?? '';
        if (!isset($estados_actuales[$estado])) {
            $estados_actuales[$estado] = 0;
        }
        $estados_actuales[$estado]++;
        
        // Por tipo de sustancia
        $sustancia = get_tiempo_limpio_property($registro, 'tipo_sustancia') ?? '';
        if (!isset($tipos_sustancia[$sustancia])) {
            $tipos_sustancia[$sustancia] = 0;
        }
        $tipos_sustancia[$sustancia]++;
        
        // Por mes
        $fecha = get_tiempo_limpio_property($registro, 'fecha_registro') ?? '';
        if ($fecha) {
            $mes = date('Y-m', strtotime($fecha));
            if (!isset($registros_por_mes[$mes])) {
                $registros_por_mes[$mes] = 0;
            }
            $registros_por_mes[$mes]++;
            
            // Por año
            $año = date('Y', strtotime($fecha));
            if (!isset($registros_por_año[$año])) {
                $registros_por_año[$año] = 0;
            }
            $registros_por_año[$año]++;
        }
    }
}

// Ordenar estadísticas
arsort($estados_actuales);
arsort($tipos_sustancia);
krsort($registros_por_mes);
krsort($registros_por_año);

// Preparar datos para gráficos
$datos_grafico_json = array();
$datos_grafico_json['mes'] = array();
$datos_grafico_json['año'] = $registros_por_año;
$datos_grafico_json['estado'] = $estados_actuales;
$datos_grafico_json['sustancia'] = $tipos_sustancia;

// Función para obtener los últimos 6 meses
if (!function_exists('obtener_ultimos_6_meses')) {
    function obtener_ultimos_6_meses() {
        $meses = [];
        for ($i = 5; $i >= 0; $i--) {
            $meses[] = date('Y-m', strtotime("-$i months"));
        }
        return $meses;
    }
}

// Preparar datos para el gráfico de los últimos 6 meses
if (!function_exists('preparar_datos_ultimos_6_meses')) {
    function preparar_datos_ultimos_6_meses($registros_por_mes) {
        $ultimos_6_meses = obtener_ultimos_6_meses();
        $datos_completos = [];
        
        foreach ($ultimos_6_meses as $mes) {
            $meses_es = [
                '01' => 'Ene', '02' => 'Feb', '03' => 'Mar', '04' => 'Abr',
                '05' => 'May', '06' => 'Jun', '07' => 'Jul', '08' => 'Ago',
                '09' => 'Sep', '10' => 'Oct', '11' => 'Nov', '12' => 'Dic'
            ];
            
            $partes = explode('-', $mes);
            $año = $partes[0];
            $mes_num = $partes[1];
            $etiqueta = $meses_es[$mes_num] . ' ' . $año;
            
            $datos_completos[$etiqueta] = $registros_por_mes[$mes] ?? 0;
        }
        
        return $datos_completos;
    }
}

$datos_grafico_json['mes'] = preparar_datos_ultimos_6_meses($registros_por_mes);

// Manejar selección de métricas y gráficos
$metricas_seleccionadas = isset($_GET['metricas']) ? sanitize_text_field($_GET['metricas']) : 'mes';
$tipo_grafico_seleccionado = isset($_GET['tipo_grafico']) ? sanitize_text_field($_GET['tipo_grafico']) : 'barras';
?>

<!-- EL RESTO DEL HTML Y JAVASCRIPT PERMANECE EXACTAMENTE IGUAL -->
<!-- [TODO EL CÓDIGO HTML DESDE <div class="wrap"> HASTA EL FINAL PERMANECE IGUAL] -->

<div class="wrap">
    <h1 class="wp-heading-inline">⏳ Tiempo Limpio</h1>
    
    <?php if (!empty($mensajes)): ?>
        <?php foreach ($mensajes as $mensaje): ?>
            <div class="notice notice-success is-dismissible">
                <p><?php echo esc_html($mensaje); ?></p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <!-- Panel de Métricas Avanzadas -->
    <div class="ac-metrics-panel" style="margin: 20px 0;">
        <h2 style="margin-bottom: 15px; color: #23282d;">📊 Métricas del Programa Tiempo Limpio</h2>
        
        <div class="ac-stats-container" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; margin-bottom: 20px;">
            <!-- Métrica Principal -->
            <div class="ac-stat-card" style="background: linear-gradient(135deg, #0073aa, #005a87); color: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="display: flex; justify-content: between; align-items: center;">
                    <div>
                        <h3 style="margin: 0 0 5px 0; font-size: 14px; opacity: 0.9;">TOTAL EN PROGRAMA</h3>
                        <p style="font-size: 32px; font-weight: bold; margin: 0;">⏳ <?php echo esc_html($total_registros); ?></p>
                    </div>
                    <div style="font-size: 24px;">⏳</div>
                </div>
                <div style="margin-top: 10px; font-size: 12px; opacity: 0.8;">
                    <?php echo esc_html($pacientes_30_dias); ?> con +30 días • 
                    <?php echo esc_html($pacientes_6_meses); ?> con +6 meses
                </div>
            </div>

            <!-- Progreso de Abstinencia -->
            <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #46b450; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #46b450; font-size: 14px;">PROGRESO DE ABSTINENCIA</h3>
                <div style="display: grid; gap: 8px;">
                    <div style="display: flex; justify-content: space-between;">
                        <span>+6 meses limpios:</span>
                        <strong><?php echo esc_html($pacientes_6_meses); ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>+30 días limpios:</span>
                        <strong><?php echo esc_html($pacientes_30_dias); ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Promedio días limpios:</span>
                        <strong><?php echo esc_html($promedio_dias); ?> días</strong>
                    </div>
                </div>
            </div>

            <!-- Distribución por Estado -->
            <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #ffb900; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #ffb900; font-size: 14px;">DISTRIBUCIÓN POR ESTADO</h3>
                <div style="max-height: 120px; overflow-y: auto;">
                    <?php foreach ($estados_actuales as $estado => $cantidad): 
                        $porcentaje = $total_registros > 0 ? round(($cantidad / $total_registros) * 100) : 0;
                    ?>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                        <span><?php echo esc_html(ucfirst($estado)); ?></span>
                        <span style="font-weight: bold;"><?php echo esc_html($cantidad); ?> (<?php echo esc_html($porcentaje); ?>%)</span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Tipos de Sustancia -->
            <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #dc3232; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #dc3232; font-size: 14px;">TIPOS DE SUSTANCIA</h3>
                <div style="max-height: 120px; overflow-y: auto;">
                    <?php foreach ($tipos_sustancia as $sustancia => $cantidad): 
                        $porcentaje = $total_registros > 0 ? round(($cantidad / $total_registros) * 100) : 0;
                    ?>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                        <span><?php echo esc_html($sustancia ?: 'No especificado'); ?></span>
                        <span style="font-weight: bold;"><?php echo esc_html($cantidad); ?> (<?php echo esc_html($porcentaje); ?>%)</span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Selector de Métricas y Gráficos -->
        <div style="background: white; padding: 15px; border-radius: 8px; margin-bottom: 15px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h4 style="margin: 0 0 10px 0; color: #23282d; font-size: 14px;">📈 Seleccionar Métricas de Visualización</h4>
            
            <!-- Selector de Métricas -->
            <div style="display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 15px;">
                <button type="button" class="button ac-metrica-btn <?php echo $metricas_seleccionadas == 'mes' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-metrica="mes"
                        style="font-size: 12px; padding: 6px 12px;">
                    📅 Por Mes
                </button>
                <button type="button" class="button ac-metrica-btn <?php echo $metricas_seleccionadas == 'año' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-metrica="año"
                        style="font-size: 12px; padding: 6px 12px;">
                    📊 Por Año
                </button>
                <button type="button" class="button ac-metrica-btn <?php echo $metricas_seleccionadas == 'estado' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-metrica="estado"
                        style="font-size: 12px; padding: 6px 12px;">
                    🏷️ Por Estado
                </button>
                <button type="button" class="button ac-metrica-btn <?php echo $metricas_seleccionadas == 'sustancia' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-metrica="sustancia"
                        style="font-size: 12px; padding: 6px 12px;">
                    💊 Por Sustancia
                </button>
            </div>

            <!-- Selector de Tipo de Gráfico -->
            <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
                <span style="font-size: 12px; color: #666; margin-right: 10px;">Tipo de gráfico:</span>
                <button type="button" class="button ac-grafico-btn <?php echo $tipo_grafico_seleccionado == 'barras' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-grafico="barras"
                        style="font-size: 11px; padding: 4px 8px;">
                    📊 Barras
                </button>
                <button type="button" class="button ac-grafico-btn <?php echo $tipo_grafico_seleccionado == 'lineas' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-grafico="lineas"
                        style="font-size: 11px; padding: 4px 8px;">
                    📈 Líneas
                </button>
                <button type="button" class="button ac-grafico-btn <?php echo $tipo_grafico_seleccionado == 'pastel' ? 'button-primary' : 'button-secondary'; ?>" 
                        data-grafico="pastel"
                        style="font-size: 11px; padding: 4px 8px;">
                    🥧 Pastel
                </button>
            </div>
        </div>

        <!-- Gráficos -->
        <div class="ac-charts-container" id="graficos-container">
            <div class="ac-chart-card" style="background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="display: flex; justify-content: between; align-items: center; margin-bottom: 15px;">
                    <h4 style="margin: 0; color: #23282d; font-size: 14px;" id="titulo-grafico">
                        📈 <?php 
                        switch($metricas_seleccionadas) {
                            case 'mes': echo 'Registros por Mes (Últimos 6 meses)'; break;
                            case 'año': echo 'Registros por Año'; break;
                            case 'estado': echo 'Registros por Estado'; break;
                            case 'sustancia': echo 'Registros por Tipo de Sustancia'; break;
                            default: echo 'Registros por Mes';
                        }
                        ?>
                    </h4>
                    <div class="ac-chart-info" style="font-size: 12px; color: #666;">
                        <span id="total-registros-grafico">Total: <?php echo array_sum($datos_grafico_json[$metricas_seleccionadas] ?? []); ?> registros</span>
                    </div>
                </div>
                
                <div id="contenedor-grafico" 
                     style="min-height: 300px; display: flex; align-items: center; justify-content: center; 
                            width: 100%; overflow: hidden; position: relative;"
                     class="ac-grafico-zoomable">
                    <div class="ac-loading" style="text-align: center; color: #666;">
                        <p>Cargando gráfico interactivo...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Acciones Principales -->
    <div class="ac-header-actions" style="display: flex; justify-content: space-between; align-items: center; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px;">
        <div>
            <a href="<?php echo admin_url('admin.php?page=ac-tiempo-limpio&action=nuevo'); ?>" class="button button-primary" style="font-size: 14px; padding: 8px 16px;">
                <span class="dashicons dashicons-plus" style="margin-top: 4px;"></span>
                Nuevo Registro
            </a>
            <?php if (!empty($registros)): ?>
            <div class="ac-export-buttons" style="display: inline-block; margin-left: 10px;">
                <a href="<?php echo admin_url('admin.php?page=ac-tiempo-limpio&export=csv'); ?>" class="button" style="font-size: 14px; padding: 8px 16px;">
                    <span class="dashicons dashicons-media-spreadsheet" style="margin-top: 4px;"></span>
                    Exportar CSV
                </a>
                <a href="<?php echo admin_url('admin.php?page=ac-tiempo-limpio&export=pdf'); ?>" class="button" style="font-size: 14px; padding: 8px 16px; margin-left: 5px;">
                    <span class="dashicons dashicons-media-document" style="margin-top: 4px;"></span>
                    Exportar PDF
                </a>
            </div>
            <?php endif; ?>
        </div>
        
        <?php if (!empty($registros)): ?>
        <div class="ac-search-export" style="display: flex; gap: 10px; align-items: center;">
            <input type="text" id="buscar-registros" placeholder="Buscar en registros..." style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; width: 250px;">
            <span class="description" style="color: #666; font-size: 13px;">
                <?php echo esc_html($total_registros); ?> registro(s) en programa
            </span>
        </div>
        <?php endif; ?>
    </div>

    <!-- Sección de Importación -->
    <div class="ac-import-section" style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #0073aa;">
        <h3 style="margin-top: 0; color: #0073aa;">
            <span class="dashicons dashicons-upload" style="margin-right: 5px;"></span>
            Importar Registros
        </h3>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <!-- Importar desde CSV -->
            <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px; background: white;">
                <h4 style="margin-top: 0; color: #0073aa;">
                    <span class="dashicons dashicons-media-spreadsheet" style="margin-right: 5px;"></span>
                    Desde Archivo CSV
                </h4>
                <form method="post" enctype="multipart/form-data">
                    <?php wp_nonce_field('importar_csv_tiempo_limpio'); ?>
                    <input type="file" name="csv_file" accept=".csv" required style="margin-bottom: 10px; width: 100%;">
                    <button type="submit" name="importar_csv_tiempo_limpio" class="button button-secondary" style="width: 100%;">
                        <span class="dashicons dashicons-upload" style="margin-top: 4px;"></span>
                        Importar CSV
                    </button>
                </form>
                <p style="margin: 10px 0 0 0; font-size: 12px; color: #666;">
                    <strong>Formato:</strong> CSV con encabezados<br>
                    <strong>Separador:</strong> Punto y coma (;)
                </p>
            </div>

            <!-- Información de Importación -->
            <div style="border: 1px solid #46b450; padding: 15px; border-radius: 5px; background: white;">
                <h4 style="margin-top: 0; color: #46b450;">
                    <span class="dashicons dashicons-info" style="margin-right: 5px;"></span>
                    Información de Importación
                </h4>
                <div style="padding: 15px; background: #f0fff0; border-radius: 4px; margin-bottom: 15px;">
                    <p style="margin: 0; font-size: 13px;">
                        <strong>Estructura requerida:</strong><br>
                        Paciente, Fecha Inicio, Tipo Sustancia, Estado, Terapeuta, Avances, Dificultades, Metas, Observaciones
                    </p>
                </div>
                <p style="margin: 10px 0 0 0; font-size: 12px; color: #666;">
                    <strong>Nota:</strong> Los pacientes deben existir previamente en el sistema.<br>
                    <strong>Formato fecha:</strong> DD/MM/AAAA
                </p>
            </div>
        </div>
    </div>
    
    <?php if (empty($registros)): ?>
        <div class="notice notice-info" style="padding: 20px; text-align: center;">
            <h3 style="margin-top: 0;">⏳ Comienza el Programa Tiempo Limpio</h3>
            <p>No hay registros de tiempo limpio en el sistema. Crea el primer registro para comenzar el seguimiento de abstinencia y recuperación.</p>
            <p style="margin-top: 15px;">
                <a href="<?php echo admin_url('admin.php?page=ac-tiempo-limpio&action=nuevo'); ?>" class="button button-primary button-large">
                    <span class="dashicons dashicons-plus"></span>
                    Crear el primer registro
                </a>
            </p>
        </div>
    <?php else: ?>
        <div class="ac-table-container">
            <table class="wp-list-table widefat fixed striped" id="tabla-registros">
                <thead>
                    <tr>
                        <th width="20%">Paciente</th>
                        <th width="12%">Fecha Inicio</th>
                        <th width="10%">Días Limpios</th>
                        <th width="12%">Tipo Sustancia</th>
                        <th width="12%">Estado Actual</th>
                        <th width="14%">Terapeuta</th>
                        <th width="20%">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($registros as $registro_item): ?>
                        <?php if (is_object($registro_item)): 
                            $paciente = $database->get_paciente_by_id(get_tiempo_limpio_property($registro_item, 'paciente_id'));
                            $terapeuta = get_tiempo_limpio_property($registro_item, 'terapeuta_id') ? 
                                $database->get_miembro_by_id(get_tiempo_limpio_property($registro_item, 'terapeuta_id')) : null;
                            
                            $fecha_inicio = get_tiempo_limpio_property($registro_item, 'fecha_inicio_abstinencia');
                            $dias_limpios = $fecha_inicio ? floor((time() - strtotime($fecha_inicio)) / (60 * 60 * 24)) : 0;
                        ?>
                        <tr class="ac-registro-row" 
                            data-paciente="<?php echo esc_attr(strtolower($paciente ? $paciente->getNombre() . ' ' . $paciente->getApellido() : '')); ?>" 
                            data-sustancia="<?php echo esc_attr(strtolower(get_tiempo_limpio_property($registro_item, 'tipo_sustancia') ?? '')); ?>" 
                            data-estado="<?php echo esc_attr(strtolower(get_tiempo_limpio_property($registro_item, 'estado_actual') ?? '')); ?>">
                            <td>
                                <strong><?php echo $paciente ? esc_html($paciente->getNombre() . ' ' . $paciente->getApellido()) : 'Paciente no encontrado'; ?></strong>
                                <?php if ($paciente): ?>
                                    <br><small style="color: #666;">C.I.: <?php echo esc_html($paciente->getCedula()); ?></small>
                                <?php endif; ?>
                                <?php if (!empty(get_tiempo_limpio_property($registro_item, 'avances'))): ?>
                                    <br>
                                    <small style="color: #46b450;">
                                        <span class="dashicons dashicons-yes-alt" style="font-size: 12px; margin-right: 2px;"></span>
                                        Tiene avances registrados
                                    </small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo $fecha_inicio ? date('d/m/Y', strtotime($fecha_inicio)) : 'No especificada'; ?>
                            </td>
                            <td>
                                <span class="ac-badge-dias ac-badge-dias-<?php echo $dias_limpios >= 180 ? 'excelente' : ($dias_limpios >= 90 ? 'bueno' : ($dias_limpios >= 30 ? 'regular' : 'inicio')); ?>" 
                                      style="padding: 4px 8px; border-radius: 12px; font-weight: bold; font-size: 12px;">
                                    <?php echo esc_html($dias_limpios); ?> días
                                </span>
                            </td>
                            <td>
                                <?php echo esc_html(get_tiempo_limpio_property($registro_item, 'tipo_sustancia') ?: 'No especificado'); ?>
                            </td>
                            <td>
                                <span class="ac-badge-estado ac-badge-estado-<?php echo esc_attr(get_tiempo_limpio_property($registro_item, 'estado_actual')); ?>" 
                                      style="padding: 4px 8px; border-radius: 3px; font-size: 12px; font-weight: 500;">
                                    <?php echo esc_html(ucfirst(get_tiempo_limpio_property($registro_item, 'estado_actual'))); ?>
                                </span>
                            </td>
                            <td>
                                <?php echo $terapeuta ? esc_html($terapeuta->getNombre() . ' ' . $terapeuta->getApellido()) : '<span style="color: #999;">No asignado</span>'; ?>
                            </td>
                            <td>
                                <div class="ac-action-buttons" style="display: flex; gap: 5px; flex-wrap: wrap;">
                                    <a href="<?php echo admin_url('admin.php?page=ac-tiempo-limpio&action=ver&id=' . get_tiempo_limpio_property($registro_item, 'id')); ?>" class="button" title="Ver registro completo" style="padding: 4px 8px; font-size: 12px;">
                                        <span class="dashicons dashicons-visibility" style="font-size: 14px; margin-top: 2px;"></span>
                                        Ver
                                    </a>
                                    <a href="<?php echo admin_url('admin.php?page=ac-tiempo-limpio&action=editar&id=' . get_tiempo_limpio_property($registro_item, 'id')); ?>" class="button" title="Editar registro" style="padding: 4px 8px; font-size: 12px;">
                                        <span class="dashicons dashicons-edit" style="font-size: 14px; margin-top: 2px;"></span>
                                        Editar
                                    </a>
                                    <a href="<?php echo admin_url('admin.php?page=ac-tiempo-limpio&export=csv&id=' . get_tiempo_limpio_property($registro_item, 'id')); ?>" class="button" title="Exportar a CSV" style="padding: 4px 8px; font-size: 12px; background: #0073aa; color: white; border-color: #0073aa;">
                                        <span class="dashicons dashicons-media-spreadsheet" style="font-size: 14px; margin-top: 2px;"></span>
                                        CSV
                                    </a>
                                    <a href="<?php echo admin_url('admin.php?page=ac-tiempo-limpio&export=pdf_individual&id=' . get_tiempo_limpio_property($registro_item, 'id')); ?>" class="button" title="Exportar a PDF" style="padding: 4px 8px; font-size: 12px; background: #dc3232; color: white; border-color: #dc3232;">
                                        <span class="dashicons dashicons-media-document" style="font-size: 14px; margin-top: 2px;"></span>
                                        PDF
                                    </a>
                                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ac-tiempo-limpio&action=eliminar&id=' . get_tiempo_limpio_property($registro_item, 'id')), 'eliminar_tiempo_limpio_' . get_tiempo_limpio_property($registro_item, 'id')); ?>" 
                                       class="button button-link-delete" 
                                       title="Eliminar registro" 
                                       style="padding: 4px 8px; font-size: 12px; color: #dc3232; border-color: #dc3232;"
                                       onclick="return confirm('¿Está seguro de que desea eliminar este registro?\n\nPaciente: <?php echo esc_js($paciente ? $paciente->getNombre() . ' ' . $paciente->getApellido() : ''); ?>\nDías limpios: <?php echo esc_js($dias_limpios); ?>');">
                                        <span class="dashicons dashicons-trash" style="font-size: 14px; margin-top: 2px;"></span>
                                        Eliminar
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Paciente</th>
                        <th>Fecha Inicio</th>
                        <th>Días Limpios</th>
                        <th>Tipo Sustancia</th>
                        <th>Estado Actual</th>
                        <th>Terapeuta</th>
                        <th>Acciones</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    <?php endif; ?>
</div>

<script>
jQuery(document).ready(function($) {
    // Variables para el gráfico
    const datosGraficos = <?php echo json_encode($datos_grafico_json); ?>;
    let metricaActual = '<?php echo esc_js($metricas_seleccionadas); ?>';
    let tipoGraficoActual = '<?php echo esc_js($tipo_grafico_seleccionado); ?>';
    
    // Inicializar el gráfico
    function inicializarGrafico() {
        cargarGrafico(metricaActual, tipoGraficoActual);
    }
    
    // Cargar gráfico
    function cargarGrafico(metrica, tipoGrafico) {
        const contenedor = $('#contenedor-grafico');
        const titulo = $('#titulo-grafico');
        const totalRegistros = $('#total-registros-grafico');
        
        // Mostrar loading
        contenedor.html('<div class="ac-loading" style="text-align: center; color: #666;"><p>Cargando gráfico interactivo...</p></div>');
        
        // Simular carga
        setTimeout(function() {
            const datos = datosGraficos[metrica] || {};
            const tituloTexto = obtenerTituloGrafico(metrica);
            const total = Object.values(datos).reduce((sum, val) => sum + val, 0);
            
            titulo.text('📈 ' + tituloTexto);
            totalRegistros.text('Total: ' + total + ' registros');
            
            // Generar gráfico
            const graficoHTML = generarGrafico(datos, tipoGrafico, tituloTexto);
            contenedor.html(graficoHTML);
            
            // Actualizar estado de botones
            actualizarBotonesActivos();
            
            // Actualizar URL sin recargar
            actualizarURL(metrica, tipoGrafico);
            
        }, 500);
    }
    
    // Obtener título del gráfico
    function obtenerTituloGrafico(metrica) {
        const titulos = {
            'mes': 'Registros por Mes (Últimos 6 meses)',
            'año': 'Registros por Año',
            'estado': 'Registros por Estado',
            'sustancia': 'Registros por Tipo de Sustancia'
        };
        return titulos[metrica] || 'Gráfico de Registros';
    }
    
    // Generar gráfico
    function generarGrafico(datos, tipo, titulo) {
        if (!datos || Object.keys(datos).length === 0) {
            return '<div style="text-align: center; padding: 40px; color: #666;">No hay datos para mostrar</div>';
        }
        
        switch(tipo) {
            case 'barras':
                return generarGraficoBarras(datos, titulo);
            case 'lineas':
                return generarGraficoLineas(datos, titulo);
            case 'pastel':
                return generarGraficoPastel(datos, titulo);
            default:
                return generarGraficoBarras(datos, titulo);
        }
    }
    
    // Generar gráfico de barras
    function generarGraficoBarras(datos, titulo) {
        const valores = Object.values(datos);
        const maxValor = valores.length > 0 ? Math.max(...valores) : 0;
        const etiquetas = Object.keys(datos);
        const altura = 300;
        
        let html = `<div class="ac-grafico-barras" style="width: 100%; height: ${altura}px; display: flex; align-items: end; gap: 8px; padding: 20px 0; border-bottom: 1px solid #eee; position: relative;">`;
        
        etiquetas.forEach((etiqueta, index) => {
            const valor = valores[index];
            const alturaBarra = maxValor > 0 ? (valor / maxValor) * (altura - 50) : 0;
            const color = obtenerColorPorMetrica(metricaActual, index);
            
            html += `
                <div style="display: flex; flex-direction: column; align-items: center; flex: 1; position: relative;">
                    <div class="ac-barra" 
                         style="background: linear-gradient(to top, ${color}, ${color}99); 
                                width: 80%; 
                                height: ${alturaBarra}px; 
                                border-radius: 4px 4px 0 0; 
                                position: relative;
                                cursor: pointer;
                                transition: all 0.3s ease;"
                         onmouseover="this.style.background='linear-gradient(to top, ${color.replace('99', '')}, ${color})'; this.style.transform='translateY(-5px)';"
                         onmouseout="this.style.background='linear-gradient(to top, ${color}, ${color}99)'; this.style.transform='translateY(0)';"
                         title="${etiqueta}: ${valor} registros">
                        <span style="position: absolute; top: -25px; left: 50%; transform: translateX(-50%); font-size: 11px; font-weight: bold; color: ${color.replace('99', '')};">${valor}</span>
                    </div>
                    <div style="margin-top: 10px; font-size: 11px; text-align: center; color: #666; height: 40px; display: flex; align-items: center; justify-content: center;">
                        <span style="writing-mode: vertical-rl; transform: rotate(180deg); white-space: nowrap;">${etiqueta}</span>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        return html;
    }
    
    // Generar gráfico de líneas
    function generarGraficoLineas(datos, titulo) {
        const valores = Object.values(datos);
        const maxValor = valores.length > 0 ? Math.max(...valores) : 1;
        const etiquetas = Object.keys(datos);
        const altura = 300;
        
        let html = `<div class="ac-grafico-lineas" style="width: 100%; height: ${altura}px; position: relative; padding: 20px 0;">`;
        html += '<svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">';
        
        // Línea de fondo
        let pathData = '';
        const xIncremento = etiquetas.length > 1 ? 100 / (etiquetas.length - 1) : 100;
        
        valores.forEach((valor, index) => {
            const x = index * xIncremento;
            const y = 100 - ((valor / maxValor) * 95);
            if (index === 0) {
                pathData += `M ${x} ${y} `;
            } else {
                pathData += `L ${x} ${y} `;
            }
        });
        
        const color = obtenerColorPorMetrica(metricaActual, 0);
        html += `<path d="${pathData}" stroke="${color}" stroke-width="1.5" fill="none" />`;
        
        // Puntos
        valores.forEach((valor, index) => {
            const x = index * xIncremento;
            const y = 100 - ((valor / maxValor) * 95);
            
            html += `
                <g>
                    <circle cx="${x}" cy="${y}" r="1.5" fill="${color}" />
                    <circle cx="${x}" cy="${y}" r="4" fill="${color}33" 
                            style="cursor: pointer; transition: all 0.3s ease;"
                            onmouseover="this.style.r='6'; this.previousElementSibling.style.r='2';"
                            onmouseout="this.style.r='4'; this.previousElementSibling.style.r='1.5';" />
                    <text x="${x}" y="${y - 8}" text-anchor="middle" font-size="3" fill="${color}" font-weight="bold">${valor}</text>
                </g>
            `;
        });
        
        html += '</svg>';
        
        // Etiquetas del eje X
        html += '<div style="display: flex; justify-content: space-between; margin-top: 10px; padding: 0 10px;">';
        etiquetas.forEach(etiqueta => {
            html += `<span style="font-size: 10px; color: #666; transform: rotate(-45deg); display: inline-block; transform-origin: left bottom;">${etiqueta.substring(0, 8)}</span>`;
        });
        html += '</div>';
        
        html += '</div>';
        return html;
    }
    
    // Generar gráfico de pastel
    function generarGraficoPastel(datos, titulo) {
        const total = Object.values(datos).reduce((sum, val) => sum + val, 0);
        if (total === 0) {
            return '<div style="text-align: center; padding: 40px; color: #666;">No hay datos para mostrar</div>';
        }
        
        const radio = 200;
        let html = '<div class="ac-grafico-pastel" style="display: flex; align-items: center; justify-content: center; height: 300px;">';
        html += '<div style="width: ' + radio + 'px; height: ' + radio + 'px; border-radius: 50%; position: relative; background: conic-gradient(';
        
        const porcentajes = [];
        let inicio = 0;
        let index = 0;
        
        Object.entries(datos).forEach(([etiqueta, valor]) => {
            const porcentaje = (valor / total) * 100;
            const color = obtenerColorPorMetrica(metricaActual, index);
            porcentajes.push({ etiqueta, valor, porcentaje, color, inicio, fin: inicio + porcentaje });
            
            html += `${color} ${inicio}% ${inicio + porcentaje}%`;
            if (index < Object.keys(datos).length - 1) {
                html += ', ';
            }
            
            inicio += porcentaje;
            index++;
        });
        
        html += ');"></div>';
        
        // Leyenda
        html += '<div style="margin-left: 20px;">';
        porcentajes.forEach(item => {
            html += `
                <div style="display: flex; align-items: center; margin-bottom: 5px;">
                    <span style="display: inline-block; width: 12px; height: 12px; background: ${item.color}; margin-right: 8px; border-radius: 2px;"></span>
                    <span style="font-size: 12px; color: #666;">
                        ${item.etiqueta}: ${item.valor} (${Math.round(item.porcentaje)}%)
                    </span>
                </div>
            `;
        });
        html += '</div>';
        
        html += '</div>';
        return html;
    }
    
    // Obtener color por métrica e índice
    function obtenerColorPorMetrica(metrica, index) {
        const colores = {
            'mes': ['#0073aa', '#00a0d2', '#46b450', '#ffb900', '#dc3232', '#826eb4'],
            'año': ['#0073aa', '#00a0d2', '#46b450', '#ffb900'],
            'estado': ['#46b450', '#0073aa', '#ffb900', '#dc3232'],
            'sustancia': ['#0073aa', '#00a0d2', '#46b450', '#ffb900', '#dc3232', '#826eb4', '#ff6b6b', '#4ecdc4']
        };
        
        const paleta = colores[metrica] || colores.mes;
        return paleta[index % paleta.length];
    }
    
    // Actualizar botones activos
    function actualizarBotonesActivos() {
        $('.ac-metrica-btn').removeClass('button-primary').addClass('button-secondary');
        $('.ac-grafico-btn').removeClass('button-primary').addClass('button-secondary');
        
        $(`.ac-metrica-btn[data-metrica="${metricaActual}"]`).removeClass('button-secondary').addClass('button-primary');
        $(`.ac-grafico-btn[data-grafico="${tipoGraficoActual}"]`).removeClass('button-secondary').addClass('button-primary');
    }
    
    // Actualizar URL sin recargar
    function actualizarURL(metrica, tipoGrafico) {
        const url = new URL(window.location);
        url.searchParams.set('metricas', metrica);
        url.searchParams.set('tipo_grafico', tipoGrafico);
        window.history.replaceState({}, '', url);
    }
    
    // Event listeners para botones
    $('.ac-metrica-btn').on('click', function() {
        metricaActual = $(this).data('metrica');
        cargarGrafico(metricaActual, tipoGraficoActual);
    });
    
    $('.ac-grafico-btn').on('click', function() {
        tipoGraficoActual = $(this).data('grafico');
        cargarGrafico(metricaActual, tipoGraficoActual);
    });
    
    // Búsqueda en tiempo real
    $('#buscar-registros').on('keyup', function() {
        var searchText = $(this).val().toLowerCase();
        var resultados = 0;
        
        $('.ac-registro-row').each(function() {
            var paciente = $(this).data('paciente');
            var sustancia = $(this).data('sustancia');
            var estado = $(this).data('estado');
            
            if (paciente.indexOf(searchText) > -1 || 
                sustancia.indexOf(searchText) > -1 || 
                estado.indexOf(searchText) > -1) {
                $(this).show();
                resultados++;
            } else {
                $(this).hide();
            }
        });
        
        $('.description').text(resultados + ' registro(s) encontrado(s)');
    });
    
    // Ordenar por días limpios (mayor a menor)
    var rows = $('.ac-registro-row').get();
    rows.sort(function(a, b) {
        var diasA = parseInt($(a).find('.ac-badge-dias').text());
        var diasB = parseInt($(b).find('.ac-badge-dias').text());
        return diasB - diasA;
    });
    
    $.each(rows, function(index, row) {
        $('#tabla-registros tbody').append(row);
    });
    
    // Inicializar el gráfico al cargar la página
    inicializarGrafico();
});
</script>

<style>
.ac-table-container {
    margin-top: 20px;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

/* Estilos para badges de días limpios */
.ac-badge-dias-inicio {
    background: #ffebee !important;
    color: #c62828 !important;
}

.ac-badge-dias-regular {
    background: #fff3e0 !important;
    color: #ef6c00 !important;
}

.ac-badge-dias-bueno {
    background: #e8f5e8 !important;
    color: #2e7d32 !important;
}

.ac-badge-dias-excelente {
    background: #e3f2fd !important;
    color: #1565c0 !important;
}

/* Estilos para badges de estado */
.ac-badge-estado-abstinente {
    background: #d4edda !important;
    color: #155724 !important;
}

.ac-badge-estado-en_progreso {
    background: #cce5ff !important;
    color: #004085 !important;
}

.ac-badge-estado-recaida {
    background: #f8d7da !important;
    color: #721c24 !important;
}

.ac-badge-estado-completado {
    background: #e2e3e5 !important;
    color: #383d41 !important;
}

/* Estilos para interactividad */
.ac-barra {
    transition: all 0.3s ease !important;
}

.ac-barra:hover {
    transform: translateY(-5px) !important;
    box-shadow: 0 4px 8px rgba(0,0,0,0.2) !important;
}

@media (max-width: 768px) {
    .ac-stats-container {
        grid-template-columns: 1fr !important;
    }
    
    .ac-header-actions {
        flex-direction: column;
        gap: 15px;
        align-items: flex-start !important;
    }
    
    .ac-action-buttons {
        flex-direction: column;
    }
    
    #buscar-registros {
        width: 100% !important;
    }
    
    .ac-import-section > div {
        grid-template-columns: 1fr !important;
    }
    
    .ac-grafico-pastel {
        flex-direction: column;
    }
    
    .ac-grafico-barras {
        gap: 4px !important;
    }
}

/* Animaciones */
@keyframes aparecerBarras {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.ac-barra {
    animation: aparecerBarras 0.5s ease forwards;
}
</style>