<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1>📊 Seguimiento Terapéutico</h1>
    
    <div class="ac-record-header">
        <div class="ac-record-info">
            <h2>Seguimiento del <?php echo date('d/m/Y', strtotime($seguimiento->getFechaSeguimiento())); ?></h2>
            <p class="ac-record-meta">
                <strong>Paciente:</strong> <?php echo esc_html($seguimiento->getPaciente()->getNombreCompleto()); ?> |
                <strong>Terapeuta:</strong> <?php echo esc_html($seguimiento->getTerapeuta()->getNombreCompleto()); ?> |
                <strong>Tipo:</strong> <?php echo esc_html(ucfirst($seguimiento->getTipoSeguimiento())); ?>
            </p>
        </div>
        <div class="ac-record-actions">
            <a href="<?php echo admin_url('admin.php?page=ac-seguimiento-terapeutico&action=editar&id=' . $seguimiento->getId()); ?>" class="button button-primary">✏️ Editar</a>
            <a href="<?php echo admin_url('admin.php?page=ac-seguimiento-terapeutico' . ($seguimiento->getPacienteId() ? '&paciente_id=' . $seguimiento->getPacienteId() : '')); ?>" class="button">← Volver</a>
        </div>
    </div>

    <div class="ac-record-details">
        <div class="ac-row">
            <div class="ac-col">
                <div class="ac-card">
                    <div class="ac-card-header">
                        <h3>📝 Información del Seguimiento</h3>
                    </div>
                    <div class="ac-card-body">
                        <table class="ac-details-table">
                            <tr><th>Paciente:</th><td><?php echo esc_html($seguimiento->getPaciente()->getNombreCompleto()); ?></td></tr>
                            <tr><th>Terapeuta:</th><td><?php echo esc_html($seguimiento->getTerapeuta()->getNombreCompleto()); ?></td></tr>
                            <tr><th>Fecha de Seguimiento:</th><td><?php echo date('d/m/Y', strtotime($seguimiento->getFechaSeguimiento())); ?></td></tr>
                            <tr><th>Tipo de Seguimiento:</th><td><?php echo esc_html(ucfirst($seguimiento->getTipoSeguimiento())); ?></td></tr>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="ac-col">
                <div class="ac-card">
                    <div class="ac-card-header">
                        <h3>📈 Progreso</h3>
                    </div>
                    <div class="ac-card-body">
                        <table class="ac-details-table">
                            <tr><th>Nivel de Progreso:</th>
                                <td>
                                    <?php
                                    $nivel = $seguimiento->getNivelProgreso();
                                    $badge_class = 'ac-badge-';
                                    switch ($nivel) {
                                        case 'excelente':
                                            $badge_class .= 'success';
                                            break;
                                        case 'bueno':
                                            $badge_class .= 'info';
                                            break;
                                        case 'regular':
                                            $badge_class .= 'warning';
                                            break;
                                        case 'bajo':
                                            $badge_class .= 'error';
                                            break;
                                        default:
                                            $badge_class .= 'default';
                                    }
                                    ?>
                                    <span class="ac-badge <?php echo $badge_class; ?>"><?php echo ucfirst($nivel); ?></span>
                                </td>
                            </tr>
                            <tr><th>Próxima Sesión:</th><td><?php echo $seguimiento->getProximaSesion() ? date('d/m/Y', strtotime($seguimiento->getProximaSesion())) : 'No programada'; ?></td></tr>
                            <tr><th>Fecha de Registro:</th><td><?php echo date('d/m/Y H:i', strtotime($seguimiento->getCreatedAt())); ?></td></tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="ac-card">
            <div class="ac-card-header">
                <h3>🎯 Progreso del Tratamiento</h3>
            </div>
            <div class="ac-card-body">
                <div class="ac-progress-info">
                    <div class="ac-progress-section">
                        <h4>Objetivo del Tratamiento</h4>
                        <p><?php echo $seguimiento->getObjetivoTratamiento() ? nl2br(esc_html($seguimiento->getObjetivoTratamiento())) : 'No especificado'; ?></p>
                    </div>
                    
                    <div class="ac-progress-section">
                        <h4>Progreso Observado</h4>
                        <p><?php echo $seguimiento->getProgresoObservado() ? nl2br(esc_html($seguimiento->getProgresoObservado())) : 'No especificado'; ?></p>
                    </div>
                    
                    <div class="ac-progress-section">
                        <h4>Dificultades Identificadas</h4>
                        <p><?php echo $seguimiento->getDificultadesIdentificadas() ? nl2br(esc_html($seguimiento->getDificultadesIdentificadas())) : 'No se identificaron dificultades.'; ?></p>
                    </div>
                    
                    <div class="ac-progress-section">
                        <h4>Intervenciones Realizadas</h4>
                        <p><?php echo $seguimiento->getIntervencionesRealizadas() ? nl2br(esc_html($seguimiento->getIntervencionesRealizadas())) : 'No se realizaron intervenciones.'; ?></p>
                    </div>
                    
                    <div class="ac-progress-section">
                        <h4>Tareas Asignadas</h4>
                        <p><?php echo $seguimiento->getTareasAsignadas() ? nl2br(esc_html($seguimiento->getTareasAsignadas())) : 'No se asignaron tareas.'; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="ac-card">
            <div class="ac-card-header">
                <h3>📝 Observaciones del Terapeuta</h3>
            </div>
            <div class="ac-card-body">
                <p><?php echo $seguimiento->getObservacionesTerapeuta() ? nl2br(esc_html($seguimiento->getObservacionesTerapeuta())) : 'No hay observaciones.'; ?></p>
            </div>
        </div>
    </div>
</div>