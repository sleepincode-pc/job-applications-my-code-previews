<div class="wrap">
    <h1>Gestión de Miembros 
        <a href="<?php echo admin_url('admin.php?page=ac-miembros&action=nuevo'); ?>" class="page-title-action">
            Agregar Nuevo Miembro
        </a>
    </h1>
    
    <div class="ac-form-section">
        <form method="get">
            <input type="hidden" name="page" value="ac-miembros">
            <div style="display: flex; gap: 10px; align-items: center; margin-bottom: 20px;">
                <input type="text" name="busqueda" placeholder="Buscar por cédula, nombre, apellido o email..." 
                       value="<?php echo esc_attr($busqueda); ?>" style="flex: 1; max-width: 400px;">
                <button type="submit" class="button">Buscar</button>
                <?php if (!empty($busqueda)): ?>
                    <a href="<?php echo admin_url('admin.php?page=ac-miembros'); ?>" class="button">Limpiar</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    
    <div class="ac-table-container">
        <table class="wp-list-table widefat fixed striped ac-table">
            <thead>
                <tr>
                    <th>Cédula</th>
                    <th>Nombre Completo</th>
                    <th>Email</th>
                    <th>Teléfono</th>
                    <th>Cargo</th>
                    <th>Fecha Ingreso</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($miembros): ?>
                    <?php foreach ($miembros as $miembro): ?>
                        <tr>
                            <td><?php echo esc_html($miembro->cedula); ?></td>
                            <td>
                                <strong><?php echo esc_html($miembro->nombre . ' ' . $miembro->apellido); ?></strong>
                                <?php if ($miembro->tipo_membresia !== 'activo'): ?>
                                    <br><small><?php echo esc_html(ucfirst($miembro->tipo_membresia)); ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html($miembro->email); ?></td>
                            <td><?php echo esc_html($miembro->telefono); ?></td>
                            <td><?php echo esc_html($miembro->cargo ?: 'Miembro'); ?></td>
                            <td><?php echo date('d/m/Y', strtotime($miembro->fecha_ingreso)); ?></td>
                            <td>
                                <span class="ac-estado ac-estado-<?php echo esc_attr($miembro->estado); ?>">
                                    <?php echo esc_html(ucfirst($miembro->estado)); ?>
                                </span>
                            </td>
                            <td class="ac-actions">
                                <a href="<?php echo admin_url('admin.php?page=ac-miembros&action=editar&cedula=' . $miembro->cedula); ?>" 
                                   class="button button-small">Editar</a>
                                <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ac-miembros&action=eliminar&cedula=' . $miembro->cedula), 'eliminar_miembro_' . $miembro->cedula); ?>" 
                                   class="button button-small button-link-delete" 
                                   onclick="return confirm('¿Está seguro de que desea eliminar este miembro?')">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" style="text-align: center;">
                            <?php if (!empty($busqueda)): ?>
                                No se encontraron miembros que coincidan con la búsqueda.
                            <?php else: ?>
                                No hay miembros registrados. <a href="<?php echo admin_url('admin.php?page=ac-miembros&action=nuevo'); ?>">Agregar el primer miembro</a>.
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <div class="ac-export-section">
        <h3>Exportar Miembros</h3>
        <p>Exportar lista de miembros en formato CSV.</p>
        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
            <input type="hidden" name="action" value="exportar_miembros">
            <?php wp_nonce_field('exportar_miembros'); ?>
            <button type="submit" class="button">Exportar CSV</button>
        </form>
    </div>
</div>