<?php
// Campos para Psicodramas
function ac_definir_campos_psicodrama() {
    return array(
        'fecha_sesion' => array(
            'type' => 'date',
            'label' => 'Fecha de Sesión',
            'required' => true
        ),
        'hora_inicio' => array(
            'type' => 'time',
            'label' => 'Hora de Inicio'
        ),
        'hora_fin' => array(
            'type' => 'time',
            'label' => 'Hora de Fin'
        ),
        'protagonista' => array(
            'type' => 'text',
            'label' => 'Protagonista',
            'required' => true
        ),
        'director' => array(
            'type' => 'text',
            'label' => 'Director del Psicodrama'
        ),
        'yo_auxiliares' => array(
            'type' => 'textarea',
            'label' => 'Yo Auxiliares Participantes'
        ),
        'tematica_principal' => array(
            'type' => 'text',
            'label' => 'Temática Principal'
        ),
        'tecnicas_utilizadas' => array(
            'type' => 'checkbox',
            'label' => 'Técnicas Utilizadas',
            'options' => array(
                'silla_vacia' => 'Silla Vacía',
                'inversion_roles' => 'Inversión de Roles',
                'espejo' => 'Espejo',
                'soliloquio' => 'Soliloquio',
                'proyeccion_futuro' => 'Proyección al Futuro',
                'doble' => 'Doble'
            )
        ),
        'descripcion_escena' => array(
            'type' => 'textarea',
            'label' => 'Descripción de la Escena'
        ),
        'momentos_clave' => array(
            'type' => 'textarea',
            'label' => 'Momentos Clave'
        ),
        'catarsis_lograda' => array(
            'type' => 'textarea',
            'label' => 'Catarsis Lograda'
        ),
        'insights_protagonista' => array(
            'type' => 'textarea',
            'label' => 'Insights del Protagonista'
        ),
        'compartir_grupo' => array(
            'type' => 'textarea',
            'label' => 'Compartir del Grupo'
        ),
        'reflexiones_finales' => array(
            'type' => 'textarea',
            'label' => 'Reflexiones Finales'
        ),
        'tareas_asignadas' => array(
            'type' => 'textarea',
            'label' => 'Tareas Asignadas'
        )
    );
}
?>