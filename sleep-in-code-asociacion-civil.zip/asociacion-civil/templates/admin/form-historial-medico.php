<?php
if (!defined('ABSPATH')) {
    exit;
}

$es_nuevo = !$historial->getId();
$titulo = $es_nuevo ? 'Agregar Nuevo Registro de Historial Médico' : 'Editar Registro de Historial Médico';
?>

<div class="wrap" style="background: white; color: black; padding: 20px;">
    <h1 style="color: black;"><?php echo $titulo; ?></h1>

    <form method="post">
        <?php wp_nonce_field('guardar_historial_medico', 'historial_medico_nonce'); ?>
        
        <div class="ac-card" style="background: white; border: 1px solid #ccc; border-radius: 8px; margin-bottom: 20px;">
            <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                <h2 style="color: black; margin: 0;">📝 Información de la Consulta</h2>
            </div>
            <div class="ac-card-body" style="padding: 20px;">
                <table class="form-table" style="color: black; width: 100%;">
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0; width: 200px;"><label for="paciente_id">Paciente *</label></th>
                        <td style="padding: 10px 0;">
                            <select id="paciente_id" name="paciente_id" class="regular-text" required <?php echo !$es_nuevo ? 'disabled' : ''; ?> style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 400px;">
                                <option value="">Seleccionar paciente...</option>
                                <?php foreach ($pacientes as $p): ?>
                                    <option value="<?php echo $p->getId(); ?>" <?php selected($historial->getPacienteId(), $p->getId()); ?>>
                                        <?php echo esc_html(($p->getNombreCompleto() ?? '') . ' (' . ($p->getCedula() ?? '') . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (!$es_nuevo): ?>
                                <input type="hidden" name="paciente_id" value="<?php echo $historial->getPacienteId(); ?>">
                                <p class="description" style="color: #666; margin: 5px 0 0 0;">No se puede cambiar el paciente una vez creado el registro.</p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="fecha_consulta">Fecha de Consulta *</label></th>
                        <td style="padding: 10px 0;">
                            <input type="date" id="fecha_consulta" name="fecha_consulta" value="<?php echo esc_attr($historial->getFechaConsulta() ?? ''); ?>" class="regular-text" required style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 200px;">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="tipo_consulta">Tipo de Consulta *</label></th>
                        <td style="padding: 10px 0;">
                            <select id="tipo_consulta" name="tipo_consulta" class="regular-text" required style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 400px;">
                                <option value="">Seleccionar...</option>
                                <option value="rutina" <?php selected($historial->getTipoConsulta() ?? '', 'rutina'); ?>>Consulta de Rutina</option>
                                <option value="emergencia" <?php selected($historial->getTipoConsulta() ?? '', 'emergencia'); ?>>Emergencia</option>
                                <option value="seguimiento" <?php selected($historial->getTipoConsulta() ?? '', 'seguimiento'); ?>>Seguimiento</option>
                                <option value="control" <?php selected($historial->getTipoConsulta() ?? '', 'control'); ?>>Control</option>
                                <option value="otros" <?php selected($historial->getTipoConsulta() ?? '', 'otros'); ?>>Otros</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="medico_tratante">Médico Tratante</label></th>
                        <td style="padding: 10px 0;">
                            <input type="text" id="medico_tratante" name="medico_tratante" value="<?php echo esc_attr($historial->getMedicoTratante() ?? ''); ?>" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 400px;">
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="ac-card" style="background: white; border: 1px solid #ccc; border-radius: 8px; margin-bottom: 20px;">
            <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                <h2 style="color: black; margin: 0;">🏥 Información Médica</h2>
            </div>
            <div class="ac-card-body" style="padding: 20px;">
                <table class="form-table" style="color: black; width: 100%;">
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0; width: 200px;"><label for="diagnostico">Diagnóstico</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="diagnostico" name="diagnostico" rows="5" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($historial->getDiagnostico() ?? ''); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="tratamiento_prescrito">Tratamiento Prescrito</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="tratamiento_prescrito" name="tratamiento_prescrito" rows="5" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($historial->getTratamientoPrescrito() ?? ''); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="medicamentos_recetados">Medicamentos Recetados</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="medicamentos_recetados" name="medicamentos_recetados" rows="3" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($historial->getMedicamentosRecetados() ?? ''); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="examenes_solicitados">Exámenes Solicitados</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="examenes_solicitados" name="examenes_solicitados" rows="3" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($historial->getExamenesSolicitados() ?? ''); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="resultados_examenes">Resultados de Exámenes</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="resultados_examenes" name="resultados_examenes" rows="3" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($historial->getResultadosExamenes() ?? ''); ?></textarea>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="ac-card" style="background: white; border: 1px solid #ccc; border-radius: 8px; margin-bottom: 20px;">
            <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
                <h2 style="color: black; margin: 0;">📅 Seguimiento</h2>
            </div>
            <div class="ac-card-body" style="padding: 20px;">
                <table class="form-table" style="color: black; width: 100%;">
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0; width: 200px;"><label for="observaciones">Observaciones</label></th>
                        <td style="padding: 10px 0;">
                            <textarea id="observaciones" name="observaciones" rows="3" class="large-text" style="color: black; border: 1px solid #ccc; padding: 8px; width: 100%;"><?php echo esc_textarea($historial->getObservaciones() ?? ''); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" style="color: black; padding: 10px 0;"><label for="proxima_cita">Próxima Cita</label></th>
                        <td style="padding: 10px 0;">
                            <input type="date" id="proxima_cita" name="proxima_cita" value="<?php echo esc_attr($historial->getProximaCita() ?? ''); ?>" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px; width: 100%; max-width: 200px;">
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <p class="submit">
            <input type="submit" name="guardar_historial_medico" class="button button-primary" value="💾 Guardar Registro" style="color: white; background: #0073aa; border: 1px solid #0073aa; padding: 10px 20px; border-radius: 4px; font-size: 14px; cursor: pointer;">
            <a href="<?php echo admin_url('admin.php?page=ac-historial-medico' . ($historial->getPacienteId() ? '&paciente_id=' . $historial->getPacienteId() : '')); ?>" class="button" style="color: #555; background: #f7f7f7; border: 1px solid #ccc; text-decoration: none; padding: 10px 20px; border-radius: 4px; font-size: 14px; margin-left: 10px;">❌ Cancelar</a>
        </p>
    </form>
</div>

<style>
.form-table th {
    color: black;
    font-weight: 600;
}

.form-table td {
    color: black;
}

.large-text {
    color: black;
    border: 1px solid #ccc;
    padding: 8px;
    width: 100%;
}

.regular-text {
    color: black;
    border: 1px solid #ccc;
    padding: 5px;
}

select.regular-text {
    color: black;
    border: 1px solid #ccc;
    padding: 5px;
}

input[type="date"] {
    color: black;
    border: 1px solid #ccc;
    padding: 5px;
}

.button-primary:hover {
    background: #005a87 !important;
    border-color: #005a87 !important;
}

.button:hover {
    background: #e5e5e5 !important;
    border-color: #bbb !important;
}

.description {
    color: #666;
    font-style: italic;
    margin: 5px 0 0 0;
}
</style>