<?php
// Campos para Pacientes
function ac_definir_campos_paciente() {
    return array(
        'nombre_completo' => array(
            'type' => 'text',
            'label' => 'Nombre Completo',
            'required' => true
        ),
        'fecha_nacimiento' => array(
            'type' => 'date',
            'label' => 'Fecha de Nacimiento'
        ),
        'edad' => array(
            'type' => 'number',
            'label' => 'Edad'
        ),
        'genero' => array(
            'type' => 'select',
            'label' => 'Género',
            'options' => array(
                'masculino' => 'Masculino',
                'femenino' => 'Femenino',
                'otro' => 'Otro',
                'prefiero_no_decir' => 'Prefiero no decir'
            )
        ),
        'documento_identidad' => array(
            'type' => 'text',
            'label' => 'Documento de Identidad'
        ),
        'telefono' => array(
            'type' => 'tel',
            'label' => 'Teléfono'
        ),
        'email' => array(
            'type' => 'email',
            'label' => 'Correo Electrónico'
        ),
        'direccion' => array(
            'type' => 'textarea',
            'label' => 'Dirección'
        ),
        'motivo_consulta' => array(
            'type' => 'textarea',
            'label' => 'Motivo de Consulta',
            'required' => true
        ),
        'fecha_primer_contacto' => array(
            'type' => 'date',
            'label' => 'Fecha Primer Contacto'
        ),
        'profesional_referente' => array(
            'type' => 'text',
            'label' => 'Profesional Referente'
        ),
        'estado_actual' => array(
            'type' => 'select',
            'label' => 'Estado Actual',
            'options' => array(
                'activo' => 'Activo',
                'inactivo' => 'Inactivo',
                'alta' => 'Alta',
                'suspendido' => 'Suspendido'
            )
        )
    );
}
?>