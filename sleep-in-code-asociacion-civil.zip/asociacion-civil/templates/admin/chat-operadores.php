<?php
// Verificar seguridad
if (!defined('ABSPATH')) {
    exit;
}

$salas = array(
    'general' => '💬 General',
    'operadores' => '👥 Operadores', 
    'coordinacion' => '📋 Coordinación',
    'urgencias' => '🚨 Urgencias',
    'terapeutico' => '💊 Área Terapéutica'
);

$sala_actual = isset($_GET['sala']) ? sanitize_text_field($_GET['sala']) : 'general';
$usuario_actual = wp_get_current_user();
$nonce = wp_create_nonce('chat_operadores_nonce');

// Diagnóstico temporal (solo para admin)
if (current_user_can('manage_options') && isset($_GET['debug_chat'])) {
    global $wpdb;
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}chat_operadores'");
    echo '<div class="notice notice-info">';
    echo '<h3>🔧 Debug Chat</h3>';
    echo '<p><strong>Tabla existe:</strong> ' . ($table_exists ? '✅ SÍ' : '❌ NO') . '</p>';
    echo '<p><strong>Usuario:</strong> ' . $usuario_actual->display_name . '</p>';
    echo '<p><strong>Sala actual:</strong> ' . $sala_actual . '</p>';
    echo '<p><strong>Nonce:</strong> ' . $nonce . '</p>';
    echo '</div>';
}
?>

<div class="wrap">
    <header class="chat-main-header">
        <div class="chat-header-content">
            <div class="chat-title-section">
                <h1 class="chat-main-title">
                    <span class="chat-title-icon">💬</span>
                    Chat de Operadores
                </h1>
                <p class="chat-subtitle">Sistema de comunicación interna para el personal de la asociación</p>
            </div>
            <div class="chat-header-actions">
                <div class="connection-status" id="estado-conexion-global">
                    <div class="status-indicator" id="status-indicator"></div>
                    <span class="status-text" id="mensaje-estado-conexion">Conectando...</span>
                </div>
            </div>
        </div>
    </header>

    <main class="chat-application">
        <!-- Sidebar Navigation -->
        <aside class="chat-sidebar">
            <!-- Salas de Chat -->
            <section class="sidebar-section">
                <h2 class="sidebar-section-title">
                    <span class="section-icon">🏠</span>
                    Salas de Chat
                </h2>
                <nav class="rooms-navigation" aria-label="Navegación de salas">
                    <ul class="rooms-list">
                        <?php foreach ($salas as $clave => $nombre): ?>
                            <li class="room-item">
                                <a href="<?php echo admin_url('admin.php?page=ac-chat-operadores&sala=' . $clave); ?>" 
                                   class="room-link <?php echo $sala_actual === $clave ? 'room-active' : ''; ?>"
                                   aria-current="<?php echo $sala_actual === $clave ? 'page' : 'false'; ?>">
                                    <span class="room-icon"><?php echo substr($nombre, 0, 2); ?></span>
                                    <span class="room-name"><?php echo esc_html(substr($nombre, 2)); ?></span>
                                    <?php if ($sala_actual === $clave): ?>
                                        <span class="active-indicator"></span>
                                    <?php endif; ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </nav>
            </section>

            <!-- Usuarios Conectados -->
            <section class="sidebar-section">
                <h2 class="sidebar-section-title">
                    <span class="section-icon">👥</span>
                    Operadores Conectados
                    <span class="users-count-badge" id="sidebar-users-count">1</span>
                </h2>
                <div class="users-container">
                    <ul class="users-list" id="lista-usuarios">
                        <li class="user-item current-user">
                            <div class="user-avatar">
                                <span class="user-avatar-initial"><?php echo strtoupper(substr($usuario_actual->display_name ?: $usuario_actual->user_login, 0, 1)); ?></span>
                                <span class="user-status online"></span>
                            </div>
                            <div class="user-info">
                                <span class="user-name"><?php echo esc_html($usuario_actual->display_name ?: $usuario_actual->user_login); ?></span>
                                <span class="user-badge">Tú</span>
                            </div>
                        </li>
                    </ul>
                </div>
            </section>

            <!-- Información de Sala -->
            <section class="sidebar-section">
                <h2 class="sidebar-section-title">
                    <span class="section-icon">ℹ️</span>
                    Información
                </h2>
                <div class="room-info-card">
                    <div class="info-item">
                        <span class="info-label">Sala actual:</span>
                        <span class="info-value" id="nombre-sala-actual"><?php echo esc_html($salas[$sala_actual] ?? $sala_actual); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Tus permisos:</span>
                        <span class="info-value badge-operator">Operador</span>
                    </div>
                    <?php if (current_user_can('manage_options')): ?>
                        <div class="info-actions">
                            <a href="<?php echo add_query_arg('debug_chat', '1'); ?>" class="debug-button">
                                <span class="debug-icon">🔧</span>
                                Modo Debug
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        </aside>

        <!-- Área Principal del Chat -->
        <div class="chat-main-area">
            <!-- Header del Chat -->
            <header class="chat-room-header">
                <div class="room-header-info">
                    <div class="room-title-section">
                        <h2 class="room-title" id="titulo-sala">
                            <?php echo esc_html($salas[$sala_actual] ?? $sala_actual); ?>
                        </h2>
                        <div class="room-meta">
                            <span class="online-indicator"></span>
                            <span class="users-online" id="contador-usuarios">1 usuario conectado</span>
                        </div>
                    </div>
                </div>
                
                <div class="chat-controls">
                    <button type="button" id="recargar-chat" class="control-button" title="Recargar mensajes">
                        <span class="button-icon">🔄</span>
                        <span class="button-text">Recargar</span>
                    </button>
                    <button type="button" id="limpiar-chat" class="control-button" title="Limpiar chat visual">
                        <span class="button-icon">🧹</span>
                        <span class="button-text">Limpiar</span>
                    </button>
                    <button type="button" id="diagnosticar-chat" class="control-button warning" title="Diagnosticar problemas">
                        <span class="button-icon">🔧</span>
                        <span class="button-text">Diagnosticar</span>
                    </button>
                </div>
            </header>

            <!-- Área de Mensajes -->
            <section class="messages-area">
                <div class="messages-container" id="contenedor-mensajes">
                    <div class="loading-state">
                        <div class="loading-spinner"></div>
                        <p class="loading-text">Cargando mensajes...</p>
                    </div>
                </div>
            </section>

            <!-- Área de Escritura -->
            <footer class="message-composer">
                <form id="formulario-mensaje" class="message-form">
                    <div class="composer-container">
                        <div class="input-container">
                            <textarea 
                                id="input-mensaje" 
                                class="message-input"
                                placeholder="Escribe tu mensaje aquí... (Enter para enviar, Shift+Enter para nueva línea)" 
                                rows="1"
                                maxlength="1000"
                                aria-label="Escribir mensaje"
                            ></textarea>
                            <button type="submit" id="boton-enviar" class="send-button" aria-label="Enviar mensaje">
                                <span class="send-icon">📤</span>
                            </button>
                        </div>
                        <div class="composer-footer">
                            <div class="character-counter">
                                <span id="contador" class="counter-number">0</span>
                                <span class="counter-separator">/</span>
                                <span class="counter-total">1000</span>
                                <span class="counter-label">caracteres</span>
                            </div>
                        </div>
                    </div>
                </form>
                
                <!-- Indicadores de Estado -->
                <div class="chat-status-indicators">
                    <div class="status-items">
                        <div id="indicador-conexion" class="status-item connected">
                            <span class="status-dot"></span>
                            <span class="status-text">Conectado</span>
                        </div>
                        <div id="indicador-escritura" class="status-item typing" style="display: none;">
                            <span class="typing-animation">
                                <span class="typing-dot"></span>
                                <span class="typing-dot"></span>
                                <span class="typing-dot"></span>
                            </span>
                            <span class="status-text">Alguien está escribiendo...</span>
                        </div>
                        <div id="indicador-carga" class="status-item loading" style="display: none;">
                            <span class="loading-spinner-mini"></span>
                            <span class="status-text">Cargando...</span>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </main>
</div>

<style>
/* ===== VARIABLES CSS ===== */
:root {
    /* Colores principales */
    --primary-color: #2563eb;
    --primary-dark: #1d4ed8;
    --primary-light: #dbeafe;
    --secondary-color: #64748b;
    --accent-color: #f59e0b;
    
    /* Colores de estado */
    --success-color: #10b981;
    --warning-color: #f59e0b;
    --error-color: #ef4444;
    --info-color: #3b82f6;
    
    /* Escala de grises */
    --gray-50: #f8fafc;
    --gray-100: #f1f5f9;
    --gray-200: #e2e8f0;
    --gray-300: #cbd5e1;
    --gray-400: #94a3b8;
    --gray-500: #64748b;
    --gray-600: #475569;
    --gray-700: #334155;
    --gray-800: #1e293b;
    --gray-900: #0f172a;
    
    /* Tipografía */
    --font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, sans-serif;
    --font-size-xs: 0.75rem;
    --font-size-sm: 0.875rem;
    --font-size-base: 1rem;
    --font-size-lg: 1.125rem;
    --font-size-xl: 1.25rem;
    --font-size-2xl: 1.5rem;
    
    /* Espaciado */
    --spacing-xs: 0.25rem;
    --spacing-sm: 0.5rem;
    --spacing-md: 1rem;
    --spacing-lg: 1.5rem;
    --spacing-xl: 2rem;
    --spacing-2xl: 3rem;
    
    /* Bordes */
    --border-radius-sm: 0.375rem;
    --border-radius-md: 0.5rem;
    --border-radius-lg: 0.75rem;
    --border-radius-xl: 1rem;
    
    /* Sombras */
    --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
    --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    
    /* Transiciones */
    --transition-fast: 0.15s ease-in-out;
    --transition-normal: 0.3s ease-in-out;
    --transition-slow: 0.5s ease-in-out;
}

/* ===== RESET Y ESTILOS BASE ===== */
.chat-application * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

.chat-application {
    font-family: var(--font-family);
    line-height: 1.5;
    color: var(--gray-800);
    background-color: var(--gray-50);
}

/* ===== LAYOUT PRINCIPAL ===== */
.chat-main-header {
    background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
    color: white;
    padding: var(--spacing-lg) 0;
    margin-bottom: 0;
}

.chat-header-content {
    max-width: 100%;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 var(--spacing-lg);
}

.chat-title-section {
    flex: 1;
}

.chat-main-title {
    font-size: var(--font-size-2xl);
    font-weight: 700;
    margin-bottom: var(--spacing-xs);
    display: flex;
    align-items: center;
    gap: var(--spacing-sm);
}

.chat-title-icon {
    font-size: 1.5em;
}

.chat-subtitle {
    opacity: 0.9;
    font-size: var(--font-size-sm);
    margin: 0;
}

.connection-status {
    display: flex;
    align-items: center;
    gap: var(--spacing-sm);
    background: rgba(255, 255, 255, 0.1);
    padding: var(--spacing-sm) var(--spacing-md);
    border-radius: var(--border-radius-lg);
    backdrop-filter: blur(10px);
}

.status-indicator {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--success-color);
    animation: pulse 2s infinite;
}

.status-text {
    font-size: var(--font-size-sm);
    font-weight: 500;
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

/* ===== LAYOUT DE LA APLICACIÓN ===== */
.chat-application {
    display: grid;
    grid-template-columns: 320px 1fr;
    min-height: calc(100vh - 200px);
    gap: 0;
}

/* ===== SIDEBAR ===== */
.chat-sidebar {
    background: white;
    border-right: 1px solid var(--gray-200);
    display: flex;
    flex-direction: column;
    height: 100%;
    overflow-y: auto;
}

.sidebar-section {
    padding: var(--spacing-lg);
    border-bottom: 1px solid var(--gray-200);
}

.sidebar-section:last-child {
    border-bottom: none;
}

.sidebar-section-title {
    font-size: var(--font-size-sm);
    font-weight: 600;
    color: var(--gray-600);
    margin-bottom: var(--spacing-md);
    display: flex;
    align-items: center;
    gap: var(--spacing-sm);
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.section-icon {
    font-size: var(--font-size-lg);
}

/* Navegación de Salas */
.rooms-list {
    list-style: none;
    display: flex;
    flex-direction: column;
    gap: var(--spacing-xs);
}

.room-item {
    position: relative;
}

.room-link {
    display: flex;
    align-items: center;
    gap: var(--spacing-md);
    padding: var(--spacing-md);
    text-decoration: none;
    color: var(--gray-700);
    border-radius: var(--border-radius-md);
    transition: all var(--transition-fast);
    position: relative;
    border: 1px solid transparent;
}

.room-link:hover {
    background: var(--gray-50);
    border-color: var(--gray-200);
    transform: translateY(-1px);
}

.room-link.room-active {
    background: var(--primary-light);
    color: var(--primary-color);
    border-color: var(--primary-color);
    font-weight: 600;
}

.room-icon {
    font-size: var(--font-size-lg);
    width: 24px;
    text-align: center;
}

.room-name {
    flex: 1;
    font-weight: 500;
}

.active-indicator {
    width: 6px;
    height: 6px;
    background: var(--primary-color);
    border-radius: 50%;
    margin-left: auto;
}

/* Lista de Usuarios */
.users-count-badge {
    background: var(--primary-color);
    color: white;
    font-size: var(--font-size-xs);
    padding: 2px 6px;
    border-radius: 10px;
    margin-left: auto;
}

.users-container {
    max-height: 200px;
    overflow-y: auto;
}

.users-list {
    list-style: none;
    display: flex;
    flex-direction: column;
    gap: var(--spacing-sm);
}

.user-item {
    display: flex;
    align-items: center;
    gap: var(--spacing-md);
    padding: var(--spacing-sm);
    border-radius: var(--border-radius-md);
    transition: background-color var(--transition-fast);
}

.user-item:hover {
    background: var(--gray-50);
}

.user-item.current-user {
    background: var(--primary-light);
}

.user-avatar {
    position: relative;
    width: 32px;
    height: 32px;
}

.user-avatar-initial {
    width: 100%;
    height: 100%;
    background: var(--primary-color);
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    font-size: var(--font-size-sm);
}

.user-status {
    position: absolute;
    bottom: 0;
    right: 0;
    width: 8px;
    height: 8px;
    border: 2px solid white;
    border-radius: 50%;
}

.user-status.online {
    background: var(--success-color);
}

.user-info {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.user-name {
    font-weight: 500;
    font-size: var(--font-size-sm);
}

.user-badge {
    font-size: var(--font-size-xs);
    color: var(--gray-500);
    background: var(--gray-100);
    padding: 1px 6px;
    border-radius: 4px;
    align-self: flex-start;
}

/* Información de Sala */
.room-info-card {
    background: var(--gray-50);
    padding: var(--spacing-md);
    border-radius: var(--border-radius-md);
    border: 1px solid var(--gray-200);
}

.info-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: var(--spacing-sm) 0;
    border-bottom: 1px solid var(--gray-200);
}

.info-item:last-child {
    border-bottom: none;
    padding-bottom: 0;
}

.info-item:first-child {
    padding-top: 0;
}

.info-label {
    font-size: var(--font-size-sm);
    color: var(--gray-600);
    font-weight: 500;
}

.info-value {
    font-size: var(--font-size-sm);
    color: var(--gray-800);
    font-weight: 600;
}

.badge-operator {
    background: var(--primary-color);
    color: white;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: var(--font-size-xs);
    font-weight: 600;
}

.info-actions {
    margin-top: var(--spacing-md);
    padding-top: var(--spacing-md);
    border-top: 1px solid var(--gray-200);
}

.debug-button {
    display: inline-flex;
    align-items: center;
    gap: var(--spacing-sm);
    padding: var(--spacing-sm) var(--spacing-md);
    background: var(--gray-100);
    color: var(--gray-700);
    text-decoration: none;
    border-radius: var(--border-radius-md);
    font-size: var(--font-size-sm);
    font-weight: 500;
    transition: all var(--transition-fast);
    border: 1px solid var(--gray-300);
}

.debug-button:hover {
    background: var(--gray-200);
    transform: translateY(-1px);
}

/* ===== ÁREA PRINCIPAL DEL CHAT ===== */
.chat-main-area {
    display: flex;
    flex-direction: column;
    background: white;
    height: 100%;
}

/* Header del Chat */
.chat-room-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: var(--spacing-lg);
    border-bottom: 1px solid var(--gray-200);
    background: white;
    box-shadow: var(--shadow-sm);
}

.room-header-info {
    display: flex;
    align-items: center;
    gap: var(--spacing-lg);
}

.room-title {
    font-size: var(--font-size-xl);
    font-weight: 700;
    color: var(--gray-900);
    margin: 0;
}

.room-meta {
    display: flex;
    align-items: center;
    gap: var(--spacing-sm);
}

.online-indicator {
    width: 6px;
    height: 6px;
    background: var(--success-color);
    border-radius: 50%;
    animation: pulse 2s infinite;
}

.users-online {
    font-size: var(--font-size-sm);
    color: var(--gray-600);
}

.chat-controls {
    display: flex;
    gap: var(--spacing-sm);
}

.control-button {
    display: inline-flex;
    align-items: center;
    gap: var(--spacing-sm);
    padding: var(--spacing-sm) var(--spacing-md);
    background: white;
    color: var(--gray-700);
    border: 1px solid var(--gray-300);
    border-radius: var(--border-radius-md);
    font-size: var(--font-size-sm);
    font-weight: 500;
    cursor: pointer;
    transition: all var(--transition-fast);
}

.control-button:hover {
    background: var(--gray-50);
    border-color: var(--gray-400);
    transform: translateY(-1px);
}

.control-button.warning {
    background: var(--warning-color);
    color: white;
    border-color: var(--warning-color);
}

.control-button.warning:hover {
    background: #e6a200;
    border-color: #e6a200;
}

.button-icon {
    font-size: var(--font-size-lg);
}

/* Área de Mensajes */
.messages-area {
    flex: 1;
    overflow: hidden;
    position: relative;
}

.messages-container {
    height: 100%;
    overflow-y: auto;
    padding: var(--spacing-lg);
    display: flex;
    flex-direction: column;
    gap: var(--spacing-md);
}

.loading-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: var(--spacing-2xl);
    color: var(--gray-500);
}

.loading-spinner {
    width: 40px;
    height: 40px;
    border: 3px solid var(--gray-200);
    border-top: 3px solid var(--primary-color);
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin-bottom: var(--spacing-md);
}

.loading-text {
    font-size: var(--font-size-sm);
    color: var(--gray-600);
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

/* Mensajes Individuales */
.message {
    max-width: 70%;
    padding: var(--spacing-md);
    border-radius: var(--border-radius-lg);
    position: relative;
    animation: messageSlide 0.3s ease-out;
    box-shadow: var(--shadow-sm);
}

@keyframes messageSlide {
    from {
        opacity: 0;
        transform: translateY(10px) scale(0.95);
    }
    to {
        opacity: 1;
        transform: translateY(0) scale(1);
    }
}

.message-own {
    background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
    color: white;
    margin-left: auto;
    align-self: flex-end;
}

.message-other {
    background: var(--gray-100);
    color: var(--gray-800);
    margin-right: auto;
    align-self: flex-start;
    border: 1px solid var(--gray-200);
}

.message-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: var(--spacing-xs);
    font-size: var(--font-size-xs);
}

.message-user {
    font-weight: 600;
    opacity: 0.9;
}

.message-time {
    opacity: 0.7;
}

.message-content {
    line-height: 1.5;
    word-wrap: break-word;
    font-size: var(--font-size-sm);
}

.message-actions {
    margin-top: var(--spacing-sm);
    text-align: right;
}

.btn-delete {
    background: rgba(255, 255, 255, 0.2);
    border: none;
    color: inherit;
    padding: 4px 8px;
    border-radius: var(--border-radius-sm);
    font-size: var(--font-size-xs);
    cursor: pointer;
    opacity: 0.7;
    transition: opacity var(--transition-fast);
}

.btn-delete:hover {
    opacity: 1;
}

/* Composer de Mensajes */
.message-composer {
    border-top: 1px solid var(--gray-200);
    background: white;
    padding: var(--spacing-lg);
}

.message-form {
    margin-bottom: var(--spacing-md);
}

.composer-container {
    border: 1px solid var(--gray-300);
    border-radius: var(--border-radius-lg);
    background: white;
    transition: border-color var(--transition-fast);
}

.composer-container:focus-within {
    border-color: var(--primary-color);
    box-shadow: 0 0 0 3px var(--primary-light);
}

.input-container {
    display: flex;
    align-items: flex-end;
    gap: var(--spacing-md);
    padding: var(--spacing-md);
}

.message-input {
    flex: 1;
    resize: none;
    min-height: 40px;
    max-height: 120px;
    border: none;
    outline: none;
    font-family: inherit;
    font-size: var(--font-size-base);
    line-height: 1.5;
    color: var(--gray-800);
    background: transparent;
}

.message-input::placeholder {
    color: var(--gray-500);
}

.send-button {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    background: var(--primary-color);
    color: white;
    border: none;
    border-radius: var(--border-radius-md);
    cursor: pointer;
    transition: all var(--transition-fast);
    flex-shrink: 0;
}

.send-button:hover {
    background: var(--primary-dark);
    transform: translateY(-1px);
}

.send-button:active {
    transform: translateY(0);
}

.send-icon {
    font-size: var(--font-size-lg);
}

.composer-footer {
    padding: 0 var(--spacing-md) var(--spacing-md);
    display: flex;
    justify-content: flex-end;
}

.character-counter {
    display: flex;
    align-items: center;
    gap: 2px;
    font-size: var(--font-size-xs);
    color: var(--gray-500);
}

.counter-number {
    font-weight: 600;
}

.counter-number.limit-exceeded {
    color: var(--error-color);
}

/* Indicadores de Estado */
.chat-status-indicators {
    border-top: 1px solid var(--gray-200);
    padding-top: var(--spacing-md);
}

.status-items {
    display: flex;
    gap: var(--spacing-lg);
    align-items: center;
}

.status-item {
    display: flex;
    align-items: center;
    gap: var(--spacing-sm);
    font-size: var(--font-size-sm);
    color: var(--gray-600);
}

.status-item.connected {
    color: var(--success-color);
}

.status-dot {
    width: 6px;
    height: 6px;
    background: currentColor;
    border-radius: 50%;
}

.status-item.typing {
    color: var(--warning-color);
}

.typing-animation {
    display: flex;
    gap: 2px;
}

.typing-dot {
    width: 4px;
    height: 4px;
    background: currentColor;
    border-radius: 50%;
    animation: typing 1.4s infinite ease-in-out;
}

.typing-dot:nth-child(1) { animation-delay: -0.32s; }
.typing-dot:nth-child(2) { animation-delay: -0.16s; }

@keyframes typing {
    0%, 80%, 100% { transform: scale(0.8); opacity: 0.5; }
    40% { transform: scale(1); opacity: 1; }
}

.status-item.loading {
    color: var(--primary-color);
}

.loading-spinner-mini {
    width: 12px;
    height: 12px;
    border: 2px solid currentColor;
    border-top: 2px solid transparent;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

/* ===== RESPONSIVE ===== */
@media (max-width: 1024px) {
    .chat-application {
        grid-template-columns: 280px 1fr;
    }
    
    .chat-header-content {
        padding: 0 var(--spacing-md);
    }
    
    .sidebar-section {
        padding: var(--spacing-md);
    }
}

@media (max-width: 768px) {
    .chat-application {
        grid-template-columns: 1fr;
    }
    
    .chat-sidebar {
        display: none;
    }
    
    .chat-room-header {
        padding: var(--spacing-md);
        flex-direction: column;
        gap: var(--spacing-md);
        align-items: stretch;
    }
    
    .room-header-info {
        justify-content: space-between;
    }
    
    .chat-controls {
        justify-content: center;
    }
    
    .message {
        max-width: 85%;
    }
    
    .messages-container {
        padding: var(--spacing-md);
    }
}

@media (max-width: 480px) {
    .chat-main-header {
        padding: var(--spacing-md) 0;
    }
    
    .chat-header-content {
        flex-direction: column;
        gap: var(--spacing-md);
        text-align: center;
    }
    
    .chat-main-title {
        font-size: var(--font-size-xl);
    }
    
    .message-composer {
        padding: var(--spacing-md);
    }
    
    .input-container {
        padding: var(--spacing-sm);
        gap: var(--spacing-sm);
    }
    
    .message {
        max-width: 90%;
        padding: var(--spacing-sm);
        margin: var(--spacing-xs) var(--spacing-sm);
    }
    
    .control-button .button-text {
        display: none;
    }
    
    .control-button {
        padding: var(--spacing-sm);
    }
}

/* ===== ESTADOS ESPECIALES ===== */
.message-temp {
    opacity: 0.7;
}

.message-error {
    background: #fef2f2;
    border: 1px solid var(--error-color);
    color: #7f1d1d;
    text-align: center;
    margin: var(--spacing-md) auto;
    padding: var(--spacing-md);
    border-radius: var(--border-radius-md);
    max-width: 80%;
}

/* Notificaciones */
.chat-notification {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 1000;
    max-width: 400px;
}

.notification {
    padding: var(--spacing-md);
    border-radius: var(--border-radius-md);
    margin-bottom: var(--spacing-sm);
    box-shadow: var(--shadow-lg);
    border-left: 4px solid;
    animation: slideInRight 0.3s ease-out;
}

.notification-success {
    background: #f0fdf4;
    border-left-color: var(--success-color);
    color: #166534;
}

.notification-error {
    background: #fef2f2;
    border-left-color: var(--error-color);
    color: #7f1d1d;
}

.notification-warning {
    background: #fffbeb;
    border-left-color: var(--warning-color);
    color: #92400e;
}

.notification-info {
    background: #eff6ff;
    border-left-color: var(--info-color);
    color: #1e40af;
}

@keyframes slideInRight {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

/* Scrollbar personalizado */
.messages-container::-webkit-scrollbar {
    width: 6px;
}

.messages-container::-webkit-scrollbar-track {
    background: var(--gray-100);
}

.messages-container::-webkit-scrollbar-thumb {
    background: var(--gray-400);
    border-radius: 3px;
}

.messages-container::-webkit-scrollbar-thumb:hover {
    background: var(--gray-500);
}

.users-container::-webkit-scrollbar {
    width: 4px;
}

.users-container::-webkit-scrollbar-track {
    background: transparent;
}

.users-container::-webkit-scrollbar-thumb {
    background: var(--gray-300);
    border-radius: 2px;
}

.users-container::-webkit-scrollbar-thumb:hover {
    background: var(--gray-400);
}
</style>

<script>
jQuery(document).ready(function($) {
    // Variables globales
    let ultimoMensajeId = 0;
    let salaActual = '<?php echo esc_js($sala_actual); ?>';
    let cargandoMensajes = false;
    let intervaloActualizacion;
    let intervaloUsuarios;
    const nonce = '<?php echo esc_js($nonce); ?>';
    let intentosReconexion = 0;
    const maxIntentosReconexion = 5;

    // Sistema de notificaciones
    function mostrarNotificacion(mensaje, tipo = 'info', duracion = 5000) {
        // Crear contenedor de notificaciones si no existe
        if ($('#chat-notifications').length === 0) {
            $('body').append('<div id="chat-notifications" class="chat-notification"></div>');
        }
        
        const notification = $(`
            <div class="notification notification-${tipo}" role="alert">
                <p>${mensaje}</p>
            </div>
        `);
        
        $('#chat-notifications').append(notification);
        
        // Auto-remover después de la duración
        setTimeout(() => {
            notification.fadeOut(300, function() {
                $(this).remove();
            });
        }, duracion);
    }

    // Función para actualizar estado de conexión
    function actualizarEstadoConexion(mensaje, tipo = 'info') {
        const indicador = $('#status-indicator');
        const texto = $('#mensaje-estado-conexion');
        const contenedor = $('#estado-conexion-global');
        
        // Remover clases anteriores
        indicador.removeClass('connecting connected error warning');
        contenedor.removeClass('connecting connected error warning');
        
        // Aplicar nuevo estado
        switch(tipo) {
            case 'error':
                indicador.addClass('error').css('background', 'var(--error-color)');
                contenedor.addClass('error');
                break;
            case 'warning':
                indicador.addClass('warning').css('background', 'var(--warning-color)');
                contenedor.addClass('warning');
                break;
            case 'success':
                indicador.addClass('connected').css('background', 'var(--success-color)');
                contenedor.addClass('connected');
                break;
            default:
                indicador.addClass('connecting').css('background', 'var(--info-color)');
                contenedor.addClass('connecting');
        }
        
        texto.text(mensaje);
    }

    // Inicializar chat
    function inicializarChat() {
        actualizarEstadoConexion('Conectando al chat...', 'info');
        cargarMensajes();
        cargarUsuariosConectados();
        configurarEventos();
        iniciarActualizacionAutomatica();
    }
    
    // Configurar eventos
    function configurarEventos() {
        // Envío de mensajes
        $('#formulario-mensaje').on('submit', function(e) {
            e.preventDefault();
            enviarMensaje();
        });
        
        // Atajo de teclado: Enter para enviar, Shift+Enter para nueva línea
        $('#input-mensaje').on('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                enviarMensaje();
            }
        });
        
        // Auto-expandir textarea y contador de caracteres
        $('#input-mensaje').on('input', function() {
            const longitud = $(this).val().length;
            $('#contador').text(longitud);
            
            if (longitud > 1000) {
                $('#contador').addClass('limit-exceeded');
            } else {
                $('#contador').removeClass('limit-exceeded');
            }
            
            // Auto-expandir
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });
        
        // Recargar mensajes
        $('#recargar-chat').on('click', function() {
            cargarMensajes();
            cargarUsuariosConectados();
            mostrarNotificacion('Recargando mensajes...', 'info');
        });
        
        // Limpiar chat visual
        $('#limpiar-chat').on('click', function() {
            if (confirm('¿Estás seguro de que quieres limpiar el chat? Esto solo afecta tu vista.')) {
                $('#contenedor-mensajes').empty();
                ultimoMensajeId = 0;
                cargarMensajes();
            }
        });
        
        // Diagnosticar chat
        $('#diagnosticar-chat').on('click', function() {
            diagnosticarChat();
        });
    }
    
    // Enviar mensaje
    function enviarMensaje() {
        const mensaje = $('#input-mensaje').val().trim();
        
        if (!mensaje) {
            mostrarNotificacion('Por favor escribe un mensaje', 'warning');
            return;
        }
        
        if (mensaje.length > 1000) {
            mostrarNotificacion('El mensaje no puede tener más de 1000 caracteres', 'error');
            return;
        }
        
        // Mostrar mensaje localmente inmediatamente
        mostrarMensajeLocal({
            id: 'temp-' + Date.now(),
            usuario: 'Tú',
            mensaje: mensaje,
            fecha: new Date().toISOString(),
            propio: true,
            sala: salaActual
        });
        
        // Limpiar input
        $('#input-mensaje').val('').height('auto');
        $('#contador').text('0').removeClass('limit-exceeded');
        
        // Enviar al servidor
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'enviar_mensaje_chat',
                nonce: nonce,
                mensaje: mensaje,
                sala: salaActual
            },
            success: function(response) {
                if (response.success) {
                    // Reemplazar mensaje temporal con el real
                    $('.message-temp').last().remove();
                    mostrarMensaje(response.data);
                    ultimoMensajeId = Math.max(ultimoMensajeId, response.data.id);
                    mostrarNotificacion('Mensaje enviado correctamente', 'success');
                } else {
                    mostrarNotificacion('Error: ' + response.data, 'error');
                    // Remover mensaje temporal en caso de error
                    $('.message-temp').last().remove();
                }
            },
            error: function(xhr, status, error) {
                mostrarNotificacion('Error de conexión al enviar el mensaje', 'error');
                console.error('Error al enviar mensaje:', error);
                $('.message-temp').last().remove();
            }
        });
    }
    
    // Cargar mensajes
    function cargarMensajes() {
        if (cargandoMensajes) return;
        
        cargandoMensajes = true;
        $('#indicador-carga').show();
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cargar_mensajes_chat',
                nonce: nonce,
                sala: salaActual,
                ultimo_id: ultimoMensajeId
            },
            success: function(response) {
                $('#indicador-carga').hide();
                
                if (response.success) {
                    actualizarEstadoConexion('Chat conectado', 'success');
                    intentosReconexion = 0;
                    
                    if (ultimoMensajeId === 0) {
                        $('#contenedor-mensajes').empty();
                    }
                    
                    if (response.data.length > 0) {
                        response.data.forEach(function(mensaje) {
                            mostrarMensaje(mensaje);
                            ultimoMensajeId = Math.max(ultimoMensajeId, mensaje.id);
                        });
                    }
                    
                    if (ultimoMensajeId === 0 && response.data.length === 0) {
                        $('#contenedor-mensajes').html(
                            '<div class="loading-state"><p>No hay mensajes en esta sala. ¡Sé el primero en escribir!</p></div>'
                        );
                    }
                } else {
                    console.error('Error al cargar mensajes: ' + response.data);
                    mostrarNotificacion('Error: ' + response.data, 'error');
                    mostrarErrorChat('No se pudieron cargar los mensajes: ' + response.data);
                }
            },
            error: function(xhr, status, error) {
                $('#indicador-carga').hide();
                console.error('Error de conexión al cargar mensajes:', error);
                
                intentosReconexion++;
                if (intentosReconexion <= maxIntentosReconexion) {
                    actualizarEstadoConexion(`Reconectando... (${intentosReconexion}/${maxIntentosReconexion})`, 'warning');
                    
                    setTimeout(function() {
                        cargandoMensajes = false;
                        cargarMensajes();
                    }, 3000);
                } else {
                    actualizarEstadoConexion('Error de conexión', 'error');
                    mostrarErrorChat('No se pudo conectar al servidor del chat. Por favor verifica tu conexión.');
                }
            },
            complete: function() {
                cargandoMensajes = false;
            }
        });
    }
    
    // Cargar usuarios conectados
    function cargarUsuariosConectados() {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'obtener_usuarios_conectados',
                nonce: nonce,
                sala: salaActual
            },
            success: function(response) {
                if (response.success) {
                    actualizarListaUsuarios(response.data);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error al cargar usuarios conectados:', error);
            }
        });
    }
    
    // Actualizar lista de usuarios
    function actualizarListaUsuarios(usuarios) {
        const lista = $('#lista-usuarios');
        const usuarioActual = '<?php echo esc_js($usuario_actual->display_name ?: $usuario_actual->user_login); ?>';
        
        // Mantener el usuario actual
        lista.find('.current-user').show();
        
        // Remover otros usuarios
        lista.find('.user-item:not(.current-user)').remove();
        
        // Agregar otros usuarios
        if (usuarios && usuarios.length > 0) {
            usuarios.forEach(function(usuario) {
                if (usuario.usuario_nombre !== usuarioActual) {
                    const inicial = usuario.usuario_nombre.charAt(0).toUpperCase();
                    lista.append(`
                        <li class="user-item">
                            <div class="user-avatar">
                                <span class="user-avatar-initial">${inicial}</span>
                                <span class="user-status online"></span>
                            </div>
                            <div class="user-info">
                                <span class="user-name">${usuario.usuario_nombre}</span>
                            </div>
                        </li>
                    `);
                }
            });
        }
        
        // Actualizar contadores
        const totalUsuarios = usuarios ? usuarios.length : 1;
        $('#contador-usuarios').text(totalUsuarios + ' usuario' + (totalUsuarios !== 1 ? 's' : '') + ' conectado' + (totalUsuarios !== 1 ? 's' : ''));
        $('#sidebar-users-count').text(totalUsuarios);
    }
    
    // Mostrar mensaje local (temporal)
    function mostrarMensajeLocal(mensaje) {
        const elemento = crearElementoMensaje(mensaje);
        elemento.addClass('message-temp');
        $('#contenedor-mensajes').append(elemento);
        scrollToBottom();
    }
    
    // Mostrar mensaje del servidor
    function mostrarMensaje(mensaje) {
        const elemento = crearElementoMensaje(mensaje);
        $('#contenedor-mensajes').append(elemento);
        scrollToBottom();
    }
    
    // Crear elemento HTML para mensaje
    function crearElementoMensaje(mensaje) {
        const fecha = new Date(mensaje.fecha);
        const fechaFormateada = fecha.toLocaleTimeString('es-ES', {
            hour: '2-digit',
            minute: '2-digit'
        });
        
        const claseMensaje = mensaje.propio ? 'message message-own' : 'message message-other';
        
        const elemento = $(`
            <div class="${claseMensaje}" data-mensaje-id="${mensaje.id}">
                <div class="message-header">
                    <span class="message-user">${mensaje.usuario}</span>
                    <span class="message-time">${fechaFormateada}</span>
                </div>
                <div class="message-content">${mensaje.mensaje}</div>
                ${mensaje.propio ? '<div class="message-actions"><button class="btn-delete" title="Eliminar mensaje">🗑️ Eliminar</button></div>' : ''}
            </div>
        `);
        
        // Evento para eliminar mensaje
        if (mensaje.propio) {
            elemento.find('.btn-delete').on('click', function() {
                eliminarMensaje(mensaje.id, elemento);
            });
        }
        
        return elemento;
    }
    
    // Eliminar mensaje
    function eliminarMensaje(mensajeId, elemento) {
        if (!confirm('¿Estás seguro de que quieres eliminar este mensaje?')) {
            return;
        }
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'eliminar_mensaje_chat',
                nonce: nonce,
                mensaje_id: mensajeId
            },
            success: function(response) {
                if (response.success) {
                    elemento.fadeOut(300, function() {
                        $(this).remove();
                    });
                    mostrarNotificacion('Mensaje eliminado correctamente', 'success');
                } else {
                    mostrarNotificacion('Error al eliminar mensaje: ' + response.data, 'error');
                }
            },
            error: function(xhr, status, error) {
                mostrarNotificacion('Error de conexión al eliminar mensaje', 'error');
                console.error('Error al eliminar mensaje:', error);
            }
        });
    }
    
    // Función para mostrar errores en el chat
    function mostrarErrorChat(mensaje) {
        const existeError = $('#error-chat-temporal').length;
        
        if (!existeError) {
            $('#contenedor-mensajes').prepend(
                `<div id="error-chat-temporal" class="message-error">
                    <p>${mensaje}</p>
                </div>`
            );
            
            setTimeout(function() {
                $('#error-chat-temporal').fadeOut(300, function() {
                    $(this).remove();
                });
            }, 10000);
        }
    }
    
    // Scroll al final
    function scrollToBottom() {
        const contenedor = $('#contenedor-mensajes');
        contenedor.scrollTop(contenedor[0].scrollHeight);
    }
    
    // Diagnosticar problemas del chat
    function diagnosticarChat() {
        mostrarNotificacion('Ejecutando diagnóstico...', 'info');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'diagnosticar_chat',
                nonce: nonce
            },
            success: function(response) {
                if (response.success) {
                    let mensajeDiagnostico = '✅ Diagnóstico completado:\n';
                    for (const [key, value] of Object.entries(response.data)) {
                        mensajeDiagnostico += `• ${key}: ${value}\n`;
                    }
                    alert(mensajeDiagnostico);
                    mostrarNotificacion('Diagnóstico completado', 'success');
                } else {
                    mostrarNotificacion('Error en diagnóstico: ' + response.data, 'error');
                }
            },
            error: function() {
                mostrarNotificacion('Error al ejecutar diagnóstico', 'error');
            }
        });
    }
    
    // Actualización automática
    function iniciarActualizacionAutomatica() {
        intervaloActualizacion = setInterval(function() {
            if (!cargandoMensajes) {
                cargarMensajes();
            }
        }, 5000);
        
        intervaloUsuarios = setInterval(function() {
            cargarUsuariosConectados();
        }, 15000);
    }
    
    // Detener actualización automática
    function detenerActualizacionAutomatica() {
        if (intervaloActualizacion) {
            clearInterval(intervaloActualizacion);
        }
        if (intervaloUsuarios) {
            clearInterval(intervaloUsuarios);
        }
    }
    
    // Inicializar cuando la página está lista
    inicializarChat();
    
    // Limpiar al salir de la página
    $(window).on('beforeunload', function() {
        detenerActualizacionAutomatica();
    });
});
</script>