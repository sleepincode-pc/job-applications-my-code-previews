<div class="wrap">
    <h1><?php echo $evento ? 'Editar Evento' : 'Agregar Nuevo Evento'; ?></h1>
    
    <div class="ac-form-section">
        <form method="post">
            <?php wp_nonce_field('guardar_evento', 'evento_nonce'); ?>
            
            <div class="ac-form-group">
                <label for="titulo">Título del Evento *</label>
                <input type="text" id="titulo" name="titulo" required 
                       value="<?php echo esc_attr($evento ? $evento->getTitulo() : ''); ?>"
                       placeholder="Ej: Asamblea General Ordinaria">
            </div>
            
            <div class="ac-form-group">
                <label for="descripcion">Descripción</label>
                <textarea id="descripcion" name="descripcion" rows="4" 
                          placeholder="Descripción detallada del evento"><?php 
                    echo esc_textarea($evento ? $evento->getDescripcion() : ''); 
                ?></textarea>
            </div>
            
            <div class="ac-form-grid">
                <div class="ac-form-group">
                    <label for="fecha">Fecha y Hora *</label>
                    <input type="datetime-local" id="fecha" name="fecha" required 
                           value="<?php echo esc_attr($evento ? date('Y-m-d\TH:i', strtotime($evento->getFecha())) : ''); ?>">
                </div>
                
                <div class="ac-form-group">
                    <label for="lugar">Lugar</label>
                    <input type="text" id="lugar" name="lugar" 
                           value="<?php echo esc_attr($evento ? $evento->getLugar() : ''); ?>"
                           placeholder="Ej: Sede de la asociación">
                </div>
            </div>
            
            <div class="ac-form-grid">
                <div class="ac-form-group">
                    <label for="tipo">Tipo de Evento *</label>
                    <select id="tipo" name="tipo" required>
                        <option value="reunion" <?php selected($evento ? $evento->getTipo() : '', 'reunion'); ?>>Reunión</option>
                        <option value="asamblea" <?php selected($evento ? $evento->getTipo() : '', 'asamblea'); ?>>Asamblea</option>
                        <option value="evento" <?php selected($evento ? $evento->getTipo() : '', 'evento'); ?>>Evento</option>
                        <option value="otros" <?php selected($evento ? $evento->getTipo() : '', 'otros'); ?>>Otros</option>
                    </select>
                </div>
                
                <div class="ac-form-group">
                    <label for="estado">Estado *</label>
                    <select id="estado" name="estado" required>
                        <option value="planificado" <?php selected($evento ? $evento->getEstado() : '', 'planificado'); ?>>Planificado</option>
                        <option value="realizado" <?php selected($evento ? $evento->getEstado() : '', 'realizado'); ?>>Realizado</option>
                        <option value="cancelado" <?php selected($evento ? $evento->getEstado() : '', 'cancelado'); ?>>Cancelado</option>
                    </select>
                </div>
            </div>
            
            <div id="asamblea-fields" style="display: <?php echo ($evento && $evento->getTipo() === 'asamblea') || (!$evento) ? 'block' : 'none'; ?>;">
                <div class="ac-form-group">
                    <label for="convocatoria">Convocatoria (Solo para asambleas)</label>
                    <textarea id="convocatoria" name="convocatoria" rows="3" 
                              placeholder="Texto de la convocatoria"><?php 
                        echo esc_textarea($evento ? $evento->getConvocatoria() : ''); 
                    ?></textarea>
                </div>
                
                <div class="ac-form-group">
                    <label for="orden_del_dia">Orden del Día (Solo para asambleas)</label>
                    <textarea id="orden_del_dia" name="orden_del_dia" rows="4" 
                              placeholder="Puntos a tratar en la asamblea"><?php 
                        echo esc_textarea($evento ? $evento->getOrdenDelDia() : ''); 
                    ?></textarea>
                </div>
            </div>
            
            <?php if ($evento && $evento->getEstado() === 'realizado'): ?>
                <div class="ac-form-group">
                    <label for="acta">Acta del Evento</label>
                    <textarea id="acta" name="acta" rows="6" 
                              placeholder="Resumen o acta de lo tratado en el evento"><?php 
                        echo esc_textarea($evento ? $evento->getActa() : ''); 
                    ?></textarea>
                </div>
                
                <div class="ac-form-group">
                    <label for="asistentes">Lista de Asistentes (uno por línea)</label>
                    <textarea id="asistentes" name="asistentes" rows="4" 
                              placeholder="Nombres de los asistentes, uno por línea"><?php 
                        $asistentes = $evento ? $evento->getAsistentes() : array();
                        echo esc_textarea(implode("\n", $asistentes)); 
                    ?></textarea>
                </div>
            <?php endif; ?>
            
            <div class="ac-form-submit">
                <button type="submit" class="button button-primary button-large">
                    <?php echo $evento ? 'Actualizar Evento' : 'Guardar Evento'; ?>
                </button>
                <a href="<?php echo admin_url('admin.php?page=ac-eventos'); ?>" class="button button-large">Cancelar</a>
            </div>
        </form>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Mostrar/ocultar campos de asamblea
    $('#tipo').change(function() {
        if ($(this).val() === 'asamblea') {
            $('#asamblea-fields').show();
        } else {
            $('#asamblea-fields').hide();
        }
    });
    
    // Validación de fecha futura
    $('#fecha').on('change', function() {
        var fechaSeleccionada = new Date($(this).val());
        var fechaActual = new Date();
        
        if (fechaSeleccionada < fechaActual) {
            if (confirm('La fecha seleccionada es en el pasado. ¿Desea cambiar el estado a "Realizado"?')) {
                $('#estado').val('realizado');
            }
        }
    });
});
</script>