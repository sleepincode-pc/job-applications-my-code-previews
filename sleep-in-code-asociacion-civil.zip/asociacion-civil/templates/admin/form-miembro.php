<div class="wrap">
    <h1><?php echo $miembro ? 'Editar Miembro' : 'Agregar Nuevo Miembro'; ?></h1>
    
    <div class="ac-form-section">
        <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('guardar_miembro', 'miembro_nonce'); ?>
            
            <div class="ac-form-grid">
                <div class="ac-form-group">
                    <label for="cedula">Cédula *</label>
                    <input type="text" id="cedula" name="cedula" required 
                           value="<?php echo esc_attr($miembro ? $miembro->getCedula() : ''); ?>"
                           <?php echo $miembro ? 'readonly' : ''; ?>>
                    <p class="description">Número de cédula de identidad</p>
                </div>
                
                <div class="ac-form-group">
                    <label for="fecha_ingreso">Fecha de Ingreso *</label>
                    <input type="date" id="fecha_ingreso" name="fecha_ingreso" required
                           value="<?php echo esc_attr($miembro ? $miembro->getFechaIngreso() : date('Y-m-d')); ?>">
                </div>
            </div>
            
            <div class="ac-form-grid">
                <div class="ac-form-group">
                    <label for="nombre">Nombre *</label>
                    <input type="text" id="nombre" name="nombre" required 
                           value="<?php echo esc_attr($miembro ? $miembro->getNombre() : ''); ?>">
                </div>
                
                <div class="ac-form-group">
                    <label for="apellido">Apellido *</label>
                    <input type="text" id="apellido" name="apellido" required 
                           value="<?php echo esc_attr($miembro ? $miembro->getApellido() : ''); ?>">
                </div>
            </div>
            
            <div class="ac-form-grid">
                <div class="ac-form-group">
                    <label for="email">Email *</label>
                    <input type="email" id="email" name="email" required 
                           value="<?php echo esc_attr($miembro ? $miembro->getEmail() : ''); ?>">
                </div>
                
                <div class="ac-form-group">
                    <label for="telefono">Teléfono</label>
                    <input type="tel" id="telefono" name="telefono" 
                           value="<?php echo esc_attr($miembro ? $miembro->getTelefono() : ''); ?>">
                </div>
            </div>
            
            <div class="ac-form-group">
                <label for="direccion">Dirección</label>
                <textarea id="direccion" name="direccion" rows="3" 
                          placeholder="Dirección completa del miembro"><?php 
                    echo esc_textarea($miembro ? $miembro->getDireccion() : ''); 
                ?></textarea>
            </div>
            
            <div class="ac-form-grid">
                <div class="ac-form-group">
                    <label for="fecha_nacimiento">Fecha de Nacimiento</label>
                    <input type="date" id="fecha_nacimiento" name="fecha_nacimiento"
                           value="<?php echo esc_attr($miembro ? $miembro->getFechaNacimiento() : ''); ?>">
                </div>
                
                <div class="ac-form-group">
                    <label for="tipo_membresia">Tipo de Membresía</label>
                    <select id="tipo_membresia" name="tipo_membresia">
                        <option value="activo" <?php selected($miembro ? $miembro->getTipoMembresia() : '', 'activo'); ?>>Activo</option>
                        <option value="vitalicio" <?php selected($miembro ? $miembro->getTipoMembresia() : '', 'vitalicio'); ?>>Vitalicio</option>
                        <option value="honorario" <?php selected($miembro ? $miembro->getTipoMembresia() : '', 'honorario'); ?>>Honorario</option>
                    </select>
                </div>
            </div>
            
            <div class="ac-form-grid">
                <div class="ac-form-group">
                    <label for="cargo">Cargo en la Asociación</label>
                    <select id="cargo" name="cargo">
                        <option value="">Miembro Regular</option>
                        <option value="Presidente" <?php selected($miembro ? $miembro->getCargo() : '', 'Presidente'); ?>>Presidente</option>
                        <option value="Vicepresidente" <?php selected($miembro ? $miembro->getCargo() : '', 'Vicepresidente'); ?>>Vicepresidente</option>
                        <option value="Secretario" <?php selected($miembro ? $miembro->getCargo() : '', 'Secretario'); ?>>Secretario</option>
                        <option value="Tesorero" <?php selected($miembro ? $miembro->getCargo() : '', 'Tesorero'); ?>>Tesorero</option>
                        <option value="Vocal" <?php selected($miembro ? $miembro->getCargo() : '', 'Vocal'); ?>>Vocal</option>
                        <option value="Comisionado" <?php selected($miembro ? $miembro->getCargo() : '', 'Comisionado'); ?>>Comisionado</option>
                    </select>
                </div>
                
                <div class="ac-form-group">
                    <label for="estado">Estado</label>
                    <select id="estado" name="estado">
                        <option value="activo" <?php selected($miembro ? $miembro->getEstado() : '', 'activo'); ?>>Activo</option>
                        <option value="inactivo" <?php selected($miembro ? $miembro->getEstado() : '', 'inactivo'); ?>>Inactivo</option>
                        <option value="suspendido" <?php selected($miembro ? $miembro->getEstado() : '', 'suspendido'); ?>>Suspendido</option>
                    </select>
                </div>
            </div>
            
            <div class="ac-form-group">
                <label for="observaciones">Observaciones</label>
                <textarea id="observaciones" name="observaciones" rows="4" 
                          placeholder="Observaciones o notas adicionales sobre el miembro"><?php 
                    echo esc_textarea($miembro ? $miembro->getObservaciones() : ''); 
                ?></textarea>
            </div>
            
            <div class="ac-form-group">
                <label for="foto">Foto del Miembro</label>
                <input type="file" id="foto" name="foto" accept="image/*">
                <p class="description">Formatos permitidos: JPG, PNG, GIF. Tamaño máximo: 2MB</p>
            </div>
            
            <div class="ac-form-submit">
                <button type="submit" class="button button-primary button-large">
                    <?php echo $miembro ? 'Actualizar Miembro' : 'Guardar Miembro'; ?>
                </button>
                <a href="<?php echo admin_url('admin.php?page=ac-miembros'); ?>" class="button button-large">Cancelar</a>
            </div>
        </form>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Validación de cédula
    $('#cedula').on('blur', function() {
        var cedula = $(this).val();
        if (cedula.length > 0 && !/^\d+$/.test(cedula)) {
            alert('La cédula debe contener solo números');
            $(this).focus();
        }
    });
    
    // Validación de email
    $('#email').on('blur', function() {
        var email = $(this).val();
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (email.length > 0 && !emailRegex.test(email)) {
            alert('Por favor ingrese un email válido');
            $(this).focus();
        }
    });
});
</script>