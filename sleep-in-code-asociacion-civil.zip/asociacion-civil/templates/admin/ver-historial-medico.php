<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1>📋 Registro de Historial Médico</h1>
    
    <div class="ac-record-header">
        <div class="ac-record-info">
            <h2>Consulta del <?php echo date('d/m/Y', strtotime($historial->getFechaConsulta())); ?></h2>
            <p class="ac-record-meta">
                <strong>Paciente:</strong> <?php echo esc_html($historial->getPaciente()->getNombreCompleto()); ?> |
                <strong>Cédula:</strong> <?php echo esc_html($historial->getPaciente()->getCedula()); ?> |
                <strong>Tipo de Consulta:</strong> <?php echo esc_html(ucfirst($historial->getTipoConsulta())); ?>
            </p>
        </div>
        <div class="ac-record-actions">
            <a href="<?php echo admin_url('admin.php?page=ac-historial-medico&action=editar&id=' . $historial->getId()); ?>" class="button button-primary">✏️ Editar</a>
            <a href="<?php echo admin_url('admin.php?page=ac-historial-medico' . ($historial->getPacienteId() ? '&paciente_id=' . $historial->getPacienteId() : '')); ?>" class="button">← Volver</a>
        </div>
    </div>

    <div class="ac-record-details">
        <div class="ac-row">
            <div class="ac-col">
                <div class="ac-card">
                    <div class="ac-card-header">
                        <h3>📝 Información de la Consulta</h3>
                    </div>
                    <div class="ac-card-body">
                        <table class="ac-details-table">
                            <tr><th>Paciente:</th><td><?php echo esc_html($historial->getPaciente()->getNombreCompleto()); ?></td></tr>
                            <tr><th>Fecha de Consulta:</th><td><?php echo date('d/m/Y', strtotime($historial->getFechaConsulta())); ?></td></tr>
                            <tr><th>Tipo de Consulta:</th><td><?php echo esc_html(ucfirst($historial->getTipoConsulta())); ?></td></tr>
                            <tr><th>Médico Tratante:</th><td><?php echo esc_html($historial->getMedicoTratante() ?: 'No especificado'); ?></td></tr>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="ac-col">
                <div class="ac-card">
                    <div class="ac-card-header">
                        <h3>📅 Seguimiento</h3>
                    </div>
                    <div class="ac-card-body">
                        <table class="ac-details-table">
                            <tr><th>Próxima Cita:</th><td><?php echo $historial->getProximaCita() ? date('d/m/Y', strtotime($historial->getProximaCita())) : 'No programada'; ?></td></tr>
                            <tr><th>Fecha de Registro:</th><td><?php echo date('d/m/Y H:i', strtotime($historial->getCreatedAt())); ?></td></tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="ac-card">
            <div class="ac-card-header">
                <h3>🏥 Información Médica</h3>
            </div>
            <div class="ac-card-body">
                <div class="ac-medical-info">
                    <div class="ac-medical-section">
                        <h4>Diagnóstico</h4>
                        <p><?php echo $historial->getDiagnostico() ? nl2br(esc_html($historial->getDiagnostico())) : 'No especificado'; ?></p>
                    </div>
                    
                    <div class="ac-medical-section">
                        <h4>Tratamiento Prescrito</h4>
                        <p><?php echo $historial->getTratamientoPrescrito() ? nl2br(esc_html($historial->getTratamientoPrescrito())) : 'No especificado'; ?></p>
                    </div>
                    
                    <div class="ac-medical-section">
                        <h4>Medicamentos Recetados</h4>
                        <p><?php echo $historial->getMedicamentosRecetados() ? nl2br(esc_html($historial->getMedicamentosRecetados())) : 'No especificados'; ?></p>
                    </div>
                    
                    <div class="ac-medical-section">
                        <h4>Exámenes Solicitados</h4>
                        <p><?php echo $historial->getExamenesSolicitados() ? nl2br(esc_html($historial->getExamenesSolicitados())) : 'No especificados'; ?></p>
                    </div>
                    
                    <div class="ac-medical-section">
                        <h4>Resultados de Exámenes</h4>
                        <p><?php echo $historial->getResultadosExamenes() ? nl2br(esc_html($historial->getResultadosExamenes())) : 'No especificados'; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="ac-card">
            <div class="ac-card-header">
                <h3>📋 Observaciones</h3>
            </div>
            <div class="ac-card-body">
                <p><?php echo $historial->getObservaciones() ? nl2br(esc_html($historial->getObservaciones())) : 'No hay observaciones.'; ?></p>
            </div>
        </div>
    </div>
</div>