<?php
// Campos para Miembros
function ac_definir_campos_miembro() {
    return array(
        'nombre_completo' => array(
            'type' => 'text',
            'label' => 'Nombre Completo',
            'required' => true
        ),
        'fecha_nacimiento' => array(
            'type' => 'date',
            'label' => 'Fecha de Nacimiento'
        ),
        'documento_identidad' => array(
            'type' => 'text',
            'label' => 'Documento de Identidad'
        ),
        'telefono' => array(
            'type' => 'tel',
            'label' => 'Teléfono'
        ),
        'email' => array(
            'type' => 'email',
            'label' => 'Correo Electrónico'
        ),
        'direccion' => array(
            'type' => 'textarea',
            'label' => 'Dirección'
        ),
        'fecha_ingreso' => array(
            'type' => 'date',
            'label' => 'Fecha de Ingreso'
        ),
        'cargo' => array(
            'type' => 'text',
            'label' => 'Cargo'
        ),
        'area_trabajo' => array(
            'type' => 'text',
            'label' => 'Área de Trabajo'
        ),
        'estado_membresia' => array(
            'type' => 'select',
            'label' => 'Estado de Membresía',
            'options' => array(
                'activo' => 'Activo',
                'inactivo' => 'Inactivo',
                'suspendido' => 'Suspendido'
            )
        ),
        'observaciones' => array(
            'type' => 'textarea',
            'label' => 'Observaciones'
        )
    );
}
?>