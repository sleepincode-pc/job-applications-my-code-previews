<div class="wrap">
    <h1><?php echo $documento ? 'Editar Documento' : 'Subir Nuevo Documento'; ?></h1>
    
    <div class="ac-form-section">
        <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('guardar_documento', 'documento_nonce'); ?>
            
            <div class="ac-form-group">
                <label for="titulo">Título del Documento *</label>
                <input type="text" id="titulo" name="titulo" required 
                       value="<?php echo esc_attr($documento ? $documento->getTitulo() : ''); ?>"
                       placeholder="Ej: Acta de Asamblea General - Enero 2024">
            </div>
            
            <div class="ac-form-group">
                <label for="descripcion">Descripción</label>
                <textarea id="descripcion" name="descripcion" rows="4" 
                          placeholder="Descripción del contenido del documento"><?php 
                    echo esc_textarea($documento ? $documento->getDescripcion() : ''); 
                ?></textarea>
            </div>
            
            <div class="ac-form-grid">
                <div class="ac-form-group">
                    <label for="tipo">Tipo de Documento *</label>
                    <select id="tipo" name="tipo" required>
                        <option value="">Seleccionar tipo</option>
                        <option value="acta" <?php selected($documento ? $documento->getTipo() : '', 'acta'); ?>>Acta</option>
                        <option value="convocatoria" <?php selected($documento ? $documento->getTipo() : '', 'convocatoria'); ?>>Convocatoria</option>
                        <option value="estatuto" <?php selected($documento ? $documento->getTipo() : '', 'estatuto'); ?>>Estatuto</option>
                        <option value="reglamento" <?php selected($documento ? $documento->getTipo() : '', 'reglamento'); ?>>Reglamento</option>
                        <option value="informe" <?php selected($documento ? $documento->getTipo() : '', 'informe'); ?>>Informe</option>
                        <option value="otros" <?php selected($documento ? $documento->getTipo() : '', 'otros'); ?>>Otros</option>
                    </select>
                </div>
                
                <div class="ac-form-group">
                    <label for="fecha_documento">Fecha del Documento *</label>
                    <input type="date" id="fecha_documento" name="fecha_documento" required
                           value="<?php echo esc_attr($documento ? $documento->getFechaDocumento() : date('Y-m-d')); ?>">
                </div>
            </div>
            
            <div class="ac-form-grid">
                <div class="ac-form-group">
                    <label for="categoria">Categoría</label>
                    <input type="text" id="categoria" name="categoria" 
                           value="<?php echo esc_attr($documento ? $documento->getCategoria() : ''); ?>"
                           placeholder="Ej: Asambleas, Financiero, Legal">
                    <p class="description">Agrupar documentos por categoría</p>
                </div>
                
                <div class="ac-form-group">
                    <label for="visible_para">Visible para *</label>
                    <select id="visible_para" name="visible_para" required>
                        <option value="junta" <?php selected($documento ? $documento->getVisiblePara() : '', 'junta'); ?>>Solo Junta Directiva</option>
                        <option value="miembros" <?php selected($documento ? $documento->getVisiblePara() : '', 'miembros'); ?>>Todos los Miembros</option>
                        <option value="publico" <?php selected($documento ? $documento->getVisiblePara() : '', 'publico'); ?>>Público General</option>
                    </select>
                </div>
            </div>
            
            <div class="ac-form-group">
                <label for="archivo">
                    <?php echo $documento ? 'Actualizar Archivo' : 'Seleccionar Archivo *'; ?>
                </label>
                <input type="file" id="archivo" name="archivo" 
                       <?php echo !$documento ? 'required' : ''; ?>
                       accept=".pdf,.doc,.docx,.xls,.xlsx,.txt">
                <p class="description">
                    Formatos permitidos: PDF, DOC, DOCX, XLS, XLSX, TXT. Tamaño máximo: 10MB
                </p>
                
                <?php if ($documento && $documento->getArchivo()): ?>
                    <div class="ac-archivo-actual">
                        <strong>Archivo actual:</strong> 
                        <a href="<?php echo esc_url($documento->getArchivoUrl()); ?>" target="_blank">
                            <?php echo esc_html($documento->getArchivo()); ?>
                        </a>
                        (<?php echo $documento->getTamanoArchivo(); ?>)
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="ac-form-submit">
                <button type="submit" class="button button-primary button-large">
                    <?php echo $documento ? 'Actualizar Documento' : 'Subir Documento'; ?>
                </button>
                <a href="<?php echo admin_url('admin.php?page=ac-documentos'); ?>" class="button button-large">Cancelar</a>
            </div>
        </form>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Validación de tipo de archivo
    $('#archivo').on('change', function() {
        var archivo = this.files[0];
        if (archivo) {
            var extension = archivo.name.split('.').pop().toLowerCase();
            var extensionesPermitidas = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'txt'];
            
            if (!extensionesPermitidas.includes(extension)) {
                alert('Tipo de archivo no permitido. Use: ' + extensionesPermitidas.join(', '));
                $(this).val('');
                return;
            }
            
            if (archivo.size > 10 * 1024 * 1024) {
                alert('El archivo excede el tamaño máximo de 10MB');
                $(this).val('');
                return;
            }
        }
    });
    
    // Sugerir categoría basada en el tipo
    $('#tipo').on('change', function() {
        var tipo = $(this).val();
        var categoria = $('#categoria');
        
        var sugerencias = {
            'acta': 'Asambleas',
            'convocatoria': 'Asambleas',
            'estatuto': 'Legal',
            'reglamento': 'Legal',
            'informe': 'Informes'
        };
        
        if (sugerencias[tipo] && !categoria.val()) {
            categoria.val(sugerencias[tipo]);
        }
    });
});
</script>