<?php
/**
 * Template principal del Sistema Integral
 * Solo contiene HTML, CSS y JavaScript para la interfaz
 */

// Prevenir acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Obtener instancia de la clase
$ac_sistema = AC_Sistema_Integral::get_instance();
$ac_sistema->verificar_permisos();

// Obtener parámetros
$modo_actual = isset($_GET['modo']) ? sanitize_text_field($_GET['modo']) : 'planificador';
$submodo_actual = isset($_GET['submodo']) ? sanitize_text_field($_GET['submodo']) : '';
$rango_actual = isset($_GET['rango']) ? sanitize_text_field($_GET['rango']) : 'semana';

// Obtener datos según el modo
$datos_horario = $ac_sistema->obtener_estado_horario();
$actividad_actual = $ac_sistema->obtener_actividad_actual($datos_horario);
$proximas_actividades = $ac_sistema->obtener_proximas_actividades($datos_horario, 3);
$progreso_dia = $ac_sistema->calcular_progreso_dia($datos_horario);
$estadisticas = $ac_sistema->obtener_estadisticas_cumplimiento($rango_actual);
$actividades_faltantes = $ac_sistema->obtener_actividades_faltantes();
$dias_semana = $ac_sistema->obtener_dias_semana();

// Si está en modo actividades, mostrar lista de actividades
if ($submodo_actual === 'actividades') {
    $this->mostrar_lista_actividades();
    return;
}

// Si está en modo actas, mostrar sistema de actas
if ($modo_actual === 'actas') {
    $this->mostrar_sistema_actas();
    return;
}

// Si está en modo medicación, mostrar sistema de medicación
if ($modo_actual === 'medicacion') {
    $this->mostrar_sistema_medicacion();
    return;
}
?>

<div class="wrap">
    <h1 class="wp-heading-inline">🗓️ Planificador Diario - Sistema Integral</h1>
    
    <!-- Navegación unificada -->
    <div class="ac-navigation" style="margin: 20px 0; background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
        <h2 style="margin-top: 0;">Sistema Integral de Gestión</h2>
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador'); ?>" 
               class="button <?php echo $modo_actual === 'planificador' && $submodo_actual !== 'actividades' ? 'button-primary' : ''; ?>" 
               style="text-decoration: none;">
                📅 Planificador Diario
            </a>
            <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador&submodo=actividades'); ?>" 
               class="button <?php echo $submodo_actual === 'actividades' ? 'button-primary' : ''; ?>" 
               style="text-decoration: none;">
                📊 Actividades Guardadas
            </a>
            <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=actas'); ?>" 
               class="button <?php echo $modo_actual === 'actas' ? 'button-primary' : ''; ?>" 
               style="text-decoration: none;">
                📋 Libro de Actas
            </a>
            <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=medicacion'); ?>" 
               class="button <?php echo $modo_actual === 'medicacion' ? 'button-primary' : ''; ?>" 
               style="text-decoration: none;">
                💊 Medicación
            </a>
        </div>
    </div>

    <!-- Acciones Principales -->
    <div class="ac-header-actions" style="display: flex; justify-content: space-between; align-items: center; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px;">
        <div>
            <button type="button" id="registrar-actividad-actual" class="button button-primary" style="font-size: 14px; padding: 8px 16px;">
                <span class="dashicons dashicons-plus" style="margin-top: 4px;"></span>
                Registrar Actividad Actual
            </button>
            <button type="button" id="exportar-registros" class="button" style="font-size: 14px; padding: 8px 16px; margin-left: 10px;">
                <span class="dashicons dashicons-media-spreadsheet" style="margin-top: 4px;"></span>
                Exportar Registros
            </button>
            <a href="<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador&submodo=actividades'); ?>" class="button" style="font-size: 14px; padding: 8px 16px; margin-left: 10px;">
                <span class="dashicons dashicons-list-view" style="margin-top: 4px;"></span>
                Ver Todas las Actividades
            </a>
            
            <!-- Botón para registro automático de actividades faltantes -->
            <?php if (!empty($actividades_faltantes)): ?>
            <button type="button" id="registrar-automatico" class="button" style="font-size: 14px; padding: 8px 16px; margin-left: 10px; background: #ffb900; border-color: #ffb900;">
                <span class="dashicons dashicons-update" style="margin-top: 4px;"></span>
                Registrar Actividades Faltantes (<?php echo count($actividades_faltantes); ?>)
            </button>
            <?php endif; ?>
        </div>
        
        <div class="ac-search-export" style="display: flex; gap: 10px; align-items: center;">
            <span class="description" style="color: #666; font-size: 13px;">
                <?php echo date('d/m/Y'); ?> • 
                <?php echo $dias_semana[$datos_horario['dia_actual']]; ?>
            </span>
        </div>
    </div>
    
    <!-- Panel de Recordatorios de Actividades Faltantes -->
    <?php if (!empty($actividades_faltantes)): ?>
    <div class="ac-recordatorios-panel" style="margin: 20px 0;">
        <div style="background: #fff3cd; border: 1px solid #ffeaa7; border-left: 4px solid #fdcb6e; padding: 15px 20px; border-radius: 8px;">
            <h3 style="margin: 0 0 10px 0; color: #856404; display: flex; align-items: center; gap: 10px;">
                <span class="dashicons dashicons-warning" style="color: #f39c12;"></span>
                Actividades Pendientes de Registro
            </h3>
            <p style="margin: 0 0 15px 0; color: #856404;">
                El sistema detectó <strong><?php echo count($actividades_faltantes); ?> actividades</strong> que ya pasaron pero no están registradas.
            </p>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 10px; margin-bottom: 15px;">
                <?php foreach ($actividades_faltantes as $index => $actividad): ?>
                <div style="background: rgba(255,255,255,0.7); padding: 10px; border-radius: 4px; display: flex; align-items: center; gap: 10px;">
                    <div style="font-size: 20px;"><?php echo $actividad['icono']; ?></div>
                    <div style="flex: 1;">
                        <div style="font-weight: bold; font-size: 13px;"><?php echo $actividad['actividad']; ?></div>
                        <div style="font-size: 11px; color: #666;">Hora: <?php echo $actividad['hora']; ?> • Duración: <?php echo $actividad['duracion']; ?>min</div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div style="display: flex; gap: 10px;">
                <button type="button" id="registrar-todas-faltantes" class="button" style="background: #f39c12; border-color: #f39c12; color: white;">
                    <span class="dashicons dashicons-yes" style="margin-top: 4px;"></span>
                    Registrar Todas como Completadas
                </button>
                <button type="button" id="ignorar-recordatorios" class="button">
                    <span class="dashicons dashicons-no" style="margin-top: 4px;"></span>
                    Omitir por Hoy
                </button>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Panel de Métricas y Estadísticas -->
    <div class="ac-metrics-panel" style="margin: 20px 0;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
            <h2 style="margin: 0; color: #23282d;">📊 Métricas de Cumplimiento</h2>
            <div>
                <select id="filtro-rango" style="padding: 5px 10px; border-radius: 4px;">
                    <option value="hoy" <?php echo $rango_actual === 'hoy' ? 'selected' : ''; ?>>Hoy</option>
                    <option value="semana" <?php echo $rango_actual === 'semana' ? 'selected' : ''; ?>>Última semana</option>
                    <option value="mes" <?php echo $rango_actual === 'mes' ? 'selected' : ''; ?>>Último mes</option>
                </select>
            </div>
        </div>
        
        <div class="ac-stats-container" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; margin-bottom: 20px;">
            <!-- Métrica Principal -->
            <div class="ac-stat-card" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h3 style="margin: 0 0 5px 0; font-size: 14px; opacity: 0.9;">CUMPLIMIENTO <?php echo strtoupper($rango_actual); ?></h3>
                        <p style="font-size: 32px; font-weight: bold; margin: 0;">📊 <?php echo esc_html($estadisticas['porcentaje_completadas']); ?>%</p>
                    </div>
                    <div style="font-size: 24px;">🎯</div>
                </div>
                <div style="margin-top: 10px; font-size: 12px; opacity: 0.8;">
                    <?php echo esc_html($estadisticas['completadas']); ?> de <?php echo esc_html($estadisticas['total_actividades']); ?> actividades
                </div>
            </div>

            <!-- Distribución por Estado -->
            <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #46b450; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #46b450; font-size: 14px;">DISTRIBUCIÓN POR ESTADO</h3>
                <div style="max-height: 120px; overflow-y: auto;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                        <span>✅ Completadas</span>
                        <span style="font-weight: bold;"><?php echo esc_html($estadisticas['completadas']); ?> (<?php echo esc_html($estadisticas['porcentaje_completadas']); ?>%)</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                        <span>🔄 En progreso</span>
                        <span style="font-weight: bold;"><?php echo esc_html($estadisticas['en_progreso']); ?> (<?php echo esc_html($estadisticas['porcentaje_en_progreso']); ?>%)</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                        <span>⏳ Pendientes</span>
                        <span style="font-weight: bold;"><?php echo esc_html($estadisticas['pendientes']); ?> (<?php echo esc_html($estadisticas['porcentaje_pendientes']); ?>%)</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                        <span>❌ Canceladas</span>
                        <span style="font-weight: bold;"><?php echo esc_html($estadisticas['canceladas']); ?> (<?php echo esc_html($estadisticas['porcentaje_canceladas']); ?>%)</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
                        <span>⚠️ No Cumplidas</span>
                        <span style="font-weight: bold;"><?php echo esc_html($estadisticas['no_cumplidas']); ?> (<?php echo esc_html($estadisticas['porcentaje_no_cumplidas']); ?>%)</span>
                    </div>
                </div>
            </div>

            <!-- Estadísticas de Calidad -->
            <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #ffb900; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #ffb900; font-size: 14px;">CALIDAD Y TIEMPO</h3>
                <div style="display: grid; gap: 8px;">
                    <div style="display: flex; justify-content: space-between;">
                        <span>Valoración promedio:</span>
                        <strong>
                            <?php 
                            $valoracion = $estadisticas['valoracion_promedio'];
                            if ($valoracion > 0) {
                                $estrellas_llenas = floor($valoracion);
                                $media_estrella = $valoracion - $estrellas_llenas >= 0.5;
                                
                                echo str_repeat('⭐', $estrellas_llenas);
                                if ($media_estrella) echo '½';
                                echo ' (' . number_format($valoracion, 1) . '/5)';
                            } else {
                                echo 'Sin datos';
                            }
                            ?>
                        </strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Duración promedio:</span>
                        <strong>
                            <?php 
                            echo $estadisticas['duracion_promedio'] > 0 
                                ? number_format($estadisticas['duracion_promedio'], 0) . ' min' 
                                : 'Sin datos'; 
                            ?>
                        </strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Actividades totales:</span>
                        <strong><?php echo esc_html($estadisticas['total_actividades']); ?></strong>
                    </div>
                </div>
            </div>

            <!-- Rango Temporal -->
            <div class="ac-stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #dc3232; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #dc3232; font-size: 14px;">PERIODO ANALIZADO</h3>
                <div style="display: grid; gap: 8px; font-size: 12px;">
                    <div style="display: flex; justify-content: space-between;">
                        <span>Desde:</span>
                        <strong><?php echo date('d/m/Y', strtotime($estadisticas['fecha_inicio'])); ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Hasta:</span>
                        <strong><?php echo date('d/m/Y', strtotime($estadisticas['fecha_fin'])); ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Rango:</span>
                        <strong><?php echo ucfirst($estadisticas['rango']); ?></strong>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Panel Principal de Estado -->
    <div class="ac-planificador-panel" style="margin: 20px 0;">
        <!-- Header con Información General -->
        <div class="ac-planificador-header" style="background: linear-gradient(135deg, #0073aa, #005a87); color: white; padding: 25px; border-radius: 12px; margin-bottom: 20px;">
            <div style="display: grid; grid-template-columns: auto 1fr auto; gap: 20px; align-items: center;">
                <div style="font-size: 48px;">🗓️</div>
                <div>
                    <h2 style="margin: 0 0 5px 0; font-size: 24px;">Plan del Día - <?php echo $dias_semana[$datos_horario['dia_actual']]; ?></h2>
                    <p style="margin: 0; opacity: 0.9; font-size: 16px;"><?php echo date('d/m/Y'); ?></p>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 32px; font-weight: bold;" class="ac-hora-actual">🕐 <?php echo $datos_horario['hora_actual']; ?></div>
                    <div style="font-size: 14px; opacity: 0.8;">Hora actual (Buenos Aires)</div>
                </div>
            </div>
            
            <!-- Barra de Progreso del Día -->
            <div style="margin-top: 20px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 14px;">
                    <span>Progreso del día</span>
                    <span><?php echo $progreso_dia; ?>%</span>
                </div>
                <div style="background: rgba(255,255,255,0.2); height: 8px; border-radius: 4px; overflow: hidden;">
                    <div style="background: white; height: 100%; width: <?php echo $progreso_dia; ?>%; border-radius: 4px; transition: width 0.5s ease;"></div>
                </div>
            </div>
        </div>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
            <!-- Columna Izquierda: Actividad Actual -->
            <div class="ac-actividad-actual" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
                <h3 style="margin-top: 0; color: #667eea; border-bottom: 2px solid #667eea; padding-bottom: 10px;">
                    <span class="dashicons dashicons-clock" style="margin-right: 8px;"></span>
                    Estado Actual
                </h3>
                
                <?php if ($actividad_actual): ?>
                    <div style="text-align: center; padding: 20px 0;">
                        <div style="font-size: 64px; margin-bottom: 15px;"><?php echo $actividad_actual['detalles']['icono']; ?></div>
                        <h4 style="margin: 0 0 10px 0; font-size: 20px; color: #333;"><?php echo $actividad_actual['detalles']['actividad']; ?></h4>
                        <div style="display: inline-block; background: #667eea; color: white; padding: 8px 16px; border-radius: 20px; font-size: 14px; font-weight: bold;">
                            🕐 <?php echo $actividad_actual['hora']; ?>
                        </div>
                    </div>
                    
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-top: 15px;">
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 13px;">
                            <div>
                                <strong>Tipo:</strong><br>
                                <span style="color: #666;"><?php echo ucfirst(str_replace('_', ' ', $actividad_actual['detalles']['tipo'])); ?></span>
                            </div>
                            <div>
                                <strong>Duración:</strong><br>
                                <span style="color: #666;"><?php echo $actividad_actual['detalles']['duracion']; ?> minutos</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Formulario de Registro -->
                    <div style="margin-top: 20px; padding: 20px; background: #f8f9fa; border-radius: 8px;">
                        <h4 style="margin-top: 0; color: #495057;">📝 Registrar esta actividad</h4>
                        <form method="post" id="form-registro-actual">
                            <input type="hidden" name="guardar_registro_diario" value="1">
                            <input type="hidden" name="fecha" value="<?php echo date('Y-m-d'); ?>">
                            <input type="hidden" name="actividad_id" value="<?php echo $actividad_actual['hora'] . '_' . sanitize_title($actividad_actual['detalles']['actividad']); ?>">
                            <input type="hidden" name="actividad_nombre" value="<?php echo esc_attr($actividad_actual['detalles']['actividad']); ?>">
                            <input type="hidden" name="tipo_actividad" value="<?php echo esc_attr($actividad_actual['detalles']['tipo']); ?>">
                            
                            <table class="form-table">
                                <tr>
                                    <th scope="row"><label for="estado">Estado</label></th>
                                    <td>
                                        <select name="estado" id="estado" class="regular-text" required>
                                            <option value="completada">✅ Completada</option>
                                            <option value="en_progreso" selected>🔄 En progreso</option>
                                            <option value="pendiente">⏳ Pendiente</option>
                                            <option value="cancelada">❌ Cancelada</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="duracion_real">Duración real (min)</label></th>
                                    <td>
                                        <input type="number" name="duracion_real" id="duracion_real" class="small-text" value="<?php echo $actividad_actual['detalles']['duracion']; ?>" min="1" max="480">
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="valoracion">Valoración</label></th>
                                    <td>
                                        <select name="valoracion" id="valoracion" class="regular-text" required>
                                            <option value="5">⭐⭐⭐⭐⭐ Excelente</option>
                                            <option value="4">⭐⭐⭐⭐ Muy buena</option>
                                            <option value="3" selected>⭐⭐⭐ Buena</option>
                                            <option value="2">⭐⭐ Regular</option>
                                            <option value="1">⭐ Mala</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="observaciones">Observaciones</label></th>
                                    <td>
                                        <textarea name="observaciones" id="observaciones" rows="3" class="large-text" placeholder="Notas, comentarios, dificultades..."></textarea>
                                    </td>
                                </tr>
                            </table>
                            
                            <p class="submit">
                                <button type="submit" class="button button-primary">
                                    <span class="dashicons dashicons-yes" style="margin-top: 4px;"></span>
                                    Guardar Registro
                                </button>
                            </p>
                        </form>
                    </div>
                <?php else: ?>
                    <div style="text-align: center; padding: 40px 20px; color: #666;">
                        <div style="font-size: 64px; margin-bottom: 15px;">🌙</div>
                        <h4 style="margin: 0 0 10px 0; color: #333;">Fuera del horario activo</h4>
                        <p>El horario activo es de 8:00 a 23:00 horas.</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Columna Derecha: Próximas Actividades -->
            <div class="ac-proximas-actividades" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
                <h3 style="margin-top: 0; color: #764ba2; border-bottom: 2px solid #764ba2; padding-bottom: 10px;">
                    <span class="dashicons dashicons-arrow-right" style="margin-right: 8px;"></span>
                    Próximas Actividades
                </h3>
                
                <?php if (!empty($proximas_actividades)): ?>
                    <div style="display: flex; flex-direction: column; gap: 15px;">
                        <?php foreach ($proximas_actividades as $index => $proxima): ?>
                            <div class="ac-proxima-actividad" 
                                 data-timestamp="<?php echo $proxima['timestamp']; ?>"
                                 style="display: grid; grid-template-columns: auto 1fr auto; gap: 15px; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #764ba2; transition: all 0.3s ease;">
                                <div style="font-size: 24px;"><?php echo $proxima['detalles']['icono']; ?></div>
                                <div>
                                    <div style="font-weight: bold; margin-bottom: 4px;"><?php echo $proxima['detalles']['actividad']; ?></div>
                                    <div style="font-size: 12px; color: #666;">
                                        <?php echo ucfirst(str_replace('_', ' ', $proxima['detalles']['tipo'])); ?> • 
                                        <?php echo $proxima['detalles']['duracion']; ?> min
                                    </div>
                                </div>
                                <div style="text-align: right;">
                                    <div style="font-weight: bold; color: #764ba2;"><?php echo $proxima['hora']; ?></div>
                                    <div class="ac-contador" style="font-size: 11px; color: #666; font-weight: bold;">
                                        en <?php echo $proxima['minutos_restantes']; ?> min
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Contador General -->
                    <div style="margin-top: 20px; padding: 15px; background: linear-gradient(135deg, #764ba2, #667eea); color: white; border-radius: 8px; text-align: center;">
                        <div style="font-size: 14px; margin-bottom: 5px;">Próxima actividad en:</div>
                        <div id="contador-general" style="font-size: 24px; font-weight: bold;">
                            <?php echo $proximas_actividades[0]['minutos_restantes']; ?> minutos
                        </div>
                    </div>
                <?php else: ?>
                    <div style="text-align: center; padding: 40px 20px; color: #666;">
                        <div style="font-size: 48px; margin-bottom: 15px;">🌜</div>
                        <p>No hay más actividades programadas para hoy.</p>
                    </div>
                <?php endif; ?>
                
                <!-- Botón de registro rápido -->
                <div style="margin-top: 20px; padding: 15px; background: #e8f5e8; border-radius: 8px; border-left: 4px solid #46b450;">
                    <h4 style="margin-top: 0; color: #2e7d32;">⚡ Registro Rápido</h4>
                    <p style="margin: 10px 0; font-size: 13px;">¿Quieres registrar una actividad no programada?</p>
                    <button type="button" id="registro-rapido" class="button" style="background: #46b450; color: white; border-color: #46b450;">
                        <span class="dashicons dashicons-plus" style="margin-top: 4px;"></span>
                        Nueva Actividad
                    </button>
                </div>

                <!-- Botón de No Cumplimiento -->
                <div style="margin-top: 15px; padding: 15px; background: #ffeaea; border-radius: 8px; border-left: 4px solid #dc3232;">
                    <h4 style="margin-top: 0; color: #dc3232;">⚠️ No Cumplimiento</h4>
                    <p style="margin: 10px 0; font-size: 13px;">¿No se pudo realizar alguna actividad programada?</p>
                    <button type="button" id="btn-no-cumplio" class="button" style="background: #dc3232; color: white; border-color: #dc3232;">
                        <span class="dashicons dashicons-warning" style="margin-top: 4px;"></span>
                        Registrar No Cumplimiento
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Horario Completo del Día -->
        <div class="ac-horario-completo" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
            <h3 style="margin-top: 0; color: #495057; border-bottom: 2px solid #495057; padding-bottom: 10px;">
                <span class="dashicons dashicons-list-view" style="margin-right: 8px;"></span>
                Horario Completo del Día
            </h3>
            
            <div class="ac-linea-tiempo" style="position: relative;">
                <?php
                $actividades = $datos_horario['actividades'];
                $hora_actual = $datos_horario['hora_actual'];
                
                // Colores por tipo de actividad
                $colores_tipo = [
                    'rutina' => '#667eea',
                    'alimentacion' => '#f093fb',
                    'desarrollo_personal' => '#4facfe',
                    'planificacion' => '#43e97b',
                    'organizacion' => '#fa709a',
                    'terapia_grupal' => '#a8edea',
                    'descanso' => '#ffecd2',
                    'terapia_escrita' => '#84fab0',
                    'salud' => '#ff9a9e'
                ];
                
                foreach ($actividades as $hora => $detalles):
                    $hora_inicio_ts = strtotime($hora);
                    $hora_fin_ts = strtotime($hora . ' + ' . $detalles['duracion'] . ' minutes');
                    $hora_actual_ts = strtotime($hora_actual);
                    
                    $es_actual = ($hora_actual_ts >= $hora_inicio_ts && $hora_actual_ts < $hora_fin_ts);
                    $es_pasado = ($hora_fin_ts <= $hora_actual_ts);
                    $es_futuro = ($hora_inicio_ts > $hora_actual_ts);
                ?>
                <div class="ac-item-tiempo" style="display: grid; grid-template-columns: 80px 1fr; gap: 20px; padding: 15px 0; position: relative; align-items: start;">
                    <!-- Línea vertical y hora -->
                    <div style="position: relative;">
                        <div style="font-weight: bold; color: <?php echo $es_pasado ? '#999' : ($es_actual ? '#667eea' : '#333'); ?>;">
                            <?php echo $hora; ?>
                        </div>
                        <?php if (!$es_pasado): ?>
                            <div style="position: absolute; left: 35px; top: 0; bottom: 0; width: 2px; background: #667eea; opacity: 0.3;"></div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Tarjeta de actividad -->
                    <div class="ac-tarjeta-actividad" 
                         style="background: <?php echo $es_pasado ? '#f8f9fa' : ($es_actual ? $colores_tipo[$detalles['tipo']] . '20' : '#ffffff'); ?>; 
                                border: 2px solid <?php echo $es_actual ? $colores_tipo[$detalles['tipo']] : 'transparent'; ?>;
                                padding: 15px; 
                                border-radius: 8px; 
                                box-shadow: 0 2px 6px rgba(0,0,0,0.1);
                                position: relative;">
                        
                        <?php if ($es_actual): ?>
                            <div style="position: absolute; top: -8px; right: -8px; background: #667eea; color: white; padding: 4px 8px; border-radius: 12px; font-size: 10px; font-weight: bold;">
                                AHORA
                            </div>
                        <?php endif; ?>
                        
                        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 8px;">
                            <div style="font-size: 24px;"><?php echo $detalles['icono']; ?></div>
                            <div style="flex: 1;">
                                <div style="font-weight: bold; color: <?php echo $es_pasado ? '#999' : '#333'; ?>;">
                                    <?php echo $detalles['actividad']; ?>
                                </div>
                                <div style="display: flex; gap: 15px; font-size: 12px; color: #666; margin-top: 4px;">
                                    <span>⏱️ <?php echo $detalles['duracion']; ?> min</span>
                                    <span>🏷️ <?php echo ucfirst(str_replace('_', ' ', $detalles['tipo'])); ?></span>
                                </div>
                            </div>
                            <div>
                                <button type="button" class="button ac-registrar-btn" data-actividad='<?php echo json_encode($detalles); ?>' data-hora="<?php echo $hora; ?>" style="font-size: 11px; padding: 4px 8px;">
                                    <span class="dashicons dashicons-edit" style="font-size: 12px; margin-top: 2px;"></span>
                                    Registrar
                                </button>
                            </div>
                        </div>
                        
                        <?php if ($es_actual): ?>
                            <div style="background: rgba(255,255,255,0.7); padding: 8px; border-radius: 4px; font-size: 12px; text-align: center;">
                                <strong>En progreso</strong> • Termina a las <?php echo date('H:i', $hora_fin_ts); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Acciones Finales -->
            <div style="margin-top: 30px; padding: 20px; background: linear-gradient(135deg, #f093fb, #f5576c); color: white; border-radius: 8px; text-align: center;">
                <h3 style="margin-top: 0; color: white;">📊 Resumen del Día</h3>
                <p>Genera un reporte completo de todas las actividades realizadas hoy.</p>
                <button type="button" id="generar-resumen" class="button button-primary" style="background: white; color: #f5576c; border-color: white; font-weight: bold;">
                    <span class="dashicons dashicons-pdf" style="margin-top: 4px;"></span>
                    Generar Resumen Diario PDF
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Modal para Registro Rápido -->
<div id="modal-registro-rapido" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; align-items: center; justify-content: center;">
    <div style="background: white; padding: 30px; border-radius: 12px; width: 90%; max-width: 500px; max-height: 90vh; overflow-y: auto;">
        <h3 style="margin-top: 0; color: #0073aa;">➕ Registrar Actividad Personalizada</h3>
        
        <form method="post" id="form-registro-rapido">
            <input type="hidden" name="guardar_registro_diario" value="1">
            <input type="hidden" name="fecha" value="<?php echo date('Y-m-d'); ?>">
            <input type="hidden" name="tipo_actividad" value="personalizada">
            
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="actividad_personalizada">Actividad *</label></th>
                    <td>
                        <input type="text" name="actividad_nombre" id="actividad_personalizada" class="regular-text" placeholder="Describe la actividad..." required>
                        <input type="hidden" name="actividad_id" value="personalizada_<?php echo time(); ?>">
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="estado_personalizado">Estado</label></th>
                    <td>
                        <select name="estado" id="estado_personalizado" class="regular-text" required>
                            <option value="completada">✅ Completada</option>
                            <option value="en_progreso">🔄 En progreso</option>
                            <option value="pendiente">⏳ Pendiente</option>
                            <option value="cancelada">❌ Cancelada</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="duracion_personalizada">Duración real (min)</label></th>
                    <td>
                        <input type="number" name="duracion_real" id="duracion_personalizada" class="small-text" value="30" min="1" max="480">
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="valoracion_personalizada">Valoración</label></th>
                    <td>
                        <select name="valoracion" id="valoracion_personalizada" class="regular-text" required>
                            <option value="5">⭐⭐⭐⭐⭐ Excelente</option>
                            <option value="4">⭐⭐⭐⭐ Muy buena</option>
                            <option value="3" selected>⭐⭐⭐ Buena</option>
                            <option value="2">⭐⭐ Regular</option>
                            <option value="1">⭐ Mala</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="observaciones_personalizadas">Observaciones</label></th>
                    <td>
                        <textarea name="observaciones" id="observaciones_personalizadas" rows="3" class="large-text" placeholder="Notas, comentarios, dificultades..."></textarea>
                    </td>
                </tr>
            </table>
            
            <p class="submit">
                <button type="submit" class="button button-primary">
                    <span class="dashicons dashicons-yes" style="margin-top: 4px;"></span>
                    Guardar Registro
                </button>
                <button type="button" id="cancelar-registro" class="button" style="margin-left: 10px;">
                    <span class="dashicons dashicons-no" style="margin-top: 4px;"></span>
                    Cancelar
                </button>
            </p>
        </form>
    </div>
</div>

<!-- Modal para No Cumplimiento -->
<div id="modal-no-cumplio" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; align-items: center; justify-content: center;">
    <div style="background: white; padding: 30px; border-radius: 12px; width: 90%; max-width: 500px; max-height: 90vh; overflow-y: auto;">
        <h3 style="margin-top: 0; color: #dc3232;">⚠️ Registrar No Cumplimiento</h3>
        
        <form method="post" id="form-no-cumplio">
            <input type="hidden" name="guardar_registro_diario" value="1">
            <input type="hidden" name="fecha" value="<?php echo date('Y-m-d'); ?>">
            <input type="hidden" name="estado" value="no_cumplida">
            <input type="hidden" name="tipo_actividad" value="no_cumplida">
            
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="actividad_no_cumplida">Actividad No Cumplida *</label></th>
                    <td>
                        <input type="text" name="actividad_nombre" id="actividad_no_cumplida" class="regular-text" required placeholder="¿Qué actividad no se cumplió?">
                        <input type="hidden" name="actividad_id" value="no_cumplida_<?php echo time(); ?>">
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="razon_no_cumplio">Razón del No Cumplimiento</label></th>
                    <td>
                        <select name="razon_no_cumplio" id="razon_no_cumplio" class="regular-text">
                            <option value="">-- Seleccionar --</option>
                            <option value="imprevisto">Imprevisto</option>
                            <option value="salud">Problema de salud</option>
                            <option value="clima">Condiciones climáticas</option>
                            <option value="personal">Razón personal</option>
                            <option value="otro">Otro</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="observaciones_no_cumplio">Observaciones</label></th>
                    <td>
                        <textarea name="observaciones" id="observaciones_no_cumplio" rows="4" class="large-text" placeholder="Explicar por qué no se cumplió la actividad..." required></textarea>
                    </td>
                </tr>
            </table>
            
            <p class="submit">
                <button type="submit" class="button button-primary" style="background: #dc3232; border-color: #dc3232;">
                    <span class="dashicons dashicons-warning" style="margin-top: 4px;"></span>
                    Registrar No Cumplimiento
                </button>
                <button type="button" id="cancelar-no-cumplio" class="button" style="margin-left: 10px;">
                    Cancelar
                </button>
            </p>
        </form>
    </div>
</div>

<!-- Modal para Registro Masivo -->
<div id="modal-registro-masivo" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; align-items: center; justify-content: center;">
    <div style="background: white; padding: 30px; border-radius: 12px; width: 90%; max-width: 500px; max-height: 90vh; overflow-y: auto;">
        <h3 style="margin-top: 0; color: #0073aa;">📝 Registrar Actividades Faltantes</h3>
        
        <div id="lista-actividades-faltantes" style="max-height: 300px; overflow-y: auto; margin: 15px 0; padding: 10px; background: #f8f9fa; border-radius: 4px;">
            <!-- Las actividades se cargarán aquí via JavaScript -->
            <?php foreach ($actividades_faltantes as $actividad): ?>
            <div style="display: flex; align-items: center; gap: 10px; padding: 8px; border-bottom: 1px solid #ddd; background: white; margin-bottom: 5px; border-radius: 4px;">
                <div style="font-size: 20px;"><?php echo $actividad['icono']; ?></div>
                <div style="flex: 1;">
                    <strong><?php echo $actividad['actividad']; ?></strong>
                    <div style="font-size: 12px; color: #666;">Hora: <?php echo $actividad['hora']; ?> • Duración: <?php echo $actividad['duracion']; ?>min</div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <p style="color: #666; font-size: 14px;">
            Se crearán registros automáticos para todas las actividades listadas arriba con estado "Completada" y valoración neutral.
        </p>
        
        <p class="submit">
            <button type="button" id="confirmar-registro-masivo" class="button button-primary">
                <span class="dashicons dashicons-yes" style="margin-top: 4px;"></span>
                Confirmar Registro
            </button>
            <button type="button" id="cancelar-registro-masivo" class="button" style="margin-left: 10px;">
                <span class="dashicons dashicons-no" style="margin-top: 4px;"></span>
                Cancelar
            </button>
        </p>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Filtro de rango para métricas
    $('#filtro-rango').on('change', function() {
        var rango = $(this).val();
        window.location.href = '<?php echo admin_url('admin.php?page=ac-sistema-integral&modo=planificador'); ?>&rango=' + rango;
    });

    // Estado actual en tiempo real
    function actualizarEstadoTiempoReal() {
        const ahora = new Date();
        const horas = ahora.getHours().toString().padStart(2, '0');
        const minutos = ahora.getMinutes().toString().padStart(2, '0');
        const segundos = ahora.getSeconds().toString().padStart(2, '0');
        
        // Actualizar hora actual
        $('.ac-hora-actual').text('🕐 ' + horas + ':' + minutos + ':' + segundos);
        
        // Actualizar contadores de próximas actividades
        $('.ac-proxima-actividad').each(function() {
            const $elemento = $(this);
            const timestamp = $elemento.data('timestamp');
            const ahoraTimestamp = Math.floor(Date.now() / 1000);
            const diferencia = timestamp - ahoraTimestamp;
            const minutosRestantes = Math.floor(diferencia / 60);
            
            if (minutosRestantes > 0) {
                // Actualizar texto del contador
                $elemento.find('.ac-contador').text('en ' + minutosRestantes + ' min');
                
                // Aplicar efectos visuales según la proximidad
                $elemento.removeClass('actividad-proxima actividad-muy-proxima');
                $elemento.find('.ac-contador').removeClass('contador-urgente');
                
                if (minutosRestantes <= 5) {
                    $elemento.addClass('actividad-muy-proxima');
                    $elemento.find('.ac-contador').addClass('contador-urgente');
                } else if (minutosRestantes <= 15) {
                    $elemento.addClass('actividad-proxima');
                }
            } else {
                $elemento.find('.ac-contador').text('¡Ahora!');
                $elemento.addClass('actividad-muy-proxima');
                $elemento.find('.ac-contador').addClass('contador-urgente');
            }
        });
        
        // Actualizar contador general
        const $primerElemento = $('.ac-proxima-actividad').first();
        if ($primerElemento.length) {
            const timestamp = $primerElemento.data('timestamp');
            const ahoraTimestamp = Math.floor(Date.now() / 1000);
            const diferencia = timestamp - ahoraTimestamp;
            const minutosRestantes = Math.floor(diferencia / 60);
            
            if (minutosRestantes > 0) {
                $('#contador-general').text(minutosRestantes + ' minutos');
            } else {
                $('#contador-general').html('<span style="color: #ffeb3b;">¡AHORA!</span>');
            }
        }
    }
    
    // Actualizar cada segundo para tiempo real
    setInterval(actualizarEstadoTiempoReal, 1000);
    actualizarEstadoTiempoReal(); // Ejecutar inmediatamente
    
    // Modal para registro rápido
    $('#registro-rapido').on('click', function() {
        $('#modal-registro-rapido').fadeIn();
    });
    
    $('#cancelar-registro').on('click', function() {
        $('#modal-registro-rapido').fadeOut();
    });
    
    // Modal No Cumplimiento
    $('#btn-no-cumplio').on('click', function() {
        $('#modal-no-cumplio').fadeIn();
    });
    
    $('#cancelar-no-cumplio').on('click', function() {
        $('#modal-no-cumplio').fadeOut();
    });
    
    // Registro automático de actividades faltantes
    $('#registrar-automatico, #registrar-todas-faltantes').on('click', function() {
        $('#modal-registro-masivo').fadeIn();
    });
    
    $('#cancelar-registro-masivo, #ignorar-recordatorios').on('click', function() {
        $('#modal-registro-masivo').fadeOut();
    });
    
    $('#confirmar-registro-masivo').on('click', function() {
        var $boton = $(this);
        $boton.prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation: spin 1s linear infinite; margin-top: 4px;"></span> Registrando...');
        
        // Simular registro (en producción sería una llamada AJAX)
        setTimeout(function() {
            alert('✅ Se han registrado todas las actividades faltantes correctamente.');
            $boton.prop('disabled', false).html('<span class="dashicons dashicons-yes" style="margin-top: 4px;"></span> Confirmar Registro');
            $('#modal-registro-masivo').fadeOut();
        }, 1500);
    });
    
    // Botones de registro en actividades
    $('.ac-registrar-btn').on('click', function() {
        const actividad = $(this).data('actividad');
        const hora = $(this).data('hora');
        
        $('#actividad_personalizada').val(actividad.actividad);
        $('#modal-registro-rapido').fadeIn();
    });
    
    // Exportar registros
    $('#exportar-registros').on('click', function() {
        alert('📊 Función de exportación (en desarrollo)\n\nEsta función exportaría todos los registros a un archivo CSV.');
    });
    
    // Generar resumen
    $('#generar-resumen').on('click', function() {
        alert('📄 Función de generación de PDF (en desarrollo)\n\nEsta función generaría un resumen PDF de todas las actividades del día.');
    });
    
    // Cerrar modales al hacer click fuera
    $('#modal-registro-rapido, #modal-no-cumplio, #modal-registro-masivo').on('click', function(e) {
        if (e.target === this) {
            $(this).fadeOut();
        }
    });
    
    // Manejar envío de formularios (simulación)
    $('form').on('submit', function(e) {
        e.preventDefault();
        var formType = $(this).attr('id');
        var message = '';
        
        switch(formType) {
            case 'form-registro-actual':
                message = '✅ Actividad actual registrada correctamente';
                break;
            case 'form-registro-rapido':
                message = '✅ Actividad personalizada registrada correctamente';
                break;
            case 'form-no-cumplio':
                message = '⚠️ No cumplimiento registrado correctamente';
                break;
            default:
                message = '✅ Datos guardados correctamente';
        }
        
        alert(message);
        
        // Cerrar modal si está abierto
        if (formType === 'form-registro-rapido') {
            $('#modal-registro-rapido').fadeOut();
        } else if (formType === 'form-no-cumplio') {
            $('#modal-no-cumplio').fadeOut();
        }
    });
});

// Estilos CSS inline para animaciones
const style = document.createElement('style');
style.textContent = `
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

@keyframes pulse {
    0% { opacity: 1; }
    50% { opacity: 0.7; }
    100% { opacity: 1; }
}

.actividad-proxima {
    background: #fff3cd !important;
    border-left-color: #ffc107 !important;
}

.actividad-muy-proxima {
    background: #f8d7da !important;
    border-left-color: #dc3545 !important;
    animation: pulse 1s infinite;
}

.contador-urgente {
    color: #dc3545 !important;
    font-weight: bold;
}
`;
document.head.appendChild(style);
</script>