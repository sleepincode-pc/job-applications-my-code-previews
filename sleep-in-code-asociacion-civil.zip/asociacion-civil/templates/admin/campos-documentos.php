<?php
// Campos para Documentos
function ac_definir_campos_documento() {
    return array(
        'titulo_documento' => array(
            'type' => 'text',
            'label' => 'Título del Documento',
            'required' => true
        ),
        'numero_documento' => array(
            'type' => 'text',
            'label' => 'Número de Documento'
        ),
        'fecha_emision' => array(
            'type' => 'date',
            'label' => 'Fecha de Emisión'
        ),
        'tipo_documento' => array(
            'type' => 'select',
            'label' => 'Tipo de Documento',
            'options' => array(
                'oficio' => 'Oficio',
                'memorandum' => 'Memorándum',
                'informe' => 'Informe',
                'acta' => 'Acta',
                'resolucion' => 'Resolución',
                'contrato' => 'Contrato',
                'convenio' => 'Convenio'
            )
        ),
        'destinatario' => array(
            'type' => 'text',
            'label' => 'Destinatario'
        ),
        'remitente' => array(
            'type' => 'text',
            'label' => 'Remitente'
        ),
        'asunto' => array(
            'type' => 'text',
            'label' => 'Asunto'
        ),
        'contenido_documento' => array(
            'type' => 'textarea',
            'label' => 'Contenido del Documento'
        ),
        'observaciones' => array(
            'type' => 'textarea',
            'label' => 'Observaciones'
        )
    );
}
?>