<?php
if (!defined('ABSPATH')) {
    exit;
}

use AsociacionCivil\Database;

$action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
$id = isset($_GET['id']) ? intval($_GET['id']) : null;
$database = new Database();
?>

<div class="wrap">
    <h1>🤝 Reuniones</h1>
    
    <?php if ($action === 'listar'): ?>
        <div class="card">
            <h2>Gestión de Reuniones</h2>
            <p>Sistema para la programación, gestión y seguimiento de reuniones internas, sesiones de grupo y encuentros terapéuticos.</p>
            
            <div class="tablenav top">
                <div class="alignleft actions">
                    <a href="<?php echo admin_url('admin.php?page=ac-reuniones&action=nuevo'); ?>" class="button button-primary">
                        Nueva Reunión
                    </a>
                </div>
                <div class="alignright actions">
                    <form method="get">
                        <input type="hidden" name="page" value="ac-reuniones">
                        <select name="tipo">
                            <option value="">Todos los tipos</option>
                            <option value="terapeutica" <?php selected(isset($_GET['tipo']) && $_GET['tipo'] === 'terapeutica'); ?>>Terapéutica</option>
                            <option value="grupal" <?php selected(isset($_GET['tipo']) && $_GET['tipo'] === 'grupal'); ?>>Grupal</option>
                            <option value="operadores" <?php selected(isset($_GET['tipo']) && $_GET['tipo'] === 'operadores'); ?>>Operadores</option>
                            <option value="administrativa" <?php selected(isset($_GET['tipo']) && $_GET['tipo'] === 'administrativa'); ?>>Administrativa</option>
                        </select>
                        <input type="text" name="busqueda" placeholder="Buscar reuniones..." value="<?php echo isset($_GET['busqueda']) ? esc_attr($_GET['busqueda']) : ''; ?>">
                        <button type="submit" class="button">Buscar</button>
                    </form>
                </div>
            </div>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Título</th>
                        <th>Tipo</th>
                        <th>Fecha y Hora</th>
                        <th>Lugar</th>
                        <th>Convocante</th>
                        <th>Asistentes</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $busqueda = isset($_GET['busqueda']) ? sanitize_text_field($_GET['busqueda']) : '';
                    $tipo = isset($_GET['tipo']) ? sanitize_text_field($_GET['tipo']) : '';
                    
                    // Obtener reuniones basadas en búsqueda o todas
                    $args = array();
                    if (!empty($busqueda)) {
                        $args['s'] = $busqueda;
                    }
                    if (!empty($tipo)) {
                        $args['tipo'] = $tipo;
                    }
                    
                    $reuniones = $database->get_reuniones($args);
                    
                    if ($reuniones && count($reuniones) > 0):
                        foreach ($reuniones as $reunion):
                            $asistentes = $reunion->getAsistentes();
                            $total_asistentes = is_array($asistentes) ? count($asistentes) : 0;
                    ?>
                    <tr>
                        <td>
                            <strong><?php echo esc_html($reunion->getTitulo()); ?></strong>
                        </td>
                        <td>
                            <span class="tipo-reunion tipo-<?php echo esc_attr($reunion->getTipo()); ?>">
                                <?php echo esc_html(ucfirst($reunion->getTipo())); ?>
                            </span>
                        </td>
                        <td>
                            <?php echo date('d/m/Y', strtotime($reunion->getFecha())); ?><br>
                            <small><?php echo esc_html($reunion->getHoraInicio() . ' - ' . $reunion->getHoraFin()); ?></small>
                        </td>
                        <td><?php echo esc_html($reunion->getLugar()); ?></td>
                        <td><?php echo esc_html($reunion->getConvocante()); ?></td>
                        <td>
                            <span class="asistentes-count" title="<?php echo $total_asistentes; ?> asistentes">
                                <?php echo $total_asistentes; ?> personas
                            </span>
                        </td>
                        <td>
                            <span class="estado-badge estado-<?php echo esc_attr($reunion->getEstado()); ?>">
                                <?php echo esc_html(ucfirst($reunion->getEstado())); ?>
                            </span>
                        </td>
                        <td>
                            <div class="row-actions">
                                <a href="<?php echo admin_url('admin.php?page=ac-reuniones&action=ver&id=' . $reunion->getId()); ?>">
                                    Ver
                                </a> |
                                <a href="<?php echo admin_url('admin.php?page=ac-reuniones&action=editar&id=' . $reunion->getId()); ?>">
                                    Editar
                                </a> |
                                <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ac-reuniones&action=eliminar&id=' . $reunion->getId()), 'eliminar_reunion_' . $reunion->getId()); ?>" 
                                   onclick="return confirm('¿Está seguro de que desea eliminar esta reunión?');" 
                                   style="color: #a00;">
                                    Eliminar
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; else: ?>
                    <tr>
                        <td colspan="8" style="text-align: center;">
                            No se encontraron reuniones.
                            <a href="<?php echo admin_url('admin.php?page=ac-reuniones&action=nuevo'); ?>">
                                Programar la primera reunión
                            </a>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    <?php elseif ($action === 'nuevo' || $action === 'editar'): ?>
        <?php
        $reunion = null;
        if ($id && $action === 'editar') {
            $reunion = $database->get_reunion_by_id($id);
            if (!$reunion) {
                echo '<div class="notice notice-error"><p>Reunión no encontrada.</p></div>';
                return;
            }
        } else {
            // Crear nueva instancia de Reunion si no existe
            $reunion = new stdClass();
            $reunion->titulo = '';
            $reunion->tipo = '';
            $reunion->fecha = '';
            $reunion->hora_inicio = '';
            $reunion->hora_fin = '';
            $reunion->lugar = '';
            $reunion->convocante = '';
            $reunion->estado = 'planificada';
            $reunion->agenda = '';
            $reunion->acuerdos = '';
            $reunion->minutos = '';
            $reunion->asistentes = array();
            
            // Métodos para compatibilidad
            $reunion->getTitulo = function() use ($reunion) { return $reunion->titulo; };
            $reunion->getTipo = function() use ($reunion) { return $reunion->tipo; };
            $reunion->getFecha = function() use ($reunion) { return $reunion->fecha; };
            $reunion->getHoraInicio = function() use ($reunion) { return $reunion->hora_inicio; };
            $reunion->getHoraFin = function() use ($reunion) { return $reunion->hora_fin; };
            $reunion->getLugar = function() use ($reunion) { return $reunion->lugar; };
            $reunion->getConvocante = function() use ($reunion) { return $reunion->convocante; };
            $reunion->getEstado = function() use ($reunion) { return $reunion->estado; };
            $reunion->getAgenda = function() use ($reunion) { return $reunion->agenda; };
            $reunion->getAcuerdos = function() use ($reunion) { return $reunion->acuerdos; };
            $reunion->getMinutos = function() use ($reunion) { return $reunion->minutos; };
            $reunion->getAsistentes = function() use ($reunion) { return $reunion->asistentes; };
        }
        
        $miembros = $database->get_miembros('activo');
        $asistentes_seleccionados = is_callable(array($reunion, 'getAsistentes')) ? $reunion->getAsistentes() : array();
        if (!is_array($asistentes_seleccionados)) {
            $asistentes_seleccionados = array();
        }
        ?>

        <div class="card">
            <h2><?php echo $action === 'nuevo' ? 'Nueva Reunión' : 'Editar Reunión'; ?></h2>
            
            <form method="post" action="">
                <?php wp_nonce_field('guardar_reunion', 'reunion_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="titulo">Título *</label></th>
                        <td>
                            <input type="text" id="titulo" name="titulo" value="<?php echo esc_attr($reunion->getTitulo()); ?>" class="regular-text" required>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="tipo">Tipo de Reunión *</label></th>
                        <td>
                            <select id="tipo" name="tipo" required>
                                <option value="">Seleccionar tipo</option>
                                <option value="terapeutica" <?php selected($reunion->getTipo(), 'terapeutica'); ?>>Terapéutica</option>
                                <option value="grupal" <?php selected($reunion->getTipo(), 'grupal'); ?>>Grupal</option>
                                <option value="operadores" <?php selected($reunion->getTipo(), 'operadores'); ?>>Operadores</option>
                                <option value="administrativa" <?php selected($reunion->getTipo(), 'administrativa'); ?>>Administrativa</option>
                                <option value="emergencia" <?php selected($reunion->getTipo(), 'emergencia'); ?>>Emergencia</option>
                            </select>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="fecha">Fecha *</label></th>
                        <td>
                            <input type="date" id="fecha" name="fecha" value="<?php echo esc_attr($reunion->getFecha()); ?>" required>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="hora_inicio">Hora Inicio *</label></th>
                        <td>
                            <input type="time" id="hora_inicio" name="hora_inicio" value="<?php echo esc_attr($reunion->getHoraInicio()); ?>" required>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="hora_fin">Hora Fin *</label></th>
                        <td>
                            <input type="time" id="hora_fin" name="hora_fin" value="<?php echo esc_attr($reunion->getHoraFin()); ?>" required>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="lugar">Lugar</label></th>
                        <td>
                            <input type="text" id="lugar" name="lugar" value="<?php echo esc_attr($reunion->getLugar()); ?>" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="convocante">Convocante</label></th>
                        <td>
                            <input type="text" id="convocante" name="convocante" value="<?php echo esc_attr($reunion->getConvocante()); ?>" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="asistentes">Asistentes</label></th>
                        <td>
                            <div style="max-height: 200px; overflow-y: auto; border: 1px solid #ddd; padding: 10px;">
                                <?php foreach ($miembros as $miembro): ?>
                                <label style="display: block; margin-bottom: 5px;">
                                    <input type="checkbox" name="asistentes[]" value="<?php echo esc_attr($miembro->id); ?>" 
                                           <?php checked(in_array($miembro->id, $asistentes_seleccionados)); ?>>
                                    <?php echo esc_html($miembro->nombre . ' ' . $miembro->apellido . ' (' . $miembro->cargo . ')'); ?>
                                </label>
                                <?php endforeach; ?>
                            </div>
                            <p class="description">Seleccione los miembros que asistirán a la reunión</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="agenda">Agenda</label></th>
                        <td>
                            <textarea id="agenda" name="agenda" rows="6" class="large-text" placeholder="Temas a tratar en la reunión..."><?php echo esc_textarea($reunion->getAgenda()); ?></textarea>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="acuerdos">Acuerdos</label></th>
                        <td>
                            <textarea id="acuerdos" name="acuerdos" rows="4" class="large-text" placeholder="Acuerdos tomados durante la reunión..."><?php echo esc_textarea($reunion->getAcuerdos()); ?></textarea>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="minutos">Minutos de la Reunión</label></th>
                        <td>
                            <textarea id="minutos" name="minutos" rows="8" class="large-text" placeholder="Resumen detallado de lo tratado en la reunión..."><?php echo esc_textarea($reunion->getMinutos()); ?></textarea>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="estado">Estado</label></th>
                        <td>
                            <select id="estado" name="estado">
                                <option value="planificada" <?php selected($reunion->getEstado(), 'planificada'); ?>>Planificada</option>
                                <option value="confirmada" <?php selected($reunion->getEstado(), 'confirmada'); ?>>Confirmada</option>
                                <option value="en_curso" <?php selected($reunion->getEstado(), 'en_curso'); ?>>En Curso</option>
                                <option value="realizada" <?php selected($reunion->getEstado(), 'realizada'); ?>>Realizada</option>
                                <option value="cancelada" <?php selected($reunion->getEstado(), 'cancelada'); ?>>Cancelada</option>
                            </select>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" name="guardar_reunion" class="button button-primary">
                        <?php echo $action === 'nuevo' ? 'Crear Reunión' : 'Actualizar Reunión'; ?>
                    </button>
                    <a href="<?php echo admin_url('admin.php?page=ac-reuniones'); ?>" class="button">
                        Cancelar
                    </a>
                </p>
            </form>
        </div>

    <?php elseif ($action === 'ver' && $id): ?>
        <?php
        $reunion = $database->get_reunion_by_id($id);
        if (!$reunion):
        ?>
            <div class="notice notice-error"><p>Reunión no encontrada.</p></div>
        <?php else: 
            $asistentes = $reunion->getAsistentes();
            $miembros_asistentes = array();
            if (is_array($asistentes) && !empty($asistentes)) {
                foreach ($asistentes as $miembro_id) {
                    $miembro = $database->get_miembro_by_id($miembro_id);
                    if ($miembro) {
                        $miembros_asistentes[] = $miembro;
                    }
                }
            }
        ?>
            <div class="card">
                <h2>Detalles de Reunión</h2>
                
                <div class="ac-details-container">
                    <div class="ac-detail-section">
                        <h3>Información General</h3>
                        <div class="ac-detail-grid">
                            <div class="ac-detail-item">
                                <strong>Título:</strong>
                                <span><?php echo esc_html($reunion->getTitulo()); ?></span>
                            </div>
                            <div class="ac-detail-item">
                                <strong>Tipo:</strong>
                                <span class="tipo-reunion tipo-<?php echo esc_attr($reunion->getTipo()); ?>">
                                    <?php echo esc_html(ucfirst($reunion->getTipo())); ?>
                                </span>
                            </div>
                            <div class="ac-detail-item">
                                <strong>Fecha:</strong>
                                <span><?php echo date('d/m/Y', strtotime($reunion->getFecha())); ?></span>
                            </div>
                            <div class="ac-detail-item">
                                <strong>Horario:</strong>
                                <span><?php echo esc_html($reunion->getHoraInicio() . ' - ' . $reunion->getHoraFin()); ?></span>
                            </div>
                            <div class="ac-detail-item">
                                <strong>Lugar:</strong>
                                <span><?php echo esc_html($reunion->getLugar()); ?></span>
                            </div>
                            <div class="ac-detail-item">
                                <strong>Convocante:</strong>
                                <span><?php echo esc_html($reunion->getConvocante()); ?></span>
                            </div>
                            <div class="ac-detail-item">
                                <strong>Estado:</strong>
                                <span class="estado-badge estado-<?php echo esc_attr($reunion->getEstado()); ?>">
                                    <?php echo esc_html(ucfirst($reunion->getEstado())); ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <?php if (!empty($miembros_asistentes)): ?>
                    <div class="ac-detail-section">
                        <h3>Asistentes (<?php echo count($miembros_asistentes); ?>)</h3>
                        <div class="ac-detail-grid">
                            <?php foreach ($miembros_asistentes as $miembro): ?>
                            <div class="ac-detail-item">
                                <strong><?php echo esc_html($miembro->nombre . ' ' . $miembro->apellido); ?></strong>
                                <span><?php echo esc_html($miembro->cargo); ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($reunion->getAgenda()): ?>
                    <div class="ac-detail-section">
                        <h3>Agenda</h3>
                        <div class="ac-detail-content">
                            <?php echo wp_kses_post(wpautop($reunion->getAgenda())); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($reunion->getAcuerdos()): ?>
                    <div class="ac-detail-section">
                        <h3>Acuerdos</h3>
                        <div class="ac-detail-content">
                            <?php echo wp_kses_post(wpautop($reunion->getAcuerdos())); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($reunion->getMinutos()): ?>
                    <div class="ac-detail-section">
                        <h3>Minutos de la Reunión</h3>
                        <div class="ac-detail-content">
                            <?php echo wp_kses_post(wpautop($reunion->getMinutos())); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <p class="submit">
                    <a href="<?php echo admin_url('admin.php?page=ac-reuniones&action=editar&id=' . $reunion->getId()); ?>" class="button button-primary">
                        Editar Reunión
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=ac-reuniones'); ?>" class="button">
                        Volver al Listado
                    </a>
                </p>
            </div>
        <?php endif; ?>

    <?php else: ?>
        <div class="notice notice-error"><p>Acción no válida.</p></div>
    <?php endif; ?>
</div>

<style>
.tipo-reunion {
    padding: 4px 8px;
    border-radius: 3px;
    font-size: 12px;
    font-weight: bold;
    text-transform: uppercase;
}

.tipo-terapeutica { background: #e8f5e8; color: #2e7d32; }
.tipo-grupal { background: #e3f2fd; color: #1565c0; }
.tipo-operadores { background: #fff3e0; color: #ef6c00; }
.tipo-administrativa { background: #f3e5f5; color: #7b1fa2; }
.tipo-emergencia { background: #ffebee; color: #c62828; }

.estado-badge {
    padding: 4px 8px;
    border-radius: 3px;
    font-size: 12px;
    font-weight: bold;
    text-transform: uppercase;
}

.estado-planificada { background: #fff3cd; color: #856404; }
.estado-confirmada { background: #cce5ff; color: #004085; }
.estado-en_curso { background: #d4edda; color: #155724; }
.estado-realizada { background: #e2e3e5; color: #383d41; }
.estado-cancelada { background: #f8d7da; color: #721c24; }

.asistentes-count {
    background: #f0f0f0;
    padding: 2px 6px;
    border-radius: 10px;
    font-size: 11px;
}

.ac-details-container {
    max-width: 800px;
}

.ac-detail-section {
    margin-bottom: 2rem;
    padding: 1rem;
    background: #f9f9f9;
    border-radius: 4px;
}

.ac-detail-section h3 {
    margin-top: 0;
    border-bottom: 1px solid #ddd;
    padding-bottom: 0.5rem;
}

.ac-detail-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1rem;
}

.ac-detail-item {
    display: flex;
    flex-direction: column;
}

.ac-detail-item strong {
    margin-bottom: 0.25rem;
    color: #333;
}

.ac-detail-content {
    background: white;
    padding: 1rem;
    border-radius: 4px;
    border-left: 4px solid #0073aa;
}
</style>