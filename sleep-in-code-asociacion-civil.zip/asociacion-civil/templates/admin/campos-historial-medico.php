<?php
// Campos para Historial Médico
function ac_definir_campos_historial_medico() {
    return array(
        'fecha_historial' => array(
            'type' => 'date',
            'label' => 'Fecha del Registro',
            'required' => true
        ),
        'motivo_consulta' => array(
            'type' => 'textarea',
            'label' => 'Motivo de Consulta'
        ),
        'sintomas_actuales' => array(
            'type' => 'textarea',
            'label' => 'Síntomas Actuales'
        ),
        'antecedentes_personales' => array(
            'type' => 'textarea',
            'label' => 'Antecedentes Personales'
        ),
        'antecedentes_familiares' => array(
            'type' => 'textarea',
            'label' => 'Antecedentes Familiares'
        ),
        'habitos' => array(
            'type' => 'textarea',
            'label' => 'Hábitos (alimentación, sueño, etc.)'
        ),
        'alergias' => array(
            'type' => 'textarea',
            'label' => 'Alergias'
        ),
        'medicamentos_actuales' => array(
            'type' => 'textarea',
            'label' => 'Medicamentos Actuales'
        ),
        'examenes_complementarios' => array(
            'type' => 'textarea',
            'label' => 'Exámenes Complementarios'
        ),
        'resultados_examenes' => array(
            'type' => 'textarea',
            'label' => 'Resultados de Exámenes'
        ),
        'diagnostico' => array(
            'type' => 'textarea',
            'label' => 'Diagnóstico'
        ),
        'plan_tratamiento' => array(
            'type' => 'textarea',
            'label' => 'Plan de Tratamiento'
        ),
        'evolucion' => array(
            'type' => 'textarea',
            'label' => 'Evolución'
        ),
        'observaciones_medicas' => array(
            'type' => 'textarea',
            'label' => 'Observaciones Médicas'
        )
    );
}
?>