<?php
// Campos para Seguimiento Terapéutico
function ac_definir_campos_seguimiento_terapeutico() {
    return array(
        'fecha_seguimiento' => array(
            'type' => 'date',
            'label' => 'Fecha de Seguimiento',
            'required' => true
        ),
        'objetivo_seguimiento' => array(
            'type' => 'textarea',
            'label' => 'Objetivo del Seguimiento'
        ),
        'actividades_realizadas' => array(
            'type' => 'textarea',
            'label' => 'Actividades Realizadas'
        ),
        'observaciones_conducta' => array(
            'type' => 'textarea',
            'label' => 'Observaciones de Conducta'
        ),
        'cambios_identificados' => array(
            'type' => 'textarea',
            'label' => 'Cambios Identificados'
        ),
        'dificultades_observadas' => array(
            'type' => 'textarea',
            'label' => 'Dificultades Observadas'
        ),
        'apoyos_brindados' => array(
            'type' => 'textarea',
            'label' => 'Apoyos Brindados'
        ),
        'coordinacion_equipo' => array(
            'type' => 'textarea',
            'label' => 'Coordinación con Equipo'
        ),
        'recomendaciones' => array(
            'type' => 'textarea',
            'label' => 'Recomendaciones'
        ),
        'proximas_acciones' => array(
            'type' => 'textarea',
            'label' => 'Próximas Acciones'
        )
    );
}
?>