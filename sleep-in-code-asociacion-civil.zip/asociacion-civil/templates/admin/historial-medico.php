<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap" style="background: white; color: black; padding: 20px;">
    <h1 class="wp-heading-inline" style="color: black;">📋 Historial Médico</h1>
    <a href="<?php echo admin_url('admin.php?page=ac-historial-medico&action=nuevo' . ($paciente_id ? '&paciente_id=' . $paciente_id : '')); ?>" class="page-title-action" style="color: white; background: #0073aa; text-decoration: none; padding: 8px 12px; border-radius: 4px;">Agregar Nuevo Registro</a>
    
    <?php if (isset($_GET['updated'])): ?>
        <div class="notice notice-success is-dismissible" style="background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 10px; margin: 15px 0;">
            <p style="margin: 0; color: #155724;">Registro de historial médico guardado correctamente.</p>
        </div>
    <?php endif; ?>

    <hr class="wp-header-end" style="border-color: #ccc; margin: 20px 0;">

    <div class="ac-card" style="background: white; border: 1px solid #ccc; border-radius: 8px;">
        <div class="ac-card-header" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ccc; border-radius: 8px 8px 0 0;">
            <h2 style="color: black; margin: 0;">
                <?php if ($paciente): ?>
                    Historial Médico de: <?php echo esc_html($paciente->getNombreCompleto()); ?>
                <?php else: ?>
                    Lista de Historial Médico
                <?php endif; ?>
            </h2>
        </div>
        <div class="ac-card-body" style="padding: 20px;">
            <?php if (!$paciente): ?>
                <form method="get" class="ac-search-form">
                    <input type="hidden" name="page" value="ac-historial-medico">
                    <div class="tablenav top">
                        <div class="alignleft actions">
                            <label for="paciente_id" style="color: black; margin-right: 10px;">Filtrar por paciente:</label>
                            <select id="paciente_id" name="paciente_id" class="regular-text" style="color: black; border: 1px solid #ccc; padding: 5px;">
                                <option value="">Todos los pacientes</option>
                                <?php foreach ($pacientes as $p): ?>
                                    <option value="<?php echo $p->getId(); ?>" <?php selected($paciente_id, $p->getId()); ?>>
                                        <?php echo esc_html($p->getNombreCompleto() . ' (' . $p->getCedula() . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <input type="submit" class="button" value="Filtrar" style="color: white; background: #0073aa; border: 1px solid #0073aa; padding: 5px 10px; border-radius: 4px; margin-left: 10px;">
                            <?php if ($paciente_id): ?>
                                <a href="<?php echo admin_url('admin.php?page=ac-historial-medico'); ?>" class="button" style="color: #555; background: #f7f7f7; border: 1px solid #ccc; text-decoration: none; padding: 5px 10px; border-radius: 4px; margin-left: 10px;">Ver todos</a>
                            <?php endif; ?>
                        </div>
                        <br class="clear">
                    </div>
                </form>
            <?php endif; ?>

            <table class="wp-list-table widefat fixed striped" style="background: white; color: black; border: 1px solid #ccc; width: 100%; border-collapse: collapse;">
                <thead style="background: #f8f9fa;">
                    <tr>
                        <th style="color: black; border-bottom: 1px solid #ccc; padding: 12px 8px; text-align: left;">Fecha Consulta</th>
                        <th style="color: black; border-bottom: 1px solid #ccc; padding: 12px 8px; text-align: left;">Paciente</th>
                        <th style="color: black; border-bottom: 1px solid #ccc; padding: 12px 8px; text-align: left;">Tipo Consulta</th>
                        <th style="color: black; border-bottom: 1px solid #ccc; padding: 12px 8px; text-align: left;">Médico Tratante</th>
                        <th style="color: black; border-bottom: 1px solid #ccc; padding: 12px 8px; text-align: left;">Diagnóstico</th>
                        <th style="color: black; border-bottom: 1px solid #ccc; padding: 12px 8px; text-align: left;">Próxima Cita</th>
                        <th style="color: black; border-bottom: 1px solid #ccc; padding: 12px 8px; text-align: left;">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($historial)): ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 30px; color: black;">
                                <p style="color: black; margin-bottom: 15px;">No se encontraron registros de historial médico.</p>
                                <a href="<?php echo admin_url('admin.php?page=ac-historial-medico&action=nuevo' . ($paciente_id ? '&paciente_id=' . $paciente_id : '')); ?>" class="button button-primary" style="color: white; background: #0073aa; text-decoration: none; padding: 8px 12px; border-radius: 4px;">Agregar primer registro</a>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($historial as $registro): ?>
                            <tr style="border-bottom: 1px solid #eee;">
                                <td style="padding: 12px 8px; border-bottom: 1px solid #eee; color: black;"><?php echo date('d/m/Y', strtotime($registro->getFechaConsulta())); ?></td>
                                <td style="padding: 12px 8px; border-bottom: 1px solid #eee; color: black;">
                                    <strong style="color: black;"><?php echo esc_html($registro->getPaciente()->getNombreCompleto()); ?></strong>
                                    <br><small style="color: #666;">Cédula: <?php echo esc_html($registro->getPaciente()->getCedula()); ?></small>
                                </td>
                                <td style="padding: 12px 8px; border-bottom: 1px solid #eee; color: black;"><?php echo esc_html(ucfirst($registro->getTipoConsulta())); ?></td>
                                <td style="padding: 12px 8px; border-bottom: 1px solid #eee; color: black;"><?php echo esc_html($registro->getMedicoTratante() ?: 'No especificado'); ?></td>
                                <td style="padding: 12px 8px; border-bottom: 1px solid #eee; color: black;">
                                    <?php 
                                    $diagnostico = $registro->getDiagnostico();
                                    if (strlen($diagnostico) > 100) {
                                        echo esc_html(substr($diagnostico, 0, 100)) . '...';
                                    } else {
                                        echo esc_html($diagnostico);
                                    }
                                    ?>
                                </td>
                                <td style="padding: 12px 8px; border-bottom: 1px solid #eee; color: black;"><?php echo $registro->getProximaCita() ? date('d/m/Y', strtotime($registro->getProximaCita())) : 'No programada'; ?></td>
                                <td style="padding: 12px 8px; border-bottom: 1px solid #eee;">
                                    <div class="row-actions" style="font-size: 12px;">
                                        <a href="<?php echo admin_url('admin.php?page=ac-historial-medico&action=ver&id=' . $registro->getId()); ?>" style="color: #0073aa; text-decoration: none;">👁️ Ver</a> |
                                        <a href="<?php echo admin_url('admin.php?page=ac-historial-medico&action=editar&id=' . $registro->getId()); ?>" style="color: #0073aa; text-decoration: none;">✏️ Editar</a> |
                                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ac-historial-medico&action=eliminar&id=' . $registro->getId()), 'eliminar_historial_medico_' . $registro->getId()); ?>" 
                                           class="delete" 
                                           style="color: #dc3232; text-decoration: none;"
                                           onclick="return confirm('¿Está seguro de que desea eliminar este registro?');">🗑️ Eliminar</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.row-actions a {
    text-decoration: none;
    margin: 0 2px;
}

.row-actions a:hover {
    text-decoration: underline;
}

/* Estilos adicionales para mantener la consistencia */
.wp-list-table th {
    background: #f8f9fa !important;
    color: black !important;
    border-bottom: 1px solid #ccc !important;
}

.wp-list-table td {
    background: white !important;
    color: black !important;
    border-bottom: 1px solid #eee !important;
}

.wp-list-table tr:nth-child(even) td {
    background: #f9f9f9 !important;
}

.button {
    color: white;
    background: #0073aa;
    border: 1px solid #0073aa;
    padding: 5px 10px;
    border-radius: 4px;
    text-decoration: none;
    display: inline-block;
}

.button:hover {
    background: #005a87;
    border-color: #005a87;
    color: white;
}

.page-title-action {
    color: white;
    background: #0073aa;
    border: 1px solid #0073aa;
    padding: 8px 12px;
    border-radius: 4px;
    text-decoration: none;
    display: inline-block;
}

.page-title-action:hover {
    background: #005a87;
    border-color: #005a87;
    color: white;
}
</style>