<?php
/**
 * Desinstalación completa del plugin Administrador de Asociación Civil
 * 
 * @package AsociacionCivil
 */

// Verificar que WordPress esté cargando este archivo durante la desinstalación
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Verificar permisos
if (!current_user_can('activate_plugins')) {
    wp_die('No tienes permisos suficientes para desinstalar este plugin.');
}

// Opción para eliminar todos los datos
$eliminar_datos = get_option('ac_eliminar_datos_desinstalacion', true);

if ($eliminar_datos) {
    global $wpdb;
    
    // =================================================================
    // ELIMINAR TODAS LAS TABLAS DE LA BASE DE DATOS - LISTA COMPLETA
    // =================================================================
    
    // Todas las tablas que están en tu base de datos actualmente
    $tablas = array(
        // Tablas del sistema original
        $wpdb->prefix . 'ac_miembros',
        $wpdb->prefix . 'ac_eventos',
        $wpdb->prefix . 'ac_documentos',
        $wpdb->prefix . 'ac_asambleas',
        $wpdb->prefix . 'ac_actas',
        
        // Tablas del módulo de psicodramas
        $wpdb->prefix . 'ac_psicodramas',
        
        // Tablas del módulo de pacientes
        $wpdb->prefix . 'ac_pacientes',
        $wpdb->prefix . 'ac_historial_medico',
        $wpdb->prefix . 'ac_seguimiento_terapeutico',
        
        // Tablas del sistema integral
        $wpdb->prefix . 'ac_metricas',        // Esta estaba en tu BD pero no en el código
        $wpdb->prefix . 'ac_medicacion',
        $wpdb->prefix . 'ac_registros_diarios',
        
        // Tablas adicionales del sistema
        $wpdb->prefix . 'ac_solo_por_hoy',    // Faltaba en tu uninstall anterior
        $wpdb->prefix . 'ac_reuniones',       // Faltaba en tu uninstall anterior
        $wpdb->prefix . 'ac_chat_operadores', // Faltaba en tu uninstall anterior
        $wpdb->prefix . 'ac_tiempo_limpio',
        
        // Otras tablas que puedas tener
        $wpdb->prefix . 'ac_camaras',         // Esta estaba en tu BD pero no en el código
    );
    
    // =================================================================
    // PRIMERO: Intentar eliminar con DROP TABLE IF EXISTS
    // =================================================================
    foreach ($tablas as $tabla) {
        $wpdb->query("DROP TABLE IF EXISTS $tabla");
    }
    
    // =================================================================
    // SEGUNDO: Eliminar CUALQUIER tabla que empiece con el prefijo + ac_
    // Esto asegura que elimine tablas que no estén en la lista
    // =================================================================
    $tablas_prefijo_ac = $wpdb->get_col("SHOW TABLES LIKE '{$wpdb->prefix}ac_%'");
    
    foreach ($tablas_prefijo_ac as $tabla) {
        $wpdb->query("DROP TABLE IF EXISTS $tabla");
        error_log("Desinstalación: Eliminada tabla $tabla");
    }
    
    // =================================================================
    // ELIMINAR TODAS LAS OPCIONES DE WORDPRESS RELACIONADAS
    // =================================================================
    
    $opciones = array(
        // Opciones generales
        'asociacion_civil_settings',
        'ac_miembros_por_pagina',
        'ac_dias_recordatorio',
        'ac_notificaciones_email',
        'ac_backup_automatico',
        'ac_eliminar_datos_desinstalacion',
        'ac_version_plugin',
        'ac_ultimo_backup',
        'ac_configuracion_inicial',
        'ac_modo_desinstalacion',
        'ac_enviar_notificacion_desinstalacion',
        
        // Opciones específicas de módulos
        'ac_psicodramas_settings',
        'ac_pacientes_settings',
        'ac_historial_medico_settings',
        'ac_seguimiento_terapeutico_settings',
        'ac_solo_por_hoy_settings',
        'ac_reuniones_settings',
        'ac_chat_operadores_settings',
        'ac_tiempo_limpio_settings',
        'ac_registros_diarios_settings',
        'ac_medicacion_settings',
        'ac_metricas_settings',
        'ac_camaras_settings',
        'ac_integral_settings',
        
        // Opciones de configuración UI/UX
        'ac_dashboard_widgets',
        'ac_color_scheme',
        'ac_notifications_enabled',
        'ac_email_templates',
        'ac_report_settings',
        
        // Opciones de caché y temporales
        'ac_cache_data',
        'ac_last_sync',
        'ac_statistics_cache',
    );
    
    foreach ($opciones as $opcion) {
        delete_option($opcion);
        // También eliminar opciones de red si es multisitio
        if (is_multisite()) {
            delete_site_option($opcion);
        }
        delete_option($opcion . '_backup');
    }
    
    // =================================================================
    // ELIMINAR METADATOS DE USUARIOS
    // =================================================================
    
    $meta_keys = array(
        // Metadatos generales
        'ac_%',
        'asociacion_civil_%',
        'ac_miembro_%',
        'ac_paciente_%',
        'ac_terapeuta_%',
        'ac_operador_%',
        'ac_user_permissions',
        'ac_last_login',
        'ac_notification_prefs',
        
        // Metadatos específicos
        'ac_custom_fields_%',
        'ac_profile_complete',
        'ac_assigned_roles',
        'ac_dashboard_prefs',
    );
    
    foreach ($meta_keys as $meta_key) {
        if (strpos($meta_key, '%') !== false) {
            // Usar LIKE para patrones
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE %s",
                $meta_key
            ));
        } else {
            // Eliminar clave específica
            delete_metadata('user', 0, $meta_key, '', true);
        }
    }
    
    // =================================================================
    // ELIMINAR ARCHIVOS SUBIDOS DEL PLUGIN
    // =================================================================
    
    $upload_dir = wp_upload_dir();
    $plugin_directories = array(
        // Directorio principal del plugin
        $upload_dir['basedir'] . '/asociacion-civil/',
        
        // Directorios específicos
        $upload_dir['basedir'] . '/ac-documentos/',
        $upload_dir['basedir'] . '/ac-fotos/',
        $upload_dir['basedir'] . '/ac-actas/',
        $upload_dir['basedir'] . '/ac-backups/',
        $upload_dir['basedir'] . '/ac-psicodramas/',
        $upload_dir['basedir'] . '/ac-pacientes/',
        $upload_dir['basedir'] . '/ac-historial/',
        $upload_dir['basedir'] . '/ac-solo-por-hoy/',
        $upload_dir['basedir'] . '/ac-camaras/',
        $upload_dir['basedir'] . '/ac-metricas/',
    );
    
    foreach ($plugin_directories as $directory) {
        if (file_exists($directory)) {
            eliminar_directorio_recursivo($directory);
        }
    }
    
    // =================================================================
    // ELIMINAR CRON JOBS DEL PLUGIN
    // =================================================================
    
    $eventos_cron = array(
        // Cron jobs generales
        'ac_backup_automatico',
        'ac_limpieza_temporal',
        'ac_recordatorio_eventos',
        'ac_reporte_mensual',
        
        // Cron jobs de módulos
        'ac_notificacion_solo_por_hoy',
        'ac_limpieza_chat',
        'ac_actualizacion_tiempo_limpio',
        'ac_recordatorio_medicacion',
        'ac_sincronizacion_metricas',
        'ac_reporte_camaras',
        'ac_actualizacion_estadisticas',
        'ac_notificacion_reuniones',
    );
    
    foreach ($eventos_cron as $evento) {
        $timestamp = wp_next_scheduled($evento);
        if ($timestamp) {
            wp_unschedule_event($timestamp, $evento);
        }
        wp_clear_scheduled_hook($evento);
    }
    
    // =================================================================
    // ELIMINAR ROLES Y CAPACIDADES
    // =================================================================
    
    // Eliminar roles personalizados
    $roles_personalizados = array(
        'junta_directiva',
        'terapeuta_ac',
        'operador_ac',
        'miembro_activo',
        'paciente_ac',
        'administrador_ac',
        'supervisor_ac',
    );
    
    foreach ($roles_personalizados as $rol) {
        remove_role($rol);
    }
    
    // Remover capacidades de roles existentes
    $roles = array('administrator', 'editor', 'author', 'contributor', 'subscriber');
    
    $capacidades = array(
        // Capacidades generales
        'manage_asociacion',
        'view_asociacion_dashboard',
        
        // Capacidades de módulos específicos
        'gestionar_miembros',
        'ver_miembros',
        'editar_miembros',
        'eliminar_miembros',
        'exportar_miembros',
        
        'gestionar_eventos',
        'ver_eventos',
        'crear_eventos',
        'editar_eventos',
        'eliminar_eventos',
        
        'gestionar_documentos',
        'ver_documentos',
        'subir_documentos',
        'editar_documentos',
        'eliminar_documentos',
        
        'gestionar_asambleas',
        'ver_asambleas',
        'crear_asambleas',
        'editar_asambleas',
        'eliminar_asambleas',
        
        'gestionar_actas',
        'ver_actas',
        'crear_actas',
        'editar_actas',
        'eliminar_actas',
        
        'gestionar_psicodramas',
        'ver_psicodramas',
        'crear_psicodramas',
        'editar_psicodramas',
        'eliminar_psicodramas',
        
        'gestionar_pacientes',
        'ver_pacientes',
        'crear_pacientes',
        'editar_pacientes',
        'eliminar_pacientes',
        'ver_historial_pacientes',
        
        'gestionar_historial_medico',
        'ver_historial_medico',
        'crear_historial_medico',
        'editar_historial_medico',
        'eliminar_historial_medico',
        
        'gestionar_seguimiento',
        'ver_seguimiento',
        'crear_seguimiento',
        'editar_seguimiento',
        'eliminar_seguimiento',
        
        'gestionar_solo_por_hoy',
        'ver_solo_por_hoy',
        'crear_solo_por_hoy',
        'editar_solo_por_hoy',
        'eliminar_solo_por_hoy',
        
        'gestionar_reuniones',
        'ver_reuniones',
        'crear_reuniones',
        'editar_reuniones',
        'eliminar_reuniones',
        
        'usar_chat_operadores',
        'ver_chat_operadores',
        'gestionar_chat_operadores',
        
        'gestionar_tiempo_limpio',
        'ver_tiempo_limpio',
        'crear_tiempo_limpio',
        'editar_tiempo_limpio',
        'eliminar_tiempo_limpio',
        
        'gestionar_registros_diarios',
        'ver_registros_diarios',
        'crear_registros_diarios',
        'editar_registros_diarios',
        
        'gestionar_medicacion',
        'ver_medicacion',
        'crear_medicacion',
        'editar_medicacion',
        'eliminar_medicacion',
        
        'gestionar_metricas',
        'ver_metricas',
        'crear_metricas',
        'editar_metricas',
        
        'gestionar_camaras',
        'ver_camaras',
        'configurar_camaras',
        
        'ver_reportes',
        'exportar_reportes',
        'ver_estadisticas',
        
        // Capacidades de administración
        'ac_manage_settings',
        'ac_view_audit_log',
        'ac_manage_backups',
        'ac_import_export',
    );
    
    foreach ($roles as $role_name) {
        $role = get_role($role_name);
        if ($role) {
            foreach ($capacidades as $cap) {
                $role->remove_cap($cap);
            }
        }
    }
    
    // =================================================================
    // LIMPIAR TRANSITORIOS Y CACHÉ
    // =================================================================
    
    // Eliminar transientes del plugin
    $wpdb->query("
        DELETE FROM {$wpdb->options} 
        WHERE option_name LIKE '_transient_ac_%' 
        OR option_name LIKE '_transient_timeout_ac_%'
        OR option_name LIKE '_site_transient_ac_%'
        OR option_name LIKE '_site_transient_timeout_ac_%'
    ");
    
    // Eliminar opciones temporales
    $wpdb->query("
        DELETE FROM {$wpdb->options} 
        WHERE option_name LIKE 'ac_temp_%'
        OR option_name LIKE 'ac_cache_%'
        OR option_name LIKE 'ac_session_%'
    ");
    
    // =================================================================
    // REGISTRAR LOG DE DESINSTALACIÓN
    // =================================================================
    
    registrar_log_desinstalacion(true);
    
    // =================================================================
    // NOTIFICACIÓN (OPCIONAL)
    // =================================================================
    
    if (get_option('ac_enviar_notificacion_desinstalacion', false)) {
        enviar_notificacion_desinstalacion();
    }
    
    // =================================================================
    // LIMPIAR CACHÉ RESIDUAL
    // =================================================================
    limpiar_cache_residual();
}

/**
 * Función para desinstalación parcial (conservar datos)
 */
function desinstalacion_parcial() {
    global $wpdb;
    
    // Solo eliminar opciones de configuración, mantener datos en tablas
    $opciones_configuracion = array(
        // Opciones generales
        'ac_miembros_por_pagina',
        'ac_dias_recordatorio',
        'ac_notificaciones_email',
        'ac_backup_automatico',
        'ac_version_plugin',
        
        // Opciones de módulos
        'ac_psicodramas_settings',
        'ac_pacientes_settings',
        'ac_historial_medico_settings',
        'ac_seguimiento_terapeutico_settings',
        'ac_solo_por_hoy_settings',
        'ac_reuniones_settings',
        'ac_chat_operadores_settings',
        'ac_tiempo_limpio_settings',
        'ac_registros_diarios_settings',
        'ac_medicacion_settings',
        'ac_metricas_settings',
        'ac_camaras_settings',
        'ac_integral_settings',
        
        // UI/UX
        'ac_dashboard_widgets',
        'ac_color_scheme',
    );
    
    foreach ($opciones_configuracion as $opcion) {
        delete_option($opcion);
        if (is_multisite()) {
            delete_site_option($opcion);
        }
    }
    
    // Eliminar cron jobs
    $eventos_cron = array(
        'ac_backup_automatico',
        'ac_limpieza_temporal',
        'ac_recordatorio_eventos',
        'ac_reporte_mensual',
        'ac_notificacion_solo_por_hoy',
        'ac_limpieza_chat',
        'ac_actualizacion_tiempo_limpio',
        'ac_recordatorio_medicacion',
        'ac_sincronizacion_metricas',
        'ac_reporte_camaras',
    );
    
    foreach ($eventos_cron as $evento) {
        $timestamp = wp_next_scheduled($evento);
        if ($timestamp) {
            wp_unschedule_event($timestamp, $evento);
        }
        wp_clear_scheduled_hook($evento);
    }
    
    // Remover capacidades básicas
    $roles = array('administrator', 'editor', 'author', 'contributor', 'subscriber');
    
    $capacidades_basicas = array(
        'manage_asociacion',
        'view_asociacion_dashboard',
        'ac_manage_settings',
    );
    
    foreach ($roles as $role_name) {
        $role = get_role($role_name);
        if ($role) {
            foreach ($capacidades_basicas as $cap) {
                $role->remove_cap($cap);
            }
        }
    }
    
    // Eliminar roles personalizados
    $roles_personalizados = array(
        'junta_directiva',
        'terapeuta_ac',
        'operador_ac',
        'miembro_activo',
        'paciente_ac',
        'administrador_ac',
        'supervisor_ac',
    );
    
    foreach ($roles_personalizados as $rol) {
        remove_role($rol);
    }
    
    // Eliminar transientes
    $wpdb->query("
        DELETE FROM {$wpdb->options} 
        WHERE option_name LIKE '_transient_ac_%' 
        OR option_name LIKE '_transient_timeout_ac_%'
    ");
    
    registrar_log_desinstalacion(false);
}

/**
 * Verificar modo de desinstalación
 */
$modo_desinstalacion = get_option('ac_modo_desinstalacion', 'completa');

if ($modo_desinstalacion === 'completa') {
    // Lógica de desinstalación completa ya ejecutada arriba si $eliminar_datos es true
} else {
    desinstalacion_parcial();
}

/**
 * FUNCIONES AUXILIARES
 */

function eliminar_directorio_recursivo($dir) {
    if (!file_exists($dir)) {
        return true;
    }
    
    if (!is_dir($dir)) {
        return unlink($dir);
    }
    
    foreach (scandir($dir) as $item) {
        if ($item == '.' || $item == '..') {
            continue;
        }
        
        if (!eliminar_directorio_recursivo($dir . DIRECTORY_SEPARATOR . $item)) {
            return false;
        }
    }
    
    return rmdir($dir);
}

function registrar_log_desinstalacion($datos_eliminados) {
    $log_entry = array(
        'fecha' => current_time('mysql'),
        'plugin' => 'Administrador de Asociación Civil',
        'version' => get_option('ac_version_plugin', '1.0.0'),
        'accion' => 'Desinstalación ' . ($datos_eliminados ? 'completa' : 'parcial'),
        'usuario' => get_current_user_id(),
        'usuario_nombre' => wp_get_current_user()->display_name,
        'datos_eliminados' => $datos_eliminados,
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'Desconocida',
        'url' => get_site_url(),
        'modo' => get_option('ac_modo_desinstalacion', 'completa')
    );
    
    $log_file = WP_CONTENT_DIR . '/logs/ac-uninstall.log';
    
    // Crear directorio de logs si no existe
    $log_dir = dirname($log_file);
    if (!file_exists($log_dir)) {
        wp_mkdir_p($log_dir);
    }
    
    // Agregar entrada al log
    file_put_contents($log_file, date('Y-m-d H:i:s') . ' - ' . json_encode($log_entry) . PHP_EOL, FILE_APPEND | LOCK_EX);
}

function enviar_notificacion_desinstalacion() {
    $admin_email = get_option('admin_email');
    $site_name = get_bloginfo('name');
    
    $asunto = '✅ Plugin Desinstalado - ' . $site_name;
    
    $mensaje = "============================================\n";
    $mensaje .= "PLUGIN DESINSTALADO: Administrador de Asociación Civil\n";
    $mensaje .= "============================================\n\n";
    
    $mensaje .= "📋 INFORMACIÓN DEL SITIO:\n";
    $mensaje .= "   • Sitio: $site_name\n";
    $mensaje .= "   • URL: " . get_site_url() . "\n";
    $mensaje .= "   • Fecha: " . current_time('mysql') . "\n";
    $mensaje .= "   • Usuario: " . wp_get_current_user()->display_name . "\n";
    $mensaje .= "   • IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'Desconocida') . "\n\n";
    
    $mensaje .= "🔧 MODO DE DESINSTALACIÓN:\n";
    $mensaje .= "   • Modo: " . get_option('ac_modo_desinstalacion', 'completa') . "\n\n";
    
    if (get_option('ac_modo_desinstalacion', 'completa') === 'completa') {
        $mensaje .= "⚠️  ATENCIÓN: TODOS LOS DATOS HAN SIDO ELIMINADOS\n";
        $mensaje .= "   Se eliminaron todas las tablas y datos del plugin.\n\n";
        
        $mensaje .= "🗑️  TABLAS ELIMINADAS:\n";
        global $wpdb;
        $tablas_eliminadas = $wpdb->get_col("SHOW TABLES LIKE '{$wpdb->prefix}ac_%'");
        if (empty($tablas_eliminadas)) {
            $mensaje .= "   • Todas las tablas fueron eliminadas correctamente\n";
        } else {
            foreach ($tablas_eliminadas as $tabla) {
                $mensaje .= "   • " . str_replace($wpdb->prefix, '', $tabla) . "\n";
            }
        }
    } else {
        $mensaje .= "💾 DATOS CONSERVADOS\n";
        $mensaje .= "   • Los datos se mantuvieron para futura reinstalación\n";
        $mensaje .= "   • Solo se eliminó la configuración del plugin\n\n";
    }
    
    $mensaje .= "\n📝 ACCIONES RECOMENDADAS:\n";
    $mensaje .= "   1. Verificar que no haya archivos residuales en /wp-content/uploads/\n";
    $mensaje .= "   2. Revisar que no haya opciones residuales en la base de datos\n";
    $mensaje .= "   3. Si fue un error, reinstalar desde: " . admin_url('plugin-install.php') . "\n\n";
    
    $mensaje .= "============================================\n";
    $mensaje .= "Fin del reporte de desinstalación\n";
    $mensaje .= "============================================\n";
    
    $headers = array('Content-Type: text/plain; charset=UTF-8');
    
    wp_mail($admin_email, $asunto, $mensaje, $headers);
}

function limpiar_cache_residual() {
    global $wpdb;
    
    // Limpiar caché de WordPress
    if (function_exists('wp_cache_flush')) {
        wp_cache_flush();
    }
    
    // Limpiar caché de transients específicos
    $wpdb->query("
        DELETE FROM {$wpdb->options} 
        WHERE option_name LIKE '%ac_%' 
        AND (option_name LIKE '_transient_%' OR option_name LIKE '_site_transient_%')
    ");
    
    // Si usas algún plugin de caché externo, limpiarlo
    if (function_exists('w3tc_pgcache_flush')) {
        w3tc_pgcache_flush();
    }
    if (function_exists('wpfc_clear_all_cache')) {
        wpfc_clear_all_cache();
    }
    if (function_exists('rocket_clean_domain')) {
        rocket_clean_domain();
    }
    
    // Limpiar caché del navegador para usuarios admin
    if (current_user_can('administrator')) {
        $wpdb->query("
            DELETE FROM {$wpdb->options} 
            WHERE option_name LIKE '_transient_bb_cache_%'
            OR option_name LIKE '_transient_wp_rest_cache_%'
        ");
    }
}

// Ejecutar limpieza final
limpiar_cache_residual();

// Log final para debug
if (defined('WP_DEBUG') && WP_DEBUG) {
    $debug_info = array(
        'timestamp' => time(),
        'action' => 'uninstall_complete',
        'plugin' => 'asociacion-civil',
        'user' => get_current_user_id(),
        'mode' => get_option('ac_modo_desinstalacion', 'completa'),
        'data_deleted' => $eliminar_datos,
        'site' => get_site_url()
    );
    
    error_log('Desinstalación de Asociación Civil completada: ' . json_encode($debug_info));
}

// Eliminar la opción de debug si existe
delete_option('ac_debug_mode');

// Mensaje final
echo '<div class="notice notice-success"><p>✅ Plugin "Administrador de Asociación Civil" desinstalado correctamente.</p></div>';
?>