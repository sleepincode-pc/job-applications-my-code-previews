jQuery(document).ready(function($) {
    'use strict';

    // Actualizar widget via AJAX
    function actualizarWidget() {
        var $widget = $('.ac-dashboard-widget');
        var $contenido = $widget.find('.ac-widget-content');
        
        $contenido.html('<div class="ac-widget-loading"><div class="spinner is-active"></div>Cargando...</div>');
        
        $.post(ac_dashboard.ajax_url, {
            action: 'actualizar_widget_asociacion',
            nonce: ac_dashboard.nonce
        }, function(response) {
            if (response.success) {
                $contenido.html(response.data.html);
                inicializarInteractividad();
            } else {
                $contenido.html('<div class="ac-widget-empty">Error al cargar los datos</div>');
            }
        }).fail(function() {
            $contenido.html('<div class="ac-widget-empty">Error de conexión</div>');
        });
    }

    // Inicializar interactividad del widget
    function inicializarInteractividad() {
        // Tooltips para elementos
        $('.ac-widget-tooltip').hover(function() {
            var tooltip = $(this).data('tooltip');
            if (tooltip) {
                $('<div class="ac-tooltip-bubble">' + tooltip + '</div>').appendTo('body');
            }
        }, function() {
            $('.ac-tooltip-bubble').remove();
        });

        // Contador de caracteres en tiempo real
        $('.ac-widget-counter').each(function() {
            var $elemento = $(this);
            var max = $elemento.data('max');
            var actual = $elemento.text().length;
            
            $elemento.after('<small class="ac-counter">' + actual + '/' + max + '</small>');
            
            $elemento.on('input', function() {
                var longitud = $(this).text().length;
                $elemento.next('.ac-counter').text(longitud + '/' + max);
                
                if (longitud > max) {
                    $elemento.next('.ac-counter').addClass('ac-counter-exceeded');
                } else {
                    $elemento.next('.ac-counter').removeClass('ac-counter-exceeded');
                }
            });
        });

        // Expandir/contraer secciones
        $('.ac-widget-expand-toggle').on('click', function(e) {
            e.preventDefault();
            var $toggle = $(this);
            var $seccion = $toggle.closest('.ac-widget-section');
            var $contenido = $seccion.find('.ac-widget-expandable');
            
            $contenido.slideToggle(200, function() {
                $toggle.text($contenido.is(':visible') ? 'Ver menos' : 'Ver más');
                $toggle.toggleClass('ac-expanded', $contenido.is(':visible'));
            });
        });

        // Quick actions
        $('.ac-quick-action-btn').on('click', function(e) {
            e.preventDefault();
            var $boton = $(this);
            var accion = $boton.data('action');
            
            $boton.prop('disabled', true).addClass('ac-loading');
            
            ejecutarAccionRapida(accion, $boton);
        });

        // Auto-refresh cada 5 minutos
        setInterval(actualizarWidget, 5 * 60 * 1000);
    }

    // Ejecutar acciones rápidas
    function ejecutarAccionRapida(accion, $boton) {
        $.post(ac_dashboard.ajax_url, {
            action: 'ac_accion_rapida',
            tipo_accion: accion,
            nonce: ac_dashboard.nonce
        }, function(response) {
            if (response.success) {
                mostrarNotificacion(response.data.mensaje, 'success');
                
                // Actualizar estadísticas si es necesario
                if (response.data.actualizar_estadisticas) {
                    actualizarEstadisticas();
                }
            } else {
                mostrarNotificacion(response.data, 'error');
            }
            
            $boton.prop('disabled', false).removeClass('ac-loading');
        }).fail(function() {
            mostrarNotificacion('Error de conexión', 'error');
            $boton.prop('disabled', false).removeClass('ac-loading');
        });
    }

    // Actualizar solo las estadísticas
    function actualizarEstadisticas() {
        var $stats = $('.ac-widget-stats');
        $stats.addClass('ac-updating');
        
        $.post(ac_dashboard.ajax_url, {
            action: 'actualizar_estadisticas_widget',
            nonce: ac_dashboard.nonce
        }, function(response) {
            if (response.success) {
                $stats.html(response.data.html);
                $stats.removeClass('ac-updating');
            }
        });
    }

    // Mostrar notificaciones
    function mostrarNotificacion(mensaje, tipo) {
        var $notificacion = $('<div class="notice notice-' + tipo + ' is-dismissible"><p>' + mensaje + '</p></div>');
        
        $('.ac-dashboard-widget').prepend($notificacion);
        
        setTimeout(function() {
            $notificacion.fadeOut(300, function() {
                $(this).remove();
            });
        }, 5000);
        
        // Cerrar manualmente
        $notificacion.find('.notice-dismiss').on('click', function() {
            $notificacion.fadeOut(300, function() {
                $(this).remove();
            });
        });
    }

    // Gestión de eventos
    $('.ac-widget-event').on('click', function() {
        var eventoId = $(this).data('evento-id');
        if (eventoId) {
            window.location.href = ac_dashboard.base_url + 'admin.php?page=ac-eventos&action=editar&id=' + eventoId;
        }
    });

    // Búsqueda en tiempo real en listas
    $('.ac-widget-search').on('input', function() {
        var busqueda = $(this).val().toLowerCase();
        var $lista = $(this).closest('.ac-widget-section').find('.ac-widget-list-item');
        
        $lista.each(function() {
            var texto = $(this).text().toLowerCase();
            if (texto.indexOf(busqueda) > -1) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });

    // Ordenamiento de listas
    $('.ac-widget-sort').on('change', function() {
        var criterio = $(this).val();
        var $contenedor = $(this).closest('.ac-widget-section').find('.ac-widget-sortable-container');
        var $elementos = $contenedor.children('.ac-widget-sortable-item');
        
        $elementos.sort(function(a, b) {
            var aVal = $(a).data(criterio);
            var bVal = $(b).data(criterio);
            
            if (criterio === 'fecha') {
                return new Date(bVal) - new Date(aVal);
            } else {
                return aVal - bVal;
            }
        }).appendTo($contenedor);
    });

    // Inicializar cuando el documento está listo
    inicializarInteractividad();

    // Manejar visibilidad del widget
    $(document).on('heartbeat-tick', function(event, data) {
        if (data.ac_widget_update) {
            actualizarWidget();
        }
    });

    // Configurar heartbeat para actualizaciones automáticas
    $(document).on('heartbeat-send', function(event, data) {
        data.ac_widget_check = true;
    });
});

// Funciones globales para el widget
var ACWidget = {
    refrescar: function() {
        jQuery('.ac-dashboard-widget').each(function() {
            var event = new CustomEvent('ac-widget-refresh');
            this.dispatchEvent(event);
        });
    },
    
    exportarDatos: function(tipo) {
        var url = ac_dashboard.ajax_url + '?action=exportar_' + tipo + '&nonce=' + ac_dashboard.nonce;
        window.open(url, '_blank');
    },
    
    mostrarDetalles: function(elemento, tipo) {
        var id = jQuery(elemento).data('id');
        jQuery.post(ac_dashboard.ajax_url, {
            action: 'obtener_detalles_' + tipo,
            id: id,
            nonce: ac_dashboard.nonce
        }, function(response) {
            if (response.success) {
                ACWidget.mostrarModal(response.data);
            }
        });
    },
    
    mostrarModal: function(contenido) {
        var modal = jQuery(
            '<div class="ac-modal">' +
            '<div class="ac-modal-content">' +
            '<span class="ac-modal-close">&times;</span>' +
            '<div class="ac-modal-body">' + contenido + '</div>' +
            '</div>' +
            '</div>'
        );
        
        jQuery('body').append(modal);
        
        modal.fadeIn();
        
        modal.find('.ac-modal-close').on('click', function() {
            modal.fadeOut(function() {
                jQuery(this).remove();
            });
        });
        
        jQuery(window).on('click', function(e) {
            if (e.target === modal[0]) {
                modal.fadeOut(function() {
                    jQuery(this).remove();
                });
            }
        });
    }
};