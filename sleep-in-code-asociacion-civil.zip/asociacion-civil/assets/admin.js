jQuery(document).ready(function($) {
    'use strict';

    // =============================================
    // CONFIGURACIÓN Y VERIFICACIÓN DE DEPENDENCIAS - CORREGIDO
    // =============================================

    // Configuración segura mejorada
    var ac_config = {
        ajaxurl: window.ajaxurl || '/wp-admin/admin-ajax.php',
        nonce: (window.ac_admin_config && ac_admin_config.nonce) || (window.ac_ajax && ac_ajax.nonce) || '',
        base_url: (window.ac_admin_config && ac_admin_config.base_url) || (window.ac_ajax && ac_ajax.base_url) || '',
        text: (window.ac_admin_config && ac_admin_config.textos) || (window.ac_ajax && ac_ajax.text_domain) || {}
    };

    // Verificar y cargar dependencias faltantes
    function cargarDependenciasFaltantes() {
        var dependenciasCargadas = [];
        
        // Cargar jQuery UI Tooltip si no está disponible
        if (typeof $.fn.tooltip === 'undefined') {
            console.log('Cargando jQuery UI Tooltip dinámicamente...');
            
            // Cargar CSS
            if (!$('link[href*="jquery-ui"]').length) {
                $('head').append('<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" type="text/css" />');
            }
            
            // Cargar JavaScript
            var script = document.createElement('script');
            script.src = 'https://code.jquery.com/ui/1.12.1/jquery-ui.min.js';
            script.onload = function() {
                console.log('✅ jQuery UI cargado dinámicamente');
                dependenciasCargadas.push('jQuery UI Tooltip');
                inicializarTooltips();
            };
            document.head.appendChild(script);
        } else {
            dependenciasCargadas.push('jQuery UI Tooltip');
        }
        
        return dependenciasCargadas;
    }

    // Verificar dependencias críticas mejorado
    function verificarDependencias() {
        var dependencias = {
            'jQuery': typeof jQuery !== 'undefined',
            'jQuery UI Core': typeof $.ui !== 'undefined',
            'jQuery UI Tooltip': typeof $.fn.tooltip !== 'undefined',
            'jQuery UI Datepicker': typeof $.fn.datepicker !== 'undefined',
            'Configuración AJAX': window.ajaxurl !== undefined
        };

        var faltantes = [];
        $.each(dependencias, function(nombre, estado) {
            if (!estado) {
                faltantes.push(nombre);
                console.warn('Falta dependencia: ' + nombre);
            }
        });

        if (faltantes.length > 0) {
            console.warn('Dependencias faltantes: ', faltantes);
            
            // Intentar cargar dependencias dinámicamente
            var cargadas = cargarDependenciasFaltantes();
            if (cargadas.length > 0) {
                console.log('Dependencias cargadas dinámicamente: ', cargadas);
            }
            
            return faltantes.length === 0;
        }

        return true;
    }

    // =============================================
    // FUNCIONES UTILITARIAS MEJORADAS
    // =============================================

    function mostrarNotificacion(mensaje, tipo = 'info', tiempo = 5000) {
        var clases = {
            'success': 'notice notice-success',
            'error': 'notice notice-error', 
            'warning': 'notice notice-warning',
            'info': 'notice notice-info'
        };

        var clase = clases[tipo] || clases.info;
        var id = 'ac-notificacion-' + Date.now();
        
        var $notificacion = $(
            '<div id="' + id + '" class="' + clase + ' is-dismissible" style="margin: 5px 0; padding: 8px 12px;">' +
            '<p style="margin: 0;">' + mensaje + '</p>' +
            '</div>'
        );
        
        // Insertar después del primer h1
        $('h1').first().after($notificacion);
        
        // Auto-eliminar después del tiempo especificado
        if (tiempo > 0) {
            setTimeout(function() {
                $notificacion.fadeOut(300, function() {
                    $(this).remove();
                });
            }, tiempo);
        }
        
        // Hacerla descartable
        $notificacion.on('click', function() {
            $(this).fadeOut(300, function() {
                $(this).remove();
            });
        });
        
        return $notificacion;
    }

    function toggleLoading($element, estado, textoPersonalizado = null) {
        if (estado) {
            $element.prop('disabled', true)
                   .data('original-text', $element.html())
                   .html('<span class="ac-loading-spinner"></span> ' + 
                         (textoPersonalizado || (ac_config.text.loading || 'Cargando...')));
        } else {
            var textoOriginal = $element.data('original-text') || $element.text();
            $element.prop('disabled', false).html(textoOriginal);
        }
    }

    // =============================================
    // INICIALIZACIÓN DE COMPONENTES UI MEJORADA
    // =============================================

    function inicializarTooltips() {
        if (typeof $.fn.tooltip !== 'undefined') {
            $('.ac-tooltip').tooltip({
                track: true,
                show: {
                    effect: "fadeIn",
                    duration: 200
                },
                hide: {
                    effect: "fadeOut", 
                    duration: 200
                },
                position: {
                    my: "center bottom-10",
                    at: "center top",
                    using: function(position, feedback) {
                        $(this).css(position);
                        $("<div>")
                            .addClass("arrow")
                            .addClass(feedback.vertical)
                            .addClass(feedback.horizontal)
                            .appendTo(this);
                    }
                }
            });
            console.log('✅ Tooltips inicializados');
        } else {
            console.warn('⚠️ jQuery UI Tooltip no disponible para inicialización');
        }
    }

    function inicializarDatepickers() {
        if (typeof $.fn.datepicker !== 'undefined') {
            $('.ac-datepicker').datepicker({
                dateFormat: 'yy-mm-dd',
                changeMonth: true,
                changeYear: true,
                yearRange: '-100:+0',
                showButtonPanel: true,
                beforeShow: function(input, inst) {
                    setTimeout(function() {
                        inst.dpDiv.css({
                            'z-index': 999999,
                            'font-size': '13px'
                        });
                    }, 0);
                }
            });
            console.log('✅ Datepickers inicializados');
        }
    }

    function inicializarTabs() {
        $('.ac-tabs').each(function() {
            var $tabs = $(this);
            $tabs.find('.ac-tab-content').hide().first().show();
            $tabs.find('.ac-tab-nav li:first').addClass('active');
            
            $tabs.find('.ac-tab-nav a').on('click', function(e) {
                e.preventDefault();
                var $tab = $(this);
                var target = $tab.attr('href');
                
                $tabs.find('.ac-tab-nav li').removeClass('active');
                $tab.closest('li').addClass('active');
                
                $tabs.find('.ac-tab-content').hide();
                $(target).show();
                
                // Disparar evento personalizado
                $(document).trigger('ac_tab_cambiado', [target, $tab]);
            });
        });
        console.log('✅ Sistema de pestañas inicializado');
    }

    function inicializarAutocomplete() {
        if (typeof $.fn.autocomplete !== 'undefined') {
            $('.ac-autocomplete').each(function() {
                var $field = $(this);
                var source = $field.data('source') || [];
                
                if (source.length > 0 || $field.data('ajax-url')) {
                    var options = {
                        minLength: 2,
                        delay: 300
                    };
                    
                    if ($field.data('ajax-url')) {
                        options.source = function(request, response) {
                            $.get(ac_config.ajaxurl, {
                                action: $field.data('ajax-action'),
                                term: request.term,
                                nonce: ac_config.nonce
                            }, function(data) {
                                response(data);
                            });
                        };
                    } else {
                        options.source = source;
                    }
                    
                    $field.autocomplete(options);
                }
            });
            console.log('✅ Autocomplete inicializado');
        }
    }

    // =============================================
    // MANEJADORES DE EVENTOS MEJORADOS
    // =============================================

    function inicializarEventos() {
        // Confirmación para eliminar
        $(document).on('click', '.ac-delete-btn, .button-link-delete, [data-action="delete"]', function(e) {
            var $btn = $(this);
            var mensaje = $btn.data('confirm-message') || '¿Está seguro de que desea eliminar este elemento?';
            
            if (!confirm(mensaje)) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            }
            
            // Mostrar loading si es un botón de acción
            if ($btn.is('button') || $btn.is('input[type="submit"]')) {
                toggleLoading($btn, true, 'Eliminando...');
            }
        });

        // Validación de cédula mejorada
        $(document).on('blur', '#cedula, .ac-cedula', function() {
            var $input = $(this);
            var cedula = $input.val().trim();
            
            if (cedula.length > 0) {
                if (!/^\d+$/.test(cedula)) {
                    mostrarNotificacion('La cédula debe contener solo números', 'error', 3000);
                    $input.focus().addClass('error');
                    return false;
                }
                
                if (cedula.length < 6) {
                    mostrarNotificacion('La cédula debe tener al menos 6 dígitos', 'warning', 3000);
                    $input.addClass('warning');
                    return false;
                }
                
                $input.removeClass('error warning');
            }
            return true;
        });

        // Búsqueda en tiempo real mejorada
        var searchTimers = {};
        $(document).on('keyup', 'input[name="busqueda"], .ac-search', function() {
            var $input = $(this);
            var timerId = $input.attr('id') || 'search_' + Date.now();
            
            clearTimeout(searchTimers[timerId]);
            
            searchTimers[timerId] = setTimeout(function() {
                var $form = $input.closest('form');
                var searchTerm = $input.val().trim();
                
                // Mostrar indicador de búsqueda
                if (searchTerm.length >= 2) {
                    $input.addClass('searching');
                } else {
                    $input.removeClass('searching');
                }
                
                if ($form.length && searchTerm.length >= 2) {
                    $form.submit();
                } else if (searchTerm.length === 0 && $form.length) {
                    // Si se borró la búsqueda, enviar formulario vacío
                    $form.submit();
                }
            }, 800);
        });

        // Campos condicionales mejorados
        $(document).on('change', '.ac-toggle-trigger', function() {
            var $trigger = $(this);
            var valor = $trigger.val();
            var target = $trigger.data('toggle-target') || '.ac-toggle-target';
            var $targets = $(target);
            
            $targets.hide().removeClass('ac-toggle-visible');
            $(target + '-' + valor).show().addClass('ac-toggle-visible');
            
            // Disparar evento
            $(document).trigger('ac_toggle_cambiado', [$trigger, valor, target]);
        });

        // Validación de archivos mejorada
        $(document).on('change', 'input[type="file"]', function() {
            var file = this.files[0];
            var $this = $(this);
            var maxSize = $this.data('max-size') || 10 * 1024 * 1024; // 10MB default
            var tiposPermitidos = $this.data('file-types') || '';
            
            if (file) {
                // Validar tamaño
                if (file.size > maxSize) {
                    var sizeMB = (maxSize / 1024 / 1024).toFixed(1);
                    mostrarNotificacion('El archivo excede el tamaño máximo permitido (' + sizeMB + 'MB)', 'error', 4000);
                    $this.val('');
                    return false;
                }
                
                // Validar tipo de archivo
                if (tiposPermitidos) {
                    var extension = file.name.split('.').pop().toLowerCase();
                    var tiposArray = tiposPermitidos.split(',').map(function(tipo) {
                        return tipo.trim().toLowerCase().replace('.', '');
                    });
                    
                    if (tiposArray.indexOf(extension) === -1) {
                        mostrarNotificacion('Tipo de archivo no permitido. Formatos aceptados: ' + tiposPermitidos, 'error', 4000);
                        $this.val('');
                        return false;
                    }
                }
                
                mostrarNotificacion('Archivo válido: ' + file.name, 'success', 2000);
            }
            return true;
        });

        // Contador de caracteres mejorado
        $('textarea[maxlength]').each(function() {
            var $textarea = $(this);
            var maxLength = parseInt($textarea.attr('maxlength'));
            var $counter = $('<div class="ac-char-counter" style="font-size: 12px; color: #666; text-align: right; margin-top: 5px;"></div>');
            
            $textarea.after($counter);
            
            function actualizarContador() {
                var length = $textarea.val().length;
                var porcentaje = (length / maxLength) * 100;
                
                $counter.text(length + '/' + maxLength + ' caracteres');
                
                if (porcentaje >= 90) {
                    $counter.css('color', '#ffb900'); // Amarillo/advertencia
                } else if (porcentaje >= 100) {
                    $counter.css('color', '#dc3232'); // Rojo/error
                } else {
                    $counter.css('color', '#666'); // Gris/normal
                }
            }
            
            $textarea.on('input', actualizarContador).trigger('input');
        });

        // Formularios AJAX mejorados
        $(document).on('submit', '.ac-ajax-form', function(e) {
            e.preventDefault();
            
            var $form = $(this);
            var $submit = $form.find('button[type="submit"]');
            var formData = new FormData($form[0]);
            
            // Agregar nonce si no está presente
            if (!formData.has('nonce') && ac_config.nonce) {
                formData.append('nonce', ac_config.nonce);
            }
            
            // Agregar acción si no está presente
            if (!formData.has('action')) {
                var action = $form.data('ajax-action') || 'ac_guardar_formulario';
                formData.append('action', action);
            }
            
            toggleLoading($submit, true, 'Guardando...');
            
            $.ajax({
                url: ac_config.ajaxurl,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log('Respuesta AJAX:', response);
                    
                    if (response.success) {
                        mostrarNotificacion(response.data.message || 'Operación exitosa', 'success', 3000);
                        
                        // Redirección
                        if (response.data.redirect) {
                            setTimeout(function() {
                                window.location.href = response.data.redirect;
                            }, 1500);
                        }
                        
                        // Recarga
                        if (response.data.reload) {
                            setTimeout(function() {
                                location.reload();
                            }, 1500);
                        }
                        
                        // Callback personalizado
                        if (response.data.callback && typeof window[response.data.callback] === 'function') {
                            window[response.data.callback](response.data);
                        }
                        
                        // Limpiar formulario si es exitoso
                        if ($form.data('clear-on-success')) {
                            $form[0].reset();
                        }
                        
                    } else {
                        var errorMsg = response.data && response.data.message ? response.data.message : 'Error en la operación';
                        mostrarNotificacion(errorMsg, 'error', 5000);
                        
                        // Mostrar errores de validación
                        if (response.data.errors) {
                            $.each(response.data.errors, function(field, error) {
                                $('[name="' + field + '"]').addClass('error')
                                                          .after('<span class="ac-field-error" style="color: #dc3232; font-size: 12px; display: block;">' + error + '</span>');
                            });
                        }
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error AJAX:', status, error, xhr.responseText);
                    var errorMsg = 'Error de conexión: ' + error;
                    
                    if (xhr.responseText) {
                        try {
                            var errorResponse = JSON.parse(xhr.responseText);
                            if (errorResponse.data && errorResponse.data.message) {
                                errorMsg = errorResponse.data.message;
                            }
                        } catch (e) {
                            // No es JSON, usar texto plano
                        }
                    }
                    
                    mostrarNotificacion(errorMsg, 'error', 5000);
                },
                complete: function() {
                    toggleLoading($submit, false);
                }
            });
        });
    }

    // =============================================
    // FUNCIONALIDADES ESPECÍFICAS DEL PLUGIN MEJORADAS
    // =============================================

    function inicializarFuncionalidadesEspecificas() {
        // Exportación de datos mejorada
        $(document).on('click', '.ac-export-btn', function(e) {
            e.preventDefault();
            
            var $btn = $(this);
            var tipo = $btn.data('export-type') || 'datos';
            var formato = $btn.data('export-format') || 'csv';
            var filtros = $btn.data('export-filters') || {};
            
            if (confirm('¿Exportar ' + tipo + ' en formato ' + formato.toUpperCase() + '?')) {
                toggleLoading($btn, true, 'Exportando...');
                
                var datosExportacion = {
                    action: 'ac_exportar_' + tipo,
                    formato: formato,
                    nonce: ac_config.nonce
                };
                
                // Agregar filtros
                $.extend(datosExportacion, filtros);
                
                $.post(ac_config.ajaxurl, datosExportacion, function(response) {
                    if (response.success && response.data.url) {
                        // Descargar archivo
                        var link = document.createElement('a');
                        link.href = response.data.url;
                        link.download = response.data.filename || ('exportacion-' + tipo + '.' + formato);
                        link.style.display = 'none';
                        
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                        
                        mostrarNotificacion('Exportación completada: ' + (response.data.filename || 'archivo descargado'), 'success', 3000);
                    } else {
                        var errorMsg = response.data && response.data.message ? response.data.message : 'Error en la exportación';
                        mostrarNotificacion(errorMsg, 'error');
                    }
                }).fail(function(xhr, status, error) {
                    mostrarNotificacion('Error en la exportación: ' + error, 'error');
                }).always(function() {
                    toggleLoading($btn, false);
                });
            }
        });

        // Cambio rápido de estado mejorado
        $(document).on('change', '.ac-quick-status', function() {
            var $select = $(this);
            var id = $select.data('id');
            var tipo = $select.data('type') || 'elemento';
            var nuevoEstado = $select.val();
            var estadoAnterior = $select.data('previous-value') || $select.val();
            
            if (!id) {
                console.error('ID no definido para cambio de estado');
                return;
            }
            
            toggleLoading($select, true);
            
            $.post(ac_config.ajaxurl, {
                action: 'ac_cambiar_estado',
                tipo: tipo,
                id: id,
                estado: nuevoEstado,
                nonce: ac_config.nonce
            }, function(response) {
                if (response.success) {
                    $select.data('previous-value', nuevoEstado);
                    mostrarNotificacion('Estado actualizado correctamente', 'success', 2000);
                    
                    // Actualizar interfaz si es necesario
                    if (response.data.update_ui) {
                        $select.closest('tr').find('.estado-badge')
                             .removeClass().addClass('estado-badge estado-' + nuevoEstado)
                             .text(response.data.estado_texto || nuevoEstado);
                    }
                } else {
                    $select.val(estadoAnterior);
                    var errorMsg = response.data && response.data.message ? response.data.message : 'Error al actualizar estado';
                    mostrarNotificacion(errorMsg, 'error');
                }
            }).fail(function(xhr, status, error) {
                $select.val(estadoAnterior);
                mostrarNotificacion('Error de conexión: ' + error, 'error');
            }).always(function() {
                toggleLoading($select, false);
            });
        });

        // Búsqueda de miembros/pacientes mejorada
        var busquedaTimer;
        $(document).on('keyup', '.ac-search-field', function() {
            var $field = $(this);
            var searchTerm = $field.val().trim();
            var $results = $($field.data('results-container'));
            var tipo = $field.data('search-type') || 'miembros';
            
            clearTimeout(busquedaTimer);
            
            if (searchTerm.length < 2) {
                $results.empty().hide();
                return;
            }
            
            $field.addClass('searching');
            
            busquedaTimer = setTimeout(function() {
                $.post(ac_config.ajaxurl, {
                    action: 'ac_buscar_' + tipo,
                    term: searchTerm,
                    nonce: ac_config.nonce
                }, function(response) {
                    $field.removeClass('searching');
                    
                    if (response.success) {
                        $results.html(response.data.html || '').show();
                        
                        // Evento para selección de resultados
                        $results.find('.ac-search-result').on('click', function() {
                            var $result = $(this);
                            var id = $result.data('id');
                            var texto = $result.data('texto') || $result.text();
                            
                            $field.val(texto).data('selected-id', id);
                            $results.hide();
                            
                            // Disparar evento de selección
                            $(document).trigger('ac_search_seleccionado', [tipo, id, texto, $field]);
                        });
                    }
                }).fail(function() {
                    $field.removeClass('searching');
                    $results.html('<div class="ac-search-error">Error en la búsqueda</div>').show();
                });
            }, 500);
        });

        // Cerrar resultados al hacer clic fuera
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.ac-search-field, .ac-search-results').length) {
                $('.ac-search-results').hide();
            }
        });
    }

    // =============================================
    // SISTEMA DE SINCRONIZACIÓN MEJORADO
    // =============================================

    function inicializarSincronizacion() {
        // Sincronización de actas
        $(document).on('click', '#sincronizar-actas, .ac-sync-btn', function() {
            var $btn = $(this);
            var tipo = $btn.data('sync-type') || 'actas';
            
            toggleLoading($btn, true, 'Sincronizando...');
            
            $.post(ac_config.ajaxurl, {
                action: 'ac_sincronizar_' + tipo,
                nonce: ac_config.nonce
            }, function(response) {
                if (response.success) {
                    mostrarNotificacion(response.data.message || 'Sincronización completada', 'success', 4000);
                    
                    // Mostrar resultados detallados
                    if (response.data.detalles) {
                        console.log('Detalles de sincronización:', response.data.detalles);
                    }
                    
                    // Recargar si es necesario
                    if (response.data.reload) {
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    }
                } else {
                    var errorMsg = response.data && response.data.message ? response.data.message : 'Error en la sincronización';
                    mostrarNotificacion(errorMsg, 'error', 5000);
                }
            }).fail(function(xhr, status, error) {
                mostrarNotificacion('Error de conexión en sincronización: ' + error, 'error');
            }).always(function() {
                toggleLoading($btn, false);
            });
        });
    }

    // =============================================
    // INICIALIZACIÓN PRINCIPAL MEJORADA
    // =============================================

    function inicializar() {
        console.log('🚀 Inicializando Asociación Civil Admin...');
        
        // Verificar dependencias primero
        var dependenciasOk = verificarDependencias();
        
        if (!dependenciasOk) {
            console.warn('⚠️ Inicializando con dependencias faltantes - algunas funciones pueden no estar disponibles');
            mostrarNotificacion('Algunas funciones pueden estar limitadas debido a dependencias faltantes', 'warning', 8000);
        }
        
        // Inicializar componentes UI (con retardo para dependencias dinámicas)
        setTimeout(function() {
            inicializarTooltips();
            inicializarDatepickers();
            inicializarTabs();
            inicializarAutocomplete();
        }, 100);
        
        // Inicializar eventos y funcionalidades
        inicializarEventos();
        inicializarFuncionalidadesEspecificas();
        inicializarSincronizacion();
        
        console.log('✅ Asociación Civil Admin inicializado correctamente');
        
        // Disparar evento de inicialización completada
        $(document).trigger('ac_admin_inicializado');
    }

    // =============================================
    // API PÚBLICA PARA USO EXTERNO
    // =============================================

    window.AC_Admin = {
        // Configuración
        config: ac_config,
        
        // Utilidades
        mostrarNotificacion: mostrarNotificacion,
        toggleLoading: toggleLoading,
        
        // Funciones de formulario
        enviarFormulario: function($form, callback) {
            $form.trigger('submit');
            if (typeof callback === 'function') {
                $(document).on('ac_form_completado', callback);
            }
        },
        
        // Búsqueda
        buscar: function(termino, tipo, callback) {
            $.post(ac_config.ajaxurl, {
                action: 'ac_buscar_' + tipo,
                term: termino,
                nonce: ac_config.nonce
            }, callback);
        },
        
        // Exportación
        exportar: function(tipo, formato, filtros, callback) {
            var datos = {
                action: 'ac_exportar_' + tipo,
                formato: formato,
                nonce: ac_config.nonce
            };
            
            if (filtros) {
                $.extend(datos, filtros);
            }
            
            $.post(ac_config.ajaxurl, datos, callback);
        },
        
        // Sincronización
        sincronizar: function(tipo, callback) {
            $.post(ac_config.ajaxurl, {
                action: 'ac_sincronizar_' + tipo,
                nonce: ac_config.nonce
            }, callback);
        },
        
        // Reinicialización
        reinicializar: function() {
            console.log('🔄 Reinicializando Asociación Civil Admin...');
            inicializar();
        }
    };

    // =============================================
    // EVENTOS GLOBALES Y MANEJO DE ERRORES
    // =============================================

    // Manejo de errores global
    $(document).ajaxError(function(event, xhr, settings, error) {
        console.error('Error AJAX global:', error, settings);
        
        // Solo mostrar notificación para errores que no sean de autenticación
        if (xhr.status !== 403 && xhr.status !== 401) {
            mostrarNotificacion('Error de conexión en ' + settings.url, 'error', 4000);
        }
    });

    // Inicialización cuando el DOM está listo
    $(document).ready(function() {
        // Pequeño delay para asegurar que todo esté cargado
        setTimeout(inicializar, 50);
    });

});