<?php

namespace AsociacionCivil;

// Incluir la clase del Sistema Integral de Gestión
require_once ASOCIACION_CIVIL_PLUGIN_PATH . 'includes/classes/class-ac-sistema-integral.php';

class Admin {
    
    private $sistema_integral;
    
    public function __construct() {
        // Solo registrar el menú una vez
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_menu', array($this, 'remove_duplicate_submenu'), 999);
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('admin_post_guardar_configuracion_asociacion', array($this, 'guardar_configuracion_handler'));
        
        add_action('wp_ajax_limpiar_cache_asociacion', array($this, 'limpiar_cache_asociacion'));
        add_action('wp_ajax_verificar_bd_asociacion', array($this, 'verificar_bd_asociacion'));
        add_action('admin_post_exportar_datos_completos', array($this, 'exportar_datos_completos'));
        
        // Agregar estilos para los iconos del menú
        add_action('admin_head', array($this, 'add_menu_icons_styles'));
        
        // Inicializar el Sistema Integral
        $this->sistema_integral = AC_Sistema_Integral::get_instance();
        
        // Debug opcional
        if (isset($_GET['debug_menu']) && current_user_can('manage_options')) {
            add_action('admin_init', array($this, 'debug_menu_structure'));
        }
    }
    
    public function add_menu_icons_styles() {
        echo '<style>
        /* Icono para el menú principal de Asociación Civil */
        #adminmenu .toplevel_page_asociacion-civil div.wp-menu-image::before {
            content: "🏛️";
            font-family: Arial, sans-serif;
        }
        
        #adminmenu .wp-submenu li a[href*="page=asociacion-civil-dashboard"]::before {
            content: "\\f226";
            font-family: dashicons;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }
        
        #adminmenu .wp-submenu li a[href*="page=ac-miembros"]::before {
            content: "\\f307";
            font-family: dashicons;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }
        
        #adminmenu .wp-submenu li a[href*="page=ac-pacientes"]::before {
            content: "\\f484";
            font-family: dashicons;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }
        
        #adminmenu .wp-submenu li a[href*="page=ac-historial-medico"]::before {
            content: "\\f481";
            font-family: dashicons;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }
        
        #adminmenu .wp-submenu li a[href*="page=ac-seguimiento-terapeutico"]::before {
            content: "\\f185";
            font-family: dashicons;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }
        
        #adminmenu .wp-submenu li a[href*="page=ac-sesiones-psicologicas"]::before {
            content: "\\f328";
            font-family: dashicons;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }
        
        #adminmenu .wp-submenu li a[href*="page=ac-psicodramas"]::before {
            content: "\\f325";
            font-family: dashicons;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }
        
        #adminmenu .wp-submenu li a[href*="page=ac-dinamicas"]::before {
            content: "\\f509";
            font-family: dashicons;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }
        
        #adminmenu .wp-submenu li a[href*="page=ac-camaras-seguridad"]::before {
            content: "\\f211";
            font-family: dashicons;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }
        
        #adminmenu .wp-submenu li a[href*="page=ac-eventos"]::before {
            content: "\\f145";
            font-family: dashicons;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }
        
        #adminmenu .wp-submenu li a[href*="page=ac-documentos"]::before {
            content: "\\f123";
            font-family: dashicons;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }
        
        #adminmenu .wp-submenu li a[href*="page=ac-notas-judiciales"]::before {
            content: "\\f331";
            font-family: dashicons;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }
        
        #adminmenu .wp-submenu li a[href*="page=ac-configuracion"]::before {
            content: "\\f108";
            font-family: dashicons;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }
        
        /* NUEVOS ICONOS PARA LOS SUBMENÚS AGREGADOS */
        #adminmenu .wp-submenu li a[href*="page=ac-solo-por-hoy"]::before {
            content: "\\f310";
            font-family: dashicons;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }
        
        #adminmenu .wp-submenu li a[href*="page=ac-reuniones"]::before {
            content: "\\f338";
            font-family: dashicons;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }
        
        #adminmenu .wp-submenu li a[href*="page=ac-chat-operadores"]::before {
            content: "\\f125";
            font-family: dashicons;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }
        
        /* NUEVO ICONO PARA TIEMPO LIMPIO */
        #adminmenu .wp-submenu li a[href*="page=ac-tiempo-limpio"]::before {
            content: "⏳";
            font-family: Arial, sans-serif;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }

        /* ICONO PARA SISTEMA INTEGRAL */
        #adminmenu .wp-submenu li a[href*="page=ac-sistema-integral"]::before {
            content: "📊";
            font-family: Arial, sans-serif;
            margin-right: 5px;
            font-size: 16px;
            vertical-align: middle;
        }
        </style>';
    }
    
    public function debug_menu_structure() {
        global $menu, $submenu;
        echo '<div class="notice notice-info">';
        echo '<h3>🔧 Debug Menú Asociación Civil</h3>';
        echo '<pre>';
        echo "=== MENÚ PRINCIPAL ===\n";
        foreach ($menu as $item) {
            if (isset($item[2])) {
                echo "{$item[0]} → {$item[2]}\n";
            }
        }
        echo "\n=== SUBMENÚ ASOCIACIÓN CIVIL ===\n";
        if (isset($submenu['asociacion-civil'])) {
            foreach ($submenu['asociacion-civil'] as $subitem) {
                echo "{$subitem[0]} → {$subitem[2]}\n";
            }
        } else {
            echo "No hay submenús\n";
        }
        echo '</pre>';
        echo '</div>';
    }
    
    public function add_admin_menu() {
        // MENÚ PRINCIPAL - Siempre registrar, WordPress maneja duplicados
        add_menu_page(
            'Gestión Asociación Civil',
            '🏛️ Asociación Civil',
            'read',
            'asociacion-civil',
            array($this, 'dashboard_page'),
            'dashicons-building',
            30
        );

        // SUBMENÚS - Con iconos en los títulos
        $submenus = array(
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Dashboard',
                'menu_title' => '📊 Dashboard',
                'capability' => 'read',
                'menu_slug' => 'asociacion-civil-dashboard',
                'function' => array($this, 'dashboard_page')
            ),
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Gestión de Miembros',
                'menu_title' => '👥 Miembros',
                'capability' => 'read',
                'menu_slug' => 'ac-miembros',
                'function' => array($this, 'miembros_page')
            ),
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Gestión de Pacientes',
                'menu_title' => '👤 Pacientes',
                'capability' => 'read',
                'menu_slug' => 'ac-pacientes',
                'function' => array($this, 'pacientes_page')
            ),
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Historial Médico',
                'menu_title' => '🏥 Historial Médico',
                'capability' => 'read',
                'menu_slug' => 'ac-historial-medico',
                'function' => array($this, 'historial_medico_page')
            ),
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Seguimiento Terapéutico',
                'menu_title' => '📈 Seguimiento Terapéutico',
                'capability' => 'read',
                'menu_slug' => 'ac-seguimiento-terapeutico',
                'function' => array($this, 'seguimiento_terapeutico_page')
            ),
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Sesiones Psicológicas',
                'menu_title' => '💬 Sesiones Psicológicas',
                'capability' => 'read',
                'menu_slug' => 'ac-sesiones-psicologicas',
                'function' => array($this, 'sesiones_psicologicas_page')
            ),
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Psicodramas',
                'menu_title' => '🎭 Psicodramas',
                'capability' => 'read',
                'menu_slug' => 'ac-psicodramas',
                'function' => array($this, 'psicodramas_page')
            ),
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Dinámicas Grupales',
                'menu_title' => '🔄 Dinámicas Grupales',
                'capability' => 'read',
                'menu_slug' => 'ac-dinamicas',
                'function' => array($this, 'dinamicas_page')
            ),
            // NUEVOS SUBMENÚS AGREGADOS
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Solo por Hoy',
                'menu_title' => '📝 Solo por Hoy',
                'capability' => 'read',
                'menu_slug' => 'ac-solo-por-hoy',
                'function' => array($this, 'solo_por_hoy_page')
            ),
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Reuniones',
                'menu_title' => '🤝 Reuniones',
                'capability' => 'read',
                'menu_slug' => 'ac-reuniones',
                'function' => array($this, 'reuniones_page')
            ),
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Chat de Operadores',
                'menu_title' => '💬 Chat de Operadores',
                'capability' => 'read',
                'menu_slug' => 'ac-chat-operadores',
                'function' => array($this, 'chat_operadores_page')
            ),
            // NUEVO SUBMENÚ TIEMPO LIMPIO
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Tiempo Limpio',
                'menu_title' => '⏳ Tiempo Limpio',
                'capability' => 'read',
                'menu_slug' => 'ac-tiempo-limpio',
                'function' => array($this, 'tiempo_limpio_page')
            ),
            // SISTEMA INTEGRAL DE GESTIÓN
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Sistema Integral de Gestión',
                'menu_title' => '📊 Sistema Integral',
                'capability' => 'read',
                'menu_slug' => 'ac-sistema-integral',
                'function' => array($this, 'sistema_integral_page')
            ),
            // FIN NUEVOS SUBMENÚS
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Cámaras de Seguridad',
                'menu_title' => '📹 Cámaras de Seguridad',
                'capability' => 'read',
                'menu_slug' => 'ac-camaras-seguridad',
                'function' => array($this, 'camaras_seguridad_page')
            ),
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Eventos y Asambleas',
                'menu_title' => '📅 Eventos',
                'capability' => 'read',
                'menu_slug' => 'ac-eventos',
                'function' => array($this, 'eventos_page')
            ),
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Documentos',
                'menu_title' => '📄 Documentos',
                'capability' => 'read',
                'menu_slug' => 'ac-documentos',
                'function' => array($this, 'documentos_page')
            ),
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Notas Judiciales',
                'menu_title' => '⚖️ Notas Judiciales',
                'capability' => 'read',
                'menu_slug' => 'ac-notas-judiciales',
                'function' => array($this, 'notas_judiciales_page')
            ),
            array(
                'parent' => 'asociacion-civil',
                'page_title' => 'Configuración',
                'menu_title' => '⚙️ Configuración',
                'capability' => 'manage_options',
                'menu_slug' => 'ac-configuracion',
                'function' => array($this, 'configuracion_page')
            )
        );
        
        // Registrar todos los submenús
        foreach ($submenus as $submenu_item) {
            add_submenu_page(
                $submenu_item['parent'],
                $submenu_item['page_title'],
                $submenu_item['menu_title'],
                $submenu_item['capability'],
                $submenu_item['menu_slug'],
                $submenu_item['function']
            );
        }
    }
    
    public function remove_duplicate_submenu() {
        global $submenu;
        
        if (isset($submenu['asociacion-civil'])) {
            // Buscar y eliminar el duplicado del Dashboard
            foreach ($submenu['asociacion-civil'] as $key => $item) {
                if ($item[2] === 'asociacion-civil-dashboard') {
                    unset($submenu['asociacion-civil'][$key]);
                    break;
                }
            }
            
            // Reindexar el array
            $submenu['asociacion-civil'] = array_values($submenu['asociacion-civil']);
        }
    }
    
    public function enqueue_admin_scripts($hook) {
        $plugin_pages = array(
            'toplevel_page_asociacion-civil',
            'asociacion-civil_page_ac-miembros',
            'asociacion-civil_page_ac-pacientes',
            'asociacion-civil_page_ac-historial-medico',
            'asociacion-civil_page_ac-seguimiento-terapeutico',
            'asociacion-civil_page_ac-sesiones-psicologicas',
            'asociacion-civil_page_ac-psicodramas',
            'asociacion-civil_page_ac-dinamicas',
            // NUEVAS PÁGINAS AGREGADAS
            'asociacion-civil_page_ac-solo-por-hoy',
            'asociacion-civil_page_ac-reuniones',
            'asociacion-civil_page_ac-chat-operadores',
            'asociacion-civil_page_ac-tiempo-limpio',
            'asociacion-civil_page_ac-sistema-integral',
            // FIN NUEVAS PÁGINAS
            'asociacion-civil_page_ac-camaras-seguridad',
            'asociacion-civil_page_ac-eventos',
            'asociacion-civil_page_ac-documentos',
            'asociacion-civil_page_ac-notas-judiciales',
            'asociacion-civil_page_ac-configuracion'
        );
        
        if (in_array($hook, $plugin_pages) || strpos($hook, 'asociacion-civil') !== false) {
            wp_enqueue_style('asociacion-civil-admin', 
                ASOCIACION_CIVIL_PLUGIN_URL . 'assets/admin.css', 
                array(), 
                ASOCIACION_CIVIL_PLUGIN_VERSION
            );
            
            wp_enqueue_script('asociacion-civil-admin', 
                ASOCIACION_CIVIL_PLUGIN_URL . 'assets/admin.js', 
                array('jquery'), 
                ASOCIACION_CIVIL_PLUGIN_VERSION, 
                true
            );
            
            wp_enqueue_script('jquery-ui-datepicker');
            wp_enqueue_style('jquery-ui-css', 
                'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css'
            );
            
            // Estilos específicos para el Sistema Integral
            if ($hook === 'asociacion-civil_page_ac-sistema-integral') {
                // Agregar animaciones para spinner
                wp_add_inline_style('asociacion-civil-admin', '
                    @keyframes spin {
                        0% { transform: rotate(0deg); }
                        100% { transform: rotate(360deg); }
                    }
                    
                    @keyframes pulse {
                        0% { opacity: 1; }
                        50% { opacity: 0.7; }
                        100% { opacity: 1; }
                    }
                ');
            }
            
            wp_localize_script('asociacion-civil-admin', 'ac_admin', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('ac_admin_nonce'),
                'textos' => array(
                    'confirmar_eliminar' => '¿Está seguro de que desea eliminar este elemento?',
                    'error' => 'Error',
                    'exito' => 'Éxito'
                )
            ));
        }
    }

    // =================================================================
    // MÉTODO PARA SISTEMA INTEGRAL DE GESTIÓN - ACTUALIZADO
    // =================================================================
    
    /**
     * Página para el Sistema Integral de Gestión
     */
    public function sistema_integral_page() {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die(
                '<div style="text-align: center; padding: 50px; font-family: Arial, sans-serif;">
                    <h1 style="color: #dc3232;">❌ Acceso Denegado</h1>
                    <p>No tienes permisos para acceder al Sistema Integral de Gestión.</p>
                    <p>Contacta al administrador del sitio para solicitar acceso.</p>
                    <p><a href="' . admin_url() . '" class="button">Volver al Inicio</a></p>
                </div>'
            );
        }
        
        // Obtener parámetros
        $modo_actual = isset($_GET['modo']) ? sanitize_text_field($_GET['modo']) : 'planificador';
        $submodo_actual = isset($_GET['submodo']) ? sanitize_text_field($_GET['submodo']) : '';
        
        // Cargar el template del sistema integral
        $sistema_integral_path = ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/sistema-integral.php';
        
        if (file_exists($sistema_integral_path)) {
            // Pasar los datos a la vista
            $datos_horario = $this->sistema_integral->obtener_estado_horario();
            $actividad_actual = $this->sistema_integral->obtener_actividad_actual($datos_horario);
            $proximas_actividades = $this->sistema_integral->obtener_proximas_actividades($datos_horario, 3);
            $progreso_dia = $this->sistema_integral->calcular_progreso_dia($datos_horario);
            $dias_semana = $this->sistema_integral->obtener_dias_semana();
            
            // Obtener el rango actual
            $rango_actual = isset($_GET['rango']) ? sanitize_text_field($_GET['rango']) : 'semana';
            $estadisticas = $this->sistema_integral->obtener_estadisticas_cumplimiento($rango_actual);
            $actividades_faltantes = $this->sistema_integral->obtener_actividades_faltantes();
            
            // Incluir el template con todos los datos
            include $sistema_integral_path;
        } else {
            // Si no existe el template, crear uno básico
            echo '<div class="wrap">';
            echo '<h1><span class="dashicons dashicons-chart-bar"></span> 📊 Sistema Integral de Gestión</h1>';
            echo '<div class="notice notice-warning">';
            echo '<p>El template del sistema integral no está disponible. Creando vista básica...</p>';
            echo '</div>';
            
            // Mostrar estadísticas básicas
            try {
                if (class_exists('AsociacionCivil\Database')) {
                    $database = new Database();
                    $estadisticas = $database->get_estadisticas();
                    
                    echo '<div class="ac-dashboard-stats">';
                    echo '<h2>📈 Estadísticas Generales del Sistema</h2>';
                    echo '<div class="ac-stats-grid">';
                    
                    // Mostrar las estadísticas disponibles
                    if (isset($estadisticas['total_miembros'])) {
                        echo '<div class="ac-stat-card">';
                        echo '<h3>👥 Miembros</h3>';
                        echo '<div class="ac-stat-number">' . esc_html($estadisticas['total_miembros']) . '</div>';
                        echo '</div>';
                    }
                    
                    if (isset($estadisticas['total_pacientes'])) {
                        echo '<div class="ac-stat-card">';
                        echo '<h3>👤 Pacientes</h3>';
                        echo '<div class="ac-stat-number">' . esc_html($estadisticas['total_pacientes']) . '</div>';
                        echo '</div>';
                    }
                    
                    if (isset($estadisticas['total_eventos'])) {
                        echo '<div class="ac-stat-card">';
                        echo '<h3>📅 Eventos</h3>';
                        echo '<div class="ac-stat-number">' . esc_html($estadisticas['total_eventos']) . '</div>';
                        echo '</div>';
                    }
                    
                    if (isset($estadisticas['total_psicodramas'])) {
                        echo '<div class="ac-stat-card">';
                        echo '<h3>🎭 Psicodramas</h3>';
                        echo '<div class="ac-stat-number">' . esc_html($estadisticas['total_psicodramas']) . '</div>';
                        echo '</div>';
                    }
                    
                    echo '</div>'; // Cierre de ac-stats-grid
                    
                    // Enlaces rápidos
                    echo '<div class="ac-quick-links">';
                    echo '<h3>🔗 Accesos Rápidos</h3>';
                    echo '<div class="ac-links-grid">';
                    
                    echo '<a href="' . admin_url('admin.php?page=ac-miembros') . '" class="ac-quick-link">';
                    echo '<span class="dashicons dashicons-groups"></span>';
                    echo '<span>Gestión de Miembros</span>';
                    echo '</a>';
                    
                    echo '<a href="' . admin_url('admin.php?page=ac-pacientes') . '" class="ac-quick-link">';
                    echo '<span class="dashicons dashicons-admin-users"></span>';
                    echo '<span>Gestión de Pacientes</span>';
                    echo '</a>';
                    
                    echo '<a href="' . admin_url('admin.php?page=ac-eventos') . '" class="ac-quick-link">';
                    echo '<span class="dashicons dashicons-calendar-alt"></span>';
                    echo '<span>Calendario de Eventos</span>';
                    echo '</a>';
                    
                    echo '<a href="' . admin_url('admin.php?page=ac-documentos') . '" class="ac-quick-link">';
                    echo '<span class="dashicons dashicons-media-document"></span>';
                    echo '<span>Documentos</span>';
                    echo '</a>';
                    
                    echo '</div>'; // Cierre de ac-links-grid
                    echo '</div>'; // Cierre de ac-quick-links
                    
                    echo '</div>'; // Cierre de ac-dashboard-stats
                } else {
                    echo '<div class="notice notice-error">';
                    echo '<p>No se pudo cargar la clase Database. Verifica que esté disponible.</p>';
                    echo '</div>';
                }
            } catch (Exception $e) {
                echo '<div class="notice notice-error">';
                echo '<p>Error al cargar las estadísticas: ' . esc_html($e->getMessage()) . '</p>';
                echo '</div>';
            }
            
            echo '<div class="ac-info-box">';
            echo '<h3>⚠️ Información Importante</h3>';
            echo '<p>Para una experiencia completa del Sistema Integral de Gestión, crea el archivo <code>sistema-integral.php</code> en:</p>';
            echo '<code>' . esc_html(ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/sistema-integral.php') . '</code>';
            echo '</div>';
            
            echo '</div>'; // Cierre de wrap
        }
    }

    // =================================================================
    // MÉTODOS PARA LOS NUEVOS SUBMENÚS
    // =================================================================
    
    public function solo_por_hoy_page() {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
        $id = isset($_GET['id']) ? intval($_GET['id']) : null;
        
        switch ($action) {
            case 'nuevo':
                $this->formulario_solo_por_hoy();
                break;
            case 'editar':
                $this->formulario_solo_por_hoy($id);
                break;
            case 'eliminar':
                $this->eliminar_solo_por_hoy($id);
                break;
            case 'ver':
                $this->ver_solo_por_hoy($id);
                break;
            default:
                $this->listar_solo_por_hoy();
                break;
        }
    }
    
    private function listar_solo_por_hoy() {
        echo '<div class="wrap">';
        echo '<h1>📝 Solo por Hoy</h1>';
        echo '<div class="notice notice-info">';
        echo '<p>Esta sección está dedicada al programa "Solo por Hoy" donde se gestionan las reflexiones diarias, metas del día y seguimiento personal.</p>';
        echo '<p><strong>Próximamente:</strong> Podrás gestionar reflexiones diarias, establecer metas y hacer seguimiento del progreso personal.</p>';
        echo '</div>';
        echo '</div>';
    }
    
    private function formulario_solo_por_hoy($id = null) {
        echo '<div class="wrap">';
        echo '<h1>' . ($id ? 'Editar' : 'Nueva') . ' Entrada - Solo por Hoy</h1>';
        echo '<div class="notice notice-warning"><p>Formulario en desarrollo.</p></div>';
        echo '</div>';
    }
    
    private function eliminar_solo_por_hoy($id) {
        if (!wp_verify_nonce($_GET['_wpnonce'], 'eliminar_solo_por_hoy_' . $id)) {
            echo '<div class="notice notice-error"><p>Error de seguridad.</p></div>';
            return;
        }
        
        echo '<div class="notice notice-info"><p>Funcionalidad de eliminar en desarrollo.</p></div>';
        wp_redirect(admin_url('admin.php?page=ac-solo-por-hoy'));
        exit;
    }
    
    private function ver_solo_por_hoy($id) {
        echo '<div class="wrap">';
        echo '<h1>Ver Entrada - Solo por Hoy</h1>';
        echo '<div class="notice notice-warning"><p>Vista en desarrollo.</p></div>';
        echo '</div>';
    }
    
    public function reuniones_page() {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
        $id = isset($_GET['id']) ? intval($_GET['id']) : null;
        
        switch ($action) {
            case 'nuevo':
                $this->formulario_reunion();
                break;
            case 'editar':
                $this->formulario_reunion($id);
                break;
            case 'eliminar':
                $this->eliminar_reunion($id);
                break;
            case 'ver':
                $this->ver_reunion($id);
                break;
            default:
                $this->listar_reuniones();
                break;
        }
    }
    
    private function listar_reuniones() {
        echo '<div class="wrap">';
        echo '<h1>🤝 Reuniones</h1>';
        echo '<div class="notice notice-info">';
        echo '<p>Esta sección está dedicada a la gestión de reuniones de la asociación.</p>';
        echo '<p><strong>Próximamente:</strong> Podrás programar reuniones, gestionar asistentes y registrar acuerdos.</p>';
        echo '</div>';
        echo '</div>';
    }
    
    private function formulario_reunion($id = null) {
        echo '<div class="wrap">';
        echo '<h1>' . ($id ? 'Editar' : 'Nueva') . ' Reunión</h1>';
        echo '<div class="notice notice-warning"><p>Formulario de reunión en desarrollo.</p></div>';
        echo '</div>';
    }
    
    private function eliminar_reunion($id) {
        if (!wp_verify_nonce($_GET['_wpnonce'], 'eliminar_reunion_' . $id)) {
            echo '<div class="notice notice-error"><p>Error de seguridad.</p></div>';
            return;
        }
        
        echo '<div class="notice notice-info"><p>Funcionalidad de eliminar reunión en desarrollo.</p></div>';
        wp_redirect(admin_url('admin.php?page=ac-reuniones'));
        exit;
    }
    
    private function ver_reunion($id) {
        echo '<div class="wrap">';
        echo '<h1>Detalles de Reunión</h1>';
        echo '<div class="notice notice-warning"><p>Vista de reunión en desarrollo.</p></div>';
        echo '</div>';
    }
    
    public function chat_operadores_page() {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
        $id = isset($_GET['id']) ? intval($_GET['id']) : null;
        
        switch ($action) {
            case 'nuevo':
                $this->formulario_chat();
                break;
            case 'editar':
                $this->formulario_chat($id);
                break;
            case 'eliminar':
                $this->eliminar_chat($id);
                break;
            case 'ver':
                $this->ver_chat($id);
                break;
            default:
                $this->listar_chats();
                break;
        }
    }
    
    private function listar_chats() {
        echo '<div class="wrap">';
        echo '<h1>💬 Chat de Operadores</h1>';
        echo '<div class="notice notice-info">';
        echo '<p>Esta sección está dedicada al chat interno entre operadores de la asociación.</p>';
        echo '<p><strong>Próximamente:</strong> Podrás comunicarte en tiempo real con otros operadores.</p>';
        echo '</div>';
        echo '</div>';
    }
    
    private function formulario_chat($id = null) {
        echo '<div class="wrap">';
        echo '<h1>' . ($id ? 'Editar' : 'Nuevo') . ' Chat</h1>';
        echo '<div class="notice notice-warning"><p>Formulario de chat en desarrollo.</p></div>';
        echo '</div>';
    }
    
    private function eliminar_chat($id) {
        if (!wp_verify_nonce($_GET['_wpnonce'], 'eliminar_chat_' . $id)) {
            echo '<div class="notice notice-error"><p>Error de seguridad.</p></div>';
            return;
        }
        
        echo '<div class="notice notice-info"><p>Funcionalidad de eliminar chat en desarrollo.</p></div>';
        wp_redirect(admin_url('admin.php?page=ac-chat-operadores'));
        exit;
    }
    
    private function ver_chat($id) {
        echo '<div class="wrap">';
        echo '<h1>Conversación de Chat</h1>';
        echo '<div class="notice notice-warning"><p>Vista de chat en desarrollo.</p></div>';
        echo '</div>';
    }

    public function tiempo_limpio_page() {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
        $id = isset($_GET['id']) ? intval($_GET['id']) : null;
        
        switch ($action) {
            case 'nuevo':
                $this->formulario_tiempo_limpio();
                break;
            case 'editar':
                $this->formulario_tiempo_limpio($id);
                break;
            case 'eliminar':
                $this->eliminar_tiempo_limpio($id);
                break;
            case 'ver':
                $this->ver_tiempo_limpio($id);
                break;
            default:
                $this->listar_tiempo_limpio();
                break;
        }
    }
    
    private function listar_tiempo_limpio() {
        echo '<div class="wrap">';
        echo '<h1>⏳ Tiempo Limpio</h1>';
        echo '<div class="notice notice-info">';
        echo '<p>Esta sección está dedicada al seguimiento del tiempo limpio de los pacientes.</p>';
        echo '<p><strong>Próximamente:</strong> Podrás registrar y hacer seguimiento del tiempo de abstinencia.</p>';
        echo '</div>';
        echo '</div>';
    }
    
    private function formulario_tiempo_limpio($id = null) {
        echo '<div class="wrap">';
        echo '<h1>' . ($id ? 'Editar' : 'Nuevo') . ' Registro - Tiempo Limpio</h1>';
        echo '<div class="notice notice-warning"><p>Formulario de tiempo limpio en desarrollo.</p></div>';
        echo '</div>';
    }
    
    private function eliminar_tiempo_limpio($id) {
        if (!wp_verify_nonce($_GET['_wpnonce'], 'eliminar_tiempo_limpio_' . $id)) {
            echo '<div class="notice notice-error"><p>Error de seguridad.</p></div>';
            return;
        }
        
        echo '<div class="notice notice-info"><p>Funcionalidad de eliminar tiempo limpio en desarrollo.</p></div>';
        wp_redirect(admin_url('admin.php?page=ac-tiempo-limpio'));
        exit;
    }
    
    private function ver_tiempo_limpio($id) {
        echo '<div class="wrap">';
        echo '<h1>Registro de Tiempo Limpio</h1>';
        echo '<div class="notice notice-warning"><p>Vista de tiempo limpio en desarrollo.</p></div>';
        echo '</div>';
    }

    // =================================================================
    // MÉTODOS EXISTENTES (se mantienen iguales)
    // =================================================================
    
    public function dashboard_page() {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $database = new Database();
        $estadisticas = $database->get_estadisticas();
        
        include ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/dashboard.php';
    }
    
    public function miembros_page() {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
        $cedula = isset($_GET['cedula']) ? sanitize_text_field($_GET['cedula']) : null;
        
        switch ($action) {
            case 'nuevo':
                $this->formulario_miembro();
                break;
            case 'editar':
                $this->formulario_miembro($cedula);
                break;
            case 'eliminar':
                $this->eliminar_miembro($cedula);
                break;
            default:
                $this->listar_miembros();
                break;
        }
    }
    
    private function listar_miembros() {
        $database = new Database();
        $busqueda = isset($_GET['busqueda']) ? sanitize_text_field($_GET['busqueda']) : '';
        
        if (!empty($busqueda)) {
            $miembros = $database->buscar_miembros($busqueda);
        } else {
            $miembros = $database->get_miembros();
        }
        
        include ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/miembros.php';
    }
    
    private function formulario_miembro($cedula = null) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $miembro = null;
        
        if ($cedula) {
            $miembro = new Miembro($cedula);
            if (!$miembro->getCedula()) {
                echo '<div class="notice notice-error"><p>Miembro no encontrado.</p></div>';
                return;
            }
        } else {
            $miembro = new Miembro();
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->guardar_miembro($miembro);
            if (!$cedula && !empty($_POST['cedula'])) {
                $miembro = new Miembro(sanitize_text_field($_POST['cedula']));
            }
        }
        
        include ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/form-miembro.php';
    }
    
    private function guardar_miembro($miembro) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return;
        }
        
        if (!wp_verify_nonce($_POST['miembro_nonce'], 'guardar_miembro')) {
            echo '<div class="notice notice-error"><p>Error de seguridad.</p></div>';
            return;
        }
        
        if (!$miembro) {
            $miembro = new Miembro();
        }
        
        if (empty($_POST['cedula']) || !is_numeric($_POST['cedula'])) {
            echo '<div class="notice notice-error"><p>La cédula es requerida y debe ser numérica.</p></div>';
            return;
        }
        
        $miembro->setCedula($_POST['cedula']);
        $miembro->setNombre($_POST['nombre']);
        $miembro->setApellido($_POST['apellido']);
        $miembro->setEmail($_POST['email']);
        $miembro->setTelefono($_POST['telefono']);
        $miembro->setDireccion($_POST['direccion']);
        $miembro->setCargo($_POST['cargo']);
        $miembro->setFechaNacimiento($_POST['fecha_nacimiento']);
        $miembro->setFechaIngreso($_POST['fecha_ingreso']);
        $miembro->setTipoMembresia($_POST['tipo_membresia']);
        $miembro->setObservaciones($_POST['observaciones']);
        
        if ($miembro->save()) {
            echo '<div class="notice notice-success"><p>Miembro guardado correctamente.</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Error al guardar el miembro.</p></div>';
        }
    }
    
    private function eliminar_miembro($cedula) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return;
        }
        
        if (!wp_verify_nonce($_GET['_wpnonce'], 'eliminar_miembro_' . $cedula)) {
            echo '<div class="notice notice-error"><p>Error de seguridad.</p></div>';
            return;
        }
        
        $miembro = new Miembro($cedula);
        if ($miembro->eliminar()) {
            echo '<div class="notice notice-success"><p>Miembro eliminado correctamente.</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Error al eliminar el miembro.</p></div>';
        }
        
        wp_redirect(admin_url('admin.php?page=ac-miembros'));
        exit;
    }
    
    public function pacientes_page() {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
        $id = isset($_GET['id']) ? intval($_GET['id']) : null;
        
        switch ($action) {
            case 'nuevo':
                $this->formulario_paciente();
                break;
            case 'editar':
                $this->formulario_paciente($id);
                break;
            case 'eliminar':
                $this->eliminar_paciente($id);
                break;
            case 'ver':
                $this->ver_paciente($id);
                break;
            default:
                $this->listar_pacientes();
                break;
        }
    }
    
    private function listar_pacientes() {
        $database = new Database();
        $busqueda = isset($_GET['busqueda']) ? sanitize_text_field($_GET['busqueda']) : '';
        
        if (!empty($busqueda)) {
            $pacientes = $database->buscar_pacientes($busqueda);
        } else {
            $pacientes = $database->get_pacientes();
        }
        
        include ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/pacientes.php';
    }
    
    private function formulario_paciente($id = null) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $paciente = null;
        $database = new Database();
        
        if ($id) {
            $paciente = $database->get_paciente_by_id($id);
            if (!$paciente || !$paciente->getId()) {
                echo '<div class="notice notice-error"><p>Paciente no encontrado.</p></div>';
                $this->listar_pacientes();
                return;
            }
        } else {
            $paciente = new Paciente();
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_paciente'])) {
            $this->guardar_paciente($paciente);
            
            if (!$id && $paciente->getId()) {
                $paciente = $database->get_paciente_by_id($paciente->getId());
            }
        }
        
        include ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/form-paciente.php';
    }
    
    private function guardar_paciente($paciente) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return false;
        }
        
        if (!isset($_POST['paciente_nonce']) || !wp_verify_nonce($_POST['paciente_nonce'], 'guardar_paciente')) {
            echo '<div class="notice notice-error"><p>Error de seguridad. Por favor, intenta nuevamente.</p></div>';
            return false;
        }

        $campos_requeridos = array('cedula', 'nombre', 'apellido', 'fecha_ingreso');
        $campos_faltantes = array();
        
        foreach ($campos_requeridos as $campo) {
            if (empty($_POST[$campo])) {
                $campos_faltantes[] = $campo;
            }
        }
        
        if (!empty($campos_faltantes)) {
            echo '<div class="notice notice-error"><p>Error: Los campos cédula, nombre, apellido y fecha de ingreso son requeridos.</p></div>';
            return false;
        }

        $data = array(
            'cedula' => sanitize_text_field($_POST['cedula']),
            'nombre' => sanitize_text_field($_POST['nombre']),
            'apellido' => sanitize_text_field($_POST['apellido']),
            'fecha_nacimiento' => sanitize_text_field($_POST['fecha_nacimiento'] ?? ''),
            'genero' => sanitize_text_field($_POST['genero'] ?? ''),
            'telefono' => sanitize_text_field($_POST['telefono'] ?? ''),
            'email' => sanitize_email($_POST['email'] ?? ''),
            'direccion' => sanitize_textarea_field($_POST['direccion'] ?? ''),
            'contacto_emergencia_nombre' => sanitize_text_field($_POST['contacto_emergencia_nombre'] ?? ''),
            'contacto_emergencia_telefono' => sanitize_text_field($_POST['contacto_emergencia_telefono'] ?? ''),
            'contacto_emergencia_parentesco' => sanitize_text_field($_POST['contacto_emergencia_parentesco'] ?? ''),
            'historial_medico' => sanitize_textarea_field($_POST['historial_medico'] ?? ''),
            'alergias' => sanitize_textarea_field($_POST['alergias'] ?? ''),
            'medicamentos_actuales' => sanitize_textarea_field($_POST['medicamentos_actuales'] ?? ''),
            'seguro_medico' => sanitize_text_field($_POST['seguro_medico'] ?? ''),
            'numero_seguro_medico' => sanitize_text_field($_POST['numero_seguro_medico'] ?? ''),
            'estado_civil' => sanitize_text_field($_POST['estado_civil'] ?? ''),
            'ocupacion' => sanitize_text_field($_POST['ocupacion'] ?? ''),
            'nivel_educativo' => sanitize_text_field($_POST['nivel_educativo'] ?? ''),
            'referencia_por' => sanitize_text_field($_POST['referencia_por'] ?? ''),
            'motivo_consulta_principal' => sanitize_textarea_field($_POST['motivo_consulta_principal'] ?? ''),
            'expectativas_tratamiento' => sanitize_textarea_field($_POST['expectativas_tratamiento'] ?? ''),
            'fecha_ingreso' => sanitize_text_field($_POST['fecha_ingreso']),
            'estado' => sanitize_text_field($_POST['estado'] ?? 'activo'),
            'observaciones_generales' => sanitize_textarea_field($_POST['observaciones_generales'] ?? '')
        );

        $database = new Database();
        
        try {
            if ($paciente->getId()) {
                $resultado = $database->update_paciente($paciente->getId(), $data);
                
                if ($resultado && !is_wp_error($resultado)) {
                    echo '<div class="notice notice-success"><p>✅ Paciente actualizado correctamente.</p></div>';
                    return true;
                } else {
                    echo '<div class="notice notice-error"><p>❌ Error al actualizar el paciente.</p></div>';
                    return false;
                }
            } else {
                $nuevo_id = $database->insert_paciente($data);
                
                if ($nuevo_id && !is_wp_error($nuevo_id)) {
                    echo '<div class="notice notice-success"><p>✅ Paciente creado correctamente.</p></div>';
                    
                    wp_redirect(admin_url('admin.php?page=ac-pacientes&updated=true'));
                    exit;
                    
                } else {
                    echo '<div class="notice notice-error"><p>❌ Error al crear el paciente.</p></div>';
                    return false;
                }
            }
        } catch (Exception $e) {
            echo '<div class="notice notice-error"><p>❌ Error del sistema: ' . esc_html($e->getMessage()) . '</p></div>';
            return false;
        }
    }
    
    private function eliminar_paciente($id) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return;
        }
        
        if (!wp_verify_nonce($_GET['_wpnonce'], 'eliminar_paciente_' . $id)) {
            echo '<div class="notice notice-error"><p>Error de seguridad.</p></div>';
            return;
        }
        
        $database = new Database();
        $resultado = $database->delete_paciente($id);
        
        if ($resultado && !is_wp_error($resultado)) {
            echo '<div class="notice notice-success"><p>Paciente eliminado correctamente.</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Error al eliminar el paciente.</p></div>';
        }
        
        wp_redirect(admin_url('admin.php?page=ac-pacientes'));
        exit;
    }
    
    private function ver_paciente($id) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $database = new Database();
        $paciente = $database->get_paciente_by_id($id);
        
        if (!$paciente || !$paciente->getId()) {
            echo '<div class="notice notice-error"><p>Paciente no encontrado.</p></div>';
            return;
        }
        
        include ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/ver-paciente.php';
    }
    
    public function historial_medico_page() {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
        $id = isset($_GET['id']) ? intval($_GET['id']) : null;
        $paciente_id = isset($_GET['paciente_id']) ? intval($_GET['paciente_id']) : null;
        
        switch ($action) {
            case 'nuevo':
                $this->formulario_historial_medico($paciente_id);
                break;
            case 'editar':
                $this->formulario_historial_medico(null, $id);
                break;
            case 'eliminar':
                $this->eliminar_historial_medico($id);
                break;
            case 'ver':
                $this->ver_historial_medico($id);
                break;
            default:
                $this->listar_historial_medico($paciente_id);
                break;
        }
    }
    
    private function listar_historial_medico($paciente_id = null) {
        $database = new Database();
        
        if ($paciente_id) {
            $historial = $database->get_historial_medico_por_paciente($paciente_id);
            $paciente = $database->get_paciente_by_id($paciente_id);
        } else {
            $historial = $database->get_historial_medico();
            $paciente = null;
        }
        
        include ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/historial-medico.php';
    }
    
    private function formulario_historial_medico($paciente_id = null, $historial_id = null) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $historial = null;
        $database = new Database();
        $pacientes = $database->get_pacientes();
        
        if ($historial_id) {
            $historial = $database->get_historial_medico_by_id($historial_id);
            if (!$historial || !$historial->getId()) {
                echo '<div class="notice notice-error"><p>Registro de historial médico no encontrado.</p></div>';
                $this->listar_historial_medico();
                return;
            }
            $paciente_id = $historial->getPacienteId();
        } else {
            $historial = new HistorialMedico();
            if ($paciente_id) {
                $historial->setPacienteId($paciente_id);
            }
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_historial_medico'])) {
            $this->guardar_historial_medico($historial);
            
            if (!$historial_id && $historial->getId()) {
                $historial = $database->get_historial_medico_by_id($historial->getId());
            }
        }
        
        $paciente = $paciente_id ? $database->get_paciente_by_id($paciente_id) : null;
        
        include ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/form-historial-medico.php';
    }
    
    private function guardar_historial_medico($historial) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return false;
        }
        
        if (!isset($_POST['historial_medico_nonce']) || !wp_verify_nonce($_POST['historial_medico_nonce'], 'guardar_historial_medico')) {
            echo '<div class="notice notice-error"><p>Error de seguridad. Por favor, intenta nuevamente.</p></div>';
            return false;
        }

        $campos_requeridos = array('paciente_id', 'fecha_consulta', 'tipo_consulta');
        $campos_faltantes = array();
        
        foreach ($campos_requeridos as $campo) {
            if (empty($_POST[$campo])) {
                $campos_faltantes[] = $campo;
            }
        }
        
        if (!empty($campos_faltantes)) {
            echo '<div class="notice notice-error"><p>Error: Los campos paciente, fecha de consulta y tipo de consulta son requeridos.</p></div>';
            return false;
        }

        $data = array(
            'paciente_id' => intval($_POST['paciente_id']),
            'fecha_consulta' => sanitize_text_field($_POST['fecha_consulta']),
            'tipo_consulta' => sanitize_text_field($_POST['tipo_consulta']),
            'medico_tratante' => sanitize_text_field($_POST['medico_tratante'] ?? ''),
            'diagnostico' => sanitize_textarea_field($_POST['diagnostico'] ?? ''),
            'tratamiento_prescrito' => sanitize_textarea_field($_POST['tratamiento_prescrito'] ?? ''),
            'medicamentos_recetados' => sanitize_textarea_field($_POST['medicamentos_recetados'] ?? ''),
            'examenes_solicitados' => sanitize_textarea_field($_POST['examenes_solicitados'] ?? ''),
            'resultados_examenes' => sanitize_textarea_field($_POST['resultados_examenes'] ?? ''),
            'observaciones' => sanitize_textarea_field($_POST['observaciones'] ?? ''),
            'proxima_cita' => sanitize_text_field($_POST['proxima_cita'] ?? '')
        );

        $database = new Database();
        
        try {
            if ($historial->getId()) {
                $resultado = $database->update_historial_medico($historial->getId(), $data);
                
                if ($resultado && !is_wp_error($resultado)) {
                    echo '<div class="notice notice-success"><p>✅ Historial médico actualizado correctamente.</p></div>';
                    return true;
                } else {
                    echo '<div class="notice notice-error"><p>❌ Error al actualizar el historial médico.</p></div>';
                    return false;
                }
            } else {
                $nuevo_id = $database->insert_historial_medico($data);
                
                if ($nuevo_id && !is_wp_error($nuevo_id)) {
                    echo '<div class="notice notice-success"><p>✅ Historial médico creado correctamente.</p></div>';
                    
                    wp_redirect(admin_url('admin.php?page=ac-historial-medico&updated=true'));
                    exit;
                    
                } else {
                    echo '<div class="notice notice-error"><p>❌ Error al crear el historial médico.</p></div>';
                    return false;
                }
            }
        } catch (Exception $e) {
            echo '<div class="notice notice-error"><p>❌ Error del sistema: ' . esc_html($e->getMessage()) . '</p></div>';
            return false;
        }
    }
    
    private function eliminar_historial_medico($id) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return;
        }
        
        if (!wp_verify_nonce($_GET['_wpnonce'], 'eliminar_historial_medico_' . $id)) {
            echo '<div class="notice notice-error"><p>Error de seguridad.</p></div>';
            return;
        }
        
        $database = new Database();
        $resultado = $database->delete_historial_medico($id);
        
        if ($resultado && !is_wp_error($resultado)) {
            echo '<div class="notice notice-success"><p>Registro de historial médico eliminado correctamente.</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Error al eliminar el registro de historial médico.</p></div>';
        }
        
        wp_redirect(admin_url('admin.php?page=ac-historial-medico'));
        exit;
    }
    
    private function ver_historial_medico($id) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $database = new Database();
        $historial = $database->get_historial_medico_by_id($id);
        
        if (!$historial || !$historial->getId()) {
            echo '<div class="notice notice-error"><p>Registro de historial médico no encontrado.</p></div>';
            return;
        }
        
        include ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/ver-historial-medico.php';
    }
    
    public function seguimiento_terapeutico_page() {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
        $id = isset($_GET['id']) ? intval($_GET['id']) : null;
        $paciente_id = isset($_GET['paciente_id']) ? intval($_GET['paciente_id']) : null;
        
        switch ($action) {
            case 'nuevo':
                $this->formulario_seguimiento_terapeutico($paciente_id);
                break;
            case 'editar':
                $this->formulario_seguimiento_terapeutico(null, $id);
                break;
            case 'eliminar':
                $this->eliminar_seguimiento_terapeutico($id);
                break;
            case 'ver':
                $this->ver_seguimiento_terapeutico($id);
                break;
            default:
                $this->listar_seguimiento_terapeutico($paciente_id);
                break;
        }
    }
    
    private function listar_seguimiento_terapeutico($paciente_id = null) {
        $database = new Database();
        
        if ($paciente_id) {
            $seguimientos = $database->get_seguimiento_terapeutico_por_paciente($paciente_id);
            $paciente = $database->get_paciente_by_id($paciente_id);
        } else {
            $seguimientos = $database->get_seguimiento_terapeutico();
            $paciente = null;
        }
        
        $terapeutas = $database->get_miembros_por_cargo('terapeuta');
        
        include ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/seguimiento-terapeutico.php';
    }
    
    private function formulario_seguimiento_terapeutico($paciente_id = null, $seguimiento_id = null) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $seguimiento = null;
        $database = new Database();
        $pacientes = $database->get_pacientes();
        $terapeutas = $database->get_miembros_por_cargo('terapeuta');
        
        if ($seguimiento_id) {
            $seguimiento = $database->get_seguimiento_terapeutico_by_id($seguimiento_id);
            if (!$seguimiento || !$seguimiento->getId()) {
                echo '<div class="notice notice-error"><p>Registro de seguimiento terapéutico no encontrado.</p></div>';
                $this->listar_seguimiento_terapeutico();
                return;
            }
            $paciente_id = $seguimiento->getPacienteId();
        } else {
            $seguimiento = new SeguimientoTerapeutico();
            if ($paciente_id) {
                $seguimiento->setPacienteId($paciente_id);
            }
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_seguimiento_terapeutico'])) {
            $this->guardar_seguimiento_terapeutico($seguimiento);
            
            if (!$seguimiento_id && $seguimiento->getId()) {
                $seguimiento = $database->get_seguimiento_terapeutico_by_id($seguimiento->getId());
            }
        }
        
        $paciente = $paciente_id ? $database->get_paciente_by_id($paciente_id) : null;
        
        include ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/form-seguimiento-terapeutico.php';
    }
    
    private function guardar_seguimiento_terapeutico($seguimiento) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return false;
        }
        
        if (!isset($_POST['seguimiento_terapeutico_nonce']) || !wp_verify_nonce($_POST['seguimiento_terapeutico_nonce'], 'guardar_seguimiento_terapeutico')) {
            echo '<div class="notice notice-error"><p>Error de seguridad. Por favor, intenta nuevamente.</p></div>';
            return false;
        }

        $campos_requeridos = array('paciente_id', 'terapeuta_id', 'fecha_seguimiento', 'tipo_seguimiento');
        $campos_faltantes = array();
        
        foreach ($campos_requeridos as $campo) {
            if (empty($_POST[$campo])) {
                $campos_faltantes[] = $campo;
            }
        }
        
        if (!empty($campos_faltantes)) {
            echo '<div class="notice notice-error"><p>Error: Los campos paciente, terapeuta, fecha de seguimiento y tipo de seguimiento son requeridos.</p></div>';
            return false;
        }

        $data = array(
            'paciente_id' => intval($_POST['paciente_id']),
            'terapeuta_id' => intval($_POST['terapeuta_id']),
            'fecha_seguimiento' => sanitize_text_field($_POST['fecha_seguimiento']),
            'tipo_seguimiento' => sanitize_text_field($_POST['tipo_seguimiento']),
            'objetivo_tratamiento' => sanitize_textarea_field($_POST['objetivo_tratamiento'] ?? ''),
            'progreso_observado' => sanitize_textarea_field($_POST['progreso_observado'] ?? ''),
            'dificultades_identificadas' => sanitize_textarea_field($_POST['dificultades_identificadas'] ?? ''),
            'intervenciones_realizadas' => sanitize_textarea_field($_POST['intervenciones_realizadas'] ?? ''),
            'tareas_asignadas' => sanitize_textarea_field($_POST['tareas_asignadas'] ?? ''),
            'nivel_progreso' => sanitize_text_field($_POST['nivel_progreso'] ?? 'regular'),
            'observaciones_terapeuta' => sanitize_textarea_field($_POST['observaciones_terapeuta'] ?? ''),
            'proxima_sesion' => sanitize_text_field($_POST['proxima_sesion'] ?? '')
        );

        $database = new Database();
        
        try {
            if ($seguimiento->getId()) {
                $resultado = $database->update_seguimiento_terapeutico($seguimiento->getId(), $data);
                
                if ($resultado && !is_wp_error($resultado)) {
                    echo '<div class="notice notice-success"><p>✅ Seguimiento terapéutico actualizado correctamente.</p></div>';
                    return true;
                } else {
                    echo '<div class="notice notice-error"><p>❌ Error al actualizar el seguimiento terapéutico.</p></div>';
                    return false;
                }
            } else {
                $nuevo_id = $database->insert_seguimiento_terapeutico($data);
                
                if ($nuevo_id && !is_wp_error($nuevo_id)) {
                    echo '<div class="notice notice-success"><p>✅ Seguimiento terapéutico creado correctamente.</p></div>';
                    
                    wp_redirect(admin_url('admin.php?page=ac-seguimiento-terapeutico&updated=true'));
                    exit;
                    
                } else {
                    echo '<div class="notice notice-error"><p>❌ Error al crear el seguimiento terapéutico.</p></div>';
                    return false;
                }
            }
        } catch (Exception $e) {
            echo '<div class="notice notice-error"><p>❌ Error del sistema: ' . esc_html($e->getMessage()) . '</p></div>';
            return false;
        }
    }
    
    private function eliminar_seguimiento_terapeutico($id) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return;
        }
        
        if (!wp_verify_nonce($_GET['_wpnonce'], 'eliminar_seguimiento_terapeutico_' . $id)) {
            echo '<div class="notice notice-error"><p>Error de seguridad.</p></div>';
            return;
        }
        
        $database = new Database();
        $resultado = $database->delete_seguimiento_terapeutico($id);
        
        if ($resultado && !is_wp_error($resultado)) {
            echo '<div class="notice notice-success"><p>Registro de seguimiento terapéutico eliminado correctamente.</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Error al eliminar el registro de seguimiento terapéutico.</p></div>';
        }
        
        wp_redirect(admin_url('admin.php?page=ac-seguimiento-terapeutico'));
        exit;
    }
    
    private function ver_seguimiento_terapeutico($id) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $database = new Database();
        $seguimiento = $database->get_seguimiento_terapeutico_by_id($id);
        
        if (!$seguimiento || !$seguimiento->getId()) {
            echo '<div class="notice notice-error"><p>Registro de seguimiento terapéutico no encontrado.</p></div>';
            return;
        }
        
        include ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/ver-seguimiento-terapeutico.php';
    }
    
    public function sesiones_psicologicas_page() {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
        $id = isset($_GET['id']) ? intval($_GET['id']) : null;
        
        switch ($action) {
            case 'nuevo':
                $this->formulario_sesion_psicologica();
                break;
            case 'editar':
                $this->formulario_sesion_psicologica($id);
                break;
            case 'eliminar':
                $this->eliminar_sesion_psicologica($id);
                break;
            case 'ver':
                $this->ver_sesion_psicologica($id);
                break;
            default:
                $this->listar_sesiones_psicologicas();
                break;
        }
    }
    
    private function listar_sesiones_psicologicas() {
        $template_path = ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/sesiones-psicologicas.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<div class="notice notice-error"><p>Error: No se pudo cargar la página de sesiones psicológicas.</p></div>';
        }
    }
    
    private function formulario_sesion_psicologica($id = null) {
        $template_path = ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/sesiones-psicologicas.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<div class="notice notice-error"><p>Error: No se pudo cargar el formulario de sesión psicológica.</p></div>';
        }
    }
    
    private function eliminar_sesion_psicologica($id) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return;
        }
        
        if (!wp_verify_nonce($_GET['_wpnonce'], 'eliminar_sesion_' . $id)) {
            echo '<div class="notice notice-error"><p>Error de seguridad.</p></div>';
            return;
        }
        
        echo '<div class="notice notice-info"><p>Funcionalidad de eliminar sesión psicológica en desarrollo.</p></div>';
        
        wp_redirect(admin_url('admin.php?page=ac-sesiones-psicologicas'));
        exit;
    }
    
    private function ver_sesion_psicologica($id) {
        $template_path = ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/sesiones-psicologicas.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<div class="notice notice-error"><p>Error: No se pudo cargar la vista de sesión psicológica.</p></div>';
        }
    }
    
    public function psicodramas_page() {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
        $id = isset($_GET['id']) ? intval($_GET['id']) : null;
        
        switch ($action) {
            case 'nuevo':
                $this->formulario_psicodrama();
                break;
            case 'editar':
                $this->formulario_psicodrama($id);
                break;
            case 'eliminar':
                $this->eliminar_psicodrama($id);
                break;
            case 'ver':
                $this->ver_psicodrama($id);
                break;
            default:
                $this->listar_psicodramas();
                break;
        }
    }
    
    private function listar_psicodramas() {
        $database = new Database();
        $psicodramas = $database->get_psicodramas();
        $facilitadores = $database->get_miembros();
        
        $template_path = ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/psicodramas.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<div class="notice notice-error"><p>Error: No se pudo cargar la página de psicodramas.</p></div>';
        }
    }
    
    private function formulario_psicodrama($id = null) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $database = new Database();
        $psicodrama = null;
        $facilitadores = $database->get_miembros();
        $miembros = $database->get_miembros();
        
        if ($id) {
            $psicodrama = $database->get_psicodrama_by_id($id);
            if (!$psicodrama || !$psicodrama->getId()) {
                echo '<div class="notice notice-error"><p>Psicodrama no encontrado.</p></div>';
                $this->listar_psicodramas();
                return;
            }
        } else {
            $psicodrama = new Psicodrama();
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_psicodrama'])) {
            $this->guardar_psicodrama($psicodrama);
            
            if (!$id && $psicodrama->getId()) {
                $psicodrama = $database->get_psicodrama_by_id($psicodrama->getId());
            }
        }
        
        $template_path = ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/psicodramas.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<div class="notice notice-error"><p>Error: No se pudo cargar el formulario de psicodrama.</p></div>';
        }
    }
    
    private function guardar_psicodrama($psicodrama) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return false;
        }
        
        if (!isset($_POST['psicodrama_nonce']) || !wp_verify_nonce($_POST['psicodrama_nonce'], 'guardar_psicodrama')) {
            echo '<div class="notice notice-error"><p>Error de seguridad. Por favor, intenta nuevamente.</p></div>';
            return false;
        }

        $campos_requeridos = array('titulo', 'fecha_sesion', 'facilitador_id');
        $campos_faltantes = array();
        
        foreach ($campos_requeridos as $campo) {
            if (empty($_POST[$campo])) {
                $campos_faltantes[] = $campo;
            }
        }
        
        if (!empty($campos_faltantes)) {
            echo '<div class="notice notice-error"><p>Error: Los campos título, fecha de sesión y facilitador son requeridos.</p></div>';
            return false;
        }

        $data = array(
            'titulo' => sanitize_text_field($_POST['titulo']),
            'descripcion' => sanitize_textarea_field($_POST['descripcion'] ?? ''),
            'fecha_sesion' => sanitize_text_field($_POST['fecha_sesion']),
            'duracion' => intval($_POST['duracion'] ?? 90),
            'facilitador_id' => intval($_POST['facilitador_id']),
            'cofacilitador_id' => !empty($_POST['cofacilitador_id']) ? intval($_POST['cofacilitador_id']) : null,
            'participantes' => isset($_POST['participantes']) ? array_map('intval', $_POST['participantes']) : array(),
            'tema_central' => sanitize_text_field($_POST['tema_central'] ?? ''),
            'tecnica_utilizada' => sanitize_text_field($_POST['tecnica_utilizada'] ?? ''),
            'observaciones' => sanitize_textarea_field($_POST['observaciones'] ?? ''),
            'estado' => sanitize_text_field($_POST['estado'] ?? 'planificada'),
            'proxima_sesion' => !empty($_POST['proxima_sesion']) ? sanitize_text_field($_POST['proxima_sesion']) : null
        );

        $database = new Database();
        
        try {
            if ($psicodrama->getId()) {
                $resultado = $database->update_psicodrama($psicodrama->getId(), $data);
                
                if ($resultado && !is_wp_error($resultado)) {
                    echo '<div class="notice notice-success"><p>✅ Psicodrama actualizado correctamente.</p></div>';
                    return true;
                } else {
                    echo '<div class="notice notice-error"><p>❌ Error al actualizar el psicodrama.</p></div>';
                    return false;
                }
            } else {
                $nuevo_id = $database->insert_psicodrama($data);
                
                if ($nuevo_id && !is_wp_error($nuevo_id)) {
                    echo '<div class="notice notice-success"><p>✅ Psicodrama creado correctamente.</p></div>';
                    
                    wp_redirect(admin_url('admin.php?page=ac-psicodramas&updated=true'));
                    exit;
                    
                } else {
                    echo '<div class="notice notice-error"><p>❌ Error al crear el psicodrama.</p></div>';
                    return false;
                }
            }
        } catch (Exception $e) {
            echo '<div class="notice notice-error"><p>❌ Error del sistema: ' . esc_html($e->getMessage()) . '</p></div>';
            return false;
        }
    }
    
    private function eliminar_psicodrama($id) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return;
        }
        
        if (!wp_verify_nonce($_GET['_wpnonce'], 'eliminar_psicodrama_' . $id)) {
            echo '<div class="notice notice-error"><p>Error de seguridad.</p></div>';
            return;
        }
        
        $database = new Database();
        $resultado = $database->delete_psicodrama($id);
        
        if ($resultado && !is_wp_error($resultado)) {
            echo '<div class="notice notice-success"><p>Psicodrama eliminado correctamente.</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Error al eliminar el psicodrama.</p></div>';
        }
        
        wp_redirect(admin_url('admin.php?page=ac-psicodramas'));
        exit;
    }
    
    private function ver_psicodrama($id) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $database = new Database();
        $psicodrama = $database->get_psicodrama_by_id($id);
        
        if (!$psicodrama || !$psicodrama->getId()) {
            echo '<div class="notice notice-error"><p>Psicodrama no encontrado.</p></div>';
            return;
        }
        
        $template_path = ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/psicodramas.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<div class="notice notice-error"><p>Error: No se pudo cargar la vista de psicodrama.</p></div>';
        }
    }
    
    public function dinamicas_page() {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
        $id = isset($_GET['id']) ? intval($_GET['id']) : null;
        
        switch ($action) {
            case 'nuevo':
                $this->formulario_dinamica();
                break;
            case 'editar':
                $this->formulario_dinamica($id);
                break;
            case 'eliminar':
                $this->eliminar_dinamica($id);
                break;
            case 'ver':
                $this->ver_dinamica($id);
                break;
            default:
                $this->listar_dinamicas();
                break;
        }
    }
    
    private function listar_dinamicas() {
        // Cargar el template de listado
        $template_path = ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/dinamicas.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<div class="notice notice-warning"><p>Página de Dinámicas Grupales en desarrollo.</p>';
            echo '<p>Próximamente podrás gestionar las dinámicas grupales desde aquí.</p></div>';
        }
    }
    
    private function formulario_dinamica($id = null) {
        // Cargar el template del formulario
        $template_path = ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/dinamicas.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<div class="notice notice-warning"><p>Formulario de Dinámicas Grupales en desarrollo.</p></div>';
        }
    }
    
    private function guardar_dinamica($dinamica) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return false;
        }
        
        // Lógica para guardar dinámicas (a implementar)
        echo '<div class="notice notice-info"><p>Funcionalidad de guardar dinámicas en desarrollo.</p></div>';
        return false;
    }
    
    private function eliminar_dinamica($id) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return;
        }
        
        if (!wp_verify_nonce($_GET['_wpnonce'], 'eliminar_dinamica_' . $id)) {
            echo '<div class="notice notice-error"><p>Error de seguridad.</p></div>';
            return;
        }
        
        echo '<div class="notice notice-info"><p>Funcionalidad de eliminar dinámicas en desarrollo.</p></div>';
        
        wp_redirect(admin_url('admin.php?page=ac-dinamicas'));
        exit;
    }
    
    private function ver_dinamica($id) {
        // Cargar el template de vista
        $template_path = ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/dinamicas.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<div class="notice notice-warning"><p>Vista de Dinámica Grupal en desarrollo.</p></div>';
        }
    }
    
    public function camaras_seguridad_page() {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
        $id = isset($_GET['id']) ? intval($_GET['id']) : null;
        
        switch ($action) {
            case 'nuevo':
                $this->formulario_camara_seguridad();
                break;
            case 'editar':
                $this->formulario_camara_seguridad($id);
                break;
            case 'eliminar':
                $this->eliminar_camara_seguridad($id);
                break;
            case 'ver':
                $this->ver_camara_seguridad($id);
                break;
            case 'registros':
                $this->registros_camara_seguridad($id);
                break;
            default:
                $this->listar_camaras_seguridad();
                break;
        }
    }
    
    private function listar_camaras_seguridad() {
        $template_path = ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/camaras-seguridad.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<div class="notice notice-error"><p>Error: No se pudo cargar la página de cámaras de seguridad.</p></div>';
        }
    }
    
    private function formulario_camara_seguridad($id = null) {
        $template_path = ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/camaras-seguridad.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<div class="notice notice-error"><p>Error: No se pudo cargar el formulario de cámara de seguridad.</p></div>';
        }
    }
    
    private function eliminar_camara_seguridad($id) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return;
        }
        
        if (!wp_verify_nonce($_GET['_wpnonce'], 'eliminar_camara_' . $id)) {
            echo '<div class="notice notice-error"><p>Error de seguridad.</p></div>';
            return;
        }
        
        echo '<div class="notice notice-info"><p>Funcionalidad de eliminar cámara de seguridad en desarrollo.</p></div>';
        
        wp_redirect(admin_url('admin.php?page=ac-camaras-seguridad'));
        exit;
    }
    
    private function ver_camara_seguridad($id) {
        $template_path = ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/camaras-seguridad.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<div class="notice notice-error"><p>Error: No se pudo cargar la vista de cámara de seguridad.</p></div>';
        }
    }
    
    private function registros_camara_seguridad($id) {
        $template_path = ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/camaras-seguridad.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<div class="notice notice-error"><p>Error: No se pudo cargar los registros de la cámara.</p></div>';
        }
    }
    
    public function eventos_page() {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
        $id = isset($_GET['id']) ? intval($_GET['id']) : null;
        
        switch ($action) {
            case 'nuevo':
                $this->formulario_evento();
                break;
            case 'editar':
                $this->formulario_evento($id);
                break;
            case 'eliminar':
                $this->eliminar_evento($id);
                break;
            default:
                $this->listar_eventos();
                break;
        }
    }
    
    private function listar_eventos() {
        $database = new Database();
        $proximos = $database->get_eventos_proximos();
        $pasados = $database->get_eventos_pasados();
        
        include ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/eventos.php';
    }
    
    private function formulario_evento($id = null) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $database = new Database();
        $evento = null;
        
        if ($id) {
            $evento = $database->get_evento_by_id($id);
            if (!$evento || !$evento->getId()) {
                echo '<div class="notice notice-error"><p>Evento no encontrado.</p></div>';
                $this->listar_eventos();
                return;
            }
        } else {
            $evento = new Evento();
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_evento'])) {
            $this->guardar_evento($evento);
            
            if (!$id && $evento->getId()) {
                $evento = $database->get_evento_by_id($evento->getId());
            }
        }
        
        include ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/eventos.php';
    }
    
    private function guardar_evento($evento) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return false;
        }
        
        if (!isset($_POST['evento_nonce']) || !wp_verify_nonce($_POST['evento_nonce'], 'guardar_evento')) {
            echo '<div class="notice notice-error"><p>Error de seguridad. Por favor, intenta nuevamente.</p></div>';
            return false;
        }

        $campos_requeridos = array('titulo', 'fecha_inicio', 'tipo');
        $campos_faltantes = array();
        
        foreach ($campos_requeridos as $campo) {
            if (empty($_POST[$campo])) {
                $campos_faltantes[] = $campo;
            }
        }
        
        if (!empty($campos_faltantes)) {
            echo '<div class="notice notice-error"><p>Error: Los campos título, fecha de inicio y tipo son requeridos.</p></div>';
            return false;
        }

        $data = array(
            'titulo' => sanitize_text_field($_POST['titulo']),
            'descripcion' => sanitize_textarea_field($_POST['descripcion'] ?? ''),
            'fecha_inicio' => sanitize_text_field($_POST['fecha_inicio']),
            'fecha_fin' => sanitize_text_field($_POST['fecha_fin'] ?? ''),
            'tipo' => sanitize_text_field($_POST['tipo']),
            'lugar' => sanitize_text_field($_POST['lugar'] ?? ''),
            'organizador' => sanitize_text_field($_POST['organizador'] ?? ''),
            'participantes' => isset($_POST['participantes']) ? array_map('intval', $_POST['participantes']) : array(),
            'estado' => sanitize_text_field($_POST['estado'] ?? 'planificado')
        );

        $database = new Database();
        
        try {
            if ($evento->getId()) {
                $resultado = $database->update_evento($evento->getId(), $data);
                
                if ($resultado && !is_wp_error($resultado)) {
                    echo '<div class="notice notice-success"><p>✅ Evento actualizado correctamente.</p></div>';
                    return true;
                } else {
                    echo '<div class="notice notice-error"><p>❌ Error al actualizar el evento.</p></div>';
                    return false;
                }
            } else {
                $nuevo_id = $database->insert_evento($data);
                
                if ($nuevo_id && !is_wp_error($nuevo_id)) {
                    echo '<div class="notice notice-success"><p>✅ Evento creado correctamente.</p></div>';
                    
                    wp_redirect(admin_url('admin.php?page=ac-eventos&updated=true'));
                    exit;
                    
                } else {
                    echo '<div class="notice notice-error"><p>❌ Error al crear el evento.</p></div>';
                    return false;
                }
            }
        } catch (Exception $e) {
            echo '<div class="notice notice-error"><p>❌ Error del sistema: ' . esc_html($e->getMessage()) . '</p></div>';
            return false;
        }
    }
    
    private function eliminar_evento($id) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return;
        }
        
        if (!wp_verify_nonce($_GET['_wpnonce'], 'eliminar_evento_' . $id)) {
            echo '<div class="notice notice-error"><p>Error de seguridad.</p></div>';
            return;
        }
        
        $database = new Database();
        $resultado = $database->delete_evento($id);
        
        if ($resultado && !is_wp_error($resultado)) {
            echo '<div class="notice notice-success"><p>Evento eliminado correctamente.</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Error al eliminar el evento.</p></div>';
        }
        
        wp_redirect(admin_url('admin.php?page=ac-eventos'));
        exit;
    }
    
    public function documentos_page() {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
        $id = isset($_GET['id']) ? intval($_GET['id']) : null;
        
        switch ($action) {
            case 'nuevo':
                $this->formulario_documento();
                break;
            case 'editar':
                $this->formulario_documento($id);
                break;
            case 'eliminar':
                $this->eliminar_documento($id);
                break;
            default:
                $this->listar_documentos();
                break;
        }
    }
    
    private function listar_documentos() {
        $database = new Database();
        $documentos = $database->get_documentos_por_tipo('', 50);
        
        include ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/documentos.php';
    }

    private function formulario_documento($id = null) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $database = new Database();
        $documento = null;
        
        if ($id) {
            $documento = $database->get_documento_by_id($id);
            if (!$documento || !$documento->getId()) {
                echo '<div class="notice notice-error"><p>Documento no encontrado.</p></div>';
                $this->listar_documentos();
                return;
            }
        } else {
            $documento = new Documento();
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_documento'])) {
            $this->guardar_documento($documento);
            
            if (!$id && $documento->getId()) {
                $documento = $database->get_documento_by_id($documento->getId());
            }
        }
        
        include ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/documentos.php';
    }
    
    private function guardar_documento($documento) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return false;
        }
        
        if (!isset($_POST['documento_nonce']) || !wp_verify_nonce($_POST['documento_nonce'], 'guardar_documento')) {
            echo '<div class="notice notice-error"><p>Error de seguridad. Por favor, intenta nuevamente.</p></div>';
            return false;
        }

        $campos_requeridos = array('titulo', 'tipo');
        $campos_faltantes = array();
        
        foreach ($campos_requeridos as $campo) {
            if (empty($_POST[$campo])) {
                $campos_faltantes[] = $campo;
            }
        }
        
        if (!empty($campos_faltantes)) {
            echo '<div class="notice notice-error"><p>Error: Los campos título y tipo son requeridos.</p></div>';
            return false;
        }

        $data = array(
            'titulo' => sanitize_text_field($_POST['titulo']),
            'tipo' => sanitize_text_field($_POST['tipo']),
            'descripcion' => sanitize_textarea_field($_POST['descripcion'] ?? ''),
            'archivo_url' => esc_url_raw($_POST['archivo_url'] ?? ''),
            'fecha_creacion' => sanitize_text_field($_POST['fecha_creacion'] ?? current_time('mysql')),
            'estado' => sanitize_text_field($_POST['estado'] ?? 'activo')
        );

        $database = new Database();
        
        try {
            if ($documento->getId()) {
                $resultado = $database->update_documento($documento->getId(), $data);
                
                if ($resultado && !is_wp_error($resultado)) {
                    echo '<div class="notice notice-success"><p>✅ Documento actualizado correctamente.</p></div>';
                    return true;
                } else {
                    echo '<div class="notice notice-error"><p>❌ Error al actualizar el documento.</p></div>';
                    return false;
                }
            } else {
                $nuevo_id = $database->insert_documento($data);
                
                if ($nuevo_id && !is_wp_error($nuevo_id)) {
                    echo '<div class="notice notice-success"><p>✅ Documento creado correctamente.</p></div>';
                    
                    wp_redirect(admin_url('admin.php?page=ac-documentos&updated=true'));
                    exit;
                    
                } else {
                    echo '<div class="notice notice-error"><p>❌ Error al crear el documento.</p></div>';
                    return false;
                }
            }
        } catch (Exception $e) {
            echo '<div class="notice notice-error"><p>❌ Error del sistema: ' . esc_html($e->getMessage()) . '</p></div>';
            return false;
        }
    }
    
    private function eliminar_documento($id) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return;
        }
        
        if (!wp_verify_nonce($_GET['_wpnonce'], 'eliminar_documento_' . $id)) {
            echo '<div class="notice notice-error"><p>Error de seguridad.</p></div>';
            return;
        }
        
        $database = new Database();
        $resultado = $database->delete_documento($id);
        
        if ($resultado && !is_wp_error($resultado)) {
            echo '<div class="notice notice-success"><p>Documento eliminado correctamente.</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Error al eliminar el documento.</p></div>';
        }
        
        wp_redirect(admin_url('admin.php?page=ac-documentos'));
        exit;
    }
    
    public function notas_judiciales_page() {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'listar';
        $id = isset($_GET['id']) ? intval($_GET['id']) : null;
        
        switch ($action) {
            case 'nuevo':
                $this->formulario_nota_judicial();
                break;
            case 'editar':
                $this->formulario_nota_judicial($id);
                break;
            case 'eliminar':
                $this->eliminar_nota_judicial($id);
                break;
            case 'ver':
                $this->ver_nota_judicial($id);
                break;
            default:
                $this->listar_notas_judiciales();
                break;
        }
    }
    
    private function listar_notas_judiciales() {
        // Cargar el template de notas judiciales
        $template_path = ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/notas-judiciales.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<div class="wrap">';
            echo '<h1>⚖️ Notas Judiciales</h1>';
            echo '<div class="notice notice-error">';
            echo '<p>Error: No se pudo cargar la página de notas judiciales.</p>';
            echo '</div>';
            echo '</div>';
        }
    }
    
    private function formulario_nota_judicial($id = null) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $database = new Database();
        $nota = null;
        
        if ($id) {
            $nota = $database->get_nota_judicial_by_id($id);
            if (!$nota) {
                echo '<div class="notice notice-error"><p>Nota judicial no encontrada.</p></div>';
                $this->listar_notas_judiciales();
                return;
            }
        } else {
            $nota = new NotaJudicial();
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_nota_judicial'])) {
            $this->guardar_nota_judicial($nota);
            
            if (!$id && $nota->getId()) {
                $nota = $database->get_nota_judicial_by_id($nota->getId());
            }
        }
        
        // Cargar el template del formulario
        $template_path = ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/notas-judiciales.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<div class="wrap">';
            echo '<h1>' . ($id ? 'Editar' : 'Nueva') . ' Nota Judicial</h1>';
            echo '<div class="notice notice-error">';
            echo '<p>Error: No se pudo cargar el formulario de nota judicial.</p>';
            echo '</div>';
            echo '</div>';
        }
    }
    
    private function guardar_nota_judicial($nota_judicial) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return false;
        }
        
        if (!isset($_POST['nota_judicial_nonce']) || !wp_verify_nonce($_POST['nota_judicial_nonce'], 'guardar_nota_judicial')) {
            echo '<div class="notice notice-error"><p>Error de seguridad. Por favor, intenta nuevamente.</p></div>';
            return false;
        }

        $campos_requeridos = array('titulo', 'fecha', 'numero_expediente');
        $campos_faltantes = array();
        
        foreach ($campos_requeridos as $campo) {
            if (empty($_POST[$campo])) {
                $campos_faltantes[] = $campo;
            }
        }
        
        if (!empty($campos_faltantes)) {
            echo '<div class="notice notice-error"><p>Error: Los campos título, fecha y número de expediente son requeridos.</p></div>';
            return false;
        }

        $data = array(
            'titulo' => sanitize_text_field($_POST['titulo']),
            'fecha' => sanitize_text_field($_POST['fecha']),
            'numero_expediente' => sanitize_text_field($_POST['numero_expediente']),
            'juzgado' => sanitize_text_field($_POST['juzgado'] ?? ''),
            'descripcion' => wp_kses_post($_POST['descripcion'] ?? ''),
            'estado' => sanitize_text_field($_POST['estado'] ?? 'pendiente'),
            'observaciones' => wp_kses_post($_POST['observaciones'] ?? '')
        );

        $database = new Database();
        
        try {
            if ($nota_judicial->getId()) {
                $resultado = $database->update_nota_judicial($nota_judicial->getId(), $data);
                
                if ($resultado && !is_wp_error($resultado)) {
                    echo '<div class="notice notice-success"><p>✅ Nota judicial actualizada correctamente.</p></div>';
                    return true;
                } else {
                    echo '<div class="notice notice-error"><p>❌ Error al actualizar la nota judicial.</p></div>';
                    return false;
                }
            } else {
                $nuevo_id = $database->insert_nota_judicial($data);
                
                if ($nuevo_id && !is_wp_error($nuevo_id)) {
                    echo '<div class="notice notice-success"><p>✅ Nota judicial creada correctamente.</p></div>';
                    
                    wp_redirect(admin_url('admin.php?page=ac-notas-judiciales&updated=true'));
                    exit;
                    
                } else {
                    echo '<div class="notice notice-error"><p>❌ Error al crear la nota judicial.</p></div>';
                    return false;
                }
            }
        } catch (Exception $e) {
            echo '<div class="notice notice-error"><p>❌ Error del sistema: ' . esc_html($e->getMessage()) . '</p></div>';
            return false;
        }
    }
    
    private function eliminar_nota_judicial($id) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            echo '<div class="notice notice-error"><p>No tienes permisos para realizar esta acción.</p></div>';
            return;
        }
        
        if (!wp_verify_nonce($_GET['_wpnonce'], 'eliminar_nota_judicial_' . $id)) {
            echo '<div class="notice notice-error"><p>Error de seguridad.</p></div>';
            return;
        }
        
        $database = new Database();
        $resultado = $database->delete_nota_judicial($id);
        
        if ($resultado && !is_wp_error($resultado)) {
            echo '<div class="notice notice-success"><p>Nota judicial eliminada correctamente.</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Error al eliminar la nota judicial.</p></div>';
        }
        
        wp_redirect(admin_url('admin.php?page=ac-notas-judiciales'));
        exit;
    }
    
    private function ver_nota_judicial($id) {
        // Verificación de permisos más permisiva
        if (!current_user_can('read')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        // Cargar el template de vista
        $template_path = ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/notas-judiciales.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<div class="wrap">';
            echo '<h1>Detalles de Nota Judicial</h1>';
            echo '<div class="notice notice-error">';
            echo '<p>Error: No se pudo cargar la vista de nota judicial.</p>';
            echo '</div>';
            echo '</div>';
        }
    }
    
    public function configuracion_page() {
        // La configuración mantiene manage_options por seguridad
        if (!current_user_can('manage_options')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
        
        $configuracion = get_option('asociacion_civil_settings', array());
        include ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/configuracion.php';
    }
    
    public function guardar_configuracion_handler() {
        // La configuración mantiene manage_options por seguridad
        if (!current_user_can('manage_options')) {
            wp_die('No tienes permisos suficientes para realizar esta acción.');
        }
        
        error_log('Datos POST recibidos: ' . print_r($_POST, true));
        
        if (!isset($_POST['configuracion_nonce']) || !wp_verify_nonce($_POST['configuracion_nonce'], 'guardar_configuracion')) {
            error_log('Error de seguridad: Nonce inválido');
            wp_die(
                'Error de seguridad. Por favor, intenta nuevamente.', 
                'Error de Seguridad', 
                array('response' => 403, 'back_link' => true)
            );
        }
        
        $configuracion_actual = get_option('asociacion_civil_settings', array());
        
        $configuracion_actual['nombre_asociacion'] = sanitize_text_field($_POST['nombre_asociacion'] ?? '');
        $configuracion_actual['rif'] = sanitize_text_field($_POST['rif'] ?? '');
        $configuracion_actual['numero_registro'] = sanitize_text_field($_POST['numero_registro'] ?? '');
        $configuracion_actual['fecha_constitucion'] = sanitize_text_field($_POST['fecha_constitucion'] ?? '');
        
        $configuracion_actual['direccion'] = sanitize_textarea_field($_POST['direccion'] ?? '');
        $configuracion_actual['telefono'] = sanitize_text_field($_POST['telefono'] ?? '');
        $configuracion_actual['email'] = sanitize_email($_POST['email'] ?? '');
        
        // CONFIGURACIONES PARA CÁMARAS
        $configuracion_actual['camaras_habilitadas'] = isset($_POST['camaras_habilitadas']) ? 1 : 0;
        $configuracion_actual['retencion_grabaciones'] = intval($_POST['retencion_grabaciones'] ?? 30);

        // CONFIGURACIONES PARA PSICODRAMAS
        $configuracion_actual['psicodramas_habilitados'] = isset($_POST['psicodramas_habilitados']) ? 1 : 0;
        $configuracion_actual['duracion_default_psicodrama'] = intval($_POST['duracion_default_psicodrama'] ?? 90);

        // CONFIGURACIONES PARA NOTAS JUDICIALES
        $configuracion_actual['notas_judiciales_habilitadas'] = isset($_POST['notas_judiciales_habilitadas']) ? 1 : 0;
        
        // NUEVAS CONFIGURACIONES PARA PACIENTES
        $configuracion_actual['pacientes_habilitados'] = isset($_POST['pacientes_habilitados']) ? 1 : 0;
        $configuracion_actual['retencion_historial_medico'] = intval($_POST['retencion_historial_medico'] ?? 365);
        
        // NUEVA CONFIGURACIÓN PARA DINÁMICAS
        $configuracion_actual['dinamicas_habilitadas'] = isset($_POST['dinamicas_habilitadas']) ? 1 : 0;
        
        // NUEVAS CONFIGURACIONES PARA REUNIONES Y TIEMPO LIMPIO
        $configuracion_actual['reuniones_habilitadas'] = isset($_POST['reuniones_habilitadas']) ? 1 : 0;
        $configuracion_actual['tiempo_limpio_habilitado'] = isset($_POST['tiempo_limpio_habilitado']) ? 1 : 0;
        
        // CONFIGURACIÓN PARA SISTEMA INTEGRAL
        $configuracion_actual['sistema_integral_habilitado'] = isset($_POST['sistema_integral_habilitado']) ? 1 : 0;
        
        $resultado_config = update_option('asociacion_civil_settings', $configuracion_actual);
        
        update_option('ac_miembros_por_pagina', intval($_POST['miembros_por_pagina'] ?? 20));
        update_option('ac_dias_recordatorio', intval($_POST['dias_recordatorio'] ?? 7));
        update_option('ac_notificaciones_email', isset($_POST['notificaciones_email']) ? 1 : 0);
        update_option('ac_backup_automatico', isset($_POST['backup_automatico']) ? 1 : 0);
        
        error_log('Configuración guardada: ' . ($resultado_config ? 'ÉXITO' : 'FALLÓ'));
        
        wp_redirect(admin_url('admin.php?page=ac-configuracion&updated=true'));
        exit;
    }
    
    public function limpiar_cache_asociacion() {
        // La configuración mantiene manage_options por seguridad
        if (!current_user_can('manage_options')) {
            wp_send_json_error('No tienes permisos suficientes');
        }
        
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'limpiar_cache')) {
            wp_send_json_error('Error de seguridad');
        }
        
        wp_send_json_success('Cache limpiado correctamente');
    }
    
    public function verificar_bd_asociacion() {
        // La configuración mantiene manage_options por seguridad
        if (!current_user_can('manage_options')) {
            wp_send_json_error('No tienes permisos suficientes');
        }
        
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'verificar_bd')) {
            wp_send_json_error('Error de seguridad');
        }
        
        wp_send_json_success('Base de datos verificada correctamente');
    }
    
    public function exportar_datos_completos() {
        // La configuración mantiene manage_options por seguridad
        if (!current_user_can('manage_options')) {
            wp_die('No tienes permisos suficientes');
        }
        
        wp_die('Función de exportación no implementada aún');
    }
}