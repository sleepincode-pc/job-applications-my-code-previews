<?php
namespace AsociacionCivil;

class CamaraSeguridad {
    
    private $db;
    private $table_name;
    
    public function __construct() {
        global $wpdb;
        $this->db = $wpdb;
        $this->table_name = $wpdb->prefix . 'ac_camaras_seguridad';
    }
    
    // Métodos para gestión de cámaras (get, create, update, delete, etc.)
    // Similar a la estructura de SesionPsicologica
}