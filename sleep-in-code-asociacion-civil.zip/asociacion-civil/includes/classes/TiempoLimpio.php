<?php

namespace AsociacionCivil;

class TiempoLimpio {
    private $id;
    private $paciente_id;
    private $fecha_inicio_abstinencia;
    private $fecha_registro;
    private $dias_limpios;
    private $tipo_sustancia;
    private $estado_actual;
    private $avances;
    private $dificultades;
    private $metas_cumplidas;
    private $observaciones;
    private $terapeuta_id;
    private $fecha_creacion;
    private $fecha_actualizacion;

    public function __construct($id = null) {
        if ($id) {
            $this->cargar($id);
        }
    }

    public function cargar($id) {
        global $wpdb;
        
        $tabla = $wpdb->prefix . 'ac_tiempo_limpio';
        $registro = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tabla WHERE id = %d", $id));
        
        if ($registro) {
            $this->id = $registro->id;
            $this->paciente_id = $registro->paciente_id;
            $this->fecha_inicio_abstinencia = $registro->fecha_inicio_abstinencia;
            $this->fecha_registro = $registro->fecha_registro;
            $this->dias_limpios = $registro->dias_limpios;
            $this->tipo_sustancia = $registro->tipo_sustancia;
            $this->estado_actual = $registro->estado_actual;
            $this->avances = $registro->avances;
            $this->dificultades = $registro->dificultades;
            $this->metas_cumplidas = $registro->metas_cumplidas;
            $this->observaciones = $registro->observaciones;
            $this->terapeuta_id = $registro->terapeuta_id;
            $this->fecha_creacion = $registro->fecha_creacion;
            $this->fecha_actualizacion = $registro->fecha_actualizacion;
            
            return true;
        }
        
        return false;
    }

    public function guardar() {
        global $wpdb;
        
        // Calcular días limpios
        $this->calcularDiasLimpios();
        
        $tabla = $wpdb->prefix . 'ac_tiempo_limpio';
        $data = array(
            'paciente_id' => $this->paciente_id,
            'fecha_inicio_abstinencia' => $this->fecha_inicio_abstinencia,
            'fecha_registro' => $this->fecha_registro,
            'dias_limpios' => $this->dias_limpios,
            'tipo_sustancia' => $this->tipo_sustancia,
            'estado_actual' => $this->estado_actual,
            'avances' => $this->avances,
            'dificultades' => $this->dificultades,
            'metas_cumplidas' => $this->metas_cumplidas,
            'observaciones' => $this->observaciones,
            'terapeuta_id' => $this->terapeuta_id,
            'fecha_actualizacion' => current_time('mysql')
        );
        
        if ($this->id) {
            // Actualizar
            $result = $wpdb->update($tabla, $data, array('id' => $this->id));
            return $result !== false;
        } else {
            // Insertar
            $data['fecha_creacion'] = current_time('mysql');
            $result = $wpdb->insert($tabla, $data);
            if ($result) {
                $this->id = $wpdb->insert_id;
                return true;
            }
        }
        
        return false;
    }

    private function calcularDiasLimpios() {
        if ($this->fecha_inicio_abstinencia) {
            $fecha_inicio = new \DateTime($this->fecha_inicio_abstinencia);
            $fecha_actual = new \DateTime();
            $diferencia = $fecha_inicio->diff($fecha_actual);
            $this->dias_limpios = $diferencia->days;
        } else {
            $this->dias_limpios = 0;
        }
    }

    public function eliminar() {
        global $wpdb;
        
        if (!$this->id) {
            return false;
        }
        
        $tabla = $wpdb->prefix . 'ac_tiempo_limpio';
        $result = $wpdb->delete($tabla, array('id' => $this->id));
        
        return $result !== false;
    }

    // Getters
    public function getId() { return $this->id; }
    public function getPacienteId() { return $this->paciente_id; }
    public function getFechaInicioAbstinencia() { return $this->fecha_inicio_abstinencia; }
    public function getFechaRegistro() { return $this->fecha_registro; }
    public function getDiasLimpios() { return $this->dias_limpios; }
    public function getTipoSustancia() { return $this->tipo_sustancia; }
    public function getEstadoActual() { return $this->estado_actual; }
    public function getAvances() { return $this->avances; }
    public function getDificultades() { return $this->dificultades; }
    public function getMetasCumplidas() { return $this->metas_cumplidas; }
    public function getObservaciones() { return $this->observaciones; }
    public function getTerapeutaId() { return $this->terapeuta_id; }
    public function getFechaCreacion() { return $this->fecha_creacion; }
    public function getFechaActualizacion() { return $this->fecha_actualizacion; }

    // Setters
    public function setPacienteId($paciente_id) { $this->paciente_id = intval($paciente_id); }
    public function setFechaInicioAbstinencia($fecha) { $this->fecha_inicio_abstinencia = sanitize_text_field($fecha); }
    public function setFechaRegistro($fecha) { $this->fecha_registro = sanitize_text_field($fecha); }
    public function setTipoSustancia($sustancia) { $this->tipo_sustancia = sanitize_text_field($sustancia); }
    public function setEstadoActual($estado) { $this->estado_actual = sanitize_text_field($estado); }
    public function setAvances($avances) { $this->avances = sanitize_textarea_field($avances); }
    public function setDificultades($dificultades) { $this->dificultades = sanitize_textarea_field($dificultades); }
    public function setMetasCumplidas($metas) { $this->metas_cumplidas = sanitize_textarea_field($metas); }
    public function setObservaciones($observaciones) { $this->observaciones = sanitize_textarea_field($observaciones); }
    public function setTerapeutaId($terapeuta_id) { $this->terapeuta_id = intval($terapeuta_id); }
}