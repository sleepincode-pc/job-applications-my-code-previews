<?php

namespace AsociacionCivil;

class Psicodrama {
    
    private $id;
    private $titulo;
    private $descripcion;
    private $fecha_sesion;
    private $duracion;
    private $facilitador_id;
    private $cofacilitador_id;
    private $participantes;
    private $tema_central;
    private $tecnica_utilizada;
    private $escenas_desarrolladas;
    private $insights_principales;
    private $observaciones;
    private $estado;
    private $proxima_sesion;
    private $materiales_utilizados;
    private $evaluacion_participantes;
    private $created_at;
    private $updated_at;

    // Constantes para estados
    const ESTADO_PLANIFICADA = 'planificada';
    const ESTADO_EN_CURSO = 'en_curso';
    const ESTADO_COMPLETADA = 'completada';
    const ESTADO_CANCELADA = 'cancelada';
    const ESTADO_REPROGRAMADA = 'reprogramada';

    // Constantes para técnicas
    const TECNICA_CAMBIO_ROL = 'cambio_rol';
    const TECNICA_DOBLE = 'doble';
    const TECNICA_ESPEJO = 'espejo';
    const TECNICA_SILLA_VACIA = 'silla_vacia';
    const TECNICA_SOLILOQUIO = 'soliloquio';
    const TECNICA_PROYECCION = 'proyeccion';
    const TECNICA_ESCULTURA = 'escultura';
    const TECNICA_ROL_PLAYING = 'rol_playing';

    public function __construct($id = null) {
        if ($id) {
            $this->cargar($id);
        }
    }

    public function cargar($id) {
        global $wpdb;
        
        $tabla = $wpdb->prefix . 'ac_psicodramas';
        $psicodrama = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tabla WHERE id = %d", $id));
        
        if ($psicodrama) {
            $this->id = $psicodrama->id;
            $this->titulo = $psicodrama->titulo;
            $this->descripcion = $psicodrama->descripcion;
            $this->fecha_sesion = $psicodrama->fecha_sesion;
            $this->duracion = $psicodrama->duracion;
            $this->facilitador_id = $psicodrama->facilitador_id;
            $this->cofacilitador_id = $psicodrama->cofacilitador_id;
            $this->participantes = maybe_unserialize($psicodrama->participantes);
            $this->tema_central = $psicodrama->tema_central;
            $this->tecnica_utilizada = $psicodrama->tecnica_utilizada;
            $this->escenas_desarrolladas = maybe_unserialize($psicodrama->escenas_desarrolladas);
            $this->insights_principales = maybe_unserialize($psicodrama->insights_principales);
            $this->observaciones = $psicodrama->observaciones;
            $this->estado = $psicodrama->estado;
            $this->proxima_sesion = $psicodrama->proxima_sesion;
            $this->materiales_utilizados = maybe_unserialize($psicodrama->materiales_utilizados);
            $this->evaluacion_participantes = maybe_unserialize($psicodrama->evaluacion_participantes);
            $this->created_at = $psicodrama->created_at;
            $this->updated_at = $psicodrama->updated_at;
            
            return true;
        }
        
        return false;
    }

    public function save() {
        global $wpdb;
        
        $tabla = $wpdb->prefix . 'ac_psicodramas';
        $datos = array(
            'titulo' => $this->titulo,
            'descripcion' => $this->descripcion,
            'fecha_sesion' => $this->fecha_sesion,
            'duracion' => $this->duracion,
            'facilitador_id' => $this->facilitador_id,
            'cofacilitador_id' => $this->cofacilitador_id,
            'participantes' => maybe_serialize($this->participantes),
            'tema_central' => $this->tema_central,
            'tecnica_utilizada' => $this->tecnica_utilizada,
            'escenas_desarrolladas' => maybe_serialize($this->escenas_desarrolladas),
            'insights_principales' => maybe_serialize($this->insights_principales),
            'observaciones' => $this->observaciones,
            'estado' => $this->estado,
            'proxima_sesion' => $this->proxima_sesion,
            'materiales_utilizados' => maybe_serialize($this->materiales_utilizados),
            'evaluacion_participantes' => maybe_serialize($this->evaluacion_participantes),
            'updated_at' => current_time('mysql')
        );
        
        if ($this->id) {
            // Actualizar
            $resultado = $wpdb->update($tabla, $datos, array('id' => $this->id));
            return $resultado !== false;
        } else {
            // Insertar
            $datos['created_at'] = current_time('mysql');
            $resultado = $wpdb->insert($tabla, $datos);
            if ($resultado) {
                $this->id = $wpdb->insert_id;
                return true;
            }
        }
        
        return false;
    }

    public function delete() {
        if (!$this->id) {
            return new \WP_Error('no_id', 'No se puede eliminar un psicodrama sin ID');
        }
        
        global $wpdb;
        $tabla = $wpdb->prefix . 'ac_psicodramas';
        $resultado = $wpdb->delete($tabla, array('id' => $this->id));
        
        if ($resultado) {
            return true;
        }
        
        return new \WP_Error('delete_error', 'Error al eliminar el psicodrama');
    }

    // Getters
    public function getId() { return $this->id; }
    public function getTitulo() { return $this->titulo; }
    public function getDescripcion() { return $this->descripcion; }
    public function getFechaSesion() { return $this->fecha_sesion; }
    public function getDuracion() { return $this->duracion; }
    public function getFacilitadorId() { return $this->facilitador_id; }
    public function getCofacilitadorId() { return $this->cofacilitador_id; }
    public function getParticipantes() { return $this->participantes; }
    public function getTemaCentral() { return $this->tema_central; }
    public function getTecnicaUtilizada() { return $this->tecnica_utilizada; }
    public function getEscenasDesarrolladas() { return $this->escenas_desarrolladas; }
    public function getInsightsPrincipales() { return $this->insights_principales; }
    public function getObservaciones() { return $this->observaciones; }
    public function getEstado() { return $this->estado; }
    public function getProximaSesion() { return $this->proxima_sesion; }
    public function getMaterialesUtilizados() { return $this->materiales_utilizados; }
    public function getEvaluacionParticipantes() { return $this->evaluacion_participantes; }
    public function getCreatedAt() { return $this->created_at; }
    public function getUpdatedAt() { return $this->updated_at; }

    // Setters
    public function setTitulo($titulo) { $this->titulo = sanitize_text_field($titulo); }
    public function setDescripcion($descripcion) { $this->descripcion = sanitize_textarea_field($descripcion); }
    public function setFechaSesion($fecha_sesion) { $this->fecha_sesion = sanitize_text_field($fecha_sesion); }
    public function setDuracion($duracion) { $this->duracion = intval($duracion); }
    public function setFacilitadorId($facilitador_id) { $this->facilitador_id = intval($facilitador_id); }
    public function setCofacilitadorId($cofacilitador_id) { $this->cofacilitador_id = intval($cofacilitador_id); }
    public function setParticipantes($participantes) { $this->participantes = $participantes; }
    public function setTemaCentral($tema_central) { $this->tema_central = sanitize_text_field($tema_central); }
    public function setTecnicaUtilizada($tecnica_utilizada) { $this->tecnica_utilizada = sanitize_text_field($tecnica_utilizada); }
    public function setEscenasDesarrolladas($escenas_desarrolladas) { $this->escenas_desarrolladas = $escenas_desarrolladas; }
    public function setInsightsPrincipales($insights_principales) { $this->insights_principales = $insights_principales; }
    public function setObservaciones($observaciones) { $this->observaciones = sanitize_textarea_field($observaciones); }
    public function setEstado($estado) { $this->estado = sanitize_text_field($estado); }
    public function setProximaSesion($proxima_sesion) { $this->proxima_sesion = sanitize_text_field($proxima_sesion); }
    public function setMaterialesUtilizados($materiales_utilizados) { $this->materiales_utilizados = $materiales_utilizados; }
    public function setEvaluacionParticipantes($evaluacion_participantes) { $this->evaluacion_participantes = $evaluacion_participantes; }

    // Métodos estáticos para obtener listas
    public static function getEstados() {
        return array(
            self::ESTADO_PLANIFICADA => 'Planificada',
            self::ESTADO_EN_CURSO => 'En Curso',
            self::ESTADO_COMPLETADA => 'Completada',
            self::ESTADO_CANCELADA => 'Cancelada',
            self::ESTADO_REPROGRAMADA => 'Reprogramada'
        );
    }

    public static function getTecnicas() {
        return array(
            self::TECNICA_CAMBIO_ROL => 'Cambio de Rol',
            self::TECNICA_DOBLE => 'Doble',
            self::TECNICA_ESPEJO => 'Espejo',
            self::TECNICA_SILLA_VACIA => 'Silla Vacía',
            self::TECNICA_SOLILOQUIO => 'Soliloquio',
            self::TECNICA_PROYECCION => 'Proyección',
            self::TECNICA_ESCULTURA => 'Escultura Familiar',
            self::TECNICA_ROL_PLAYING => 'Role Playing'
        );
    }

    // Métodos para obtener información relacionada
    public function getFacilitador() {
        if ($this->facilitador_id) {
            return new Miembro($this->facilitador_id);
        }
        return null;
    }

    public function getCofacilitador() {
        if ($this->cofacilitador_id) {
            return new Miembro($this->cofacilitador_id);
        }
        return null;
    }

    public function getFacilitadorNombre() {
        $facilitador = $this->getFacilitador();
        return $facilitador ? $facilitador->getNombreCompleto() : 'No asignado';
    }

    public function getCofacilitadorNombre() {
        $cofacilitador = $this->getCofacilitador();
        return $cofacilitador ? $cofacilitador->getNombreCompleto() : 'No asignado';
    }

    public function getNumeroParticipantes() {
        if (is_array($this->participantes)) {
            return count($this->participantes);
        }
        return 0;
    }

    public function getParticipantesNombres() {
        if (empty($this->participantes) || !is_array($this->participantes)) {
            return array();
        }

        $nombres = array();
        foreach ($this->participantes as $participante_id) {
            $miembro = new Miembro($participante_id);
            if ($miembro->getId()) {
                $nombres[] = $miembro->getNombreCompleto();
            }
        }
        return $nombres;
    }

    public function getTecnicaNombre() {
        $tecnicas = self::getTecnicas();
        return isset($tecnicas[$this->tecnica_utilizada]) ? $tecnicas[$this->tecnica_utilizada] : $this->tecnica_utilizada;
    }

    public function getEstadoNombre() {
        $estados = self::getEstados();
        return isset($estados[$this->estado]) ? $estados[$this->estado] : $this->estado;
    }

    // Métodos de validación
    public function validar() {
        $errores = array();

        if (empty($this->titulo)) {
            $errores[] = 'El título es requerido';
        }

        if (empty($this->fecha_sesion)) {
            $errores[] = 'La fecha de sesión es requerida';
        }

        if (empty($this->facilitador_id)) {
            $errores[] = 'El facilitador es requerido';
        }

        if ($this->duracion <= 0) {
            $errores[] = 'La duración debe ser mayor a 0';
        }

        return empty($errores) ? true : $errores;
    }

    // Método para cambiar estado
    public function cambiarEstado($nuevo_estado) {
        $estados_validos = array_keys(self::getEstados());
        if (in_array($nuevo_estado, $estados_validos)) {
            $this->estado = $nuevo_estado;
            return $this->save();
        }
        return false;
    }

    // Método para agregar participante
    public function agregarParticipante($miembro_id) {
        if (!is_array($this->participantes)) {
            $this->participantes = array();
        }

        if (!in_array($miembro_id, $this->participantes)) {
            $this->participantes[] = $miembro_id;
            return true;
        }

        return false;
    }

    // Método para remover participante
    public function removerParticipante($miembro_id) {
        if (is_array($this->participantes)) {
            $key = array_search($miembro_id, $this->participantes);
            if ($key !== false) {
                unset($this->participantes[$key]);
                $this->participantes = array_values($this->participantes); // Reindexar
                return true;
            }
        }
        return false;
    }

    // Método para agregar escena
    public function agregarEscena($titulo_escena, $descripcion_escena) {
        if (!is_array($this->escenas_desarrolladas)) {
            $this->escenas_desarrolladas = array();
        }

        $escena = array(
            'titulo' => sanitize_text_field($titulo_escena),
            'descripcion' => sanitize_textarea_field($descripcion_escena),
            'timestamp' => current_time('mysql')
        );

        $this->escenas_desarrolladas[] = $escena;
        return true;
    }

    // Método para agregar insight
    public function agregarInsight($insight) {
        if (!is_array($this->insights_principales)) {
            $this->insights_principales = array();
        }

        $this->insights_principales[] = array(
            'texto' => sanitize_textarea_field($insight),
            'timestamp' => current_time('mysql')
        );

        return true;
    }
}
?>