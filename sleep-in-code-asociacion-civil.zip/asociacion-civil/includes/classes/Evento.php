<?php

namespace AsociacionCivil;

class Evento {
    
    private $data = array();
    private $database;
    
    public function __construct($id = null) {
        $this->database = new Database();
        
        if ($id) {
            $this->load($id);
        }
    }
    
    public function load($id) {
        global $wpdb;
        $data = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}ac_eventos WHERE id = %d", $id)
        );
        
        if ($data) {
            $this->data = (array) $data;
            return true;
        }
        
        return false;
    }
    
    public function save() {
        global $wpdb;
        
        if ($this->data['id'] ?? false) {
            return $wpdb->update(
                "{$wpdb->prefix}ac_eventos",
                $this->data,
                array('id' => $this->data['id'])
            );
        } else {
            $result = $wpdb->insert(
                "{$wpdb->prefix}ac_eventos",
                $this->data
            );
            if ($result) {
                $this->data['id'] = $wpdb->insert_id;
            }
            return $result;
        }
    }
    
    public function eliminar() {
        global $wpdb;
        
        if ($this->data['id'] ?? false) {
            return $wpdb->delete(
                "{$wpdb->prefix}ac_eventos",
                array('id' => $this->data['id'])
            );
        }
        return false;
    }
    
    // Getters y Setters
    public function setTitulo($titulo) { 
        $this->data['titulo'] = sanitize_text_field($titulo); 
    }
    
    public function setDescripcion($desc) { 
        $this->data['descripcion'] = sanitize_textarea_field($desc); 
    }
    
    public function setFecha($fecha) { 
        $this->data['fecha'] = sanitize_text_field($fecha); 
    }
    
    public function setLugar($lugar) { 
        $this->data['lugar'] = sanitize_text_field($lugar); 
    }
    
    public function setTipo($tipo) { 
        $tipos_permitidos = array('reunion', 'asamblea', 'evento', 'otros');
        if (in_array($tipo, $tipos_permitidos)) {
            $this->data['tipo'] = $tipo;
        }
    }
    
    public function setEstado($estado) {
        $estados_permitidos = array('planificado', 'realizado', 'cancelado');
        if (in_array($estado, $estados_permitidos)) {
            $this->data['estado'] = $estado;
        }
    }
    
    public function setAsistentes($asistentes) {
        if (is_array($asistentes)) {
            $this->data['asistentes'] = serialize($asistentes);
        } else {
            $this->data['asistentes'] = sanitize_textarea_field($asistentes);
        }
    }
    
    public function setActa($acta) {
        $this->data['acta'] = sanitize_textarea_field($acta);
    }
    
    public function getTitulo() { 
        return $this->data['titulo'] ?? ''; 
    }
    
    public function getDescripcion() { 
        return $this->data['descripcion'] ?? ''; 
    }
    
    public function getFecha() { 
        return $this->data['fecha'] ?? ''; 
    }
    
    public function getLugar() { 
        return $this->data['lugar'] ?? ''; 
    }
    
    public function getTipo() { 
        return $this->data['tipo'] ?? 'reunion'; 
    }
    
    public function getEstado() { 
        return $this->data['estado'] ?? 'planificado'; 
    }
    
    public function getFechaFormateada() { 
        return date('d/m/Y H:i', strtotime($this->data['fecha'] ?? '')); 
    }
    
    public function getAsistentes() {
        if (isset($this->data['asistentes'])) {
            $asistentes = maybe_unserialize($this->data['asistentes']);
            return is_array($asistentes) ? $asistentes : array();
        }
        return array();
    }
    
    public function getActa() {
        return $this->data['acta'] ?? '';
    }
    
    public function esPasado() {
        return strtotime($this->data['fecha'] ?? '') < current_time('timestamp');
    }
    
    public function esProximo() {
        return strtotime($this->data['fecha'] ?? '') >= current_time('timestamp');
    }
    
    public function toArray() {
        return $this->data;
    }
}
?>