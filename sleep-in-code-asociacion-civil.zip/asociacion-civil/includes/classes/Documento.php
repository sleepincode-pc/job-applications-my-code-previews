<?php

namespace AsociacionCivil;

class Documento {
    
    private $data = array();
    private $database;
    
    public function __construct($id = null) {
        $this->database = new Database();
        
        if ($id) {
            $this->load($id);
        }
    }
    
    public function load($id) {
        global $wpdb;
        $data = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}ac_documentos WHERE id = %d", $id)
        );
        
        if ($data) {
            $this->data = (array) $data;
            return true;
        }
        
        return false;
    }
    
    public function save() {
        global $wpdb;
        
        if ($this->data['id'] ?? false) {
            return $wpdb->update(
                "{$wpdb->prefix}ac_documentos",
                $this->data,
                array('id' => $this->data['id'])
            );
        } else {
            $result = $wpdb->insert(
                "{$wpdb->prefix}ac_documentos",
                $this->data
            );
            if ($result) {
                $this->data['id'] = $wpdb->insert_id;
            }
            return $result;
        }
    }
    
    public function eliminar() {
        global $wpdb;
        
        if ($this->data['id'] ?? false) {
            // Eliminar archivo físico si existe
            if (!empty($this->data['archivo'])) {
                $upload_dir = wp_upload_dir();
                $file_path = $upload_dir['basedir'] . '/asociacion-civil/' . $this->data['archivo'];
                if (file_exists($file_path)) {
                    unlink($file_path);
                }
            }
            
            return $wpdb->delete(
                "{$wpdb->prefix}ac_documentos",
                array('id' => $this->data['id'])
            );
        }
        return false;
    }
    
    public function subirArchivo($archivo) {
        if (!function_exists('wp_handle_upload')) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
        }
        
        $upload_dir = wp_upload_dir();
        $plugin_dir = $upload_dir['basedir'] . '/asociacion-civil/';
        $plugin_url = $upload_dir['baseurl'] . '/asociacion-civil/';
        
        // Crear directorio si no existe
        if (!file_exists($plugin_dir)) {
            wp_mkdir_p($plugin_dir);
        }
        
        // Validar tipo de archivo
        $tipos_permitidos = array(
            'pdf' => 'application/pdf',
            'doc' => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xls' => 'application/vnd.ms-excel',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        );
        
        $file_info = wp_check_filetype($archivo['name']);
        if (!in_array($file_info['type'], $tipos_permitidos)) {
            return new \WP_Error('tipo_invalido', 'Tipo de archivo no permitido');
        }
        
        // Validar tamaño (máximo 10MB)
        if ($archivo['size'] > 10 * 1024 * 1024) {
            return new \WP_Error('tamano_excedido', 'El archivo excede el tamaño máximo permitido (10MB)');
        }
        
        // Generar nombre único
        $nombre_archivo = sanitize_file_name($archivo['name']);
        $nombre_archivo = wp_unique_filename($plugin_dir, $nombre_archivo);
        
        // Mover archivo
        if (move_uploaded_file($archivo['tmp_name'], $plugin_dir . $nombre_archivo)) {
            $this->data['archivo'] = $nombre_archivo;
            return $plugin_url . $nombre_archivo;
        }
        
        return new \WP_Error('error_subida', 'Error al subir el archivo');
    }
    
    // Getters y Setters
    public function setTitulo($titulo) { 
        $this->data['titulo'] = sanitize_text_field($titulo); 
    }
    
    public function setDescripcion($desc) { 
        $this->data['descripcion'] = sanitize_textarea_field($desc); 
    }
    
    public function setTipo($tipo) { 
        $tipos_permitidos = array('acta', 'convocatoria', 'estatuto', 'reglamento', 'informe', 'otros');
        if (in_array($tipo, $tipos_permitidos)) {
            $this->data['tipo'] = $tipo;
        }
    }
    
    public function setArchivo($archivo) { 
        $this->data['archivo'] = sanitize_file_name($archivo); 
    }
    
    public function setFechaDocumento($fecha) { 
        $this->data['fecha_documento'] = sanitize_text_field($fecha); 
    }
    
    public function setCategoria($categoria) { 
        $this->data['categoria'] = sanitize_text_field($categoria); 
    }
    
    public function setVisiblePara($visible) {
        $opciones = array('junta', 'miembros', 'publico');
        if (in_array($visible, $opciones)) {
            $this->data['visible_para'] = $visible;
        }
    }
    
    public function getTitulo() { 
        return $this->data['titulo'] ?? ''; 
    }
    
    public function getDescripcion() { 
        return $this->data['descripcion'] ?? ''; 
    }
    
    public function getTipo() { 
        return $this->data['tipo'] ?? 'otros'; 
    }
    
    public function getArchivo() { 
        return $this->data['archivo'] ?? ''; 
    }
    
    public function getArchivoUrl() {
        if (!empty($this->data['archivo'])) {
            $upload_dir = wp_upload_dir();
            return $upload_dir['baseurl'] . '/asociacion-civil/' . $this->data['archivo'];
        }
        return '';
    }
    
    public function getFechaDocumento() { 
        return $this->data['fecha_documento'] ?? ''; 
    }
    
    public function getFechaDocumentoFormateada() {
        return date('d/m/Y', strtotime($this->data['fecha_documento'] ?? ''));
    }
    
    public function getCategoria() { 
        return $this->data['categoria'] ?? ''; 
    }
    
    public function getVisiblePara() { 
        return $this->data['visible_para'] ?? 'junta'; 
    }
    
    public function toArray() {
        return $this->data;
    }
    
    public function getExtension() {
        $archivo = $this->data['archivo'] ?? '';
        return pathinfo($archivo, PATHINFO_EXTENSION);
    }
    
    public function getTamanoArchivo() {
        if (!empty($this->data['archivo'])) {
            $upload_dir = wp_upload_dir();
            $file_path = $upload_dir['basedir'] . '/asociacion-civil/' . $this->data['archivo'];
            if (file_exists($file_path)) {
                $size = filesize($file_path);
                return size_format($size, 2);
            }
        }
        return '0 B';
    }
}
?>