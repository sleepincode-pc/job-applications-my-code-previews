<?php
/**
 * Clase para gestionar sesiones psicológicas
 * 
 * @package AsociacionCivil
 * @subpackage Sesiones
 */

namespace AsociacionCivil;

class SesionPsicologica {
    
    private $db;
    private $table_name;
    
    public function __construct() {
        global $wpdb;
        $this->db = $wpdb;
        $this->table_name = $wpdb->prefix . 'ac_sesiones_psicologicas';
    }
    
    /**
     * Obtener una sesión por ID
     */
    public function get($id) {
        $sql = $this->db->prepare("SELECT * FROM {$this->table_name} WHERE id = %d", $id);
        return $this->db->get_row($sql);
    }
    
    /**
     * Obtener todas las sesiones de un paciente
     */
    public function get_by_paciente($paciente_id, $limit = null, $offset = 0) {
        $sql = $this->db->prepare("
            SELECT s.*, 
                   m_paciente.nombre as paciente_nombre,
                   m_paciente.apellido as paciente_apellido,
                   m_psicologo.nombre as psicologo_nombre,
                   m_psicologo.apellido as psicologo_apellido
            FROM {$this->table_name} s
            LEFT JOIN {$this->db->prefix}ac_miembros m_paciente ON s.paciente_id = m_paciente.id
            LEFT JOIN {$this->db->prefix}ac_miembros m_psicologo ON s.psicologo_id = m_psicologo.id
            WHERE s.paciente_id = %d
            ORDER BY s.fecha_sesion DESC
        ", $paciente_id);
        
        if ($limit) {
            $sql .= $this->db->prepare(" LIMIT %d OFFSET %d", $limit, $offset);
        }
        
        return $this->db->get_results($sql);
    }
    
    /**
     * Obtener todas las sesiones de un psicólogo
     */
    public function get_by_psicologo($psicologo_id, $limit = null, $offset = 0) {
        $sql = $this->db->prepare("
            SELECT s.*, 
                   m_paciente.nombre as paciente_nombre,
                   m_paciente.apellido as paciente_apellido
            FROM {$this->table_name} s
            LEFT JOIN {$this->db->prefix}ac_miembros m_paciente ON s.paciente_id = m_paciente.id
            WHERE s.psicologo_id = %d
            ORDER BY s.fecha_sesion DESC
        ", $psicologo_id);
        
        if ($limit) {
            $sql .= $this->db->prepare(" LIMIT %d OFFSET %d", $limit, $offset);
        }
        
        return $this->db->get_results($sql);
    }
    
    /**
     * Obtener sesiones por rango de fechas
     */
    public function get_by_fecha($fecha_inicio, $fecha_fin, $psicologo_id = null) {
        $where = "WHERE s.fecha_sesion BETWEEN %s AND %s";
        $params = array($fecha_inicio, $fecha_fin);
        
        if ($psicologo_id) {
            $where .= " AND s.psicologo_id = %d";
            $params[] = $psicologo_id;
        }
        
        $sql = $this->db->prepare("
            SELECT s.*, 
                   m_paciente.nombre as paciente_nombre,
                   m_paciente.apellido as paciente_apellido,
                   m_psicologo.nombre as psicologo_nombre,
                   m_psicologo.apellido as psicologo_apellido
            FROM {$this->table_name} s
            LEFT JOIN {$this->db->prefix}ac_miembros m_paciente ON s.paciente_id = m_paciente.id
            LEFT JOIN {$this->db->prefix}ac_miembros m_psicologo ON s.psicologo_id = m_psicologo.id
            {$where}
            ORDER BY s.fecha_sesion DESC
        ", $params);
        
        return $this->db->get_results($sql);
    }
    
    /**
     * Crear una nueva sesión
     */
    public function create($data) {
        $defaults = array(
            'paciente_id' => 0,
            'psicologo_id' => 0,
            'fecha_sesion' => current_time('mysql'),
            'duracion' => 60,
            'tipo_sesion' => 'individual',
            'motivo_consulta' => '',
            'contenido_sesion' => '',
            'observaciones' => '',
            'estado' => 'completada',
            'proxima_sesion' => null,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        );
        
        $data = wp_parse_args($data, $defaults);
        
        // Validar datos requeridos
        if (empty($data['paciente_id']) || empty($data['psicologo_id'])) {
            return new \WP_Error('missing_data', 'Paciente y psicólogo son requeridos');
        }
        
        // Sanitizar datos
        $sanitized_data = array(
            'paciente_id' => absint($data['paciente_id']),
            'psicologo_id' => absint($data['psicologo_id']),
            'fecha_sesion' => sanitize_text_field($data['fecha_sesion']),
            'duracion' => absint($data['duracion']),
            'tipo_sesion' => sanitize_text_field($data['tipo_sesion']),
            'motivo_consulta' => wp_kses_post($data['motivo_consulta']),
            'contenido_sesion' => wp_kses_post($data['contenido_sesion']),
            'observaciones' => wp_kses_post($data['observaciones']),
            'estado' => sanitize_text_field($data['estado']),
            'proxima_sesion' => $data['proxima_sesion'] ? sanitize_text_field($data['proxima_sesion']) : null,
            'created_at' => $data['created_at'],
            'updated_at' => $data['updated_at']
        );
        
        $result = $this->db->insert($this->table_name, $sanitized_data);
        
        if ($result) {
            return $this->db->insert_id;
        }
        
        return new \WP_Error('db_error', 'Error al crear la sesión psicológica');
    }
    
    /**
     * Actualizar una sesión existente
     */
    public function update($id, $data) {
        $session = $this->get($id);
        if (!$session) {
            return new \WP_Error('not_found', 'Sesión no encontrada');
        }
        
        // Sanitizar datos
        $sanitized_data = array();
        
        if (isset($data['paciente_id'])) {
            $sanitized_data['paciente_id'] = absint($data['paciente_id']);
        }
        
        if (isset($data['psicologo_id'])) {
            $sanitized_data['psicologo_id'] = absint($data['psicologo_id']);
        }
        
        if (isset($data['fecha_sesion'])) {
            $sanitized_data['fecha_sesion'] = sanitize_text_field($data['fecha_sesion']);
        }
        
        if (isset($data['duracion'])) {
            $sanitized_data['duracion'] = absint($data['duracion']);
        }
        
        if (isset($data['tipo_sesion'])) {
            $sanitized_data['tipo_sesion'] = sanitize_text_field($data['tipo_sesion']);
        }
        
        if (isset($data['motivo_consulta'])) {
            $sanitized_data['motivo_consulta'] = wp_kses_post($data['motivo_consulta']);
        }
        
        if (isset($data['contenido_sesion'])) {
            $sanitized_data['contenido_sesion'] = wp_kses_post($data['contenido_sesion']);
        }
        
        if (isset($data['observaciones'])) {
            $sanitized_data['observaciones'] = wp_kses_post($data['observaciones']);
        }
        
        if (isset($data['estado'])) {
            $sanitized_data['estado'] = sanitize_text_field($data['estado']);
        }
        
        if (isset($data['proxima_sesion'])) {
            $sanitized_data['proxima_sesion'] = $data['proxima_sesion'] ? sanitize_text_field($data['proxima_sesion']) : null;
        }
        
        $sanitized_data['updated_at'] = current_time('mysql');
        
        $result = $this->db->update(
            $this->table_name,
            $sanitized_data,
            array('id' => $id)
        );
        
        if ($result !== false) {
            return true;
        }
        
        return new \WP_Error('db_error', 'Error al actualizar la sesión psicológica');
    }
    
    /**
     * Eliminar una sesión
     */
    public function delete($id) {
        $session = $this->get($id);
        if (!$session) {
            return new \WP_Error('not_found', 'Sesión no encontrada');
        }
        
        $result = $this->db->delete($this->table_name, array('id' => $id));
        
        if ($result) {
            return true;
        }
        
        return new \WP_Error('db_error', 'Error al eliminar la sesión psicológica');
    }
    
    /**
     * Obtener estadísticas de sesiones
     */
    public function get_estadisticas($psicologo_id = null, $mes = null, $ano = null) {
        $where = "WHERE 1=1";
        $params = array();
        
        if ($psicologo_id) {
            $where .= " AND psicologo_id = %d";
            $params[] = $psicologo_id;
        }
        
        if ($mes && $ano) {
            $where .= " AND YEAR(fecha_sesion) = %d AND MONTH(fecha_sesion) = %d";
            $params[] = $ano;
            $params[] = $mes;
        }
        
        $sql = $this->db->prepare("
            SELECT 
                COUNT(*) as total_sesiones,
                AVG(duracion) as duracion_promedio,
                COUNT(DISTINCT paciente_id) as pacientes_unicos,
                SUM(CASE WHEN estado = 'completada' THEN 1 ELSE 0 END) as sesiones_completadas,
                SUM(CASE WHEN estado = 'cancelada' THEN 1 ELSE 0 END) as sesiones_canceladas,
                SUM(CASE WHEN estado = 'programada' THEN 1 ELSE 0 END) as sesiones_programadas
            FROM {$this->table_name}
            {$where}
        ", $params);
        
        return $this->db->get_row($sql);
    }
    
    /**
     * Obtener próximas sesiones programadas
     */
    public function get_proximas_sesiones($dias = 7, $psicologo_id = null) {
        $fecha_limite = date('Y-m-d H:i:s', strtotime("+{$dias} days"));
        
        $where = "WHERE (proxima_sesion IS NOT NULL AND proxima_sesion <= %s) OR (estado = 'programada' AND fecha_sesion <= %s)";
        $params = array($fecha_limite, $fecha_limite);
        
        if ($psicologo_id) {
            $where .= " AND psicologo_id = %d";
            $params[] = $psicologo_id;
        }
        
        $sql = $this->db->prepare("
            SELECT s.*, 
                   m_paciente.nombre as paciente_nombre,
                   m_paciente.apellido as paciente_apellido,
                   m_psicologo.nombre as psicologo_nombre,
                   m_psicologo.apellido as psicologo_apellido
            FROM {$this->table_name} s
            LEFT JOIN {$this->db->prefix}ac_miembros m_paciente ON s.paciente_id = m_paciente.id
            LEFT JOIN {$this->db->prefix}ac_miembros m_psicologo ON s.psicologo_id = m_psicologo.id
            {$where}
            ORDER BY COALESCE(proxima_sesion, fecha_sesion) ASC
        ", $params);
        
        return $this->db->get_results($sql);
    }
    
    /**
     * Buscar sesiones por término
     */
    public function search($term, $limit = 50, $offset = 0) {
        $term = '%' . $this->db->esc_like($term) . '%';
        
        $sql = $this->db->prepare("
            SELECT s.*, 
                   m_paciente.nombre as paciente_nombre,
                   m_paciente.apellido as paciente_apellido,
                   m_psicologo.nombre as psicologo_nombre,
                   m_psicologo.apellido as psicologo_apellido
            FROM {$this->table_name} s
            LEFT JOIN {$this->db->prefix}ac_miembros m_paciente ON s.paciente_id = m_paciente.id
            LEFT JOIN {$this->db->prefix}ac_miembros m_psicologo ON s.psicologo_id = m_psicologo.id
            WHERE m_paciente.nombre LIKE %s 
               OR m_paciente.apellido LIKE %s
               OR m_psicologo.nombre LIKE %s
               OR m_psicologo.apellido LIKE %s
               OR s.motivo_consulta LIKE %s
               OR s.contenido_sesion LIKE %s
               OR s.observaciones LIKE %s
            ORDER BY s.fecha_sesion DESC
            LIMIT %d OFFSET %d
        ", $term, $term, $term, $term, $term, $term, $term, $limit, $offset);
        
        return $this->db->get_results($sql);
    }
    
    /**
     * Obtener tipos de sesión disponibles
     */
    public function get_tipos_sesion() {
        return array(
            'individual' => 'Sesión Individual',
            'pareja' => 'Terapia de Pareja',
            'familiar' => 'Terapia Familiar',
            'grupal' => 'Terapia Grupal',
            'evaluacion' => 'Evaluación Psicológica',
            'seguimiento' => 'Seguimiento'
        );
    }
    
    /**
     * Obtener estados disponibles
     */
    public function get_estados() {
        return array(
            'programada' => 'Programada',
            'completada' => 'Completada',
            'cancelada' => 'Cancelada',
            'reprogramada' => 'Reprogramada'
        );
    }
    
    /**
     * Validar datos de sesión
     */
    public function validar_datos($data) {
        $errors = array();
        
        if (empty($data['paciente_id'])) {
            $errors[] = 'El paciente es requerido';
        }
        
        if (empty($data['psicologo_id'])) {
            $errors[] = 'El psicólogo es requerido';
        }
        
        if (empty($data['fecha_sesion'])) {
            $errors[] = 'La fecha de sesión es requerida';
        }
        
        if (empty($data['tipo_sesion'])) {
            $errors[] = 'El tipo de sesión es requerido';
        }
        
        return $errors;
    }
    
    /**
     * Generar reporte de sesiones
     */
    public function generar_reporte($fecha_inicio, $fecha_fin, $psicologo_id = null) {
        $sesiones = $this->get_by_fecha($fecha_inicio, $fecha_fin, $psicologo_id);
        $estadisticas = $this->get_estadisticas($psicologo_id);
        
        return array(
            'sesiones' => $sesiones,
            'estadisticas' => $estadisticas,
            'periodo' => array(
                'inicio' => $fecha_inicio,
                'fin' => $fecha_fin
            )
        );
    }
}