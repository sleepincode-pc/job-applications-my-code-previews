<?php

class SesionPsicologica {
    private $id;
    private $paciente_id;
    private $psicologo_id;
    private $fecha_sesion;
    private $duracion;
    private $tipo_sesion;
    private $motivo_consulta;
    private $contenido_sesion;
    private $observaciones;
    private $estado;
    private $proxima_sesion;
    private $fecha_creacion;
    private $fecha_actualizacion;
    
    // Objetos relacionados
    private $paciente;
    private $psicologo;

    public function __construct($data = array()) {
        if (!empty($data)) {
            $this->id = $data['id'] ?? null;
            $this->paciente_id = $data['paciente_id'] ?? null;
            $this->psicologo_id = $data['psicologo_id'] ?? null;
            $this->fecha_sesion = $data['fecha_sesion'] ?? null;
            $this->duracion = $data['duracion'] ?? 50;
            $this->tipo_sesion = $data['tipo_sesion'] ?? 'Individual';
            $this->motivo_consulta = $data['motivo_consulta'] ?? '';
            $this->contenido_sesion = $data['contenido_sesion'] ?? '';
            $this->observaciones = $data['observaciones'] ?? '';
            $this->estado = $data['estado'] ?? 'completada';
            $this->proxima_sesion = $data['proxima_sesion'] ?? null;
            $this->fecha_creacion = $data['fecha_creacion'] ?? current_time('mysql');
            $this->fecha_actualizacion = $data['fecha_actualizacion'] ?? current_time('mysql');
        }
    }

    // Getters
    public function getId() {
        return $this->id;
    }

    public function getPacienteId() {
        return $this->paciente_id;
    }

    public function getPsicologoId() {
        return $this->psicologo_id;
    }

    public function getFechaSesion() {
        return $this->fecha_sesion;
    }

    public function getDuracion() {
        return $this->duracion;
    }

    public function getTipoSesion() {
        return $this->tipo_sesion;
    }

    public function getMotivoConsulta() {
        return $this->motivo_consulta;
    }

    public function getContenidoSesion() {
        return $this->contenido_sesion;
    }

    public function getObservaciones() {
        return $this->observaciones;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getProximaSesion() {
        return $this->proxima_sesion;
    }

    public function getFechaCreacion() {
        return $this->fecha_creacion;
    }

    public function getFechaActualizacion() {
        return $this->fecha_actualizacion;
    }

    // Setters
    public function setId($id) {
        $this->id = $id;
        return $this;
    }

    public function setPacienteId($paciente_id) {
        $this->paciente_id = $paciente_id;
        return $this;
    }

    public function setPsicologoId($psicologo_id) {
        $this->psicologo_id = $psicologo_id;
        return $this;
    }

    public function setFechaSesion($fecha_sesion) {
        $this->fecha_sesion = $fecha_sesion;
        return $this;
    }

    public function setDuracion($duracion) {
        $this->duracion = $duracion;
        return $this;
    }

    public function setTipoSesion($tipo_sesion) {
        $this->tipo_sesion = $tipo_sesion;
        return $this;
    }

    public function setMotivoConsulta($motivo_consulta) {
        $this->motivo_consulta = $motivo_consulta;
        return $this;
    }

    public function setContenidoSesion($contenido_sesion) {
        $this->contenido_sesion = $contenido_sesion;
        return $this;
    }

    public function setObservaciones($observaciones) {
        $this->observaciones = $observaciones;
        return $this;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
        return $this;
    }

    public function setProximaSesion($proxima_sesion) {
        $this->proxima_sesion = $proxima_sesion;
        return $this;
    }

    // Métodos para objetos relacionados
    public function setPaciente($paciente) {
        $this->paciente = $paciente;
        return $this;
    }

    public function getPaciente() {
        return $this->paciente;
    }

    public function setPsicologo($psicologo) {
        $this->psicologo = $psicologo;
        return $this;
    }

    public function getPsicologo() {
        return $this->psicologo;
    }

    // Métodos para obtener datos relacionados (para compatibilidad con el template)
    public function getPacienteNombre() {
        if ($this->paciente && method_exists($this->paciente, 'getNombreCompleto')) {
            return $this->paciente->getNombreCompleto();
        }
        return 'Paciente no encontrado';
    }

    public function getPacienteNombreCompleto() {
        return $this->getPacienteNombre();
    }

    public function getPacienteApellido() {
        if ($this->paciente && method_exists($this->paciente, 'getApellido')) {
            return $this->paciente->getApellido();
        }
        return '';
    }

    public function getPacienteCedula() {
        if ($this->paciente && method_exists($this->paciente, 'getCedula')) {
            return $this->paciente->getCedula();
        }
        return '';
    }

    public function getPacienteFoto() {
        if ($this->paciente && method_exists($this->paciente, 'getFoto')) {
            return $this->paciente->getFoto();
        }
        return '';
    }

    public function getPsicologoNombre() {
        if ($this->psicologo && method_exists($this->psicologo, 'getNombreCompleto')) {
            return $this->psicologo->getNombreCompleto();
        }
        return 'Psicólogo no asignado';
    }

    // Métodos de utilidad
    public function toArray() {
        return [
            'id' => $this->id,
            'paciente_id' => $this->paciente_id,
            'psicologo_id' => $this->psicologo_id,
            'fecha_sesion' => $this->fecha_sesion,
            'duracion' => $this->duracion,
            'tipo_sesion' => $this->tipo_sesion,
            'motivo_consulta' => $this->motivo_consulta,
            'contenido_sesion' => $this->contenido_sesion,
            'observaciones' => $this->observaciones,
            'estado' => $this->estado,
            'proxima_sesion' => $this->proxima_sesion,
            'fecha_creacion' => $this->fecha_creacion,
            'fecha_actualizacion' => $this->fecha_actualizacion
        ];
    }

    public function validate() {
        $errors = [];

        if (empty($this->paciente_id)) {
            $errors[] = 'El paciente es requerido';
        }

        if (empty($this->psicologo_id)) {
            $errors[] = 'El psicólogo es requerido';
        }

        if (empty($this->fecha_sesion)) {
            $errors[] = 'La fecha de sesión es requerida';
        }

        if (empty($this->duracion) || $this->duracion <= 0) {
            $errors[] = 'La duración debe ser mayor a 0';
        }

        if (empty($this->tipo_sesion)) {
            $errors[] = 'El tipo de sesión es requerido';
        }

        if (empty($this->estado)) {
            $errors[] = 'El estado es requerido';
        }

        return $errors;
    }

    // Métodos estáticos para operaciones comunes
    public static function getEstados() {
        return [
            'completada' => 'Completada',
            'pendiente' => 'Pendiente',
            'cancelada' => 'Cancelada',
            'reprogramada' => 'Reprogramada'
        ];
    }

    public static function getTiposSesion() {
        return [
            'Individual' => 'Individual',
            'Grupal' => 'Grupal',
            'Familiar' => 'Familiar',
            'Evaluación' => 'Evaluación',
            'Seguimiento' => 'Seguimiento',
            'Intervención' => 'Intervención',
            'Terapia' => 'Terapia'
        ];
    }

    public static function getDuracionesPredeterminadas() {
        return [
            30 => '30 minutos',
            45 => '45 minutos',
            50 => '50 minutos',
            60 => '1 hora',
            90 => '1 hora 30 minutos',
            120 => '2 horas'
        ];
    }

    // Método para formatear la fecha de manera legible
    public function getFechaSesionFormateada() {
        if ($this->fecha_sesion) {
            return date('d/m/Y H:i', strtotime($this->fecha_sesion));
        }
        return 'No especificada';
    }

    public function getProximaSesionFormateada() {
        if ($this->proxima_sesion) {
            return date('d/m/Y H:i', strtotime($this->proxima_sesion));
        }
        return 'No programada';
    }

    // Método para verificar si la sesión está vencida
    public function estaVencida() {
        if ($this->estado === 'pendiente' && $this->fecha_sesion) {
            return strtotime($this->fecha_sesion) < current_time('timestamp');
        }
        return false;
    }

    // Método para obtener un resumen del contenido
    public function getResumenContenido($length = 100) {
        if (empty($this->contenido_sesion)) {
            return 'Sin contenido registrado';
        }

        $contenido = strip_tags($this->contenido_sesion);
        if (strlen($contenido) <= $length) {
            return $contenido;
        }

        return substr($contenido, 0, $length) . '...';
    }

    public function getResumenMotivo($length = 100) {
        if (empty($this->motivo_consulta)) {
            return 'Sin motivo especificado';
        }

        $motivo = strip_tags($this->motivo_consulta);
        if (strlen($motivo) <= $length) {
            return $motivo;
        }

        return substr($motivo, 0, $length) . '...';
    }

    // Método para obtener la clase CSS según el estado
    public function getClaseEstado() {
        $clases = [
            'completada' => 'ac-badge-completada',
            'pendiente' => 'ac-badge-pendiente',
            'cancelada' => 'ac-badge-cancelada',
            'reprogramada' => 'ac-badge-reprogramada'
        ];

        return $clases[$this->estado] ?? 'ac-badge-pendiente';
    }

    // Método para obtener la clase CSS según el tipo de sesión
    public function getClaseTipoSesion() {
        $clases = [
            'Individual' => 'ac-badge-individual',
            'Grupal' => 'ac-badge-grupal',
            'Familiar' => 'ac-badge-familiar',
            'Evaluación' => 'ac-badge-evaluacion',
            'Seguimiento' => 'ac-badge-seguimiento',
            'Intervención' => 'ac-badge-intervencion',
            'Terapia' => 'ac-badge-terapia'
        ];

        return $clases[$this->tipo_sesion] ?? 'ac-badge-individual';
    }

    // Método para calcular el tiempo transcurrido desde la creación
    public function getTiempoTranscurrido() {
        if (!$this->fecha_creacion) {
            return '';
        }

        $creacion = strtotime($this->fecha_creacion);
        $ahora = current_time('timestamp');
        $diferencia = $ahora - $creacion;

        if ($diferencia < 60) {
            return 'Hace unos segundos';
        } elseif ($diferencia < 3600) {
            $minutos = floor($diferencia / 60);
            return "Hace $minutos minuto" . ($minutos > 1 ? 's' : '');
        } elseif ($diferencia < 86400) {
            $horas = floor($diferencia / 3600);
            return "Hace $horas hora" . ($horas > 1 ? 's' : '');
        } else {
            $dias = floor($diferencia / 86400);
            return "Hace $dias día" . ($dias > 1 ? 's' : '');
        }
    }
}

// Clase auxiliar para el Psicólogo (si no existe)
class Psicologo {
    private $id;
    private $nombre;
    private $apellido;
    private $especialidad;
    private $email;
    private $telefono;
    private $foto;

    public function __construct($data = array()) {
        if (!empty($data)) {
            $this->id = $data['id'] ?? null;
            $this->nombre = $data['nombre'] ?? '';
            $this->apellido = $data['apellido'] ?? '';
            $this->especialidad = $data['especialidad'] ?? '';
            $this->email = $data['email'] ?? '';
            $this->telefono = $data['telefono'] ?? '';
            $this->foto = $data['foto'] ?? '';
        }
    }

    // Getters
    public function getId() { return $this->id; }
    public function getNombre() { return $this->nombre; }
    public function getApellido() { return $this->apellido; }
    public function getEspecialidad() { return $this->especialidad; }
    public function getEmail() { return $this->email; }
    public function getTelefono() { return $this->telefono; }
    public function getFoto() { return $this->foto; }

    public function getNombreCompleto() {
        return trim($this->nombre . ' ' . $this->apellido);
    }
}

// Si necesitas una clase Paciente básica (asumiendo que no existe)
class Paciente {
    private $id;
    private $nombre;
    private $apellido;
    private $cedula;
    private $fecha_nacimiento;
    private $email;
    private $telefono;
    private $foto;
    private $direccion;
    private $estado;

    public function __construct($data = array()) {
        if (!empty($data)) {
            $this->id = $data['id'] ?? null;
            $this->nombre = $data['nombre'] ?? '';
            $this->apellido = $data['apellido'] ?? '';
            $this->cedula = $data['cedula'] ?? '';
            $this->fecha_nacimiento = $data['fecha_nacimiento'] ?? '';
            $this->email = $data['email'] ?? '';
            $this->telefono = $data['telefono'] ?? '';
            $this->foto = $data['foto'] ?? '';
            $this->direccion = $data['direccion'] ?? '';
            $this->estado = $data['estado'] ?? 'activo';
        }
    }

    // Getters
    public function getId() { return $this->id; }
    public function getNombre() { return $this->nombre; }
    public function getApellido() { return $this->apellido; }
    public function getCedula() { return $this->cedula; }
    public function getFechaNacimiento() { return $this->fecha_nacimiento; }
    public function getEmail() { return $this->email; }
    public function getTelefono() { return $this->telefono; }
    public function getFoto() { return $this->foto; }
    public function getDireccion() { return $this->direccion; }
    public function getEstado() { return $this->estado; }

    public function getNombreCompleto() {
        return trim($this->nombre . ' ' . $this->apellido);
    }

    public function getEdad() {
        if (!$this->fecha_nacimiento) {
            return 'No especificada';
        }

        $nacimiento = new DateTime($this->fecha_nacimiento);
        $hoy = new DateTime();
        $edad = $hoy->diff($nacimiento);
        return $edad->y;
    }
}