<?php

namespace AsociacionCivil;

class Dashboard {
    
    private $database;
    
    public function __construct() {
        $this->database = new Database();
        add_action('wp_dashboard_setup', array($this, 'agregar_widget_dashboard'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_dashboard_scripts'));
    }
    
    public function enqueue_dashboard_scripts($hook) {
        if ($hook === 'index.php') {
            wp_enqueue_style('asociacion-civil-dashboard', ASOCIACION_CIVIL_PLUGIN_URL . 'assets/dashboard-widget.css', array(), ASOCIACION_CIVIL_PLUGIN_VERSION);
            wp_enqueue_script('asociacion-civil-dashboard', ASOCIACION_CIVIL_PLUGIN_URL . 'assets/dashboard-widget.js', array('jquery', 'wp-util'), ASOCIACION_CIVIL_PLUGIN_VERSION, true);
            
            wp_localize_script('asociacion-civil-dashboard', 'ac_dashboard', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('ac_dashboard_nonce'),
                'textos' => array(
                    'cargando' => 'Cargando...',
                    'error' => 'Error al cargar los datos',
                    'ver_todos' => 'Ver todos',
                    'miembros_activos' => 'Miembros activos',
                    'proximos_eventos' => 'Próximos eventos',
                    'documentos_recientes' => 'Documentos recientes'
                )
            ));
        }
    }
    
    public function agregar_widget_dashboard() {
        if (current_user_can('manage_asociacion') || current_user_can('manage_options')) {
            wp_add_dashboard_widget(
                'ac_dashboard_widget',
                'Resumen de la Asociación Civil',
                array($this, 'mostrar_widget_dashboard')
            );
        }
    }
    
    public function mostrar_widget_dashboard() {
        $estadisticas = $this->obtener_estadisticas_rapidas();
        $proximos_eventos = $this->database->get_eventos_proximos(3);
        $documentos_recientes = $this->database->get_documentos_por_tipo('', 3);
        
        ?>
        <div class="ac-dashboard-widget">
            <div class="ac-widget-stats">
                <div class="ac-widget-stat">
                    <span class="ac-stat-icon">👥</span>
                    <div class="ac-stat-info">
                        <span class="ac-stat-number"><?php echo esc_html($estadisticas['miembros_activos']); ?></span>
                        <span class="ac-stat-label">Miembros</span>
                    </div>
                </div>
                <div class="ac-widget-stat">
                    <span class="ac-stat-icon">📅</span>
                    <div class="ac-stat-info">
                        <span class="ac-stat-number"><?php echo esc_html($estadisticas['eventos_proximos']); ?></span>
                        <span class="ac-stat-label">Eventos</span>
                    </div>
                </div>
                <div class="ac-widget-stat">
                    <span class="ac-stat-icon">📋</span>
                    <div class="ac-stat-info">
                        <span class="ac-stat-number"><?php echo esc_html($estadisticas['total_documentos']); ?></span>
                        <span class="ac-stat-label">Documentos</span>
                    </div>
                </div>
            </div>
            
            <?php if (!empty($proximos_eventos)): ?>
                <div class="ac-widget-section">
                    <h3>Próximos Eventos</h3>
                    <div class="ac-widget-event-list">
                        <?php foreach ($proximos_eventos as $evento): ?>
                            <div class="ac-widget-event">
                                <div class="ac-event-date">
                                    <?php echo date('d M', strtotime($evento->fecha)); ?>
                                </div>
                                <div class="ac-event-details">
                                    <strong><?php echo esc_html(wp_trim_words($evento->titulo, 5)); ?></strong>
                                    <div class="ac-event-time">
                                        <?php echo date('H:i', strtotime($evento->fecha)); ?>
                                        <?php if ($evento->lugar): ?>
                                            • <?php echo esc_html(wp_trim_words($evento->lugar, 2)); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($documentos_recientes)): ?>
                <div class="ac-widget-section">
                    <h3>Documentos Recientes</h3>
                    <div class="ac-widget-doc-list">
                        <?php foreach ($documentos_recientes as $doc): ?>
                            <div class="ac-widget-doc">
                                <span class="dashicons dashicons-media-document"></span>
                                <div class="ac-doc-details">
                                    <strong><?php echo esc_html(wp_trim_words($doc->titulo, 4)); ?></strong>
                                    <div class="ac-doc-date">
                                        <?php echo date('d/m/Y', strtotime($doc->fecha_documento)); ?>
                                        • <?php echo esc_html(ucfirst($doc->tipo)); ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <div class="ac-widget-actions">
                <a href="<?php echo admin_url('admin.php?page=asociacion-civil'); ?>" class="button button-primary">
                    Ver Dashboard Completo
                </a>
                <div class="ac-quick-links">
                    <a href="<?php echo admin_url('admin.php?page=ac-miembros&action=nuevo'); ?>">Agregar Miembro</a>
                    <a href="<?php echo admin_url('admin.php?page=ac-eventos&action=nuevo'); ?>">Nuevo Evento</a>
                    <a href="<?php echo admin_url('admin.php?page=ac-documentos&action=nuevo'); ?>">Subir Documento</a>
                </div>
            </div>
        </div>
        <?php
    }
    
    private function obtener_estadisticas_rapidas() {
        return array(
            'miembros_activos' => $this->database->get_total_miembros_activos(),
            'eventos_proximos' => $this->database->get_total_eventos_proximos(),
            'total_documentos' => $this->database->get_total_documentos(),
            'asambleas_pendientes' => $this->database->get_total_asambleas_pendientes()
        );
    }
    
    public function obtener_datos_grafico_miembros() {
        global $wpdb;
        
        $datos = $wpdb->get_results("
            SELECT 
                DATE_FORMAT(fecha_ingreso, '%Y-%m') as mes,
                COUNT(*) as total
            FROM {$wpdb->prefix}ac_miembros 
            WHERE fecha_ingreso >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
            GROUP BY mes
            ORDER BY mes
        ");
        
        return $datos;
    }
    
    public function obtener_estadisticas_avanzadas() {
        $estadisticas = array(
            'miembros_por_tipo' => $this->obtener_miembros_por_tipo(),
            'eventos_por_mes' => $this->obtener_eventos_por_mes(),
            'documentos_por_tipo' => $this->obtener_documentos_por_tipo(),
            'asistencia_promedio' => $this->calcular_asistencia_promedio()
        );
        
        return $estadisticas;
    }
    
    private function obtener_miembros_por_tipo() {
        global $wpdb;
        
        return $wpdb->get_results("
            SELECT 
                tipo_membresia,
                COUNT(*) as total
            FROM {$wpdb->prefix}ac_miembros 
            WHERE estado = 'activo'
            GROUP BY tipo_membresia
        ");
    }
    
    private function obtener_eventos_por_mes() {
        global $wpdb;
        
        return $wpdb->get_results("
            SELECT 
                DATE_FORMAT(fecha, '%Y-%m') as mes,
                COUNT(*) as total
            FROM {$wpdb->prefix}ac_eventos 
            WHERE fecha >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
            GROUP BY mes
            ORDER BY mes
        ");
    }
    
    private function obtener_documentos_por_tipo() {
        global $wpdb;
        
        return $wpdb->get_results("
            SELECT 
                tipo,
                COUNT(*) as total
            FROM {$wpdb->prefix}ac_documentos 
            GROUP BY tipo
        ");
    }
    
    private function calcular_asistencia_promedio() {
        global $wpdb;
        
        $eventos_con_asistentes = $wpdb->get_var("
            SELECT COUNT(*) 
            FROM {$wpdb->prefix}ac_eventos 
            WHERE asistentes IS NOT NULL AND asistentes != ''
        ");
        
        if ($eventos_con_asistentes > 0) {
            $total_asistentes = $wpdb->get_var("
                SELECT SUM(
                    LENGTH(asistentes) - LENGTH(REPLACE(asistentes, ',', '')) + 1
                )
                FROM {$wpdb->prefix}ac_eventos 
                WHERE asistentes IS NOT NULL AND asistentes != ''
            ");
            
            return round($total_asistentes / $eventos_con_asistentes, 1);
        }
        
        return 0;
    }
    
    public function generar_reporte_mensual() {
        $mes_actual = date('Y-m');
        $mes_anterior = date('Y-m', strtotime('-1 month'));
        
        $reporte = array(
            'mes_actual' => $mes_actual,
            'nuevos_miembros' => $this->contar_nuevos_miembros($mes_actual),
            'eventos_realizados' => $this->contar_eventos_mes($mes_actual),
            'documentos_subidos' => $this->contar_documentos_mes($mes_actual),
            'comparativa_mes_anterior' => $this->comparar_con_mes_anterior($mes_anterior)
        );
        
        return $reporte;
    }
    
    private function contar_nuevos_miembros($mes) {
        global $wpdb;
        
        return $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*) 
            FROM {$wpdb->prefix}ac_miembros 
            WHERE DATE_FORMAT(fecha_ingreso, '%%Y-%%m') = %s
        ", $mes));
    }
    
    private function contar_eventos_mes($mes) {
        global $wpdb;
        
        return $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*) 
            FROM {$wpdb->prefix}ac_eventos 
            WHERE DATE_FORMAT(fecha, '%%Y-%%m') = %s 
            AND estado = 'realizado'
        ", $mes));
    }
    
    private function contar_documentos_mes($mes) {
        global $wpdb;
        
        return $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*) 
            FROM {$wpdb->prefix}ac_documentos 
            WHERE DATE_FORMAT(fecha_subida, '%%Y-%%m') = %s
        ", $mes));
    }
    
    private function comparar_con_mes_anterior($mes_anterior) {
        $miembros_actual = $this->contar_nuevos_miembros(date('Y-m'));
        $miembros_anterior = $this->contar_nuevos_miembros($mes_anterior);
        
        $eventos_actual = $this->contar_eventos_mes(date('Y-m'));
        $eventos_anterior = $this->contar_eventos_mes($mes_anterior);
        
        return array(
            'miembros' => array(
                'actual' => $miembros_actual,
                'anterior' => $miembros_anterior,
                'variacion' => $miembros_anterior > 0 ? 
                    round((($miembros_actual - $miembros_anterior) / $miembros_anterior) * 100, 1) : 0
            ),
            'eventos' => array(
                'actual' => $eventos_actual,
                'anterior' => $eventos_anterior,
                'variacion' => $eventos_anterior > 0 ? 
                    round((($eventos_actual - $eventos_anterior) / $eventos_anterior) * 100, 1) : 0
            )
        );
    }
}

// ⚠️ ELIMINAR ESTA PARTE DUPLICADA - COMENTAR O BORRAR TODO LO QUE SIGUE ⚠️
// La clase Database ya está definida en Database.php, no debe repetirse aquí
/*
class Database {
    // ... métodos existentes ...
    
    public function get_total_miembros_activos() {
        global $wpdb;
        return $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ac_miembros WHERE estado = 'activo'");
    }
    
    public function get_total_eventos_proximos() {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}ac_eventos WHERE fecha >= %s", current_time('mysql')));
    }
    
    public function get_total_asambleas_pendientes() {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}ac_eventos WHERE tipo = 'asamblea' AND fecha >= %s", current_time('mysql')));
    }
}
*/
?>