<?php
// =============================================
// CLASIFICADOR DE CONTENIDO AUTOMÁTICO - VERSIÓN CORREGIDA
// =============================================
// Clase para clasificar automáticamente el contenido extraído por OCR
// y redirigir a los templates correspondientes
// =============================================

if (!defined('ABSPATH')) {
    exit;
}

class ClasificadorContenido {
    
    // =============================================
    // PALABRAS CLAVE PARA CLASIFICACIÓN - ACTUALIZADAS
    // =============================================
    
    // Palabras clave específicas para sesiones psicológicas
    public static $palabras_clave_psicologia = array(
        // Términos generales de psicología
        'psicología', 'psicólogo', 'psicóloga', 'terapia', 'consulta', 'sesión',
        'paciente', 'cliente', 'usuario', 'consultante', 'tratamiento',
        'intervención', 'evaluación', 'diagnóstico', 'prognóstico',
        
        // Psicodramas y técnicas específicas
        'psicodrama', 'psicodramas', 'roleplaying', 'juego de roles',
        'escenificación', 'dramatización', 'representación',
        'protagonista', 'director', 'yo auxiliar', 'audiencia',
        'calentamiento', 'acción', 'compartir',
        
        // Dinámicas grupales e individuales
        'dinámica', 'dinámicas', 'ejercicio', 'ejercicios', 'técnica',
        'actividad', 'juego', 'simulación', 'role play', 'rol play',
        
        // Términos terapéuticos
        'transferencia', 'contratransferencia', 'insight', 'catarsis',
        'consciencia', 'autoconocimiento', 'proyección', 'identificación',
        'resistencia', 'interpretación', 'asociación libre',
        
        // Emociones y estados
        'ansiedad', 'depresión', 'estrés', 'trauma', 'conflicto',
        'emoción', 'sentimiento', 'affecto', 'estado de ánimo',
        'frustración', 'ira', 'enojo', 'tristeza', 'alegría', 'miedo',
        
        // Procesos psicológicos
        'cognición', 'pensamiento', 'razonamiento', 'memoria', 'atención',
        'percepción', 'aprendizaje', 'motivación', 'inteligencia',
        
        // Áreas de especialidad
        'clínica', 'educativa', 'organizacional', 'forense', 'social',
        'comunitaria', 'salud mental', 'bienestar emocional',
        
        // Técnicas y enfoques
        'cognitivo', 'conductual', 'humanista', 'psicoanalítico',
        'sistémico', 'gestalt', 'existencial', 'centrado en soluciones',
        
        // Solo por hoy (término específico solicitado)
        'solo por hoy', 'por hoy', 'hoy trabajo', 'hoy focalizaremos',
        
        // Términos de proceso
        'proceso terapéutico', 'proceso de cambio', 'evolución',
        'mejoría', 'avance', 'retroceso', 'estancamiento',
        
        // Términos adicionales para mejor detección
        'historial clínico', 'nota de evolución', 'progreso del paciente',
        'evaluación psicológica', 'pruebas psicológicas', 'test psicológico'
    );
    
    // Palabras clave específicas para actas de reunión
    public static $palabras_clave_actas = array(
        // Términos generales de reuniones
        'reunión', 'asamblea', 'junta', 'consejo', 'comité', 'comisión',
        'sesión', 'convocatoria', 'convocar', 'convocado', 'convocantes',
        
        // Estructura de actas
        'acta', 'orden del día', 'punto del día', 'agenda', 'temario',
        'asistentes', 'presentes', 'ausentes', 'excusa', 'justificación',
        
        // Desarrolllo de reuniones
        'discusión', 'debate', 'deliberación', 'análisis', 'propuesta',
        'moción', 'votación', 'votar', 'aprobación', 'rechazo',
        'unánime', 'mayoría', 'minoría', 'abstención',
        
        // Acuerdos y decisiones
        'acuerdo', 'acuerdos', 'decisión', 'resolución', 'determinación',
        'conclusión', 'resultado', 'fallo', 'veredicto',
        
        // Entradas y salidas (términos específicos solicitados)
        'entrada', 'entradas', 'salida', 'salidas', 'ingreso', 'egreso',
        'llegada', 'partida', 'incorporación', 'retiro',
        
        // Documentación y formalidades
        'firma', 'firmado', 'secretario', 'presidente', 'vocal',
        'testigo', 'certifica', 'consta', 'certificado',
        
        // Tiempos y lugares
        'convocado para', 'celebrado en', 'lugar', 'fecha', 'hora',
        'inicio', 'final', 'duración', 'adjourn', 'clausura',
        
        // Tipos de reuniones
        'ordinaria', 'extraordinaria', 'urgente', 'emergencia',
        'planificación', 'seguimiento', 'evaluación',
        
        // Términos adicionales
        'minuta', 'resumen ejecutivo', 'puntos tratados', 'acuerdos tomados',
        'lista de asistencia', 'quórum', 'votaciones', 'resultado de votación'
    );
    
    // Palabras clave específicas para psicodramas
    public static $palabras_clave_psicodramas = array(
        'psicodrama', 'psicodramas', 'moreno', 'escenario', 'escena',
        'doble', 'espejo', 'soliloquio', 'inversión de roles',
        'proyección al futuro', 'silla vacía', 'auxiliares yo',
        'caldeamiento', 'catarsis', 'integración', 'compartir',
        'testimonio', 'cura', 'espontaneidad', 'creatividad',
        'protagonista', 'director', 'yo auxiliar', 'audiencia',
        'roleplaying', 'juego de roles', 'dramatización',
        'técnicas psicodramáticas', 'escenificación terapéutica'
    );
    
    // Palabras clave para pacientes
    public static $palabras_clave_pacientes = array(
        'paciente', 'historial médico', 'diagnóstico', 'tratamiento',
        'medicación', 'síntomas', 'evolución', 'progreso',
        'ficha médica', 'antecedentes', 'alergias', 'prescripción',
        'cita médica', 'control', 'seguimiento médico',
        'expediente médico', 'historia clínica', 'signos vitales'
    );
    
    // Palabras clave para notas judiciales
    public static $palabras_clave_judiciales = array(
        'tribunal', 'juez', 'fiscal', 'abogado', 'demanda',
        'sentencia', 'audiencia', 'proceso judicial', 'testigo',
        'prueba', 'fallo', 'apelación', 'jurídico', 'legal',
        'nota judicial', 'diligencia', 'auto', 'juzgado',
        'procedimiento legal', 'abogado defensor', 'ministerio público'
    );
    
    // Palabras clave para miembros
    public static $palabras_clave_miembros = array(
        'miembro', 'socio', 'asociado', 'directiva', 'asamblea',
        'cuota', 'membresía', 'admisión', 'baja', 'renovación',
        'cargo', 'elección', 'estatutos', 'reglamento',
        'directorio', 'comité ejecutivo', 'votación de miembros'
    );
    
    // Palabras clave para documentos
    public static $palabras_clave_documentos = array(
        'documento', 'archivo', 'expediente', 'registro', 'certificado',
        'informe', 'acta', 'contrato', 'convenio', 'acuerdo',
        'oficio', 'memorándum', 'circular', 'resolución',
        'oficial', 'formal', 'protocolo', 'normativa'
    );
    
    // =============================================
    // MÉTODOS PRINCIPALES DE CLASIFICACIÓN
    // =============================================
    
    /**
     * Clasifica el contenido y determina el template destino
     */
    public static function clasificarYRedirigirContenido($texto) {
        $puntuaciones = array(
            'psicodramas' => self::calcularPuntuacionPsicodramas($texto),
            'sesiones-psicologicas' => self::calcularPuntuacionSesiones($texto),
            'pacientes' => self::calcularPuntuacionPacientes($texto),
            'notas-judiciales' => self::calcularPuntuacionJudiciales($texto),
            'historial-medico' => self::calcularPuntuacionHistorialMedico($texto),
            'miembros' => self::calcularPuntuacionMiembros($texto),
            'seguimiento-terapeutico' => self::calcularPuntuacionSeguimiento($texto),
            'documentos' => self::calcularPuntuacionDocumentos($texto),
            'actas' => self::calcularPuntuacionActas($texto)
        );
        
        // Encontrar el tipo con mayor puntuación
        $max_puntuacion = max($puntuaciones);
        $tipo_principal = array_search($max_puntuacion, $puntuaciones);
        
        // Si hay empate, priorizar ciertos tipos
        if ($max_puntuacion > 0) {
            $tipos_empatados = array_keys($puntuaciones, $max_puntuacion);
            if (count($tipos_empatados) > 1) {
                // Prioridad: sesiones psicológicas > actas > otros
                if (in_array('sesiones-psicologicas', $tipos_empatados)) {
                    $tipo_principal = 'sesiones-psicologicas';
                } elseif (in_array('actas', $tipos_empatados)) {
                    $tipo_principal = 'actas';
                }
            }
        }
        
        $confianza = self::calcularConfianzaCombinada($puntuaciones);
        
        return array(
            'tipo_principal' => $tipo_principal,
            'confianza' => $confianza,
            'destino' => $tipo_principal,
            'puntuaciones' => $puntuaciones,
            'redireccion_automatica' => $confianza > 70 // Reducido a 70% para más sensibilidad
        );
    }
    
    // =============================================
    // MÉTODOS DE CÁLCULO DE PUNTUACIONES ESPECÍFICAS
    // =============================================
    
    private static function calcularPuntuacionPsicodramas($texto) {
        return self::calcularPuntuacionBase($texto, self::$palabras_clave_psicodramas, 3);
    }
    
    private static function calcularPuntuacionSesiones($texto) {
        return self::calcularPuntuacionBase($texto, self::$palabras_clave_psicologia, 2);
    }
    
    private static function calcularPuntuacionPacientes($texto) {
        return self::calcularPuntuacionBase($texto, self::$palabras_clave_pacientes, 2);
    }
    
    private static function calcularPuntuacionJudiciales($texto) {
        return self::calcularPuntuacionBase($texto, self::$palabras_clave_judiciales, 3);
    }
    
    private static function calcularPuntuacionHistorialMedico($texto) {
        $puntuacion = self::calcularPuntuacionBase($texto, self::$palabras_clave_pacientes, 2);
        // Términos específicos de historial médico
        $terminos_especificos = array(
            'historial médico', 'antecedentes familiares', 'enfermedades previas', 
            'cirugías', 'hospitalizaciones', 'medicamentos actuales',
            'exámenes de laboratorio', 'resultados de exámenes'
        );
        $texto_minusculas = mb_strtolower($texto, 'UTF-8');
        
        foreach ($terminos_especificos as $termino) {
            if (strpos($texto_minusculas, $termino) !== false) {
                $puntuacion += 3;
            }
        }
        
        return $puntuacion;
    }
    
    private static function calcularPuntuacionMiembros($texto) {
        return self::calcularPuntuacionBase($texto, self::$palabras_clave_miembros, 2);
    }
    
    private static function calcularPuntuacionSeguimiento($texto) {
        $puntuacion = self::calcularPuntuacionBase($texto, self::$palabras_clave_psicologia, 1);
        // Términos específicos de seguimiento
        $terminos_especificos = array(
            'seguimiento', 'progreso', 'evolución', 'mejoría', 'control', 
            'evaluación continua', 'sesión de seguimiento', 'control terapéutico'
        );
        $texto_minusculas = mb_strtolower($texto, 'UTF-8');
        
        foreach ($terminos_especificos as $termino) {
            if (strpos($texto_minusculas, $termino) !== false) {
                $puntuacion += 2;
            }
        }
        
        return $puntuacion;
    }
    
    private static function calcularPuntuacionDocumentos($texto) {
        return self::calcularPuntuacionBase($texto, self::$palabras_clave_documentos, 1);
    }
    
    private static function calcularPuntuacionActas($texto) {
        $puntuacion_base = self::calcularPuntuacionBase($texto, self::$palabras_clave_actas, 1);
        
        // Bonus por estructura de acta
        $texto_minusculas = mb_strtolower($texto, 'UTF-8');
        $patrones_acta = array(
            'orden del día', 'punto del día', 'lista de asistentes',
            'acuerdos tomados', 'firma del secretario', 'firma del presidente'
        );
        
        foreach ($patrones_acta as $patron) {
            if (strpos($texto_minusculas, $patron) !== false) {
                $puntuacion_base += 2;
            }
        }
        
        return $puntuacion_base;
    }
    
    private static function calcularPuntuacionBase($texto, $palabras_clave, $peso_base = 1) {
        $texto_minusculas = mb_strtolower($texto, 'UTF-8');
        $puntuacion = 0;
        
        foreach ($palabras_clave as $palabra) {
            // Buscar la palabra completa para evitar coincidencias parciales no deseadas
            $pos = strpos($texto_minusculas, $palabra);
            if ($pos !== false) {
                // Verificar que es una palabra completa (no parte de otra palabra)
                $antes = $pos > 0 ? $texto_minusculas[$pos - 1] : ' ';
                $despues = $pos + strlen($palabra) < strlen($texto_minusculas) ? $texto_minusculas[$pos + strlen($palabra)] : ' ';
                
                if (!ctype_alpha($antes) && !ctype_alpha($despues)) {
                    $puntuacion += $peso_base;
                }
            }
        }
        
        return $puntuacion;
    }
    
    private static function calcularConfianzaCombinada($puntuaciones) {
        $total = array_sum($puntuaciones);
        if ($total == 0) return 0;
        
        $max_puntuacion = max($puntuaciones);
        $confianza_base = ($max_puntuacion / $total) * 100;
        
        // Ajustar por diferencia con la segunda puntuación más alta
        arsort($puntuaciones);
        $puntuaciones_ordenadas = array_values($puntuaciones);
        
        if (count($puntuaciones_ordenadas) > 1 && $puntuaciones_ordenadas[0] > 0) {
            $diferencia = $puntuaciones_ordenadas[0] - $puntuaciones_ordenadas[1];
            $ajuste_diferencia = ($diferencia / $puntuaciones_ordenadas[0]) * 30;
            $confianza_base += $ajuste_diferencia;
        }
        
        // Ajuste por cantidad de palabras encontradas
        $total_palabras = array_sum($puntuaciones);
        if ($total_palabras > 10) {
            $confianza_base += min(10, ($total_palabras - 10) * 0.5);
        }
        
        return min(100, max(0, round($confianza_base)));
    }
    
    // =============================================
    // MÉTODOS DE REDIRECCIÓN Y DESTINO - ACTUALIZADOS
    // =============================================
    
    /**
     * Obtiene la URL de destino para el template específico
     */
    public static function obtenerUrlDestino($template, $texto_extraido = '') {
        $texto_codificado = $texto_extraido ? '&texto=' . urlencode(base64_encode($texto_extraido)) : '';
        
        // Mapeo de templates a URLs de administración - CORREGIDO
        $mapeo_templates = array(
            'psicodramas' => 'ac-psicodramas',
            'sesiones-psicologicas' => 'ac-sesiones', // Corregido: era 'ac-sesiones-psicologicas'
            'pacientes' => 'ac-pacientes',
            'notas-judiciales' => 'ac-notas-judiciales',
            'historial-medico' => 'ac-historial-medico',
            'miembros' => 'ac-miembros',
            'seguimiento-terapeutico' => 'ac-seguimiento-terapeutico',
            'documentos' => 'ac-documentos',
            'actas' => 'ac-libro-actas'
        );
        
        $page_slug = $mapeo_templates[$template] ?? 'ac-libro-actas';
        
        return admin_url("admin.php?page={$page_slug}&ocr_clasificado=1{$texto_codificado}");
    }
    
    /**
     * Procesa OCR y redirige automáticamente si es necesario
     */
    public static function procesarOCRyRedirigir($texto_ocr) {
        $resultado = self::clasificarYRedirigirContenido($texto_ocr);
        
        // Si hay redirección automática y confianza alta, redirigir
        if ($resultado['redireccion_automatica']) {
            $url_destino = self::obtenerUrlDestino($resultado['destino'], $texto_ocr);
            
            // Mostrar mensaje de redirección
            echo '<div class="notice notice-info">';
            echo '<p>🎯 <strong>Clasificación Automática Detectada</strong></p>';
            echo '<p>El contenido se ha identificado como <strong>' . self::obtenerNombreTemplate($resultado['tipo_principal']) . '</strong> con ' . $resultado['confianza'] . '% de confianza.</p>';
            echo '<p>Redirigiendo automáticamente al módulo correspondiente...</p>';
            echo '</div>';
            
            echo '<script>
                setTimeout(function() {
                    window.location.href = "' . esc_url($url_destino) . '";
                }, 3000);
            </script>';
            
            return true;
        }
        
        return false;
    }
    
    /**
     * Obtiene nombre legible del template - ACTUALIZADO
     */
    public static function obtenerNombreTemplate($template) {
        $nombres = array(
            'psicodramas' => 'Psicodrama',
            'sesiones-psicologicas' => 'Sesión Psicológica', // Corregido
            'pacientes' => 'Paciente',
            'notas-judiciales' => 'Nota Judicial',
            'historial-medico' => 'Historial Médico',
            'miembros' => 'Miembro',
            'seguimiento-terapeutico' => 'Seguimiento Terapéutico',
            'documentos' => 'Documento',
            'actas' => 'Acta de Reunión'
        );
        
        return $nombres[$template] ?? 'Contenido';
    }
    
    /**
     * Obtiene icono para el template
     */
    public static function obtenerIconoTemplate($template) {
        $iconos = array(
            'psicodramas' => '🎭',
            'sesiones-psicologicas' => '🛋️',
            'pacientes' => '👤',
            'notas-judiciales' => '⚖️',
            'historial-medico' => '🏥',
            'miembros' => '👥',
            'seguimiento-terapeutico' => '📊',
            'documentos' => '📄',
            'actas' => '📋'
        );
        
        return $iconos[$template] ?? '📄';
    }
    
    // =============================================
    // MÉTODOS DE ANÁLISIS DETALLADO
    // =============================================
    
    /**
     * Genera reporte completo de clasificación
     */
    public static function generarReporteClasificacion($texto) {
        $resultado = self::clasificarYRedirigirContenido($texto);
        
        $html = '<div class="ac-reporte-clasificacion" style="border: 1px solid #ddd; padding: 20px; border-radius: 8px; background: #f9f9f9; margin-bottom: 20px;">';
        $html .= '<h4 style="margin-top: 0; color: #0073aa;">🎯 Análisis de Clasificación Automática</h4>';
        
        // Información principal
        $html .= '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">';
        
        $html .= '<div style="background: white; padding: 15px; border-radius: 6px; border-left: 4px solid #0073aa;">';
        $html .= '<h5 style="margin: 0 0 10px 0; color: #0073aa;">Clasificación Principal</h5>';
        $html .= '<div style="display: flex; align-items: center; gap: 10px;">';
        $html .= '<span style="font-size: 24px;">' . self::obtenerIconoTemplate($resultado['tipo_principal']) . '</span>';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: #0073aa;">' . self::obtenerNombreTemplate($resultado['tipo_principal']) . '</div>';
        $html .= '<div style="font-size: 14px; color: #666;">Confianza: ' . $resultado['confianza'] . '%</div>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';
        
        $html .= '<div style="background: white; padding: 15px; border-radius: 6px; border-left: 4px solid #46b450;">';
        $html .= '<h5 style="margin: 0 0 10px 0; color: #46b450;">Destino Sugerido</h5>';
        $html .= '<div style="font-size: 16px; font-weight: bold; color: #46b450;">' . self::obtenerNombreTemplate($resultado['destino']) . '</div>';
        $html .= '<div style="font-size: 14px; color: #666;">' . ($resultado['redireccion_automatica'] ? 'Redirección automática' : 'Revisión sugerida') . '</div>';
        $html .= '</div>';
        
        $html .= '</div>';
        
        // Puntuaciones detalladas
        $html .= self::generarReportePuntuaciones($resultado['puntuaciones']);
        
        // Palabras clave encontradas
        $html .= self::generarReportePalabrasClave($texto);
        
        $html .= '</div>';
        
        return $html;
    }
    
    /**
     * Genera reporte de puntuaciones por categoría
     */
    private static function generarReportePuntuaciones($puntuaciones) {
        $html = '<div style="background: white; padding: 15px; border-radius: 6px; margin-bottom: 15px;">';
        $html .= '<h5 style="margin: 0 0 15px 0; color: #666;">Puntuaciones por Categoría</h5>';
        
        foreach ($puntuaciones as $template => $puntuacion) {
            $porcentaje = array_sum($puntuaciones) > 0 ? 
                         round(($puntuacion / array_sum($puntuaciones)) * 100) : 0;
            
            $html .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; padding: 8px; background: #f8f9fa; border-radius: 4px;">';
            $html .= '<div style="display: flex; align-items: center; gap: 8px;">';
            $html .= '<span style="font-size: 16px;">' . self::obtenerIconoTemplate($template) . '</span>';
            $html .= '<span style="font-weight: 500;">' . self::obtenerNombreTemplate($template) . '</span>';
            $html .= '</div>';
            $html .= '<div style="display: flex; align-items: center; gap: 10px;">';
            $html .= '<div style="width: 100px; background: #e9ecef; border-radius: 10px; height: 8px;">';
            $html .= '<div style="background: #0073aa; height: 100%; border-radius: 10px; width: ' . $porcentaje . '%;"></div>';
            $html .= '</div>';
            $html .= '<span style="font-size: 12px; color: #666; min-width: 40px;">' . $puntuacion . ' pts</span>';
            $html .= '</div>';
            $html .= '</div>';
        }
        
        $html .= '</div>';
        return $html;
    }
    
    /**
     * Genera reporte de palabras clave encontradas
     */
    private static function generarReportePalabrasClave($texto) {
        $texto_minusculas = mb_strtolower($texto, 'UTF-8');
        $palabras_encontradas = array();
        
        // Buscar en todas las categorías
        $categorias = array(
            'Psicodramas' => self::$palabras_clave_psicodramas,
            'Sesiones Psicológicas' => self::$palabras_clave_psicologia,
            'Pacientes' => self::$palabras_clave_pacientes,
            'Notas Judiciales' => self::$palabras_clave_judiciales,
            'Miembros' => self::$palabras_clave_miembros,
            'Documentos' => self::$palabras_clave_documentos,
            'Actas' => self::$palabras_clave_actas
        );
        
        foreach ($categorias as $categoria => $palabras) {
            foreach ($palabras as $palabra) {
                if (strpos($texto_minusculas, $palabra) !== false) {
                    // Verificar que es una palabra completa
                    $pos = strpos($texto_minusculas, $palabra);
                    $antes = $pos > 0 ? $texto_minusculas[$pos - 1] : ' ';
                    $despues = $pos + strlen($palabra) < strlen($texto_minusculas) ? $texto_minusculas[$pos + strlen($palabra)] : ' ';
                    
                    if (!ctype_alpha($antes) && !ctype_alpha($despues)) {
                        $palabras_encontradas[$categoria][] = $palabra;
                    }
                }
            }
        }
        
        $html = '<div style="background: white; padding: 15px; border-radius: 6px;">';
        $html .= '<h5 style="margin: 0 0 15px 0; color: #666;">Palabras Clave Detectadas</h5>';
        
        foreach ($palabras_encontradas as $categoria => $palabras) {
            if (!empty($palabras)) {
                $html .= '<div style="margin-bottom: 15px;">';
                $html .= '<h6 style="margin: 0 0 8px 0; color: #0073aa; font-size: 13px;">' . $categoria . ' (' . count($palabras) . ')</h6>';
                $html .= '<div style="display: flex; flex-wrap: wrap; gap: 5px;">';
                
                foreach ($palabras as $palabra) {
                    $color = self::obtenerColorCategoria($categoria);
                    $html .= '<span style="background: ' . $color . '; color: white; padding: 4px 8px; border-radius: 12px; font-size: 11px;">' . $palabra . '</span>';
                }
                
                $html .= '</div>';
                $html .= '</div>';
            }
        }
        
        if (empty($palabras_encontradas)) {
            $html .= '<p style="margin: 0; color: #666; font-style: italic;">No se detectaron palabras clave específicas</p>';
        }
        
        $html .= '</div>';
        
        return $html;
    }
    
    /**
     * Obtiene color para categoría
     */
    private static function obtenerColorCategoria($categoria) {
        $colores = array(
            'Psicodramas' => '#667eea',
            'Sesiones Psicológicas' => '#4facfe',
            'Pacientes' => '#f093fb',
            'Notas Judiciales' => '#ff6b6b',
            'Miembros' => '#46b450',
            'Documentos' => '#ffa726',
            'Actas' => '#0073aa'
        );
        
        return $colores[$categoria] ?? '#666';
    }
    
    // =============================================
    // MÉTODOS DE COMPATIBILIDAD - ACTUALIZADOS
    // =============================================
    
    /**
     * Método de compatibilidad para clasificación simple
     * Ahora mapea correctamente los tipos
     */
    public static function clasificarContenido($texto) {
        $resultado = self::clasificarYRedirigirContenido($texto);
        
        // Mapear tipos internos a tipos compatibles con el sistema existente
        $mapeo_tipos = array(
            'sesiones-psicologicas' => 'sesion_psicologica',
            'psicodramas' => 'psicodrama',
            'actas' => 'acta',
            'pacientes' => 'paciente',
            'notas-judiciales' => 'nota_judicial',
            'historial-medico' => 'historial_medico',
            'miembros' => 'miembro',
            'seguimiento-terapeutico' => 'seguimiento',
            'documentos' => 'documento'
        );
        
        return $mapeo_tipos[$resultado['tipo_principal']] ?? 'acta';
    }
    
    /**
     * Método de compatibilidad para obtener confianza
     */
    public static function obtenerConfianzaClasificacion($texto) {
        $resultado = self::clasificarYRedirigirContenido($texto);
        return $resultado['confianza'];
    }
    
    /**
     * Método mejorado para análisis detallado
     */
    public static function analizarContenidoCompleto($texto) {
        $resultado = self::clasificarYRedirigirContenido($texto);
        
        // Análisis adicional de estructura
        $lineas = explode("\n", $texto);
        $total_lineas = count($lineas);
        $lineas_no_vacias = array_filter($lineas, function($linea) {
            return trim($linea) !== '';
        });
        $total_palabras = str_word_count($texto);
        
        $resultado['analisis_estructura'] = array(
            'total_lineas' => $total_lineas,
            'lineas_no_vacias' => count($lineas_no_vacias),
            'total_palabras' => $total_palabras,
            'densidad_palabras' => $total_palabras > 0 ? round(array_sum($resultado['puntuaciones']) / $total_palabras * 100, 2) : 0
        );
        
        return $resultado;
    }
}