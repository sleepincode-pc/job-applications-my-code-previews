<?php

namespace AsociacionCivil;

class SeguimientoTerapeutico {
    
    private $id;
    private $paciente_id;
    private $terapeuta_id;
    private $fecha_seguimiento;
    private $tipo_seguimiento;
    private $objetivo_tratamiento;
    private $progreso_observado;
    private $dificultades_identificadas;
    private $intervenciones_realizadas;
    private $tareas_asignadas;
    private $nivel_progreso;
    private $observaciones_terapeuta;
    private $proxima_sesion;
    private $created_at;

    public function __construct($id = null) {
        if ($id) {
            $this->id = $id;
            $this->cargar();
        }
    }

    public function cargar() {
        global $wpdb;
        $tabla = $wpdb->prefix . 'ac_seguimiento_terapeutico';
        $seguimiento = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tabla WHERE id = %d", $this->id), ARRAY_A);
        
        if ($seguimiento) {
            $this->paciente_id = $seguimiento['paciente_id'];
            $this->terapeuta_id = $seguimiento['terapeuta_id'];
            $this->fecha_seguimiento = $seguimiento['fecha_seguimiento'];
            $this->tipo_seguimiento = $seguimiento['tipo_seguimiento'];
            $this->objetivo_tratamiento = $seguimiento['objetivo_tratamiento'];
            $this->progreso_observado = $seguimiento['progreso_observado'];
            $this->dificultades_identificadas = $seguimiento['dificultades_identificadas'];
            $this->intervenciones_realizadas = $seguimiento['intervenciones_realizadas'];
            $this->tareas_asignadas = $seguimiento['tareas_asignadas'];
            $this->nivel_progreso = $seguimiento['nivel_progreso'];
            $this->observaciones_terapeuta = $seguimiento['observaciones_terapeuta'];
            $this->proxima_sesion = $seguimiento['proxima_sesion'];
            $this->created_at = $seguimiento['created_at'];
            return true;
        }
        return false;
    }

    public function guardar() {
        global $wpdb;
        $tabla = $wpdb->prefix . 'ac_seguimiento_terapeutico';

        $datos = array(
            'paciente_id' => $this->paciente_id,
            'terapeuta_id' => $this->terapeuta_id,
            'fecha_seguimiento' => $this->fecha_seguimiento,
            'tipo_seguimiento' => $this->tipo_seguimiento,
            'objetivo_tratamiento' => $this->objetivo_tratamiento,
            'progreso_observado' => $this->progreso_observado,
            'dificultades_identificadas' => $this->dificultades_identificadas,
            'intervenciones_realizadas' => $this->intervenciones_realizadas,
            'tareas_asignadas' => $this->tareas_asignadas,
            'nivel_progreso' => $this->nivel_progreso,
            'observaciones_terapeuta' => $this->observaciones_terapeuta,
            'proxima_sesion' => $this->proxima_sesion
        );

        if ($this->id) {
            return $wpdb->update($tabla, $datos, array('id' => $this->id));
        } else {
            $datos['created_at'] = current_time('mysql');
            $resultado = $wpdb->insert($tabla, $datos);
            if ($resultado) {
                $this->id = $wpdb->insert_id;
            }
            return $resultado;
        }
    }

    public function eliminar() {
        global $wpdb;
        $tabla = $wpdb->prefix . 'ac_seguimiento_terapeutico';
        return $wpdb->delete($tabla, array('id' => $this->id));
    }

    // Getters
    public function getId() { return $this->id; }
    public function getPacienteId() { return $this->paciente_id; }
    public function getTerapeutaId() { return $this->terapeuta_id; }
    public function getFechaSeguimiento() { return $this->fecha_seguimiento; }
    public function getTipoSeguimiento() { return $this->tipo_seguimiento; }
    public function getObjetivoTratamiento() { return $this->objetivo_tratamiento; }
    public function getProgresoObservado() { return $this->progreso_observado; }
    public function getDificultadesIdentificadas() { return $this->dificultades_identificadas; }
    public function getIntervencionesRealizadas() { return $this->intervenciones_realizadas; }
    public function getTareasAsignadas() { return $this->tareas_asignadas; }
    public function getNivelProgreso() { return $this->nivel_progreso; }
    public function getObservacionesTerapeuta() { return $this->observaciones_terapeuta; }
    public function getProximaSesion() { return $this->proxima_sesion; }
    public function getCreatedAt() { return $this->created_at; }

    // Setters
    public function setId($id) { $this->id = $id; }
    public function setPacienteId($paciente_id) { $this->paciente_id = $paciente_id; }
    public function setTerapeutaId($terapeuta_id) { $this->terapeuta_id = $terapeuta_id; }
    public function setFechaSeguimiento($fecha_seguimiento) { $this->fecha_seguimiento = $fecha_seguimiento; }
    public function setTipoSeguimiento($tipo_seguimiento) { $this->tipo_seguimiento = $tipo_seguimiento; }
    public function setObjetivoTratamiento($objetivo_tratamiento) { $this->objetivo_tratamiento = $objetivo_tratamiento; }
    public function setProgresoObservado($progreso_observado) { $this->progreso_observado = $progreso_observado; }
    public function setDificultadesIdentificadas($dificultades_identificadas) { $this->dificultades_identificadas = $dificultades_identificadas; }
    public function setIntervencionesRealizadas($intervenciones_realizadas) { $this->intervenciones_realizadas = $intervenciones_realizadas; }
    public function setTareasAsignadas($tareas_asignadas) { $this->tareas_asignadas = $tareas_asignadas; }
    public function setNivelProgreso($nivel_progreso) { $this->nivel_progreso = $nivel_progreso; }
    public function setObservacionesTerapeuta($observaciones_terapeuta) { $this->observaciones_terapeuta = $observaciones_terapeuta; }
    public function setProximaSesion($proxima_sesion) { $this->proxima_sesion = $proxima_sesion; }
}