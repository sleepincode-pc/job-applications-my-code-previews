<?php

namespace AsociacionCivil;

class Reunion {
    private $id;
    private $titulo;
    private $tipo;
    private $fecha;
    private $hora_inicio;
    private $hora_fin;
    private $lugar;
    private $convocante;
    private $asistentes;
    private $agenda;
    private $acuerdos;
    private $minutos;
    private $estado;
    private $fecha_creacion;
    private $fecha_actualizacion;

    public function __construct($id = null) {
        if ($id) {
            $this->cargar($id);
        }
    }

    public function cargar($id) {
        global $wpdb;
        
        $tabla = $wpdb->prefix . 'ac_reuniones';
        $reunion = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tabla WHERE id = %d", $id));
        
        if ($reunion) {
            $this->id = $reunion->id;
            $this->titulo = $reunion->titulo;
            $this->tipo = $reunion->tipo;
            $this->fecha = $reunion->fecha;
            $this->hora_inicio = $reunion->hora_inicio;
            $this->hora_fin = $reunion->hora_fin;
            $this->lugar = $reunion->lugar;
            $this->convocante = $reunion->convocante;
            $this->asistentes = maybe_unserialize($reunion->asistentes);
            $this->agenda = $reunion->agenda;
            $this->acuerdos = $reunion->acuerdos;
            $this->minutos = $reunion->minutos;
            $this->estado = $reunion->estado;
            $this->fecha_creacion = $reunion->fecha_creacion;
            $this->fecha_actualizacion = $reunion->fecha_actualizacion;
            
            return true;
        }
        
        return false;
    }

    public function guardar() {
        global $wpdb;
        
        $tabla = $wpdb->prefix . 'ac_reuniones';
        $data = array(
            'titulo' => $this->titulo,
            'tipo' => $this->tipo,
            'fecha' => $this->fecha,
            'hora_inicio' => $this->hora_inicio,
            'hora_fin' => $this->hora_fin,
            'lugar' => $this->lugar,
            'convocante' => $this->convocante,
            'asistentes' => maybe_serialize($this->asistentes),
            'agenda' => $this->agenda,
            'acuerdos' => $this->acuerdos,
            'minutos' => $this->minutos,
            'estado' => $this->estado,
            'fecha_actualizacion' => current_time('mysql')
        );
        
        if ($this->id) {
            // Actualizar
            $result = $wpdb->update($tabla, $data, array('id' => $this->id));
            return $result !== false;
        } else {
            // Insertar
            $data['fecha_creacion'] = current_time('mysql');
            $result = $wpdb->insert($tabla, $data);
            if ($result) {
                $this->id = $wpdb->insert_id;
                return true;
            }
        }
        
        return false;
    }

    public function agregarAsistente($miembro_id) {
        if (!is_array($this->asistentes)) {
            $this->asistentes = array();
        }
        
        if (!in_array($miembro_id, $this->asistentes)) {
            $this->asistentes[] = $miembro_id;
            return true;
        }
        
        return false;
    }

    public function eliminarAsistente($miembro_id) {
        if (is_array($this->asistentes)) {
            $key = array_search($miembro_id, $this->asistentes);
            if ($key !== false) {
                unset($this->asistentes[$key]);
                $this->asistentes = array_values($this->asistentes);
                return true;
            }
        }
        
        return false;
    }

    public function eliminar() {
        global $wpdb;
        
        if (!$this->id) {
            return false;
        }
        
        $tabla = $wpdb->prefix . 'ac_reuniones';
        $result = $wpdb->delete($tabla, array('id' => $this->id));
        
        return $result !== false;
    }

    // Getters
    public function getId() { return $this->id; }
    public function getTitulo() { return $this->titulo; }
    public function getTipo() { return $this->tipo; }
    public function getFecha() { return $this->fecha; }
    public function getHoraInicio() { return $this->hora_inicio; }
    public function getHoraFin() { return $this->hora_fin; }
    public function getLugar() { return $this->lugar; }
    public function getConvocante() { return $this->convocante; }
    public function getAsistentes() { return $this->asistentes; }
    public function getAgenda() { return $this->agenda; }
    public function getAcuerdos() { return $this->acuerdos; }
    public function getMinutos() { return $this->minutos; }
    public function getEstado() { return $this->estado; }
    public function getFechaCreacion() { return $this->fecha_creacion; }
    public function getFechaActualizacion() { return $this->fecha_actualizacion; }

    // Setters
    public function setTitulo($titulo) { $this->titulo = sanitize_text_field($titulo); }
    public function setTipo($tipo) { $this->tipo = sanitize_text_field($tipo); }
    public function setFecha($fecha) { $this->fecha = sanitize_text_field($fecha); }
    public function setHoraInicio($hora) { $this->hora_inicio = sanitize_text_field($hora); }
    public function setHoraFin($hora) { $this->hora_fin = sanitize_text_field($hora); }
    public function setLugar($lugar) { $this->lugar = sanitize_text_field($lugar); }
    public function setConvocante($convocante) { $this->convocante = sanitize_text_field($convocante); }
    public function setAsistentes($asistentes) { $this->asistentes = is_array($asistentes) ? $asistentes : array(); }
    public function setAgenda($agenda) { $this->agenda = wp_kses_post($agenda); }
    public function setAcuerdos($acuerdos) { $this->acuerdos = wp_kses_post($acuerdos); }
    public function setMinutos($minutos) { $this->minutos = wp_kses_post($minutos); }
    public function setEstado($estado) { $this->estado = sanitize_text_field($estado); }
}