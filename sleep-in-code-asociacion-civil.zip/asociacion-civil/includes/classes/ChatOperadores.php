<?php
// Verificar seguridad
if (!defined('ABSPATH')) {
    exit;
}

class ChatOperadores {
    
    private $table_name;
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'chat_operadores';
        
        // Registrar acciones AJAX para usuarios autenticados
        add_action('wp_ajax_enviar_mensaje_chat', array($this, 'enviar_mensaje'));
        add_action('wp_ajax_cargar_mensajes_chat', array($this, 'cargar_mensajes'));
        add_action('wp_ajax_eliminar_mensaje_chat', array($this, 'eliminar_mensaje'));
        add_action('wp_ajax_obtener_usuarios_conectados', array($this, 'obtener_usuarios_conectados'));
        add_action('wp_ajax_diagnosticar_chat', array($this, 'diagnosticar_chat'));
        
        // Verificar tablas al inicializar
        add_action('init', array($this, 'verificar_tablas_chat'));
        
        // Cargar scripts necesarios
        add_action('admin_enqueue_scripts', array($this, 'cargar_scripts'));
    }
    
    public function cargar_scripts($hook) {
        if ($hook !== 'toplevel_page_ac-chat-operadores') {
            return;
        }
        
        // Cargar jQuery UI si es necesario
        wp_enqueue_script('jquery-ui-core');
  
    }
    
    public function verificar_tablas_chat() {
        global $wpdb;
        
        // Solo verificar en admin para mejorar rendimiento
        if (!is_admin()) {
            return;
        }
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Tabla de mensajes
        $sql_mensajes = "CREATE TABLE {$this->table_name} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            usuario_id mediumint(9) NOT NULL,
            usuario_nombre varchar(100) NOT NULL,
            sala varchar(50) NOT NULL,
            mensaje text NOT NULL,
            fecha datetime DEFAULT CURRENT_TIMESTAMP,
            ip_address varchar(45),
            status tinyint(1) DEFAULT 1,
            PRIMARY KEY (id),
            KEY sala (sala),
            KEY usuario_id (usuario_id),
            KEY fecha (fecha)
        ) $charset_collate;";
        
        // Tabla de usuarios conectados
        $table_usuarios = $wpdb->prefix . 'chat_usuarios_conectados';
        $sql_usuarios = "CREATE TABLE {$table_usuarios} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            usuario_id mediumint(9) NOT NULL,
            usuario_nombre varchar(100) NOT NULL,
            ultima_actividad datetime DEFAULT CURRENT_TIMESTAMP,
            sala_actual varchar(50),
            ip_address varchar(45),
            PRIMARY KEY (id),
            UNIQUE KEY usuario_id (usuario_id),
            KEY ultima_actividad (ultima_actividad)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_mensajes);
        dbDelta($sql_usuarios);
        
        // Log para debugging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Chat Operadores: Tablas verificadas/creadas');
        }
    }
    
    public function enviar_mensaje() {
        // HEADERS para evitar cache y CORS
        header('Content-Type: application/json');
        header('Cache-Control: no-cache, no-store, must-revalidate');
        
        try {
            // Verificar que estamos recibiendo datos POST
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                wp_send_json_error('Método no permitido', 405);
                return;
            }

            // Verificar nonce
            if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'chat_operadores_nonce')) {
                wp_send_json_error('Error de seguridad: Nonce inválido o expirado');
                return;
            }
            
            // Verificar que el usuario esté logueado
            if (!is_user_logged_in()) {
                wp_send_json_error('Usuario no autenticado');
                return;
            }
            
            // Verificar parámetros requeridos
            if (!isset($_POST['mensaje']) || !isset($_POST['sala'])) {
                wp_send_json_error('Parámetros incompletos');
                return;
            }
            
            $mensaje = sanitize_textarea_field($_POST['mensaje']);
            $sala = sanitize_text_field($_POST['sala']);
            $usuario_actual = wp_get_current_user();
            
            if (empty($mensaje)) {
                wp_send_json_error('El mensaje no puede estar vacío');
                return;
            }
            
            if (strlen($mensaje) > 1000) {
                wp_send_json_error('El mensaje no puede tener más de 1000 caracteres');
                return;
            }
            
            global $wpdb;
            
            // Verificar que la tabla existe
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$this->table_name}'");
            if (!$table_exists) {
                $this->verificar_tablas_chat();
            }
            
            // Insertar mensaje
            $result = $wpdb->insert(
                $this->table_name,
                array(
                    'usuario_id' => $usuario_actual->ID,
                    'usuario_nombre' => $usuario_actual->display_name ?: $usuario_actual->user_login,
                    'sala' => $sala,
                    'mensaje' => $mensaje,
                    'ip_address' => $_SERVER['REMOTE_ADDR']
                ),
                array('%d', '%s', '%s', '%s', '%s')
            );
            
            if ($result === false) {
                error_log('Error al insertar mensaje: ' . $wpdb->last_error);
                wp_send_json_error('Error al guardar el mensaje en la base de datos: ' . $wpdb->last_error);
                return;
            }
            
            // Actualizar actividad del usuario
            $this->actualizar_usuario_conectado($usuario_actual, $sala);
            
            wp_send_json_success(array(
                'id' => $wpdb->insert_id,
                'usuario' => $usuario_actual->display_name ?: $usuario_actual->user_login,
                'mensaje' => wp_kses_post($mensaje),
                'fecha' => current_time('mysql'),
                'propio' => true
            ));
            
        } catch (Exception $e) {
            error_log('Excepción en enviar_mensaje: ' . $e->getMessage());
            wp_send_json_error('Error interno del servidor: ' . $e->getMessage());
        }
        
        // Asegurar que WordPress no siga ejecutando
        wp_die();
    }
    
    public function cargar_mensajes() {
        // HEADERS para evitar cache
        header('Content-Type: application/json');
        header('Cache-Control: no-cache, no-store, must-revalidate');
        
        try {
            // Verificar que estamos recibiendo datos POST
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                wp_send_json_error('Método no permitido', 405);
                return;
            }

            // Verificar nonce
            if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'chat_operadores_nonce')) {
                wp_send_json_error('Error de seguridad: Nonce inválido o expirado');
                return;
            }
            
            // Verificar que el usuario esté logueado
            if (!is_user_logged_in()) {
                wp_send_json_error('Usuario no autenticado');
                return;
            }
            
            // Verificar parámetros requeridos
            if (!isset($_POST['sala'])) {
                wp_send_json_error('Parámetro sala requerido');
                return;
            }
            
            $sala = sanitize_text_field($_POST['sala']);
            $ultimo_id = isset($_POST['ultimo_id']) ? intval($_POST['ultimo_id']) : 0;
            
            global $wpdb;
            $usuario_actual = wp_get_current_user();
            
            // Verificar que la tabla existe
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$this->table_name}'");
            if (!$table_exists) {
                $this->verificar_tablas_chat();
                wp_send_json_success(array());
                return;
            }
            
            // Actualizar actividad del usuario
            $this->actualizar_usuario_conectado($usuario_actual, $sala);
            
            // Obtener mensajes con manejo de errores
            $query = $wpdb->prepare(
                "SELECT * FROM {$this->table_name} 
                 WHERE sala = %s AND id > %d AND status = 1 
                 ORDER BY id ASC 
                 LIMIT 100",
                $sala,
                $ultimo_id
            );
            
            $mensajes = $wpdb->get_results($query);
            
            if ($wpdb->last_error) {
                error_log('Error en consulta de chat: ' . $wpdb->last_error);
                wp_send_json_error('Error en la base de datos: ' . $wpdb->last_error);
                return;
            }
            
            $mensajes_formateados = array();
            foreach ($mensajes as $mensaje) {
                $mensajes_formateados[] = array(
                    'id' => $mensaje->id,
                    'usuario' => $mensaje->usuario_nombre,
                    'mensaje' => wp_kses_post($mensaje->mensaje),
                    'fecha' => $mensaje->fecha,
                    'propio' => ($mensaje->usuario_id == $usuario_actual->ID)
                );
            }
            
            wp_send_json_success($mensajes_formateados);
            
        } catch (Exception $e) {
            error_log('Excepción en cargar_mensajes: ' . $e->getMessage());
            wp_send_json_error('Error interno del servidor: ' . $e->getMessage());
        }
        
        // Asegurar que WordPress no siga ejecutando
        wp_die();
    }
    
    public function eliminar_mensaje() {
        // HEADERS para evitar cache
        header('Content-Type: application/json');
        header('Cache-Control: no-cache, no-store, must-revalidate');
        
        try {
            // Verificar que estamos recibiendo datos POST
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                wp_send_json_error('Método no permitido', 405);
                return;
            }

            if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'chat_operadores_nonce')) {
                wp_send_json_error('Error de seguridad');
                return;
            }
            
            if (!isset($_POST['mensaje_id'])) {
                wp_send_json_error('ID de mensaje requerido');
                return;
            }
            
            $mensaje_id = intval($_POST['mensaje_id']);
            $usuario_actual = wp_get_current_user();
            
            global $wpdb;
            
            // Verificar que el mensaje pertenece al usuario
            $mensaje = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$this->table_name} WHERE id = %d",
                $mensaje_id
            ));
            
            if (!$mensaje) {
                wp_send_json_error('El mensaje no existe');
                return;
            }
            
            if ($mensaje->usuario_id != $usuario_actual->ID) {
                wp_send_json_error('No tienes permisos para eliminar este mensaje');
                return;
            }
            
            // Marcar como eliminado en lugar de borrar físicamente
            $result = $wpdb->update(
                $this->table_name,
                array('status' => 0),
                array('id' => $mensaje_id),
                array('%d'),
                array('%d')
            );
            
            if ($result === false) {
                error_log('Error al eliminar mensaje: ' . $wpdb->last_error);
                wp_send_json_error('Error al eliminar el mensaje: ' . $wpdb->last_error);
                return;
            }
            
            wp_send_json_success('Mensaje eliminado correctamente');
            
        } catch (Exception $e) {
            error_log('Excepción en eliminar_mensaje: ' . $e->getMessage());
            wp_send_json_error('Error interno del servidor: ' . $e->getMessage());
        }
        
        wp_die();
    }
    
    public function obtener_usuarios_conectados() {
        // HEADERS para evitar cache
        header('Content-Type: application/json');
        header('Cache-Control: no-cache, no-store, must-revalidate');
        
        try {
            // Verificar que estamos recibiendo datos POST
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                wp_send_json_error('Método no permitido', 405);
                return;
            }

            if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'chat_operadores_nonce')) {
                wp_send_json_error('Error de seguridad');
                return;
            }
            
            if (!isset($_POST['sala'])) {
                wp_send_json_error('Parámetro sala requerido');
                return;
            }
            
            global $wpdb;
            $table_usuarios = $wpdb->prefix . 'chat_usuarios_conectados';
            
            // Verificar que la tabla existe
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_usuarios'");
            if (!$table_exists) {
                $this->verificar_tablas_chat();
                wp_send_json_success(array());
                return;
            }
            
            // Limpiar usuarios inactivos (más de 5 minutos)
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$table_usuarios} WHERE ultima_actividad < %s",
                date('Y-m-d H:i:s', strtotime('-5 minutes'))
            ));
            
            $sala = sanitize_text_field($_POST['sala']);
            
            $usuarios = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$table_usuarios} WHERE sala_actual = %s ORDER BY usuario_nombre",
                $sala
            ));
            
            if ($wpdb->last_error) {
                error_log('Error en consulta de usuarios: ' . $wpdb->last_error);
                wp_send_json_error('Error en la base de datos: ' . $wpdb->last_error);
                return;
            }
            
            wp_send_json_success($usuarios);
            
        } catch (Exception $e) {
            error_log('Excepción en obtener_usuarios_conectados: ' . $e->getMessage());
            wp_send_json_error('Error interno del servidor: ' . $e->getMessage());
        }
        
        wp_die();
    }
    
    public function diagnosticar_chat() {
        // HEADERS para evitar cache
        header('Content-Type: application/json');
        header('Cache-Control: no-cache, no-store, must-revalidate');
        
        try {
            if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'chat_operadores_nonce')) {
                wp_send_json_error('Error de seguridad');
                return;
            }
            
            global $wpdb;
            $diagnostico = array();
            
            // Verificar tablas
            $table_mensajes = $wpdb->get_var("SHOW TABLES LIKE '{$this->table_name}'");
            $table_usuarios = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}chat_usuarios_conectados'");
            
            $diagnostico['tabla_mensajes'] = $table_mensajes ? '✅ EXISTE' : '❌ NO EXISTE';
            $diagnostico['tabla_usuarios'] = $table_usuarios ? '✅ EXISTE' : '❌ NO EXISTE';
            
            // Verificar mensajes de ejemplo
            if ($table_mensajes) {
                $total_mensajes = $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name}");
                $diagnostico['total_mensajes'] = $total_mensajes;
                
                // Verificar mensajes por sala actual
                $sala_actual = sanitize_text_field($_POST['sala'] ?? 'general');
                $mensajes_sala = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$this->table_name} WHERE sala = %s AND status = 1",
                    $sala_actual
                ));
                $diagnostico['mensajes_sala_actual'] = $mensajes_sala;
            }
            
            // Verificar usuario actual
            $usuario_actual = wp_get_current_user();
            $diagnostico['usuario_actual'] = $usuario_actual->display_name ?: $usuario_actual->user_login;
            $diagnostico['usuario_id'] = $usuario_actual->ID;
            $diagnostico['esta_logueado'] = is_user_logged_in() ? '✅ SÍ' : '❌ NO';
            
            // Verificar configuración WordPress
            $diagnostico['ajaxurl'] = admin_url('admin-ajax.php');
            $diagnostico['wp_debug'] = defined('WP_DEBUG') && WP_DEBUG ? '✅ ACTIVADO' : '❌ DESACTIVADO';
            
            // Verificar errores de base de datos
            $diagnostico['ultimo_error_db'] = $wpdb->last_error ?: '✅ SIN ERRORES';
            
            // Información del servidor
            $diagnostico['php_version'] = PHP_VERSION;
            $diagnostico['wp_version'] = get_bloginfo('version');
            
            wp_send_json_success($diagnostico);
            
        } catch (Exception $e) {
            error_log('Excepción en diagnosticar_chat: ' . $e->getMessage());
            wp_send_json_error('Error en diagnóstico: ' . $e->getMessage());
        }
        
        wp_die();
    }
    
    private function actualizar_usuario_conectado($usuario, $sala) {
        global $wpdb;
        $table_usuarios = $wpdb->prefix . 'chat_usuarios_conectados';
        
        $data = array(
            'usuario_id' => $usuario->ID,
            'usuario_nombre' => $usuario->display_name ?: $usuario->user_login,
            'ultima_actividad' => current_time('mysql'),
            'sala_actual' => $sala,
            'ip_address' => $_SERVER['REMOTE_ADDR']
        );
        
        $wpdb->replace($table_usuarios, $data);
        
        if ($wpdb->last_error) {
            error_log('Error al actualizar usuario conectado: ' . $wpdb->last_error);
        }
    }
    
    public function mostrar_chat() {
        $salas = array(
            'general' => '💬 General',
            'operadores' => '👥 Operadores', 
            'coordinacion' => '📋 Coordinación',
            'urgencias' => '🚨 Urgencias',
            'terapeutico' => '💊 Área Terapéutica'
        );

        $sala_actual = isset($_GET['sala']) ? sanitize_text_field($_GET['sala']) : 'general';
        $usuario_actual = wp_get_current_user();
        $nonce = wp_create_nonce('chat_operadores_nonce');
        
        // Verificar si el chat está habilitado
        $configuracion = get_option('asociacion_civil_settings', array());
        $chat_habilitado = $configuracion['chat_habilitado'] ?? 1;
        
        if (!$chat_habilitado) {
            echo '<div class="wrap">';
            echo '<h1>💬 Chat de Operadores</h1>';
            echo '<div class="notice notice-warning">';
            echo '<p>El sistema de chat está deshabilitado. Por favor, contacta al administrador.</p>';
            echo '</div>';
            echo '</div>';
            return;
        }

        // Diagnóstico temporal (solo para admin)
        if (current_user_can('manage_options') && isset($_GET['debug_chat'])) {
            global $wpdb;
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}chat_operadores'");
            echo '<div class="notice notice-info">';
            echo '<h3>🔧 Debug Chat</h3>';
            echo '<p><strong>Tabla existe:</strong> ' . ($table_exists ? '✅ SÍ' : '❌ NO') . '</p>';
            echo '<p><strong>Usuario:</strong> ' . $usuario_actual->display_name . '</p>';
            echo '<p><strong>Sala actual:</strong> ' . $sala_actual . '</p>';
            echo '<p><strong>Nonce:</strong> ' . $nonce . '</p>';
            echo '<p><strong>AJAX URL:</strong> ' . admin_url('admin-ajax.php') . '</p>';
            echo '</div>';
        }
        ?>
        
        <div class="wrap">
            <header class="chat-header">
                <h1 class="chat-title">
                    <span class="chat-icon">💬</span>
                    Chat de Operadores
                </h1>
                <p class="chat-description">Sistema de comunicación interna para el personal de la asociación</p>
            </header>

            <!-- Sistema de notificaciones -->
            <div id="chat-notifications" class="chat-notifications" aria-live="polite"></div>

            <main class="chat-layout">
                <!-- Sidebar -->
                <aside class="chat-sidebar" role="complementary">
                    <!-- Navegación de salas -->
                    <nav class="chat-rooms" aria-label="Salas de chat">
                        <h2 class="sidebar-title">Salas de Chat</h2>
                        <ul class="rooms-list" role="list">
                            <?php foreach ($salas as $clave => $nombre): ?>
                                <li class="room-item" role="listitem">
                                    <a href="<?php echo admin_url('admin.php?page=ac-chat-operadores&sala=' . $clave); ?>" 
                                       class="room-link <?php echo $sala_actual === $clave ? 'room-active' : ''; ?>"
                                       aria-current="<?php echo $sala_actual === $clave ? 'page' : 'false'; ?>">
                                        <span class="room-icon"><?php echo substr($nombre, 0, 2); ?></span>
                                        <span class="room-name"><?php echo esc_html(substr($nombre, 2)); ?></span>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </nav>

                    <!-- Usuarios conectados -->
                    <section class="chat-users" aria-label="Usuarios conectados">
                        <h2 class="sidebar-title">Operadores Conectados</h2>
                        <ul class="users-list" role="list" id="lista-usuarios">
                            <li class="user-item" role="listitem">
                                <div class="user-info">
                                    <span class="user-status" aria-label="Conectado"></span>
                                    <span class="user-name">
                                        <?php echo esc_html($usuario_actual->display_name ?: $usuario_actual->user_login); ?>
                                        <span class="user-badge">(Tú)</span>
                                    </span>
                                </div>
                            </li>
                        </ul>
                    </section>

                    <!-- Información de la sala -->
                    <section class="chat-info" aria-label="Información de la sala">
                        <h2 class="sidebar-title">Información</h2>
                        <div class="info-content">
                            <div class="info-item">
                                <strong>Sala:</strong>
                                <span id="nombre-sala-actual"><?php echo esc_html($salas[$sala_actual] ?? $sala_actual); ?></span>
                            </div>
                            <div class="info-item">
                                <strong>Tus permisos:</strong>
                                <span>Operador</span>
                            </div>
                            <?php if (current_user_can('manage_options')): ?>
                                <div class="info-actions">
                                    <a href="<?php echo add_query_arg('debug_chat', '1'); ?>" class="button button-small button-outline">
                                        <span class="debug-icon">🔧</span>
                                        Debug
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </section>
                </aside>

                <!-- Área principal del chat -->
                <div class="chat-main" role="main">
                    <!-- Header del chat -->
                    <header class="chat-room-header">
                        <div class="room-info">
                            <h2 class="room-title" id="titulo-sala">
                                <?php echo esc_html($salas[$sala_actual] ?? $sala_actual); ?>
                            </h2>
                            <div class="room-stats">
                                <span class="users-count" id="contador-usuarios" aria-live="polite">
                                    1 usuario conectado
                                </span>
                            </div>
                        </div>
                        
                        <div class="chat-actions">
                            <button type="button" id="recargar-chat" class="btn btn-secondary" title="Recargar mensajes">
                                <span class="btn-icon">🔄</span>
                                <span class="btn-text">Recargar</span>
                            </button>
                            <button type="button" id="limpiar-chat" class="btn btn-secondary" title="Limpiar chat visual">
                                <span class="btn-icon">🧹</span>
                                <span class="btn-text">Limpiar</span>
                            </button>
                            <button type="button" id="diagnosticar-chat" class="btn btn-warning" title="Diagnosticar problemas">
                                <span class="btn-icon">🔧</span>
                                <span class="btn-text">Diagnosticar</span>
                            </button>
                        </div>
                    </header>

                    <!-- Área de mensajes -->
                    <section class="chat-messages" aria-label="Mensajes del chat">
                        <div class="messages-container" id="contenedor-mensajes" role="log" aria-live="polite">
                            <div class="loading-state">
                                <div class="loading-spinner"></div>
                                <p>Cargando mensajes...</p>
                            </div>
                        </div>
                    </section>

                    <!-- Área de escritura -->
                    <footer class="chat-composer">
                        <form id="formulario-mensaje" class="message-form" method="post">
                            <div class="composer-input">
                                <textarea 
                                    id="input-mensaje" 
                                    class="message-input"
                                    placeholder="Escribe tu mensaje aquí... (Enter para enviar, Shift+Enter para nueva línea)" 
                                    rows="1"
                                    maxlength="1000"
                                    aria-label="Escribir mensaje"
                                ></textarea>
                                <button type="submit" id="boton-enviar" class="btn btn-primary send-button" aria-label="Enviar mensaje">
                                    <span class="send-icon">📤</span>
                                </button>
                            </div>
                            <div class="composer-meta">
                                <div class="char-counter">
                                    <span id="contador" class="counter-number">0</span>
                                    <span class="counter-text">/1000 caracteres</span>
                                </div>
                            </div>
                        </form>
                        
                        <!-- Indicadores de estado -->
                        <div class="chat-status" id="estado-chat">
                            <div class="status-items">
                                <span id="indicador-conexion" class="status-item status-connected">
                                    <span class="status-dot"></span>
                                    Conectado
                                </span>
                                <span id="indicador-escritura" class="status-item status-typing" style="display: none;">
                                    <span class="typing-icon">✍️</span>
                                    Alguien está escribiendo...
                                </span>
                                <span id="indicador-carga" class="status-item status-loading" style="display: none;">
                                    <span class="loading-icon">⏳</span>
                                    Cargando...
                                </span>
                            </div>
                        </div>
                    </footer>
                </div>
            </main>
        </div>

        <style>
        /* CSS Moderno - Design System */
        :root {
            --primary-color: #0073aa;
            --primary-dark: #005a87;
            --primary-light: #e7f3f8;
            --success-color: #46b450;
            --warning-color: #ffb900;
            --error-color: #dc3232;
            --bg-color: #f8f9fa;
            --surface-color: #ffffff;
            --text-primary: #2c3338;
            --text-secondary: #646970;
            --text-muted: #8c8f94;
            --border-color: #dcdcde;
            --border-light: #f0f0f1;
            --shadow-sm: 0 1px 3px rgba(0,0,0,0.1);
            --shadow-md: 0 4px 6px rgba(0,0,0,0.1);
            --shadow-lg: 0 10px 25px rgba(0,0,0,0.1);
            --radius-sm: 6px;
            --radius-md: 8px;
            --radius-lg: 12px;
            --transition: all 0.2s ease-in-out;
        }

        /* Layout Principal */
        .chat-layout {
            display: grid;
            grid-template-columns: 320px 1fr;
            gap: 24px;
            margin-top: 24px;
            min-height: 70vh;
        }

        .chat-header {
            margin-bottom: 24px;
        }

        .chat-title {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 28px;
            font-weight: 700;
            color: var(--text-primary);
            margin: 0 0 8px 0;
        }

        .chat-icon {
            font-size: 32px;
        }

        .chat-description {
            color: var(--text-secondary);
            margin: 0;
            font-size: 16px;
        }

        /* Sidebar */
        .chat-sidebar {
            background: var(--surface-color);
            border-radius: var(--radius-lg);
            padding: 24px;
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--border-light);
            display: flex;
            flex-direction: column;
            gap: 32px;
        }

        .sidebar-title {
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--text-secondary);
            margin: 0 0 16px 0;
        }

        /* Navegación de Salas */
        .rooms-list {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .room-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            text-decoration: none;
            color: var(--text-primary);
            border-radius: var(--radius-md);
            transition: var(--transition);
            border: 1px solid transparent;
        }

        .room-link:hover {
            background: var(--bg-color);
            border-color: var(--border-color);
        }

        .room-link.room-active {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-dark);
        }

        .room-icon {
            font-size: 18px;
        }

        .room-name {
            font-weight: 500;
        }

        /* Lista de Usuarios */
        .users-list {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .user-item {
            padding: 8px 0;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-status {
            width: 8px;
            height: 8px;
            background: var(--success-color);
            border-radius: 50%;
            position: relative;
        }

        .user-status::after {
            content: '';
            position: absolute;
            top: -2px;
            left: -2px;
            right: -2px;
            bottom: -2px;
            background: var(--success-color);
            border-radius: 50%;
            opacity: 0.4;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 0.4; }
            50% { transform: scale(1.2); opacity: 0.2; }
        }

        .user-name {
            font-weight: 500;
            color: var(--text-primary);
        }

        .user-badge {
            color: var(--text-muted);
            font-size: 12px;
        }

        /* Información */
        .info-content {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .info-item {
            display: flex;
            justify-content: between;
            gap: 8px;
        }

        .info-item strong {
            color: var(--text-primary);
            min-width: 80px;
        }

        .info-item span {
            color: var(--text-secondary);
        }

        .info-actions {
            margin-top: 16px;
        }

        /* Área Principal */
        .chat-main {
            display: flex;
            flex-direction: column;
            background: var(--surface-color);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--border-light);
            overflow: hidden;
        }

        /* Header del Chat */
        .chat-room-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 24px;
            background: var(--surface-color);
            border-bottom: 1px solid var(--border-light);
        }

        .room-info {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .room-title {
            font-size: 20px;
            font-weight: 600;
            color: var(--text-primary);
            margin: 0;
        }

        .room-stats {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .users-count {
            background: var(--bg-color);
            color: var(--text-secondary);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }

        .chat-actions {
            display: flex;
            gap: 8px;
        }

        /* Botones */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            border: 1px solid var(--border-color);
            background: var(--surface-color);
            color: var(--text-primary);
            text-decoration: none;
            border-radius: var(--radius-md);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            outline: none;
        }

        .btn:hover {
            background: var(--bg-color);
            border-color: var(--text-muted);
            transform: translateY(-1px);
        }

        .btn:focus {
            box-shadow: 0 0 0 2px var(--primary-light);
        }

        .btn-primary {
            background: var(--primary-color);
            border-color: var(--primary-dark);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            border-color: var(--primary-dark);
        }

        .btn-secondary {
            background: var(--surface-color);
            border-color: var(--border-color);
            color: var(--text-primary);
        }

        .btn-warning {
            background: var(--warning-color);
            border-color: #e6a200;
            color: #000;
        }

        .btn-warning:hover {
            background: #e6a200;
            border-color: #cc9200;
        }

        .btn-outline {
            background: transparent;
            border: 1px solid var(--border-color);
        }

        .btn-icon {
            font-size: 16px;
        }

        .btn-text {
            font-size: 14px;
        }

        /* Área de Mensajes */
        .chat-messages {
            flex: 1;
            overflow: hidden;
            position: relative;
        }

        .messages-container {
            height: 100%;
            overflow-y: auto;
            padding: 0;
        }

        .loading-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 60px 20px;
            color: var(--text-muted);
        }

        .loading-spinner {
            width: 32px;
            height: 32px;
            border: 3px solid var(--border-light);
            border-top: 3px solid var(--primary-color);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 16px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Mensajes Individuales */
        .message {
            margin: 16px 24px;
            padding: 16px 20px;
            border-radius: var(--radius-lg);
            max-width: 75%;
            position: relative;
            animation: messageSlide 0.3s ease-out;
        }

        @keyframes messageSlide {
            from {
                opacity: 0;
                transform: translateY(10px) scale(0.95);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .message-own {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            margin-left: auto;
            margin-right: 24px;
        }

        .message-other {
            background: var(--bg-color);
            color: var(--text-primary);
            margin-right: auto;
            margin-left: 24px;
            border: 1px solid var(--border-light);
        }

        .message-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 6px;
            font-size: 12px;
        }

        .message-user {
            font-weight: 600;
            opacity: 0.9;
        }

        .message-time {
            opacity: 0.7;
        }

        .message-content {
            line-height: 1.5;
            word-wrap: break-word;
        }

        .message-actions {
            margin-top: 8px;
            text-align: right;
        }

        .btn-delete {
            background: rgba(255,255,255,0.2);
            border: none;
            color: inherit;
            padding: 4px 8px;
            border-radius: var(--radius-sm);
            font-size: 11px;
            cursor: pointer;
            opacity: 0.7;
            transition: var(--transition);
        }

        .btn-delete:hover {
            opacity: 1;
            background: rgba(255,255,255,0.3);
        }

        /* Composer */
        .chat-composer {
            border-top: 1px solid var(--border-light);
            background: var(--surface-color);
            padding: 20px 24px;
        }

        .message-form {
            margin-bottom: 12px;
        }

        .composer-input {
            display: flex;
            gap: 12px;
            align-items: flex-end;
        }

        .message-input {
            flex: 1;
            resize: none;
            min-height: 44px;
            max-height: 120px;
            padding: 12px 16px;
            border: 1px solid var(--border-color);
            border-radius: var(--radius-md);
            font-family: inherit;
            font-size: 14px;
            line-height: 1.5;
            transition: var(--transition);
            background: var(--surface-color);
        }

        .message-input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px var(--primary-light);
        }

        .send-button {
            padding: 12px;
            border-radius: var(--radius-md);
            min-width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .send-icon {
            font-size: 18px;
        }

        .composer-meta {
            display: flex;
            justify-content: flex-end;
            margin-top: 8px;
        }

        .char-counter {
            font-size: 12px;
            color: var(--text-muted);
        }

        .counter-number {
            font-weight: 600;
        }

        .counter-number.limit-exceeded {
            color: var(--error-color);
        }

        /* Estados del Chat */
        .chat-status {
            border-top: 1px solid var(--border-light);
            padding-top: 12px;
        }

        .status-items {
            display: flex;
            gap: 16px;
            align-items: center;
        }

        .status-item {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
            color: var(--text-muted);
        }

        .status-connected {
            color: var(--success-color);
        }

        .status-dot {
            width: 6px;
            height: 6px;
            background: currentColor;
            border-radius: 50%;
        }

        .status-typing {
            color: var(--warning-color);
        }

        .status-loading {
            color: var(--primary-color);
        }

        .typing-icon, .loading-icon {
            font-size: 14px;
        }

        /* Notificaciones */
        .chat-notifications {
            position: fixed;
            top: 80px;
            right: 20px;
            z-index: 1000;
            max-width: 400px;
        }

        .notification {
            padding: 12px 16px;
            border-radius: var(--radius-md);
            margin-bottom: 8px;
            box-shadow: var(--shadow-lg);
            border-left: 4px solid;
            animation: slideIn 0.3s ease-out;
        }

        .notification-success {
            background: var(--surface-color);
            border-left-color: var(--success-color);
            color: var(--text-primary);
        }

        .notification-error {
            background: #fdf2f2;
            border-left-color: var(--error-color);
            color: #7a261d;
        }

        .notification-warning {
            background: #fff8e5;
            border-left-color: var(--warning-color);
            color: #6b4d00;
        }

        .notification-info {
            background: var(--primary-light);
            border-left-color: var(--primary-color);
            color: var(--text-primary);
        }

        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .chat-layout {
                grid-template-columns: 280px 1fr;
                gap: 20px;
            }
        }

        @media (max-width: 768px) {
            .chat-layout {
                grid-template-columns: 1fr;
            }
            
            .chat-sidebar {
                display: none;
            }
            
            .message {
                max-width: 85%;
                margin: 12px 16px;
            }
            
            .chat-room-header {
                padding: 16px 20px;
                flex-direction: column;
                gap: 12px;
                align-items: stretch;
            }
            
            .room-info {
                justify-content: space-between;
            }
            
            .chat-actions {
                justify-content: center;
            }
        }

        @media (max-width: 480px) {
            .chat-composer {
                padding: 16px 20px;
            }
            
            .composer-input {
                gap: 8px;
            }
            
            .message {
                max-width: 90%;
                margin: 8px 12px;
                padding: 12px 16px;
            }
            
            .btn-text {
                display: none;
            }
            
            .btn {
                padding: 8px 12px;
            }
        }

        /* Estados de carga y error */
        .message-temp {
            opacity: 0.7;
        }

        .message-error {
            background: #fdf2f2;
            border: 1px solid var(--error-color);
            color: #7a261d;
            text-align: center;
            margin: 16px 24px;
            padding: 16px;
            border-radius: var(--radius-md);
        }
        </style>

        <script>
        jQuery(document).ready(function($) {
            // Variables globales
            let ultimoMensajeId = 0;
            let salaActual = '<?php echo esc_js($sala_actual); ?>';
            let cargandoMensajes = false;
            let intervaloActualizacion;
            let intervaloUsuarios;
            const nonce = '<?php echo esc_js($nonce); ?>';
            let intentosReconexion = 0;
            const maxIntentosReconexion = 5;

            // Sistema de notificaciones
            function mostrarNotificacion(mensaje, tipo = 'info', duracion = 5000) {
                const notification = $(`
                    <div class="notification notification-${tipo}" role="alert">
                        <p>${mensaje}</p>
                    </div>
                `);
                
                $('#chat-notifications').append(notification);
                
                // Auto-remover después de la duración
                setTimeout(() => {
                    notification.fadeOut(300, function() {
                        $(this).remove();
                    });
                }, duracion);
            }

            // Función para verificar la respuesta AJAX
            function manejarErrorAJAX(xhr, status, error, operacion) {
                console.error(`Error en ${operacion}:`, error);
                
                let mensajeError = 'Error de conexión';
                
                if (xhr.status === 400) {
                    mensajeError = 'Error en la solicitud (400). Verifica los datos enviados.';
                } else if (xhr.status === 403) {
                    mensajeError = 'Acceso denegado. La sesión pudo haber expirado.';
                } else if (xhr.status === 500) {
                    mensajeError = 'Error interno del servidor.';
                } else if (status === 'timeout') {
                    mensajeError = 'Tiempo de espera agotado.';
                } else if (status === 'parsererror') {
                    mensajeError = 'Error al procesar la respuesta del servidor.';
                }
                
                mostrarNotificacion(`${operacion}: ${mensajeError}`, 'error');
                return mensajeError;
            }

            // Inicializar chat
            function inicializarChat() {
                mostrarNotificacion('Conectando al chat...', 'info');
                cargarMensajes();
                cargarUsuariosConectados();
                configurarEventos();
                iniciarActualizacionAutomatica();
            }
            
            // Configurar eventos
            function configurarEventos() {
                // Envío de mensajes
                $('#formulario-mensaje').on('submit', function(e) {
                    e.preventDefault();
                    enviarMensaje();
                });
                
                // Atajo de teclado: Enter para enviar, Shift+Enter para nueva línea
                $('#input-mensaje').on('keydown', function(e) {
                    if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        enviarMensaje();
                    }
                });
                
                // Auto-expandir textarea
                $('#input-mensaje').on('input', function() {
                    // Contador de caracteres
                    const longitud = $(this).val().length;
                    $('#contador').text(longitud);
                    
                    if (longitud > 1000) {
                        $('#contador').addClass('limit-exceeded');
                    } else {
                        $('#contador').removeClass('limit-exceeded');
                    }
                    
                    // Auto-expandir
                    this.style.height = 'auto';
                    this.style.height = (this.scrollHeight) + 'px';
                });
                
                // Recargar mensajes
                $('#recargar-chat').on('click', function() {
                    cargarMensajes();
                    cargarUsuariosConectados();
                    mostrarNotificacion('Recargando mensajes...', 'info');
                });
                
                // Limpiar chat visual
                $('#limpiar-chat').on('click', function() {
                    if (confirm('¿Estás seguro de que quieres limpiar el chat? Esto solo afecta tu vista.')) {
                        $('#contenedor-mensajes').empty();
                        ultimoMensajeId = 0;
                        cargarMensajes();
                    }
                });
                
                // Diagnosticar chat
                $('#diagnosticar-chat').on('click', function() {
                    diagnosticarChat();
                });
            }
            
            // Enviar mensaje
            function enviarMensaje() {
                const mensaje = $('#input-mensaje').val().trim();
                
                if (!mensaje) {
                    mostrarNotificacion('Por favor escribe un mensaje', 'warning');
                    return;
                }
                
                if (mensaje.length > 1000) {
                    mostrarNotificacion('El mensaje no puede tener más de 1000 caracteres', 'error');
                    return;
                }
                
                // Mostrar mensaje localmente inmediatamente
                mostrarMensajeLocal({
                    id: 'temp-' + Date.now(),
                    usuario: 'Tú',
                    mensaje: mensaje,
                    fecha: new Date().toISOString(),
                    propio: true,
                    sala: salaActual
                });
                
                // Limpiar input
                $('#input-mensaje').val('').height('auto');
                $('#contador').text('0').removeClass('limit-exceeded');
                
                // Enviar al servidor
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'enviar_mensaje_chat',
                        nonce: nonce,
                        mensaje: mensaje,
                        sala: salaActual
                    },
                    timeout: 10000,
                    success: function(response) {
                        if (response.success) {
                            // Reemplazar mensaje temporal con el real
                            $('.message-temp').last().remove();
                            mostrarMensaje(response.data);
                            ultimoMensajeId = Math.max(ultimoMensajeId, response.data.id);
                            mostrarNotificacion('Mensaje enviado correctamente', 'success');
                        } else {
                            mostrarNotificacion('Error: ' + response.data, 'error');
                            // Remover mensaje temporal en caso de error
                            $('.message-temp').last().remove();
                        }
                    },
                    error: function(xhr, status, error) {
                        const mensajeError = manejarErrorAJAX(xhr, status, error, 'enviar mensaje');
                        $('.message-temp').last().remove();
                    }
                });
            }
            
            // Cargar mensajes
            function cargarMensajes() {
                if (cargandoMensajes) return;
                
                cargandoMensajes = true;
                $('#indicador-carga').show();
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'cargar_mensajes_chat',
                        nonce: nonce,
                        sala: salaActual,
                        ultimo_id: ultimoMensajeId
                    },
                    timeout: 10000,
                    success: function(response) {
                        $('#indicador-carga').hide();
                        
                        if (response.success) {
                            mostrarNotificacion('Chat conectado correctamente', 'success');
                            intentosReconexion = 0; // Resetear intentos
                            
                            if (ultimoMensajeId === 0) {
                                // Primera carga, limpiar contenedor
                                $('#contenedor-mensajes').empty();
                            }
                            
                            if (response.data.length > 0) {
                                response.data.forEach(function(mensaje) {
                                    mostrarMensaje(mensaje);
                                    ultimoMensajeId = Math.max(ultimoMensajeId, mensaje.id);
                                });
                            }
                            
                            if (ultimoMensajeId === 0 && response.data.length === 0) {
                                $('#contenedor-mensajes').html(
                                    '<div class="loading-state"><p>No hay mensajes en esta sala. ¡Sé el primero en escribir!</p></div>'
                                );
                            }
                        } else {
                            console.error('Error al cargar mensajes: ' + response.data);
                            mostrarNotificacion('Error: ' + response.data, 'error');
                            mostrarErrorChat('No se pudieron cargar los mensajes: ' + response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        $('#indicador-carga').hide();
                        const mensajeError = manejarErrorAJAX(xhr, status, error, 'cargar mensajes');
                        
                        intentosReconexion++;
                        if (intentosReconexion <= maxIntentosReconexion) {
                            const mensajeReintento = `Error de conexión. Reintentando... (${intentosReconexion}/${maxIntentosReconexion})`;
                            mostrarNotificacion(mensajeReintento, 'warning');
                            
                            // Reintentar después de 3 segundos
                            setTimeout(function() {
                                cargandoMensajes = false;
                                cargarMensajes();
                            }, 3000);
                        } else {
                            mostrarNotificacion('Error de conexión persistente. Por favor recarga la página.', 'error');
                            mostrarErrorChat('No se pudo conectar al servidor del chat. Por favor verifica tu conexión.');
                        }
                    },
                    complete: function() {
                        cargandoMensajes = false;
                    }
                });
            }
            
            // Cargar usuarios conectados
            function cargarUsuariosConectados() {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'obtener_usuarios_conectados',
                        nonce: nonce,
                        sala: salaActual
                    },
                    timeout: 10000,
                    success: function(response) {
                        if (response.success) {
                            actualizarListaUsuarios(response.data);
                        } else {
                            console.error('Error en respuesta:', response.data);
                        }
                    },
                    error: function(xhr, status, error) {
                        manejarErrorAJAX(xhr, status, error, 'cargar usuarios conectados');
                    }
                });
            }
            
            // Actualizar lista de usuarios
            function actualizarListaUsuarios(usuarios) {
                const lista = $('#lista-usuarios');
                const usuarioActual = '<?php echo esc_js($usuario_actual->display_name ?: $usuario_actual->user_login); ?>';
                
                // Mantener el usuario actual
                lista.find('.user-item:first').show();
                
                // Remover otros usuarios (excepto el primero que es el usuario actual)
                lista.find('.user-item:not(:first)').remove();
                
                // Agregar otros usuarios
                if (usuarios && usuarios.length > 0) {
                    usuarios.forEach(function(usuario) {
                        if (usuario.usuario_nombre !== usuarioActual) {
                            lista.append(`
                                <li class="user-item" role="listitem">
                                    <div class="user-info">
                                        <span class="user-status" aria-label="Conectado"></span>
                                        <span class="user-name">${usuario.usuario_nombre}</span>
                                    </div>
                                </li>
                            `);
                        }
                    });
                }
                
                // Actualizar contador
                const totalUsuarios = usuarios ? usuarios.length : 1;
                $('#contador-usuarios').text(totalUsuarios + ' usuario' + (totalUsuarios !== 1 ? 's' : '') + ' conectado' + (totalUsuarios !== 1 ? 's' : ''));
            }
            
            // Mostrar mensaje local (temporal)
            function mostrarMensajeLocal(mensaje) {
                const elemento = crearElementoMensaje(mensaje);
                elemento.addClass('message-temp');
                $('#contenedor-mensajes').append(elemento);
                scrollToBottom();
            }
            
            // Mostrar mensaje del servidor
            function mostrarMensaje(mensaje) {
                const elemento = crearElementoMensaje(mensaje);
                $('#contenedor-mensajes').append(elemento);
                scrollToBottom();
            }
            
            // Crear elemento HTML para mensaje
            function crearElementoMensaje(mensaje) {
                const fecha = new Date(mensaje.fecha);
                const fechaFormateada = fecha.toLocaleTimeString('es-ES', {
                    hour: '2-digit',
                    minute: '2-digit'
                });
                
                const claseMensaje = mensaje.propio ? 'message message-own' : 'message message-other';
                
                const elemento = $(`
                    <article class="${claseMensaje}" data-mensaje-id="${mensaje.id}" role="article">
                        <header class="message-header">
                            <span class="message-user">${mensaje.usuario}</span>
                            <time class="message-time" datetime="${mensaje.fecha}">${fechaFormateada}</time>
                        </header>
                        <div class="message-content">
                            ${mensaje.mensaje}
                        </div>
                        ${mensaje.propio ? '<footer class="message-actions"><button class="btn-delete" title="Eliminar mensaje">🗑️ Eliminar</button></footer>' : ''}
                    </article>
                `);
                
                // Evento para eliminar mensaje
                if (mensaje.propio) {
                    elemento.find('.btn-delete').on('click', function() {
                        eliminarMensaje(mensaje.id, elemento);
                    });
                }
                
                return elemento;
            }
            
            // Eliminar mensaje
            function eliminarMensaje(mensajeId, elemento) {
                if (!confirm('¿Estás seguro de que quieres eliminar este mensaje?')) {
                    return;
                }
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'eliminar_mensaje_chat',
                        nonce: nonce,
                        mensaje_id: mensajeId
                    },
                    timeout: 10000,
                    success: function(response) {
                        if (response.success) {
                            elemento.fadeOut(300, function() {
                                $(this).remove();
                            });
                            mostrarNotificacion('Mensaje eliminado correctamente', 'success');
                        } else {
                            mostrarNotificacion('Error al eliminar mensaje: ' + response.data, 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        manejarErrorAJAX(xhr, status, error, 'eliminar mensaje');
                    }
                });
            }
            
            // Función para mostrar errores en el chat
            function mostrarErrorChat(mensaje) {
                const existeError = $('#error-chat-temporal').length;
                
                if (!existeError) {
                    $('#contenedor-mensajes').prepend(
                        `<div id="error-chat-temporal" class="message-error" role="alert">
                            <p>${mensaje}</p>
                        </div>`
                    );
                    
                    // Remover el error después de 10 segundos
                    setTimeout(function() {
                        $('#error-chat-temporal').fadeOut(300, function() {
                            $(this).remove();
                        });
                    }, 10000);
                }
            }
            
            // Scroll al final
            function scrollToBottom() {
                const contenedor = $('#contenedor-mensajes');
                contenedor.scrollTop(contenedor[0].scrollHeight);
            }
            
            // Diagnosticar problemas del chat
            function diagnosticarChat() {
                mostrarNotificacion('Ejecutando diagnóstico...', 'info');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'diagnosticar_chat',
                        nonce: nonce
                    },
                    timeout: 10000,
                    success: function(response) {
                        if (response.success) {
                            let mensajeDiagnostico = '✅ Diagnóstico completado:\n';
                            for (const [key, value] of Object.entries(response.data)) {
                                mensajeDiagnostico += `• ${key}: ${value}\n`;
                            }
                            alert(mensajeDiagnostico);
                            mostrarNotificacion('Diagnóstico completado', 'success');
                        } else {
                            mostrarNotificacion('Error en diagnóstico: ' + response.data, 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        manejarErrorAJAX(xhr, status, error, 'diagnosticar chat');
                    }
                });
            }
            
            // Actualización automática
            function iniciarActualizacionAutomatica() {
                intervaloActualizacion = setInterval(function() {
                    if (!cargandoMensajes) {
                        cargarMensajes();
                    }
                }, 5000);
                
                intervaloUsuarios = setInterval(function() {
                    cargarUsuariosConectados();
                }, 15000);
            }
            
            // Detener actualización automática
            function detenerActualizacionAutomatica() {
                if (intervaloActualizacion) {
                    clearInterval(intervaloActualizacion);
                }
                if (intervaloUsuarios) {
                    clearInterval(intervaloUsuarios);
                }
            }
            
            // Inicializar cuando la página está lista
            inicializarChat();
            
            // Limpiar al salir de la página
            $(window).on('beforeunload', function() {
                detenerActualizacionAutomatica();
            });
        });
        </script>
        <?php
    }
}

// Inicializar el chat
$chat_operadores = new ChatOperadores();

// Función para mostrar el chat en el admin
function mostrar_chat_operadores_admin() {
    global $chat_operadores;
    $chat_operadores->mostrar_chat();
}

// Registrar hook de activación para crear tablas
register_activation_hook(__FILE__, array($chat_operadores, 'verificar_tablas_chat'));