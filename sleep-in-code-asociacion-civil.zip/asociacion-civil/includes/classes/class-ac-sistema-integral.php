<?php
/**
 * Clase principal del Sistema Integral de Gestión
 * Contiene toda la lógica del sistema
 */

if (!defined('ABSPATH')) {
    exit;
}

class AC_Sistema_Integral {
    
    // Propiedades
    private $plugin_dir;
    private $plugin_url;
    private $version = '2.0';
    
    // Instancia única
    private static $instance = null;
    
    /**
     * Constructor privado (singleton)
     */
    private function __construct() {
        $this->plugin_dir = plugin_dir_path(dirname(dirname(__FILE__)));
        $this->plugin_url = plugin_dir_url(dirname(dirname(__FILE__)));
        
        // Configurar zona horaria
        date_default_timezone_set('America/Argentina/Buenos_Aires');
    }
    
    /**
     * Obtener instancia única
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Obtener datos del horario
     */
    public function obtener_estado_horario() {
        $hora_actual = date('H:i');
        $dia_actual = date('N');
        
        // Estructura horaria
        $actividades = [
            '08:00' => ['actividad' => 'Buen día / Despertar', 'icono' => '☀️', 'duracion' => 30, 'tipo' => 'rutina'],
            '08:30' => ['actividad' => 'Desayuno', 'icono' => '🍽️', 'duracion' => 30, 'tipo' => 'alimentacion'],
            '09:00' => ['actividad' => 'Lectura: "Solo por Hoy" + Libro Azul + Reflexión', 'icono' => '📖', 'duracion' => 30, 'tipo' => 'desarrollo_personal'],
            '09:30' => ['actividad' => 'Objetivos del día', 'icono' => '🎯', 'duracion' => 30, 'tipo' => 'planificacion'],
            '10:00' => ['actividad' => 'Reorden (organización y limpieza)', 'icono' => '🧹', 'duracion' => 90, 'tipo' => 'organizacion'],
            '11:30' => ['actividad' => 'Grupo de Sentimiento Libre', 'icono' => '👥', 'duracion' => 60, 'tipo' => 'terapia_grupal'],
            '12:30' => ['actividad' => 'Almuerzo', 'icono' => '🥗', 'duracion' => 30, 'tipo' => 'alimentacion'],
            '13:00' => ['actividad' => 'Hora Libre', 'icono' => '🆓', 'duracion' => 130, 'tipo' => 'descanso'],
            '15:10' => ['actividad' => 'Grupo de R.E.S. escrita del día anterior', 'icono' => '✍️', 'duracion' => 170, 'tipo' => 'terapia_escrita'],
            '18:10' => ['actividad' => 'Merienda', 'icono' => '☕', 'duracion' => 50, 'tipo' => 'alimentacion'],
            '19:00' => ['actividad' => 'Grupo de Escritura de R.E.S. para leer al día siguiente', 'icono' => '📝', 'duracion' => 120, 'tipo' => 'terapia_escrita'],
            '21:00' => ['actividad' => 'Cena', 'icono' => '🍲', 'duracion' => 60, 'tipo' => 'alimentacion'],
            '22:00' => ['actividad' => 'Medicación', 'icono' => '💊', 'duracion' => 60, 'tipo' => 'salud'],
            '23:00' => ['actividad' => 'Todos a la cama', 'icono' => '🛌', 'duracion' => 480, 'tipo' => 'descanso']
        ];
        
        return [
            'hora_actual' => $hora_actual,
            'dia_actual' => $dia_actual,
            'actividades' => $actividades
        ];
    }
    
    /**
     * Obtener actividad actual
     */
    public function obtener_actividad_actual($datos_horario = null) {
        if (!$datos_horario) {
            $datos_horario = $this->obtener_estado_horario();
        }
        
        $hora_actual = $datos_horario['hora_actual'];
        $actividades = $datos_horario['actividades'];
        
        $actividad_actual = null;
        $hora_actual_ts = strtotime($hora_actual);
        
        foreach ($actividades as $hora => $detalles) {
            $hora_inicio_ts = strtotime($hora);
            $hora_fin_ts = strtotime($hora . ' + ' . $detalles['duracion'] . ' minutes');
            
            // Si la hora actual está entre el inicio y el fin de la actividad
            if ($hora_actual_ts >= $hora_inicio_ts && $hora_actual_ts < $hora_fin_ts) {
                $actividad_actual = [
                    'hora' => $hora,
                    'detalles' => $detalles,
                    'hora_fin' => date('H:i', $hora_fin_ts)
                ];
                break;
            }
        }
        
        return $actividad_actual;
    }
    
    /**
     * Obtener próximas actividades
     */
    public function obtener_proximas_actividades($datos_horario = null, $limite = 3) {
        if (!$datos_horario) {
            $datos_horario = $this->obtener_estado_horario();
        }
        
        $hora_actual = $datos_horario['hora_actual'];
        $actividades = $datos_horario['actividades'];
        
        $proximas = [];
        $hora_actual_ts = strtotime($hora_actual);
        
        foreach ($actividades as $hora => $detalles) {
            $hora_actividad_ts = strtotime($hora);
            
            // Solo incluir actividades futuras
            if ($hora_actividad_ts > $hora_actual_ts) {
                $minutos_restantes = round(($hora_actividad_ts - $hora_actual_ts) / 60);
                
                $proximas[] = [
                    'hora' => $hora, 
                    'detalles' => $detalles,
                    'minutos_restantes' => $minutos_restantes,
                    'timestamp' => $hora_actividad_ts
                ];
                
                if (count($proximas) >= $limite) break;
            }
        }
        
        return $proximas;
    }
    
    /**
     * Calcular progreso del día
     */
    public function calcular_progreso_dia($datos_horario = null) {
        if (!$datos_horario) {
            $datos_horario = $this->obtener_estado_horario();
        }
        
        $hora_actual = strtotime($datos_horario['hora_actual']);
        $inicio_dia = strtotime('08:00');
        $fin_dia = strtotime('23:00');
        $total_minutos = ($fin_dia - $inicio_dia) / 60;
        $minutos_transcurridos = ($hora_actual - $inicio_dia) / 60;
        
        if ($minutos_transcurridos < 0) return 0;
        if ($minutos_transcurridos > $total_minutos) return 100;
        
        return round(($minutos_transcurridos / $total_minutos) * 100);
    }
    
    /**
     * Obtener estadísticas de cumplimiento
     */
    public function obtener_estadisticas_cumplimiento($rango = 'semana') {
        // Datos de ejemplo para demostración
        // En una implementación real, estos vendrían de la base de datos
        
        $fecha_fin = date('Y-m-d');
        switch ($rango) {
            case 'hoy':
                $fecha_inicio = $fecha_fin;
                break;
            case 'semana':
                $fecha_inicio = date('Y-m-d', strtotime('-6 days'));
                break;
            case 'mes':
                $fecha_inicio = date('Y-m-d', strtotime('-29 days'));
                break;
            default:
                $fecha_inicio = date('Y-m-d', strtotime('-6 days'));
        }
        
        // Ejemplo de datos estáticos
        return [
            'total_actividades' => 45,
            'completadas' => 38,
            'pendientes' => 4,
            'canceladas' => 2,
            'no_cumplidas' => 1,
            'en_progreso' => 0,
            'porcentaje_completadas' => 84,
            'porcentaje_pendientes' => 9,
            'porcentaje_canceladas' => 4,
            'porcentaje_no_cumplidas' => 2,
            'porcentaje_en_progreso' => 0,
            'valoracion_promedio' => 4.2,
            'duracion_promedio' => 58,
            'rango' => $rango,
            'fecha_inicio' => $fecha_inicio,
            'fecha_fin' => $fecha_fin,
            'con_datos' => true
        ];
    }
    
    /**
     * Obtener días de la semana
     */
    public function obtener_dias_semana() {
        return [
            1 => 'Lunes',
            2 => 'Martes', 
            3 => 'Miércoles',
            4 => 'Jueves',
            5 => 'Viernes',
            6 => 'Sábado',
            7 => 'Domingo'
        ];
    }
    
    /**
     * Obtener actividades faltantes (simulación)
     */
    public function obtener_actividades_faltantes() {
        // Ejemplo de actividades faltantes
        return [
            [
                'hora' => '08:30',
                'actividad' => 'Desayuno',
                'icono' => '🍽️',
                'tipo' => 'alimentacion',
                'duracion' => 30
            ],
            [
                'hora' => '09:00',
                'actividad' => 'Lectura: "Solo por Hoy" + Libro Azul + Reflexión',
                'icono' => '📖',
                'tipo' => 'desarrollo_personal',
                'duracion' => 30
            ]
        ];
    }
    
    /**
     * Verificar permisos del usuario
     */
    public function verificar_permisos() {
        if (!current_user_can('manage_options') && !current_user_can('edit_pages')) {
            wp_die('No tienes permisos para acceder a esta página.');
        }
    }
    
    /**
     * Obtener URL del plugin
     */
    public function get_plugin_url() {
        return $this->plugin_url;
    }
    
    /**
     * Obtener ruta del plugin
     */
    public function get_plugin_dir() {
        return $this->plugin_dir;
    }
    
    /**
     * Obtener versión
     */
    public function get_version() {
        return $this->version;
    }
    
    /**
     * Obtener datos de ejemplo para actas
     */
    public function obtener_actas_ejemplo() {
        return [
            [
                'id' => 1,
                'titulo' => 'Reunión de Coordinación General',
                'fecha' => date('Y-m-d', strtotime('-2 days')),
                'lugar' => 'Sala de Conferencias',
                'tipo' => 'ordinaria',
                'convocante' => 'Directora General',
                'asistentes' => "Juan Pérez\nMaría González\nCarlos López",
                'contenido' => 'Se discutieron los avances del proyecto y se establecieron nuevas metas.',
                'acuerdos' => "Asignar recursos para el nuevo módulo\nProgramar capacitación para el equipo\nRevisar presupuesto mensual",
                'fecha_creacion' => date('Y-m-d H:i:s', strtotime('-2 days')),
                'fecha_actualizacion' => date('Y-m-d H:i:s', strtotime('-2 days'))
            ],
            [
                'id' => 2,
                'titulo' => 'Evaluación de Proyectos',
                'fecha' => date('Y-m-d', strtotime('-5 days')),
                'lugar' => 'Oficina Principal',
                'tipo' => 'comision',
                'convocante' => 'Comité de Evaluación',
                'asistentes' => "Ana Rodríguez\nLuis Martínez\nPatricia Sánchez",
                'contenido' => 'Revisión de los proyectos presentados y evaluación de viabilidad.',
                'acuerdos' => "Aprobar proyecto de renovación\nSolicitar más información al proyecto B\nAsignar mentor al proyecto C",
                'fecha_creacion' => date('Y-m-d H:i:s', strtotime('-5 days')),
                'fecha_actualizacion' => date('Y-m-d H:i:s', strtotime('-5 days'))
            ]
        ];
    }
    
    /**
     * Obtener datos de ejemplo para medicación
     */
    public function obtener_medicacion_ejemplo() {
        return [
            [
                'id' => 1,
                'paciente_nombre' => 'Juan Pérez',
                'medicamento' => 'Paracetamol',
                'dosis' => '500mg',
                'frecuencia' => 'Cada 8 horas',
                'fecha_inicio' => date('Y-m-d', strtotime('-10 days')),
                'fecha_fin' => date('Y-m-d', strtotime('+5 days')),
                'prescrito_por' => 'Dr. Martínez'
            ],
            [
                'id' => 2,
                'paciente_nombre' => 'María González',
                'medicamento' => 'Ibuprofeno',
                'dosis' => '400mg',
                'frecuencia' => 'Cada 12 horas',
                'fecha_inicio' => date('Y-m-d', strtotime('-3 days')),
                'fecha_fin' => '',
                'prescrito_por' => 'Dra. Rodríguez'
            ]
        ];
    }
    
    /**
     * Obtener pacientes de ejemplo
     */
    public function obtener_pacientes_ejemplo() {
        return [
            ['id' => 1, 'nombre' => 'Juan', 'apellido' => 'Pérez'],
            ['id' => 2, 'nombre' => 'María', 'apellido' => 'González'],
            ['id' => 3, 'nombre' => 'Carlos', 'apellido' => 'López']
        ];
    }
}