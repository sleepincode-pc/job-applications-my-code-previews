<?php

namespace AsociacionCivil;

class HistorialMedico {
    
    private $id;
    private $paciente_id;
    private $fecha_consulta;
    private $tipo_consulta;
    private $medico_tratante;
    private $diagnostico;
    private $tratamiento_prescrito;
    private $medicamentos_recetados;
    private $examenes_solicitados;
    private $resultados_examenes;
    private $observaciones;
    private $proxima_cita;
    private $created_at;

    public function __construct($id = null) {
        if ($id) {
            $this->id = $id;
            $this->cargar();
        }
    }

    public function cargar() {
        global $wpdb;
        $tabla = $wpdb->prefix . 'ac_historial_medico';
        $historial = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tabla WHERE id = %d", $this->id), ARRAY_A);
        
        if ($historial) {
            $this->paciente_id = $historial['paciente_id'];
            $this->fecha_consulta = $historial['fecha_consulta'];
            $this->tipo_consulta = $historial['tipo_consulta'];
            $this->medico_tratante = $historial['medico_tratante'];
            $this->diagnostico = $historial['diagnostico'];
            $this->tratamiento_prescrito = $historial['tratamiento_prescrito'];
            $this->medicamentos_recetados = $historial['medicamentos_recetados'];
            $this->examenes_solicitados = $historial['examenes_solicitados'];
            $this->resultados_examenes = $historial['resultados_examenes'];
            $this->observaciones = $historial['observaciones'];
            $this->proxima_cita = $historial['proxima_cita'];
            $this->created_at = $historial['created_at'];
            return true;
        }
        return false;
    }

    public function guardar() {
        global $wpdb;
        $tabla = $wpdb->prefix . 'ac_historial_medico';

        $datos = array(
            'paciente_id' => $this->paciente_id,
            'fecha_consulta' => $this->fecha_consulta,
            'tipo_consulta' => $this->tipo_consulta,
            'medico_tratante' => $this->medico_tratante,
            'diagnostico' => $this->diagnostico,
            'tratamiento_prescrito' => $this->tratamiento_prescrito,
            'medicamentos_recetados' => $this->medicamentos_recetados,
            'examenes_solicitados' => $this->examenes_solicitados,
            'resultados_examenes' => $this->resultados_examenes,
            'observaciones' => $this->observaciones,
            'proxima_cita' => $this->proxima_cita
        );

        if ($this->id) {
            return $wpdb->update($tabla, $datos, array('id' => $this->id));
        } else {
            $datos['created_at'] = current_time('mysql');
            $resultado = $wpdb->insert($tabla, $datos);
            if ($resultado) {
                $this->id = $wpdb->insert_id;
            }
            return $resultado;
        }
    }

    public function eliminar() {
        global $wpdb;
        $tabla = $wpdb->prefix . 'ac_historial_medico';
        return $wpdb->delete($tabla, array('id' => $this->id));
    }

    // Getters
    public function getId() { return $this->id; }
    public function getPacienteId() { return $this->paciente_id; }
    public function getFechaConsulta() { return $this->fecha_consulta; }
    public function getTipoConsulta() { return $this->tipo_consulta; }
    public function getMedicoTratante() { return $this->medico_tratante; }
    public function getDiagnostico() { return $this->diagnostico; }
    public function getTratamientoPrescrito() { return $this->tratamiento_prescrito; }
    public function getMedicamentosRecetados() { return $this->medicamentos_recetados; }
    public function getExamenesSolicitados() { return $this->examenes_solicitados; }
    public function getResultadosExamenes() { return $this->resultados_examenes; }
    public function getObservaciones() { return $this->observaciones; }
    public function getProximaCita() { return $this->proxima_cita; }
    public function getCreatedAt() { return $this->created_at; }

    // Setters
    public function setId($id) { $this->id = $id; }
    public function setPacienteId($paciente_id) { $this->paciente_id = $paciente_id; }
    public function setFechaConsulta($fecha_consulta) { $this->fecha_consulta = $fecha_consulta; }
    public function setTipoConsulta($tipo_consulta) { $this->tipo_consulta = $tipo_consulta; }
    public function setMedicoTratante($medico_tratante) { $this->medico_tratante = $medico_tratante; }
    public function setDiagnostico($diagnostico) { $this->diagnostico = $diagnostico; }
    public function setTratamientoPrescrito($tratamiento_prescrito) { $this->tratamiento_prescrito = $tratamiento_prescrito; }
    public function setMedicamentosRecetados($medicamentos_recetados) { $this->medicamentos_recetados = $medicamentos_recetados; }
    public function setExamenesSolicitados($examenes_solicitados) { $this->examenes_solicitados = $examenes_solicitados; }
    public function setResultadosExamenes($resultados_examenes) { $this->resultados_examenes = $resultados_examenes; }
    public function setObservaciones($observaciones) { $this->observaciones = $observaciones; }
    public function setProximaCita($proxima_cita) { $this->proxima_cita = $proxima_cita; }
}