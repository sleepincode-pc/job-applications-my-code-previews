<?php
namespace AsociacionCivil;

// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

class Database {
    
    // Propiedades para los nombres de las tablas
    private $table_miembros;
    private $table_eventos;
    private $table_documentos;
    private $table_psicodramas;
    private $table_pacientes;
    private $table_historial_medico;
    private $table_seguimiento_terapeutico;
    private $table_solo_por_hoy;
    private $table_reuniones;
    private $table_chat_operadores;
    private $table_tiempo_limpio;
    private $table_registros_diarios;
    private $table_medicacion;
    
    public function __construct() {
        global $wpdb;
        $this->table_miembros = $wpdb->prefix . 'ac_miembros';
        $this->table_eventos = $wpdb->prefix . 'ac_eventos';
        $this->table_documentos = $wpdb->prefix . 'ac_documentos';
        $this->table_psicodramas = $wpdb->prefix . 'ac_psicodramas';
        $this->table_pacientes = $wpdb->prefix . 'ac_pacientes';
        $this->table_historial_medico = $wpdb->prefix . 'ac_historial_medico';
        $this->table_seguimiento_terapeutico = $wpdb->prefix . 'ac_seguimiento_terapeutico';
        $this->table_solo_por_hoy = $wpdb->prefix . 'ac_solo_por_hoy';
        $this->table_reuniones = $wpdb->prefix . 'ac_reuniones';
        $this->table_chat_operadores = $wpdb->prefix . 'ac_chat_operadores';
        $this->table_tiempo_limpio = $wpdb->prefix . 'ac_tiempo_limpio';
        $this->table_registros_diarios = $wpdb->prefix . 'ac_registros_diarios';
        $this->table_medicacion = $wpdb->prefix . 'ac_medicacion';
    }
    
    /**
     * Crear todas las tablas del sistema
     */
    public function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Tabla de miembros (versión unificada)
        $sql_miembros = "CREATE TABLE {$this->table_miembros} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            cedula varchar(20) NOT NULL,
            nombre varchar(100) NOT NULL,
            apellido varchar(100) NOT NULL,
            email varchar(100) NOT NULL,
            telefono varchar(20),
            direccion text,
            fecha_nacimiento date,
            fecha_ingreso date NOT NULL,
            tipo_membresia varchar(50) DEFAULT 'activo',
            cargo varchar(100),
            estado varchar(20) DEFAULT 'activo',
            foto varchar(255),
            observaciones text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY cedula (cedula),
            UNIQUE KEY email (email)
        ) $charset_collate;";
        
        // Tabla de eventos
        $sql_eventos = "CREATE TABLE {$this->table_eventos} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            titulo varchar(200) NOT NULL,
            descripcion text,
            fecha datetime NOT NULL,
            lugar varchar(200),
            tipo varchar(50) DEFAULT 'reunion',
            asistentes text,
            acta text,
            estado varchar(20) DEFAULT 'planificado',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        // Tabla de documentos
        $sql_documentos = "CREATE TABLE {$this->table_documentos} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            titulo varchar(200) NOT NULL,
            descripcion text,
            tipo varchar(50) NOT NULL,
            archivo varchar(255) NOT NULL,
            fecha_subida datetime DEFAULT CURRENT_TIMESTAMP,
            fecha_documento date,
            categoria varchar(100),
            visible_para varchar(50) DEFAULT 'junta',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";

        // Tabla de psicodramas (versión unificada)
        $sql_psicodramas = "CREATE TABLE {$this->table_psicodramas} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            titulo varchar(200) NOT NULL,
            descripcion text,
            fecha_sesion datetime NOT NULL,
            duracion int DEFAULT 90,
            facilitador_id mediumint(9) NOT NULL,
            cofacilitador_id mediumint(9),
            participantes text,
            tema_central varchar(255),
            tecnica_utilizada varchar(100),
            observaciones text,
            estado varchar(20) DEFAULT 'planificada',
            proxima_sesion datetime,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY fecha_sesion (fecha_sesion),
            KEY facilitador_id (facilitador_id),
            KEY estado (estado)
        ) $charset_collate;";

        // Tabla de pacientes (versión mejorada)
        $sql_pacientes = "CREATE TABLE {$this->table_pacientes} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            cedula varchar(50) NOT NULL,
            nombre varchar(255) NOT NULL,
            apellido varchar(255) NOT NULL,
            fecha_nacimiento date,
            genero varchar(20),
            telefono varchar(50),
            email varchar(255),
            direccion text,
            contacto_emergencia_nombre varchar(100),
            contacto_emergencia_telefono varchar(20),
            contacto_emergencia_parentesco varchar(50),
            historial_medico text,
            alergias text,
            medicamentos_actuales text,
            seguro_medico varchar(100),
            numero_seguro_medico varchar(50),
            estado_civil varchar(30),
            ocupacion varchar(100),
            nivel_educativo varchar(50),
            referencia_por varchar(100),
            motivo_consulta_principal text,
            expectativas_tratamiento text,
            fecha_ingreso date NOT NULL,
            estado varchar(50) DEFAULT 'activo',
            observaciones_generales text,
            foto varchar(255),
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY cedula (cedula),
            KEY idx_estado (estado),
            KEY idx_nombre (nombre),
            KEY idx_apellido (apellido)
        ) $charset_collate;";

        // Tabla de historial médico
        $sql_historial_medico = "CREATE TABLE {$this->table_historial_medico} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            paciente_id mediumint(9) NOT NULL,
            fecha_consulta date NOT NULL,
            tipo_consulta varchar(100),
            medico_tratante varchar(100),
            diagnostico text,
            tratamiento_prescrito text,
            medicamentos_recetados text,
            examenes_solicitados text,
            resultados_examenes text,
            observaciones text,
            proxima_cita date,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY paciente_id (paciente_id),
            KEY fecha_consulta (fecha_consulta)
        ) $charset_collate;";

        // Tabla de seguimiento terapéutico
        $sql_seguimiento_terapeutico = "CREATE TABLE {$this->table_seguimiento_terapeutico} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            paciente_id mediumint(9) NOT NULL,
            terapeuta_id mediumint(9) NOT NULL,
            fecha_seguimiento datetime NOT NULL,
            tipo_seguimiento varchar(100),
            objetivo_tratamiento text,
            progreso_observado text,
            dificultades_identificadas text,
            intervenciones_realizadas text,
            tareas_asignadas text,
            nivel_progreso varchar(50),
            observaciones_terapeuta text,
            proxima_sesion datetime,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY paciente_id (paciente_id),
            KEY terapeuta_id (terapeuta_id),
            KEY fecha_seguimiento (fecha_seguimiento)
        ) $charset_collate;";

        // Tabla de Solo por Hoy
        $sql_solo_por_hoy = "CREATE TABLE {$this->table_solo_por_hoy} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            fecha date NOT NULL,
            titulo varchar(200) NOT NULL,
            contenido text NOT NULL,
            autor_id mediumint(9) NOT NULL,
            estado varchar(20) DEFAULT 'publicado',
            tipo_reflexion varchar(50) DEFAULT 'diaria',
            tags text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY fecha (fecha),
            KEY autor_id (autor_id),
            KEY estado (estado)
        ) $charset_collate;";

        // Tabla de Reuniones
        $sql_reuniones = "CREATE TABLE {$this->table_reuniones} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            titulo varchar(200) NOT NULL,
            tipo varchar(50) DEFAULT 'ordinaria',
            fecha datetime NOT NULL,
            hora_inicio time NOT NULL,
            hora_fin time,
            lugar varchar(200),
            convocante varchar(100),
            asistentes text,
            agenda text,
            acuerdos text,
            minutos text,
            estado varchar(20) DEFAULT 'planificada',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY fecha (fecha),
            KEY tipo (tipo),
            KEY estado (estado)
        ) $charset_collate;";

        // Tabla de Chat de Operadores
        $sql_chat_operadores = "CREATE TABLE {$this->table_chat_operadores} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            operador_id mediumint(9) NOT NULL,
            mensaje text NOT NULL,
            tipo_mensaje varchar(50) DEFAULT 'texto',
            destinatario_id mediumint(9),
            leido boolean DEFAULT FALSE,
            urgente boolean DEFAULT FALSE,
            fecha_envio datetime DEFAULT CURRENT_TIMESTAMP,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY operador_id (operador_id),
            KEY destinatario_id (destinatario_id),
            KEY fecha_envio (fecha_envio),
            KEY leido (leido)
        ) $charset_collate;";

        // Tabla de Tiempo Limpio
        $sql_tiempo_limpio = "CREATE TABLE {$this->table_tiempo_limpio} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            paciente_id mediumint(9) NOT NULL,
            fecha_inicio_abstinencia date NOT NULL,
            fecha_registro date NOT NULL,
            tipo_sustancia varchar(100),
            estado_actual varchar(50) DEFAULT 'abstinente',
            avances text,
            dificultades text,
            metas_cumplidas text,
            observaciones text,
            terapeuta_id mediumint(9),
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY paciente_id (paciente_id),
            KEY fecha_inicio_abstinencia (fecha_inicio_abstinencia),
            KEY estado_actual (estado_actual)
        ) $charset_collate;";

        // Tabla de registros diarios (para el sistema integral)
        $sql_registros_diarios = "CREATE TABLE {$this->table_registros_diarios} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            fecha date NOT NULL,
            actividad_id varchar(255) NOT NULL,
            actividad_nombre varchar(255) NOT NULL,
            estado varchar(50) NOT NULL,
            duracion_real int(11),
            valoracion int(11),
            observaciones text,
            tipo_actividad varchar(100),
            fecha_creacion datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_fecha (fecha),
            KEY idx_actividad (actividad_id),
            KEY idx_estado (estado)
        ) $charset_collate;";

        // Tabla de medicación (versión mejorada)
        $sql_medicacion = "CREATE TABLE {$this->table_medicacion} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            paciente_id mediumint(9) NOT NULL,
            medicamento varchar(255) NOT NULL,
            dosis varchar(100) NOT NULL,
            frecuencia varchar(100) NOT NULL,
            via_administracion varchar(50),
            fecha_inicio date NOT NULL,
            fecha_fin date,
            horario_administracion text,
            indicaciones_especiales text,
            estado varchar(20) DEFAULT 'activo',
            prescrito_por varchar(255),
            observaciones text,
            fecha_creacion datetime DEFAULT CURRENT_TIMESTAMP,
            fecha_actualizacion datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY paciente_id (paciente_id),
            KEY estado (estado),
            KEY fecha_inicio (fecha_inicio)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        // Crear todas las tablas
        $tablas_sql = [
            $sql_miembros, $sql_eventos, $sql_documentos, $sql_psicodramas, 
            $sql_pacientes, $sql_historial_medico, $sql_seguimiento_terapeutico, 
            $sql_solo_por_hoy, $sql_reuniones, $sql_chat_operadores, $sql_tiempo_limpio, 
            $sql_registros_diarios, $sql_medicacion
        ];
        
        foreach ($tablas_sql as $sql) {
            dbDelta($sql);
        }
        
        // Verificar si las tablas se crearon correctamente
        return $this->verificar_tablas_creadas();
    }
    
    /**
     * Verificar que todas las tablas se crearon correctamente
     */
    private function verificar_tablas_creadas() {
        global $wpdb;
        
        $tablas = [
            $this->table_miembros,
            $this->table_eventos,
            $this->table_documentos,
            $this->table_psicodramas,
            $this->table_pacientes,
            $this->table_historial_medico,
            $this->table_seguimiento_terapeutico,
            $this->table_solo_por_hoy,
            $this->table_reuniones,
            $this->table_chat_operadores,
            $this->table_tiempo_limpio,
            $this->table_registros_diarios,
            $this->table_medicacion
        ];
        
        foreach ($tablas as $tabla) {
            if ($wpdb->get_var("SHOW TABLES LIKE '$tabla'") != $tabla) {
                error_log("Error: La tabla $tabla no se creó correctamente");
                return false;
            }
        }
        
        return true;
    }

    // =================================================================
    // MÉTODOS PARA EL SISTEMA INTEGRAL - TABLAS PRINCIPALES
    // =================================================================

    /**
     * Verificar si una tabla existe
     */
    public function tabla_existe($tipo) {
        global $wpdb;
        $tabla_nombre = $this->get_table_name($tipo);
        return $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tabla_nombre)) == $tabla_nombre;
    }

    /**
     * Obtener el nombre de una tabla por tipo
     */
    public function get_table_name($tipo) {
        switch ($tipo) {
            case 'miembros':
                return $this->table_miembros;
            case 'eventos':
                return $this->table_eventos;
            case 'documentos':
                return $this->table_documentos;
            case 'psicodramas':
                return $this->table_psicodramas;
            case 'pacientes':
                return $this->table_pacientes;
            case 'historial_medico':
                return $this->table_historial_medico;
            case 'seguimiento_terapeutico':
                return $this->table_seguimiento_terapeutico;
            case 'solo_por_hoy':
                return $this->table_solo_por_hoy;
            case 'reuniones':
                return $this->table_reuniones;
            case 'chat_operadores':
                return $this->table_chat_operadores;
            case 'tiempo_limpio':
                return $this->table_tiempo_limpio;
            case 'registros_diarios':
                return $this->table_registros_diarios;
            case 'medicacion':
                return $this->table_medicacion;
            default:
                return false;
        }
    }

    // =================================================================
    // MÉTODOS PARA SOLO POR HOY
    // =================================================================

    public function get_solo_por_hoy($args = []) {
        global $wpdb;
        
        if (!$this->tabla_existe('solo_por_hoy')) {
            return [];
        }
        
        $defaults = [
            'number' => 20,
            'offset' => 0,
            'orderby' => 'fecha',
            'order' => 'DESC',
            'estado' => 'publicado'
        ];
        
        $args = wp_parse_args($args, $defaults);
        
        $where = "1=1";
        $prepare_values = [];
        
        if (!empty($args['estado'])) {
            $where .= " AND estado = %s";
            $prepare_values[] = $args['estado'];
        }
        
        $query = "SELECT * FROM {$this->table_solo_por_hoy} WHERE $where ORDER BY {$args['orderby']} {$args['order']} LIMIT %d OFFSET %d";
        $prepare_values[] = $args['number'];
        $prepare_values[] = $args['offset'];
        
        if (!empty($prepare_values)) {
            $query = $wpdb->prepare($query, $prepare_values);
        }
        
        return $wpdb->get_results($query, ARRAY_A);
    }
    
    public function get_solo_por_hoy_by_id($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('solo_por_hoy')) {
            return null;
        }
        
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_solo_por_hoy} WHERE id = %d", $id),
            ARRAY_A
        );
    }
    
    public function get_solo_por_hoy_por_fecha($fecha) {
        global $wpdb;
        
        if (!$this->tabla_existe('solo_por_hoy')) {
            return null;
        }
        
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_solo_por_hoy} WHERE fecha = %s", $fecha),
            ARRAY_A
        );
    }
    
    public function insert_solo_por_hoy($data) {
        global $wpdb;
        
        if (!$this->tabla_existe('solo_por_hoy')) {
            return new \WP_Error('table_missing', 'La tabla de Solo por Hoy no existe');
        }
        
        $data = $this->sanitizar_datos_solo_por_hoy($data);
        
        $resultado = $wpdb->insert($this->table_solo_por_hoy, $data);
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $wpdb->insert_id;
    }
    
    public function update_solo_por_hoy($id, $data) {
        global $wpdb;
        
        if (!$this->tabla_existe('solo_por_hoy')) {
            return new \WP_Error('table_missing', 'La tabla de Solo por Hoy no existe');
        }
        
        $data = $this->sanitizar_datos_solo_por_hoy($data);
        
        $resultado = $wpdb->update(
            $this->table_solo_por_hoy,
            $data,
            ['id' => $id]
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    public function delete_solo_por_hoy($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('solo_por_hoy')) {
            return new \WP_Error('table_missing', 'La tabla de Solo por Hoy no existe');
        }
        
        $resultado = $wpdb->delete(
            $this->table_solo_por_hoy,
            ['id' => $id],
            ['%d']
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    private function sanitizar_datos_solo_por_hoy($data) {
        $sanitized = [];
        
        if (isset($data['fecha'])) {
            $sanitized['fecha'] = sanitize_text_field($data['fecha']);
        }
        if (isset($data['titulo'])) {
            $sanitized['titulo'] = sanitize_text_field($data['titulo']);
        }
        if (isset($data['contenido'])) {
            $sanitized['contenido'] = wp_kses_post($data['contenido']);
        }
        if (isset($data['autor_id'])) {
            $sanitized['autor_id'] = intval($data['autor_id']);
        }
        if (isset($data['estado'])) {
            $sanitized['estado'] = sanitize_text_field($data['estado']);
        }
        if (isset($data['tipo_reflexion'])) {
            $sanitized['tipo_reflexion'] = sanitize_text_field($data['tipo_reflexion']);
        }
        if (isset($data['tags'])) {
            $sanitized['tags'] = sanitize_text_field($data['tags']);
        }
        
        return $sanitized;
    }

    // =================================================================
    // MÉTODOS PARA REUNIONES
    // =================================================================

    public function get_reuniones($args = []) {
        global $wpdb;
        
        if (!$this->tabla_existe('reuniones')) {
            return [];
        }
        
        $defaults = [
            'number' => 20,
            'offset' => 0,
            'orderby' => 'fecha',
            'order' => 'DESC',
            'estado' => '',
            'tipo' => ''
        ];
        
        $args = wp_parse_args($args, $defaults);
        
        $where = "1=1";
        $prepare_values = [];
        
        if (!empty($args['estado'])) {
            $where .= " AND estado = %s";
            $prepare_values[] = $args['estado'];
        }
        
        if (!empty($args['tipo'])) {
            $where .= " AND tipo = %s";
            $prepare_values[] = $args['tipo'];
        }
        
        $query = "SELECT * FROM {$this->table_reuniones} WHERE $where ORDER BY {$args['orderby']} {$args['order']} LIMIT %d OFFSET %d";
        $prepare_values[] = $args['number'];
        $prepare_values[] = $args['offset'];
        
        if (!empty($prepare_values)) {
            $query = $wpdb->prepare($query, $prepare_values);
        }
        
        return $wpdb->get_results($query, ARRAY_A);
    }
    
    public function get_reunion_by_id($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('reuniones')) {
            return null;
        }
        
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_reuniones} WHERE id = %d", $id),
            ARRAY_A
        );
    }
    
    public function insert_reunion($data) {
        global $wpdb;
        
        if (!$this->tabla_existe('reuniones')) {
            return new \WP_Error('table_missing', 'La tabla de reuniones no existe');
        }
        
        $defaults = [
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ];
        
        $data = wp_parse_args($data, $defaults);
        
        // Serializar asistentes si es un array
        if (isset($data['asistentes']) && is_array($data['asistentes'])) {
            $data['asistentes'] = maybe_serialize($data['asistentes']);
        }
        
        $data = $this->sanitizar_datos_reunion($data);
        
        $resultado = $wpdb->insert($this->table_reuniones, $data);
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $wpdb->insert_id;
    }
    
    public function update_reunion($id, $data) {
        global $wpdb;
        
        if (!$this->tabla_existe('reuniones')) {
            return new \WP_Error('table_missing', 'La tabla de reuniones no existe');
        }
        
        $data['updated_at'] = current_time('mysql');
        
        // Serializar asistentes si es un array
        if (isset($data['asistentes']) && is_array($data['asistentes'])) {
            $data['asistentes'] = maybe_serialize($data['asistentes']);
        }
        
        $data = $this->sanitizar_datos_reunion($data);
        
        $resultado = $wpdb->update(
            $this->table_reuniones,
            $data,
            ['id' => $id]
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    public function delete_reunion($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('reuniones')) {
            return new \WP_Error('table_missing', 'La tabla de reuniones no existe');
        }
        
        $resultado = $wpdb->delete(
            $this->table_reuniones,
            ['id' => $id],
            ['%d']
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    private function sanitizar_datos_reunion($data) {
        $sanitized = [];
        
        if (isset($data['titulo'])) {
            $sanitized['titulo'] = sanitize_text_field($data['titulo']);
        }
        if (isset($data['tipo'])) {
            $sanitized['tipo'] = sanitize_text_field($data['tipo']);
        }
        if (isset($data['fecha'])) {
            $sanitized['fecha'] = sanitize_text_field($data['fecha']);
        }
        if (isset($data['hora_inicio'])) {
            $sanitized['hora_inicio'] = sanitize_text_field($data['hora_inicio']);
        }
        if (isset($data['hora_fin'])) {
            $sanitized['hora_fin'] = sanitize_text_field($data['hora_fin']);
        }
        if (isset($data['lugar'])) {
            $sanitized['lugar'] = sanitize_text_field($data['lugar']);
        }
        if (isset($data['convocante'])) {
            $sanitized['convocante'] = sanitize_text_field($data['convocante']);
        }
        if (isset($data['asistentes'])) {
            $sanitized['asistentes'] = $data['asistentes'];
        }
        if (isset($data['agenda'])) {
            $sanitized['agenda'] = wp_kses_post($data['agenda']);
        }
        if (isset($data['acuerdos'])) {
            $sanitized['acuerdos'] = wp_kses_post($data['acuerdos']);
        }
        if (isset($data['minutos'])) {
            $sanitized['minutos'] = wp_kses_post($data['minutos']);
        }
        if (isset($data['estado'])) {
            $sanitized['estado'] = sanitize_text_field($data['estado']);
        }
        if (isset($data['created_at'])) {
            $sanitized['created_at'] = sanitize_text_field($data['created_at']);
        }
        if (isset($data['updated_at'])) {
            $sanitized['updated_at'] = sanitize_text_field($data['updated_at']);
        }
        
        return $sanitized;
    }

    // =================================================================
    // MÉTODOS PARA CHAT DE OPERADORES
    // =================================================================

    public function get_chat_operadores($args = []) {
        global $wpdb;
        
        if (!$this->tabla_existe('chat_operadores')) {
            return [];
        }
        
        $defaults = [
            'number' => 50,
            'offset' => 0,
            'orderby' => 'fecha_envio',
            'order' => 'DESC',
            'operador_id' => '',
            'destinatario_id' => '',
            'leido' => ''
        ];
        
        $args = wp_parse_args($args, $defaults);
        
        $where = "1=1";
        $prepare_values = [];
        
        if (!empty($args['operador_id'])) {
            $where .= " AND operador_id = %d";
            $prepare_values[] = $args['operador_id'];
        }
        
        if (!empty($args['destinatario_id'])) {
            $where .= " AND destinatario_id = %d";
            $prepare_values[] = $args['destinatario_id'];
        }
        
        if ($args['leido'] !== '') {
            $where .= " AND leido = %d";
            $prepare_values[] = $args['leido'] ? 1 : 0;
        }
        
        $query = "SELECT * FROM {$this->table_chat_operadores} WHERE $where ORDER BY {$args['orderby']} {$args['order']} LIMIT %d OFFSET %d";
        $prepare_values[] = $args['number'];
        $prepare_values[] = $args['offset'];
        
        if (!empty($prepare_values)) {
            $query = $wpdb->prepare($query, $prepare_values);
        }
        
        return $wpdb->get_results($query, ARRAY_A);
    }
    
    public function get_chat_operador_by_id($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('chat_operadores')) {
            return null;
        }
        
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_chat_operadores} WHERE id = %d", $id),
            ARRAY_A
        );
    }
    
    public function insert_chat_operador($data) {
        global $wpdb;
        
        if (!$this->tabla_existe('chat_operadores')) {
            return new \WP_Error('table_missing', 'La tabla de chat de operadores no existe');
        }
        
        $defaults = [
            'fecha_envio' => current_time('mysql'),
            'created_at' => current_time('mysql')
        ];
        
        $data = wp_parse_args($data, $defaults);
        $data = $this->sanitizar_datos_chat_operador($data);
        
        $resultado = $wpdb->insert($this->table_chat_operadores, $data);
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $wpdb->insert_id;
    }
    
    public function update_chat_operador($id, $data) {
        global $wpdb;
        
        if (!$this->tabla_existe('chat_operadores')) {
            return new \WP_Error('table_missing', 'La tabla de chat de operadores no existe');
        }
        
        $data = $this->sanitizar_datos_chat_operador($data);
        
        $resultado = $wpdb->update(
            $this->table_chat_operadores,
            $data,
            ['id' => $id]
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    public function delete_chat_operador($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('chat_operadores')) {
            return new \WP_Error('table_missing', 'La tabla de chat de operadores no existe');
        }
        
        $resultado = $wpdb->delete(
            $this->table_chat_operadores,
            ['id' => $id],
            ['%d']
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    public function marcar_como_leido($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('chat_operadores')) {
            return new \WP_Error('table_missing', 'La tabla de chat de operadores no existe');
        }
        
        $resultado = $wpdb->update(
            $this->table_chat_operadores,
            ['leido' => 1],
            ['id' => $id],
            ['%d'],
            ['%d']
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    private function sanitizar_datos_chat_operador($data) {
        $sanitized = [];
        
        if (isset($data['operador_id'])) {
            $sanitized['operador_id'] = intval($data['operador_id']);
        }
        if (isset($data['mensaje'])) {
            $sanitized['mensaje'] = sanitize_textarea_field($data['mensaje']);
        }
        if (isset($data['tipo_mensaje'])) {
            $sanitized['tipo_mensaje'] = sanitize_text_field($data['tipo_mensaje']);
        }
        if (isset($data['destinatario_id'])) {
            $sanitized['destinatario_id'] = intval($data['destinatario_id']);
        }
        if (isset($data['leido'])) {
            $sanitized['leido'] = $data['leido'] ? 1 : 0;
        }
        if (isset($data['urgente'])) {
            $sanitized['urgente'] = $data['urgente'] ? 1 : 0;
        }
        if (isset($data['fecha_envio'])) {
            $sanitized['fecha_envio'] = sanitize_text_field($data['fecha_envio']);
        }
        if (isset($data['created_at'])) {
            $sanitized['created_at'] = sanitize_text_field($data['created_at']);
        }
        
        return $sanitized;
    }

    // =================================================================
    // MÉTODOS PARA TIEMPO LIMPIO
    // =================================================================

    public function get_tiempo_limpio($args = []) {
        global $wpdb;
        
        if (!$this->tabla_existe('tiempo_limpio')) {
            return [];
        }
        
        $defaults = [
            'number' => 20,
            'offset' => 0,
            'orderby' => 'fecha_registro',
            'order' => 'DESC',
            'paciente_id' => '',
            'estado_actual' => ''
        ];
        
        $args = wp_parse_args($args, $defaults);
        
        $where = "1=1";
        $prepare_values = [];
        
        if (!empty($args['paciente_id'])) {
            $where .= " AND paciente_id = %d";
            $prepare_values[] = $args['paciente_id'];
        }
        
        if (!empty($args['estado_actual'])) {
            $where .= " AND estado_actual = %s";
            $prepare_values[] = $args['estado_actual'];
        }
        
        $query = "SELECT tl.*, p.nombre as paciente_nombre, p.apellido as paciente_apellido, p.cedula as paciente_cedula
                 FROM {$this->table_tiempo_limpio} tl
                 LEFT JOIN {$this->table_pacientes} p ON tl.paciente_id = p.id
                 WHERE $where ORDER BY tl.{$args['orderby']} {$args['order']} LIMIT %d OFFSET %d";
        $prepare_values[] = $args['number'];
        $prepare_values[] = $args['offset'];
        
        if (!empty($prepare_values)) {
            $query = $wpdb->prepare($query, $prepare_values);
        }
        
        return $wpdb->get_results($query, ARRAY_A);
    }
    
    public function get_tiempo_limpio_by_id($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('tiempo_limpio')) {
            return null;
        }
        
        return $wpdb->get_row(
            $wpdb->prepare("
                SELECT tl.*, p.nombre as paciente_nombre, p.apellido as paciente_apellido, p.cedula as paciente_cedula
                FROM {$this->table_tiempo_limpio} tl
                LEFT JOIN {$this->table_pacientes} p ON tl.paciente_id = p.id
                WHERE tl.id = %d
            ", $id),
            ARRAY_A
        );
    }
    
    public function get_tiempo_limpio_por_paciente($paciente_id) {
        global $wpdb;
        
        if (!$this->tabla_existe('tiempo_limpio')) {
            return [];
        }
        
        return $wpdb->get_results(
            $wpdb->prepare("
                SELECT tl.*, p.nombre as paciente_nombre, p.apellido as paciente_apellido, p.cedula as paciente_cedula
                FROM {$this->table_tiempo_limpio} tl
                LEFT JOIN {$this->table_pacientes} p ON tl.paciente_id = p.id
                WHERE tl.paciente_id = %d
                ORDER BY tl.fecha_registro DESC
            ", $paciente_id),
            ARRAY_A
        );
    }
    
    public function insert_tiempo_limpio($data) {
        global $wpdb;
        
        if (!$this->tabla_existe('tiempo_limpio')) {
            return new \WP_Error('table_missing', 'La tabla de tiempo limpio no existe');
        }
        
        $defaults = [
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ];
        
        $data = wp_parse_args($data, $defaults);
        $data = $this->sanitizar_datos_tiempo_limpio($data);
        
        $resultado = $wpdb->insert($this->table_tiempo_limpio, $data);
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $wpdb->insert_id;
    }
    
    public function update_tiempo_limpio($id, $data) {
        global $wpdb;
        
        if (!$this->tabla_existe('tiempo_limpio')) {
            return new \WP_Error('table_missing', 'La tabla de tiempo limpio no existe');
        }
        
        $data['updated_at'] = current_time('mysql');
        $data = $this->sanitizar_datos_tiempo_limpio($data);
        
        $resultado = $wpdb->update(
            $this->table_tiempo_limpio,
            $data,
            ['id' => $id]
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    public function delete_tiempo_limpio($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('tiempo_limpio')) {
            return new \WP_Error('table_missing', 'La tabla de tiempo limpio no existe');
        }
        
        $resultado = $wpdb->delete(
            $this->table_tiempo_limpio,
            ['id' => $id],
            ['%d']
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    public function calcular_dias_abstinencia($paciente_id) {
        global $wpdb;
        
        if (!$this->tabla_existe('tiempo_limpio')) {
            return 0;
        }
        
        $resultado = $wpdb->get_row(
            $wpdb->prepare("
                SELECT fecha_inicio_abstinencia 
                FROM {$this->table_tiempo_limpio} 
                WHERE paciente_id = %d 
                ORDER BY fecha_registro DESC 
                LIMIT 1
            ", $paciente_id)
        );
        
        if (!$resultado || empty($resultado->fecha_inicio_abstinencia)) {
            return 0;
        }
        
        $fecha_inicio = new \DateTime($resultado->fecha_inicio_abstinencia);
        $hoy = new \DateTime();
        $diferencia = $hoy->diff($fecha_inicio);
        
        return $diferencia->days;
    }
    
    private function sanitizar_datos_tiempo_limpio($data) {
        $sanitized = [];
        
        if (isset($data['paciente_id'])) {
            $sanitized['paciente_id'] = intval($data['paciente_id']);
        }
        if (isset($data['fecha_inicio_abstinencia'])) {
            $sanitized['fecha_inicio_abstinencia'] = sanitize_text_field($data['fecha_inicio_abstinencia']);
        }
        if (isset($data['fecha_registro'])) {
            $sanitized['fecha_registro'] = sanitize_text_field($data['fecha_registro']);
        }
        if (isset($data['tipo_sustancia'])) {
            $sanitized['tipo_sustancia'] = sanitize_text_field($data['tipo_sustancia']);
        }
        if (isset($data['estado_actual'])) {
            $sanitized['estado_actual'] = sanitize_text_field($data['estado_actual']);
        }
        if (isset($data['avances'])) {
            $sanitized['avances'] = sanitize_textarea_field($data['avances']);
        }
        if (isset($data['dificultades'])) {
            $sanitized['dificultades'] = sanitize_textarea_field($data['dificultades']);
        }
        if (isset($data['metas_cumplidas'])) {
            $sanitized['metas_cumplidas'] = sanitize_textarea_field($data['metas_cumplidas']);
        }
        if (isset($data['observaciones'])) {
            $sanitized['observaciones'] = sanitize_textarea_field($data['observaciones']);
        }
        if (isset($data['terapeuta_id'])) {
            $sanitized['terapeuta_id'] = intval($data['terapeuta_id']);
        }
        if (isset($data['created_at'])) {
            $sanitized['created_at'] = sanitize_text_field($data['created_at']);
        }
        if (isset($data['updated_at'])) {
            $sanitized['updated_at'] = sanitize_text_field($data['updated_at']);
        }
        
        return $sanitized;
    }

    // =================================================================
    // MÉTODOS PARA PACIENTES
    // =================================================================
    
    public function get_pacientes($estado = 'activo', $limit = null, $offset = 0) {
        global $wpdb;
        
        if (!$this->tabla_existe('pacientes')) {
            return [];
        }
        
        $query = "SELECT * FROM {$this->table_pacientes} WHERE estado = %s ORDER BY fecha_ingreso DESC, nombre ASC";
        $params = [$estado];
        
        if ($limit) {
            $query .= " LIMIT %d OFFSET %d";
            $params[] = $limit;
            $params[] = $offset;
        }
        
        return $wpdb->get_results($wpdb->prepare($query, $params), ARRAY_A);
    }
    
    public function get_paciente_by_id($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('pacientes')) {
            return null;
        }
        
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_pacientes} WHERE id = %d", $id),
            ARRAY_A
        );
    }
    
    public function buscar_pacientes($termino) {
        global $wpdb;
        
        if (!$this->tabla_existe('pacientes')) {
            return [];
        }
        
        $like_term = '%' . $wpdb->esc_like($termino) . '%';
        
        return $wpdb->get_results(
            $wpdb->prepare("
                SELECT * FROM {$this->table_pacientes} 
                WHERE cedula LIKE %s OR nombre LIKE %s OR apellido LIKE %s OR email LIKE %s 
                ORDER BY fecha_ingreso DESC
            ", $like_term, $like_term, $like_term, $like_term),
            ARRAY_A
        );
    }
    
    public function insert_paciente($data) {
        global $wpdb;
        
        if (!$this->tabla_existe('pacientes')) {
            return new \WP_Error('table_missing', 'La tabla de pacientes no existe');
        }
        
        $data = $this->sanitizar_datos_paciente($data);
        
        $resultado = $wpdb->insert($this->table_pacientes, $data);
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $wpdb->insert_id;
    }
    
    public function update_paciente($id, $data) {
        global $wpdb;
        
        if (!$this->tabla_existe('pacientes')) {
            return new \WP_Error('table_missing', 'La tabla de pacientes no existe');
        }
        
        $data = $this->sanitizar_datos_paciente($data);
        
        $resultado = $wpdb->update(
            $this->table_pacientes,
            $data,
            ['id' => $id]
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    public function delete_paciente($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('pacientes')) {
            return new \WP_Error('table_missing', 'La tabla de pacientes no existe');
        }
        
        $resultado = $wpdb->delete(
            $this->table_pacientes,
            ['id' => $id],
            ['%d']
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    private function sanitizar_datos_paciente($data) {
        $sanitized = [];
        
        if (isset($data['cedula'])) {
            $sanitized['cedula'] = sanitize_text_field($data['cedula']);
        }
        if (isset($data['nombre'])) {
            $sanitized['nombre'] = sanitize_text_field($data['nombre']);
        }
        if (isset($data['apellido'])) {
            $sanitized['apellido'] = sanitize_text_field($data['apellido']);
        }
        if (isset($data['fecha_nacimiento'])) {
            $sanitized['fecha_nacimiento'] = sanitize_text_field($data['fecha_nacimiento']);
        }
        if (isset($data['genero'])) {
            $sanitized['genero'] = sanitize_text_field($data['genero']);
        }
        if (isset($data['telefono'])) {
            $sanitized['telefono'] = sanitize_text_field($data['telefono']);
        }
        if (isset($data['email'])) {
            $sanitized['email'] = sanitize_email($data['email']);
        }
        if (isset($data['direccion'])) {
            $sanitized['direccion'] = sanitize_textarea_field($data['direccion']);
        }
        if (isset($data['contacto_emergencia_nombre'])) {
            $sanitized['contacto_emergencia_nombre'] = sanitize_text_field($data['contacto_emergencia_nombre']);
        }
        if (isset($data['contacto_emergencia_telefono'])) {
            $sanitized['contacto_emergencia_telefono'] = sanitize_text_field($data['contacto_emergencia_telefono']);
        }
        if (isset($data['contacto_emergencia_parentesco'])) {
            $sanitized['contacto_emergencia_parentesco'] = sanitize_text_field($data['contacto_emergencia_parentesco']);
        }
        if (isset($data['historial_medico'])) {
            $sanitized['historial_medico'] = sanitize_textarea_field($data['historial_medico']);
        }
        if (isset($data['alergias'])) {
            $sanitized['alergias'] = sanitize_textarea_field($data['alergias']);
        }
        if (isset($data['medicamentos_actuales'])) {
            $sanitized['medicamentos_actuales'] = sanitize_textarea_field($data['medicamentos_actuales']);
        }
        if (isset($data['seguro_medico'])) {
            $sanitized['seguro_medico'] = sanitize_text_field($data['seguro_medico']);
        }
        if (isset($data['numero_seguro_medico'])) {
            $sanitized['numero_seguro_medico'] = sanitize_text_field($data['numero_seguro_medico']);
        }
        if (isset($data['estado_civil'])) {
            $sanitized['estado_civil'] = sanitize_text_field($data['estado_civil']);
        }
        if (isset($data['ocupacion'])) {
            $sanitized['ocupacion'] = sanitize_text_field($data['ocupacion']);
        }
        if (isset($data['nivel_educativo'])) {
            $sanitized['nivel_educativo'] = sanitize_text_field($data['nivel_educativo']);
        }
        if (isset($data['referencia_por'])) {
            $sanitized['referencia_por'] = sanitize_text_field($data['referencia_por']);
        }
        if (isset($data['motivo_consulta_principal'])) {
            $sanitized['motivo_consulta_principal'] = sanitize_textarea_field($data['motivo_consulta_principal']);
        }
        if (isset($data['expectativas_tratamiento'])) {
            $sanitized['expectativas_tratamiento'] = sanitize_textarea_field($data['expectativas_tratamiento']);
        }
        if (isset($data['fecha_ingreso'])) {
            $sanitized['fecha_ingreso'] = sanitize_text_field($data['fecha_ingreso']);
        }
        if (isset($data['estado'])) {
            $sanitized['estado'] = sanitize_text_field($data['estado']);
        }
        if (isset($data['observaciones_generales'])) {
            $sanitized['observaciones_generales'] = sanitize_textarea_field($data['observaciones_generales']);
        }
        
        return $sanitized;
    }
    
    // =================================================================
    // MÉTODOS PARA HISTORIAL MÉDICO
    // =================================================================
    
    public function get_historial_medico($limit = 50, $offset = 0) {
        global $wpdb;
        
        if (!$this->tabla_existe('historial_medico')) {
            return [];
        }
        
        return $wpdb->get_results(
            $wpdb->prepare("
                SELECT hm.*, p.nombre, p.apellido, p.cedula 
                FROM {$this->table_historial_medico} hm
                LEFT JOIN {$this->table_pacientes} p ON hm.paciente_id = p.id
                ORDER BY hm.fecha_consulta DESC 
                LIMIT %d OFFSET %d
            ", $limit, $offset),
            ARRAY_A
        );
    }
    
    public function get_historial_medico_por_paciente($paciente_id, $limit = 50, $offset = 0) {
        global $wpdb;
        
        if (!$this->tabla_existe('historial_medico')) {
            return [];
        }
        
        return $wpdb->get_results(
            $wpdb->prepare("
                SELECT hm.*, p.nombre, p.apellido, p.cedula 
                FROM {$this->table_historial_medico} hm
                LEFT JOIN {$this->table_pacientes} p ON hm.paciente_id = p.id
                WHERE hm.paciente_id = %d
                ORDER BY hm.fecha_consulta DESC 
                LIMIT %d OFFSET %d
            ", $paciente_id, $limit, $offset),
            ARRAY_A
        );
    }
    
    public function get_historial_medico_by_id($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('historial_medico')) {
            return null;
        }
        
        return $wpdb->get_row(
            $wpdb->prepare("
                SELECT hm.*, p.nombre, p.apellido, p.cedula 
                FROM {$this->table_historial_medico} hm
                LEFT JOIN {$this->table_pacientes} p ON hm.paciente_id = p.id
                WHERE hm.id = %d
            ", $id),
            ARRAY_A
        );
    }
    
    public function insert_historial_medico($data) {
        global $wpdb;
        
        if (!$this->tabla_existe('historial_medico')) {
            return new \WP_Error('table_missing', 'La tabla de historial médico no existe');
        }
        
        $data = $this->sanitizar_datos_historial_medico($data);
        
        $resultado = $wpdb->insert($this->table_historial_medico, $data);
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $wpdb->insert_id;
    }
    
    public function update_historial_medico($id, $data) {
        global $wpdb;
        
        if (!$this->tabla_existe('historial_medico')) {
            return new \WP_Error('table_missing', 'La tabla de historial médico no existe');
        }
        
        $data = $this->sanitizar_datos_historial_medico($data);
        
        $resultado = $wpdb->update(
            $this->table_historial_medico,
            $data,
            ['id' => $id]
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    public function delete_historial_medico($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('historial_medico')) {
            return new \WP_Error('table_missing', 'La tabla de historial médico no existe');
        }
        
        $resultado = $wpdb->delete(
            $this->table_historial_medico,
            ['id' => $id],
            ['%d']
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    private function sanitizar_datos_historial_medico($data) {
        $sanitized = [];
        
        if (isset($data['paciente_id'])) {
            $sanitized['paciente_id'] = intval($data['paciente_id']);
        }
        if (isset($data['fecha_consulta'])) {
            $sanitized['fecha_consulta'] = sanitize_text_field($data['fecha_consulta']);
        }
        if (isset($data['tipo_consulta'])) {
            $sanitized['tipo_consulta'] = sanitize_text_field($data['tipo_consulta']);
        }
        if (isset($data['medico_tratante'])) {
            $sanitized['medico_tratante'] = sanitize_text_field($data['medico_tratante']);
        }
        if (isset($data['diagnostico'])) {
            $sanitized['diagnostico'] = sanitize_textarea_field($data['diagnostico']);
        }
        if (isset($data['tratamiento_prescrito'])) {
            $sanitized['tratamiento_prescrito'] = sanitize_textarea_field($data['tratamiento_prescrito']);
        }
        if (isset($data['medicamentos_recetados'])) {
            $sanitized['medicamentos_recetados'] = sanitize_textarea_field($data['medicamentos_recetados']);
        }
        if (isset($data['examenes_solicitados'])) {
            $sanitized['examenes_solicitados'] = sanitize_textarea_field($data['examenes_solicitados']);
        }
        if (isset($data['resultados_examenes'])) {
            $sanitized['resultados_examenes'] = sanitize_textarea_field($data['resultados_examenes']);
        }
        if (isset($data['observaciones'])) {
            $sanitized['observaciones'] = sanitize_textarea_field($data['observaciones']);
        }
        if (isset($data['proxima_cita'])) {
            $sanitized['proxima_cita'] = sanitize_text_field($data['proxima_cita']);
        }
        
        return $sanitized;
    }
    
    // =================================================================
    // MÉTODOS PARA SEGUIMIENTO TERAPÉUTICO
    // =================================================================
    
    public function get_seguimiento_terapeutico($limit = 50, $offset = 0) {
        global $wpdb;
        
        if (!$this->tabla_existe('seguimiento_terapeutico')) {
            return [];
        }
        
        return $wpdb->get_results(
            $wpdb->prepare("
                SELECT st.*, p.nombre as paciente_nombre, p.apellido as paciente_apellido, p.cedula as paciente_cedula,
                       t.nombre as terapeuta_nombre, t.apellido as terapeuta_apellido
                FROM {$this->table_seguimiento_terapeutico} st
                LEFT JOIN {$this->table_pacientes} p ON st.paciente_id = p.id
                LEFT JOIN {$this->table_miembros} t ON st.terapeuta_id = t.id
                ORDER BY st.fecha_seguimiento DESC 
                LIMIT %d OFFSET %d
            ", $limit, $offset),
            ARRAY_A
        );
    }
    
    public function get_seguimiento_terapeutico_por_paciente($paciente_id, $limit = 50, $offset = 0) {
        global $wpdb;
        
        if (!$this->tabla_existe('seguimiento_terapeutico')) {
            return [];
        }
        
        return $wpdb->get_results(
            $wpdb->prepare("
                SELECT st.*, p.nombre as paciente_nombre, p.apellido as paciente_apellido, p.cedula as paciente_cedula,
                       t.nombre as terapeuta_nombre, t.apellido as terapeuta_apellido
                FROM {$this->table_seguimiento_terapeutico} st
                LEFT JOIN {$this->table_pacientes} p ON st.paciente_id = p.id
                LEFT JOIN {$this->table_miembros} t ON st.terapeuta_id = t.id
                WHERE st.paciente_id = %d
                ORDER BY st.fecha_seguimiento DESC 
                LIMIT %d OFFSET %d
            ", $paciente_id, $limit, $offset),
            ARRAY_A
        );
    }
    
    public function get_seguimiento_terapeutico_by_id($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('seguimiento_terapeutico')) {
            return null;
        }
        
        return $wpdb->get_row(
            $wpdb->prepare("
                SELECT st.*, p.nombre as paciente_nombre, p.apellido as paciente_apellido, p.cedula as paciente_cedula,
                       t.nombre as terapeuta_nombre, t.apellido as terapeuta_apellido
                FROM {$this->table_seguimiento_terapeutico} st
                LEFT JOIN {$this->table_pacientes} p ON st.paciente_id = p.id
                LEFT JOIN {$this->table_miembros} t ON st.terapeuta_id = t.id
                WHERE st.id = %d
            ", $id),
            ARRAY_A
        );
    }
    
    public function insert_seguimiento_terapeutico($data) {
        global $wpdb;
        
        if (!$this->tabla_existe('seguimiento_terapeutico')) {
            return new \WP_Error('table_missing', 'La tabla de seguimiento terapéutico no existe');
        }
        
        $data = $this->sanitizar_datos_seguimiento_terapeutico($data);
        
        $resultado = $wpdb->insert($this->table_seguimiento_terapeutico, $data);
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $wpdb->insert_id;
    }
    
    public function update_seguimiento_terapeutico($id, $data) {
        global $wpdb;
        
        if (!$this->tabla_existe('seguimiento_terapeutico')) {
            return new \WP_Error('table_missing', 'La tabla de seguimiento terapéutico no existe');
        }
        
        $data = $this->sanitizar_datos_seguimiento_terapeutico($data);
        
        $resultado = $wpdb->update(
            $this->table_seguimiento_terapeutico,
            $data,
            ['id' => $id]
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    public function delete_seguimiento_terapeutico($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('seguimiento_terapeutico')) {
            return new \WP_Error('table_missing', 'La tabla de seguimiento terapéutico no existe');
        }
        
        $resultado = $wpdb->delete(
            $this->table_seguimiento_terapeutico,
            ['id' => $id],
            ['%d']
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    private function sanitizar_datos_seguimiento_terapeutico($data) {
        $sanitized = [];
        
        if (isset($data['paciente_id'])) {
            $sanitized['paciente_id'] = intval($data['paciente_id']);
        }
        if (isset($data['terapeuta_id'])) {
            $sanitized['terapeuta_id'] = intval($data['terapeuta_id']);
        }
        if (isset($data['fecha_seguimiento'])) {
            $sanitized['fecha_seguimiento'] = sanitize_text_field($data['fecha_seguimiento']);
        }
        if (isset($data['tipo_seguimiento'])) {
            $sanitized['tipo_seguimiento'] = sanitize_text_field($data['tipo_seguimiento']);
        }
        if (isset($data['objetivo_tratamiento'])) {
            $sanitized['objetivo_tratamiento'] = sanitize_textarea_field($data['objetivo_tratamiento']);
        }
        if (isset($data['progreso_observado'])) {
            $sanitized['progreso_observado'] = sanitize_textarea_field($data['progreso_observado']);
        }
        if (isset($data['dificultades_identificadas'])) {
            $sanitized['dificultades_identificadas'] = sanitize_textarea_field($data['dificultades_identificadas']);
        }
        if (isset($data['intervenciones_realizadas'])) {
            $sanitized['intervenciones_realizadas'] = sanitize_textarea_field($data['intervenciones_realizadas']);
        }
        if (isset($data['tareas_asignadas'])) {
            $sanitized['tareas_asignadas'] = sanitize_textarea_field($data['tareas_asignadas']);
        }
        if (isset($data['nivel_progreso'])) {
            $sanitized['nivel_progreso'] = sanitize_text_field($data['nivel_progreso']);
        }
        if (isset($data['observaciones_terapeuta'])) {
            $sanitized['observaciones_terapeuta'] = sanitize_textarea_field($data['observaciones_terapeuta']);
        }
        if (isset($data['proxima_sesion'])) {
            $sanitized['proxima_sesion'] = sanitize_text_field($data['proxima_sesion']);
        }
        
        return $sanitized;
    }

    // =================================================================
    // MÉTODOS PARA PSICODRAMAS
    // =================================================================

    public function get_psicodramas($args = []) {
        global $wpdb;
        
        if (!$this->tabla_existe('psicodramas')) {
            return [];
        }
        
        $defaults = [
            'number' => 20,
            'offset' => 0,
            'orderby' => 'fecha_sesion',
            'order' => 'DESC',
            'estado' => ''
        ];
        
        $args = wp_parse_args($args, $defaults);
        
        $where = "1=1";
        $prepare_values = [];
        
        if (!empty($args['estado'])) {
            $where .= " AND estado = %s";
            $prepare_values[] = $args['estado'];
        }
        
        $query = "SELECT * FROM {$this->table_psicodramas} WHERE $where ORDER BY {$args['orderby']} {$args['order']} LIMIT %d OFFSET %d";
        $prepare_values[] = $args['number'];
        $prepare_values[] = $args['offset'];
        
        if (!empty($prepare_values)) {
            $query = $wpdb->prepare($query, $prepare_values);
        }
        
        return $wpdb->get_results($query, ARRAY_A);
    }
    
    public function get_psicodrama_by_id($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('psicodramas')) {
            return null;
        }
        
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_psicodramas} WHERE id = %d", $id),
            ARRAY_A
        );
    }
    
    public function insert_psicodrama($data) {
        global $wpdb;
        
        if (!$this->tabla_existe('psicodramas')) {
            return new \WP_Error('table_missing', 'La tabla de psicodramas no existe');
        }
        
        $defaults = [
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ];
        
        $data = wp_parse_args($data, $defaults);
        
        if (isset($data['participantes']) && is_array($data['participantes'])) {
            $data['participantes'] = maybe_serialize($data['participantes']);
        }
        
        $data = $this->sanitizar_datos_psicodrama($data);
        
        $resultado = $wpdb->insert($this->table_psicodramas, $data);
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $wpdb->insert_id;
    }
    
    public function update_psicodrama($id, $data) {
        global $wpdb;
        
        if (!$this->tabla_existe('psicodramas')) {
            return new \WP_Error('table_missing', 'La tabla de psicodramas no existe');
        }
        
        $data['updated_at'] = current_time('mysql');
        
        if (isset($data['participantes']) && is_array($data['participantes'])) {
            $data['participantes'] = maybe_serialize($data['participantes']);
        }
        
        $data = $this->sanitizar_datos_psicodrama($data);
        
        $resultado = $wpdb->update(
            $this->table_psicodramas,
            $data,
            ['id' => $id]
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    public function delete_psicodrama($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('psicodramas')) {
            return new \WP_Error('table_missing', 'La tabla de psicodramas no existe');
        }
        
        $resultado = $wpdb->delete(
            $this->table_psicodramas,
            ['id' => $id],
            ['%d']
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    private function sanitizar_datos_psicodrama($data) {
        $sanitized = [];
        
        if (isset($data['titulo'])) {
            $sanitized['titulo'] = sanitize_text_field($data['titulo']);
        }
        if (isset($data['descripcion'])) {
            $sanitized['descripcion'] = sanitize_textarea_field($data['descripcion']);
        }
        if (isset($data['fecha_sesion'])) {
            $sanitized['fecha_sesion'] = sanitize_text_field($data['fecha_sesion']);
        }
        if (isset($data['duracion'])) {
            $sanitized['duracion'] = intval($data['duracion']);
        }
        if (isset($data['facilitador_id'])) {
            $sanitized['facilitador_id'] = intval($data['facilitador_id']);
        }
        if (isset($data['cofacilitador_id'])) {
            $sanitized['cofacilitador_id'] = intval($data['cofacilitador_id']);
        }
        if (isset($data['participantes'])) {
            $sanitized['participantes'] = $data['participantes'];
        }
        if (isset($data['tema_central'])) {
            $sanitized['tema_central'] = sanitize_text_field($data['tema_central']);
        }
        if (isset($data['tecnica_utilizada'])) {
            $sanitized['tecnica_utilizada'] = sanitize_text_field($data['tecnica_utilizada']);
        }
        if (isset($data['observaciones'])) {
            $sanitized['observaciones'] = sanitize_textarea_field($data['observaciones']);
        }
        if (isset($data['estado'])) {
            $sanitized['estado'] = sanitize_text_field($data['estado']);
        }
        if (isset($data['proxima_sesion'])) {
            $sanitized['proxima_sesion'] = sanitize_text_field($data['proxima_sesion']);
        }
        if (isset($data['created_at'])) {
            $sanitized['created_at'] = sanitize_text_field($data['created_at']);
        }
        if (isset($data['updated_at'])) {
            $sanitized['updated_at'] = sanitize_text_field($data['updated_at']);
        }
        
        return $sanitized;
    }

    // =================================================================
    // MÉTODOS PARA REGISTROS DIARIOS (SISTEMA INTEGRAL)
    // =================================================================

    /**
     * Obtener registros por rango de fechas
     */
    public function obtener_registros_por_rango($rango = 'semana') {
        global $wpdb;
        
        if (!$this->tabla_existe('registros_diarios')) {
            return [];
        }
        
        $fecha_fin = date('Y-m-d');
        switch ($rango) {
            case 'hoy':
                $fecha_inicio = $fecha_fin;
                break;
            case 'semana':
                $fecha_inicio = date('Y-m-d', strtotime('-6 days'));
                break;
            case 'mes':
                $fecha_inicio = date('Y-m-d', strtotime('-29 days'));
                break;
            default:
                $fecha_inicio = date('Y-m-d', strtotime('-6 days'));
        }
        
        $query = $wpdb->prepare("
            SELECT * FROM {$this->table_registros_diarios} 
            WHERE fecha BETWEEN %s AND %s 
            ORDER BY fecha DESC, id DESC
        ", $fecha_inicio, $fecha_fin);
        
        return $wpdb->get_results($query, ARRAY_A);
    }

    /**
     * Obtener estadísticas de cumplimiento
     */
    public function obtener_estadisticas_cumplimiento($rango = 'semana') {
        global $wpdb;
        
        if (!$this->tabla_existe('registros_diarios')) {
            return $this->estadisticas_por_defecto($rango);
        }
        
        $fecha_fin = date('Y-m-d');
        switch ($rango) {
            case 'hoy':
                $fecha_inicio = $fecha_fin;
                break;
            case 'semana':
                $fecha_inicio = date('Y-m-d', strtotime('-6 days'));
                break;
            case 'mes':
                $fecha_inicio = date('Y-m-d', strtotime('-29 days'));
                break;
            default:
                $fecha_inicio = date('Y-m-d', strtotime('-6 days'));
        }
        
        $query = $wpdb->prepare("
            SELECT 
                COUNT(*) as total_actividades,
                SUM(CASE WHEN estado = 'completada' THEN 1 ELSE 0 END) as completadas,
                SUM(CASE WHEN estado = 'pendiente' THEN 1 ELSE 0 END) as pendientes,
                SUM(CASE WHEN estado = 'cancelada' THEN 1 ELSE 0 END) as canceladas,
                SUM(CASE WHEN estado = 'no_cumplida' THEN 1 ELSE 0 END) as no_cumplidas,
                SUM(CASE WHEN estado = 'en_progreso' THEN 1 ELSE 0 END) as en_progreso,
                AVG(CASE WHEN valoracion > 0 THEN valoracion ELSE NULL END) as valoracion_promedio,
                AVG(CASE WHEN duracion_real > 0 THEN duracion_real ELSE NULL END) as duracion_promedio
            FROM {$this->table_registros_diarios} 
            WHERE fecha BETWEEN %s AND %s
        ", $fecha_inicio, $fecha_fin);
        
        $estadisticas = $wpdb->get_row($query, ARRAY_A);
        
        if (!$estadisticas || $estadisticas['total_actividades'] == 0) {
            return $this->estadisticas_por_defecto($rango, $fecha_inicio, $fecha_fin);
        }
        
        $total = $estadisticas['total_actividades'];
        $completadas = $estadisticas['completadas'];
        $pendientes = $estadisticas['pendientes'];
        $canceladas = $estadisticas['canceladas'];
        $no_cumplidas = $estadisticas['no_cumplidas'];
        $en_progreso = $estadisticas['en_progreso'];
        
        $porcentaje_completadas = $total > 0 ? round(($completadas / $total) * 100) : 0;
        $porcentaje_pendientes = $total > 0 ? round(($pendientes / $total) * 100) : 0;
        $porcentaje_canceladas = $total > 0 ? round(($canceladas / $total) * 100) : 0;
        $porcentaje_no_cumplidas = $total > 0 ? round(($no_cumplidas / $total) * 100) : 0;
        $porcentaje_en_progreso = $total > 0 ? round(($en_progreso / $total) * 100) : 0;
        
        return [
            'total_actividades' => $total,
            'completadas' => $completadas,
            'pendientes' => $pendientes,
            'canceladas' => $canceladas,
            'no_cumplidas' => $no_cumplidas,
            'en_progreso' => $en_progreso,
            'porcentaje_completadas' => $porcentaje_completadas,
            'porcentaje_pendientes' => $porcentaje_pendientes,
            'porcentaje_canceladas' => $porcentaje_canceladas,
            'porcentaje_no_cumplidas' => $porcentaje_no_cumplidas,
            'porcentaje_en_progreso' => $porcentaje_en_progreso,
            'valoracion_promedio' => floatval($estadisticas['valoracion_promedio'] ?? 0),
            'duracion_promedio' => floatval($estadisticas['duracion_promedio'] ?? 0),
            'rango' => $rango,
            'fecha_inicio' => $fecha_inicio,
            'fecha_fin' => $fecha_fin,
            'con_datos' => true
        ];
    }

    /**
     * Estadísticas por defecto cuando no hay datos
     */
    private function estadisticas_por_defecto($rango, $fecha_inicio = null, $fecha_fin = null) {
        if ($fecha_inicio === null) {
            $fecha_fin = date('Y-m-d');
            switch ($rango) {
                case 'hoy':
                    $fecha_inicio = $fecha_fin;
                    break;
                case 'semana':
                    $fecha_inicio = date('Y-m-d', strtotime('-6 days'));
                    break;
                case 'mes':
                    $fecha_inicio = date('Y-m-d', strtotime('-29 days'));
                    break;
                default:
                    $fecha_inicio = date('Y-m-d', strtotime('-6 days'));
            }
        }
        
        return [
            'total_actividades' => 0,
            'completadas' => 0,
            'pendientes' => 0,
            'canceladas' => 0,
            'no_cumplidas' => 0,
            'en_progreso' => 0,
            'porcentaje_completadas' => 0,
            'porcentaje_pendientes' => 0,
            'porcentaje_canceladas' => 0,
            'porcentaje_no_cumplidas' => 0,
            'porcentaje_en_progreso' => 0,
            'valoracion_promedio' => 0,
            'duracion_promedio' => 0,
            'rango' => $rango,
            'fecha_inicio' => $fecha_inicio,
            'fecha_fin' => $fecha_fin,
            'con_datos' => false
        ];
    }

    /**
     * Guardar registro diario
     */
    public function guardar_registro_diario($datos) {
        global $wpdb;
        
        if (!$this->tabla_existe('registros_diarios')) {
            return ['success' => false, 'message' => 'La tabla de registros no existe'];
        }
        
        $fecha = sanitize_text_field($datos['fecha'] ?? '');
        $actividad_id = sanitize_text_field($datos['actividad_id'] ?? '');
        $actividad_nombre = sanitize_text_field($datos['actividad_nombre'] ?? '');
        $estado = sanitize_text_field($datos['estado'] ?? 'completada');
        $observaciones = sanitize_textarea_field($datos['observaciones'] ?? '');
        $duracion_real = intval($datos['duracion_real'] ?? 0);
        $valoracion = intval($datos['valoracion'] ?? 5);
        $tipo_actividad = sanitize_text_field($datos['tipo_actividad'] ?? '');
        
        if (empty($fecha) || empty($actividad_id) || empty($actividad_nombre)) {
            return ['success' => false, 'message' => 'Faltan campos obligatorios'];
        }
        
        // Verificar si ya existe
        $existe = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*) FROM {$this->table_registros_diarios} 
            WHERE fecha = %s AND actividad_id = %s
        ", $fecha, $actividad_id));
        
        if ($existe > 0) {
            // Actualizar
            $resultado = $wpdb->update(
                $this->table_registros_diarios,
                [
                    'estado' => $estado,
                    'duracion_real' => $duracion_real,
                    'valoracion' => $valoracion,
                    'observaciones' => $observaciones,
                    'tipo_actividad' => $tipo_actividad
                ],
                [
                    'fecha' => $fecha,
                    'actividad_id' => $actividad_id
                ],
                ['%s', '%d', '%d', '%s', '%s'],
                ['%s', '%s']
            );
            $registro_id = $wpdb->get_var($wpdb->prepare("
                SELECT id FROM {$this->table_registros_diarios} 
                WHERE fecha = %s AND actividad_id = %s
            ", $fecha, $actividad_id));
        } else {
            // Insertar
            $resultado = $wpdb->insert(
                $this->table_registros_diarios,
                [
                    'fecha' => $fecha,
                    'actividad_id' => $actividad_id,
                    'actividad_nombre' => $actividad_nombre,
                    'estado' => $estado,
                    'duracion_real' => $duracion_real,
                    'valoracion' => $valoracion,
                    'observaciones' => $observaciones,
                    'tipo_actividad' => $tipo_actividad
                ],
                ['%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s']
            );
            $registro_id = $wpdb->insert_id;
        }
        
        if ($resultado === false) {
            return [
                'success' => false,
                'message' => 'Error al guardar en la base de datos: ' . $wpdb->last_error
            ];
        }
        
        return [
            'success' => true,
            'message' => 'Registro guardado correctamente',
            'registro_id' => $registro_id
        ];
    }

    /**
     * Obtener todas las actividades con filtros
     */
    public function obtener_todas_actividades($limit = 100, $offset = 0, $filtros = []) {
        global $wpdb;
        
        if (!$this->tabla_existe('registros_diarios')) {
            return [];
        }
        
        $where_conditions = ["1=1"];
        $params = [];
        
        if (!empty($filtros['fecha_desde'])) {
            $where_conditions[] = "fecha >= %s";
            $params[] = $filtros['fecha_desde'];
        }
        
        if (!empty($filtros['fecha_hasta'])) {
            $where_conditions[] = "fecha <= %s";
            $params[] = $filtros['fecha_hasta'];
        }
        
        if (!empty($filtros['estado'])) {
            $where_conditions[] = "estado = %s";
            $params[] = $filtros['estado'];
        }
        
        if (!empty($filtros['tipo_actividad'])) {
            $where_conditions[] = "tipo_actividad = %s";
            $params[] = $filtros['tipo_actividad'];
        }
        
        if (!empty($filtros['actividad_nombre'])) {
            $where_conditions[] = "actividad_nombre LIKE %s";
            $params[] = '%' . $wpdb->esc_like($filtros['actividad_nombre']) . '%';
        }
        
        $where_clause = implode(" AND ", $where_conditions);
        
        $params[] = $limit;
        $params[] = $offset;
        
        $query = $wpdb->prepare("
            SELECT * FROM {$this->table_registros_diarios} 
            WHERE $where_clause 
            ORDER BY fecha DESC, id DESC 
            LIMIT %d OFFSET %d
        ", $params);
        
        $actividades = $wpdb->get_results($query, ARRAY_A);
        
        return $actividades ?: [];
    }

    /**
     * Contar actividades con filtros
     */
    public function contar_actividades($filtros = []) {
        global $wpdb;
        
        if (!$this->tabla_existe('registros_diarios')) {
            return 0;
        }
        
        $where_conditions = ["1=1"];
        $params = [];
        
        if (!empty($filtros['fecha_desde'])) {
            $where_conditions[] = "fecha >= %s";
            $params[] = $filtros['fecha_desde'];
        }
        
        if (!empty($filtros['fecha_hasta'])) {
            $where_conditions[] = "fecha <= %s";
            $params[] = $filtros['fecha_hasta'];
        }
        
        if (!empty($filtros['estado'])) {
            $where_conditions[] = "estado = %s";
            $params[] = $filtros['estado'];
        }
        
        if (!empty($filtros['tipo_actividad'])) {
            $where_conditions[] = "tipo_actividad = %s";
            $params[] = $filtros['tipo_actividad'];
        }
        
        if (!empty($filtros['actividad_nombre'])) {
            $where_conditions[] = "actividad_nombre LIKE %s";
            $params[] = '%' . $wpdb->esc_like($filtros['actividad_nombre']) . '%';
        }
        
        $where_clause = implode(" AND ", $where_conditions);
        
        if (!empty($params)) {
            $query = $wpdb->prepare("
                SELECT COUNT(*) FROM {$this->table_registros_diarios} 
                WHERE $where_clause
            ", $params);
        } else {
            $query = "SELECT COUNT(*) FROM {$this->table_registros_diarios} WHERE $where_clause";
        }
        
        return $wpdb->get_var($query);
    }

    /**
     * Obtener actividad por ID
     */
    public function obtener_actividad_por_id($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('registros_diarios')) {
            return null;
        }
        
        $query = $wpdb->prepare("
            SELECT * FROM {$this->table_registros_diarios} 
            WHERE id = %d
        ", $id);
        
        $actividad = $wpdb->get_row($query, ARRAY_A);
        
        return $actividad;
    }

    /**
     * Actualizar actividad
     */
    public function actualizar_actividad($id, $datos) {
        global $wpdb;
        
        if (!$this->tabla_existe('registros_diarios')) {
            return ['success' => false, 'message' => 'La tabla de registros no existe'];
        }
        
        $estado = sanitize_text_field($datos['estado'] ?? '');
        $duracion_real = intval($datos['duracion_real'] ?? 0);
        $valoracion = intval($datos['valoracion'] ?? 0);
        $observaciones = sanitize_textarea_field($datos['observaciones'] ?? '');
        $tipo_actividad = sanitize_text_field($datos['tipo_actividad'] ?? '');
        
        $resultado = $wpdb->update(
            $this->table_registros_diarios,
            [
                'estado' => $estado,
                'duracion_real' => $duracion_real,
                'valoracion' => $valoracion,
                'observaciones' => $observaciones,
                'tipo_actividad' => $tipo_actividad
            ],
            ['id' => $id],
            ['%s', '%d', '%d', '%s', '%s'],
            ['%d']
        );
        
        if ($resultado === false) {
            return [
                'success' => false,
                'message' => 'Error al actualizar la actividad: ' . $wpdb->last_error
            ];
        }
        
        return [
            'success' => true,
            'message' => 'Actividad actualizada correctamente'
        ];
    }

    /**
     * Eliminar actividad
     */
    public function eliminar_actividad($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('registros_diarios')) {
            return ['success' => false, 'message' => 'La tabla de registros no existe'];
        }
        
        $resultado = $wpdb->delete(
            $this->table_registros_diarios,
            ['id' => $id],
            ['%d']
        );
        
        if ($resultado === false) {
            return [
                'success' => false,
                'message' => 'Error al eliminar la actividad: ' . $wpdb->last_error
            ];
        }
        
        return [
            'success' => true,
            'message' => 'Actividad eliminada correctamente'
        ];
    }

    /**
     * Verificar actividades faltantes del día
     */
    public function verificar_actividades_faltantes() {
        global $wpdb;
        
        if (!$this->tabla_existe('registros_diarios')) {
            return [];
        }
        
        $fecha_actual = date('Y-m-d');
        $hora_actual = date('H:i');
        
        $actividades_registradas = $wpdb->get_col($wpdb->prepare("
            SELECT actividad_id FROM {$this->table_registros_diarios} 
            WHERE fecha = %s
        ", $fecha_actual));
        
        // Actividades del horario fijo
        $actividades_horario = [
            '08:00' => ['actividad' => 'Buen día / Despertar', 'icono' => '☀️', 'duracion' => 30, 'tipo' => 'rutina'],
            '08:30' => ['actividad' => 'Desayuno', 'icono' => '🍽️', 'duracion' => 30, 'tipo' => 'alimentacion'],
            '09:00' => ['actividad' => 'Lectura: "Solo por Hoy" + Libro Azul + Reflexión', 'icono' => '📖', 'duracion' => 30, 'tipo' => 'desarrollo_personal'],
            '09:30' => ['actividad' => 'Objetivos del día', 'icono' => '🎯', 'duracion' => 30, 'tipo' => 'planificacion'],
            '10:00' => ['actividad' => 'Reorden (organización y limpieza)', 'icono' => '🧹', 'duracion' => 90, 'tipo' => 'organizacion'],
            '11:30' => ['actividad' => 'Grupo de Sentimiento Libre', 'icono' => '👥', 'duracion' => 60, 'tipo' => 'terapia_grupal'],
            '12:30' => ['actividad' => 'Almuerzo', 'icono' => '🥗', 'duracion' => 30, 'tipo' => 'alimentacion'],
            '13:00' => ['actividad' => 'Hora Libre', 'icono' => '🆓', 'duracion' => 130, 'tipo' => 'descanso'],
            '15:10' => ['actividad' => 'Grupo de R.E.S. escrita del día anterior', 'icono' => '✍️', 'duracion' => 170, 'tipo' => 'terapia_escrita'],
            '18:10' => ['actividad' => 'Merienda', 'icono' => '☕', 'duracion' => 50, 'tipo' => 'alimentacion'],
            '19:00' => ['actividad' => 'Grupo de Escritura de R.E.S. para leer al día siguiente', 'icono' => '📝', 'duracion' => 120, 'tipo' => 'terapia_escrita'],
            '21:00' => ['actividad' => 'Cena', 'icono' => '🍲', 'duracion' => 60, 'tipo' => 'alimentacion'],
            '22:00' => ['actividad' => 'Medicación', 'icono' => '💊', 'duracion' => 60, 'tipo' => 'salud'],
            '23:00' => ['actividad' => 'Todos a la cama', 'icono' => '🛌', 'duracion' => 480, 'tipo' => 'descanso']
        ];
        
        $actividades_faltantes = [];
        
        foreach ($actividades_horario as $hora => $detalles) {
            $actividad_id = $hora . '_' . sanitize_title($detalles['actividad']);
            
            if (strtotime($hora) <= strtotime($hora_actual)) {
                if (!in_array($actividad_id, $actividades_registradas)) {
                    $actividades_faltantes[] = [
                        'hora' => $hora,
                        'actividad' => $detalles['actividad'],
                        'icono' => $detalles['icono'],
                        'tipo' => $detalles['tipo'],
                        'duracion' => $detalles['duracion']
                    ];
                }
            }
        }
        
        return $actividades_faltantes;
    }

    // =================================================================
    // MÉTODOS PARA MEDICACIÓN (SISTEMA INTEGRAL)
    // =================================================================

    /**
     * Guardar medicación
     */
    public function guardar_medicacion($datos) {
        global $wpdb;
        
        if (!$this->tabla_existe('medicacion')) {
            return ['success' => false, 'message' => 'La tabla de medicación no existe'];
        }
        
        $id = intval($datos['id'] ?? 0);
        $paciente_id = intval($datos['paciente_id'] ?? 0);
        $medicamento = sanitize_text_field($datos['medicamento'] ?? '');
        $dosis = sanitize_text_field($datos['dosis'] ?? '');
        $frecuencia = sanitize_text_field($datos['frecuencia'] ?? '');
        $via_administracion = sanitize_text_field($datos['via_administracion'] ?? '');
        $fecha_inicio = sanitize_text_field($datos['fecha_inicio'] ?? '');
        $fecha_fin = sanitize_text_field($datos['fecha_fin'] ?? '');
        $horario_administracion = sanitize_textarea_field($datos['horario_administracion'] ?? '');
        $prescrito_por = sanitize_text_field($datos['prescrito_por'] ?? '');
        $indicaciones_especiales = sanitize_textarea_field($datos['indicaciones_especiales'] ?? '');
        $observaciones = sanitize_textarea_field($datos['observaciones'] ?? '');
        $estado = sanitize_text_field($datos['estado'] ?? 'activo');
        
        if (empty($paciente_id) || empty($medicamento) || empty($dosis) || empty($frecuencia) || empty($fecha_inicio)) {
            return ['success' => false, 'message' => 'Los campos obligatorios están vacíos'];
        }
        
        $datos = [
            'paciente_id' => $paciente_id,
            'medicamento' => $medicamento,
            'dosis' => $dosis,
            'frecuencia' => $frecuencia,
            'via_administracion' => $via_administracion,
            'fecha_inicio' => $fecha_inicio,
            'fecha_fin' => $fecha_fin,
            'horario_administracion' => $horario_administracion,
            'prescrito_por' => $prescrito_por,
            'indicaciones_especiales' => $indicaciones_especiales,
            'observaciones' => $observaciones,
            'estado' => $estado
        ];
        
        if ($id > 0) {
            $resultado = $wpdb->update(
                $this->table_medicacion,
                $datos,
                ['id' => $id],
                ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'],
                ['%d']
            );
        } else {
            $resultado = $wpdb->insert(
                $this->table_medicacion,
                $datos,
                ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
            );
            $id = $wpdb->insert_id;
        }
        
        if ($resultado === false) {
            return [
                'success' => false,
                'message' => 'Error al guardar en la base de datos: ' . $wpdb->last_error
            ];
        }
        
        return [
            'success' => true,
            'message' => $id > 0 ? 'Medicación actualizada correctamente' : 'Medicación registrada correctamente',
            'id' => $id
        ];
    }

    /**
     * Obtener medicación por paciente
     */
    public function obtener_medicacion_por_paciente($paciente_id) {
        global $wpdb;
        
        if (!$this->tabla_existe('medicacion')) {
            return [];
        }
        
        $query = $wpdb->prepare("
            SELECT * FROM {$this->table_medicacion} 
            WHERE paciente_id = %d AND estado = 'activo'
            ORDER BY fecha_inicio DESC
        ", $paciente_id);
        
        return $wpdb->get_results($query, ARRAY_A);
    }

    /**
     * Obtener medicación por ID
     */
    public function obtener_medicacion_por_id($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('medicacion')) {
            return null;
        }
        
        $query = $wpdb->prepare("
            SELECT * FROM {$this->table_medicacion} 
            WHERE id = %d
        ", $id);
        
        return $wpdb->get_row($query, ARRAY_A);
    }

    /**
     * Eliminar medicación (marcar como inactiva)
     */
    public function eliminar_medicacion($id) {
        global $wpdb;
        
        if (!$this->tabla_existe('medicacion')) {
            return ['success' => false, 'message' => 'La tabla de medicación no existe'];
        }
        
        $resultado = $wpdb->update(
            $this->table_medicacion,
            ['estado' => 'inactivo'],
            ['id' => $id],
            ['%s'],
            ['%d']
        );
        
        if ($resultado === false) {
            return [
                'success' => false,
                'message' => 'Error al eliminar la medicación: ' . $wpdb->last_error
            ];
        }
        
        return [
            'success' => true,
            'message' => 'Medicación eliminada correctamente'
        ];
    }

    // =================================================================
    // MÉTODOS PARA MIEMBROS
    // =================================================================

    public function insert_miembro($data) {
        global $wpdb;
        
        $data = $this->sanitizar_datos_miembro($data);
        
        $resultado = $wpdb->insert($this->table_miembros, $data);
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $wpdb->insert_id;
    }
    
    public function get_miembros($estado = 'activo', $limit = null, $offset = 0) {
        global $wpdb;
        
        $query = "SELECT * FROM {$this->table_miembros} WHERE estado = %s ORDER BY fecha_ingreso DESC";
        $params = [$estado];
        
        if ($limit) {
            $query .= " LIMIT %d OFFSET %d";
            $params[] = $limit;
            $params[] = $offset;
        }
        
        return $wpdb->get_results($wpdb->prepare($query, $params), ARRAY_A);
    }
    
    public function get_miembro_by_cedula($cedula) {
        global $wpdb;
        
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_miembros} WHERE cedula = %s", $cedula),
            ARRAY_A
        );
    }
    
    public function get_miembro_by_id($id) {
        global $wpdb;
        
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_miembros} WHERE id = %d", $id),
            ARRAY_A
        );
    }
    
    public function update_miembro($cedula, $data) {
        global $wpdb;
        
        $data = $this->sanitizar_datos_miembro($data);
        
        $resultado = $wpdb->update(
            $this->table_miembros,
            $data,
            ['cedula' => $cedula]
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    public function delete_miembro($cedula) {
        global $wpdb;
        
        $resultado = $wpdb->delete(
            $this->table_miembros,
            ['cedula' => $cedula],
            ['%s']
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    public function buscar_miembros($termino) {
        global $wpdb;
        
        $like_term = '%' . $wpdb->esc_like($termino) . '%';
        
        return $wpdb->get_results(
            $wpdb->prepare("
                SELECT * FROM {$this->table_miembros} 
                WHERE cedula LIKE %s OR nombre LIKE %s OR apellido LIKE %s OR email LIKE %s 
                ORDER BY fecha_ingreso DESC
            ", $like_term, $like_term, $like_term, $like_term),
            ARRAY_A
        );
    }
    
    public function get_total_miembros($estado = null) {
        global $wpdb;
        
        if ($estado) {
            return $wpdb->get_var(
                $wpdb->prepare("SELECT COUNT(*) FROM {$this->table_miembros} WHERE estado = %s", $estado)
            );
        }
        
        return $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_miembros}");
    }
    
    private function sanitizar_datos_miembro($data) {
        $sanitized = [];
        
        if (isset($data['cedula'])) {
            $sanitized['cedula'] = sanitize_text_field($data['cedula']);
        }
        if (isset($data['nombre'])) {
            $sanitized['nombre'] = sanitize_text_field($data['nombre']);
        }
        if (isset($data['apellido'])) {
            $sanitized['apellido'] = sanitize_text_field($data['apellido']);
        }
        if (isset($data['email'])) {
            $sanitized['email'] = sanitize_email($data['email']);
        }
        if (isset($data['telefono'])) {
            $sanitized['telefono'] = sanitize_text_field($data['telefono']);
        }
        if (isset($data['direccion'])) {
            $sanitized['direccion'] = sanitize_textarea_field($data['direccion']);
        }
        if (isset($data['fecha_nacimiento'])) {
            $sanitized['fecha_nacimiento'] = sanitize_text_field($data['fecha_nacimiento']);
        }
        if (isset($data['fecha_ingreso'])) {
            $sanitized['fecha_ingreso'] = sanitize_text_field($data['fecha_ingreso']);
        }
        if (isset($data['tipo_membresia'])) {
            $sanitized['tipo_membresia'] = sanitize_text_field($data['tipo_membresia']);
        }
        if (isset($data['cargo'])) {
            $sanitized['cargo'] = sanitize_text_field($data['cargo']);
        }
        if (isset($data['estado'])) {
            $sanitized['estado'] = sanitize_text_field($data['estado']);
        }
        if (isset($data['observaciones'])) {
            $sanitized['observaciones'] = sanitize_textarea_field($data['observaciones']);
        }
        
        return $sanitized;
    }

    // =================================================================
    // MÉTODOS PARA EVENTOS
    // =================================================================

    public function insert_evento($data) {
        global $wpdb;
        
        $data = $this->sanitizar_datos_evento($data);
        
        $resultado = $wpdb->insert($this->table_eventos, $data);
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $wpdb->insert_id;
    }
    
    public function get_eventos_proximos($limit = 10) {
        global $wpdb;
        
        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$this->table_eventos} WHERE fecha >= %s ORDER BY fecha ASC LIMIT %d", current_time('mysql'), $limit),
            ARRAY_A
        );
    }
    
    public function get_eventos_pasados($limit = 10) {
        global $wpdb;
        
        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$this->table_eventos} WHERE fecha < %s ORDER BY fecha DESC LIMIT %d", current_time('mysql'), $limit),
            ARRAY_A
        );
    }
    
    public function get_evento_by_id($id) {
        global $wpdb;
        
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_eventos} WHERE id = %d", $id),
            ARRAY_A
        );
    }
    
    public function update_evento($id, $data) {
        global $wpdb;
        
        $data = $this->sanitizar_datos_evento($data);
        
        $resultado = $wpdb->update(
            $this->table_eventos,
            $data,
            ['id' => $id]
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    public function delete_evento($id) {
        global $wpdb;
        
        $resultado = $wpdb->delete(
            $this->table_eventos,
            ['id' => $id],
            ['%d']
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    public function get_total_eventos() {
        global $wpdb;
        
        return $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_eventos}");
    }
    
    private function sanitizar_datos_evento($data) {
        $sanitized = [];
        
        if (isset($data['titulo'])) {
            $sanitized['titulo'] = sanitize_text_field($data['titulo']);
        }
        if (isset($data['descripcion'])) {
            $sanitized['descripcion'] = sanitize_textarea_field($data['descripcion']);
        }
        if (isset($data['fecha'])) {
            $sanitized['fecha'] = sanitize_text_field($data['fecha']);
        }
        if (isset($data['lugar'])) {
            $sanitized['lugar'] = sanitize_text_field($data['lugar']);
        }
        if (isset($data['tipo'])) {
            $sanitized['tipo'] = sanitize_text_field($data['tipo']);
        }
        if (isset($data['asistentes'])) {
            $sanitized['asistentes'] = sanitize_textarea_field($data['asistentes']);
        }
        if (isset($data['acta'])) {
            $sanitized['acta'] = sanitize_textarea_field($data['acta']);
        }
        if (isset($data['estado'])) {
            $sanitized['estado'] = sanitize_text_field($data['estado']);
        }
        
        return $sanitized;
    }

    // =================================================================
    // MÉTODOS PARA DOCUMENTOS
    // =================================================================

    public function insert_documento($data) {
        global $wpdb;
        
        $data = $this->sanitizar_datos_documento($data);
        
        $resultado = $wpdb->insert($this->table_documentos, $data);
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $wpdb->insert_id;
    }
    
    public function get_documentos_por_tipo($tipo = '', $limit = 20) {
        global $wpdb;
        
        if ($tipo) {
            return $wpdb->get_results(
                $wpdb->prepare("SELECT * FROM {$this->table_documentos} WHERE tipo = %s ORDER BY fecha_documento DESC LIMIT %d", $tipo, $limit),
                ARRAY_A
            );
        }
        
        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$this->table_documentos} ORDER BY fecha_documento DESC LIMIT %d", $limit),
            ARRAY_A
        );
    }
    
    public function get_documento_by_id($id) {
        global $wpdb;
        
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_documentos} WHERE id = %d", $id),
            ARRAY_A
        );
    }
    
    public function update_documento($id, $data) {
        global $wpdb;
        
        $data = $this->sanitizar_datos_documento($data);
        
        $resultado = $wpdb->update(
            $this->table_documentos,
            $data,
            ['id' => $id]
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    public function delete_documento($id) {
        global $wpdb;
        
        $resultado = $wpdb->delete(
            $this->table_documentos,
            ['id' => $id],
            ['%d']
        );
        
        if ($resultado === false) {
            return new \WP_Error('db_error', $wpdb->last_error);
        }
        
        return $resultado;
    }
    
    public function get_total_documentos() {
        global $wpdb;
        
        return $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_documentos}");
    }
    
    private function sanitizar_datos_documento($data) {
        $sanitized = [];
        
        if (isset($data['titulo'])) {
            $sanitized['titulo'] = sanitize_text_field($data['titulo']);
        }
        if (isset($data['descripcion'])) {
            $sanitized['descripcion'] = sanitize_textarea_field($data['descripcion']);
        }
        if (isset($data['tipo'])) {
            $sanitized['tipo'] = sanitize_text_field($data['tipo']);
        }
        if (isset($data['archivo'])) {
            $sanitized['archivo'] = sanitize_file_name($data['archivo']);
        }
        if (isset($data['fecha_documento'])) {
            $sanitized['fecha_documento'] = sanitize_text_field($data['fecha_documento']);
        }
        if (isset($data['categoria'])) {
            $sanitized['categoria'] = sanitize_text_field($data['categoria']);
        }
        if (isset($data['visible_para'])) {
            $sanitized['visible_para'] = sanitize_text_field($data['visible_para']);
        }
        
        return $sanitized;
    }

    // =================================================================
    // MÉTODOS AUXILIARES
    // =================================================================

    public function get_miembros_por_cargo($cargo = 'terapeuta') {
        global $wpdb;
        
        if (!$this->tabla_existe('miembros')) {
            return [];
        }
        
        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$this->table_miembros} WHERE cargo LIKE %s AND estado = 'activo' ORDER BY nombre ASC", '%' . $wpdb->esc_like($cargo) . '%'),
            ARRAY_A
        );
    }
    
    public function calcular_edad($fecha_nacimiento) {
        if (empty($fecha_nacimiento)) {
            return 'N/A';
        }
        
        $nacimiento = new \DateTime($fecha_nacimiento);
        $hoy = new \DateTime();
        $edad = $hoy->diff($nacimiento);
        
        return $edad->y;
    }

    // =================================================================
    // MÉTODOS ESTADÍSTICOS PARA EL DASHBOARD
    // =================================================================

    public function get_total_miembros_activos() {
        global $wpdb;
        
        return $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_miembros} WHERE estado = 'activo'");
    }
    
    public function get_total_eventos_proximos() {
        global $wpdb;
        
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_eventos} WHERE fecha >= %s", 
            current_time('mysql')
        ));
    }
    
    public function get_total_eventos_pendientes() {
        global $wpdb;
        
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_eventos} WHERE fecha >= %s AND estado = 'planificado'", 
            current_time('mysql')
        ));
    }
    
    public function get_estadisticas() {
        return [
            'total_miembros' => $this->get_total_miembros_activos(),
            'total_eventos' => $this->get_total_eventos(),
            'total_documentos' => $this->get_total_documentos(),
            'total_pacientes' => $this->get_total_pacientes_activos(),
            'total_psicodramas' => $this->get_total_psicodramas(),
            'proximos_eventos' => $this->get_eventos_proximos(5)
        ];
    }
    
    public function get_total_pacientes_activos() {
        global $wpdb;
        
        if (!$this->tabla_existe('pacientes')) {
            return 0;
        }
        
        return $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_pacientes} WHERE estado = 'activo'");
    }
    
    public function get_total_psicodramas() {
        global $wpdb;
        
        if (!$this->tabla_existe('psicodramas')) {
            return 0;
        }
        
        return $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_psicodramas} WHERE estado = 'planificada'");
    }
    
    // =================================================================
    // MÉTODOS DE UTILIDAD Y MANTENIMIENTO
    // =================================================================

    /**
     * Crear tabla de medicación si no existe
     */
    public function crear_tabla_medicacion() {
        global $wpdb;
        
        if ($this->tabla_existe('medicacion')) {
            return true;
        }
        
        $charset_collate = $wpdb->get_charset_collate();
        $sql_medicacion = "CREATE TABLE {$this->table_medicacion} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            paciente_id mediumint(9) NOT NULL,
            medicamento varchar(255) NOT NULL,
            dosis varchar(100) NOT NULL,
            frecuencia varchar(100) NOT NULL,
            via_administracion varchar(50),
            fecha_inicio date NOT NULL,
            fecha_fin date,
            horario_administracion text,
            indicaciones_especiales text,
            estado varchar(20) DEFAULT 'activo',
            prescrito_por varchar(255),
            observaciones text,
            fecha_creacion datetime DEFAULT CURRENT_TIMESTAMP,
            fecha_actualizacion datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY paciente_id (paciente_id),
            KEY estado (estado),
            KEY fecha_inicio (fecha_inicio)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_medicacion);
        
        return $this->tabla_existe('medicacion');
    }

    /**
     * Verificar integridad de todas las tablas
     */
    public function verificar_integridad_tablas() {
        global $wpdb;
        
        $tablas = [
            $this->table_miembros,
            $this->table_eventos,
            $this->table_documentos,
            $this->table_psicodramas,
            $this->table_pacientes,
            $this->table_historial_medico,
            $this->table_seguimiento_terapeutico,
            $this->table_solo_por_hoy,
            $this->table_reuniones,
            $this->table_chat_operadores,
            $this->table_tiempo_limpio,
            $this->table_registros_diarios,
            $this->table_medicacion
        ];
        
        $resultados = [];
        foreach ($tablas as $tabla) {
            $resultados[$tabla] = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tabla)) == $tabla;
        }
        
        return $resultados;
    }

    /**
     * Optimizar todas las tablas
     */
    public function optimizar_tablas() {
        global $wpdb;
        
        $tablas = [
            $this->table_miembros,
            $this->table_eventos,
            $this->table_documentos,
            $this->table_psicodramas,
            $this->table_pacientes,
            $this->table_historial_medico,
            $this->table_seguimiento_terapeutico,
            $this->table_solo_por_hoy,
            $this->table_reuniones,
            $this->table_chat_operadores,
            $this->table_tiempo_limpio,
            $this->table_registros_diarios,
            $this->table_medicacion
        ];
        
        foreach ($tablas as $tabla) {
            if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tabla)) == $tabla) {
                $wpdb->query("OPTIMIZE TABLE $tabla");
            }
        }
        
        return true;
    }

    /**
     * Crear backup de todas las tablas
     */
    public function backup_tablas() {
        global $wpdb;
        
        $tablas = [
            $this->table_miembros,
            $this->table_eventos,
            $this->table_documentos,
            $this->table_psicodramas,
            $this->table_pacientes,
            $this->table_historial_medico,
            $this->table_seguimiento_terapeutico,
            $this->table_solo_por_hoy,
            $this->table_reuniones,
            $this->table_chat_operadores,
            $this->table_tiempo_limpio,
            $this->table_registros_diarios,
            $this->table_medicacion
        ];
        
        $backup_data = [];
        foreach ($tablas as $tabla) {
            if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tabla)) == $tabla) {
                $backup_data[$tabla] = $wpdb->get_results("SELECT * FROM $tabla", ARRAY_A);
            }
        }
        
        return $backup_data;
    }

    /**
     * Restaurar backup de tablas
     */
    public function restaurar_backup($backup_data) {
        global $wpdb;
        
        foreach ($backup_data as $tabla => $datos) {
            if (!empty($datos)) {
                // Vaciar tabla primero
                $wpdb->query("TRUNCATE TABLE $tabla");
                
                // Insertar datos
                foreach ($datos as $fila) {
                    $wpdb->insert($tabla, $fila);
                }
            }
        }
        
        return true;
    }

    /**
     * Obtener estadísticas generales del sistema
     */
    public function obtener_estadisticas_generales() {
        global $wpdb;
        
        $estadisticas = [
            'total_miembros' => 0,
            'total_pacientes' => 0,
            'total_registros_hoy' => 0,
            'total_eventos_proximos' => 0
        ];
        
        // Total miembros
        if ($this->tabla_existe('miembros')) {
            $estadisticas['total_miembros'] = $wpdb->get_var("
                SELECT COUNT(*) FROM {$this->table_miembros} WHERE estado = 'activo'
            ");
        }
        
        // Total pacientes
        if ($this->tabla_existe('pacientes')) {
            $estadisticas['total_pacientes'] = $wpdb->get_var("
                SELECT COUNT(*) FROM {$this->table_pacientes} WHERE estado = 'activo'
            ");
        }
        
        // Total registros hoy
        if ($this->tabla_existe('registros_diarios')) {
            $fecha_hoy = date('Y-m-d');
            $estadisticas['total_registros_hoy'] = $wpdb->get_var($wpdb->prepare("
                SELECT COUNT(*) FROM {$this->table_registros_diarios} WHERE fecha = %s
            ", $fecha_hoy));
        }
        
        // Total eventos próximos
        if ($this->tabla_existe('eventos')) {
            $fecha_actual = date('Y-m-d H:i:s');
            $estadisticas['total_eventos_proximos'] = $wpdb->get_var($wpdb->prepare("
                SELECT COUNT(*) FROM {$this->table_eventos} 
                WHERE fecha >= %s AND estado = 'planificado'
            ", $fecha_actual));
        }
        
        return $estadisticas;
    }

    /**
     * Obtener cumplimiento por tipo de actividad
     */
    public function obtener_cumplimiento_por_tipo($rango = 'semana') {
        global $wpdb;
        
        if (!$this->tabla_existe('registros_diarios')) {
            return [];
        }
        
        $fecha_fin = date('Y-m-d');
        switch ($rango) {
            case 'hoy':
                $fecha_inicio = $fecha_fin;
                break;
            case 'semana':
                $fecha_inicio = date('Y-m-d', strtotime('-6 days'));
                break;
            case 'mes':
                $fecha_inicio = date('Y-m-d', strtotime('-29 days'));
                break;
            default:
                $fecha_inicio = date('Y-m-d', strtotime('-6 days'));
        }
        
        $query = $wpdb->prepare("
            SELECT 
                tipo_actividad,
                COUNT(*) as total,
                SUM(CASE WHEN estado = 'completada' THEN 1 ELSE 0 END) as completadas,
                AVG(CASE WHEN valoracion > 0 THEN valoracion ELSE NULL END) as valoracion_promedio
            FROM {$this->table_registros_diarios} 
            WHERE fecha BETWEEN %s AND %s
            GROUP BY tipo_actividad
            ORDER BY total DESC
        ", $fecha_inicio, $fecha_fin);
        
        return $wpdb->get_results($query, ARRAY_A);
    }

    /**
     * Obtener tendencia de cumplimiento por día
     */
    public function obtener_tendencia_cumplimiento($dias = 7) {
        global $wpdb;
        
        if (!$this->tabla_existe('registros_diarios')) {
            return [];
        }
        
        $fecha_fin = date('Y-m-d');
        $fecha_inicio = date('Y-m-d', strtotime('-' . ($dias - 1) . ' days'));
        
        $query = $wpdb->prepare("
            SELECT 
                fecha,
                COUNT(*) as total_actividades,
                SUM(CASE WHEN estado = 'completada' THEN 1 ELSE 0 END) as completadas,
                ROUND((SUM(CASE WHEN estado = 'completada' THEN 1 ELSE 0 END) / COUNT(*)) * 100, 0) as porcentaje
            FROM {$this->table_registros_diarios} 
            WHERE fecha BETWEEN %s AND %s
            GROUP BY fecha
            ORDER BY fecha ASC
        ", $fecha_inicio, $fecha_fin);
        
        return $wpdb->get_results($query, ARRAY_A);
    }

    // =================================================================
    // MÉTODOS PARA REGISTRO AUTOMÁTICO
    // =================================================================

    /**
     * Crear registro automático de actividad actual
     */
    public function registro_automatico_actividad() {
        global $wpdb;
        
        if (!$this->tabla_existe('registros_diarios')) {
            return;
        }
        
        $fecha_actual = date('Y-m-d');
        $hora_actual = date('H:i');
        
        // Obtener actividad actual del horario
        $actividad_actual = $this->obtener_actividad_actual_del_horario($hora_actual);
        
        if (!$actividad_actual) {
            return;
        }
        
        $actividad_id = $actividad_actual['hora'] . '_' . sanitize_title($actividad_actual['detalles']['actividad']);
        
        // Verificar si ya existe
        $existe_registro = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*) FROM {$this->table_registros_diarios} 
            WHERE fecha = %s AND actividad_id = %s
        ", $fecha_actual, $actividad_id));
        
        if ($existe_registro > 0) {
            return;
        }
        
        // Determinar estado automático
        $estado_auto = 'en_progreso';
        $hora_actividad = strtotime($actividad_actual['hora']);
        $hora_actual_ts = strtotime($hora_actual);
        $duracion = $actividad_actual['detalles']['duracion'];
        $hora_fin = strtotime($actividad_actual['hora'] . ' + ' . $duracion . ' minutes');
        
        if ($hora_actual_ts > ($hora_fin + 900)) {
            $estado_auto = 'completada';
        }
        
        $resultado = $wpdb->insert(
            $this->table_registros_diarios,
            [
                'fecha' => $fecha_actual,
                'actividad_id' => $actividad_id,
                'actividad_nombre' => $actividad_actual['detalles']['actividad'],
                'estado' => $estado_auto,
                'duracion_real' => $actividad_actual['detalles']['duracion'],
                'valoracion' => 3,
                'observaciones' => 'Registro automático del sistema',
                'tipo_actividad' => $actividad_actual['detalles']['tipo']
            ],
            ['%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s']
        );
        
        if ($resultado) {
            error_log("Asociacion Civil: Registro automático creado para " . $actividad_actual['detalles']['actividad'] . " - Estado: " . $estado_auto);
        }
    }

    /**
     * Actualizar registros automáticos (cambiar de "en_progreso" a "completada")
     */
    public function actualizar_registros_automaticos() {
        global $wpdb;
        
        if (!$this->tabla_existe('registros_diarios')) {
            return;
        }
        
        $fecha_actual = date('Y-m-d');
        $hora_actual = date('H:i');
        
        $actividades_en_progreso = $wpdb->get_results($wpdb->prepare("
            SELECT * FROM {$this->table_registros_diarios} 
            WHERE fecha = %s AND estado = 'en_progreso'
        ", $fecha_actual), ARRAY_A);
        
        foreach ($actividades_en_progreso as $registro) {
            $partes = explode('_', $registro['actividad_id']);
            $hora_actividad = $partes[0];
            
            $duracion = $registro['duracion_real'] ?: 60;
            $hora_fin = date('H:i', strtotime($hora_actividad . ' + ' . $duracion . ' minutes'));
            
            if (strtotime($hora_actual) > (strtotime($hora_fin) + 900)) {
                $wpdb->update(
                    $this->table_registros_diarios,
                    ['estado' => 'completada'],
                    ['id' => $registro['id']],
                    ['%s'],
                    ['%d']
                );
                error_log("Asociacion Civil: Registro actualizado automáticamente a completado - " . $registro['actividad_nombre']);
            }
        }
    }

    /**
     * Obtener actividad actual del horario
     */
    private function obtener_actividad_actual_del_horario($hora_actual) {
        $actividades = [
            '08:00' => ['actividad' => 'Buen día / Despertar', 'icono' => '☀️', 'duracion' => 30, 'tipo' => 'rutina'],
            '08:30' => ['actividad' => 'Desayuno', 'icono' => '🍽️', 'duracion' => 30, 'tipo' => 'alimentacion'],
            '09:00' => ['actividad' => 'Lectura: "Solo por Hoy" + Libro Azul + Reflexión', 'icono' => '📖', 'duracion' => 30, 'tipo' => 'desarrollo_personal'],
            '09:30' => ['actividad' => 'Objetivos del día', 'icono' => '🎯', 'duracion' => 30, 'tipo' => 'planificacion'],
            '10:00' => ['actividad' => 'Reorden (organización y limpieza)', 'icono' => '🧹', 'duracion' => 90, 'tipo' => 'organizacion'],
            '11:30' => ['actividad' => 'Grupo de Sentimiento Libre', 'icono' => '👥', 'duracion' => 60, 'tipo' => 'terapia_grupal'],
            '12:30' => ['actividad' => 'Almuerzo', 'icono' => '🥗', 'duracion' => 30, 'tipo' => 'alimentacion'],
            '13:00' => ['actividad' => 'Hora Libre', 'icono' => '🆓', 'duracion' => 130, 'tipo' => 'descanso'],
            '15:10' => ['actividad' => 'Grupo de R.E.S. escrita del día anterior', 'icono' => '✍️', 'duracion' => 170, 'tipo' => 'terapia_escrita'],
            '18:10' => ['actividad' => 'Merienda', 'icono' => '☕', 'duracion' => 50, 'tipo' => 'alimentacion'],
            '19:00' => ['actividad' => 'Grupo de Escritura de R.E.S. para leer al día siguiente', 'icono' => '📝', 'duracion' => 120, 'tipo' => 'terapia_escrita'],
            '21:00' => ['actividad' => 'Cena', 'icono' => '🍲', 'duracion' => 60, 'tipo' => 'alimentacion'],
            '22:00' => ['actividad' => 'Medicación', 'icono' => '💊', 'duracion' => 60, 'tipo' => 'salud'],
            '23:00' => ['actividad' => 'Todos a la cama', 'icono' => '🛌', 'duracion' => 480, 'tipo' => 'descanso']
        ];
        
        $actividad_actual = null;
        $hora_actual_ts = strtotime($hora_actual);
        
        foreach ($actividades as $hora => $detalles) {
            $hora_inicio_ts = strtotime($hora);
            $hora_fin_ts = strtotime($hora . ' + ' . $detalles['duracion'] . ' minutes');
            
            if ($hora_actual_ts >= $hora_inicio_ts && $hora_actual_ts < $hora_fin_ts) {
                $actividad_actual = [
                    'hora' => $hora,
                    'detalles' => $detalles,
                    'hora_fin' => date('H:i', $hora_fin_ts)
                ];
                break;
            }
        }
        
        return $actividad_actual;
    }

    // =================================================================
    // MÉTODOS PARA REPORTES
    // =================================================================

    public function get_miembros_por_mes($meses = 12) {
        global $wpdb;
        
        return $wpdb->get_results(
            $wpdb->prepare("
                SELECT 
                    DATE_FORMAT(fecha_ingreso, '%%Y-%%m') as mes,
                    COUNT(*) as total
                FROM {$this->table_miembros} 
                WHERE fecha_ingreso >= DATE_SUB(NOW(), INTERVAL %d MONTH)
                GROUP BY mes
                ORDER BY mes
            ", $meses)
        );
    }
    
    public function get_eventos_por_tipo() {
        global $wpdb;
        
        return $wpdb->get_results("
            SELECT 
                tipo,
                COUNT(*) as total
            FROM {$this->table_eventos} 
            GROUP BY tipo
            ORDER BY total DESC
        ", ARRAY_A);
    }
    
    public function get_documentos_por_visibilidad() {
        global $wpdb;
        
        return $wpdb->get_results("
            SELECT 
                visible_para,
                COUNT(*) as total
            FROM {$this->table_documentos} 
            GROUP BY visible_para
            ORDER BY total DESC
        ", ARRAY_A);
    }
}

// Inicializar la base de datos cuando sea necesario
add_action('admin_init', function() {
    $database = new Database();
    $database->create_tables();
});

?>