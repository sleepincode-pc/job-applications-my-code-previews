<?php

namespace AsociacionCivil;

class Paciente {
    
    private $id;
    private $cedula;
    private $nombre;
    private $apellido;
    private $fecha_nacimiento;
    private $genero;
    private $telefono;
    private $email;
    private $direccion;
    private $contacto_emergencia_nombre;
    private $contacto_emergencia_telefono;
    private $contacto_emergencia_parentesco;
    private $historial_medico;
    private $alergias;
    private $medicamentos_actuales;
    private $seguro_medico;
    private $numero_seguro_medico;
    private $estado_civil;
    private $ocupacion;
    private $nivel_educativo;
    private $referencia_por;
    private $motivo_consulta_principal;
    private $expectativas_tratamiento;
    private $fecha_ingreso;
    private $estado;
    private $observaciones_generales;
    private $foto;
    private $created_at;
    private $updated_at;

    public function __construct($id = null) {
        if ($id) {
            $this->id = $id;
            $this->cargar();
        }
    }

    public function cargar() {
        global $wpdb;
        $tabla = $wpdb->prefix . 'ac_pacientes';
        $paciente = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tabla WHERE id = %d", $this->id), ARRAY_A);
        
        if ($paciente) {
            $this->cedula = $paciente['cedula'];
            $this->nombre = $paciente['nombre'];
            $this->apellido = $paciente['apellido'];
            $this->fecha_nacimiento = $paciente['fecha_nacimiento'];
            $this->genero = $paciente['genero'];
            $this->telefono = $paciente['telefono'];
            $this->email = $paciente['email'];
            $this->direccion = $paciente['direccion'];
            $this->contacto_emergencia_nombre = $paciente['contacto_emergencia_nombre'];
            $this->contacto_emergencia_telefono = $paciente['contacto_emergencia_telefono'];
            $this->contacto_emergencia_parentesco = $paciente['contacto_emergencia_parentesco'];
            $this->historial_medico = $paciente['historial_medico'];
            $this->alergias = $paciente['alergias'];
            $this->medicamentos_actuales = $paciente['medicamentos_actuales'];
            $this->seguro_medico = $paciente['seguro_medico'];
            $this->numero_seguro_medico = $paciente['numero_seguro_medico'];
            $this->estado_civil = $paciente['estado_civil'];
            $this->ocupacion = $paciente['ocupacion'];
            $this->nivel_educativo = $paciente['nivel_educativo'];
            $this->referencia_por = $paciente['referencia_por'];
            $this->motivo_consulta_principal = $paciente['motivo_consulta_principal'];
            $this->expectativas_tratamiento = $paciente['expectativas_tratamiento'];
            $this->fecha_ingreso = $paciente['fecha_ingreso'];
            $this->estado = $paciente['estado'];
            $this->observaciones_generales = $paciente['observaciones_generales'];
            $this->foto = $paciente['foto'];
            $this->created_at = $paciente['created_at'];
            $this->updated_at = $paciente['updated_at'];
            return true;
        }
        return false;
    }

    public function guardar() {
        global $wpdb;
        $tabla = $wpdb->prefix . 'ac_pacientes';

        $datos = array(
            'cedula' => $this->cedula,
            'nombre' => $this->nombre,
            'apellido' => $this->apellido,
            'fecha_nacimiento' => $this->fecha_nacimiento,
            'genero' => $this->genero,
            'telefono' => $this->telefono,
            'email' => $this->email,
            'direccion' => $this->direccion,
            'contacto_emergencia_nombre' => $this->contacto_emergencia_nombre,
            'contacto_emergencia_telefono' => $this->contacto_emergencia_telefono,
            'contacto_emergencia_parentesco' => $this->contacto_emergencia_parentesco,
            'historial_medico' => $this->historial_medico,
            'alergias' => $this->alergias,
            'medicamentos_actuales' => $this->medicamentos_actuales,
            'seguro_medico' => $this->seguro_medico,
            'numero_seguro_medico' => $this->numero_seguro_medico,
            'estado_civil' => $this->estado_civil,
            'ocupacion' => $this->ocupacion,
            'nivel_educativo' => $this->nivel_educativo,
            'referencia_por' => $this->referencia_por,
            'motivo_consulta_principal' => $this->motivo_consulta_principal,
            'expectativas_tratamiento' => $this->expectativas_tratamiento,
            'fecha_ingreso' => $this->fecha_ingreso,
            'estado' => $this->estado,
            'observaciones_generales' => $this->observaciones_generales,
            'foto' => $this->foto,
            'updated_at' => current_time('mysql')
        );

        if ($this->id) {
            return $wpdb->update($tabla, $datos, array('id' => $this->id));
        } else {
            $datos['created_at'] = current_time('mysql');
            $resultado = $wpdb->insert($tabla, $datos);
            if ($resultado) {
                $this->id = $wpdb->insert_id;
            }
            return $resultado;
        }
    }

    public function eliminar() {
        global $wpdb;
        $tabla = $wpdb->prefix . 'ac_pacientes';
        return $wpdb->delete($tabla, array('id' => $this->id));
    }

    // MÉTODO AÑADIDO: Calcular edad a partir de la fecha de nacimiento
    public function calcularEdad() {
        if (empty($this->fecha_nacimiento) || $this->fecha_nacimiento == '0000-00-00') {
            return null;
        }

        try {
            $fecha_nacimiento = new \DateTime($this->fecha_nacimiento);
            $hoy = new \DateTime();
            $edad = $hoy->diff($fecha_nacimiento);
            
            return $edad->y; // Retorna los años
        } catch (\Exception $e) {
            return null;
        }
    }

    // MÉTODO AÑADIDO: Formatear fecha de nacimiento para mostrar
    public function getFechaNacimientoFormateada() {
        if (empty($this->fecha_nacimiento) || $this->fecha_nacimiento == '0000-00-00') {
            return 'No especificada';
        }

        try {
            $fecha = new \DateTime($this->fecha_nacimiento);
            return $fecha->format('d/m/Y');
        } catch (\Exception $e) {
            return 'Fecha inválida';
        }
    }

    // MÉTODO AÑADIDO: Obtener genero formateado
    public function getGeneroFormateado() {
        $generos = [
            'M' => 'Masculino',
            'F' => 'Femenino',
            'O' => 'Otro'
        ];
        
        return $generos[$this->genero] ?? 'No especificado';
    }

    // MÉTODO AÑADIDO: Obtener estado formateado
    public function getEstadoFormateado() {
        $estados = [
            'activo' => 'Activo',
            'inactivo' => 'Inactivo',
            'alta' => 'Alta médica'
        ];
        
        return $estados[$this->estado] ?? 'Desconocido';
    }

    // Getters
    public function getId() { return $this->id; }
    public function getCedula() { return $this->cedula; }
    public function getNombre() { return $this->nombre; }
    public function getApellido() { return $this->apellido; }
    public function getNombreCompleto() { return $this->nombre . ' ' . $this->apellido; }
    public function getFechaNacimiento() { return $this->fecha_nacimiento; }
    public function getGenero() { return $this->genero; }
    public function getTelefono() { return $this->telefono; }
    public function getEmail() { return $this->email; }
    public function getDireccion() { return $this->direccion; }
    public function getContactoEmergenciaNombre() { return $this->contacto_emergencia_nombre; }
    public function getContactoEmergenciaTelefono() { return $this->contacto_emergencia_telefono; }
    public function getContactoEmergenciaParentesco() { return $this->contacto_emergencia_parentesco; }
    public function getHistorialMedico() { return $this->historial_medico; }
    public function getAlergias() { return $this->alergias; }
    public function getMedicamentosActuales() { return $this->medicamentos_actuales; }
    public function getSeguroMedico() { return $this->seguro_medico; }
    public function getNumeroSeguroMedico() { return $this->numero_seguro_medico; }
    public function getEstadoCivil() { return $this->estado_civil; }
    public function getOcupacion() { return $this->ocupacion; }
    public function getNivelEducativo() { return $this->nivel_educativo; }
    public function getReferenciaPor() { return $this->referencia_por; }
    public function getMotivoConsultaPrincipal() { return $this->motivo_consulta_principal; }
    public function getExpectativasTratamiento() { return $this->expectativas_tratamiento; }
    public function getFechaIngreso() { return $this->fecha_ingreso; }
    public function getEstado() { return $this->estado; }
    public function getObservacionesGenerales() { return $this->observaciones_generales; }
    public function getFoto() { return $this->foto; }
    public function getCreatedAt() { return $this->created_at; }
    public function getUpdatedAt() { return $this->updated_at; }

    // Setters
    public function setId($id) { $this->id = $id; }
    public function setCedula($cedula) { $this->cedula = $cedula; }
    public function setNombre($nombre) { $this->nombre = $nombre; }
    public function setApellido($apellido) { $this->apellido = $apellido; }
    public function setFechaNacimiento($fecha_nacimiento) { $this->fecha_nacimiento = $fecha_nacimiento; }
    public function setGenero($genero) { $this->genero = $genero; }
    public function setTelefono($telefono) { $this->telefono = $telefono; }
    public function setEmail($email) { $this->email = $email; }
    public function setDireccion($direccion) { $this->direccion = $direccion; }
    public function setContactoEmergenciaNombre($contacto_emergencia_nombre) { $this->contacto_emergencia_nombre = $contacto_emergencia_nombre; }
    public function setContactoEmergenciaTelefono($contacto_emergencia_telefono) { $this->contacto_emergencia_telefono = $contacto_emergencia_telefono; }
    public function setContactoEmergenciaParentesco($contacto_emergencia_parentesco) { $this->contacto_emergencia_parentesco = $contacto_emergencia_parentesco; }
    public function setHistorialMedico($historial_medico) { $this->historial_medico = $historial_medico; }
    public function setAlergias($alergias) { $this->alergias = $alergias; }
    public function setMedicamentosActuales($medicamentos_actuales) { $this->medicamentos_actuales = $medicamentos_actuales; }
    public function setSeguroMedico($seguro_medico) { $this->seguro_medico = $seguro_medico; }
    public function setNumeroSeguroMedico($numero_seguro_medico) { $this->numero_seguro_medico = $numero_seguro_medico; }
    public function setEstadoCivil($estado_civil) { $this->estado_civil = $estado_civil; }
    public function setOcupacion($ocupacion) { $this->ocupacion = $ocupacion; }
    public function setNivelEducativo($nivel_educativo) { $this->nivel_educativo = $nivel_educativo; }
    public function setReferenciaPor($referencia_por) { $this->referencia_por = $referencia_por; }
    public function setMotivoConsultaPrincipal($motivo_consulta_principal) { $this->motivo_consulta_principal = $motivo_consulta_principal; }
    public function setExpectativasTratamiento($expectativas_tratamiento) { $this->expectativas_tratamiento = $expectativas_tratamiento; }
    public function setFechaIngreso($fecha_ingreso) { $this->fecha_ingreso = $fecha_ingreso; }
    public function setEstado($estado) { $this->estado = $estado; }
    public function setObservacionesGenerales($observaciones_generales) { $this->observaciones_generales = $observaciones_generales; }
    public function setFoto($foto) { $this->foto = $foto; }
    public function setCreatedAt($created_at) { $this->created_at = $created_at; }
    public function setUpdatedAt($updated_at) { $this->updated_at = $updated_at; }
}