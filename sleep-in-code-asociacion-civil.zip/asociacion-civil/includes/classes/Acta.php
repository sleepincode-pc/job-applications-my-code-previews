<?php

namespace AsociacionCivil;

class Acta {
    private $id;
    private $titulo;
    private $fecha;
    private $lugar;
    private $tipo;
    private $contenido;
    private $asistentes;
    private $acuerdos;
    private $fecha_creacion;
    private $fecha_actualizacion;
    private $convocante;
    private $estado;
    private $usuario_id;
    
    private static $database = null;
    
    public function __construct($id = null) {
        // Inicializar valores por defecto
        $this->estado = 'activo';
        $this->usuario_id = get_current_user_id();
        
        if ($id) {
            $this->cargar($id);
        }
    }
    
    /**
     * Obtener instancia única de Database
     */
    private static function get_database() {
        if (self::$database === null) {
            self::$database = new Database();
        }
        return self::$database;
    }
    
    /**
     * Verificar si la tabla de actas existe
     */
    private static function tabla_existe() {
        $database = self::get_database();
        return $database->tabla_existe('actas');
    }
    
    /**
     * Inicializar la tabla si no existe
     */
    private static function inicializar_tabla() {
        $database = self::get_database();
        if (!$database->tabla_existe('actas')) {
            $database->create_tables();
        }
    }
    
    public function cargar($id) {
        global $wpdb;
        
        if (!self::tabla_existe()) {
            self::inicializar_tabla();
        }
        
        $database = self::get_database();
        $tabla = $database->get_table_name('actas');
        
        $acta = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tabla WHERE id = %d", $id));
        
        if ($acta) {
            $this->id = $acta->id;
            $this->titulo = $acta->titulo;
            $this->fecha = $acta->fecha;
            $this->lugar = $acta->lugar;
            $this->tipo = $acta->tipo;
            $this->contenido = $acta->contenido;
            $this->asistentes = $acta->asistentes;
            $this->acuerdos = $acta->acuerdos;
            $this->fecha_creacion = $acta->fecha_creacion;
            $this->fecha_actualizacion = $acta->fecha_actualizacion;
            $this->convocante = $acta->convocante ?? '';
            $this->estado = $acta->estado ?? 'activo';
            $this->usuario_id = $acta->usuario_id ?? get_current_user_id();
            
            self::log("Acta cargada exitosamente - ID: $this->id, Título: $this->titulo");
            return true;
        }
        
        self::log("Error: No se encontró acta con ID: $id", 'error');
        return false;
    }
    
    public function save() {
        global $wpdb;
        
        if (!self::tabla_existe()) {
            self::inicializar_tabla();
        }
        
        $database = self::get_database();
        $tabla = $database->get_table_name('actas');
        
        // Validar datos antes de guardar
        $validacion = $this->es_valida();
        if ($validacion !== true) {
            self::log("Error de validación al guardar acta: " . implode(', ', $validacion), 'error');
            return false;
        }
        
        $datos = array(
            'titulo' => $this->titulo,
            'fecha' => $this->fecha,
            'lugar' => $this->lugar,
            'tipo' => $this->tipo,
            'contenido' => $this->contenido,
            'asistentes' => $this->asistentes,
            'acuerdos' => $this->acuerdos,
            'convocante' => $this->convocante,
            'estado' => $this->estado,
            'usuario_id' => $this->usuario_id,
            'fecha_actualizacion' => current_time('mysql')
        );
        
        self::log("Guardando acta - ID: " . $this->id . ", Título: " . $this->titulo);
        
        try {
            if ($this->id) {
                // Actualizar acta existente
                $resultado = $wpdb->update(
                    $tabla,
                    $datos,
                    array('id' => $this->id),
                    array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s'),
                    array('%d')
                );
                
                if ($resultado === false) {
                    throw new \Exception($wpdb->last_error);
                }
                
                self::log("Acta actualizada exitosamente - ID: $this->id");
                return true;
            } else {
                // Crear nueva acta
                $datos['fecha_creacion'] = current_time('mysql');
                $resultado = $wpdb->insert(
                    $tabla,
                    $datos,
                    array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s')
                );
                
                if ($resultado === false) {
                    throw new \Exception($wpdb->last_error);
                }
                
                $this->id = $wpdb->insert_id;
                self::log("Nueva acta creada exitosamente - ID: $this->id");
                return true;
            }
        } catch (\Exception $e) {
            self::log("Error al guardar acta - ID: $this->id, Error: " . $e->getMessage(), 'error');
            return false;
        }
    }
    
    public function eliminar() {
        global $wpdb;
        
        if (!$this->id) {
            self::log("Error: No se puede eliminar acta sin ID", 'error');
            return false;
        }
        
        if (!self::tabla_existe()) {
            self::log("Error: La tabla de actas no existe", 'error');
            return false;
        }
        
        $database = self::get_database();
        $tabla = $database->get_table_name('actas');
        
        try {
            // Marcar como eliminado en lugar de borrar físicamente
            $resultado = $wpdb->update(
                $tabla,
                array('estado' => 'eliminado', 'fecha_actualizacion' => current_time('mysql')),
                array('id' => $this->id),
                array('%s', '%s'),
                array('%d')
            );
            
            if ($resultado === false) {
                throw new \Exception($wpdb->last_error);
            }
            
            self::log("Acta marcada como eliminada - ID: $this->id");
            $this->estado = 'eliminado';
            return true;
        } catch (\Exception $e) {
            self::log("Error al eliminar acta - ID: $this->id, Error: " . $e->getMessage(), 'error');
            return false;
        }
    }
    
    /**
     * Sistema de logging unificado
     */
    private static function log($mensaje, $tipo = 'info') {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $prefijo = "[Sistema AC - Acta - $tipo]";
            error_log("$prefijo $mensaje");
        }
        
        // También registrar en la base de datos si es un error crítico
        if ($tipo === 'error' && function_exists('ac_log_error')) {
            ac_log_error($mensaje);
        }
    }
    
    // Getters
    public function getId() {
        return $this->id;
    }
    
    public function getTitulo() {
        return $this->titulo;
    }
    
    public function getFecha($formato = 'Y-m-d') {
        if ($this->fecha && $formato) {
            try {
                return date($formato, strtotime($this->fecha));
            } catch (\Exception $e) {
                return $this->fecha;
            }
        }
        return $this->fecha;
    }
    
    public function getLugar() {
        return $this->lugar;
    }
    
    public function getTipo() {
        return $this->tipo;
    }
    
    public function getContenido() {
        return $this->contenido;
    }
    
    public function getAsistentes() {
        return $this->asistentes;
    }
    
    public function getAcuerdos() {
        return $this->acuerdos;
    }
    
    public function getFechaCreacion($formato = 'Y-m-d H:i:s') {
        if ($this->fecha_creacion && $formato) {
            try {
                return date($formato, strtotime($this->fecha_creacion));
            } catch (\Exception $e) {
                return $this->fecha_creacion;
            }
        }
        return $this->fecha_creacion;
    }
    
    public function getFechaActualizacion($formato = 'Y-m-d H:i:s') {
        if ($this->fecha_actualizacion && $formato) {
            try {
                return date($formato, strtotime($this->fecha_actualizacion));
            } catch (\Exception $e) {
                return $this->fecha_actualizacion;
            }
        }
        return $this->fecha_actualizacion;
    }
    
    public function getConvocante() {
        return $this->convocante;
    }
    
    public function getEstado() {
        return $this->estado;
    }
    
    public function getUsuarioId() {
        return $this->usuario_id;
    }
    
    // Setters
    public function setId($id) {
        $this->id = intval($id);
        return $this;
    }
    
    public function setTitulo($titulo) {
        $this->titulo = sanitize_text_field($titulo);
        return $this;
    }
    
    public function setFecha($fecha) {
        $this->fecha = sanitize_text_field($fecha);
        return $this;
    }
    
    public function setLugar($lugar) {
        $this->lugar = sanitize_text_field($lugar);
        return $this;
    }
    
    public function setTipo($tipo) {
        $this->tipo = sanitize_text_field($tipo);
        return $this;
    }
    
    public function setContenido($contenido) {
        $this->contenido = wp_kses_post($contenido);
        return $this;
    }
    
    public function setAsistentes($asistentes) {
        $this->asistentes = wp_kses_post($asistentes);
        return $this;
    }
    
    public function setAcuerdos($acuerdos) {
        $this->acuerdos = wp_kses_post($acuerdos);
        return $this;
    }
    
    public function setConvocante($convocante) {
        $this->convocante = sanitize_text_field($convocante);
        return $this;
    }
    
    public function setEstado($estado) {
        $this->estado = sanitize_text_field($estado);
        return $this;
    }
    
    public function setUsuarioId($usuario_id) {
        $this->usuario_id = intval($usuario_id);
        return $this;
    }
    
    public function setFechaCreacion($fecha_creacion) {
        $this->fecha_creacion = $fecha_creacion;
        return $this;
    }
    
    public function setFechaActualizacion($fecha_actualizacion) {
        $this->fecha_actualizacion = $fecha_actualizacion;
        return $this;
    }
    
    // Métodos de validación
    public function es_valida() {
        $errores = array();
        
        if (empty($this->titulo)) {
            $errores[] = 'El título es requerido';
        }
        
        if (empty($this->fecha)) {
            $errores[] = 'La fecha es requerida';
        } elseif (!strtotime($this->fecha)) {
            $errores[] = 'La fecha no es válida';
        }
        
        if (empty($this->tipo)) {
            $errores[] = 'El tipo de acta es requerido';
        }
        
        return empty($errores) ? true : $errores;
    }
    
    // Métodos estáticos para obtener listas
    public static function get_tipos_acta() {
        return array(
            'reunion' => 'Reunión Ordinaria',
            'asamblea' => 'Asamblea',
            'extraordinaria' => 'Reunión Extraordinaria',
            'junta' => 'Junta Directiva',
            'comision' => 'Comisión',
            'otro' => 'Otro'
        );
    }
    
    public function get_tipo_nombre() {
        $tipos = self::get_tipos_acta();
        return isset($tipos[$this->tipo]) ? $tipos[$this->tipo] : $this->tipo;
    }
    
    // Método para formatear el contenido para display
    public function get_contenido_formateado() {
        return wpautop($this->contenido);
    }
    
    public function get_asistentes_formateados() {
        return wpautop($this->asistentes);
    }
    
    public function get_acuerdos_formateados() {
        return wpautop($this->acuerdos);
    }
    
    // Método para obtener resumen
    public function get_resumen($longitud = 100) {
        $contenido = strip_tags($this->contenido);
        if (strlen($contenido) > $longitud) {
            return substr($contenido, 0, $longitud) . '...';
        }
        return $contenido;
    }
    
    // Método para verificar si es nueva
    public function es_nueva() {
        return empty($this->id);
    }
    
    // Método para clonar acta
    public function clonar() {
        $nueva_acta = new Acta();
        $nueva_acta->setTitulo($this->titulo . ' (Copia)')
                   ->setFecha($this->fecha)
                   ->setLugar($this->lugar)
                   ->setTipo($this->tipo)
                   ->setContenido($this->contenido)
                   ->setAsistentes($this->asistentes)
                   ->setAcuerdos($this->acuerdos)
                   ->setConvocante($this->convocante)
                   ->setEstado($this->estado)
                   ->setUsuarioId($this->usuario_id);
        return $nueva_acta;
    }
    
    // Método para exportar datos como array
    public function to_array() {
        return array(
            'id' => $this->id,
            'titulo' => $this->titulo,
            'fecha' => $this->getFecha('d/m/Y'),
            'lugar' => $this->lugar,
            'tipo' => $this->tipo,
            'tipo_nombre' => $this->get_tipo_nombre(),
            'contenido' => $this->contenido,
            'asistentes' => $this->asistentes,
            'acuerdos' => $this->acuerdos,
            'convocante' => $this->convocante,
            'estado' => $this->estado,
            'usuario_id' => $this->usuario_id,
            'fecha_creacion' => $this->getFechaCreacion('d/m/Y H:i'),
            'fecha_actualizacion' => $this->getFechaActualizacion('d/m/Y H:i'),
            'resumen' => $this->get_resumen(150)
        );
    }
    
    /**
     * Método estático para obtener todas las actas
     */
    public static function obtener_todas($limit = 50, $offset = 0, $filtros = []) {
        if (!self::tabla_existe()) {
            self::inicializar_tabla();
        }
        
        $database = self::get_database();
        $resultados = $database->obtener_actas_existentes($limit, $offset);
        
        $actas = [];
        foreach ($resultados as $resultado) {
            $acta = new Acta();
            $acta->setId($resultado['id'])
                 ->setTitulo($resultado['titulo'])
                 ->setFecha($resultado['fecha'])
                 ->setLugar($resultado['lugar'])
                 ->setTipo($resultado['tipo'])
                 ->setContenido($resultado['contenido'])
                 ->setAsistentes($resultado['asistentes'])
                 ->setAcuerdos($resultado['acuerdos'])
                 ->setConvocante($resultado['convocante'])
                 ->setEstado($resultado['estado'])
                 ->setUsuarioId($resultado['usuario_id'])
                 ->setFechaCreacion($resultado['fecha_creacion'])
                 ->setFechaActualizacion($resultado['fecha_actualizacion']);
            
            $actas[] = $acta;
        }
        
        return $actas;
    }
    
    /**
     * Método estático para obtener una acta por ID
     */
    public static function obtener_por_id($id) {
        $acta = new Acta($id);
        return $acta->getId() ? $acta : null;
    }
    
    /**
     * Método estático para contar actas
     */
    public static function contar($filtros = []) {
        if (!self::tabla_existe()) {
            return 0;
        }
        
        $database = self::get_database();
        return $database->get_total_actas();
    }
    
    /**
     * Método para buscar actas
     */
    public static function buscar($termino, $limit = 50, $offset = 0) {
        if (!self::tabla_existe()) {
            self::inicializar_tabla();
        }
        
        global $wpdb;
        $database = self::get_database();
        $tabla = $database->get_table_name('actas');
        
        $like_term = '%' . $wpdb->esc_like($termino) . '%';
        
        $query = $wpdb->prepare("
            SELECT * FROM $tabla 
            WHERE estado = 'activo' 
            AND (titulo LIKE %s OR contenido LIKE %s OR asistentes LIKE %s)
            ORDER BY fecha DESC 
            LIMIT %d OFFSET %d
        ", $like_term, $like_term, $like_term, $limit, $offset);
        
        $resultados = $wpdb->get_results($query, ARRAY_A);
        
        $actas = [];
        foreach ($resultados as $resultado) {
            $acta = new Acta();
            $acta->setId($resultado['id'])
                 ->setTitulo($resultado['titulo'])
                 ->setFecha($resultado['fecha'])
                 ->setLugar($resultado['lugar'])
                 ->setTipo($resultado['tipo'])
                 ->setContenido($resultado['contenido'])
                 ->setAsistentes($resultado['asistentes'])
                 ->setAcuerdos($resultado['acuerdos'])
                 ->setConvocante($resultado['convocante'])
                 ->setEstado($resultado['estado'])
                 ->setUsuarioId($resultado['usuario_id']);
            
            $actas[] = $acta;
        }
        
        return $actas;
    }
    
    /**
     * Método para generar reporte de actas por período
     */
    public static function generar_reporte($fecha_inicio, $fecha_fin) {
        if (!self::tabla_existe()) {
            self::inicializar_tabla();
        }
        
        global $wpdb;
        $database = self::get_database();
        $tabla = $database->get_table_name('actas');
        
        $query = $wpdb->prepare("
            SELECT * FROM $tabla 
            WHERE estado = 'activo' 
            AND fecha BETWEEN %s AND %s
            ORDER BY fecha, tipo
        ", $fecha_inicio, $fecha_fin);
        
        $resultados = $wpdb->get_results($query, ARRAY_A);
        
        $reporte = [
            'total_actas' => count($resultados),
            'fecha_inicio' => $fecha_inicio,
            'fecha_fin' => $fecha_fin,
            'actas' => [],
            'por_tipo' => [],
            'por_mes' => []
        ];
        
        foreach ($resultados as $resultado) {
            $acta = new Acta();
            $acta->setId($resultado['id'])
                 ->setTitulo($resultado['titulo'])
                 ->setFecha($resultado['fecha'])
                 ->setLugar($resultado['lugar'])
                 ->setTipo($resultado['tipo'])
                 ->setContenido($resultado['contenido'])
                 ->setAsistentes($resultado['asistentes'])
                 ->setAcuerdos($resultado['acuerdos'])
                 ->setConvocante($resultado['convocante']);
            
            $reporte['actas'][] = $acta->to_array();
            
            // Estadísticas por tipo
            $tipo = $resultado['tipo'];
            if (!isset($reporte['por_tipo'][$tipo])) {
                $reporte['por_tipo'][$tipo] = 0;
            }
            $reporte['por_tipo'][$tipo]++;
            
            // Estadísticas por mes
            $mes = date('Y-m', strtotime($resultado['fecha']));
            if (!isset($reporte['por_mes'][$mes])) {
                $reporte['por_mes'][$mes] = 0;
            }
            $reporte['por_mes'][$mes]++;
        }
        
        return $reporte;
    }
    
    /**
     * Método para sincronizar con el sistema integral
     */
    public static function sincronizar_con_sistema_integral() {
        if (!class_exists('SistemaIntegralConnector')) {
            self::log("Conector de sistema integral no disponible", 'warning');
            return false;
        }
        
        try {
            $connector = SistemaIntegralConnector::get_instance();
            
            // Obtener actividades completadas recientemente
            $actividades = $connector->obtener_actividades_completadas_para_actas();
            
            $actas_creadas = [];
            foreach ($actividades as $actividad) {
                $acta = new Acta();
                $acta->setTitulo('Acta de ' . $actividad['actividad'])
                     ->setFecha($actividad['fecha'])
                     ->setLugar('Sede Principal')
                     ->setTipo('reunion')
                     ->setContenido($actividad['observaciones'])
                     ->setAsistentes($actividad['participantes'] ?? '')
                     ->setAcuerdos($actividad['acuerdos'] ?? '')
                     ->setConvocante('Sistema Automático');
                
                if ($acta->save()) {
                    $actas_creadas[] = [
                        'acta_id' => $acta->getId(),
                        'actividad_id' => $actividad['id'],
                        'fecha' => $actividad['fecha']
                    ];
                }
            }
            
            return $actas_creadas;
            
        } catch (\Exception $e) {
            self::log("Error en sincronización: " . $e->getMessage(), 'error');
            return false;
        }
    }
    
    /**
     * Método para validar permisos del usuario actual
     */
    public function usuario_puede_editar() {
        $usuario_actual = get_current_user_id();
        
        // Administradores pueden editar todo
        if (current_user_can('manage_options')) {
            return true;
        }
        
        // El creador puede editar sus propias actas
        if ($this->usuario_id == $usuario_actual) {
            return true;
        }
        
        // Editores pueden editar actas
        if (current_user_can('edit_pages')) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Método para validar permisos del usuario actual para eliminar
     */
    public function usuario_puede_eliminar() {
        // Solo administradores pueden eliminar
        return current_user_can('manage_options');
    }
    
    /**
     * Método para obtener estadísticas de uso
     */
    public static function obtener_estadisticas() {
        if (!self::tabla_existe()) {
            self::inicializar_tabla();
        }
        
        global $wpdb;
        $database = self::get_database();
        $tabla = $database->get_table_name('actas');
        
        $estadisticas = [
            'total' => 0,
            'activas' => 0,
            'eliminadas' => 0,
            'por_tipo' => [],
            'por_mes' => [],
            'por_usuario' => []
        ];
        
        // Total general
        $estadisticas['total'] = $wpdb->get_var("SELECT COUNT(*) FROM $tabla");
        
        // Por estado
        $resultados_estado = $wpdb->get_results("
            SELECT estado, COUNT(*) as total 
            FROM $tabla 
            GROUP BY estado
        ", ARRAY_A);
        
        foreach ($resultados_estado as $row) {
            if ($row['estado'] == 'activo') {
                $estadisticas['activas'] = $row['total'];
            } elseif ($row['estado'] == 'eliminado') {
                $estadisticas['eliminadas'] = $row['total'];
            }
        }
        
        // Por tipo
        $resultados_tipo = $wpdb->get_results("
            SELECT tipo, COUNT(*) as total 
            FROM $tabla 
            WHERE estado = 'activo' 
            GROUP BY tipo
        ", ARRAY_A);
        
        foreach ($resultados_tipo as $row) {
            $estadisticas['por_tipo'][$row['tipo']] = $row['total'];
        }
        
        // Por mes (últimos 6 meses)
        $seis_meses_atras = date('Y-m-d', strtotime('-6 months'));
        $resultados_mes = $wpdb->get_results($wpdb->prepare("
            SELECT DATE_FORMAT(fecha, '%%Y-%%m') as mes, COUNT(*) as total 
            FROM $tabla 
            WHERE estado = 'activo' AND fecha >= %s
            GROUP BY mes 
            ORDER BY mes DESC
        ", $seis_meses_atras), ARRAY_A);
        
        foreach ($resultados_mes as $row) {
            $estadisticas['por_mes'][$row['mes']] = $row['total'];
        }
        
        // Por usuario (top 10)
        $resultados_usuario = $wpdb->get_results("
            SELECT usuario_id, COUNT(*) as total 
            FROM $tabla 
            WHERE estado = 'activo' 
            GROUP BY usuario_id 
            ORDER BY total DESC 
            LIMIT 10
        ", ARRAY_A);
        
        foreach ($resultados_usuario as $row) {
            $usuario = get_user_by('id', $row['usuario_id']);
            $nombre = $usuario ? $usuario->display_name : 'Usuario #' . $row['usuario_id'];
            $estadisticas['por_usuario'][$nombre] = $row['total'];
        }
        
        return $estadisticas;
    }
    
    // Método mágico para representación como string
    public function __toString() {
        return "Acta #{$this->id}: {$this->titulo} ({$this->getFecha('d/m/Y')})";
    }
    
    /**
     * Método para inicializar el sistema completo
     * Debe llamarse en la activación del plugin
     */
    public static function inicializar_sistema() {
        self::inicializar_tabla();
        self::log("Sistema de actas inicializado correctamente");
        return true;
    }
    
    /**
     * Método para limpiar registros antiguos (mantenimiento)
     */
    public static function limpiar_registros_antiguos($dias = 365) {
        if (!self::tabla_existe()) {
            return 0;
        }
        
        global $wpdb;
        $database = self::get_database();
        $tabla = $database->get_table_name('actas');
        
        $fecha_limite = date('Y-m-d', strtotime("-$dias days"));
        
        $resultado = $wpdb->query($wpdb->prepare("
            UPDATE $tabla 
            SET estado = 'archivado' 
            WHERE estado = 'activo' 
            AND fecha < %s
        ", $fecha_limite));
        
        if ($resultado !== false) {
            self::log("$resultado actas archivadas (anteriores a $fecha_limite)");
            return $resultado;
        }
        
        return 0;
    }
}