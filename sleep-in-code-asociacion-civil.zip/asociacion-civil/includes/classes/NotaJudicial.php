<?php

namespace AsociacionCivil;

class NotaJudicial {

    private $id;
    private $titulo;
    private $fecha;
    private $numero_expediente;
    private $juzgado;
    private $descripcion;
    private $estado;
    private $observaciones;
    private $created_at;
    private $updated_at;

    // Getters y Setters

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getTitulo() {
        return $this->titulo;
    }

    public function setTitulo($titulo) {
        $this->titulo = $titulo;
    }

    public function getFecha() {
        return $this->fecha;
    }

    public function setFecha($fecha) {
        $this->fecha = $fecha;
    }

    public function getNumeroExpediente() {
        return $this->numero_expediente;
    }

    public function setNumeroExpediente($numero_expediente) {
        $this->numero_expediente = $numero_expediente;
    }

    public function getJuzgado() {
        return $this->juzgado;
    }

    public function setJuzgado($juzgado) {
        $this->juzgado = $juzgado;
    }

    public function getDescripcion() {
        return $this->descripcion;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function getObservaciones() {
        return $this->observaciones;
    }

    public function setObservaciones($observaciones) {
        $this->observaciones = $observaciones;
    }

    public function getCreatedAt() {
        return $this->created_at;
    }

    public function setCreatedAt($created_at) {
        $this->created_at = $created_at;
    }

    public function getUpdatedAt() {
        return $this->updated_at;
    }

    public function setUpdatedAt($updated_at) {
        $this->updated_at = $updated_at;
    }

    // Métodos para guardar, eliminar, etc.

    public function save() {
        $database = new Database();
        $data = array(
            'titulo' => $this->titulo,
            'fecha' => $this->fecha,
            'numero_expediente' => $this->numero_expediente,
            'juzgado' => $this->juzgado,
            'descripcion' => $this->descripcion,
            'estado' => $this->estado,
            'observaciones' => $this->observaciones
        );

        if ($this->id) {
            // Actualizar
            return $database->update_nota_judicial($this->id, $data);
        } else {
            // Crear
            $nuevo_id = $database->insert_nota_judicial($data);
            if ($nuevo_id) {
                $this->id = $nuevo_id;
                return true;
            }
            return false;
        }
    }

    public function eliminar() {
        $database = new Database();
        return $database->delete_nota_judicial($this->id);
    }

    // Cargar por ID
    public function cargarPorId($id) {
        $database = new Database();
        $nota_judicial = $database->get_nota_judicial_by_id($id);
        if ($nota_judicial) {
            $this->id = $nota_judicial->getId();
            $this->titulo = $nota_judicial->getTitulo();
            $this->fecha = $nota_judicial->getFecha();
            $this->numero_expediente = $nota_judicial->getNumeroExpediente();
            $this->juzgado = $nota_judicial->getJuzgado();
            $this->descripcion = $nota_judicial->getDescripcion();
            $this->estado = $nota_judicial->getEstado();
            $this->observaciones = $nota_judicial->getObservaciones();
            $this->created_at = $nota_judicial->getCreatedAt();
            $this->updated_at = $nota_judicial->getUpdatedAt();
            return true;
        }
        return false;
    }
}