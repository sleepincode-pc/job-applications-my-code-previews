<?php

namespace AsociacionCivil;

class Miembro {
    
    private $data = array();
    private $database;
    
    public function __construct($cedula = null) {
        $this->database = new Database();
        
        if ($cedula) {
            $this->load($cedula);
        }
    }
    
    public function load($cedula) {
        $data = $this->database->get_miembro_by_cedula($cedula);
        
        if ($data) {
            $this->data = (array) $data;
            return true;
        }
        
        return false;
    }
    
    public function save() {
        if ($this->data['id'] ?? false) {
            // Actualizar existente
            return $this->update();
        } else {
            // Crear nuevo
            return $this->create();
        }
    }
    
    private function create() {
        $defaults = array(
            'fecha_ingreso' => current_time('mysql'),
            'estado' => 'activo',
            'tipo_membresia' => 'activo'
        );
        
        $this->data = array_merge($defaults, $this->data);
        
        return $this->database->insert_miembro($this->data);
    }
    
    private function update() {
        $cedula = $this->data['cedula'];
        unset($this->data['id']); // No actualizar el ID
        
        return $this->database->update_miembro($cedula, $this->data);
    }
    
    public function eliminar() {
        if ($this->data['cedula'] ?? false) {
            return $this->database->delete_miembro($this->data['cedula']);
        }
        return false;
    }
    
    public function cambiar_estado($nuevo_estado) {
        $estados_permitidos = array('activo', 'inactivo', 'suspendido');
        if (in_array($nuevo_estado, $estados_permitidos)) {
            $this->data['estado'] = $nuevo_estado;
            return $this->save();
        }
        return false;
    }
    
    // Getters
    public function getNombreCompleto() {
        return $this->data['nombre'] . ' ' . $this->data['apellido'];
    }
    
    public function getCedula() {
        return $this->data['cedula'] ?? '';
    }
    
    public function getNombre() {
        return $this->data['nombre'] ?? '';
    }
    
    public function getApellido() {
        return $this->data['apellido'] ?? '';
    }
    
    public function getEmail() {
        return $this->data['email'] ?? '';
    }
    
    public function getTelefono() {
        return $this->data['telefono'] ?? '';
    }
    
    public function getDireccion() {
        return $this->data['direccion'] ?? '';
    }
    
    public function getCargo() {
        return $this->data['cargo'] ?? '';
    }
    
    public function getEstado() {
        return $this->data['estado'] ?? '';
    }
    
    public function getFechaIngreso() {
        return $this->data['fecha_ingreso'] ?? '';
    }
    
    public function getFechaIngresoFormateada() {
        return date('d/m/Y', strtotime($this->data['fecha_ingreso'] ?? ''));
    }
    
    public function getTipoMembresia() {
        return $this->data['tipo_membresia'] ?? '';
    }
    
    // Setters con validación
    public function setCedula($cedula) {
        $this->data['cedula'] = sanitize_text_field($cedula);
    }
    
    public function setNombre($nombre) {
        $this->data['nombre'] = sanitize_text_field($nombre);
    }
    
    public function setApellido($apellido) {
        $this->data['apellido'] = sanitize_text_field($apellido);
    }
    
    public function setEmail($email) {
        $this->data['email'] = sanitize_email($email);
    }
    
    public function setTelefono($telefono) {
        $this->data['telefono'] = sanitize_text_field($telefono);
    }
    
    public function setCargo($cargo) {
        $this->data['cargo'] = sanitize_text_field($cargo);
    }
    
    public function setDireccion($direccion) {
        $this->data['direccion'] = sanitize_textarea_field($direccion);
    }
    
    public function setFechaNacimiento($fecha) {
        $this->data['fecha_nacimiento'] = sanitize_text_field($fecha);
    }
    
    public function setFechaIngreso($fecha) {
        $this->data['fecha_ingreso'] = sanitize_text_field($fecha);
    }
    
    public function setTipoMembresia($tipo) {
        $tipos_permitidos = array('activo', 'vitalicio', 'honorario');
        if (in_array($tipo, $tipos_permitidos)) {
            $this->data['tipo_membresia'] = $tipo;
        }
    }
    
    public function setObservaciones($observaciones) {
        $this->data['observaciones'] = sanitize_textarea_field($observaciones);
    }
    
    public function toArray() {
        return $this->data;
    }
    
    public function esJuntaDirectiva() {
        $cargos_junta = array('Presidente', 'Vicepresidente', 'Secretario', 'Tesorero', 'Vocal');
        return in_array($this->data['cargo'], $cargos_junta);
    }
}
?>