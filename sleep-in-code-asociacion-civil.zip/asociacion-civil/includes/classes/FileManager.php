<?php

namespace AsociacionCivil;

class FileManager {
    
    private $upload_dir;
    
    public function __construct() {
        $upload_dir = wp_upload_dir();
        $this->upload_dir = $upload_dir['basedir'] . '/asociacion-civil';
        $this->ensure_directories();
    }
    
    private function ensure_directories() {
        $directories = [
            '/pacientes',
            '/pacientes/fotos-perfil',
            '/pacientes/fotos-generales',
            '/documentos',
            '/actas'
        ];
        
        foreach ($directories as $dir) {
            $full_path = $this->upload_dir . $dir;
            if (!file_exists($full_path)) {
                wp_mkdir_p($full_path);
            }
        }
        
        // Crear archivo .htaccess para protección
        $htaccess_content = "Options -Indexes\nDeny from all";
        file_put_contents($this->upload_dir . '/.htaccess', $htaccess_content);
    }
    
    public function get_paciente_fotos($paciente_id) {
        $fotos = [];
        
        // Obtener fotos de perfil
        $perfil_dir = $this->upload_dir . '/pacientes/fotos-perfil';
        $perfil_pattern = $perfil_dir . '/paciente-' . $paciente_id . '-*';
        $perfil_files = glob($perfil_pattern);
        
        foreach ($perfil_files as $file) {
            $filename = basename($file);
            $fotos[] = [
                'filename' => $filename,
                'url' => $this->get_file_url($filename, '/pacientes/fotos-perfil'),
                'tipo' => 'perfil',
                'fecha' => filemtime($file)
            ];
        }
        
        // Obtener fotos generales
        $general_dir = $this->upload_dir . '/pacientes/fotos-generales';
        $general_pattern = $general_dir . '/paciente-' . $paciente_id . '-*';
        $general_files = glob($general_pattern);
        
        foreach ($general_files as $file) {
            $filename = basename($file);
            $fotos[] = [
                'filename' => $filename,
                'url' => $this->get_file_url($filename, '/pacientes/fotos-generales'),
                'tipo' => 'general',
                'fecha' => filemtime($file)
            ];
        }
        
        // Ordenar por fecha (más reciente primero)
        usort($fotos, function($a, $b) {
            return $b['fecha'] - $a['fecha'];
        });
        
        return $fotos;
    }
    
    public function get_foto_perfil_principal($paciente_id) {
        $fotos = $this->get_paciente_fotos($paciente_id);
        
        // Buscar la primera foto de perfil
        foreach ($fotos as $foto) {
            if ($foto['tipo'] === 'perfil') {
                return $foto['url'];
            }
        }
        
        // Si no encuentra foto de perfil, buscar cualquier foto
        if (!empty($fotos)) {
            return $fotos[0]['url'];
        }
        
        // Si no hay fotos, retornar null o una imagen por defecto
        return null;
    }
    
    public function get_file_url($filename, $subdir = '') {
        $upload_dir = wp_upload_dir();
        return $upload_dir['baseurl'] . '/asociacion-civil' . $subdir . '/' . $filename;
    }
    
    public function subir_foto_perfil($paciente_id, $file) {
        $perfil_dir = $this->upload_dir . '/pacientes/fotos-perfil';
        
        // Generar nombre único para el archivo
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'paciente-' . $paciente_id . '-' . uniqid() . '.' . $extension;
        $filepath = $perfil_dir . '/' . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            return $filename;
        }
        
        return false;
    }
    
    public function eliminar_foto($filename, $tipo = 'perfil') {
        if ($tipo === 'perfil') {
            $filepath = $this->upload_dir . '/pacientes/fotos-perfil/' . $filename;
        } else {
            $filepath = $this->upload_dir . '/pacientes/fotos-generales/' . $filename;
        }
        
        if (file_exists($filepath)) {
            return unlink($filepath);
        }
        
        return false;
    }
}
?>