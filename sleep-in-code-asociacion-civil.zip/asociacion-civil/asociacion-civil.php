<?php
/**
 * Plugin Name: Administrador de Asociación Civil
 * Description: Gestión completa de la asociación civil - miembros, eventos, documentación, cámaras de seguridad, psicodramas y pacientes
 * Version: 1.2.0
 * Author: Tu Nombre
 * Text Domain: asociacion-civil
 * License: GPL v2 or later
 * Requires at least: 5.0
 * Tested up to: 6.3
 * Requires PHP: 7.4
 */

// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Definir constantes
define('ASOCIACION_CIVIL_PLUGIN_URL', plugin_dir_url(__FILE__));
define('ASOCIACION_CIVIL_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('ASOCIACION_CIVIL_PLUGIN_VERSION', '1.2.0');
define('ASOCIACION_CIVIL_PLUGIN_BASENAME', plugin_basename(__FILE__));

// CONSTANTES PARA EL SISTEMA DE CAMPOS Y CLASIFICADOR
define('ASOCIACION_CIVIL_CAMPOS_PATH', ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/');
define('ASOCIACION_CIVIL_CLASIFICADOR_PATH', ASOCIACION_CIVIL_PLUGIN_PATH . 'includes/');

// NUEVA CONSTANTE PARA EL SISTEMA DE LIBRO DE ACTAS
define('ASOCIACION_CIVIL_LIBRO_ACTAS_PATH', ASOCIACION_CIVIL_PLUGIN_PATH . 'templates/admin/');

// Autocargador de clases
spl_autoload_register(function ($class_name) {
    if (strpos($class_name, 'AsociacionCivil\\') === 0) {
        $class_name = str_replace('AsociacionCivil\\', '', $class_name);
        $class_file = ASOCIACION_CIVIL_PLUGIN_PATH . 'includes/classes/' . $class_name . '.php';
        if (file_exists($class_file)) {
            require_once $class_file;
        }
    }
});

// Inicializar el plugin
class AsociacionCivilPlugin {
    
    private static $instance = null;
    private $database;
    private $admin;
    private $dashboard;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->init();
    }
    
    private function init() {
        // Registrar hooks de activación/desactivación
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        register_uninstall_hook(__FILE__, array('AsociacionCivilPlugin', 'uninstall'));
        
        // Cargar clases cuando WordPress esté listo
        add_action('plugins_loaded', array($this, 'load_classes'));
        add_action('init', array($this, 'load_textdomain'));
        
        // Registrar hooks adicionales
        add_action('admin_init', array($this, 'admin_init'));
        
        // Cargar jQuery UI y scripts del plugin
        add_action('admin_enqueue_scripts', array($this, 'cargar_scripts_admin'));
        
        // NUEVO: Ejecutar el sistema de libro de actas cuando sea necesario
        add_action('admin_menu', array($this, 'verificar_sistema_actas'), 20);
    }
    
    // NUEVO MÉTODO: Verificar que el sistema de actas esté listo
    public function verificar_sistema_actas() {
        // Verificar que las funciones del sistema de actas estén disponibles
        $funciones_criticas = array(
            'ac_sistema_integrado',
            'ac_ajax_registro_masivo_faltantes',
            'ac_verificar_actividades_faltantes'
        );
        
        $funciones_faltantes = array();
        foreach ($funciones_criticas as $funcion) {
            if (!function_exists($funcion)) {
                $funciones_faltantes[] = $funcion;
            }
        }
        
        if (!empty($funciones_faltantes) && current_user_can('manage_options')) {
            error_log('Asociacion Civil: ADVERTENCIA - Funciones de libro de actas faltantes: ' . implode(', ', $funciones_faltantes));
            
            // Intentar cargar los archivos manualmente
            $this->cargar_sistema_libro_actas_manual();
        }
    }
    
    // NUEVO MÉTODO: Cargar manualmente el sistema de libro de actas
    private function cargar_sistema_libro_actas_manual() {
        $archivos_libro_actas = array(
            'libro-actas-core.php',
            'libro-actas-ui.php'
        );
        
        foreach ($archivos_libro_actas as $archivo) {
            $ruta_completa = ASOCIACION_CIVIL_LIBRO_ACTAS_PATH . $archivo;
            if (file_exists($ruta_completa)) {
                require_once $ruta_completa;
                error_log('Asociacion Civil: Archivo de libro de actas cargado manualmente - ' . $archivo);
            } else {
                error_log('Asociacion Civil: ERROR - No se encontró el archivo de libro de actas - ' . $ruta_completa);
            }
        }
    }
    
    public function cargar_scripts_admin($hook) {
        // Solo cargar en las páginas de nuestro plugin
        if (strpos($hook, 'ac-') === false) {
            return;
        }
        
        // Cargar jQuery UI completo
        wp_enqueue_script('jquery-ui-core');
        wp_enqueue_script('jquery-ui-widget');
        wp_enqueue_script('jquery-ui-mouse');
        wp_enqueue_script('jquery-ui-accordion');
        wp_enqueue_script('jquery-ui-autocomplete');
        wp_enqueue_script('jquery-ui-slider');
        wp_enqueue_script('jquery-ui-tabs');
        wp_enqueue_script('jquery-ui-sortable');
        wp_enqueue_script('jquery-ui-draggable');
        wp_enqueue_script('jquery-ui-droppable');
        wp_enqueue_script('jquery-ui-datepicker');
        wp_enqueue_script('jquery-ui-dialog');
        wp_enqueue_script('jquery-ui-tooltip');
        
        // Cargar estilos de jQuery UI
        wp_enqueue_style('jquery-ui-css', ASOCIACION_CIVIL_PLUGIN_URL . 'assets/css/jquery-ui.css', array(), '1.12.1');
        
        // Cargar nuestro script principal
        wp_enqueue_script(
            'asociacion-civil-admin',
            ASOCIACION_CIVIL_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery', 'jquery-ui-core', 'jquery-ui-tooltip', 'jquery-ui-datepicker', 'jquery-ui-tabs'),
            ASOCIACION_CIVIL_PLUGIN_VERSION,
            true
        );
        
        // Cargar nuestros estilos
        wp_enqueue_style(
            'asociacion-civil-admin',
            ASOCIACION_CIVIL_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            ASOCIACION_CIVIL_PLUGIN_VERSION
        );
        
        // Pasar variables a JavaScript
        wp_localize_script('asociacion-civil-admin', 'ac_admin_config', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('asociacion_civil_nonce'),
            'base_url' => ASOCIACION_CIVIL_PLUGIN_URL,
            'textos' => array(
                'loading' => __('Cargando...', 'asociacion-civil'),
                'error' => __('Error', 'asociacion-civil'),
                'success' => __('Éxito', 'asociacion-civil'),
                'confirm_delete' => __('¿Está seguro de que desea eliminar este elemento?', 'asociacion-civil')
            )
        ));
    }
    
    public function activate() {
        global $wpdb;
        
        // Verificar requisitos mínimos
        $this->verificar_requisitos();
        
        // Cargar archivo de upgrade para dbDelta
        if (!function_exists('dbDelta')) {
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        }
        
        // Cargar la clase Database manualmente porque el autocargador no está disponible en la activación
        require_once ASOCIACION_CIVIL_PLUGIN_PATH . 'includes/classes/Database.php';
        
        // Crear todas las tablas usando la clase Database
        $database = new AsociacionCivil\Database();
        $database->create_tables();
        
        // Crear roles y capacidades
        $this->create_roles();
        
        // Configuración inicial
        $this->initial_setup();
        
        // Programar eventos cron
        $this->programar_eventos_cron();
        
        // Registrar la activación
        $this->registrar_activacion();
        
        // Flush rewrite rules
        flush_rewrite_rules();
        
        error_log('✅ Plugin Asociación Civil activado - Todas las tablas creadas usando la clase Database');
    }

    public function deactivate() {
        // Limpiar eventos cron
        $this->limpiar_eventos_cron();
        
        // Limpiar cache temporal
        $this->limpiar_cache_temporal();
        
        // Registrar la desactivación
        $this->registrar_desactivacion();
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    public static function uninstall() {
        // Cargar el archivo de desinstalación
        require_once ASOCIACION_CIVIL_PLUGIN_PATH . 'uninstall.php';
    }
    
    public function load_classes() {
        // 1. Cargar todos los archivos de campos primero
        $this->cargar_archivos_campos();
        
        // 2. Cargar clasificador de contenido
        $this->cargar_clasificador();
        
        // 3. Cargar sistema de libro de actas (¡CRÍTICO!)
        $this->cargar_sistema_libro_actas();
        
        // 4. Cargar todas las clases necesarias
        $clases_requeridas = array(
            'Database',
            'Miembro',
            'Evento',
            'Documento',
            'Acta',
            'SesionPsicologica',
            'CamaraSeguridad',
            'RegistroCamara',
            'Psicodrama',
            'Paciente',
            'HistorialMedico',
            'SeguimientoTerapeutico',
            'Admin',
            'Dashboard'
        );
        
        foreach ($clases_requeridas as $clase) {
            $archivo = ASOCIACION_CIVIL_PLUGIN_PATH . 'includes/classes/' . $clase . '.php';
            if (file_exists($archivo)) {
                require_once $archivo;
                error_log('Asociacion Civil: Clase cargada - ' . $clase);
            } else {
                error_log('Asociacion Civil: No se pudo cargar la clase ' . $clase . ' desde ' . $archivo);
            }
        }
        
        // 5. Inicializar componentes
        try {
            $this->database = new AsociacionCivil\Database();
            $this->admin = new AsociacionCivil\Admin();
            $this->dashboard = new AsociacionCivil\Dashboard();
            
            // Debug: Verificar que todo se cargó
            $this->verificar_carga_completa();
            
        } catch (Exception $e) {
            error_log('Asociacion Civil: Error inicializando clases - ' . $e->getMessage());
        }
    }
    
    /**
     * Cargar todos los archivos de campos
     */
    private function cargar_archivos_campos() {
        $archivos_campos = array(
            'campos-psicodramas.php',
            'campos-sesiones-psicologicas.php',
            'campos-pacientes.php',
            'campos-notas-judiciales.php',
            'campos-historial-medico.php',
            'campos-miembros.php',
            'campos-seguimiento-terapeutico.php',
            'campos-documentos.php'
        );
        
        foreach ($archivos_campos as $archivo) {
            $ruta_completa = ASOCIACION_CIVIL_CAMPOS_PATH . $archivo;
            if (file_exists($ruta_completa)) {
                require_once $ruta_completa;
                error_log('Asociacion Civil: Campo cargado - ' . $archivo);
            } else {
                error_log('Asociacion Civil: No se encontró el archivo de campo - ' . $ruta_completa);
            }
        }
    }

    /**
     * Cargar el clasificador de contenido
     */
    private function cargar_clasificador() {
        $archivo_clasificador = ASOCIACION_CIVIL_CLASIFICADOR_PATH . 'ClasificadorContenido.php';
        if (file_exists($archivo_clasificador)) {
            require_once $archivo_clasificador;
            error_log('Asociacion Civil: Clasificador de contenido cargado');
        } else {
            error_log('Asociacion Civil: No se encontró el clasificador de contenido - ' . $archivo_clasificador);
        }
    }
    
    /**
     * Cargar el sistema de libro de actas
     */
    private function cargar_sistema_libro_actas() {
        // Archivos del sistema de libro de actas
        $archivos_libro_actas = array(
            'libro-actas-core.php',
            'libro-actas-ui.php'
        );
        
        foreach ($archivos_libro_actas as $archivo) {
            $ruta_completa = ASOCIACION_CIVIL_LIBRO_ACTAS_PATH . $archivo;
            if (file_exists($ruta_completa)) {
                require_once $ruta_completa;
                error_log('Asociacion Civil: Sistema de libro de actas cargado - ' . $archivo);
            } else {
                error_log('Asociacion Civil: ERROR - No se encontró el archivo de libro de actas - ' . $ruta_completa);
            }
        }
        
        // Verificar que las funciones críticas estén disponibles
        $this->verificar_funciones_actas();
    }
    
    /**
     * Verificar que las funciones del sistema de actas estén disponibles
     */
    private function verificar_funciones_actas() {
        $funciones_criticas = array(
            'ac_verificar_actividades_faltantes',
            'ac_ajax_registro_masivo_faltantes',
            'ac_manejar_sincronizacion_actas_ajax',
            'ac_guardar_registro_diario',
            'ac_sistema_integrado'
        );
        
        $funciones_faltantes = array();
        foreach ($funciones_criticas as $funcion) {
            if (!function_exists($funcion)) {
                $funciones_faltantes[] = $funcion;
            }
        }
        
        if (!empty($funciones_faltantes)) {
            error_log('Asociacion Civil: ADVERTENCIA - Funciones de libro de actas no disponibles: ' . implode(', ', $funciones_faltantes));
            
            // Intentar cargar los archivos manualmente
            $this->cargar_sistema_libro_actas_manual();
        } else {
            error_log('Asociacion Civil: ✅ Sistema de libro de actas cargado correctamente - Todas las funciones disponibles');
        }
    }
    
    public function load_textdomain() {
        load_plugin_textdomain(
            'asociacion-civil',
            false,
            dirname(plugin_basename(__FILE__)) . '/languages'
        );
    }
    
    public function admin_init() {
        // Verificar si necesitamos realizar alguna actualización
        $this->verificar_actualizaciones();
        
        // Registrar configuraciones
        $this->registrar_configuraciones();
        
        // Agregar enlaces de acción en la lista de plugins
        add_filter('plugin_action_links_' . ASOCIACION_CIVIL_PLUGIN_BASENAME, array($this, 'agregar_enlaces_plugin'));
        
        // Agregar enlaces de meta en la lista de plugins
        add_filter('plugin_row_meta', array($this, 'agregar_meta_enlaces_plugin'), 10, 2);
        
        // Registrar AJAX handlers
        $this->registrar_ajax_handlers();
        
        // Debug: Verificar que admin_init se ejecuta
        if (defined('WP_DEBUG') && WP_DEBUG) {
            add_action('admin_notices', array($this, 'debug_admin_notice'));
        }
    }
    
    // MÉTODO: Registrar handlers AJAX
    private function registrar_ajax_handlers() {
        // =============================================
        // HANDLERS PARA EL SISTEMA DE LIBRO DE ACTAS
        // =============================================
        
        // Handler para registro masivo de actividades faltantes
        if (function_exists('ac_ajax_registro_masivo_faltantes')) {
            add_action('wp_ajax_ac_registro_masivo_faltantes', 'ac_ajax_registro_masivo_faltantes');
            error_log('Asociacion Civil: ✅ Handler AJAX registrado - ac_registro_masivo_faltantes');
        } else {
            error_log('Asociacion Civil: ❌ ERROR - No se pudo registrar handler AJAX: ac_registro_masivo_faltantes');
        }
        
        // Handler para sincronización de actas
        if (function_exists('ac_manejar_sincronizacion_actas_ajax')) {
            add_action('wp_ajax_ac_sincronizar_actas', 'ac_manejar_sincronizacion_actas_ajax');
            error_log('Asociacion Civil: ✅ Handler AJAX registrado - ac_sincronizar_actas');
        } else {
            error_log('Asociacion Civil: ❌ ERROR - No se pudo registrar handler AJAX: ac_sincronizar_actas');
        }
        
        // =============================================
        // HANDLERS PARA EL SISTEMA PRINCIPAL
        // =============================================
        
        // Handlers para búsqueda
        add_action('wp_ajax_ac_buscar_miembros', array($this, 'ajax_buscar_miembros'));
        add_action('wp_ajax_ac_buscar_pacientes', array($this, 'ajax_buscar_pacientes'));
        
        // Handlers para guardar datos
        add_action('wp_ajax_ac_guardar_formulario', array($this, 'ajax_guardar_formulario'));
        add_action('wp_ajax_ac_cambiar_estado', array($this, 'ajax_cambiar_estado'));
        
        // Handlers para exportación
        add_action('wp_ajax_ac_exportar_datos', array($this, 'ajax_exportar_datos'));
        
        // Registrar todos los handlers en un log para debug
        $registro_masivo = has_action('wp_ajax_ac_registro_masivo_faltantes') ? '✅' : '❌';
        $sincronizacion = has_action('wp_ajax_ac_sincronizar_actas') ? '✅' : '❌';
        error_log("Asociacion Civil: Total handlers AJAX registrados: {$registro_masivo} para registro masivo, {$sincronizacion} para sincronización");
    }
    
    /**
     * Verificar que todo se cargó correctamente
     */
    private function verificar_carga_completa() {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            // Verificar sistema de libro de actas
            $this->verificar_funciones_actas();
            
            // Verificar clases principales
            $clases_verificadas = array(
                'Database' => ($this->database instanceof AsociacionCivil\Database),
                'Admin' => ($this->admin instanceof AsociacionCivil\Admin),
                'Dashboard' => ($this->dashboard instanceof AsociacionCivil\Dashboard),
                'Acta' => class_exists('AsociacionCivil\Acta'),
                'SesionPsicologica' => class_exists('AsociacionCivil\SesionPsicologica'),
                'CamaraSeguridad' => class_exists('AsociacionCivil\CamaraSeguridad'),
                'RegistroCamara' => class_exists('AsociacionCivil\RegistroCamara'),
                'Psicodrama' => class_exists('AsociacionCivil\Psicodrama'),
                'Paciente' => class_exists('AsociacionCivil\Paciente'),
                'HistorialMedico' => class_exists('AsociacionCivil\HistorialMedico'),
                'SeguimientoTerapeutico' => class_exists('AsociacionCivil\SeguimientoTerapeutico')
            );
            
            $clases_ok = array_filter($clases_verificadas);
            error_log('Asociacion Civil: Clases cargadas: ' . count($clases_ok) . '/' . count($clases_verificadas));
            
            if (count($clases_ok) === count($clases_verificadas)) {
                error_log('Asociacion Civil: ✅ Todas las clases cargadas correctamente');
            } else {
                $clases_faltantes = array_keys(array_filter($clases_verificadas, function($cargada) {
                    return !$cargada;
                }));
                error_log('Asociacion Civil: ❌ Clases faltantes: ' . implode(', ', $clases_faltantes));
            }
        }
    }
    
    // Métodos AJAX placeholder
    public function ajax_buscar_miembros() {
        check_ajax_referer('asociacion_civil_nonce', 'nonce');
        
        $term = sanitize_text_field($_GET['term']);
        $resultados = array();
        
        // Aquí iría la lógica real de búsqueda
        if (!empty($term)) {
            $resultados[] = array(
                'id' => 1,
                'label' => 'Ejemplo Miembro - ' . $term,
                'value' => 'Ejemplo Miembro'
            );
        }
        
        wp_send_json_success($resultados);
    }
    
    public function ajax_buscar_pacientes() {
        check_ajax_referer('asociacion_civil_nonce', 'nonce');
        
        $term = sanitize_text_field($_GET['term']);
        $resultados = array();
        
        // Aquí iría la lógica real de búsqueda
        if (!empty($term)) {
            $resultados[] = array(
                'id' => 1,
                'label' => 'Ejemplo Paciente - ' . $term,
                'value' => 'Ejemplo Paciente'
            );
        }
        
        wp_send_json_success($resultados);
    }
    
    public function ajax_guardar_formulario() {
        check_ajax_referer('asociacion_civil_nonce', 'nonce');
        
        // Aquí iría la lógica real para guardar formularios
        wp_send_json_success(array(
            'message' => 'Datos guardados correctamente',
            'reload' => false
        ));
    }
    
    public function ajax_cambiar_estado() {
        check_ajax_referer('asociacion_civil_nonce', 'nonce');
        
        // Aquí iría la lógica real para cambiar estados
        wp_send_json_success(array(
            'message' => 'Estado actualizado correctamente',
            'update_ui' => true,
            'estado_texto' => 'Activo'
        ));
    }
    
    public function ajax_exportar_datos() {
        check_ajax_referer('asociacion_civil_nonce', 'nonce');
        
        // Aquí iría la lógica real para exportar datos
        wp_send_json_success(array(
            'url' => '#',
            'filename' => 'exportacion.csv'
        ));
    }
    
    public function debug_admin_notice() {
        if (current_user_can('manage_options')) {
            // Verificar funciones del sistema de actas
            $funciones_actas = array(
                'ac_verificar_actividades_faltantes',
                'ac_ajax_registro_masivo_faltantes',
                'ac_sistema_integrado'
            );
            
            $estados = array();
            foreach ($funciones_actas as $funcion) {
                $estados[] = $funcion . ': ' . (function_exists($funcion) ? '✅' : '❌');
            }
            
            echo '<div class="notice notice-info"><p><strong>Debug Asociación Civil:</strong> ' . 
                 implode(' | ', $estados) . '</p></div>';
        }
    }
    
    private function verificar_requisitos() {
        $requisitos = array(
            'php_version' => '7.4',
            'wp_version' => '5.0'
        );
        
        $errores = array();
        
        // Verificar versión de PHP
        if (version_compare(PHP_VERSION, $requisitos['php_version'], '<')) {
            $errores[] = sprintf(
                'Se requiere PHP versión %s o superior. Tu versión actual es %s.',
                $requisitos['php_version'],
                PHP_VERSION
            );
        }
        
        // Verificar versión de WordPress
        global $wp_version;
        if (version_compare($wp_version, $requisitos['wp_version'], '<')) {
            $errores[] = sprintf(
                'Se requiere WordPress versión %s o superior. Tu versión actual es %s.',
                $requisitos['wp_version'],
                $wp_version
            );
        }
        
        // Si hay errores, mostrar mensaje y desactivar plugin
        if (!empty($errores)) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                '<h1>Error de Activación</h1>' .
                '<p>No se puede activar el plugin <strong>Administrador de Asociación Civil</strong> debido a los siguientes errores:</p>' .
                '<ul><li>' . implode('</li><li>', $errores) . '</li></ul>' .
                '<p>Por favor, corrige estos errores y intenta activar el plugin nuevamente.</p>' .
                '<p><a href="' . admin_url('plugins.php') . '">Volver a la lista de plugins</a></p>'
            );
        }
    }
    
    private function create_roles() {
        // Capacidades para administradores
        $admin_role = get_role('administrator');
        if ($admin_role) {
            $capabilities = array(
                'manage_asociacion',
                'gestionar_miembros', 
                'gestionar_eventos',
                'gestionar_documentos',
                'gestionar_actas',
                'gestionar_sesiones',
                'gestionar_camaras',
                'gestionar_psicodramas',
                'gestionar_pacientes',
                'gestionar_historial_medico',
                'gestionar_seguimiento_terapeutico',
                'ver_reportes',
                'configurar_asociacion'
            );
            
            foreach ($capabilities as $cap) {
                if (!$admin_role->has_cap($cap)) {
                    $admin_role->add_cap($cap);
                }
            }
        }
        
        // Capacidades para editores
        $editor_role = get_role('editor');
        if ($editor_role) {
            $editor_caps = array(
                'manage_asociacion',
                'gestionar_miembros',
                'gestionar_eventos', 
                'gestionar_documentos',
                'gestionar_actas',
                'gestionar_sesiones',
                'gestionar_camaras',
                'gestionar_psicodramas',
                'gestionar_pacientes',
                'gestionar_historial_medico',
                'gestionar_seguimiento_terapeutico',
                'ver_reportes'
            );
            
            foreach ($editor_caps as $cap) {
                if (!$editor_role->has_cap($cap)) {
                    $editor_role->add_cap($cap);
                }
            }
        }
        
        // Capacidades para seguridad (nuevo rol opcional)
        $security_role = get_role('security_guard');
        if (!$security_role) {
            add_role('security_guard', 'Guardia de Seguridad', array(
                'read' => true,
                'gestionar_camaras' => true,
                'ver_reportes' => true
            ));
        }

        // Capacidades para terapeutas (nuevo rol opcional)
        $therapist_role = get_role('therapist');
        if (!$therapist_role) {
            add_role('therapist', 'Terapeuta', array(
                'read' => true,
                'gestionar_sesiones' => true,
                'gestionar_psicodramas' => true,
                'gestionar_pacientes' => true,
                'gestionar_historial_medico' => true,
                'gestionar_seguimiento_terapeutico' => true,
                'ver_reportes' => true
            ));
        }

        // Capacidades para médicos (nuevo rol opcional)
        $doctor_role = get_role('doctor');
        if (!$doctor_role) {
            add_role('doctor', 'Médico', array(
                'read' => true,
                'gestionar_pacientes' => true,
                'gestionar_historial_medico' => true,
                'ver_reportes' => true
            ));
        }
    }
    
    private function initial_setup() {
        // Configuración por defecto
        $default_settings = array(
            'nombre_asociacion' => 'Nombre de la Asociación Civil',
            'rif' => '',
            'direccion' => '',
            'telefono' => '',
            'email' => '',
            'fecha_constitucion' => '',
            'numero_registro' => '',
            'miembros_por_pagina' => 20,
            'dias_recordatorio' => 7,
            'notificaciones_email' => true,
            'backup_automatico' => false,
            'modo_desinstalacion' => 'parcial',
            'camaras_habilitadas' => true,
            'psicodramas_habilitados' => true,
            'pacientes_habilitados' => true,
            'retencion_grabaciones' => 30,
            'retencion_historial_medico' => 365
        );
        
        // Solo crear la opción si no existe
        if (!get_option('asociacion_civil_settings')) {
            update_option('asociacion_civil_settings', $default_settings);
        }
        
        // Opciones adicionales
        $opciones = array(
            'ac_version_plugin' => ASOCIACION_CIVIL_PLUGIN_VERSION,
            'ac_fecha_activacion' => current_time('mysql'),
            'ac_configuracion_inicial' => true
        );
        
        foreach ($opciones as $key => $value) {
            if (!get_option($key)) {
                update_option($key, $value);
            }
        }
    }
    
    private function programar_eventos_cron() {
        if (!wp_next_scheduled('ac_backup_automatico')) {
            wp_schedule_event(time(), 'daily', 'ac_backup_automatico');
        }
        
        if (!wp_next_scheduled('ac_recordatorio_eventos')) {
            wp_schedule_event(time(), 'daily', 'ac_recordatorio_eventos');
        }
        
        if (!wp_next_scheduled('ac_limpieza_temporal')) {
            wp_schedule_event(time(), 'weekly', 'ac_limpieza_temporal');
        }
        
        if (!wp_next_scheduled('ac_reporte_mensual')) {
            wp_schedule_event(time(), 'monthly', 'ac_reporte_mensual');
        }
        
        // EVENTO CRON: Limpieza de grabaciones antiguas
        if (!wp_next_scheduled('ac_limpieza_grabaciones')) {
            wp_schedule_event(time(), 'daily', 'ac_limpieza_grabaciones');
        }

        // EVENTO CRON: Recordatorio de psicodramas
        if (!wp_next_scheduled('ac_recordatorio_psicodramas')) {
            wp_schedule_event(time(), 'daily', 'ac_recordatorio_psicodramas');
        }

        // EVENTO CRON: Recordatorio de citas médicas
        if (!wp_next_scheduled('ac_recordatorio_citas_medicas')) {
            wp_schedule_event(time(), 'daily', 'ac_recordatorio_citas_medicas');
        }

        // EVENTO CRON: Limpieza de historial médico antiguo
        if (!wp_next_scheduled('ac_limpieza_historial_medico')) {
            wp_schedule_event(time(), 'monthly', 'ac_limpieza_historial_medico');
        }
        
        // Registrar hooks para los eventos cron
        add_action('ac_backup_automatico', array($this, 'ejecutar_backup_automatico'));
        add_action('ac_recordatorio_eventos', array($this, 'enviar_recordatorios_eventos'));
        add_action('ac_limpieza_temporal', array($this, 'ejecutar_limpieza_temporal'));
        add_action('ac_reporte_mensual', array($this, 'generar_reporte_mensual'));
        add_action('ac_limpieza_grabaciones', array($this, 'limpiar_grabaciones_antiguas'));
        add_action('ac_recordatorio_psicodramas', array($this, 'enviar_recordatorios_psicodramas'));
        add_action('ac_recordatorio_citas_medicas', array($this, 'enviar_recordatorios_citas_medicas'));
        add_action('ac_limpieza_historial_medico', array($this, 'limpiar_historial_medico_antiguo'));
    }
    
    private function limpiar_eventos_cron() {
        $eventos = array(
            'ac_backup_automatico',
            'ac_recordatorio_eventos',
            'ac_limpieza_temporal',
            'ac_reporte_mensual',
            'ac_limpieza_grabaciones',
            'ac_recordatorio_psicodramas',
            'ac_recordatorio_citas_medicas',
            'ac_limpieza_historial_medico'
        );
        
        foreach ($eventos as $evento) {
            $timestamp = wp_next_scheduled($evento);
            if ($timestamp) {
                wp_unschedule_event($timestamp, $evento);
            }
        }
    }
    
    private function limpiar_cache_temporal() {
        // Limpiar transientes del plugin
        global $wpdb;
        $wpdb->query("
            DELETE FROM {$wpdb->options} 
            WHERE option_name LIKE '_transient_ac_%' 
            OR option_name LIKE '_transient_timeout_ac_%'
        ");
        
        // Limpiar cache de object cache si está activo
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }
    }
    
    private function registrar_activacion() {
        $log_entry = array(
            'fecha' => current_time('mysql'),
            'version' => ASOCIACION_CIVIL_PLUGIN_VERSION,
            'tipo' => 'activacion',
            'usuario' => get_current_user_id(),
            'sitio' => get_bloginfo('url')
        );
        
        $this->escribir_log($log_entry);
    }
    
    private function registrar_desactivacion() {
        $log_entry = array(
            'fecha' => current_time('mysql'),
            'version' => ASOCIACION_CIVIL_PLUGIN_VERSION,
            'tipo' => 'desactivacion',
            'usuario' => get_current_user_id(),
            'sitio' => get_bloginfo('url')
        );
        
        $this->escribir_log($log_entry);
    }
    
    private function verificar_actualizaciones() {
        $version_actual = get_option('ac_version_plugin', '1.0.0');
        
        if (version_compare($version_actual, ASOCIACION_CIVIL_PLUGIN_VERSION, '<')) {
            // Ejecutar rutinas de actualización
            $this->ejecutar_actualizaciones($version_actual);
            
            // Actualizar la versión en la base de datos
            update_option('ac_version_plugin', ASOCIACION_CIVIL_PLUGIN_VERSION);
            
            // Registrar la actualización
            $this->registrar_actualizacion($version_actual, ASOCIACION_CIVIL_PLUGIN_VERSION);
        }
    }
    
    private function ejecutar_actualizaciones($version_anterior) {
        // Aquí irían las rutinas específicas para cada versión
        if (version_compare($version_anterior, '1.1.0', '<')) {
            // Actualizaciones para la versión 1.1.0 - Agregar tabla de psicodramas
            $this->actualizar_a_v1_1_0();
        }
        
        if (version_compare($version_anterior, '1.2.0', '<')) {
            // Actualizaciones para la versión 1.2.0 - Agregar tablas de pacientes
            $this->actualizar_a_v1_2_0();
        }
        
        // Agregar más condiciones para futuras versiones
    }
    
    private function actualizar_a_v1_1_0() {
        // Cargar la clase Database manualmente
        require_once ASOCIACION_CIVIL_PLUGIN_PATH . 'includes/classes/Database.php';
        
        // Crear tablas de psicodramas usando la clase Database
        $database = new AsociacionCivil\Database();
        
        // La tabla de psicodramas ya se crea en el método create_tables()
        // Solo necesitamos asegurarnos de que exista
        $database->create_tables();
        
        error_log('Asociacion Civil: Actualizando a versión 1.1.0 - Tabla de psicodramas verificada');
    }

    private function actualizar_a_v1_2_0() {
        // Cargar la clase Database manualmente
        require_once ASOCIACION_CIVIL_PLUGIN_PATH . 'includes/classes/Database.php';
        
        // Crear tablas de pacientes usando la clase Database
        $database = new AsociacionCivil\Database();
        
        // Las tablas de pacientes ya se crean en el método create_tables()
        // Solo necesitamos asegurarnos de que existan
        $database->create_tables();
        
        error_log('Asociacion Civil: Actualizando a versión 1.2.0 - Tablas de pacientes verificadas');
    }
    
    private function registrar_actualizacion($de_version, $a_version) {
        $log_entry = array(
            'fecha' => current_time('mysql'),
            'de_version' => $de_version,
            'a_version' => $a_version,
            'tipo' => 'actualizacion',
            'usuario' => get_current_user_id()
        );
        
        $this->escribir_log($log_entry);
    }
    
    private function registrar_configuraciones() {
        register_setting('asociacion_civil_settings', 'asociacion_civil_settings', array(
            'type' => 'array',
            'description' => 'Configuración principal de la Asociación Civil',
            'sanitize_callback' => array($this, 'sanitizar_configuracion'),
            'default' => array()
        ));
    }
    
    public function sanitizar_configuracion($input) {
        $output = array();
        
        // Sanitizar cada campo
        if (isset($input['nombre_asociacion'])) {
            $output['nombre_asociacion'] = sanitize_text_field($input['nombre_asociacion']);
        }
        
        if (isset($input['rif'])) {
            $output['rif'] = sanitize_text_field($input['rif']);
        }
        
        if (isset($input['direccion'])) {
            $output['direccion'] = sanitize_textarea_field($input['direccion']);
        }
        
        if (isset($input['telefono'])) {
            $output['telefono'] = sanitize_text_field($input['telefono']);
        }
        
        if (isset($input['email'])) {
            $output['email'] = sanitize_email($input['email']);
        }
        
        if (isset($input['fecha_constitucion'])) {
            $output['fecha_constitucion'] = sanitize_text_field($input['fecha_constitucion']);
        }
        
        if (isset($input['numero_registro'])) {
            $output['numero_registro'] = sanitize_text_field($input['numero_registro']);
        }
        
        if (isset($input['miembros_por_pagina'])) {
            $output['miembros_por_pagina'] = absint($input['miembros_por_pagina']);
        }
        
        if (isset($input['dias_recordatorio'])) {
            $output['dias_recordatorio'] = absint($input['dias_recordatorio']);
        }
        
        if (isset($input['notificaciones_email'])) {
            $output['notificaciones_email'] = (bool) $input['notificaciones_email'];
        }
        
        if (isset($input['backup_automatico'])) {
            $output['backup_automatico'] = (bool) $input['backup_automatico'];
        }
        
        if (isset($input['modo_desinstalacion'])) {
            $output['modo_desinstalacion'] = in_array($input['modo_desinstalacion'], array('parcial', 'completa')) 
                ? $input['modo_desinstalacion'] 
                : 'parcial';
        }
        
        // CONFIGURACIONES PARA CÁMARAS
        if (isset($input['camaras_habilitadas'])) {
            $output['camaras_habilitadas'] = (bool) $input['camaras_habilitadas'];
        }
        
        if (isset($input['retencion_grabaciones'])) {
            $output['retencion_grabaciones'] = absint($input['retencion_grabaciones']);
        }

        // CONFIGURACIONES PARA PSICODRAMAS
        if (isset($input['psicodramas_habilitados'])) {
            $output['psicodramas_habilitados'] = (bool) $input['psicodramas_habilitados'];
        }
        
        if (isset($input['duracion_default_psicodrama'])) {
            $output['duracion_default_psicodrama'] = absint($input['duracion_default_psicodrama']);
        }

        // CONFIGURACIONES PARA PACIENTES
        if (isset($input['pacientes_habilitados'])) {
            $output['pacientes_habilitados'] = (bool) $input['pacientes_habilitados'];
        }
        
        if (isset($input['retencion_historial_medico'])) {
            $output['retencion_historial_medico'] = absint($input['retencion_historial_medico']);
        }
        
        return $output;
    }
    
    public function agregar_enlaces_plugin($links) {
        $enlaces = array(
            'dashboard' => sprintf(
                '<a href="%s">Dashboard</a>',
                admin_url('admin.php?page=ac-dashboard')
            ),
            'configuracion' => sprintf(
                '<a href="%s">Configuración</a>',
                admin_url('admin.php?page=ac-configuracion')
            )
        );
        
        return array_merge($enlaces, $links);
    }
    
    public function agregar_meta_enlaces_plugin($links, $file) {
        if ($file === ASOCIACION_CIVIL_PLUGIN_BASENAME) {
            $nuevos_links = array(
                'documentacion' => '<a href="https://ejemplo.com/documentacion" target="_blank">Documentación</a>',
                'soporte' => '<a href="https://ejemplo.com/soporte" target="_blank">Soporte</a>'
            );
            
            return array_merge($links, $nuevos_links);
        }
        
        return $links;
    }
    
    // Métodos para eventos cron
    public function ejecutar_backup_automatico() {
        if (!get_option('ac_backup_automatico', false)) {
            return;
        }
        
        // Lógica de backup automático
        $this->generar_backup();
    }
    
    public function enviar_recordatorios_eventos() {
        if (!get_option('ac_notificaciones_email', true)) {
            return;
        }
        
        // Lógica de recordatorios de eventos
        $this->enviar_recordatorios();
    }
    
    public function ejecutar_limpieza_temporal() {
        // Lógica de limpieza de archivos temporales
        $this->limpiar_archivos_temporales();
    }
    
    public function generar_reporte_mensual() {
        // Lógica de generación de reporte mensual
        $this->enviar_reporte_mensual();
    }
    
    // MÉTODO: Limpiar grabaciones antiguas
    public function limpiar_grabaciones_antiguas() {
        $config = get_option('asociacion_civil_settings', array());
        $dias_retencion = isset($config['retencion_grabaciones']) ? $config['retencion_grabaciones'] : 30;
        
        if ($dias_retencion > 0) {
            $fecha_limite = date('Y-m-d H:i:s', strtotime("-{$dias_retencion} days"));
            
            global $wpdb;
            $resultado = $wpdb->query(
                $wpdb->prepare("
                    DELETE FROM {$wpdb->prefix}ac_registros_camaras 
                    WHERE fecha_evento < %s
                ", $fecha_limite)
            );
            
            if ($resultado !== false) {
                error_log("Asociacion Civil: Limpieza de grabaciones - {$resultado} registros eliminados");
            }
        }
    }

    // MÉTODO: Recordatorios de psicodramas
    public function enviar_recordatorios_psicodramas() {
        if (!get_option('ac_notificaciones_email', true)) {
            return;
        }
        
        // Lógica de recordatorios para próximos psicodramas
        $this->enviar_recordatorios_psicodrama();
    }

    // MÉTODO: Recordatorios de citas médicas
    public function enviar_recordatorios_citas_medicas() {
        if (!get_option('ac_notificaciones_email', true)) {
            return;
        }
        
        // Lógica de recordatorios para próximas citas médicas
        $this->enviar_recordatorios_citas();
    }

    // MÉTODO: Limpieza de historial médico antiguo
    public function limpiar_historial_medico_antiguo() {
        $config = get_option('asociacion_civil_settings', array());
        $dias_retencion = isset($config['retencion_historial_medico']) ? $config['retencion_historial_medico'] : 365;
        
        if ($dias_retencion > 0) {
            $fecha_limite = date('Y-m-d', strtotime("-{$dias_retencion} days"));
            
            global $wpdb;
            $resultado = $wpdb->query(
                $wpdb->prepare("
                    DELETE FROM {$wpdb->prefix}ac_historial_medico 
                    WHERE fecha_consulta < %s
                ", $fecha_limite)
            );
            
            if ($resultado !== false) {
                error_log("Asociacion Civil: Limpieza de historial médico - {$resultado} registros eliminados");
            }
        }
    }
    
    private function generar_backup() {
        // Implementar lógica de backup
        error_log('Asociacion Civil: Ejecutando backup automático');
    }
    
    private function enviar_recordatorios() {
        // Implementar lógica de recordatorios
        error_log('Asociacion Civil: Enviando recordatorios de eventos');
    }
    
    private function limpiar_archivos_temporales() {
        // Implementar lógica de limpieza
        error_log('Asociacion Civil: Limpiando archivos temporales');
    }
    
    private function enviar_reporte_mensual() {
        // Implementar lógica de reporte mensual
        error_log('Asociacion Civil: Generando reporte mensual');
    }

    private function enviar_recordatorios_psicodrama() {
        // Implementar lógica de recordatorios para psicodramas
        error_log('Asociacion Civil: Enviando recordatorios de psicodramas');
    }

    private function enviar_recordatorios_citas() {
        // Implementar lógica de recordatorios para citas médicas
        error_log('Asociacion Civil: Enviando recordatorios de citas médicas');
    }
    
    private function escribir_log($entry) {
        $log_file = WP_CONTENT_DIR . '/logs/asociacion-civil.log';
        $log_dir = dirname($log_file);
        
        // Crear directorio si no existe
        if (!file_exists($log_dir)) {
            wp_mkdir_p($log_dir);
        }
        
        // Formatear la entrada del log
        $timestamp = current_time('mysql');
        $message = "[" . $timestamp . "] " . json_encode($entry) . PHP_EOL;
        
        // Escribir en el archivo de log
        file_put_contents($log_file, $message, FILE_APPEND | LOCK_EX);
    }
    
    // Métodos públicos para acceso externo
    public function get_database() {
        return $this->database;
    }
    
    public function get_admin() {
        return $this->admin;
    }
    
    public function get_dashboard() {
        return $this->dashboard;
    }
    
    public static function get_plugin_info() {
        $plugin = self::getInstance();
        
        // Verificar funciones de campos
        $funciones_campos = array(
            'psicodramas' => function_exists('ac_definir_campos_psicodrama'),
            'sesiones' => function_exists('ac_definir_campos_sesion_psicologica'),
            'pacientes' => function_exists('ac_definir_campos_paciente'),
            'judiciales' => function_exists('ac_definir_campos_nota_judicial'),
            'historial' => function_exists('ac_definir_campos_historial_medico'),
            'miembros' => function_exists('ac_definir_campos_miembro'),
            'seguimiento' => function_exists('ac_definir_campos_seguimiento_terapeutico'),
            'documentos' => function_exists('ac_definir_campos_documento')
        );
        
        return array(
            'version' => ASOCIACION_CIVIL_PLUGIN_VERSION,
            'path' => ASOCIACION_CIVIL_PLUGIN_PATH,
            'url' => ASOCIACION_CIVIL_PLUGIN_URL,
            'basename' => ASOCIACION_CIVIL_PLUGIN_BASENAME,
            'clases_cargadas' => array(
                'Database' => ($plugin->database instanceof AsociacionCivil\Database),
                'Admin' => ($plugin->admin instanceof AsociacionCivil\Admin),
                'Dashboard' => ($plugin->dashboard instanceof AsociacionCivil\Dashboard),
                'Acta' => class_exists('AsociacionCivil\Acta'),
                'SesionPsicologica' => class_exists('AsociacionCivil\SesionPsicologica'),
                'CamaraSeguridad' => class_exists('AsociacionCivil\CamaraSeguridad'),
                'RegistroCamara' => class_exists('AsociacionCivil\RegistroCamara'),
                'Psicodrama' => class_exists('AsociacionCivil\Psicodrama'),
                'Paciente' => class_exists('AsociacionCivil\Paciente'),
                'HistorialMedico' => class_exists('AsociacionCivil\HistorialMedico'),
                'SeguimientoTerapeutico' => class_exists('AsociacionCivil\SeguimientoTerapeutico')
            ),
            'sistema_campos' => array(
                'clasificador_cargado' => class_exists('ClasificadorContenido'),
                'funciones_campos' => $funciones_campos,
                'total_funciones' => count(array_filter($funciones_campos))
            ),
            'sistema_actas' => array(
                'core_cargado' => function_exists('ac_ajax_registro_masivo_faltantes'),
                'ui_cargado' => function_exists('ac_sistema_integrado'),
                'ruta_core' => ASOCIACION_CIVIL_LIBRO_ACTAS_PATH . 'libro-actas-core.php',
                'existe_core' => file_exists(ASOCIACION_CIVIL_LIBRO_ACTAS_PATH . 'libro-actas-core.php'),
                'existe_ui' => file_exists(ASOCIACION_CIVIL_LIBRO_ACTAS_PATH . 'libro-actas-ui.php')
            )
        );
    }
}

// Inicializar el plugin
function asociacion_civil_init() {
    return AsociacionCivilPlugin::getInstance();
}

// Punto de entrada principal
add_action('plugins_loaded', 'asociacion_civil_init', 0);

// Hook para activación multisitio
if (is_multisite()) {
    add_action('wp_initialize_site', function($new_site) {
        switch_to_blog($new_site->blog_id);
        $plugin = new AsociacionCivilPlugin();
        $plugin->activate();
        restore_current_blog();
    });
}

// Funciones de ayuda globales
if (!function_exists('ac_log')) {
    function ac_log($message, $level = 'info') {
        $plugin = AsociacionCivilPlugin::getInstance();
        $timestamp = current_time('mysql');
        $log_entry = array(
            'level' => $level,
            'message' => $message,
            'timestamp' => $timestamp
        );
        
        $plugin->escribir_log($log_entry);
    }
}

if (!function_exists('ac_get_config')) {
    function ac_get_config($key = null, $default = null) {
        $config = get_option('asociacion_civil_settings', array());
        
        if ($key === null) {
            return $config;
        }
        
        return isset($config[$key]) ? $config[$key] : $default;
    }
}

// Funciones globales para el sistema de campos y clasificador
if (!function_exists('ac_obtener_campos_por_tipo')) {
    function ac_obtener_campos_por_tipo($tipo) {
        $funciones_campos = array(
            'psicodramas' => 'ac_definir_campos_psicodrama',
            'sesiones-psicologicas' => 'ac_definir_campos_sesion_psicologica',
            'pacientes' => 'ac_definir_campos_paciente',
            'notas-judiciales' => 'ac_definir_campos_nota_judicial',
            'historial-medico' => 'ac_definir_campos_historial_medico',
            'miembros' => 'ac_definir_campos_miembro',
            'seguimiento-terapeutico' => 'ac_definir_campos_seguimiento_terapeutico',
            'documentos' => 'ac_definir_campos_documento'
        );
        
        if (isset($funciones_campos[$tipo]) && function_exists($funciones_campos[$tipo])) {
            return call_user_func($funciones_campos[$tipo]);
        }
        
        return array();
    }
}

if (!function_exists('ac_generar_formulario_campos')) {
    function ac_generar_formulario_campos($tipo, $valores = array()) {
        $campos = ac_obtener_campos_por_tipo($tipo);
        
        if (empty($campos)) {
            return '<p>No hay campos definidos para este tipo de contenido.</p>';
        }
        
        $html = '';
        
        foreach ($campos as $clave => $config) {
            $valor = isset($valores[$clave]) ? $valores[$clave] : '';
            $requerido = isset($config['required']) && $config['required'] ? 'required' : '';
            $etiqueta = isset($config['label']) ? $config['label'] : $clave;
            
            $html .= '<div class="form-field">';
            $html .= '<label for="' . esc_attr($clave) . '">' . esc_html($etiqueta) . '</label>';
            
            switch ($config['type']) {
                case 'text':
                case 'date':
                case 'time':
                case 'email':
                case 'tel':
                case 'number':
                    $html .= '<input type="' . esc_attr($config['type']) . '" id="' . esc_attr($clave) . '" name="' . esc_attr($clave) . '" value="' . esc_attr($valor) . '" ' . $requerido . ' class="regular-text">';
                    break;
                    
                case 'textarea':
                    $html .= '<textarea id="' . esc_attr($clave) . '" name="' . esc_attr($clave) . '" ' . $requerido . ' class="large-text" rows="5">' . esc_textarea($valor) . '</textarea>';
                    break;
                    
                case 'select':
                    $html .= '<select id="' . esc_attr($clave) . '" name="' . esc_attr($clave) . '" ' . $requerido . ' class="regular-text">';
                    $html .= '<option value="">Seleccionar...</option>';
                    if (isset($config['options'])) {
                        foreach ($config['options'] as $valor_opcion => $etiqueta_opcion) {
                            $selected = ($valor == $valor_opcion) ? 'selected' : '';
                            $html .= '<option value="' . esc_attr($valor_opcion) . '" ' . $selected . '>' . esc_html($etiqueta_opcion) . '</option>';
                        }
                    }
                    $html .= '</select>';
                    break;
                    
                case 'checkbox':
                    if (isset($config['options'])) {
                        foreach ($config['options'] as $valor_opcion => $etiqueta_opcion) {
                            $checked = is_array($valor) && in_array($valor_opcion, $valor) ? 'checked' : '';
                            $html .= '<label class="checkbox-label">';
                            $html .= '<input type="checkbox" name="' . esc_attr($clave) . '[]" value="' . esc_attr($valor_opcion) . '" ' . $checked . '> ' . esc_html($etiqueta_opcion);
                            $html .= '</label><br>';
                        }
                    }
                    break;
                    
                default:
                    $html .= '<input type="text" id="' . esc_attr($clave) . '" name="' . esc_attr($clave) . '" value="' . esc_attr($valor) . '" ' . $requerido . ' class="regular-text">';
                    break;
            }
            
            $html .= '</div>';
        }
        
        return $html;
    }
}

if (!function_exists('ac_procesar_ocr_y_clasificar')) {
    function ac_procesar_ocr_y_clasificar($texto_ocr) {
        if (class_exists('ClasificadorContenido')) {
            return ClasificadorContenido::procesarOCRyRedirigir($texto_ocr);
        }
        return false;
    }
}

if (!function_exists('ac_obtener_url_destino')) {
    function ac_obtener_url_destino($template, $texto_extraido = '') {
        if (class_exists('ClasificadorContenido')) {
            return ClasificadorContenido::obtenerUrlDestino($template, $texto_extraido);
        }
        return admin_url('admin.php?page=ac-dashboard');
    }
}

// Debug function para verificar que el plugin se está cargando
if (!function_exists('ac_debug_check')) {
    function ac_debug_check() {
        if (defined('WP_DEBUG') && WP_DEBUG && current_user_can('manage_options')) {
            add_action('admin_notices', function() {
                $plugin_info = AsociacionCivilPlugin::get_plugin_info();
                
                $status = array();
                $status[] = 'Plugin cargado: ✅';
                
                // Estado de clases principales
                foreach ($plugin_info['clases_cargadas'] as $clase => $cargada) {
                    $status[] = "Clase {$clase}: " . ($cargada ? '✅' : '❌');
                }
                
                // Estado del sistema de campos
                $status[] = 'Clasificador: ' . ($plugin_info['sistema_campos']['clasificador_cargado'] ? '✅' : '❌');
                $status[] = 'Funciones campos: ' . $plugin_info['sistema_campos']['total_funciones'] . '/8';
                
                // Estado del sistema de actas
                $status[] = 'Sistema Actas Core: ' . ($plugin_info['sistema_actas']['core_cargado'] ? '✅' : '❌');
                $status[] = 'Sistema Actas UI: ' . ($plugin_info['sistema_actas']['ui_cargado'] ? '✅' : '❌');
                $status[] = 'Archivo Core existe: ' . ($plugin_info['sistema_actas']['existe_core'] ? '✅' : '❌');
                $status[] = 'Archivo UI existe: ' . ($plugin_info['sistema_actas']['existe_ui'] ? '✅' : '❌');
                
                echo '<div class="notice notice-warning"><p><strong>Debug Asociación Civil:</strong> ' . 
                     implode(' | ', $status) . '</p></div>';
            });
        }
    }
    add_action('admin_init', 'ac_debug_check');
}

// Debug mejorado para el menú
add_action('admin_init', 'ac_debug_menu_completo');

function ac_debug_menu_completo() {
    if (isset($_GET['debug_ac_menu']) && current_user_can('manage_options')) {
        global $menu, $submenu;
        
        echo '<div class="notice notice-info">';
        echo '<h3>🔧 Debug Completo - Menú Asociación Civil</h3>';
        
        // Verificar menú principal
        $menu_principal = false;
        foreach ($menu as $item) {
            if (isset($item[2]) && $item[2] === 'ac-dashboard') {
                $menu_principal = true;
                break;
            }
        }
        
        echo '<p><strong>Menú principal existe:</strong> ' . ($menu_principal ? '✅ SÍ' : '❌ NO') . '</p>';
        
        // Verificar submenús
        if (isset($submenu['ac-dashboard'])) {
            echo '<p><strong>Submenús encontrados (' . count($submenu['ac-dashboard']) . '):</strong></p>';
            echo '<ul>';
            foreach ($submenu['ac-dashboard'] as $subitem) {
                echo '<li>' . $subitem[0] . ' → ' . $subitem[2] . ' → ✅</li>';
            }
            echo '</ul>';
        } else {
            echo '<p><strong>Submenús:</strong> ❌ NO HAY SUBMENÚS REGISTRADOS</p>';
        }
        
        echo '</div>';
    }
}

// Agregar link de debug en el admin
add_action('admin_notices', 'ac_mostrar_debug_menu_link');

function ac_mostrar_debug_menu_link() {
    if (current_user_can('manage_options') && !isset($_GET['debug_ac_menu'])) {
        $current_screen = get_current_screen();
        if (strpos($current_screen->base, 'ac-') === 0) {
            echo '<div class="notice notice-warning">';
            echo '<p><strong>Asociación Civil:</strong> <a href="' . add_query_arg('debug_ac_menu', '1') . '">🔧 Debuggear Menú</a></p>';
            echo '</div>';
        }
    }
}

// Debug específico para el sistema de actas
add_action('admin_init', function() {
    if (isset($_GET['debug_ac_sistema_actas']) && current_user_can('manage_options')) {
        echo '<div class="notice notice-info">';
        echo '<h3>🔧 Debug - Sistema de Libro de Actas</h3>';
        
        // Verificar archivos
        $archivos = array(
            'Libro Actas Core' => ASOCIACION_CIVIL_LIBRO_ACTAS_PATH . 'libro-actas-core.php',
            'Libro Actas UI' => ASOCIACION_CIVIL_LIBRO_ACTAS_PATH . 'libro-actas-ui.php'
        );
        
        foreach ($archivos as $nombre => $ruta) {
            echo '<p><strong>' . $nombre . ':</strong> ';
            if (file_exists($ruta)) {
                echo '✅ EXISTE en ' . $ruta . '<br>';
                
                // Cargar y verificar funciones
                if ($nombre === 'Libro Actas Core') {
                    require_once $ruta;
                    $funciones = array(
                        'ac_ajax_registro_masivo_faltantes',
                        'ac_manejar_sincronizacion_actas_ajax',
                        'ac_verificar_actividades_faltantes'
                    );
                    
                    foreach ($funciones as $funcion) {
                        echo '• ' . $funcion . ': ' . 
                            (function_exists($funcion) ? '✅ DISPONIBLE' : '❌ NO DISPONIBLE') . '<br>';
                    }
                }
            } else {
                echo '❌ NO EXISTE en ' . $ruta;
            }
            echo '</p>';
        }
        
        // Verificar handlers AJAX registrados
        echo '<p><strong>Handlers AJAX registrados:</strong><br>';
        echo '• ac_registro_masivo_faltantes: ' . 
            (has_action('wp_ajax_ac_registro_masivo_faltantes') ? '✅ REGISTRADO' : '❌ NO REGISTRADO') . '<br>';
        echo '• ac_sincronizar_actas: ' . 
            (has_action('wp_ajax_ac_sincronizar_actas') ? '✅ REGISTRADO' : '❌ NO REGISTRADO');
        echo '</p>';
        
        echo '</div>';
    }
});

// Agregar link de debug del sistema de actas
add_action('admin_notices', function() {
    if (current_user_can('manage_options') && !isset($_GET['debug_ac_sistema_actas'])) {
        $current_screen = get_current_screen();
        if (strpos($current_screen->base, 'ac-') === 0) {
            echo '<div class="notice notice-warning">';
            echo '<p><strong>Sistema de Actas:</strong> <a href="' . add_query_arg('debug_ac_sistema_actas', '1') . '">🔍 Debuggear Sistema de Actas</a></p>';
            echo '</div>';
        }
    }
});