<?php
// Evitar el acceso directo al archivo
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Agregar un submenú en la sección "Usuarios"
function mi_plugin_agregar_submenu_usuarios() {
    add_users_page(
        __( 'Actualizar Metadatos', 'mi_plugin' ), // Título de la página
        __( 'Actualizar Metadatos', 'mi_plugin' ), // Nombre en el menú
        'manage_options',                          // Capacidad requerida
        'actualizar-metadatos',                    // Slug del submenú
        'mi_plugin_pagina_actualizar_metadatos'    // Función para mostrar el contenido
    );
}
add_action( 'admin_menu', 'mi_plugin_agregar_submenu_usuarios' );

// Contenido de la página de sincronización
function mi_plugin_pagina_actualizar_metadatos() {
    // Procesar la acción de sincronización si se ha enviado el formulario
    if ( isset( $_POST['sincronizar_metadatos'] ) ) {
        $usuarios = get_users();
        $contador_actualizados = 0;

        foreach ( $usuarios as $usuario ) {
            $first_name = get_user_meta( $usuario->ID, 'first_name', true );
            $last_name = get_user_meta( $usuario->ID, 'last_name', true );

            if ( empty( get_user_meta( $usuario->ID, 'billing_first_name', true ) ) && ! empty( $first_name ) ) {
                update_user_meta( $usuario->ID, 'billing_first_name', $first_name );
                $contador_actualizados++;
            }

            if ( empty( get_user_meta( $usuario->ID, 'billing_last_name', true ) ) && ! empty( $last_name ) ) {
                update_user_meta( $usuario->ID, 'billing_last_name', $last_name );
                $contador_actualizados++;
            }
        }

        // Mostrar mensaje de éxito
        echo '<div class="updated notice is-dismissible"><p>' . sprintf( __( '%d usuarios actualizados correctamente.', 'mi_plugin' ), $contador_actualizados ) . '</p></div>';
    }

    // Mostrar el formulario
    ?>
    <div class="wrap">
        <h1><?php _e( 'Actualizar Metadatos de Usuarios', 'mi_plugin' ); ?></h1>
        <form method="post">
            <p><?php _e( 'Haga clic en el botón para sincronizar los nombres y apellidos con los campos de facturación de los usuarios existentes.', 'mi_plugin' ); ?></p>
            <input type="hidden" name="sincronizar_metadatos" value="1" />
            <input type="submit" class="button button-primary" value="<?php _e( 'Sincronizar Metadatos', 'mi_plugin' ); ?>" />
        </form>
    </div>
    <?php
}