<?php
/*
Plugin Name: AccessWork Registro Personalizado
Description: Añade campos personalizados de registro editables a tu comercio electrónico
Version: 2.4
Author: Accesswork 
*/


//ESTA ES LA VERSIÓN 1.1 DE EL PLUGIN DE REGISTRO PEDIDO POR PULPO Y  HECHO POR ACCESSWORK | IAMNOTSUREWHOIAM {( DEVELOPER NAME )}
//ALGUNOS COMENTARIOS O TIPS PROVISTOS POR EL DEVELOPER PARA EVITAR CUALQUIER TIPO DE PROBLEMAS EN CUANTO A ATAQUES ACERCA DEL MISMO:
//TODAS LAS LINEAS ESTÁN SANITIZADAS, A PRUEBA DE ATAQUES XSS, GPTRL Y SQL INJECTION, ÚNICO DETALLE VISTO POR EL DEVELOPER: 
// EL REGISTRO PREDEFINIDO POR WOOCOMMERCE RELACIONADO CON EL INGRESO DEL EMAIL NO ESTÁ SANITIZADO NI ASEGURADO.
//SOLUCIÓN: SE ENCUENTRAN PLUGINS PARA EVITAR CUALQUIER TIPO DE PROBLEMA EN CUANTO ATAQUES O INTENTOS DE INGRESOS A EL SISTEMA
//SIN MÁS QUE DECIR. DEJO MI PLUGIN LISTA ESTA VERSIÓN PARA INICIALIZAR LA PRUEBA EN LOS SITIOS COMERCIALES.



/*
FIX PARA LA VERSIÓN 1.2 | IAMNOTSUREWHOIAM {( DEVELOPER NAME )}
SE ACOMODARON Y ORDENARON LOS CAMPOS, ADEMÁS DE AGREGARSE EL Provincia AL REGISTRO Y A LA EDICIÓN.
SIN MAS QUE DECIR, CIERRO ESTA VERSIÓN
*/


/*
FIX PARA LA VERSIÓN 1.5 | IAMNOTSUREWHOIAM {( DEVELOPER NAME )}
SE MEJORÓ EL PANEL DE WORDPRESS, SE CAMBIO EL DNI Y SOLO SE DEJO EL CUIT, SE CAMBIARON LOS TIPOS DE IVA, SE AGREGÓ UN INPUT
QUE CORROBORA LAS COINCIDENCIAS DE LAS CONTRASEÑAS.

SE PUEDE AÑADIR ACENTOS EN LOS INPUTS DE REGISTRO
*/

/*
FIX PARA LA VERSIÓN 1.6 | IAMNOTSUREWHOIAM {( DEVELOPER NAME )}
SE AGREGO EL SHIPPING A TODOS LOS CAMPOS

SE UTILIZO DE TEST **
*/


/*
FIX PARA LA VERSIÓN 1.7 | IAMNOTSUREWHOIAM {( DEVELOPER NAME )}
SE AGREGO EL SHIPPING A TODOS LOS CAMPOS

FUNCIONAL.
*/


/*
FIX PARA LA VERSIÓN 2.0 | IAMNOTSUREWHOIAM {( DEVELOPER NAME )}
CAMBIOS SIGNIFICATIVOS EN EL REGISTRO AGREGANDO PROVINCIAS FORZANDO QUE SEA ARGENTINA EL PAIS
AGREGUE EL BOTON DE ACTUALIZAR METADATOS EN USUARIOS

FUNCIONAL.
*/


/*
FIX PARA LA VERSIÓN 2.2 | IAMNOTSUREWHOIAM {( DEVELOPER NAME )}

CAMBIOS EN TIPO DE IVA SEGÚN SELECCIÓN

TRES PRIMEROS ----> CUIT 11 DIGITOS
CONSUMIDOR FINAL ---> CUIL 11 DIGITOS

FUNCIONAL.
*/


// Evitar el acceso directo a este archivo
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Sale del script si no se está ejecutando dentro de WordPress
}


include_once( plugin_dir_path( __FILE__ ) . 'backview.php' );



// Añadir el campo de confirmación de contraseña al formulario de registro
function agregar_campo_confirmar_contrasena_woocommerce() {
    wp_nonce_field( 'woocommerce_register_action', 'woocommerce_register_nonce' );
    ?>
    <p class="form-row form-row-wide">
        <label for="reg_confirm_password"><?php _e( 'Confirmar Contraseña', 'woocommerce' ); ?> <span class="required">*</span></label>
        <input type="password" class="input-text" name="reg_confirm_password" id="reg_confirm_password" value="" />
    </p>
    <?php
}
add_action( 'woocommerce_register_form', 'agregar_campo_confirmar_contrasena_woocommerce' );

// Validar que las contraseñas coincidan al registrar un nuevo usuario
function validar_confirmar_contrasena_woocommerce( $validation_errors, $username, $email ) {
    // Verificar nonce para protección CSRF
    if ( ! isset( $_POST['woocommerce_register_nonce'] ) || ! wp_verify_nonce( $_POST['woocommerce_register_nonce'], 'woocommerce_register_action' ) ) {
        $validation_errors->add( 'security_error', __( 'Error de seguridad, por favor intente nuevamente.', 'woocommerce' ) );
        return $validation_errors;
    }

    // Validar las contraseñas
    if ( isset( $_POST['password'] ) && isset( $_POST['reg_confirm_password'] ) ) {
        $password = $_POST['password'];
        $confirm_password = $_POST['reg_confirm_password'];

        // Verificar si las contraseñas coinciden
        if ( $password !== $confirm_password ) {
            $validation_errors->add( 'password_mismatch_error', __( 'Las contraseñas no coinciden. Por favor, intente nuevamente.', 'woocommerce' ) );
        }
    } else {
        $validation_errors->add( 'password_error', __( 'Por favor, ingrese una contraseña y su confirmación.', 'woocommerce' ) );
    }

    return $validation_errors;
}
add_filter( 'woocommerce_registration_errors', 'validar_confirmar_contrasena_woocommerce', 10, 3 );
// 1. Añadir el campo combinado de Nombre y Apellido al formulario de registro de WooCommerce
function agregar_campo_nombre_apellido_combinado_woocommerce() {
    wp_nonce_field( 'woocommerce_register_action', 'woocommerce_register_nonce' );
    ?>
    <p class="form-row form-row-wide">
        <label for="full_name"><?php _e( 'Nombre y Apellido', 'woocommerce' ); ?> <span class="required">*</span></label>
        <input type="text" class="input-text" name="full_name" id="full_name" value="<?php if ( ! empty( $_POST['full_name'] ) ) echo esc_attr( wp_unslash( $_POST['full_name'] ) ); ?>" maxlength="200" />
    </p>
    <script type="text/javascript">
        document.getElementById('full_name').addEventListener('input', function(e) {
            var input = e.target.value;
            input = input.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, ''); // Solo letras y espacios
            if (input.length > 200) {
                input = input.substring(0, 200);
            }
            e.target.value = input;
        });
    </script>
    <?php
}
add_action( 'woocommerce_register_form', 'agregar_campo_nombre_apellido_combinado_woocommerce' );

// 2. Validar el campo combinado de Nombre y Apellido durante el registro
function validar_nombre_apellido_combinado_woocommerce( $validation_errors, $username, $email ) {
    if ( ! isset( $_POST['woocommerce_register_nonce'] ) || ! wp_verify_nonce( $_POST['woocommerce_register_nonce'], 'woocommerce_register_action' ) ) {
        $validation_errors->add( 'security_error', __( 'Error de seguridad, por favor intente nuevamente.', 'woocommerce' ) );
        return $validation_errors;
    }

    if ( ! empty( $_POST['full_name'] ) ) {
        $full_name = sanitize_text_field( $_POST['full_name'] );
        if ( strlen( $full_name ) > 200 ) {
            $validation_errors->add( 'full_name_error', __( 'El nombre y apellido no pueden tener más de 200 caracteres.', 'woocommerce' ) );
        }
        if ( ! preg_match( '/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/', $full_name ) ) {
            $validation_errors->add( 'full_name_error', __( 'El nombre y apellido solo pueden contener letras, espacios y caracteres acentuados.', 'woocommerce' ) );
        }
    } else {
        $validation_errors->add( 'full_name_error', __( 'Por favor, ingresa tu nombre y apellido.', 'woocommerce' ) );
    }

    return $validation_errors;
}
add_filter( 'woocommerce_registration_errors', 'validar_nombre_apellido_combinado_woocommerce', 10, 3 );

// 3. Guardar los campos Nombre y Apellido combinados en el perfil del usuario
function guardar_nombre_apellido_combinado_woocommerce( $customer_id ) {
    if ( isset( $_POST['woocommerce_register_nonce'] ) && wp_verify_nonce( $_POST['woocommerce_register_nonce'], 'woocommerce_register_action' ) ) {
        if ( isset( $_POST['full_name'] ) ) {
            $full_name = sanitize_text_field( $_POST['full_name'] );
            $name_parts = explode( ' ', $full_name, 2 );
            $first_name = $name_parts[0];
            $last_name = isset( $name_parts[1] ) ? $name_parts[1] : '';

            update_user_meta( $customer_id, 'first_name', $first_name );
            update_user_meta( $customer_id, 'last_name', $last_name );
            update_user_meta( $customer_id, 'billing_first_name', $first_name );
            update_user_meta( $customer_id, 'billing_last_name', $last_name );
            update_user_meta( $customer_id, 'shipping_first_name', $first_name );
            update_user_meta( $customer_id, 'shipping_last_name', $last_name );
        }
    }
}
add_action( 'woocommerce_created_customer', 'guardar_nombre_apellido_combinado_woocommerce' );

// 4. Mostrar el nombre completo en los campos de facturación en el checkout
add_filter( 'woocommerce_checkout_fields', 'sincronizar_datos_nombre_apellido_checkout' );
function sincronizar_datos_nombre_apellido_checkout( $fields ) {
    $user_id = get_current_user_id();
    if ( $user_id ) {
        $first_name = get_user_meta( $user_id, 'first_name', true );
        $last_name = get_user_meta( $user_id, 'last_name', true );

        if ( empty( $first_name ) ) {
            $first_name = get_user_meta( $user_id, 'billing_first_name', true );
        }
        if ( empty( $last_name ) ) {
            $last_name = get_user_meta( $user_id, 'billing_last_name', true );
        }

        $fields['billing']['billing_first_name']['default'] = $first_name;
        $fields['billing']['billing_last_name']['default'] = $last_name;
    }
    return $fields;
}

// 5. Actualizar los datos de usuario al finalizar el checkout
add_action( 'woocommerce_checkout_update_user_meta', 'actualizar_datos_nombre_apellido_checkout', 10, 2 );
function actualizar_datos_nombre_apellido_checkout( $customer_id, $posted ) {
    if ( isset( $posted['billing_first_name'] ) ) {
        update_user_meta( $customer_id, 'first_name', sanitize_text_field( $posted['billing_first_name'] ) );
        update_user_meta( $customer_id, 'billing_first_name', sanitize_text_field( $posted['billing_first_name'] ) );
    }
    if ( isset( $posted['billing_last_name'] ) ) {
        update_user_meta( $customer_id, 'last_name', sanitize_text_field( $posted['billing_last_name'] ) );
        update_user_meta( $customer_id, 'billing_last_name', sanitize_text_field( $posted['billing_last_name'] ) );
    }
}

// 6. Sincronizar datos para usuarios existentes en la activación del plugin o en un momento definido
function sincronizar_usuarios_existentes() {
    $users = get_users();
    foreach ( $users as $user ) {
        $first_name = get_user_meta( $user->ID, 'first_name', true );
        $last_name = get_user_meta( $user->ID, 'last_name', true );

        if ( empty( $first_name ) || empty( $last_name ) ) {
            $billing_first_name = get_user_meta( $user->ID, 'billing_first_name', true );
            $billing_last_name = get_user_meta( $user->ID, 'billing_last_name', true );

            if ( ! empty( $billing_first_name ) ) {
                update_user_meta( $user->ID, 'first_name', $billing_first_name );
            }
            if ( ! empty( $billing_last_name ) ) {
                update_user_meta( $user->ID, 'last_name', $billing_last_name );
            }
        }
    }
}
add_action( 'init', 'sincronizar_usuarios_existentes' );


// 1. Añadir el campo combinado al formulario de registro de WooCommerce
function agregar_campo_nombre_comercial_empresa_woocommerce() {
    wp_nonce_field( 'woocommerce_register_action', 'woocommerce_register_nonce' );
    ?>
    <p class="form-row form-row-wide">
        <label for="company"><?php _e( 'Nombre Comercial', 'woocommerce' ); ?> <span class="required">*</span></label>
        <input type="text" class="input-text" name="company" id="company" value="<?php if ( ! empty( $_POST['company'] ) ) echo esc_attr( wp_unslash( $_POST['company'] ) ); ?>" maxlength="200" />
    </p>
    <script type="text/javascript">
        document.getElementById('company').addEventListener('input', function(e) {
            var input = e.target.value;
            input = input.replace(/[^a-zA-Z0-9áéíóúÁÉÍÓÚñÑ\s]/g, ''); // Solo letras, números y espacios
            if (input.length > 200) {
                input = input.substring(0, 200);
            }
            e.target.value = input;
        });
    </script>
    <?php
}
add_action( 'woocommerce_register_form', 'agregar_campo_nombre_comercial_empresa_woocommerce' );

// 2. Validar el campo en el registro
function validar_campo_nombre_comercial_empresa( $validation_errors, $username, $email ) {
    if ( ! isset( $_POST['woocommerce_register_nonce'] ) || ! wp_verify_nonce( $_POST['woocommerce_register_nonce'], 'woocommerce_register_action' ) ) {
        $validation_errors->add( 'security_error', __( 'Error de seguridad, por favor intente nuevamente.', 'woocommerce' ) );
        return $validation_errors;
    }

    if ( empty( $_POST['company'] ) ) {
        $validation_errors->add( 'company_error', __( 'Por favor, ingresa el Nombre Comercial y la Empresa de Envío.', 'woocommerce' ) );
    } elseif ( strlen( sanitize_text_field( $_POST['company'] ) ) > 200 ) {
        $validation_errors->add( 'company_length_error', __( 'El campo no puede superar los 200 caracteres.', 'woocommerce' ) );
    }

    return $validation_errors;
}
add_filter( 'woocommerce_registration_errors', 'validar_campo_nombre_comercial_empresa', 10, 3 );

// 3. Guardar el campo en el metadato "company"
function guardar_campo_nombre_comercial_empresa( $customer_id ) {
    if ( isset( $_POST['woocommerce_register_nonce'] ) && wp_verify_nonce( $_POST['woocommerce_register_nonce'], 'woocommerce_register_action' ) ) {
        if ( isset( $_POST['company'] ) ) {
            $company = sanitize_text_field( $_POST['company'] );
            update_user_meta( $customer_id, 'company', $company );
        }
    }
}
add_action( 'woocommerce_created_customer', 'guardar_campo_nombre_comercial_empresa' );

// 4. Mostrar el campo en el área de administración del perfil del usuario
function mostrar_campo_nombre_comercial_empresa_admin( $user ) {
    ?>
    <h3><?php _e( 'Información de la Empresa', 'woocommerce' ); ?></h3>
    <table class="form-table">
        <tr>
            <th><label for="company"><?php _e( 'Nombre Comercial', 'woocommerce' ); ?></label></th>
            <td>
                <input type="text" name="company" id="company" value="<?php echo esc_attr( get_user_meta( $user->ID, 'company', true ) ); ?>" class="regular-text" maxlength="200" />
            </td>
        </tr>
    </table>
    <?php
}
add_action( 'show_user_profile', 'mostrar_campo_nombre_comercial_empresa_admin' );
add_action( 'edit_user_profile', 'mostrar_campo_nombre_comercial_empresa_admin' );

// 5. Guardar el campo desde el perfil de administración
function guardar_campo_nombre_comercial_empresa_admin( $user_id ) {
    if ( isset( $_POST['company'] ) ) {
        $company = sanitize_text_field( $_POST['company'] );
        update_user_meta( $user_id, 'company', $company );
    }
}
add_action( 'personal_options_update', 'guardar_campo_nombre_comercial_empresa_admin' );
add_action( 'edit_user_profile_update', 'guardar_campo_nombre_comercial_empresa_admin' );




// 1. Añadir el campo combinado de Número de Teléfono (Facturación y Envío) al formulario de registro de WooCommerce
function agregar_campo_telefono_combinado_woocommerce() {
    wp_nonce_field( 'woocommerce_register_action', 'woocommerce_register_nonce' );
    ?>
    <p class="form-row form-row-wide">
        <label for="phone_number"><?php _e( 'Número de Teléfono', 'woocommerce' ); ?> <span class="required">*</span></label>
        <input type="text" class="input-text" name="phone_number" id="phone_number" value="<?php if ( ! empty( $_POST['phone_number'] ) ) echo esc_attr( wp_unslash( $_POST['phone_number'] ) ); ?>" />
    </p>

    <script type="text/javascript">
        // Validación en el lado del cliente para el campo combinado de teléfono
        document.getElementById('phone_number').addEventListener('input', function (event) {
            var valor = event.target.value;
            var valorFiltrado = valor.replace(/[^0-9]/g, ''); // Solo números
            if (valorFiltrado.length > 15) {
                valorFiltrado = valorFiltrado.substring(0, 15); // Limitar a 15 caracteres
            }
            event.target.value = valorFiltrado;
        });
    </script>
    <?php
}
add_action( 'woocommerce_register_form', 'agregar_campo_telefono_combinado_woocommerce' );

// 2. Validar el campo combinado de teléfono durante el registro
function validar_telefono_combinado_woocommerce( $username, $email, $validation_errors ) {
    // Verificar nonce de seguridad
    if ( ! isset( $_POST['woocommerce_register_nonce'] ) || ! wp_verify_nonce( $_POST['woocommerce_register_nonce'], 'woocommerce_register_action' ) ) {
        $validation_errors->add( 'security_error', __( 'Error de seguridad, por favor intente nuevamente.', 'woocommerce' ) );
        return $validation_errors;
    }

    if ( isset( $_POST['phone_number'] ) ) {
        $phone_number = sanitize_text_field( $_POST['phone_number'] );

        // Validar que solo contenga números
        if ( ! preg_match( '/^\d+$/', $phone_number ) ) {
            $validation_errors->add( 'phone_number_error', __( 'El número de teléfono solo debe contener números.', 'woocommerce' ) );
        }

        // Validar que la longitud no sea mayor a 15 caracteres
        if ( strlen( $phone_number ) > 15 ) {
            $validation_errors->add( 'phone_number_error', __( 'El número de teléfono no puede exceder los 15 caracteres.', 'woocommerce' ) );
        }

        // Validar que no esté vacío
        if ( empty( $phone_number ) ) {
            $validation_errors->add( 'phone_number_error', __( 'Por favor, ingresa tu número de teléfono.', 'woocommerce' ) );
        }
    }

    return $validation_errors;
}
add_action( 'woocommerce_register_post', 'validar_telefono_combinado_woocommerce', 10, 3 );

// 3. Guardar el número de teléfono combinado en el perfil del usuario después del registro
function guardar_telefono_combinado_woocommerce( $customer_id ) {
    if ( isset( $_POST['phone_number'] ) ) {
        $phone_number = sanitize_text_field( $_POST['phone_number'] );
        update_user_meta( $customer_id, 'phone_number', $phone_number );

        // Guardar también en billing_phone y shipping_phone el mismo valor
        update_user_meta( $customer_id, 'billing_phone', $phone_number );
        update_user_meta( $customer_id, 'shipping_phone', $phone_number );
    }
}
add_action( 'woocommerce_created_customer', 'guardar_telefono_combinado_woocommerce' );

// 4. Mostrar el número de teléfono combinado en el perfil del usuario en el área de administración
function mostrar_telefono_combinado_admin_usuario( $user ) {
    ?>
    <h3><?php _e( 'Información adicional del usuario', 'woocommerce' ); ?></h3>
    <table class="form-table">
        <tr>
            <th><label for="phone_number"><?php _e( 'Número de Teléfono (Facturación y Envío)', 'woocommerce' ); ?></label></th>
            <td>
                <input type="text" name="phone_number" id="phone_number" value="<?php echo esc_attr( get_user_meta( $user->ID, 'phone_number', true ) ); ?>" class="regular-text" />
            </td>
        </tr>
    </table>
    <?php
}
add_action( 'show_user_profile', 'mostrar_telefono_combinado_admin_usuario' );
add_action( 'edit_user_profile', 'mostrar_telefono_combinado_admin_usuario' );

// 5. Guardar el número de teléfono desde el área de administración
function guardar_telefono_combinado_admin_usuario( $user_id ) {
    if ( isset( $_POST['phone_number'] ) ) {
        $phone_number = sanitize_text_field( $_POST['phone_number'] );
        update_user_meta( $user_id, 'phone_number', $phone_number );

        // Guardar también en billing_phone y shipping_phone el mismo valor
        update_user_meta( $user_id, 'billing_phone', $phone_number );
        update_user_meta( $user_id, 'shipping_phone', $phone_number );
    }
}
add_action( 'personal_options_update', 'guardar_telefono_combinado_admin_usuario' );
add_action( 'edit_user_profile_update', 'guardar_telefono_combinado_admin_usuario' );

// 6. Añadir validación de JavaScript para el campo de teléfono en el frontend
function agregar_validacion_telefono_js() {
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#phone_number').on('input', function() {
                var phoneValue = $(this).val();
                // Eliminar cualquier carácter no numérico
                $(this).val(phoneValue.replace(/[^0-9]/g, ''));

                // Limitar a 15 caracteres
                if ($(this).val().length > 15) {
                    $(this).val($(this).val().substr(0, 15));
                }
            });
        });
    </script>
    <?php
}
add_action( 'wp_footer', 'agregar_validacion_telefono_js' );




// 1. Añadir campo "Tipo de IVA" y campo dinámico "CUIT/CUIL" al formulario de registro
function agregar_campos_personalizados_woocommerce() {
    wp_nonce_field('woocommerce_register_action', 'woocommerce_register_nonce');
    ?>
    <p class="form-row form-row-wide">
        <label for="tipo_iva"><?php _e('Tipo de IVA', 'woocommerce'); ?> <span class="required">*</span></label>
        <select name="tipo_iva" id="tipo_iva">
            <option value="inscripto"><?php _e('Inscripto', 'woocommerce'); ?></option>
            <option value="monotributo"><?php _e('Monotributo', 'woocommerce'); ?></option>
            <option value="exento"><?php _e('Exento', 'woocommerce'); ?></option>
            <option value="consumidor_final"><?php _e('Consumidor Final', 'woocommerce'); ?></option>
        </select>
    </p>
    <p class="form-row form-row-wide">
        <label for="cuit" id="label_cuit"><?php _e('CUIT', 'woocommerce'); ?> <span class="required">*</span></label>
        <input type="text" class="input-text" name="cuit" id="cuit" value="<?php if (!empty($_POST['cuit'])) echo esc_attr(wp_unslash($_POST['cuit'])); ?>" maxlength="11" />
    </p>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function () {
            var tipoIva = document.getElementById('tipo_iva');
            var cuitInput = document.getElementById('cuit');
            var labelCuit = document.getElementById('label_cuit');

            function actualizarCampo() {
                var tipo = tipoIva.value;
                if (tipo === 'consumidor_final') {
                    labelCuit.textContent = 'CUIL *';
                    cuitInput.maxLength = 11;
                } else {
                    labelCuit.textContent = 'CUIT *';
                    cuitInput.maxLength = 11;
                }
                cuitInput.value = cuitInput.value.replace(/\D/g, '').substring(0, cuitInput.maxLength);
            }

            tipoIva.addEventListener('change', actualizarCampo);
            cuitInput.addEventListener('input', function (e) {
                var tipo = tipoIva.value;
                var max = (tipo === 'consumidor_final') ? 8 : 11;
                var input = e.target.value.replace(/\D/g, '').substring(0, max);
                e.target.value = input;
            });

            actualizarCampo(); // Ejecutar al cargar
        });
    </script>
    <?php
}
add_action('woocommerce_register_form', 'agregar_campos_personalizados_woocommerce');

// 2. Validación del tipo de IVA y CUIT/CUIL
function validar_campos_personalizados_woocommerce($username, $email, $validation_errors) {
    if (!isset($_POST['woocommerce_register_nonce']) || !wp_verify_nonce($_POST['woocommerce_register_nonce'], 'woocommerce_register_action')) {
        $validation_errors->add('security_error', __('Error de seguridad, por favor intente nuevamente.', 'woocommerce'));
        return $validation_errors;
    }

    $tipo_iva = isset($_POST['tipo_iva']) ? sanitize_text_field($_POST['tipo_iva']) : '';
    $cuit = isset($_POST['cuit']) ? sanitize_text_field($_POST['cuit']) : '';

    $valid_types = array('inscripto', 'monotributo', 'exento', 'consumidor_final');

    if (empty($tipo_iva) || !in_array($tipo_iva, $valid_types)) {
        $validation_errors->add('tipo_iva_error', __('Por favor, selecciona un tipo de IVA válido.', 'woocommerce'));
    }

    if (empty($cuit) || !preg_match('/^\d+$/', $cuit)) {
        $validation_errors->add('cuit_error', __('El CUIT/CUIL solo debe contener números.', 'woocommerce'));
    }

    if ($tipo_iva === 'consumidor_final' && strlen($cuit) != 11) {
        $validation_errors->add('cuit_error', __('El CUIL debe tener exactamente 8 dígitos.', 'woocommerce'));
    }

    if ($tipo_iva !== 'consumidor_final' && strlen($cuit) != 11) {
        $validation_errors->add('cuit_error', __('El CUIT debe tener exactamente 11 dígitos.', 'woocommerce'));
    }

    return $validation_errors;
}
add_action('woocommerce_register_post', 'validar_campos_personalizados_woocommerce', 10, 3);

// 3. Guardar los campos personalizados
function guardar_campos_personalizados_woocommerce($customer_id) {
    if (isset($_POST['tipo_iva'])) {
        $tipo_iva = sanitize_text_field($_POST['tipo_iva']);
        update_user_meta($customer_id, 'billing_tipo_iva', $tipo_iva);
        update_user_meta($customer_id, 'shipping_tipo_iva', $tipo_iva);
    }

    if (isset($_POST['cuit'])) {
        $cuit = sanitize_text_field($_POST['cuit']);
        update_user_meta($customer_id, 'billing_cuit', $cuit);
        update_user_meta($customer_id, 'shipping_cuit', $cuit);
        update_user_meta($customer_id, '_billing_cuit', $cuit);
        update_user_meta($customer_id, '_shipping_cuit', $cuit);
    }
}
add_action('woocommerce_created_customer', 'guardar_campos_personalizados_woocommerce');

// 4. Mostrar campos en el perfil del admin
function mostrar_campos_personalizados_admin_usuario($user) {
    $tipo_iva = get_user_meta($user->ID, 'billing_tipo_iva', true);
    $cuit = get_user_meta($user->ID, 'billing_cuit', true);
    ?>
    <h3><?php _e('Información adicional del usuario', 'woocommerce'); ?></h3>
    <table class="form-table">
        <tr>
            <th><label for="tipo_iva"><?php _e('Tipo de IVA', 'woocommerce'); ?></label></th>
            <td>
                <select name="tipo_iva" id="tipo_iva">
                    <option value="inscripto" <?php selected($tipo_iva, 'inscripto'); ?>><?php _e('Inscripto', 'woocommerce'); ?></option>
                    <option value="monotributo" <?php selected($tipo_iva, 'monotributo'); ?>><?php _e('Monotributo', 'woocommerce'); ?></option>
                    <option value="exento" <?php selected($tipo_iva, 'exento'); ?>><?php _e('Exento', 'woocommerce'); ?></option>
                    <option value="consumidor_final" <?php selected($tipo_iva, 'consumidor_final'); ?>><?php _e('Consumidor Final', 'woocommerce'); ?></option>
                </select>
            </td>
        </tr>
        <tr>
            <th><label for="cuit"><?php _e('CUIT/CUIL', 'woocommerce'); ?></label></th>
            <td>
                <input type="text" name="cuit" id="cuit" value="<?php echo esc_attr($cuit); ?>" class="regular-text" maxlength="11" />
            </td>
        </tr>
    </table>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function () {
            var tipoIva = document.getElementById('tipo_iva');
            var cuitInput = document.getElementById('cuit');

            function actualizarCampo() {
                var tipo = tipoIva.value;
                cuitInput.maxLength = (tipo === 'consumidor_final') ? 8 : 11;
                cuitInput.value = cuitInput.value.replace(/\D/g, '').substring(0, cuitInput.maxLength);
            }

            tipoIva.addEventListener('change', actualizarCampo);
            cuitInput.addEventListener('input', function (e) {
                var tipo = tipoIva.value;
                var max = (tipo === 'consumidor_final') ? 8 : 11;
                var input = e.target.value.replace(/\D/g, '').substring(0, max);
                e.target.value = input;
            });

            actualizarCampo();
        });
    </script>
    <?php
}
add_action('show_user_profile', 'mostrar_campos_personalizados_admin_usuario');
add_action('edit_user_profile', 'mostrar_campos_personalizados_admin_usuario');

// 5. Guardar campos desde el admin
function guardar_campos_personalizados_admin_usuario($user_id) {
    if (isset($_POST['tipo_iva'])) {
        $tipo_iva = sanitize_text_field($_POST['tipo_iva']);
        update_user_meta($user_id, 'billing_tipo_iva', $tipo_iva);
        update_user_meta($user_id, 'shipping_tipo_iva', $tipo_iva);
    }

    if (isset($_POST['cuit'])) {
        $cuit = sanitize_text_field($_POST['cuit']);
        update_user_meta($user_id, 'billing_cuit', $cuit);
        update_user_meta($user_id, 'shipping_cuit', $cuit);
        update_user_meta($user_id, '_billing_cuit', $cuit);
        update_user_meta($user_id, '_shipping_cuit', $cuit);
    }
}
add_action('personal_options_update', 'guardar_campos_personalizados_admin_usuario');
add_action('edit_user_profile_update', 'guardar_campos_personalizados_admin_usuario');



// 1. Añadir el campo Código Postal combinado (Facturación y Envío) al formulario de registro de WooCommerce
function agregar_campo_postcode_combinado_woocommerce() {
    wp_nonce_field( 'woocommerce_register_action', 'woocommerce_register_nonce' );
    ?>
    <p class="form-row form-row-wide">
        <label for="postcode"><?php _e( 'Código Postal', 'woocommerce' ); ?> <span class="required">*</span></label>
        <input type="text" class="input-text" name="postcode" id="postcode" value="<?php if ( ! empty( $_POST['postcode'] ) ) echo esc_attr( wp_unslash( $_POST['postcode'] ) ); ?>" maxlength="4" />
    </p>

    <script type="text/javascript">
        document.getElementById('postcode').addEventListener('input', function(e) {
            var input = e.target.value;
            // Eliminar cualquier carácter no numérico
            input = input.replace(/\D/g, '');
            // Limitar a 4 caracteres
            if (input.length > 4) {
                input = input.substring(0, 4);
            }
            e.target.value = input;
        });
    </script>
    <?php
}
add_action( 'woocommerce_register_form', 'agregar_campo_postcode_combinado_woocommerce' );

// 2. Validar el campo Código Postal combinado durante el registro
function validar_postcode_combinado_woocommerce( $username, $email, $validation_errors ) {
    // Verificar nonce de seguridad
    if ( ! isset( $_POST['woocommerce_register_nonce'] ) || ! wp_verify_nonce( $_POST['woocommerce_register_nonce'], 'woocommerce_register_action' ) ) {
        $validation_errors->add( 'security_error', __( 'Error de seguridad, por favor intente nuevamente.', 'woocommerce' ) );
        return $validation_errors;
    }

    if ( isset( $_POST['postcode'] ) && empty( $_POST['postcode'] ) ) {
        $validation_errors->add( 'postcode_error', __( 'Por favor, ingresa tu código postal.', 'woocommerce' ) );
    } else {
        // Sanitizar y validar que solo contiene números y que no exceda los 4 caracteres
        $postcode = sanitize_text_field( $_POST['postcode'] );
        if ( ! preg_match( '/^\d{1,4}$/', $postcode ) ) {
            $validation_errors->add( 'postcode_error', __( 'El código postal solo puede contener hasta 4 dígitos numéricos.', 'woocommerce' ) );
        }
    }

    return $validation_errors;
}
add_action( 'woocommerce_register_post', 'validar_postcode_combinado_woocommerce', 10, 3 );

// 3. Guardar el código postal combinado (Facturación y Envío) en el perfil del usuario después del registro
function guardar_postcode_combinado_woocommerce( $customer_id ) {
    if ( isset( $_POST['postcode'] ) ) {
        // Sanitizar y asegurar que solo contiene números
        $postcode = sanitize_text_field( $_POST['postcode'] );
        $postcode = preg_replace( '/\D/', '', $postcode ); // Eliminar caracteres no numéricos
        // Limitar la longitud a 4 caracteres
        $postcode = substr( $postcode, 0, 4 );
        update_user_meta( $customer_id, 'billing_postcode', $postcode );
        update_user_meta( $customer_id, 'shipping_postcode', $postcode );
        update_user_meta( $customer_id, '_billing_postcode', $postcode ); // Para WooCommerce
        update_user_meta( $customer_id, '_shipping_postcode', $postcode ); // Para WooCommerce
    }
}
add_action( 'woocommerce_created_customer', 'guardar_postcode_combinado_woocommerce' );

// 4. Mostrar el campo Código Postal combinado en el perfil del usuario en el área de administración
function mostrar_postcode_combinado_admin_usuario( $user ) {
    ?>
    <h3><?php _e( 'Información adicional del usuario', 'woocommerce' ); ?></h3>
    <table class="form-table">
        <tr>
            <th><label for="postcode"><?php _e( 'Código Postal (Facturación y Envío)', 'woocommerce' ); ?></label></th>
            <td>
                <input type="text" name="postcode" id="postcode" value="<?php echo esc_attr( get_user_meta( $user->ID, 'billing_postcode', true ) ); ?>" class="regular-text" maxlength="4" />
            </td>
        </tr>
    </table>
    <?php
}
add_action( 'show_user_profile', 'mostrar_postcode_combinado_admin_usuario' );
add_action( 'edit_user_profile', 'mostrar_postcode_combinado_admin_usuario' );

// 5. Guardar el código postal desde el área de administración del perfil de usuario
function guardar_postcode_combinado_admin_usuario( $user_id ) {
    if ( isset( $_POST['postcode'] ) ) {
        // Sanitizar y asegurar que solo contiene números
        $postcode = sanitize_text_field( $_POST['postcode'] );
        $postcode = preg_replace( '/\D/', '', $postcode ); // Eliminar caracteres no numéricos
        // Limitar la longitud a 4 caracteres
        $postcode = substr( $postcode, 0, 4 );
        update_user_meta( $user_id, 'billing_postcode', $postcode );
        update_user_meta( $user_id, 'shipping_postcode', $postcode );
        update_user_meta( $user_id, '_billing_postcode', $postcode ); // Para WooCommerce
        update_user_meta( $user_id, '_shipping_postcode', $postcode ); // Para WooCommerce
    }
}
add_action( 'personal_options_update', 'guardar_postcode_combinado_admin_usuario' );
add_action( 'edit_user_profile_update', 'guardar_postcode_combinado_admin_usuario' );

// 1. Añadir el campo Dirección combinado (Facturación y Envío) al formulario de registro de WooCommerce
function agregar_campo_direccion_combinado_woocommerce() {
    wp_nonce_field( 'woocommerce_register_action', 'woocommerce_register_nonce' );
    ?>
    <p class="form-row form-row-wide">
        <label for="address_1"><?php _e( 'Dirección', 'woocommerce' ); ?> <span class="required">*</span></label>
        <input type="text" class="input-text" name="address_1" id="address_1" value="<?php if ( ! empty( $_POST['address_1'] ) ) echo esc_attr( wp_unslash( $_POST['address_1'] ) ); ?>" />
    </p>
    <?php
}
add_action( 'woocommerce_register_form', 'agregar_campo_direccion_combinado_woocommerce' );

// 2. Validar el campo Dirección combinado durante el registro
function validar_direccion_combinada_woocommerce( $username, $email, $validation_errors ) {
    // Verificar nonce de seguridad
    if ( ! isset( $_POST['woocommerce_register_nonce'] ) || ! wp_verify_nonce( $_POST['woocommerce_register_nonce'], 'woocommerce_register_action' ) ) {
        $validation_errors->add( 'security_error', __( 'Error de seguridad, por favor intente nuevamente.', 'woocommerce' ) );
        return $validation_errors;
    }

    if ( isset( $_POST['address_1'] ) && empty( $_POST['address_1'] ) ) {
        $validation_errors->add( 'address_1_error', __( 'Por favor, ingresa tu dirección.', 'woocommerce' ) );
    }

    return $validation_errors;
}
add_action( 'woocommerce_register_post', 'validar_direccion_combinada_woocommerce', 10, 3 );

// 3. Guardar el campo Dirección combinado (Facturación y Envío) en el perfil del usuario y en WooCommerce después del registro
function guardar_direccion_combinada_woocommerce( $customer_id ) {
    if ( isset( $_POST['address_1'] ) ) {
        // Sanitizar y guardar la dirección
        $address_1 = sanitize_text_field( $_POST['address_1'] );
        // Guardar tanto en los metadatos del usuario como en WooCommerce
        update_user_meta( $customer_id, 'billing_address_1', $address_1 );
        update_user_meta( $customer_id, 'shipping_address_1', $address_1 );
        update_user_meta( $customer_id, '_billing_address_1', $address_1 ); // Para WooCommerce
        update_user_meta( $customer_id, '_shipping_address_1', $address_1 ); // Para WooCommerce
    }
}
add_action( 'woocommerce_created_customer', 'guardar_direccion_combinada_woocommerce' );

// 4. Mostrar el campo Dirección combinado en el perfil del usuario en el área de administración
function mostrar_direccion_combinada_admin_usuario( $user ) {
    ?>
    <h3><?php _e( 'Información adicional del usuario', 'woocommerce' ); ?></h3>
    <table class="form-table">
        <tr>
            <th><label for="address_1"><?php _e( 'Dirección (Facturación y Envío)', 'woocommerce' ); ?></label></th>
            <td>
                <input type="text" name="address_1" id="address_1" value="<?php echo esc_attr( get_user_meta( $user->ID, 'billing_address_1', true ) ); ?>" class="regular-text" />
            </td>
        </tr>
    </table>
    <?php
}
add_action( 'show_user_profile', 'mostrar_direccion_combinada_admin_usuario' );
add_action( 'edit_user_profile', 'mostrar_direccion_combinada_admin_usuario' );

// 5. Guardar la dirección desde el área de administración del perfil de usuario
function guardar_direccion_combinada_admin_usuario( $user_id ) {
    if ( isset( $_POST['address_1'] ) ) {
        // Sanitizar y guardar la dirección
        $address_1 = sanitize_text_field( $_POST['address_1'] );
        update_user_meta( $user_id, 'billing_address_1', $address_1 );
        update_user_meta( $user_id, 'shipping_address_1', $address_1 );
        update_user_meta( $user_id, '_billing_address_1', $address_1 ); // Guardar también en WooCommerce
        update_user_meta( $user_id, '_shipping_address_1', $address_1 ); // Guardar también en WooCommerce
    }
}
add_action( 'personal_options_update', 'guardar_direccion_combinada_admin_usuario' );
add_action( 'edit_user_profile_update', 'guardar_direccion_combinada_admin_usuario' );



// 1. Añadir el campo de provincia en el formulario de registro de WooCommerce (siempre con país 'AR' - Argentina)
function agregar_campo_provincias_woocommerce() {
    wp_nonce_field( 'woocommerce_register_action', 'woocommerce_register_nonce' );

    // Asegurarse de que la región sea siempre Argentina
    $wc_countries = new WC_Countries();
    $provincias = $wc_countries->get_states( 'AR' );  // 'AR' es el código de Argentina en WooCommerce

    ?>
    <p class="form-row form-row-wide">
        <label for="provincia"><?php _e( 'Provincia', 'woocommerce' ); ?> <span class="required">*</span></label>
        <select name="provincia" id="provincia" required>
            <option value=""><?php _e( 'Selecciona una provincia', 'woocommerce' ); ?></option>
            <?php foreach ( $provincias as $state_code => $state_name ) : ?>
                <option value="<?php echo esc_attr( $state_code ); ?>"><?php echo esc_html( $state_name ); ?></option>
            <?php endforeach; ?>
        </select>
    </p>
    <?php
}
add_action( 'woocommerce_register_form', 'agregar_campo_provincias_woocommerce' );

// 2. Validar el campo de provincia durante el registro
function validar_provincia_woocommerce( $username, $email, $validation_errors ) {
    // Verificar nonce de seguridad
    if ( ! isset( $_POST['woocommerce_register_nonce'] ) || ! wp_verify_nonce( $_POST['woocommerce_register_nonce'], 'woocommerce_register_action' ) ) {
        $validation_errors->add( 'security_error', __( 'Error de seguridad, por favor intente nuevamente.', 'woocommerce' ) );
        return $validation_errors;
    }

    if ( isset( $_POST['provincia'] ) && empty( $_POST['provincia'] ) ) {
        $validation_errors->add( 'provincia_error', __( 'Por favor, selecciona una provincia.', 'woocommerce' ) );
    }

    return $validation_errors;
}
add_action( 'woocommerce_register_post', 'validar_provincia_woocommerce', 10, 3 );

// 3. Guardar la provincia en los campos de estado (billing_state y shipping_state) durante el registro del usuario
function guardar_provincia_woocommerce( $customer_id ) {
    if ( isset( $_POST['provincia'] ) ) {
        $provincia = sanitize_text_field( $_POST['provincia'] );
        // Guardar la provincia directamente en billing_state y shipping_state
        update_user_meta( $customer_id, 'billing_state', $provincia );
        update_user_meta( $customer_id, 'shipping_state', $provincia );
        
        // Asegurar que el país siempre sea Argentina (AR)
        update_user_meta( $customer_id, 'billing_country', 'AR' );
        update_user_meta( $customer_id, 'shipping_country', 'AR' );
    }
}
add_action( 'woocommerce_created_customer', 'guardar_provincia_woocommerce' );

// 4. Mostrar la provincia en el perfil de administración del usuario
function mostrar_provincia_admin_usuario( $user ) {
    // Obtener las provincias de Argentina usando WC_Countries
    $wc_countries = new WC_Countries();
    $provincias = $wc_countries->get_states( 'AR' );  // 'AR' es el código de Argentina en WooCommerce

    ?>
    <h3><?php _e( 'Información de dirección', 'woocommerce' ); ?></h3>
    <table class="form-table">
        <tr>
            <th><label for="provincia"><?php _e( 'Provincia', 'woocommerce' ); ?></label></th>
            <td>
                <select name="provincia" id="provincia">
                    <?php foreach ( $provincias as $state_code => $state_name ) : ?>
                        <option value="<?php echo esc_attr( $state_code ); ?>" <?php selected( get_user_meta( $user->ID, 'billing_state', true ), $state_code ); ?>>
                            <?php echo esc_html( $state_name ); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
    </table>
    <?php
}
add_action( 'show_user_profile', 'mostrar_provincia_admin_usuario' );
add_action( 'edit_user_profile', 'mostrar_provincia_admin_usuario' );

// 5. Guardar la provincia desde el área de administración del perfil de usuario (facturación y envío)
function guardar_provincia_admin_usuario( $user_id ) {
    if ( isset( $_POST['provincia'] ) ) {
        $provincia = sanitize_text_field( $_POST['provincia'] );
        // Guardar la provincia en billing_state y shipping_state
        update_user_meta( $user_id, 'billing_state', $provincia );
        update_user_meta( $user_id, 'shipping_state', $provincia );
        
        // Asegurar que el país siempre sea Argentina (AR)
        update_user_meta( $user_id, 'billing_country', 'AR' );
        update_user_meta( $user_id, 'shipping_country', 'AR' );
    }
}
add_action( 'personal_options_update', 'guardar_provincia_admin_usuario' );
add_action( 'edit_user_profile_update', 'guardar_provincia_admin_usuario' );

// 6. Mostrar el campo de provincia en el checkout para usuarios ya registrados
function mostrar_provincia_checkout( $fields ) {
    // Obtener las provincias de Argentina usando WC_Countries
    $wc_countries = new WC_Countries();
    $provincias = $wc_countries->get_states( 'AR' );

    // Añadir el campo de provincia a billing y shipping en el checkout
    $fields['billing']['billing_state'] = array(
        'type'        => 'select',
        'label'       => __('Provincia', 'woocommerce'),
        'options'     => array_merge( array( '' => __( 'Selecciona una provincia', 'woocommerce' ) ), $provincias ),
        'required'    => true,
        'class'       => array( 'form-row-wide' ),
        'default'     => 'AR',  // Por defecto siempre es Argentina
    );

    $fields['shipping']['shipping_state'] = array(
        'type'        => 'select',
        'label'       => __('Provincia de envío', 'woocommerce'),
        'options'     => array_merge( array( '' => __( 'Selecciona una provincia', 'woocommerce' ) ), $provincias ),
        'required'    => true,
        'class'       => array( 'form-row-wide' ),
        'default'     => 'AR',  // Por defecto siempre es Argentina
    );

    return $fields;
}
add_filter( 'woocommerce_checkout_fields', 'mostrar_provincia_checkout' );

// 7. Guardar la provincia en el checkout para usuarios ya registrados (facturación y envío)
function guardar_provincia_checkout( $order_id ) {
    if ( isset( $_POST['billing_state'] ) ) {
        $provincia = sanitize_text_field( $_POST['billing_state'] );
        update_post_meta( $order_id, '_billing_state', $provincia );
    }

    if ( isset( $_POST['shipping_state'] ) ) {
        $provincia = sanitize_text_field( $_POST['shipping_state'] );
        update_post_meta( $order_id, '_shipping_state', $provincia );
    }
}
add_action( 'woocommerce_checkout_update_order_meta', 'guardar_provincia_checkout' );

// 8. Mostrar la provincia en el detalle del pedido en la administración de WooCommerce
function mostrar_provincia_detalle_pedido( $order ) {
    $provincia_billing = get_post_meta( $order->get_id(), '_billing_state', true );
    $provincia_shipping = get_post_meta( $order->get_id(), '_shipping_state', true );

    if ( $provincia_billing ) {
        echo '<p><strong>' . __('Provincia de Facturación', 'woocommerce') . ':</strong> ' . esc_html( $provincia_billing ) . '</p>';
    }
    if ( $provincia_shipping ) {
        echo '<p><strong>' . __('Provincia de Envío', 'woocommerce') . ':</strong> ' . esc_html( $provincia_shipping ) . '</p>';
    }
}
add_action( 'woocommerce_admin_order_data_after_billing_address', 'mostrar_provincia_detalle_pedido', 10, 1 );
add_action( 'woocommerce_admin_order_data_after_shipping_address', 'mostrar_provincia_detalle_pedido', 10, 1 );



// 1. Añadir el campo Ciudad (facturación + envío) al formulario de registro de WooCommerce
function agregar_campo_ciudad_combinada_woocommerce() {
    wp_nonce_field( 'woocommerce_register_action', 'woocommerce_register_nonce' );
    ?>
    <p class="form-row form-row-wide">
        <label for="city_combined"><?php _e( 'Ciudad', 'woocommerce' ); ?> <span class="required">*</span></label>
        <input type="text" class="input-text" name="city_combined" id="city_combined" value="<?php if ( ! empty( $_POST['city_combined'] ) ) echo esc_attr( wp_unslash( $_POST['city_combined'] ) ); ?>" maxlength="25" />
    </p>
    <script type="text/javascript">
        document.getElementById('city_combined').addEventListener('input', function(e) {
            var input = e.target.value;
            input = input.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, ''); // Solo letras y espacios
            if (input.length > 25) {
                input = input.substring(0, 25);
            }
            e.target.value = input;
        });
    </script>
    <?php
}
add_action( 'woocommerce_register_form', 'agregar_campo_ciudad_combinada_woocommerce' );

// 2. Validar el campo Ciudad combinado durante el registro
function validar_ciudad_combinada_woocommerce( $username, $email, $validation_errors ) {
    if ( ! isset( $_POST['woocommerce_register_nonce'] ) || ! wp_verify_nonce( $_POST['woocommerce_register_nonce'], 'woocommerce_register_action' ) ) {
        $validation_errors->add( 'security_error', __( 'Error de seguridad, por favor intente nuevamente.', 'woocommerce' ) );
        return $validation_errors;
    }

    if ( isset( $_POST['city_combined'] ) && empty( $_POST['city_combined'] ) ) {
        $validation_errors->add( 'city_combined_error', __( 'Por favor, ingresa tu ciudad de facturación y envío.', 'woocommerce' ) );
    } else {
        $city_combined = sanitize_text_field( $_POST['city_combined'] );
        if ( ! preg_match( '/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/', $city_combined ) ) {
            $validation_errors->add( 'city_combined_error', __( 'La ciudad solo puede contener letras y espacios.', 'woocommerce' ) );
        }
        if ( strlen( $city_combined ) > 25 ) {
            $validation_errors->add( 'city_combined_error', __( 'La ciudad no puede tener más de 25 caracteres.', 'woocommerce' ) );
        }
    }
    return $validation_errors;
}
add_action( 'woocommerce_register_post', 'validar_ciudad_combinada_woocommerce', 10, 3 );

// 3. Guardar el campo Ciudad combinado (facturación + envío) en el perfil del usuario
function guardar_ciudad_combinada_woocommerce( $customer_id ) {
    if ( isset( $_POST['city_combined'] ) ) {
        $city_combined = sanitize_text_field( $_POST['city_combined'] );
        $city_combined = preg_replace( '/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/', '', $city_combined ); // Eliminar caracteres no permitidos
        $city_combined = substr( $city_combined, 0, 25 );
        update_user_meta( $customer_id, 'billing_city', $city_combined );
        update_user_meta( $customer_id, 'shipping_city', $city_combined );
        update_user_meta( $customer_id, '_billing_city', $city_combined ); // Para WooCommerce
        update_user_meta( $customer_id, '_shipping_city', $city_combined ); // Para WooCommerce
    }
}
add_action( 'woocommerce_created_customer', 'guardar_ciudad_combinada_woocommerce' );

// 4. Mostrar el campo Ciudad combinado en el perfil del usuario en el área de administración
function mostrar_ciudad_combinada_admin_usuario( $user ) {
    ?>
    <h3><?php _e( 'Información adicional del usuario', 'woocommerce' ); ?></h3>
    <table class="form-table">
        <tr>
            <th><label for="city_combined"><?php _e( 'Ciudad (Facturación y Envío)', 'woocommerce' ); ?></label></th>
            <td>
                <input type="text" name="city_combined" id="city_combined" value="<?php echo esc_attr( get_user_meta( $user->ID, 'billing_city', true ) ); ?>" class="regular-text" maxlength="25" />
            </td>
        </tr>
    </table>
    <?php
}
add_action( 'show_user_profile', 'mostrar_ciudad_combinada_admin_usuario' );
add_action( 'edit_user_profile', 'mostrar_ciudad_combinada_admin_usuario' );

// 5. Guardar la ciudad combinada desde el área de administración del perfil de usuario
function guardar_ciudad_combinada_admin_usuario( $user_id ) {
    if ( isset( $_POST['city_combined'] ) ) {
        $city_combined = sanitize_text_field( $_POST['city_combined'] );
        $city_combined = preg_replace( '/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/', '', $city_combined ); // Eliminar caracteres no permitidos
        $city_combined = substr( $city_combined, 0, 25 );
        update_user_meta( $user_id, 'billing_city', $city_combined );
        update_user_meta( $user_id, 'shipping_city', $city_combined );
        update_user_meta( $user_id, '_billing_city', $city_combined ); // Para WooCommerce
        update_user_meta( $user_id, '_shipping_city', $city_combined ); // Para WooCommerce
    }
}
add_action( 'personal_options_update', 'guardar_ciudad_combinada_admin_usuario' );
add_action( 'edit_user_profile_update', 'guardar_ciudad_combinada_admin_usuario' );










?>